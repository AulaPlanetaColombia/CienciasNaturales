(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
        titulo1(this,txt['titulo']);


	this.instance = new lib.botiquin();
	this.instance.setTransform(663,332.4,0.731,0.731,0,0,0,44,0.5);

	
	this.text = new cjs.Text(txt['txt1'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(666.1,532.5);
	this.btn1 = new lib.btn3();
	this.btn1.setTransform(129.8,251.7);
	new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.btn3(), 3);

	this.btn2 = new lib.btn2();
	this.btn2.setTransform(129.8,331.7);
	new cjs.ButtonHelper(this.btn2, 0, 1, 2, false, new lib.btn2(), 3);

	this.btn3 = new lib.btn1();
	this.btn3.setTransform(129.8,411.7);
	new cjs.ButtonHelper(this.btn3, 0, 1, 2, false, new lib.btn1(), 3);
 this.btn1.on("click", function (evt) {
        putStage(new lib.frame2());
    });
 this.btn2.on("click", function (evt) {
        putStage(new lib.frame3());
    });
 this.btn3.on("click", function (evt) {
        putStage(new lib.frame4(0));
    });

       
        this.addChild(this.logo, this.titulo, this.siguiente, this.btn3,this.btn2,this.btn1,this.text_1,this.instance,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        //titulo2(this, txt['titulo']);
	

	this.text_1 = new cjs.Text("Es esencial para poder actuar ante cualquier accidente que se pueda producir.\n\nHay que tener siempre uno casa, en el colegio y en el lugar de trabajo.\n\n\n¡Reflexiona!\n\n¿Qué elementos consideras que debe contener un buen botiquín de primeros auxilios?", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 461;
	this.text_1.setTransform(441,173.9);
  var html = createDiv(txt['txt2'], "Verdana", "20px", '470px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(441, 173-638);
	this.text_2 = new cjs.Text(txt['tit1'], "bold 23px Verdana");
	this.text_2.lineHeight = 23;
	this.text_2.lineWidth = 493;
	this.text_2.setTransform(101,30.9);

	 this.practica = new lib.btn_practica(txt['btnsolucion']);
        this.practica.setTransform(837, 565, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
  this.practica.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

	this.instance = new lib.imagen();
	this.instance.setTransform(231.5,329,1,1,0,0,0,151.5,198);
       
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance,this.practica,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
      // Capa 1
	this.text = new cjs.Text(txt['txt15'], "18px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 130;
	this.text.setTransform(855.4,494.9);

	this.text_1 = new cjs.Text(txt['txt14'], "18px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 130;
	this.text_1.setTransform(696.4,494.9);

	this.text_2 = new cjs.Text(txt['txt13'], "18px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 130;
	this.text_2.setTransform(549.4,494.9);

	this.text_3 = new cjs.Text(txt['txt12'], "18px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.lineWidth = 152;
	this.text_3.setTransform(391.4,494.9);

	this.text_4 = new cjs.Text(txt['txt11'], "18px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.lineWidth = 128;
	this.text_4.setTransform(237.4,494.9);

	this.text_5 = new cjs.Text(txt['txt10'], "18px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.lineWidth = 128;
	this.text_5.setTransform(96.4,494.9);

	this.text_6 = new cjs.Text(txt['txt9'], "18px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 18;
	this.text_6.lineWidth = 130;
	this.text_6.setTransform(865.4,244.9);

	this.text_7 = new cjs.Text(txt['txt8'], "18px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 18;
	this.text_7.lineWidth = 130;
	this.text_7.setTransform(725.4,244.9);

	this.text_8 = new cjs.Text(txt['txt7'], "18px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 18;
	this.text_8.lineWidth = 130;
	this.text_8.setTransform(585.4,244.9);

	this.text_9 = new cjs.Text(txt['txt6'], "18px Verdana");
	this.text_9.lineHeight = 18;
	this.text_9.lineWidth = 152;
	this.text_9.setTransform(415.4,244.9);

	this.text_10 = new cjs.Text(txt['txt5'], "18px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 18;
	this.text_10.lineWidth = 152;
	this.text_10.setTransform(307.4,244.9);

	this.text_11 = new cjs.Text(txt['txt4'], "18px Verdana");
	this.text_11.lineHeight = 18;
	this.text_11.lineWidth = 128;
	this.text_11.setTransform(146.4,244.9);

	this.text_12 = new cjs.Text(txt['txt3'], "18px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 18;
	this.text_12.lineWidth = 128;
	this.text_12.setTransform(82.4,244.9);

	this.instance = new lib.quemaduras();
	this.instance.setTransform(844.8,409.1,0.234,0.234,52,0,0,43.9,8.6);

	this.instance_1 = new lib.picaduras();
	this.instance_1.setTransform(696.8,409.6,0.226,0.226,-59.9,0,0,44.3,8.4);

	this.instance_2 = new lib.antiseptico();
	this.instance_2.setTransform(551.4,404.5,0.292,0.292,0,0,0,43.9,8.4);

	this.instance_3 = new lib.vendas();
	this.instance_3.setTransform(387.7,415.8,0.408,0.408,0,0,0,44,8.4);

	this.instance_4 = new lib.gasas();
	this.instance_4.setTransform(863.2,179.8,0.25,0.25,0,0,0,44.1,8.4);

	this.instance_5 = new lib.termometro();
	this.instance_5.setTransform(243.5,410.1,0.308,0.308,-59.9,0,0,44.1,8.3);

	this.instance_6 = new lib.espadadrapo();
	this.instance_6.setTransform(108.5,415.6,0.264,0.264,0,0,0,44,8.5);

	this.instance_7 = new lib.algodon();
	this.instance_7.setTransform(733.7,159,0.292,0.292,0,0,0,44,8.4);

	this.instance_8 = new lib.tiritas();
	this.instance_8.setTransform(593.3,170.1,0.264,0.264,-40.1,0,0,44,8.4);

	this.instance_9 = new lib.alcohol();
	this.instance_9.setTransform(450.7,160.2,0.38,0.38,0,0,0,44,8.4);

	this.instance_10 = new lib.tijras();
	this.instance_10.setTransform(326.4,162.5,0.367,0.367,0,0,0,44.1,8.6);

	this.instance_11 = new lib.pinzas();
	this.instance_11.setTransform(200.3,168,0.269,0.269,-59.9,0,0,44,8.5);

	this.instance_12 = new lib.agua();
	this.instance_12.setTransform(82,160.1,0.379,0.379,0,0,0,43.9,0.3);

       
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.instance_12,this.instance_11,this.instance_10,this.instance_9,this.instance_8,this.instance_7,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
      this.text = new cjs.Text(txt['txt16'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 461;
	this.text.setTransform(492,273.9);

	this.instance = new lib.Imagen1();
	this.instance.setTransform(274.4,289,1.111,1.111,0,0,0,151.4,198);


       
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
   this.instance = new lib.Imagen12();
	this.instance.setTransform(270.8,289.9,1.111,1.111,0,0,0,147.8,263.6);

	this.text = new cjs.Text("Paso 1: Lávate las manos con abundante agua y jabón.", "bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 412;
	this.text.setTransform(492.4,262.9);
  var html = createDiv(txt['txt17'], "Verdana", "20px", '420px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(480, 250-608);
	this.instance_1 = new lib.Imagen2();
	this.instance_1.setTransform(205,329,1,1,0,0,0,151.5,198);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1,this.text,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.text = new cjs.Text("Paso 1: Lávate las manos con abundante agua y jabón.", "bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 412;
	this.text.setTransform(492.4,262.9);
  var html = createDiv(txt['txt18'], "Verdana", "20px", '420px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(480, 250-608);
    this.instance = new lib.Imagen13();
	this.instance.setTransform(273.8,289,1.111,1.111,0,0,0,151.4,198);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame3_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        var html = createDiv(txt['txt19'], "Verdana", "20px", '420px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(480, 250-608);
    this.instance = new lib.Imagen14();
	this.instance.setTransform(273.8,289,1.111,1.111,0,0,0,151.4,198);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame3_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
         var html = createDiv(txt['txt20'], "Verdana", "20px", '420px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(480, 250-608);
	this.instance = new lib.Imagen15();
	this.instance.setTransform(273.8,289,1.111,1.111,0,0,0,151.4,198);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame3_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
   	this.instance = new lib.sec6();
	this.instance.setTransform(489.5,289.3,0.801,0.801,0,0,0,36.1,0.4);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
       
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame4 = function (resp) {
        this.initialize();
        clearTexts();

         // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
     // Capa 1
	this.text = new cjs.Text("112", "bold 23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 23;
        
          if (isbq)
	this.text.setTransform(495,73.4,0.9,0.9);
else
	this.text.setTransform(600,73.4,0.9,0.9);
	this.instance = new lib.telefono();
        if (isbq)
	this.instance.setTransform(459,82,0.338,0.338,0,0,0,44,0.5);
else
	this.instance.setTransform(553,85.4,0.338,0.338,0,0,0,44,0.5);


	

	this.btn1 = new lib.btn5();
	this.btn1.setTransform(130.2,341.7);
	new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.btn5(), 3);

	this.btn1_1 = new lib.btn4();
	this.btn1_1.setTransform(130.2,251.7);
	new cjs.ButtonHelper(this.btn1_1, 0, 1, 2, false, new lib.btn4(), 3);


	this.btn1_3 = new lib.btn6();
	this.btn1_3.setTransform(130.2,431.7);
	new cjs.ButtonHelper(this.btn1_3, 0, 1, 2, false, new lib.btn6(), 3);

        this.btn1_1.on("click", function (evt) {
            putStage(new lib.frame4b(1));
        });
        this.btn1.on("click", function (evt) {
            putStage(new lib.frame4b(2));
        });
        this.btn1_3.on("click", function (evt) {
            putStage(new lib.frame4b(3));
        });


	this.text_1 = new cjs.Text(txt['tit2'], "bold 23px Verdana");
	this.text_1.lineHeight = 25;
	this.text_1.setTransform(82.4,69.9+incremento);

	this.instance_1 = new lib.imagen3();
	this.instance_1.setTransform(712,329,1,1,0,0,0,151.5,198);
      
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.instance_1,this.text_1,this.btn1_3,this.btn1_2,this.btn1_1,this.btn1,this.instance,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame4b = function (resp) {
        this.initialize();
        clearTexts();

  // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
     // Capa 1
	this.text = new cjs.Text("112", "bold 23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 23;
    if (isbq)
	this.text.setTransform(495,73.4,0.9,0.9);
else
	this.text.setTransform(600,73.4,0.9,0.9);
	this.instance0 = new lib.telefono();
        if (isbq)
	this.instance0.setTransform(459,82,0.338,0.338,0,0,0,44,0.5);
else
	this.instance0.setTransform(553,85.4,0.338,0.338,0,0,0,44,0.5);

        if (resp==2)
	this.btn1 = new lib.btn5("single",2);
        else
	this.btn1 = new lib.btn5("single",0);

	this.btn1.setTransform(130.2,341.7);

        if (resp==1)
	this.btn1_1 = new lib.btn4("single",2);
        else
	this.btn1_1 = new lib.btn4("single",0);
            
	this.btn1_1.setTransform(130.2,251.7);


	        if (resp==3)
	this.btn1_3 = new lib.btn6("single",2);
        else
	this.btn1_3 = new lib.btn6("single",0);

	this.btn1_3.setTransform(130.2,431.7);

	this.text_1 = new cjs.Text(txt['tit2'], "bold 23px Verdana");
	this.text_1.lineHeight = 25;
	this.text_1.setTransform(82.4,69.9+incremento);

        if (resp==1 || resp==2){
            this.instance_1 = new lib.Path();
	this.instance_1.setTransform(1076.2,490.6,0.741,0.741,0,0,0,873.6,284.5);
	this.instance_1.shadow = new cjs.Shadow("rgba(0,0,0,0.706)",7,7,15);

	this.text_2 = new cjs.Text(txt['poprta_1'], "20px Verdana");
	this.text_2.lineHeight = 26;
	this.text_2.lineWidth = 234;
	this.text_2.setTransform(575.5,342.8);

	this.cerrar2 = new lib.btn_cerrar();
	this.cerrar2.setTransform(832.8,325.2,0.775,0.733);
	new cjs.ButtonHelper(this.cerrar2, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.5,1,1).p("EAgUgKRMhAnAAAQhkAAAABkIAARbQAABkBkAAMBAnAAAQBkAAAAhkIAAxbQAAhkhkAAg");
	this.shape.setTransform(654,360);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EggTAKRQhkAAAAhkIAAxaQAAhjBkAAMBAnAAAQBkAAAABjIAARaQAABkhkAAg");
	this.shape_1.setTransform(654,360);
        }
        else{
          
  var html = createDiv(txt['poprta_2'], "Verdana", "20px", '450px', '40px', "20px", "185px", "left");
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(378, 220-608);
	this.instance = new lib.Path_1();
	this.instance.setTransform(865.3,483,0.484,0.484,0,0,0,98,103.8);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.706)",7,7,15);

	this.cerrar2 = new lib.btn_cerrar();
	this.cerrar2.setTransform(879.3,225.2,0.775,0.733);
	new cjs.ButtonHelper(this.cerrar2, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.5,1,1).p("EApogZwMhTPAAAQhkAAAABkMAAAAwZQAABkBkAAMBTPAAAQBkAAAAhkMAAAgwZQAAhkhkAAg");
	this.shape.setTransform(633.9,365);
        }
	
  this.cerrar2.on("click", function (evt) {
            putStage(new lib.frame4());
        });

        this.addChild(this.logo, this.instance0,this.titulo, this.home, this.anterior,this.instance_1,this.text_1,this.btn1_3,this.btn1_2, this.text_4,this.btn1_1,this.btn1,this.instance,this.text,this.shape_1,this.shape,this.cerrar2,this.text_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   
   (lib._01_OPT = function() {
	this.initialize(img._01_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,533,400);


(lib._112_OPT = function() {
	this.initialize(img._112_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,400);


(lib.botiquin2_OPT = function() {
	this.initialize(img.botiquin2_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,450);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.vendas = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BCB8B5").s().p("ABmDjQgYgXgIgDQgVgggkgjIg+g8Qgfg4gVhZQgKgmgYiBIAXgFQAvBVAFAyQAPANAKAkQAJAkAPANQgHAKAHAJIALATQAAAFAAAHIAAAIQAAAEANASQAKANgCALQAUAPAOAeIAYA1QAOAJAQAPIAbAcIgCAAQgOAAgSgRg");
	this.shape.setTransform(-89.7,5.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BCB8B5").s().p("AABNZIgUgKQgNgGgOACQhfg3g2gjQhQgyg9gvQgPgWgbg6QgZg1gTgZQgCgQgNgZQgNgXgBgTIgWgjQgEgfgihfQgehTABg6QACgGgCgGQgDgHABgEQAFgJAAgQIAAgbQABgFAFgJQAFgJABgFQADgOgCghQgBghADgQQAThxARhBQAahgAjg7QgGgXALgdIASguQARACAaAHQAGgJASgsQAOghAOgPQAVgDAggVQAfgUAZgCQAbgcApgLQAlgKA1ABQAHgCADAFQAFAFACAAQAvgCA7AUQAhALBCAaIAmAYQAWAOAUAFQAAAFAGAEQAGADgDAIQAYAEASAfQATAhARAHQALAyAjBBQABAlAJArIASBNQgCAVABAIQACAMAIALQABAEgEAEQgEAEABAFQASBvAABnQAABngSBtQAAAGgGAEQgHAFgBADQABBFgmBEQgVAogwBIQgEABgGAEQgGADgEABQgYAeg6AyQg6AzgYAeQgqAQgwABQgmABg2gKQgRgNgxgPQh8hzhKh/IgahVQgRg3gJggIAAgXQgVgcgDhAQAAhIgFgfQAFgWAKhkQAIhOASgkQgIgoATgrIAjhDQAlhLAogoIAPgJQAJgGACgIQASgEArgbQAkgWAdACQAZgMAoAAQA+gBAMgCQAjAFAgAXQATANAjAcQASAeAnA4QAgA0AIA0QABAFgBAGIgDAJQADAKAJATQgFATACAqQACArgFATQAHATgEAlQgEAuABALQgIAMgEAaQgDAbgIAKQAHALgCASQgDASgIAKQAGANgEAOQgFARADANQgTBEgdAeQgMBQg5AjQABAKgFAIQgHAKgBAEQgUAHgZARIgpAcQgwAgg1gKQg8gggjgxQgjgxgRhKQAAgDgDgDIgFgFQgXhegIhLQgKhgAJhZQAEgDADgKQAEgKADgDQAIg6AjhBQAphFARgmQADAAANgKQAJgGAJAFQAFABAAgHQABgIADgBQANABAagEQAYgDAJABQBmAyAwCFIAFBlQADA1AJAoQgWCWhxAzQgpAFgogKQgugMgXgdQgchhALhaQANhwBMgSQAZAJAQATQASAVgCAaIgOgCQgOgDgJACQgMAEgQAZQgOAXgKgDQgBAIADgBQAGgCABADQgMAEACAQQABAOAJAKQgFABgDAGIgEAKQABAEAHALQAGAIgFAJQABAFADgDQAFgDACABQgDAIADAEQAFAHABAEQAxAmAlgpQAdgeAPg+QgBgugRg0QgSg3gZgdQgagbgzAHQgOALgjANQgeAPgCAbIgOAAQgUBTADBgQADBeAWBMQAQAEAYASQAfAVAKAGIBZgDQAtgFAegVQBKg6AjiBQgBgugGhLQgFhKgCgvQgGgggYgmQgdgvgHgSQgKgFg8gyQgngjgyABQgLAHgVADQgZADgMAEQgWAPgaAkQggAsgLAMQgCAFgBAFIAAAPQgbAogUA8IgfBuQADAMgBAMQgBANgHAEQAJB5AiDGQACAHAKgBQAJAfAPAmIAcBCQAOAMAnAmQAhAgAXAPQAHACAdgDQAUgBAEAIIANgCQAIgCAIABQAQgIAtgdQAngZAbgKQAjgYAhg1QAig/ATgdIAAgRQAFgEAGgKQAHgLAEgEQAUhHAQh2QAQiDAJg8QgLgeAChEQABhNgHgjQgUgsgXg+QgUgbgsgtQgugvgTgYIgQgFQgIgCgHAEQgDgIgOgEQgRgFgEgDQgGABgggBQgYgBgKAGQgFgGgPAAIgaABQhBANgeALQg1ASgZAdQgCAAgFADQgFABgFgBQgRAageAcIg1AvQgEANgOAeQgMAagCAUQgUAYgJArQgNA3gHAQQACAGAHgBQgKALAAATQgBAMACAbIgEANQgDAIgEACQAMAUgSAUQACAjgHBRQgFBJAEAqQArBwAMBiIAOAXQAIAQgCAJQAMALAKAVQAJAVABAQQAYAQANAeQAVAUAaAhIAqA4QAnAUAMAmQAiAPBCANIByAVIATgHQALgFAEgGQArAGAnguQAvg3AagIQAcgVANgcQAEAAAHgDQAGgDAGAAQAWgQATgfQAKgPAUgsQAbgNAQgvQAXhAAGgLQABgFgBgGIgDgJQAagbgGgqQAQg4AChcQACh7ADgfQgRglAJhUQgXgvADg7QgMhSgZhJQgQgxgnhZQgpgZgigxIgagPQgPgIgFgMIiBgxQhMgcg8gMQgWAFgJAEIg1gCQgZAAgXAHQgDABgOAJQgKAHgHgFQgIAHggAQQgbANgLAQQgYADgeAQQgiAUgPAEQgKATgfAPIgLATQgHAKgHAGQgEAYgYA7QgXA2gBAgQgjBEgWBkQgQBHgNBsQgEAPgIAIQAHAHgCATQgCASAGAGQgRAhAIBEQAJBNgGAaIgXAEIgLg7QgOglgDg0QgDgxAIguQgIhMARhYQAAguANgxIAYhTQAIgNAbhGQATg0AYgXQAIgfAQgkIAeg+QAFAAAEgDQAFgDAEAAQAXghA8gsQBAgvAWgcQAFgBAGAEQAFADAEgDQADgBAIgGQAGgEAJACQAuglBPgMQBHgMBTAKQATAEAgALQAhAMARAEQAMAMBKAlQA4AcAKAjQAgATAkArQAyA+AIAIQAIAbAcAwQAbAtAGAgQAcAqAQBVQAWBxAJAZQAAAEgCAFQgCAGABAFQAMAqAFAoQAIAzgFAZQAHARAIAMIAAAlQABAUAHAMQgEAUgBAzQAAAxgGAYQAFA+gaBNQgPArghBVQgQATgcAwQgbAtgSAUQABAGgCAGIgCALQgWAQgXAiIgmA4QgYAKgWAPIgpAbIiIASQgsAFgqAAQghAAgggDgAlbJZIAEACQACACADgBQAAgGgGgDQAAADgDADg");
	this.shape_1.setTransform(-43.2,-41.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAAADIgDgCQADgBAAgDQAEACAAAFIgBAAIgDgBg");
	this.shape_2.setTransform(-77.6,18.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAAAAQABgHAAAHIgBAEIAAgEg");
	this.shape_3.setTransform(-69.3,34.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAAAIQgXgLgKgOQAmAQAdATIgGAAQgLAAgRgKg");
	this.shape_4.setTransform(-61.7,39.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#BCB8B5").s().p("AgLAdQgJgDgDgGQACgWAOgQQALgRAUACQgBAHgFAKQgEAJAEAHIgJAPQgEAKgCAJIgOgFg");
	this.shape_5.setTransform(-46,-38.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgCACIAAgDIAFAAIAAADg");
	this.shape_6.setTransform(164,35.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAAAAQABgHAAAHIgBAEIAAgEg");
	this.shape_7.setTransform(197.7,116.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF0000").s().p("ACwMHQACgJAQgPQAMgLgEgQQALAAALgLQALgLAKgBQABgQAHgSIAMgdQgFgZAJgeIATgxIAAgYQAAgPgDgGQAJgPALglQALhUABhzQgBh/ABg+QgIgXgCggQgCgogDgXQgDgLgYhBQgRgugCgfQgUgPAAgZQglg8gUgdQgigzgggdQgOgmghgiIg+g5QgCgHgFgIQgHgJgCgFQgVgJgpghQglgegegIQgagdgsgRQgWgIg8gQQgHAIgMAAQgGABgSgDQgFgPgEgGQgGgLgIgFIACgEQAcALArABIBGgCIAAgCQAsAWA/AnIBnBAQANAYA+A5QAzAvAQAsQAXAPAIAIQAEAPATAWQARAVADARQA2A8AlBrQAVA9AgCPQAGCjAABJQgBCHgRBfQADAFgCALQgCANABAIQgYAbABBHIgSA1QgMAkgEAZQAGABAGAEIAJAHIgEAHQgSADgtAXQgeAPgXAAIgKAAg");
	this.shape_8.setTransform(126.8,-75.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E2DDD7").s().p("AChLsIgJgHQgFgEgHgBQAEgZANgkIASg1QgBhHAYgbQgBgIACgNQABgLgCgFQARhfAAiHQABhJgHilQggiNgVg9Qgkhrg2g8QgDgRgSgVQgSgWgEgPQgIgIgWgPQgPgsgzgvQg+g5gQgYIhnhAQg+gngsgWIgDgBQBcgNBjAlQATAIA/AbQAyAXAhAKIAWAUQAOAMAOAFQAPATA0AsQAsAmASAfQAJAZAhBAQAcA2AKAmQANAOAOAlQAOAnALANQACAhANAsQARA1ADAUQgDAqAUAnQACBJAGCAQgLAvAABEIgEANQgCAIgFACQgBB7giA0QAHAGgGAPQgHAUADALQgHAAgEAMQgEALgIAAQACAMgOAWQgNATAFAKQgXAIAJAPQgRAEgXAOQgMAIgaAUQgEAAgEgDg");
	this.shape_9.setTransform(141.2,-77.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E2DDD7").s().p("AmWORQAQgLAGgGQAAgFAFgNQAFgNgBgNQAVgSAOg6QAPhAANgRQgFgMAEgPQAGgQABgJQgCgiAIhMQAHhIgFgwQAAgHgFgRQgEgOABgIIAEgUQACgMgGgIIADgNQABgIAEgCQgHgUgKgLIABgbQAAgUgGgFQAHgmgMg0QgOg9ABgcQgCg5gbhHQglhcgGgbQgug/gThaIgZglQgOgVgFgWQgLgTgegqQgagmgNgYQgWgVgdgkQgegpgQgTQg6hHhCgTIAIgCQAVgIAUACQAdgOAtgLIBOgTQA1ACBUgUQBkgWAjgDQBVgHCggZQClgbBQgHQAIAFAGALQAEAHAEAOQASADAHgBQAMAAAHgIQA8AQAWAIQArARAbAdQAeAIAkAeQApAhAWAJQACAFAHAJQAGAIACAHIA+A5QAiAjANAlQAhAdAiAzQAUAdAlA8QgBAaAVAPQACAeARAuQAYBBADALQADAYACAoQACAiAIAWQgCA/ACB8QgBBzgLBUQgLAlgKAPQAEAGAAAPIAAAYIgTAxQgJAeAEAZIgLAeQgHARgBARQgLAAgKALQgLALgMAAQAFAQgNALQgPAQgCAIIgBAEQhGAFg6AdQhuANiyBNQivBLhrALQiDAmhEATQh1AghZALIgDAAQAGgHAPgKg");
	this.shape_10.setTransform(76.4,-59.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E2DDD7").s().p("Ah6N8IAegIIAWgaQAMgQADgQQADABADgCQADgCADABQAKgYAVgbIAkgsQAQgrAfgzIA4hUQAGgXAYhKQATg7AIgnQAAgLABgXQABgSgCgMIAGgVQADgPADgHQgCikgsjgQADgKgBgLIgCgWQgMgcgLhDQgMhEgLgbQgggygUhEIgMgUQgIgLgIgGQgOgjgggtQgrg5gKgSQhEhDhDgrQhQgzhZgaQADgHASABQAYACAEgBQAzgQAbgHQAqgJArgDIAIALQAGAJAGADQAhgCAWAOQAWANAEAVQAZgKAMAnQAFABACgFQABgDAEAEQAPAOAXAfQAaAfAOANQALAnAgASQAEALALATQALATADAMQACAEAGAAQAGgCADAEIAeA2QAQAiAGAdQACAGAHAFIALAJQAQA1ApBgQApBeARA4IAAA3QAJAOABAhIABA4QACAKAHAWQAHAXABAMQACAPAAAgQgBAfACARIAIAoQAEAbAAAWQAAAFgDAIIgDANQAKAwgJBMQgMBrAAAPQABAFgEACIgGACQAFATgMAdQgNAeADAOQgNAbgeAtQgfAugMAZQgEAEgIABQgHAAgEAEIgCAGIgBAGQgDABgFgBQgFgBgCABQgCABAAAFQgBAGgDACQgDADgOAEQgLACgCAIIgBAGQgNADiMAzQhZAihOAEQAHgLASgHg");
	this.shape_11.setTransform(3.9,-44.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FF0000").s().p("AA5NcQAOgEADgDQADgCABgGQAAgFACgBQACgBAFABQAFABADgBQABgKACgCQAEgEAHAAQAIgBAEgEQAMgZAfguQAegtANgbQgDgOANgeQAMgdgFgTIAGgCQAEgCgBgFQAAgPAMhrQAJhMgKgwIADgNQADgIAAgFQAAgWgEgbIgIgoQgCgRABgfQAAgggCgPQgBgMgHgXQgHgWgCgMIgBg2QgBghgJgOIAAg3QgRg4gpheQgphggQg1IgLgJQgHgFgCgGQgGgdgQgiIgeg2QgDgEgGACQgGAAgCgEQgDgMgJgTQgLgTgEgLQgggSgLgnQgOgNgagfQgZgfgPgOQgEgEgBADQgCAFgFgBQgMgngZAKQgEgVgWgNQgWgOghACQgGgDgGgJIgIgLIAAgGQALAAAdgJQAXgHARAGIAAACIgIADQBCATA6BGQAQAUAfApQAcAkAWAUQALAYAbAnQAdAqALATQAFAVAOAWIAZAlQATBaAvA/QAGAbAkBcQAbBHACA7QgBAbAPA8QAMA0gIAlQAGAGAAAUIgBAaQAKAMAIAUQgEACgCAIIgDANQAGAHgBAMIgFAVQgBAIAEANQAFASABAHQAEAwgHBHQgIBNACAiQgBAIgGARQgEAOAFAMQgNASgPBAQgOA6gVASQABANgEAMQgGAOAAAEQgGAHgPAKQgPALgHAHIAEgBIABAGQhYATgnAKQACgIALgCg");
	this.shape_12.setTransform(16.9,-50.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF0000").s().p("ACiJ+QgBgFgEgGQgEgGgCgJQABgCAHgCQAHgCAAgFQAHhVgKgqQAMgUgCgzQgCg2AJgSQgHg7ABhQIAGiXIgGgOIgGgPQACgegLg7QgMg8ABgbQgSgRAHgUQgSgWgVhBQgUg9gTgTQAEgGgDgGQgEgJAAgFQgsgvgZgnIgSAAQgxhDhvgWIgOgRQgIgKgKgCIgBABIgBgDIArgPQAYgKASgMIAEAFQgIAEgBAKQAEAIAPAJQAQAJAFAGIAfAGQBUBDApAxQA9BIAWBXQABACAGAEQAFADgBAGQALA9AgA4QAEASAIBEQAHA2AKAbQAGAngGBDQgHBOABAdQABALAHAcQAFAYgBAPQgCAVgBBEQgBA5gFAjQAFAGADALIAEAUQgTAVALAxQAMAzgHALIAAADg");
	this.shape_13.setTransform(33.6,104.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#E2DDD7").s().p("ACPJpQgBgKgMgNQgMgNgBgNQgBgJADgIIAEgOQgCgRAAgaQABgagCgMQAGgvABh7QABh7AHg8QgDgHAAgZQAAgVgGgHIgCguQgBgbAAgRQACgGgEgDQgEgEAAgEQgDg4gSg+IghhqQgmg/gYgiQgjg0gkgjIgOAAQgBgGgHgFQgIgGgCgDIishOQADgKAOgDIAagEQAsgUA6gLIABgBQALACAIAKIANARQBtAWAyBDIARAAQAbAnAtAvQAAAFAEAJQACAGgDAGQASATAVA9QAVBBARAWQgGAUASARQgBAbALA8QAMA7gCAgIAFANIAGAOIgFCXQgCBQAHA7QgJASACA2QADAzgNAUQAKAqgHBVQAAAFgGACQgHACgBACQABAJAEAGQAEAGABAFIABADIgPAAQguAAg2gDg");
	this.shape_14.setTransform(24.1,106.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FF0000").s().p("AgYIbQACgKgEgIIgHgNQAOgqADheQADhyAGgoQgDgEgDgMQgCgMgDgEQADhwgFjDIgHlIIgJgUQgEgMgHgIIgBgUIABgSIAagGIAGAAIAAgFIAEgCQAOAjACAHQAFAQAAAaIgCAsQAAAXAHAmQAIAmAAAQQAAAVgJBEQgIA6AFAlQAOAugDBxQgCByAOAuQgLAkAEBRQADBRgHAXQADAMABAYQABAWADAJQALABAGgEIABACQgOAOgYAMQgbAPgKAHg");
	this.shape_15.setTransform(165.9,89.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E2DDD7").s().p("AlsLsQgLgxATgVIgEgUQgDgMgFgGQAFgiABg6QABhDACgWQABgPgFgXQgHgdgBgKQgBgeAHhNQAGhDgGgpQgKgbgHg2QgIhEgEgSQggg2gLg+QABgFgFgDQgGgEgBgCQgWhYg9hIQgpgxhWhDIgfgGQgFgFgQgKQgPgIgEgIQABgKAIgEQAHgEAPACIAaAEQALgDAOgNQAOgPAKgDQBkgOB7giQBHgTCLgqQAigDAygMQA6gOAWgDQBEglB9glQBHgrBGgGQAsgUAugLQA2gNAwABQAIgCAMgHQANgFANACIADAFQAWAnAkAcQgEAJAAAIIABAUQAEACAJAJQAIAHAHACQALAoAQAuIAfBXIgBASIABATQAHAIAEAMIAJAUIAHFJQAFDCgDBxQADADACANQADALADAEQgGApgDBxQgDBegOAqIAHAOQAEAIgCAKIgCACIgHAGIgdAPQgSAJgHALQgdAMhAAfQg8AdgiAOQgaAFhIAZQg7AUgvACQhzAoi2ANQjXAJhqAHQAHgMgMgyg");
	this.shape_16.setTransform(92,87.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#E2DDD7").s().p("AAcKkQgDgIgBgXQgBgYgDgLQAHgYgDhRQgEhRALgjQgOgvAChxQADhzgOgvQgFgkAIg4QAJhEAAgWQAAgPgIgnQgHgmAAgWIACgtQAAgZgFgRQgCgHgOgjQgRgmABgaQgOgegMgQIgThEQgNglgUgSQgBgNgJgUQgIgUgCgNIADgFQALgRAYAEQAUAEARAOQAEADgCAHQgDAHAEADQALAFAVAMIAIAPQAFAJABAIQAFABAIAIQAHAJAGACQADAQAaArQAYAngBAZQAPARAHAxQAHAzAOASQgBAbADA9QADAzgFAkIAJAjQgEAoAEBCQAEBNgBAeQgBAPgGApQgGAjABAVIAEAkQADAXgBATIgGBJQgEAvABAaIAFAzQADAcgCAYQgFAOAAAXQABAbgCAIIgXAOQgOAJgLADQgEADgHAJQgGAIgEADQgFAEgIAAIgEgBg");
	this.shape_17.setTransform(166.2,71.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AggZ3QgMgDgGgFQgJgNgBgQQgBgRAIgOQgDglADgoIAJhRQgIgwAHhSQAIhagEgpQgBgGAEgEQAEgEgCgGQgBgTAAhYQAAg8gNgrQAGgrgTg8QgZhRgCgOQgHgPgcgnQgCgWgUgeQgcgpgEgIQhJgvglgUQhBgkhCgGQgEgGgPgEQgOgFgFgFQgXgEhGAEQg6AEgggNQg1AEhQgQQhygXgPgCIgfgMQgSgHgFgNQglgHgtgfQg1gkgXgJQgCgFgHgHQgHgHgBgHQgHADgEgBIgJgFQgPgNhAhDQgwgyglgZQgCgSgSgFQgagtgghPQgBghgRhDQgShDgBglIgJgXQgFgOgGgGQgBgFACgGQACgFAAgEQgRg4gBhMQgBg2AHhdQABgGgCgFIgFgJQABgmAJg6IAOhmIAJgWQAGgNgBgOQAEgCAEgJQAFgJAEgDQAKgyArhPQArhOAKgzQAYgbAIgTQAwggAdgYQAoghAagiQAfgGASgPQADgHgHgGQgFgGAEgEQAZgOA+gSQBbgaAOgFIAMgMQAHgIAEgGQAyAEBMgLIBrgQQA4gTCcgXQCPgWBAgcQBHgCBNgLQBJgMBAgSQA/gGCngYQCNgUBVgHQAGABAFgFQAFgFAFAAQANADAZgCQAYgBAPADQAkgJAMgBQAagDAVAHQAIgDAVABQAeACAsAOQAwAPAYADQAFgBACAEQADAFACABQAfABAkAWQApAYAVAEIBLAvQAvAcAYAXQAtAsAKAIIAiA+QAUAlAUATIAkBgQAVA2AYAhQAOAqASBUQAUBbALAkIAIDFQABB4gUBSQgCASAEALQgMAfgWBhQgSBQgWAkQAEAJgBAKIgDAVQgMADgIALQgEAEgIAQQgPADgNALIgVAVQgGACgLAAQgKgBgEACQAFALARAIQAWALAFAEQgBAIAEAGQAFAJAAADQAhAdAcA3QAMAXAhBOQgEAcALAjQAMAlgBAPQAIAYADAEQAGAdgFAuQgFAzABASQABAOAKAdQAIAcABAPQABARgFAjQgFAiABAUIAGAaQAEAPABALQgQB+AFBfIABBMIgBBPIACCEQgDBKgcAsQgXABgeAXQggAZgYADQgDACgCAHQgCAIgCADQgNAAgLAKQgPAOgEACQhkAig3ArQgpAMhRAdQhOAcgsAMQgNgCgLACQgQACgJAAQgzAShcANIiZAVQhLgCgWAOQiYgNhzAVQh0gKgnATIgLgFQgHgCAAAKQgHgGgKgEgAjYFaIgqAPIAAADQg6ALgsAVIgaADQgOAEgDAKICsBNQACADAIAGQAHAFABAGIAOAAQAkAkAlAzQAYAjAmA+IAhBqQASA/ADA3QAAAEAEAEQAEAEgCAFQAAARABAcIACAvQAEAHAAAWQAAAZADAHQgGA7AAB7QgBB8gGAvQACAMgBAaQAAAZACARIgEAOQgDAJABAJQABAMAKANQAMAOABAKQA/ADA0gBIgBgDIA9AAIAAgCQBqgHDXgJQC5gNBzgoQAugCA8gUQBHgZAbgFQAigOA7gdQBBgfAcgMQAHgLASgJIAdgPIAIgGQAKgIAcgOQAYgMAPgPIgCgCQAFgDAGgIQAGgJAEgDQAMgDAOgJIAXgOQABgIAAgbQgBgXAGgOQABgYgCgcIgFgzQgCgaAFgvIAGhJQAAgTgCgXIgEgkQgCgVAGgjQAHgpAAgPQABgegEhNQgDhEADgoIgIgjQAFgkgDgzQgEg9ACgbQgPgSgHgzQgHgxgOgRQAAgZgXgnQgbgrgCgQQgGgCgIgJQgHgIgIgBQgBgIgFgJIgIgPQgUgKgMgFQgDgDACgHQACgHgEgDQgRgOgTgEQgYgEgMARIgFgCIg8AXIgDgFQgOgCgMAFQgNAHgHACQgwgBg2ALQgvALgrAUQhGAGhHArQh9AlhHAlQgVADg7AOQgyAMghADQiLAqhHATQh7AihjAOQgJADgPAPQgNANgMADIgZgEQgPgCgIAEIgDgFQgTAMgYAJgAmRFHIgWAZIgeAIQgSAHgHALQBOgEBbghQCMgzANgEIABgFQAngKBYgUIgBgFQBWgLB2ggQBDgSCDgnQBtgLCvhLQCyhLBugMQA6gdBHgGIAAgEQAbAEAkgSQAtgXASgEIAEgGQADACAFAAQAagUALgHQAXgPARgEQgJgPAYgIQgGgKANgTQAPgVgCgNQAHAAAFgLQAEgLAHgBQgDgLAHgTQAFgQgGgFQAhg1ABh7QAFgCADgHIADgOQABhEALguQgHiAgChKQgUgpADgqQgDgUgQg0QgOgsgBghQgLgOgOgmQgOglgNgOQgLgngbg2QghhAgJgYQgSgfgsgmQg1gtgPgSQgNgGgOgLIgYgVQghgKgzgWQg+gcgUgHQhjgmhcANIADACIAAABIhGACQgrAAgcgMIgCAEQhQAHimAbQigAahVAGQgkADhhAXQhVATg1gBIhNASQguALgdAOQgUgBgVAHIAAgDQgRgFgXAHQgdAIgLAAIAAAHQgrACgqAKQgbAGgzAQQgEABgYgBQgSgCgDAIQBZAZBQAzQBDArBEBEQAKASArA4QAiAuAOAjQAIAFAIAMIAMAUQAUBEAgAyQALAbAMBEQALBCAMAcIACAXQABALgDAJQAsDjACCkQgDAGgDAPIgGAWQACALgBATQgBAWAAALQgIAogTA7QgYBJgGAVIg4BVQgfAygQArIgmAtQgVAagKAYQgDAAgDABQgDACgDAAQgDAQgMAQgAs1FaIAWAJQBIAIBOgKICJgSIAogbQAXgOAXgKIAng4QAXgiAVgRIACgKQACgHgBgGQATgUAagtQAcgwAQgTQAhhTAPgrQAbhMgGg/QAHgYAAgxQAAgyAFgUQgHgMgBgUIgBglQgIgMgGgRQAEgcgHgyQgGgogLgrQgCgFADgFQACgGgBgEQgIgZgWhxQgRhVgbgpQgHghgagtQgdgwgHgaQgIgIgzg/QgjgrghgSQgJgjg4gcQhKgmgNgLQgQgEgigMQgfgLgTgFQhVgJhHALQhQANguAlQgJgDgGAFQgIAGgDAAQgDAEgFgDQgGgEgGABQgWAbhAAvQg7AsgYAiQgEgBgEAEQgFADgEgBIgeA+QgRAkgIAgQgXAWgUA0QgbBHgHANIgZBTQgMAxgBAuQgRBYAJBLQgIAwACAxQADA1AOAlIAMA7QAYCBAJAmQAWBbAfA2IBAA8QAjAjAVAgQAIADAYAXQATASAPgBIgagcQgQgPgPgJIgXg1QgOgegUgPQACgLgKgNQgOgSgBgEIAAgIQABgHgBgEIgMgSQgHgKAHgLQgOgNgKgkQgJgkgQgNQgFgyguhVQAGgZgKhOQgIhEARggQgGgHACgTQACgTgGgHQAHgJAEgOQANhsAQhHQAXhlAihEQACggAWg2QAZg7ADgYQAIgFAHgLIALgSQAegQAKgTQAQgEAigTQAdgRAZgDQAKgPAcgOQAggPAHgIQAIAFAKgGQAOgKADAAQAXgHAYAAIA1ABQAJgEAXgFQA9ANBNAcICBAxQAEALAQAJIAaAOQAhAyApAZQAnBZAQAxQAZBJAMBSQgCA6AWAwQgJBUASAkQgEAggCB9QgCBcgPA4QAFAqgZAbIACAJQACAFgBAGQgHAKgWBAQgRAvgaAOQgVApgJAQQgTAfgXAQQgFgBgHADQgHAEgEAAQgNAcgbAVQgbAHguA3QgoAvgqgGQgFAGgLAEIgTAHIhzgUQhCgNgigQQgNglgngUIgqg5QgZgggWgUQgNgegYgQQgBgPgJgUQgJgVgNgLQACgKgHgPIgPgYQgLhigrhvQgFgqAGhKQAGhSgBgjQARgVgMgTQAFgDADgHIAEgNQgCgcAAgLQABgUAJgKQgGAAgCgGQAHgPAMg3QAKgrATgZQADgUAMgaQAOgdADgOIA2gvQAdgcASgZQAFABAEgCQAFgCADAAQAZgeA0gSQAegKBBgOIAaAAQAQAAAEAGQANgGAYAAQAgABAGgBQADAEARAEQAOAEADAIQAHgEAJADIAQAEQATAZAuAvQAsAtAUAbQAXA+AUAsQAGAigBBNQgBBEAKAeQgIA9gQCFQgQB1gUBHQgEAEgHALQgHAKgFAEIAAARQgTAegiA/QggA1gkAYQgbAKgnAWQgsAdgTAJQgHgBgIABIgOACQgEgIgUACQgdACgHgBQgXgQghggQgmgkgPgMIgbhCQgQgmgJgfQgKABgBgHQgjjFgIh5QAGgHACgNQABgMgDgMIAfhuQATg7AbgoIABgPQAAgGACgFQAMgLAfgsQAagkAXgPQAMgEAZgEQAUgDAMgGQAygBApAiQA7AzALAFQAGASAeAuQAYAnAGAgQABAuAGBLQAFBNACAuQgjCBhKA5QgeAVgwAFIhZADQgKgFgfgWQgYgRgPgFQgXhMgCheQgDhiAThSIAPAAQACgcAdgOQAkgNANgLQAzgHAbAbQAbAcASA3QARA0ABAxQgPA9geAfQgnAogwgmQgBgEgFgGQgDgEADgJQgCgBgFAEQgEACgBgFQAFgIgFgIQgIgMAAgDIAEgKQACgHAFAAQgJgKgBgOQgBgQALgGQgBgEgFACQgEABACgIQAKADAOgWQAQgaALgEQAKgBANACIAPACQACgZgSgVQgQgTgagJQhMASgNBxQgKBbAcBgQAXAdAuAMQAoAKArgFQBwgzAXiWQgKgpgDg2IgFhkQgwiFhogzQgIAAgZADQgZADgOAAQgDAAAAAIQAAAHgFgBQgJgEgJAGQgOAJgDABQgRAmgpBFQgiBAgIA7QgEACgDALQgDAKgEACQgKBbALBhQAIBKAWBeIAFAFQADADABAEQARBJAiAxQAkAyA7AeQA1AKAzgeIApgdQAZgRAUgHQAAgDAHgLQAFgIgBgKQA5giAMhQQAdgeAUhEQgEgOAFgQQAEgPgFgMQAIgKACgSQACgSgGgMQAHgJAEgbQADgbAJgLQgBgOAEgtQAEglgHgTQAFgUgCgqQgCgrAEgTQgIgSgDgLIACgJQACgFgBgGQgIgzggg0Qgng4gTgeQgjgdgSgNQghgXgjgEQgLABhBABQgnABgZALQgegCgjAWQgsAcgRAEQgCAIgKAFIgOAKQgoAogmBLIgjBCQgTAsAIAnQgRAkgIBOQgLBmgEAWQAEAfABBIQADBAAVAdIAAAXQAIAfARA3IAaBWQBKB9B9ByQAxAQARANQA2AJAnAAQAwgBAqgRQAYgeA6gyQA6gyAYgfQAEAAAGgEQAGgEAEAAQAwhHAWgnQAmhFgChFQABgCAIgFQAGgEAAgGQAShtAAhnQAAhqgShuQgCgGAEgDQAEgEAAgEQgJgMgBgLQgBgIACgVIgShOQgJgqgCgmQgihAgMgzQgQgGgUgiQgSgfgXgDQACgIgFgEQgHgEABgFQgVgEgWgOIglgZQhCgZgigLQg7gUgwACQgDgBgEgFQgEgEgGABQg2gBgkAKQgqAMgaAcQgaACgeAUQggAVgVADQgPAOgOAiQgRArgGAKQgbgHgQgCIgSAuQgLAcAGAYQgkA6gZBhQgRBAgUByQgCAQABAhQABAhgDAPQgBAFgFAKQgEAJgBAFIAAAbQAAAPgGAKQAAAEACAHQACAGgBAGQgBA6AdBTQAiBeAEAgIAXAiQABATAMAYQAOAZACAPQASAXAaA2QAbA5APAWQA8AvBRAzQA2AiBfA3IAFAAQALAAALAFgAvbE/QAXAOANgEQgdgUgogRQAKAPAXAMgAwnEIQACAIAAgIIgBgEIgBAEgAtGnqQgOARgCAXQADAGAKAEIAQAFQABgKAEgJIAJgQQgDgJADgJQAFgKABgGIgFAAQgQAAgMAOg");
	this.shape_18.setTransform(37,8.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FF0000").s().p("AAVBIQgQgtgJgmQgHgCgIgHQgJgJgEgCIgBgVQAAgHAEgJQgkgcgWgnIA8gXIAGACIgDAEQACANAIAUQAJAUABANQASASANAlIATBDQAMAQAOAeQgBAaARAmIgEACIgGAAIAAAFIgaAGIgfhXg");
	this.shape_19.setTransform(155.8,20.6);

	this.addChild(this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-109.7,-158,307.6,333.1);


(lib.tiritas = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2B17C").s().p("AHoIgQhZgLgxgYQhOgGiygZQitgYhcgHQgTgKgngDQgygDgOgDQgRgKgegOIgxgXQgNgGgZgYQgVgVgWgFQgBgIgGgJQgHgJgCgGQgIAEgJgGQgNgIgGgBQgJgVgGgJQgKgQgQABQACgRgJgMQgEgGgPgMIACgRQACgJAGABQgXgSgJg5QgKg/gOgSQALgcgBg2QgChAAFgfIA3hmQAgg7AagmIApghQAXgVALgVQBDgmCIgsQBOACA6gTQBJABEXgNQDYgKCQAPQgEALADAVIAJAlQgKC8ADDZQACCcAMDlQgFAkgBAvIABBRQgFAJgBAKIgFASQgBAKAMAQQALAOgEAGQhggIgygGg");
	this.shape.setTransform(-42.2,42.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DD781D").s().p("AAAIiQiDALijgMQhpgIizgXQh4ANhpgNQgKgDALgGQAPgHgCgIQgEgUgEhAQgEg3gKggQAHhPgGihQgBgWACguQABgrgBgWQgBgbgFgyIgJhOQgDgzAJhwQAIhtgFg5QAHgNAEgSIAHgfQAjgCA/AHQBEAGAfAAQAfAAA+gFQA7gDAvAFQBGAGCNAQQB7ALBOgFQAYgCAsACIBKACQBGABBTAGICVALQAVABA4gDQAxgCAcAEQAHABAPAHQAOAGAIABQATADA5gBQAxgCAcAHQAIAcABAxQABAuAJAZQgHBKgIB/IgIBhQgDA2AEAfIgEAvQAAAVAIAOQgFAkgLDCQgICMgbBTQAAAFAHATQAGAQgEARQk5gHnEgwg");
	this.shape_1.setTransform(107.9,47.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F2B17C").s().p("AhRI6QhegCijgJQivgJg9gCQAUgggCgvQgEg3ACghQAFgPAEgaIAGgkQgJgnALh2QALhtgRgoQAOi4AHhnQAJiZABh7QAAgEAEAAQEoAdFlBEQAHABAJAHQAJAIAHACQArABAvAXQA3AcAZAFQBJAwAmAwQAxA8AJBOQgBAFAIgBQAJAAgCAFQACAZAMArQALApABAVQAQAZAFArQAGArgIAnQAFAlgHA8QgKBQAAAYQgHAcgTAhIgdAuQgJAKgdATQgZARgLAPQgPgGgJAJQgJAMgGADQidA5kWAAIglAAg");
	this.shape_2.setTransform(248.4,53.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AWfKhQhZADg4gOQgLADgiAAQgeAAgMAHQhugPjAgHQjGgIhvgOQgHAAgKACQgMADgFAAIkygbQi2gPiAgGQgJAFgbgBQgbgBgJAFQgWgEhlgDQhMgDgfgQQgHgCgDAFQgDAGgDABQgogIhVgFQhsgGgYgCQibAGjfglQj4gvh6gQQgagEhkgGQhSgFglgJQhDAEhHgWQhKgXgngnQgaAFghgfQghgegQAEQABgMgSgPQgPgMALgLQgjgIgOgNQgUgSAPgeQgKgKgQAEIASgVQgGgGgKgTQgJgRgIgHQAHhTgagdIgIhMQgFguABghQAAgHAJgDQAJgDgBgIQABgMgFgLQgIgMgDgHQAIgKAFgVQAEgRAPgJQAHgtAggyQApg/AJgZQAfgRAfgcQAXgWAegiQALgFAtgXQAkgUAZgFQADAAAIABQAIACAEgBIAugQQAfgLAXgEQAWgEAyAAQAwgBAXgEQAFgBAKgGQAJgFAEgBQAEAAAHAFQAIAFACAAQALABAYgGQAagHAMAAQADAAAIADIALADQAOAAAagHQAXgFAUAJQAygKBsACQBxACA4gIQA6AHCUACQCCABBSAPQB/gFCXAKQBCAFDDATQALgDAbgEQBcAKCBAEIDuAEQA2AKBGABQBAACA0gFQBgAVCkAQQC5ASBNANQAJgBAFAFQAHAGAEAAQBLADB2AWQCGAZArAEIA3ASQAiALAUAIQAcgEAfAWQAjAZAWACQANAdAdgDQAKAIAXAhQASAaAVAIQgBAVANAQQAIAKATARIAYBDQAOApAAAiQATAcAKBGQALBPAPAhQgKAKADAQQABAKAFAUQgEAMgFAbQgEAVgGARQADAEACAOQACAMAFAEQgHAYgMBEQgKA0gPAkQgUAbgyAoQgyApgUAZQhAAEgwAiQg+gBhEAKQgsAHhJARQgsgJhfAEgAO+oIQgCB7gJCaQgGBngPC1QARAqgKBtQgMB2AJAnIgGAlQgEAagFAPQgCAgAFA4QABAvgUAgQA+ABCvAKQCiAJBeABQEzAECog8QAGgEAIgMQAJgJAQAGQAKgOAagRQAcgUAJgJIAeguQATgiAGgcQABgXAKhQQAHg8gGgmQAIgmgFgsQgFgrgRgbQAAgTgMgpQgMgqgBgaQACgFgJABQgJAAACgEQgKhOgwg9QgngwhIgvQgZgFg3gcQgvgYgsgBQgGgCgKgHQgIgHgIgCQlnhEkngcQgFAAABADgANEJMQAEgSgGgQQgHgSAAgFQAbhUAIiLQALjCAFgkQgIgPAAgUIAEguQgEggADg3IAIhgQAIiAAHhJQgJgZgBgvQgBgxgIgbQgcgHgxABQg5ABgTgCQgIgBgOgHQgPgGgHgCQgcgEgxADQg4ADgVgBIiVgLQhTgGhGgBIhKgDQgsgBgYABQhQAGh5gMQiNgPhGgHQgvgEg7ADQg+AEgfABQgfAAhEgHQg/gGgjABIgHAfQgEASgHANQAFA6gIBtQgJBwADAyIAJBOQAFAzABAaQABAXgBAsQgCAsABAWQAGCigHBOQAKAhAEA2QAEBAAEAUQACAIgPAIQgLAFAKAEQBpAMB4gNQCzAYBpAIQCjALCBgKQHGAvE5AIgA91D1QAGAJABAHQAWAFAWAVQAZAZAMAGIAxAXQAeANASALQANADAyADQAnACAUALQBbAGCwAZQCyAYBOAGQAxAYBZAMQAyAGBgAIQAEgHgLgOQgMgPABgLIAEgRQACgKAFgJIgBhSQAAguAFglQgLjkgDidQgDjZAKi8IgIglQgEgUAEgLQiPgQjYALQkaANhIgBQg7AShOgBQiHAshEAlQgLAWgWAUIgpAiQgbAmggA7Ig2BmQgFAeABBBQABA1gKAfQAOASAKA9QAJA5AXARQgHAAgBAJIgCAQQAOAMAFAHQAIAMgCARQAQgCAKAQQAGAJAJAWQAGABANAHQAKAGAIgDQABAFAHAKg");
	this.shape_3.setTransform(100.8,48.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F2B17C").s().p("Aj6JjIg2gDQgOgBgggPQgbgMgWADQgEgHgJgGQgKgHgDgEQgHAGgLgCQgOgDgGACQgQgSgJgGQgPgLgOAHQgEgRgMgIQgGgEgTgGQgDgLgBgGQgCgJAHgCQgcgIgdgyQgfg3gUgMQgBghgTgxQgYg9gGgdIAPhzQAJhAALguQATgdAIgRQAOgbADgXQAegkAugpQAcgZA5gvQBLgaAvgmQBEgYEDhvQDFhWCLgjQAAALALASIAVAfQA4C1BQDJQA7CWBaDNQAIAlAQArIAeBMQgCAKACAKIACASQADAKARAKQAPAKgCAHQhcAagxAMQhYAVg2gFQhLAWivAoQitAnhWAZQgWgCglALQgxAPgNACQgUgEghgDg");
	this.shape_4.setTransform(-95.1,39.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DD781D").s().p("AotL4QALgNgFgHQgKgRgag6QgXgygVgbQgUhIhAiZQgJgUgOgsQgOgqgJgVQgKgXgXgvQgagygJgUQgWgugfhqQgehpgZg0QACgPgCgSIgGgfQAggNA/gRQBBgRAdgMIBWglQA3gYAtgMQBDgTCKgiQB2ggBKgiQAXgKAogOIBHgYQA+gXBRgYICQgrQAUgGAzgWQAtgUAbgGQAIgCAQACQAQABAGgCQATgEA1gVQAugTAcgDQASAXASAtQASArARAVQARA/AnCCIAaBdQARA0AQAdIAMAuQAIATAMALQAIAlA6C2QAqCGAEBXQABAFAOAOQALANACASQkpBom4BzQh3A4ibAuQhmAeivAoQhqA3hoAaQgKAAAIgJg");
	this.shape_5.setTransform(38.3,2.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F2B17C").s().p("AlNIOQgXgygKggQgBgQgFgZIgHgkQgWgigfhyQgdhqgeghQg1izgdheQgtiUgqhzQgCgDAEgCQElhOFig+QAIgBAIAEQAMADAGAAQAqgOA0AFQA9AHAagEQBVATA0AfQBDAoAkBFQAAAFAIgDQAIgEAAAFQAKAYAaAjQAaAjAHATQAZAUAUAmQAVAmAGAnQASAhAPA7QATBPAIAUQADAdgGAlQgDATgIAjQgGAMgTAcQgSAZgFARQgRABgFALQgDAOgFAGQiHBzkhBoQhZAgiZAxQioA1g5AUQAHglgSgsg");
	this.shape_6.setTransform(171.2,-30);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("A5xPvQgWAOgqgSQgpgRgOAKQgDgLgXgIQgSgHAGgOQgiAFgSgHQgagJAEgiQgMgGgOAJQACgFAGgVQgHgDgQgOQgOgNgKgDQgXhQgjgVQgGgOgcg2QgVgqgLgeQgDgIAIgFQAHgGgDgHQgDgMgJgJIgRgOQAEgLgDgWQgCgRALgOQgKgsANg7QAQhJAAgaQAngwAghYQAJgIAigmQAbgeAWgOQACgCAJgBQAIgBADgCIAlggQAZgVAVgKQASgLAvgSQAugSAUgMQADgCAHgJQAHgIAEgCQADgCAJACQAJACADgBQAJgDAVgOQAWgPALgEQADgCAJABQAIAAADgBQAMgGAWgPQAVgNAVABQAsgaBlgkQBrgmAygcQA5gOCLgyQB7gtBRgOQB1gyCRgrQBCgUC8gyQAKgIAXgNQBagWB4grIDhhQQA2gJBBgXQA9gVAvgXQBhgOCfgrQCygwBOgPQAIgEAHADQAIADAFgBQBHgZB2gUQCIgYAogLIA6gDQAjgCAWABQAZgNAkAJQApALAWgGQAXAXAagNQAMAEAhAWQAaATAWAAQAHAUASAKQALAHAXAJIAuA2QAcAhANAgQAbAUAiBAQAmBGAaAZQgFANAIAPIAPAZQABANAFAbQAEAVAAASQAFADAHAMQAGALAFACQACAXANBFQAJA0gBAoQgKAgggA3QghA4gKAeQg7AbghAwQg5AVg8AgQgkAUhCArQgsAHhYAlQhRAjg6AGQgJAHggAMQgdAKgIALQhtAZi2A9Qi8A+hsAaQgIADgIAFIgPAIIkoBTQixAyh6AoQgHAIgZAIQgaAJgHAIQgWAEheAhQhHAYgjgEQgHgBgBAHQgBAHgCABQgqAIhQAZIh+AmQiPA9jeArQj5Ash4AbQgZAGhgAeQhOAYgnAFQg9AahKAFIgaABQg9AAgpgTgA58OnQAgAPAOABIA2AEQAhACAUAEQANgCAxgPQAlgLAWADQBYgaCtgnQCvgoBLgWQA2AFBYgUQAxgMBcgaQACgIgPgJQgRgLgDgKIgCgSQgCgKACgKIgehMQgQgrgIgkQhajQg7iWQhQjHg4i0IgVggQgLgSAAgLQiLAkjHBVQkDBvhEAZQgvAjhLAbQg5AugcAZQguApgeAkQgDAYgOAbQgIAQgTAeQgLAtgJBCIgPBzQAGAdAYA9QATAxABAhQAUAMAfA3QAdAzAcAHQgHACACAJQABAGADALQATAGAGAEQAMAJAEAQQAOgHAPALQAJAHAQARQAGgCAOADQALACAHgGQADAEAKAHQAJAGAEAHIAJAAQASAAAWAJgAGirtQgbAGgtATQg0AXgUAGIiPAqQhRAYg/AYIhGAXQgpAOgXALQhJAhh3AgQiJAjhEASQgtANg2AYIhWAlQgdALhCASQg+AQggANIAFAgQADASgCAPQAZA0AeBpQAfBqAVAuQAJAUAaAyQAYAuAKAYQAJAVAOAqQAOAsAJAUQBACZAUBHQAVAbAWAyQAaA7ALARQAFAHgLAMQgIAJAKAAQBogaBqg2QCvgpBmgeQCaguB4g4QG4hyEphoQgCgSgMgNQgNgPgCgEQgDhYgqiDQg6i5gIgkQgNgLgHgUIgNgtQgQgdgQg0IgahdQgoiCgQhAQgRgUgSgrQgSgtgSgXQgcADguASQg1AVgTAFQgGABgQgBIgMAAIgMABgAU9u8QliA9klBPQgEACABACQAqBzAuCUQAdBfA0C1QAfAhAcBpQAfBzAWAfIAIAkQAFAaABAQQAJAfAYAzQARArgHAlQA6gUCng0QCcgxBYggQEhhmCIh0QAEgFAEgPQAFgLARAAQAFgRARgZQAUgcAFgNQAJgjADgSQAGgmgEgcQgIgXgThOQgOg7gTghQgGgngUgnQgUgmgZgTQgIgUgZgiQgagkgKgXQAAgGgIAEQgJAEAAgFQgkhGhDgoQg0gfhVgTQgZAEg+gGQg0gGgpAOQgHABgLgEQgIgCgHAAIgDAAg");
	this.shape_7.setTransform(35.8,5.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F2B17C").s().p("AICIlQhagDgzgTQhPACizgIQivgHhbACQgVgJgnACQgyACgOgCQgSgJgfgLIgzgSQgNgEgcgWQgXgTgWgDQgCgIgHgIQgIgJgCgFQgIAEgKgFQgNgGgGAAQgLgVgHgIQgLgPgQADQAAgRgJgMQgFgFgQgLIAAgRQABgJAHAAQgZgPgPg4QgPg+gQgRQAHgfgGg1QgHg/ACgeIAshrQAag+AXgoIAmglQAUgXAJgWQAngbA3gbQAjgSBCgdQBOgGA4gYQBGgFEXgpQDWgeCQACQgDALAGAUIAMAkQAHC7AYDZQASCaAhDjQgBAmAEAuIAIBRQgDAJgBAKQgBAMgCAGQAAAKANAPQANANgEAHIhFAAIhNgBg");
	this.shape_8.setTransform(-152.5,-30.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#DD781D").s().p("ArZJTQgKgDALgGQAOgJgDgIQgGgVgKg+QgJg2gNgfQAAhNgWiiQgDgXgDgtQgCgtgDgWQgEgZgLgxQgMg3gDgWQgJgygChwQgBhtgLg5QAGgOACgSIADggQAjgEBAAAQBEAAAfgDIBdgNQA6gJAvAAQBGgBCOADQB7AABPgOQAogGBkgFQBGgFBTgDICWgDQAVAAA3gJQAxgHAcABQAIABAPAFQAPAFAHAAQATABA4gHQAxgFAdAEQALAbAGAwQAFAuALAYQAABWAEB0IACBgQABA3AIAgIABAwQABASAJAOQgBAlAIDBQAFCMgTBVQAAAFAJASQAIAQgCARQk8AXnFgEQiAAXijAEQhnACi3gHQhuAXhfAAIgTAAg");
	this.shape_9.setTransform(-7.1,-34.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F2B17C").s().p("AoGHfQgKg3gBghQAEgPABgaIADglQgNgmAAh3QAAhtgVgoQgCixgEhsQgGiZgKh8QgBgDAFAAQEmAAFsAhQAIABAJAGQALAHAGABQAsgDAwATQA6AXAZACQBNAoArAsQA1A4ASBNQgBAFAIgCQAJgBgBAFQADAaAQApQAQAnACAVQATAZAKAqQAJArgFAlQAKAlgCA9QgCBRACAXQgEAdgQAiQgHAQgSAhQgIALgaAWQgYATgJAPQgQgEgIAKQgIAMgFAFQihBMkwAZQheAHijAHQiuAHg+AEQARghgGgvg");
	this.shape_10.setTransform(136.3,-37.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("Au5KDQj8gYh6gEQgagBhkADQhSADgngFQhBAKhKgQQhMgPgqgjQgZAHgkgbQgjgcgRAHQAAgMgTgOQgPgLAIgMQgigEgPgLQgXgQANggQgKgJgQAFIAPgWQgGgGgMgSQgLgPgJgGQAAgogFgZQgIgfgRgQIgOhLQgKgtgCghQgBgIAJgDQAJgEgBgIQgBgMgGgLIgMgSQAGgIAEgWQACgRAOgKQACgtAbg2QAjhDAHgZQAzgjA1hNQAKgFArgcQAigXAagHQADgBAHABQAIABADgBIAtgVQAdgOAYgGQAUgGAzgFQAwgFAXgHQADgBAKgHQAJgGAEgBQADAAAIAEQAIAEADAAQAKgBAZgIQAYgJAMgBQAEAAAHACQAJACACAAQAOgCAagKQAWgGAVAHQAxgOBrgJQBxgIA4gOQA6ABCUgMQCBgLBSAHQCAgSCWgEQBFgBDCABQAMgFAagHQBbACCAgJIDugTQA3AFBFgFQBAgEAzgLQBiANCkAAQC6AABOAGQAJgCAGAEQAHAFAEAAQBMgFB3AMQCJAMAqAAIA5AMQAiAIAVAGQAcgGAgASQAlAWAXAAQAQAbAcgFQALAHAZAeQAVAZAVAFQACAVAPAPQAJAJATAPIAfBBQATAnADAiQAVAaAQBHQATBOASAfQgJALAEAQIAJAbQgCAMgDAcQgBAVgGARQAEAEADANQAEAMAEAEQgEAXgGBGQgEA1gMAmQgRAcguAtQguAtgSAbQhAAKgsAnQg9AFhCAQQgpALhLAYQgsgFheANQhYAMg5gJQgLAFghADQgfACgLAIQhwgEi/ALQjGALhvgDQgHABgLADIgQAEIkzACQi4ACiAAHQgIAGgZACQgbACgJAFQgYgChkAGQhLAFghgNQgGgCgDAGQgDAHgDAAQgpgDhUADIiEAEQhZANhwAAQhTAAhggHgAt8JQQAzABBggBQADgHgMgNQgOgOAAgKQACgHABgLQABgLAEgJIgIhRQgEguABglQghjkgSiaQgYjYgIi8IgMgkQgFgUADgLQiQgCjXAfQkZAohGAGQg3AYhPAGQhBAcgjASQg3AbgnAbQgJAXgVAWIglAmQgXAogaA+IgsBrQgCAcAHBBQAGA0gIAgQAQAQAQA+QAOA4AZAPQgHABAAAJIAAAQQAQALAEAGQAKALgBARQARgDAKAPQAIAJAKAUQAHAAANAHQAKAFAIgEQACAEAIAKQAHAIACAHQAVADAYATQAbAWANAFIA0ASQAfAKASAJQAOACAxgCQAogBAUAJQBcgDCxAIQCzAHBPgBQAzATBZADgAmDokQgvAAg6AJIhdAOQgfADhEAAQhAAAgjAEIgDAgQgBASgHANQALA5ABBtQADBwAIAzQADAWAMA2QALAyAEAZQADAWADAsQACAuADAWQAWCjABBMQANAgAIA2QAKA+AGAUQADAIgOAJQgLAHALACQBmADB5gZQC3AGBngCQCkgDB/gXQHFADE8gWQACgSgHgPQgKgTAAgEQAThVgFiMQgIjCABgkQgIgOgCgTIgBgwQgHgggCg2IgBhhQgEh0gBhVQgKgYgGgvQgGgwgLgbQgcgEgyAGQg4AGgTAAQgHAAgPgGQgPgFgIAAQgcgCgxAIQg3AIgVABIiWADQhTAChGAGQhkAEgqAHQhNANh7AAQh2gChEAAIgaAAgAOHpJQALB7AFCZQAEBsACCzQAWAmAABuQAAB2AMAnIgCAkQgCAbgEAPQACAhAJA2QAGAvgRAiQA+gFCugHQCkgGBdgIQEygZChhMQAGgEAHgNQAIgKAQAFQAKgPAXgUQAagWAIgLQATggAGgQQAQgjAEgdQgBgXABhRQACg8gJgkQAEgngJgqQgJgqgUgaQgCgUgPgoQgRgpgDgZQACgGgJACQgJABABgFQgShMg1g4QgrgshMgoQgagDg5gXQgxgTgsAEQgGgCgKgGQgKgGgHgBQlugiknAAQgFAAABAEg");
	this.shape_11.setTransform(-11.8,-34.5);

	this.addChild(this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-225.7,-99.6,539.6,216.2);


(lib.tijras = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjwGzQgLgEgIAAIgKgOQhpgzhGhoQgRgKgUgZQgagggGgGQgOgigEgXQgFggAIggQAFgMAQgXQAPgVAFgNQASgSAmggQAmghARgRIApgXQAagPAQgHQAegHApgYQAsgaAXgHQAZgQA3gcQA2gcAXgQQAlgJAlgYIAYgHQANgFAGgHIAEABQABAAABAAQAAABABAAQAAAAABAAQAAAAABAAIAXgMQANgGAOgBQAcgPANgFQAZgKAYgDQA7gYAbgHQA2gPAmANIAKgEQAGgCAFABQAKACAOAHIAYAKIAIAZQAEAKAHAKQgFAFgCAMIgDAVQABAEgFACIgHADQABATgVAUQgYAXgEAOQgEAAgEAEQgEAEgFgBQg2BCgTAVQgrAvgoAeQh8CQiFBsQgDALgOAOQgOAOgEAJQgVAIgPAMQgSAQgBASQgPAQgfAdQgaAagOAYQgIgDgHAIQgGAGgFgEQAAAAgBABQAAAAAAAAQgBABABAAQAAABAAAAQADAEgCADQgPADgJANQgHAKgEATQgKACgJAHQgHAAgMgFg");
	this.shape.setTransform(-38.4,66.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0060B6").s().p("AkwLEIgOAAQgJAAgDADQgsgPgxgcIhVgyQgFgHgEgKQgggNgqgiQgzgpgSgLIAAgKIgngcQgVgSgJgUQhghNgzh7QADgCAAgFIAAgJQgPg4Afg5QApg9AQgcIAOgHQAegiA9gyQBHg6AYgZQAhgfBJgwQBNgzAegaQAdgPBMgfQBDgbAjgUQAFABAGgBIAKgCQBcg8CEgtIASAAQALAAAEADQBWgaAegGQBIgOA2AMQAFABAEgDQAEgCAEAAQAaAGA/ABQA7ACAWAHQBCgJA7gaQA7gaAqgmQAJgmAmgTIAPgWQAEAAADADQABAOANAVQAKAQgFAUQADAFADAMQAEALAGADQAEAKAHAbQAGAYAFAMQAAAKgIAGQgKAGgEAEQACAFACgBIAGgBQgQAeggARQgPAcgoAyQgmAxgQAeQgrAfgOAcQgNAFgOAQQgSAUgHAEQgBAIgGAJQgxAtg5BEIhiB4QiRCShHBUQgEgBgCACQgEACgCAAQgEALgUAPQgSAOgDAOIgMAAQgDADgCAGIgFAKQgYAOgiAqQghAqgXAOQgDAJgIAMIgNATQgZARgjAoQgnAsgTAPQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBgBgBAAIgFgBQglAlg1A/QgHgFgIACIgQAFQgDgJgJgDgAlGJBQAIAEAHgBQAQgMAEgFQAIgLgEgMQAPgNAHgHQALgMAFgQQAkgdA8hFQA9hGAjgdQBUheB2hpQABgHAEgHQAYgRAQgdQAIgEAKgIIASgOIAFgJQAEgEABgEQALgKAsgvQAhgkAZgSQAAgDACgDQACgCgBgEQAqgaAcgzQAWgpARhDQgDgEAAgJIABgQQgGAAABgJIgYgQQgNgKgGgMQgJgEgXgDQgXgEgJgDQgXAEgugEQgQAOgmAAIgHADQgFACgFAAQggAPhTAeQhLAbgkAUQiDAyh7BMQhEAcg3AiQgWAEgcAQQgiASgOAEQgBAHgIAGQgKAIgCADIgMAAQgTAXguApQgsApgTAYQgEAggWARQACAJgCAGIgDAOQAHAVgFAkQgFAhALAYQAZATAiAtQAlAxAUARQgBAEACADQACADgBACQAaAbATAPQAbAUAcAMQgBAEADACQAEACgBAEQAOADANANIAXAWQAQABARALQAXAOAFACIAFAAQAFAAAGACg");
	this.shape_1.setTransform(-26.6,57.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AlVbEQgogEgPgFQgLgLgdgLQgggMgLgIQgQADgRgOQgUgRgNgBIgCgEIgBgFQgdgQgggdIg3gyQgDAAgFgEQgDgDgGACIgFgOQgSgIgggZQgdgYgXgHQgBgFgIgHQgIgGABgIQgUgOg8g4QgwgtgigQQgMgUADgLQgJAAgJgGQgJgGgEgJQgKADgLgEQgLgFgBgLQgogFgwgdQg5gigYgIQgFgPgZgNQgagOgFgMQgJgBgMgKQgKgJgMABQgTgXg/gzQg2gsgVglQgJgCgMgOQgMgOgKgDQgsg8gVgfQgjg3gOg1IABgXQAAgIgFgHQgBgBAAgBQABAAAAgBQAAAAAAgBQABAAABAAIAFgBQgEgSAOgbQASgdAFgOQABgFgDgEQgDgEAAgDQAVgSAYghQAbgmAOgSQAmgOAYgkQAOgHAUgQIAggZQATgXAoggQAvgmAPgQIAVgKQALgHAEgJQAggMA5grQA2goAngMQAGgIAVgGQAWgHAGgHQA4gSBqg1QBkgyA/gRQAHgEAVgFQATgFAIgFQAmgDAOgOQAMAEATgHIAfgLQAvgCBhACQBbACAtgCQBnANBTg2QA1gkBDhXQAAgCACgIQAAgEgEgDIAygvQAbgcANgdQAGAAAGgEQAGgFAEAAQABgCABgFQABgGABgCQAngcAOghQAFgBAEgFQAEgFADgBQAlhMBRhgQBsiDAVgeQAFABADgFQAEgFAFAAQAXgmAYgOQgBgFACgEQACgEAAgEQAFAAAEgEIAHgFQAGgTAYgXQAZgZAHgQIBBhEQAmgoAUgjQALgDALgRQALgRAKgDIAAgMIAKAAQAog4BHhIIB3h5QAYghBBg6QBCg8AZgiQAXgLAXgVIAoglQAtgMAqgfQAQAHAdgIQAhgKAWAEQAiAJAeATQADAEAEAKQAEAHAIABQgEAKAIATQAHAPALANQgEBJgiAmQgBALgIAPQgHAQgBAKQgKANgZArQgVAkgSAPQABAEgBAEIgCAHQgZAfg6BXQgzBMgjAmQgyBnhQBjQgPAjghAkQgtBYgqAyQggA+hSBxQhPBughBCQgLAGgIAOQgDAFgJAXQgSATg3BHQgtA5giAcQgFARgaAbQgYAYgCAZQgmAhgEApQgEADgIgCQgHgBgDACQgBABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAIgcAiQgQATgQAJQgZA1gwA4QgCAPgCAGQgCAHgGAIQgBAHAGAFQAGAFABAEQgDAGAAAZQANASADAaQABAQgCAjQAGAkABApQABAbgBA3QAAAEgEAEQgDADAAADQgCAagGAfIgMA1QACAWgHAoQgHAnADAUIgaBWQgPA0gJAlQgLARgNA1QgLAxgRARQgiBQgWAtQggBEghAxQABAEgCAEQgCAFAAADIgcAsQgPAagGAZQgVAWg7BGQgwA6ghAeQhoBfiGAFQgNgGglgEgAkNacQAqABAcgIQABgDAFgDQAFgDABgCQAZgEAbgVQAhgZAPgFQAWgiAbgOQANgRAWgVIAjgjIAPgaQAJgPALgHQADgQAQgYQAQgXADgRQAMgHAHgLQAIgNgDgMQAOgUAYgsQAYgsAOgUIAAgRQArg8AkhtQAmh/AVg+QABghABgMQABgCAEgCQADgBgBgFIAMhRQAHgvgCgfQARg7gIgwQAGgFABgJQgBgKABgHQgFgSgCglQgBglgIgYIgGgFQgEgCAAgFQAGgPgMgiQgMgiAGgVQgBgEgGgDQgGgEgBgDQAKgDgFgQQAXgTAHgGQAPgQAFgTQAWgTAcglIAtg8QgGgLgPgEIgigEQiDgkhLAOQgDAHgMAGQgMAIgCAIIgFgBQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAIgRAQQgLAKgKADIhHBYQgpAzgaApQgTAMgVAZQgMAOgWAeQgXAOgjAsQgiAqgbAOQAAAEgDAFQgDAGgBAEQgTAUg6BFQgvA4ggAeQAAAEgDADQgCAEAAADQgbAXgyA3QgwA1gdAYQgNATgjAiQgjAfgMAXQgjAbgQARQgaAbgOAcQgMAGgRATQgRATgNAGQgHAagqAdQgoAbgGAeIgUAQQgNAKgFAJIgsAYQgWAQAAAdQAHgBAHADQAIADAEAAQAJAXAjAbQAkAcAKATQARAIAZAdQAYAbATAHQAYAZA1AlQA4AmAWAVQAZAJAGASQAOAFA0AiQAoAaAfADQAOAOAhALQAnANAJAFIAJAAIA2ACgAvnS9IAQgFQAIgCAHAFQA1g/AlglIAFABQABABAAAAQABAAAAAAQABAAABAAQAAAAABAAQATgPAngsQAjgoAZgRIANgTQAIgMADgJQAZgOAhgqQAigqAYgOIAFgKQACgGADgDIAMAAQADgOASgOQAUgPAEgLQACAAAEgCQACgCAEABQBHhUCRiSIBih6QA5hEAxgtQAGgJABgIQAHgEASgUQAOgQANgFQAOgcApgfQAQgeAmgxQAogyAPgcQAggRAQgcIgGABQgCABgCgFQAEgEAKgGQAIgGAAgKQgFgMgGgYQgHgbgEgKQgGgDgEgLQgDgMgDgFQAFgUgKgQQgNgVgBgOQgDgDgEAAIgPAWQgmATgJAmQgqAmg5AaQg7AahCAJQgWgHg7gCQg/gBgagGQgEAAgEACQgEADgFgBQg2gMhIAOQgeAGhWAaQgEgDgLAAIgSAAQiGArhcA8IgKACQgGABgFgBQgjAUhDAbQhMAfgdAPQgeAahNAzQhJAwghAfQgYAZhHA6Qg9AygeAkIgOAHQgQAcgpA9QgfA5APA4IAAAJQAAAFgDACQAzB7BgBNQAJAUAVASIAnAcIAAAKQASALAzApQAqAiAgANQAEAKAFAHIBVAyQAxAcAsAPQADgDAJAAIAOAAQAJADADAJgAFigyQBCAGAnAPQAvAIAkgRQAGgKAagdQAVgXAGgVQAAgCgEgCQgEgBABgFQAFgIgGgRQgHgSgIgHQgBgPgMgUQgNgVAAgKQgOgCgFgUQgHgVgKgFIAFgJIgHgCQgEgBgBgCQAAgTgLgQQgOgRgGgKIADgVQACgPgDgJQAIgMAMgcQAMgXASgGQAIgQAbgiQAZgeAHgYQAUgLAXglQAYgmASgLQALgYAjgoQAigmAKgdQAagaA7hHQA0g/AiggQABgEADgFQADgGAAgEQA6gxA7hdQAGgBAGgGQAGgHAFgBQAFgNARgRQARgSAEgNQAdgbA1g/QAzg9AfgbQAPgZAxg2QArgvAQgkQAmgdAMgjIAIAAQAEABAAgDQgDgMANgLQATgNACgFQhGACg6AYQg9AagiAuQgnAbgOALQgcAYgOAZQgbAPgaAbQgRASgZAhQgQAJgXAZQgXAagOAJQgSAZguAtQgsAsgSAcQgDAAgDADQgCADgEgBQgDAMgMAOQgPARgDAHQgXAQgZAiIgqA5QgmAfgmA5QgxAuhFBUQhXBsgZAbQgDATgVAMQgBAGgEAIQgNAKgGACQglA0gyBLIhWB/QgoAagbA1QgEgCgCADQgCAEgEgBQAAAHgCAAQAFAqAXBJQAYBOAFAjQAIACAIgCIANgEQAZAFBYAJgAPQvvQgSAZg4A9QgwA1gWAlQgbAZgtBAQgsA9gdAaQgEAKgMAUQgMASgDANQgdAagcAsIgvBQQgXAMgGAcIAEARQACAKgEAGQAHALATApQAPAhAOAPQACAWAOAVIAYAjIAIAYQAGANANABQAbgpBChTQA+hPAeguQADgJgBgHIARgMQAWgtA+hTQA7hQAXgzQANgMARgbQATggAIgKQACgGAIgNQAIgLABgKQBMheAmhPQAtguAahCQAIAAAFgKQAGgLAHAAQALgbAfgrQAhgtAIgVQAOgKAJgOQAMgRABgNQASgMATglQATgnAPgMQgFgBAAgGQAIgBAHgMQAGgMAIgBQAEgWAYgpQAVglAAghQAEgCACgHQACgIACgCQAAgNgFgRQgGgVgBgIIgFgDQgDgCgEAAQgFAHgXAOQgTALgDAPQgEgBgEAEQgDADgFgBQgCAFgFAFIgKAHQg9BPhIBLQgQAcgwAxQgtAugRAiQgyAtg+BMQhEBYgkAqIAAAOIgCAKIgHgEIgHgBIgDAAgAPRwJQgBABAAAAQgBAAAAABQgBAAAAAAQAAAAAAABQgCAGAGgDQAHgDgEgDIgCgBIgCABg");
	this.shape_2.setTransform(44,8.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AjXHqQgHgDgIABQgGgCgXgOQgQgLgQgBIgXgWQgNgNgPgDQABgEgDgCQgDgCABgEQgcgMgbgUQgUgPgZgbQAAgCgCgDQgCgDABgEQgTgRglgxQgigtgagTQgKgYAFghQAEgkgGgVIADgOQABgGgBgJQAVgRAFggQASgWAtgpQAugrATgXIAMAAQACgDAJgIQAJgGABgHQAOgEAigSQAcgQAVgEQA3giBFgcQB7hMCBgyQAmgUBLgbQBTgeAggPQAFAAAFgCIAGgDQAnAAAQgOQAtAEAYgEQAJADAXAEQAXADAJAEQAFAMANAKIAYAQQgBAJAHAAIgBAQQAAAJADAEQgRBDgXApQgcAzgpAaQABAEgCACQgDADABADQgZASghAkQgsAvgLAKQgBAEgEAGIgFAJIgSAOQgLAIgHAEQgQAdgYARQgEAFgBAHQh2BphWBeQgkAdg6BGQg9BFgjAdQgGAQgKAMQgHAHgQANQAFAMgIALQgFAFgPAMIgDAAQgGAAgHgDgABelUIgYAHQglAYgjAJQgaAQg1AcQg4AcgYAQQgXAHgsAaQgpAYgeAHQgRAHgZAPIgpAXQgRARgnAhQglAggTASQgEANgPAVQgQAXgFAMQgJAgAGAgQAEAXANAiQAHAGAaAgQAUAZARAKQBGBoBpAzIAJAOQAJAAALAEQALAFAIAAQAJgHAKgCQAEgTAGgKQAKgNAPgDQACgDgDgEQgBAAAAgBQAAAAAAgBQAAAAABAAQAAAAABgBQAFAEAGgGQAHgIAIADQAOgYAagaQAfgdAOgQQACgSARgQQAQgMAWgIQAFgJAMgOQAOgOADgLQCFhsB8iQQAogeAqgvQAUgVA2hCQAEABAEgEQAFgEAEAAQADgOAYgXQAWgUgCgTIAHgDQAGgCgBgEIADgVQACgMAFgFQgIgKgDgKIgIgZIgYgKQgPgHgJgCQgGgBgFACIgKAEQgmgNg2APQgcAHg6AYQgZADgYAKQgNAFgdAPQgNABgOAGIgWAMQgBAAgBAAQAAAAgBAAQAAAAgBAAQAAgBgBAAIgEgBQgHAHgMAFg");
	this.shape_3.setTransform(-37.8,66.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0060B6").s().p("AgiNVQg2gCgJABQgJgGgngNQgigKgNgOQgfgDgogaQg1gigOgGQgFgRgZgJQgXgVg4gnQg0glgYgYQgTgIgYgbQgagcgRgIQgJgTgkgdQgjgagKgYQgEAAgHgDQgIgDgHACQABgdAWgRIAsgXQAFgKANgJIAUgRQAGgdAogcQAqgcAHgaQAMgGASgTQARgTAMgGQANgdAbgbQAQgQAigcQANgWAiggQAkgfANgUQAdgYAvg0QAzg3AbgXQAAgDACgEQADgEgBgDQAhgfAvg4QA4hFATgUQABgEACgFQAEgFAAgFQAbgOAhgqQAkgsAXgOQAWgeAMgOQAUgZAWgMQAagoAog0IBHhYQALgDALgJIARgQQAAgBABAAQAAgBABAAQAAAAABAAQAAAAABAAIAFACQACgJALgHQANgIADgHQBKgPCEAmIAhAFQAQAEAGAKIgtA9QgcAkgXAUQgEATgPAPQgHAHgXASQAEARgJACQABAEAGADQAGADABAEQgHAWAMAiQAMAhgFAQQAAAEADADIAGAFQAJAYABAkQACAmAFASQgBAGABALQgBAJgGAFQAHAwgRA7QADAegHAwIgMBRQABAEgEACQgDACgBABQgCAMgBAhQgVA8glCAQglBtgqA8IAAAQQgOAVgYAsQgZArgNAVQADAMgIANQgIAKgLAHQgDARgQAYQgQAXgDARQgLAGgJAPIgPAaIglAkQgXAVgMARQgbAOgXAhQgOAGghAYQgcAVgZAEQAAACgGAEQgEADgBADQgYAGgfAAIgNAAgAi1MDQABAGAEgGIgEgDQgBAAAAAAQAAAAAAAAQAAABAAAAQAAABAAABgAm1H0QAhAJAIAZQAEABAHAEQAFAEAFAAQAiAsBHASQAvApBFAGQALAKAYAGQAZAFALgGQAZgPAMgFQAYgJAUACIA1gjQAegVATgUQATgjAdgTQAfg5BHhOQAHgOAphCQAegwAKgpIADgCQAAAAABAAQAAAAABAAQAAgBABAAQAAABABAAIA8ifQAlhgAag7QAAgJAGgUQAEgRgBgNQAGgHAFgUQAFgUAGgGQAAgDgDgDQgDgDABgFQAMgPAFgXQAGgZgEgWQAPgugPg6QgOg1gdgcQgMgCgLgKIgWgPQgIAFgIgBQgFgBgMgFIgFAEQgCACgFgBQgWgHgaAOQghARgNACQAAALgDADQgKABgLAOQgJAOgMAAIgYAfQgOARgPAJIAAALQgWAWgoAvQgmAoghAUQgJAageAiIgvA4QgJAGgHABQgWAqgmAdQgLAagVAeIglAxQgQAkgdAiQgUAZglAhQgcAug+BGQhDBNgZAjQgEABgFAFQgGAFgHgBQAAAFgEADIgIAGIAGAKQABAEgHAFQAMAFAFANIAIAZIAKABQAEABAEgCIAOAXg");
	this.shape_4.setTransform(20.5,92.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgBAAQgCgFAFAFQAAAAgBABQAAAAAAABQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAQAAgBAAAAg");
	this.shape_5.setTransform(2.5,169.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AiEJYQgYgFgLgKQhFgGgwgqQhHgSghgrQgFgBgGgEQgGgEgEgBQgIgZghgIIgOgYQgEACgFgBIgKgBIgIgYQgEgOgMgFQAHgEgBgEIgGgLIAIgFQAEgEAAgFQAHABAFgEQAGgGADAAQAZgkBEhNQA+hGAcgtQAlgiAUgYQAdgiAQgiIAlgzQAVgeALgaQAmgdAWgqQAHgBAJgHIAvg4QAdgiAKgaQAhgTAmgpQAogvAWgVIAAgMQAOgJAPgRIAXgfQANABAJgOQALgOAKgBQADgEgBgLQAOgBAggSQAagOAXAHQAFABACgCIAFgDQAMAFAFAAQAIABAIgEIAVAPQAMAJAMACQAdAcAOA2QAPA6gPAtQAEAWgGAZQgGAYgLAPQgBAEADADQADADAAAEQgHAGgEAUQgFAUgGAGQABANgFASQgFAUAAAIQgaA7glBiIg8CdQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAIgEACQgJAogeAwQgqBCgGAOQhHBPgfA4QgeAUgSAjQgUATgeAVIg0AkQgUgDgYAKQgMAFgZAOQgGAEgKAAQgJAAgLgDgAheIlQARgKARABQAQgRAogFQALgLALgBIAXgYQANgPAOgGQAPgbAxg4QAsgyAPgmQAjgmAUggQAbgpALgtQAjgsABglQAEgBADgDIAFgFQAGgeAQgoIAZhEQgKgDgCgOQAFgGAFAAIAMADQAWg9ANghQAFhTAVgpIACgOIgCgOQANgTgBgeQAAglAFgOIgPgWQgIgNgBgPQgPgbglgLQgmgLgkAOIAAAFQAAABAAABQAAAAAAABQgBAAAAABQgBAAAAAAQgIAEglARQglAxhfBgQhZBagoA5QgXARgfAnQgjAugQAPQgSAegnA4QgnA3gSAeQgdAagwA+QgwA+gdAaIgsA3QgaAggLAdQAjA2AuAYQAEAJAAAFQAkAdA7AbQAjAQBIAcIAkgBIAJAAQAKAAAJABgAGAhhQAFADACgFQACgGgEgBIgFAJg");
	this.shape_6.setTransform(21.8,99.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgCAEIADgIQAEABgCAEQgBAEgCAAIgCgBg");
	this.shape_7.setTransform(60.6,88.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D0D8D8").s().p("Al2M+QgmgPhDgGQhXgJgagFIgMAEQgIACgIgCQgGgjgYhOQgWhJgFgqQACAAAAgHQADABACgEQACgDAFACQAbg1AngaIBWh/QAzhLAlg0QAFgCAOgKQAEgIAAgGQAWgMACgTQAZgbBYhsQBEhSAxguQAmg5AmgfIAqg5QAZgiAVgQQAEgHAOgRQAMgOAEgMQAEABACgDQACgDAEAAQASgcAsgsQAugtARgZQAPgJAXgaQAWgZAQgJQAZghASgSQAZgbAbgPQAPgZAcgYQANgLAngbQAjguA9gaQA5gYBGgCQgCAFgSANQgOALAEAMQAAADgFgBIgHAAQgNAjglAdQgRAkgrAvQgxA2gPAZQgeAbg0A9Qg0A/gdAbQgEANgSASQgRARgEANQgFABgHAHQgGAGgGABQg6Bdg6AxQAAAEgDAGQgEAFAAAEQgiAgg1A/Qg4BFgaAaQgKAdgiAmQgkAogKAYQgSALgYAmQgYAlgUALQgHAYgYAeQgcAigHAQQgTAGgMAXQgLAcgIAMQADAJgDAPIgDAVQAGAKAOARQALAQAAATQACACADABIAHACIgFAJQALAFAGAVQAGAUANACQABAKAMAVQAMAUABAPQAJAHAGASQAGARgEAIQgBAFADABQAEACABACQgGAVgVAXQgaAdgGAKQgZAMgfAAQgNAAgPgDgAnEINQgbAAgIABQgaAIgVAcQgWAhgMAOQAEAKAKApQAHAhAMALQAMADAlAVQAfARAWAAQAQgBARgJQAKgFATgOIAMgYQAHgPAHgIIACg5QABgggNgQQgIgEgXgSQgTgPgQgFQgMADgTAAg");
	this.shape_8.setTransform(127.4,-77.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AiFImIgjABQhIgcgjgQQg8gbgjgdQgBgFgEgJQgtgYgjg2QAKgdAbggIArg3QAegaAwg+QAwg+AdgaQARgeAog3QAng4ARgeQAQgPAkguQAfgnAYgRQAmg5BZhaQBfhgAlgxQAmgRAHgEQABAAAAAAQABgBAAAAQAAgBAAAAQABgBAAgBIAAgFQAkgOAlALQAlALAQAbQAAAPAJANIAOAWQgFAOABAlQABAegNATIABAOIgBAOQgVApgFBTQgOAhgWA9IgMgDQgEAAgFAGQABAOAKADIgZBEQgPAogHAeIgFAFQgDADgEABQAAAlgjAsQgMAtgaApQgUAggjAmQgQAmgrAyQgxA4gPAbQgOAGgOAPIgWAYQgJABgNALQgpAFgQARQgRgBgQAKQgNgCgQABg");
	this.shape_9.setTransform(22.9,98.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#A3CECD").s().p("AgHAvIgOgKQgIgbAGgVQAFgSAQgTQAFABAHgDQAIgDAEAAQAIASgHAcQgIAiACAUIgKgBQgCABADAHQgIgBgHgGg");
	this.shape_10.setTransform(78.4,-15.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#A3CECD").s().p("AgVADIAPgwQALgHAGAAQAIAAAIAJQADAjgMAYQgPAggcAFQgFgWAJgcg");
	this.shape_11.setTransform(86.4,-12.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgdBeQglgVgMgDQgMgLgHghQgKgngEgKQAMgOAWghQAVgcAagIQAIgBAZAAQATAAAMgDQAQAFATAPQAXASAIAEQANAQgBAgIgCA3QgHAIgHAPIgMAYQgTAOgKAFQgRAJgQABIgBAAQgVAAgdgRgAA6gnQgGAAgNAHIgPAwQgJAcAFAWQAegFAPggQAMgagDghQgHgJgIAAIgBAAgAgXAsQgDgHACgBIAKABQgCgUAIghQAHgdgIgSQgEAAgIADQgHADgHgBQgQATgFASQgGAVAIAcIAOAKQAIAFAJABIAAAAg");
	this.shape_12.setTransform(81.7,-14.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgCAAQAAAAAAAAQAAAAAAAAQABgBAAAAQABAAAAgBQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABAAQADACgGACIgBABQgBAAAAAAQgBAAAAgBQAAAAAAgBQAAgBABAAg");
	this.shape_13.setTransform(141.8,-94.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#D0D8D8").s().p("AmkLhIgIgYIgYgjQgOgWgDgVQgOgQgPggQgSgpgHgLQADgHgCgKIgDgQQAGgdAWgMIAwhPQAcgsAcgaQADgOAMgSQANgTADgLQAegaArg9QAuhAAagZQAXgkAwgzQA4g9ASgZQAFgBAEACIAIAEIACgKIAAgOQAjgrBDhXQA+hMAyguQAQghAtguQAxgyAQgbQBIhLA9hQIAJgHQAGgEABgFQAFABAEgEQADgDAFABQADgPATgMQAXgNAFgIQADAAADACIAGADQABAIAFAVQAFASAAANQgCACgCAHQgCAIgDACQgBAhgVAkQgYApgEAWQgHACgHAMQgGALgIABQAAAGAEACQgOAMgUAnQgSAlgTALQgBAOgLAQQgKAOgNALQgJAVggAsQggArgKAbQgIABgFAKQgGALgIAAQgaBBgtAuQglBOhNBdQgBALgHALQgJANgCAGQgHAJgSAgQgQAbgOANQgXAzg6BPQg/BUgWAsIgQAMQABAIgEAJQgdAug/BPQhBBTgcApQgMgCgGgMg");
	this.shape_14.setTransform(149,-82.2);

	this.addChild(this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-119.1,-165.7,326.4,348.6);


(lib.termometro = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D3D2D1").s().p("A+VCxQgpgIgSAKQg3gCgTgCQgsgHgVgWQAAgMgLgZQgKgVAFgSIgHgQQAFhLAFgmQAJhEAggXIApAKQAVACAOgOQAEAAAEADQAEADAFgBQAFAAAEgCIAHgDQAZAFBDgKQLUgEGEgKICggCQBoAAA7gCQALAAAYACQAXADAMgBIAtgCIAtgCIFLgCQDOAAB/gDIBPABIBOACIDLACIAlgDQAXgCAMAFQCVgHDAAEIFXAKQAOgGAQADQAPADAKAJQAWgCAwgGQApgDATAQIAXgIQAOgEALgHQBIAJAxAcQAHAWAbABQgCAIAIAEIAPAJQADADAEAGQADAGACABQALAHAbABQAcAAAMAGQAlgGA6AAIBhgBQgFA2AMAZQgIAKAAALQgBAMAHAJQgFABAAAGQgYAFgegCQgdgDgVgHQgIAGgHAAQgHgBgKgFQgEAAgDAEIgFAFQgMgJgYABQgbABgLgFQgRAQgIAMQgKAPgEAUIgJADQgFABACAHQgMgEgHAIQgJAJAFANQgDgBgEACQgDACgEgBQgPAWgkAFQgrABgTACQgEgBgGgDIgIgFQghAEgLgCQgCgGgHgEIgMgIQiDAPhEgIQgIgnADhAQAFhGAAghQgDgIgPgEIgQAHQgIAFgEAJQgBAHAEAFIAIAJIAABWQgBAzgDAiQgPACgPgCQgHgbABgVQAAgdANgNQgGgVgIgHIgRAEQgIADgFAAQgCARABAoQABAngDAPQgLAAgCACQgdgKAEgtQAEg8gDgHQgEgDgIABQgIACgDgDQgTASAFAoQAGA1gDAMIgTAAIgOgzQgIgiAGgVQgEgJgLgEIgUgEQgKAVAEAcQADAWANAWQgFAOgFAVIgPgCIgMgBQgMgigEgSQgIggADgbQgJgMgSACQgSABgGAOQgCANAGAMQAFAMAMAFIAHAgQAFARgBAPQgFABgSgBQgQgCgJACIAAgJQgBgGADgBQgQgogGgwQgGgyAHgmQgGgQgKgHQgJgBgHAFQgHAHgFADQAAAWAIAyQAIAygCAYQACANAFAIQgBAFgEAFIgGAIQgBAEAFACQAEADgBAFQgJADgfgDQgDgDADgDQAEgEgBgEQgBgGgKgBQgMAAgDgCQAGgrACgUQACgkgTgMQgWABgKAPQAOAUgBAoIgCA8IgGACQgDABgCgDQgQgOgCgiQgCgeAKgaQgHgUgUACQgTAMACArQADA4gDALQgPgQgFghQgEggAIgZQgFgXgPgDQgdAMAGArQAJA7gFAQQgPADgJgKQgNgMgFgCQgHgPAEgvQADgogQgLQgIAAgLAFQgLAFgEgBQgDAXASA9QAIAwgzgFIgMhgQgHg5ADgpQgHgOgWACQgWADgDAQQACAIAHAJIAMANIAFBXQADAxgIAaQgFgCgJAAQgIAAgFACQgSgRgEgmQgEgmAOgXQgEgPgQgDQgRgEgJANQgEAWAGAnIAJA+QgLgBgFgOQgHgPgJgFIgCglQgBgWAIgNQgFgEgDgKQgDgJgGgFQgOgCgJAIIgOAPQAJAWAFAjIAFA5IgTAAQgDgDACgFQABgFgCgBQgSgMAAgsQAAgtgOgNQgZAFgIAHQABAIAMAqQAIAcgJARQgBAEAEAFQADAEgBAFQgEAEgHgCQgKgCgDAAQABgKgHgJQgJgMgBgDQgDgUADgiQADgfgDgKQgPgHgWALQgBASAFApQAFAmgEAVQgFAFgKAAQgJgBgGgEQAEgFgEgMQgDgIAIAAQgCgJgMACIgIhOQgFgtAGgZQgCgFgGgCIgLgFQgHABgGAHQgHAHgFABQAAAKALBKQAJA6gEAgQgLAIgPgGQgHgCgQgJIABgxQABgfAKgNQgFgUgWgBQgXgBgBAZQAJAQAAAcIgEA5IgTAAQgLgRgCggQgDggAHgZQgDgMgKgGQgLgGgNAFQgCADgDAJIgHAOQALAZAEAaQAEAggMAOQgGAAACgGQADgIgBgCQgRgHgFgeQgFgbAJgYQgDgUgWACQgWADAAAUQARA1gDAuQgCACgHgBQgJgCgFABQADgXgRgMIgCglQgDgcABgQQgHgSgaACQgEABgDAFQgEAGgFAAIAAAJQABAGgDABQATANAEAhQADAVgDAlQgHgBgMACQgKACgEgDQABgOgHgRIgPgdQgFg5AAgMQAAggAMgbQgGgNgPgCQgNgCgQAGIAIBmQAFA7AFAkQgJAFgPgBIgZgCIgIguQgEgeAIgVQgEgKgJgDIgTgDQgPAOAHAnQAHAtgGARIgMABQgEAAgFgDQABhCAGgfQgKgMgPAFQgOAEgFAMQAGAJgBAYQgCAZAGAMQgDAHgEAQQgggFgEghQgCgWAKgqQgCgMgKgGQgKgFgKAEIgIANQgFAHgBAIQAJAVAAAYQAAALgEAiQgDACgGABIgKACQgGgHACgJQgSgPADgxQACgxgRgMQgGgBgFADQgFAEgFgBQgMAFADASQAAADgFAEQABAGAKARQAJAQABALQAAALgCAQQgDATAAAIIglAAQgDgDgBgKQgBgMgCgDQgUgWACg7QAGhBABgXQgDgPgTgBQgTAAgGAOQANAcgCA4QgCBBAIAbQgEAEAAAEIABAMQgNAFgOAAQgRgBgHgIQAEgzgBgUQgCgigjAKIAABoQgPACgFgLQgCgGgBgUIgFgiQgDgSAIgPQgBgHgIgDIgOgEQgYALAHAsQAHAxgOAOQgSgKgCggQgCgygDgJQgDgHgJgDQgIgCgIACQgSAQAMApQALAogTAMQAAgOgCgIQgEgPgMAAQgEgNAFgpQACgcgRgIQgLAAgGAJIgIATQADAMAAAoQABAjAHAOIglAAQgCgRgOgBQgChWgMhKQABgFAEgHQAFgHgBgGQAAgJgKgDIgRgFQgUARADAlQACASAMAqQgBATgBAnQgBAigIARIghAAQgDgHgDg/QgBgsgeAAQgWANAPAmQASArgPAUIgTAAQgNgTgBghQgBgRAEgqQgbgLgRASIADAKQADAFgIABQAHAMABAbQABAfAEALIgGAGQgEADgGAAQADgIgDgEQgCgDgJgBQgCgHABg4QAAgkgUgKQgOADgMANQATBEgMApQgFACgUAAQgDgDADgCQAEgEABgCQgQgNgEgeQgFgfANgTQgIgYgYAGQgHABgFAIQgGAJgDACIAIAxQAGAgAAARQgFAEgLABQgKACgHgDQgLgkgFhDQgFg7ADguQgFgTgUACQgTACgCATQANAlADA+IACBnQgQAGgZgBIgKgpQgHgbADgSIAJgVQAFgLgKgKIgRgCQgMgBgIADQgBABgCAHQgBAGgHgCQgDABAEAEQAGAEAAACQgFAJABAIQABAGAFAKQgCAOACAVQABAUAEAOQgDADgJAAIgOAAQgBgEACgEIACgGQgQgMgDgfQgCgZAEgdQgHgMgRADQgRACgFALIAKA1QAEAaAAAcQgGAEgRgEQgBgJAKACQgVgbAFhLQgHgJgEgEQgIgGgLAAQgPAFAAAUQABASAJANQABAIgDAbQgCASAHAMQgCAHgNACQgLACgJgEQAKgIAAgOQAAgPgMgHQABgKgEgZQgEgXAEgQQgEgOgPABQgPABgHAJQgEAWAHAlQAHAjgDARQABACAGADQAFACgBAFQgIAEgQgDQgTgCgIABQgBgFAFgBQAFgCABgBQgBgJgKglQgHgcAEgTQgHgXgBgeIABg4QgBgHAIgEIgEgIQgCgFADgEQgGgFgMAAIgVgCIgFAJQgDAGgDACQAGAVgGAUQAKAPAAAXQABAOgCAgQAKAegPApQAIAGABALQACAKgGAKIg1AAQACgJACgnQACgfAKgPQgMgYgLgGQgYAEgLAJQgDAIADAKQADALgBAEQAUAOgKA+QgFADgKAAQgJAAgGgDQgJgSgBggIgCgvQgXgNgMAIQgJAOAJAjQAKAmgKAUQgJAAgDgIQgDgHAEgIQgGgCgBAFIgFgfQgEgUAJgIQgJgQAAgQQgGgLgPADQgNACgIAIQACAVAIAmQAFAggPASQgHgIgCgbQgDgagHgJQAEgHgCgPQgCgRADgJQgKgJgEgBQgJgFgKADQgPAUAKArQAPA7AAAFQgEADgJAAIgPAAQgBgBgBgFQgBgFgEACQABgegIhIQgIg9AGglQgHgNgLgEQgMgEgOAIQgBAaALBWQAIBCgLAsQgJACgNAAQgSAAgagEg");
	this.shape.setTransform(11.8,8.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ARBDUQgEgHgCgBQgMAEgqgEQgkgEgRANQgQgHgXAFQgLgHgHgDQhCgCgfACQgUgFggACIg0ADQgOAAghgEQgfgEgRABIgUAEQgMADgHAAIjegEQiLgChPAEQhFgIh0gGQg/gDiUACQiUAChEgDQgLAMgPAAQgPAAgKgMInIAIQkFAFi2ABQgGAAgIAFQgJAGgFAAQgQgIgHgBQhIgBiuAGQiXAGhZgEIgpAAIgqACIjDACQh6ABhTAEQgNgEgRgLIgbgRQgKgXgQgQQABgFgFg0QgEgqALgYQgEgVAFgkQAGgmgDgQQAGhIA5gcQAOACAQgHIAegNQAKAHAfAJQCJAEDqgDQD+gDBzACQA4ABBzgDQBUAADogFQDMgEB4ACQCIACEPgHQBegCCpAAQC0ABBNgBICHgBQBOgCA3gGQB8ALDXgDQD4gDBYAEQAFAAALAFQAXADAmgFQArgGARABQAHAAANAEQAOAEAHABQAMABASgEIAegGQAZgEAqADQAxAEAQgBIAMAHQAHAEACAFQAQgCAYAKQAcAMANABQAEACADAKQADAJAGACIAVAIQAPAHgIAKQALAAAPAIIAbANQAbgCAdABQAhABATAFQBCgOBwAEQB7AFAzgHQAmAFBbgDQBPgEAlAJQAYgEAaAAIAvAAQANAKAXALIAjAQQgDAJADAGIAOARQgDAIADAbQgWAagFAZQiaAwkegCIgPAFIgPAEQgxgDg0ACIhkAEQgfgLg4AEQhAAEgPgCQgEABgOAKQgKAHgOgCQgJAZgdAZQgpAhgGAHQhFALhcgCIiVgEQgRgIgZAAIguABQgGgBgEAGQgFAGgDABIgVAAIgBAAQgFAAgEgGgEgjXACwQAtAIAVgGQALgsgIhBQgLhWABgbQAOgHAMAEQALAEAHANQgGAkAIA9QAIBIgBAeQAEgBABAEQABAGABAAIAPAAQAJAAAEgCQAAgFgPg7QgKgrAPgUQAKgDAJAEQAEACAKAIQgDAKACARQACAPgEAHQAHAIADAbQACAaAHAIQAPgSgFggQgIgmgCgUQAIgJANgCQAPgCAGAKQAAARAJAQQgJAIAEATIAFAfQABgEAGABQgEAIADAIQADAIAJgBQAKgTgKgmQgJgkAJgNQAMgJAXAOIACAvQABAgAJASQAGACAJAAQAKABAFgDQAKg/gUgOQABgDgDgLQgDgLADgHQALgJAYgFQALAHAMAXQgKAPgCAfQgCAngCAKIA1AAQAGgKgCgLQgBgKgIgGQAPgpgKgfQACgfgBgPQAAgWgKgPQAGgUgGgWQADgCADgGIAFgIIAVABQAMABAGAFQgDADACAFIAEAIQgIAEABAIIgBA3QABAeAHAYQgEATAHAcQAKAlABAIQgBACgFABQgFABABAFQAIgBATADQAQACAIgEQABgFgFgCQgGgCgBgCQADgRgHgkQgHgkAEgWQAHgKAPgBQAPAAAEANQgEAQAEAXQAEAagBAJQAMAHAAAPQAAAOgKAIQAJAEALgCQANgBACgIQgHgMACgSQADgagBgJQgJgNgBgRQAAgUAPgFQALAAAIAGQAEADAHAJQgFBMAVAaQgKgBABAIQARAFAGgFQAAgcgEgaIgKg0QAFgLARgDQARgCAHALQgEAeACAYQADAgAQALIgCAHQgCADABAEIAOAAQAJAAADgCQgEgPgBgUQgCgUACgPQgFgKgBgGQgBgHAFgJQAAgCgGgFQgEgDADgCQAHACABgFQACgIABAAQAIgDAMABIARACQAKAJgFAMIgJAUQgDATAHAbIAKAoQAZABAQgGIgChnQgDg9gNglQACgUATgCQAUgCAFATQgDAvAFA7QAFBDALAkQAHACAKgBQALgCAFgEQAAgQgGggIgIgxQADgCAGgJQAFgIAHgCQAYgFAIAYQgNATAFAfQAEAeAQAMQgBACgEAEQgDADADADQAUAAAFgDQAMgpgThDQAMgOAOgCQAUAKAAAkQgBA4ACAGQAJABACAEQADADgDAIQAGABAEgDIAGgHQgEgLgBgeQgBgcgHgMQAIgBgDgEIgDgLQARgRAbAKQgEArABAQQABAiANASIATAAQAPgUgSgrQgPgmAWgMQAeAAABAsQADA+ADAHIAhAAQAIgRABghQABgnABgUQgMgqgCgSQgDglAUgQIARAEQAKAEAAAIQABAGgFAHQgEAIgBAEQAMBKACBWQAOACACARIAlAAQgHgPgBgiQAAgogDgNIAIgSQAGgKALAAQARAIgCAcQgFAqAEAMQAMAAAEAPQACAIAAAOQATgMgLgoQgMgpASgPQAIgDAIADQAJADADAGQADAKACAxQACAhASAKQAOgPgHgxQgHgsAYgKIAOADQAIAEABAHQgIAOADATIAFAiQABAUACAFQAFAMAPgDIAAhoQAjgJACAiQABAUgEAyQAHAJARAAQAOABANgFIgBgMQAAgEAEgFQgIgaAChBQACg5gNgcQAGgOATABQATAAADAPQgBAYgGBAQgCA7AUAWQACADABAMQABALADACIAlAAQAAgIADgSQACgQAAgLQgBgLgJgQQgKgSgBgGQAFgDAAgEQgDgRAMgGQAFACAFgEQAFgEAGABQARAMgCAxQgDAyASAOQgCAJAGAHIAKgCQAGgBADgBQAEgiAAgMQAAgXgJgVQABgIAFgIIAIgMQAKgEAKAFQAKAGACALQgKAqACAWQAEAhAgAFQAEgQADgHQgGgMACgZQABgYgGgIQAFgNAOgEQAPgEAKALQgGAfgBBDQAFADAEAAIAMgBQAGgRgHgtQgHgnAPgPIATAEQAJADAEAJQgIAVAEAeIAIAvIAZACQAPAAAJgFQgFgkgFg6IgIhnQAQgFANABQAPACAGAOQgMAaAAAhQAAALAFA5IAPAdQAHASgBAOQAGACAKgBQAMgCAHABQADglgDgVQgEgigTgNQADAAgBgGIAAgKQAFABAEgGQADgGAEAAQAagCAHASQgBAQADAbIACAmQARAMgDAXQAFgBAJABQAHABACgBQADgvgRg1QAAgUAWgCQAWgCADATQgJAZAFAbQAFAdARAHQABADgDAIQgCAFAGABQAMgPgEgfQgEgagLgaIAHgOQADgIACgDQANgGALAHQAKAGADALQgHAZADAgQACAgALASIATAAIAEg6QAAgcgJgQQABgYAXABQAWABAFAUQgKANgBAeIgBAxQAQAKAHACQAPAFALgHQAEghgJg5QgLhKAAgKQAFgCAHgHQAGgHAHAAIAJAEQAGADACAEQgGAZAFAtIAIBOQAMgBACAIQgIABADAIQAEALgEAGQAGAEAJAAQAKABAFgFQAEgVgFgmQgFgqABgRQAWgLAPAGQADAKgDAgQgDAhADAUQABAEAJALQAHAJgBALQADgBAKADQAHABAEgDQABgGgDgEQgEgEABgFQAJgRgIgbQgMgrgBgIQAIgGAZgFQAOAMAAAtQAAAsASAMQACACgBAFQgCAFADACIATAAIgFg4QgFgkgJgVIAOgQQAJgHAOACQAGAEADAKQADAJAFAFQgIANABAVIACAlQAJAFAHAQQAFANALABIgJg9QgGgnAEgWQAJgNARADQAQADAEAQQgOAXAEAmQAEAmASAQQAFgCAIAAQAJAAAFACQAIgagDgxIgFhWIgMgNQgHgJgCgJQADgPAWgDQAWgDAHAOQgDApAHA5IAMBhQAzAFgIgxQgSg8ADgXQAEAAALgEQALgFAIgBQAQAMgDAoQgEAvAHAPQAFABANANQAJAJAPgDQAFgPgJg7QgGgrAdgMQAPADAFAWQgIAZAEAgQAFAhAPARQADgLgDg5QgCgrATgMQAUgCAHAVQgKAZACAfQACAiAQAOQACACADgBIAGgBIACg8QABgogOgUQAKgPAWgCQATANgCAjQgCAVgGAqQADACAMABQAKABABAGQABAEgEAEQgDACADADQAfADAJgDQABgFgEgCQgFgCABgEIAGgJQAEgFABgFQgFgHgCgOQACgXgIgzQgIgyAAgWQAFgCAHgHQAHgFAJAAQAKAIAGAQQgHAlAGAzQAGAvAQApQgDAAABAGIAAAKQAJgDAQACQASACAFgBQABgQgFgRIgHggQgMgEgFgNQgGgMACgNQAGgNASgCQASgCAJANQgDAbAIAfQAEATAMAiIAMAAIAPACQAFgUAFgPQgNgVgDgXQgEgbAKgVIAUAEQALADAEAJQgGAWAIAiIAOAyIATAAQADgLgGg1QgFgpATgRQADACAIgBQAIgCAEADQADAIgEA8QgEAtAdAKQACgDALAAQADgPgBgnQgBgoACgRQAFAAAIgDIARgDQAIAGAGAVQgNAOAAAcQgBAWAHAaQAPACAPgCQADghABg0IAAhWIgIgIQgEgFABgIQAEgJAIgEIAQgIQAPAFADAHQAAAhgFBGQgDBAAIAnQBEAICDgPIAMAIQAHAFACAGQALABAhgEIAIAFQAGAEAEABQATgCArgCQAkgFAPgVQAEABADgCQAEgCADAAQgFgNAJgIQAHgJAMAFQgCgHAFgCIAJgDQAEgTAKgQQAIgLARgQQALAEAbgBQAYAAAMAIIAFgFQADgDAEgBQAKAGAHAAQAHABAIgHQAVAIAdACQAeACAYgFQAAgFAFgCQgHgJABgLQAAgMAIgKQgMgYAFg2IhhAAQg6ABglAGQgMgGgcgBQgbgBgLgGQgCgBgDgGQgEgHgDgCIgPgJQgIgFACgHQgbgCgHgVQgxgchIgJQgLAGgOAFIgXAHQgTgPgpACQgwAHgWABQgKgJgPgCQgQgDgOAFIlXgKQjAgDiVAGQgMgFgXACIglADIjLgCIhOgCIhPAAQh9ACjOABIlNABIgtACIgtADQgMAAgXgCQgYgDgLAAQg7AChoABIigACQmEAKrUAEQhDAJgZgFIgHAEQgEACgFgBQgFABgEgDQgEgDgEAAQgOAPgVgCIgpgKQggAWgJBFQgFAmgFBKIAHARQgFARAKAWQALAZAAAMQAVAVAsAHQATADA3ABQAKgFARAAQAOAAASADgAetBBQAFgDAFABQAlACApgBQAygCAfgGIBggDQA1gDAigKQADADAMgBQAMAAADACQAIgGAUgEQAXgFAHgDIAIACQAFACADAAQAFgIANgDQAOgEAFgGIAEgMQABgEAAgHIALAAQgDgEgGgPQgGgNgGgFQhZgcigAHQgEgBgDgDIgHgFQAAADgCAEQiGAKiwgKQgHAVAIAZQAKAdgCAUIAFACQAEADgCAHIgJALQgFAIAAAIIAcAGQAQABAMgHIAIAFQAFADAFgBQAGABAFgDg");
	this.shape_1.setTransform(44,8.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A3B6B7").s().p("AjbBKQgFABgFgDIgIgFQgMAHgQgBIgcgGQAAgIAFgIIAJgLQACgHgEgDIgFgCQACgUgKgdQgIgZAHgVQCwAKCEgKQACgEAAgDIAHAFQADADAEABQCggHBZAcQAGAFAGANQAGAPADAEIgLAAQAAAHgBACIgEAOQgFAGgOAEQgNADgFAIQgDAAgFgCIgIgCQgHADgXAFQgUAEgIAGQgDgCgMAAQgMABgDgDQgiAKg1ADIheADQgfAGgyACQgpABglgCQgFgBgFADQgEADgEAAIgDgBg");
	this.shape_2.setTransform(261.5,7.8);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-208.7,-13.3,505.6,43.7);


(lib.solucion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("SOLUCIÓN", "bold 15px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 112;
	this.text.setTransform(56,6.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape.setTransform(58.8,17,0.439,0.707,0,0,0,-0.1,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape_1.setTransform(58.8,17,0.439,0.707,0,0,0,-0.1,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape_2.setTransform(58.8,17,0.439,0.707,0,0,0,-0.1,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape_3.setTransform(58.8,17,0.439,0.707,0,0,0,-0.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,117.7,34);


(lib.sec6 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AjVCAQgGgEgRgJQgQgHgGgIQgFgYgBgdIgBg1QAVhBAYg+IAbAKQgeBLACBAID9ACQCSAABYADIgBAbQgPAFglADQgQgHgXABIgpACIiogFQhqgEgsAFQgPACgKAHQgNAIAGALQAlAdBVADIgBAaQg7gBg6gFg");
	this.shape.setTransform(-227.4,258.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FBD4C9").s().p("ApbIGQACgQAOgUQAcgfAKgRQASgegMgeQgsAKhQAyQhIAug8AGQAJgcAggWQAmgYARgOIA3glQAhgWAQgVQgZgSghAeQgqAlgQADIhIA0QABgYAdgeQAogoAGgKIAOgMQAJgHAJgBQACgPAKgLIAjgcQAUgQgDgWQgFgmhFAIQgnAFgTACQghACgQgHQAngMBKgNQBPgNAZgGQAZgOAsgNIBLgVIAxAAQAaABANgBQBqhHCxiNQCeiBBIg1QCGhiB4g/QA7gPBigoQBngrA0gOIAIAAQAIAcATBnQAPBTASAqQgyAHhIAbQhQAfgmAHIgbAPQgQAJgNAEQgmAfhWAxQhWAygmAeQhbAjiBBNQhwBGg3AdQgPAMgnAXQglAWgRAPQABAegQA3QgSA9gDAeQgYAMgNAnQgHAWgMAvQgNgBgKgKIgRgRQgBgOAWhEQAQgvghgTQhDAYg0A1QgpArgoBIQgNAJgWAXQgUATgZABQAMgrAggVg");
	this.shape_1.setTransform(-175.6,-75.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Ak2B8IAMgCQCog2BggWQAKACAVgDQAOgDAJAEQCKhVCKhuIAPATQixCNhqBHQgNACgYgBIgxgBIhLAVQgsANgZAOQgZAGhPAOg");
	this.shape_2.setTransform(-213.3,-75.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAjA4QAPgTAJgUQgTgFgfACQgiAEgRABQg7ADgKgnQAGglAzgIQAegFBAgEIAEAaQhJAMgmAMQAQAIAggDQATgBAlgGQBGgIAEAkQADAXgTAQIgjAcg");
	this.shape_3.setTransform(-248.5,-55.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AkcAPIABgZIASABIESgHQCrgFBpAMIAAAaIkfABIhDAAQiBAAhWgDg");
	this.shape_4.setTransform(-208.6,270.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AltEbQgDgnAZgmQAhgpAOgVIAbAHQgNAUgDAQQgfAUgNAsQAZgCAVgTQAVgWANgJQAphIApgrQA0g2BDgYQAhATgQAvQgXBEACAPIAQARQAKAJAOACQAMgvAFgWQAMgoAZgMQACgdASg7QAQg4AAgeQARgOAkgWQAngXAQgNQA3gdByhGIALATQgEACgDAHQgDAJgCACQg2AZhAAoIhuBHQACARgLALQgOAOgBAGQgRBngPAwQgbAKgMA8QgLA4gcAGQgUADgXgOQgVgNgJgQQgOgbAKgmQAPgrAFgVQgrAIglAoQgOAQgtBCQgkA1gdAVQgiAagrAAIgTgBg");
	this.shape_5.setTransform(-207.5,-42.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AiYB8QgFgSAGgQQACgGANgVQACg7AygyQA+g2AYggIAZAQQgLAKgCAPQgJACgGAHIgPALQgGALgnAnQgeAcgBAZIBIgzQAQgCAogmQAhgdAZARQgPAVgiAXIg1AjQgQAOgmAXQggAXgKAcQA8gHBHgtQBQgwArgLQANAdgSAdQgLARgcAgIgbgHQANgUAGgRQgZACghATIg4AkQgwAcgqAAQgYAAgWgJg");
	this.shape_6.setTransform(-245.2,-36.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF4000").s().p("Ah9BIQACgvAcgxQAlhCAFgUQAHAEBLA4QAzAlAtALQgHAbgdAcQgdAcglAQQghAOgeAAQgxAAgkgng");
	this.shape_7.setTransform(-222.7,224.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF4000").s().p("AgOAZQg/gdgagkQAIgYAQgMQAGgCACAGQAZAdA8AkQBCAmAYAXQAAAHgHAGQgIAGgBAFQgIgFhegwg");
	this.shape_8.setTransform(-215.3,214.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AhQQwIABgcQAegIBQAFQBQAGAkgLQhLgciIgGQiqgIg1gKIABgbQBhADBeAIQgHghASgiIAdg5QgLgCgcgJQgXgJgSAAQgeAxgKAJQgbAcgtgCQgLgGgHgMQgFgJgFgRQgUASgcAEQgiAFgKgbQARgWAKgrQgHAEgeAhQgVAYgeAAIgPgJQgIgGgBgJQABgkAjgxQAigvgBggIhDAtQgsAfgmgBQgnAAgmgTQgigQgdgdQgvA5gdBHIgbgLQAnhgAohEQAHgJAZgIQA2h3AagvQAwhaA0g4QACgIAGgOQAHgNABgJQB9iZBRhWQB3h7B0hUQDVidCdj0QAPgEAJgSIAQgeIgsg2QgdghgPgVQAFgIAHgXQAGgUAGgJQA3gKAvgrQApgmAdg5QgNgtgghFIAbgNQA6CBBCBXQBPBmBkA9IgSATIhKgrQgdgcgwg0IhLhQQgBgFgEABQgJAEgCAEQgQAJgdAXQgcAWgQAKQgEAEguAXQggARgGAYQCPC5DyDTIgUAWQg9glhXhdQhehlgzgjQAAADgCACQgCADAAAEQgTALgQAYIgdAqQgGAHgPAOQgQAOgHAJQgOARgUAiQgWAmgMAOQgTAYg5A1QgvArhKA4Ih5BdQh2BbhpB/QhbBvhbCVQBWBTCDAuQBBg/BrhMQB6hTA8grQAZgLAYgQIAOAXQiZBghxBUQiJBnhmBqQANAvA3AUQAFAHgFAKQgFANABAGQANgPAkACQAnADAEAfQAIgCAUgBQAQAAAMgFQAIAFAMAOQANAPAHAFQAkAPBUASQBVARAlAPIAfAbQATAQAOAJQABANAGAOQAIAUABAFIgWBBQgPAjgXAUQhkgGiDgCgAg7OQQgCAiAGAWQAoAIBAAEIBuAIQALhEg4ggQglgVhUgLQghAYgTAggAjVMuQgQAVgCAlQAiACAPgYQAIgMALgqQgIgCgHAAQgUAAgPAUgAknMTQgTAZgBAjQA3gKANhKIgGAAQgZAAgRAYgAmEL5QgGAKgWAwQAegJAUgbQARgUANgkQggAFgUAdgApaI6QgcAygCAvQA5A+BdglQAlgPAdgdQAdgcAHgdQgtgLgzgkQhNg5gHgEQgGAUgkBDgAoAGfQgQANgIAXQAaAlA/AfQBgAvAIAGQABgFAIgGQAHgGAAgIQgYgXhCgnQg+gkgZgdQgBgFgEAAIgDAAg");
	this.shape_9.setTransform(-172,165.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgLgLQASgdAggFQgNAkgQASQgTAbgeAJQAWguAGgKg");
	this.shape_10.setTransform(-209.7,242.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgNgRQASgaAcADQgMBHg1ALQABgkASgXg");
	this.shape_11.setTransform(-200.3,245.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#8E0000").s().p("ACBCIQhZgDiPAAIkAgBQgChCAehJQAdhHAvg5QAdAdAiAQQAmATAnAAQAmABAsgfIBBguQABAhghAvQgiAwgBAjQABAJAIAGIAPAJQAcAAAVgYQAegfAHgEQgKApgRAWQAKAaAigEQAcgEAUgSQAFARAFAJQAHAMALAGQAtACAbgcQAKgKAegwQASAAAXAIQAcAKALACIgdA5QgSAiAHAhQhegJhhgDg");
	this.shape_12.setTransform(-213.7,247.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AghAmQADgkAQgUQARgaAfAIQgLAogIAMQgOAXgbAAIgHgBg");
	this.shape_13.setTransform(-191.9,248.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AoOHDQCAhPBbgiQAmgfBWgxQBXgyAlgeQANgFAQgJIAbgOQAkgIBQgeQBIgcAzgGQgSgrgPhQQgThogIgcIgIAAQg0APhoAqQhfAog8APQh4A/iFBgQhJA1igCBIgOgTQBUhDBIhBQA/grAggXQA0gnAlggQBgg4CKg4QBEgbC1hCQADgXgFgoQgGglAEgQQCYhTDsglQAZgEAygMIAFAVQgpAKgfANQh2APhQAXQhhAeg9AwQgHB9AUBoQAXB2A4BEQA2gEBEgRIAGAWQg0AMgkASQgKAOgGAHQgLAJgNADQhNBkhDBtIgXgOIBCh1QAohEApgjQgEgJgJgLIgPgTQg5AIhUAdQhfAignAJQhmBKiLBNQhgA1ijBQg");
	this.shape_14.setTransform(-119.2,-116.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#9A1919").s().p("AgqAZIkUAGIgSAAQhVgDglgcQgGgKANgIQAKgHAPgCQAsgFBqAEICqAFIApgCQAXgBAQAHQAjgDAPgFQA1AKCqAIQCLAGBLAaQglAMhQgGQhSgGgeAIQhpgLipAFg");
	this.shape_15.setTransform(-203.3,266.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAAA6QhBgFgogIQgGgWACggQATggAhgXQBUALAlAUQA4AhgLBCIhtgIg");
	this.shape_16.setTransform(-167,257.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AhQEMQARg0AHgmQALgygBgtQATgfALg0QAGgaAIhJQAPgxAph/IAbAIIgJAcIgRBQQgMAugPAaQgLBXgXBbQgBArgQA1QgIAfgVA6g");
	this.shape_17.setTransform(-134.5,0.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AkWDhIBihCQA6goAvgTQAsgsAUgYQAjgmAUgkQAhgUAXgkQAOgHAKgBQASgUAygxQArgsAXgcIAVATIhVBiQgzA3gwAdIg6BHQgkAsgTAfQiXBYhfA8g");
	this.shape_18.setTransform(-131.2,165);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#BE0000").s().p("AAAARIgfgLQAMgZAdAAQAgAAgPAlQgEACgGAAQgIAAgJgDg");
	this.shape_19.setTransform(-134.8,44.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FBD4C9").s().p("ApbGsQBaiVBchvQBpiAB1hbIB8hdQBKg3AtgsQA5g0ATgYQAMgPAVglQAUgjAPgRQAHgIAPgOQAPgOAHgIIAcgpQARgYATgLQgBgEACgDQADgDAAgCQAzAjBdBkQBXBeA+AlIALAGQgTAmgfAmQgWAcgsArQgyAygSAUQgJABgPAHQgXAkghAUQgUAigkAoQgVAXgrAtQgwASg6AoIhiBDQgWAPgYAMQg9Arh7BTQhrBLhCA/QiDgthVhTg");
	this.shape_20.setTransform(-160.8,161);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AjvBLQg5AJgrgcQgmgZgSguQAHgbANgnIAWhCIAcAJQgZBOAHA5QAagGB7goQBYgdBIgBQB0grDegdQAqgGAxgDIABAVQgXAFjIAdQiHAThAAjQhlgBhcApQABARAMAkQAMAggBAZIAWAxIgbANQgYgygPgkgAkzAfIAeAKQATAFALgDQAOgngfAAQgfAAgMAbg");
	this.shape_21.setTransform(-107.2,42.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AiCECQAoh+AZhFQAmhnAmhMQASgYAHgMQAOgWAEgWQAdgdAYgpIAYAPQiODuhcEYg");
	this.shape_22.setTransform(-115.9,-52.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#00A23D").s().p("ABaESQgogXgTgDQjvjUiPi3QAGgYAggQQAtgYAFgEQAQgJAcgXQAcgWAQgKQADgEAJgEQADgBABAFIBMBQQAwA0AcAcIBJArQAxAcAlARQAwAVAvALQAQANAiAOQAsARALAHQgYA2hgB6QgPASgWATQgdAYgTADIgIAAQgXAAgagOg");
	this.shape_23.setTransform(-102.8,105);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AHIDDQAEgbgCglQiNglhggSQiKgZhzAAIgCgVQBjgFBtARQDRAiBTAOQg6gsh5gbQiMgYhCgSQiigKh7ACQiZACh0AVIgmAQQgXAKgLgPQAKgXArgKIBHgSIExgLQCsgCB+AZQDBAlB3AuQgMgqg3gVQhEgVgegLQiBgvipgWQiggUiwAFIhKAQQgyALgQgPQAEgVAagDQAOgBAcABQDFgTCxAPQDBAPCYA1QgwghhpggQiCgngZgMQArACAnALQAyALAYAUQBEAHBUAkQAxAUBbAtIAZADIgBAKQAAAMAJAPQAKANABAJQACAMgFALIgJASQAUAaAIAlIgRARQgLAGgQgDQgLATgHAkg");
	this.shape_24.setTransform(-64.1,23);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AJ2NQQgngZgqgqQgRgRg2g8Iglh3QgXhIAEg5IgkhBQgXgogNgbQgTgKgSgjQgVglgOgLIAAgYIh0iYQhGhagshBQh4i4g0izQh4hIi9hQQgFAIgJALIgSAVIglAsQgdAegWACQgfADgkgnQgrgtgWgHQgXgTgogaIhBgrQghATg0BOQg7BWgdAZQgnAigmAJQgxALgigiQgjAcgmAqIgVgTQAfglAUgmIgMgHIATgVQATADAoAXQAfARAagDQATgDAdgYQAWgTAPgSQBgh6AYg2QgLgHgsgRQgigOgQgPQgvgLgwgVQglgRgxgcIARgTQAlAOBdAnQBQAiAyARQCoBdB1BcQAUg2AbheQAehvANglIAaAJQgUA/gQBHQA2A6CiBCQCfBAA1A9QAMAXADAKQAEASgCAVQA0CZBqCcQAwBGCcC/QBPhZB9g/QhEjkgsiBIAZgIIBLDdQArB5AmBbQAsBJA7BUQAbggAOgPQAZgaAnAMQANgbAjgUIA/ghIAZAPQgZAWgCAqQgDAtAaARQAMgDABgXIgGgjIAPgeIARADQgEAJgBBFQgBAvghADQgOgBgKgOQgLgPgJgCQgCAGgDArQgBAggPAHQgWADgOgNIgUgaQAAAhgEAOQgJAagXADQgfAAgMgnQgOgxgKgIQgMAJgGATQgEAOgCAaQgaA1g9AnQgiAXhUAlQAYDDB4BBQAhgYAhgxQAjg5AUgaICYiWQBahaA6hAQAJAAAJgMQAIgLAKAHIALAKIigCnQhgBjhEBAQgLAVgsA8QgkAwgMAnQATAIALgSQALgYAGgKQBMhQAlgpQBAhHAng8QAugnBrh5QBdhpBDgvIASASQicCWh3CEQiLCchsCYQARAAATgLQAXgOAIgDQBEhgBVhEQAZgkAXgcIAPAMQgBAIgGAMQgHAMgBAIQgVATgIAJQgOARgFATQgjAXg/BIQg5BCguAXQgpAHgNABIgHAAQgWAAgZgIgAHSDaQhDAkgRA2QAKAeAdArQAfAwAKAXQASAEARgEIAhgIQANgNAWgNIAmgWQAihSANgaQgUhFgvgwQhcAhgZAOgALXEVQgCAwAZALQANgUAEghQADgkgMgXQgeAEgBAxgAMqDkQgIA3AhAZQANgGgBgcQgCghACgOQAHgOAEgRQAEgWgHgPQgkAPgJA2gAFGDPIARAeQAKASAJAJQA4g0AggVQA1gmBAgGQgRgygsgaQh3Aug9BagAoSpiQgJAhAGAWIAmgjQAUgWAGgXIgUgSQgMgKgQAAIgNA1g");
	this.shape_25.setTransform(18.7,179.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgIgDQAEAAAEADQAEABAGgBIAAADIgNABQgIAAADgHg");
	this.shape_26.setTransform(-78.6,-0.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FF7F00").s().p("AtyN7QAVg6AIgfQAQg1ABgrQAZhbALhZQAPgaAMguIARhQIAJgcQBckZCQjtQBDhtBNhkQANgCALgKQAGgGAKgOQAkgTA0gLQAugLCMgPQB2gNA6gTQgRgIgpAGQguAHgWgFQARgPBEgMQA/gLASgWQhZgEh2AkQiFAuhEARQhEASg2ADQg4hEgXh3QgUhoAHh+QA9gwBhgeQBQgXB2gPQAfgNApgKQBTgVBigDQBmgDBUASQA+AfAgBZQAcBQgGBcQARAKAQASQAIAKARAYQAQAXALALQAQARATAIIAqAFQAbADATAAQAQgEASgOIAegWQAKgPAJhFQAHg4AagNQBvB9ANCQQADAfgBA0IgGBpQgEBBAAAnQgiAkhMAEQgpAChZgKQAGgUAXgsQAVgnAGgdQAkg/AQgfQAhg8APgqQAehPgmgNQgJARgGAjQgJAsgEAMQgoBBg0BzQgYA1gzBqQg+CDgeBDQgyBygfBfQABALgDAOQgEAOACAKQgiBXgPCYQgJBXgKCuQhcgtgwgUQhVgkhEgHQgYgUgvgMQgngKgsgCQAaALCAAoQBpAgAvAhQiXg1i/gPQi0gPjEATQgcgCgPACQgZACgEAWQAQAPAygLIBKgQQCwgFCiAUQCnAWCBAvQAeALBEAVQA3AXAMApQh4gtjBgnQh7gZiuACIkxALIhHARQgrAKgKAZQALAQAXgKIAlgSQB0gVCagCQB7gDCkAKQBAATCMAaQB5AbA6AsQhTgPjSghQhqgRhlAFQgxACgqAGQjdAdh3ArQhIABhXAdQh8ApgaAFQgHg5AZhOgAixJ0QAuAKAkAEQgXgSg1gHQg9gFgbgGIBSAWgAkXJWQgDAIAIAAIAPAAIAAgEQgGACgFgDQgEgDgEAAIgBAAg");
	this.shape_27.setTransform(-51.5,-60.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AAAADIhRgTQAcAFA7AGQA1AFAXASQgkgEgugLg");
	this.shape_28.setTransform(-69.3,1.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("ADrGBQgQgSgRgKQAGhcgchQQgghZg+gfQhUgShkADQhiADhVAVIgFgVQBSgVATgDQA8gMA0AAQBgABBTAPQAOgkAFgVQAHgkgCglIgLADIgHgYIAWgHQABgLgCgNIgDgUQgFAAgYAJQgSAGgRgDQghgTgPgsQgQguAGg4QAHg4AbgoIAbAHQgOAQACAWIgLAYQgQAxALAxQANA2AoAIQAJgBAMgKQAMgJALAAQAVAGALAeIgJB4QgGBBgRAlQAnAlARAbQAJAYAcCEQAWBkAiAoIgbAKQgRgYgIgKg");
	this.shape_29.setTransform(-26.5,-168.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AltChQAUgEAQgJQBdAFBfgnICXhOQgGgFgSABIgeAAQgzgSgZgLQgqgQgTgZQgBgGAGgEQAFgEgCgGQANgHARAGIAbAJQDdgNBxhPQBKgPBFgWIAEAOIjZBUQiCAzhuAIQASAXA5ADQAIAABXgEQAJAAAZgLQAWgHAEASQgGATgeAMQgkANgIAIQgpANg4AaIhfApQh1AvhuABg");
	this.shape_30.setTransform(-16.1,-251.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AjMAkQBEgRCGgsQB1gkBaAEQgSAWg/ALQhEAMgTANQAXAFAugGQApgFASAGQg6ATh3ANQiLAPgvALg");
	this.shape_31.setTransform(-55.6,-111.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("Ai2EYQAPgyAUgrQArhhAxhDQA3hKBLgwQiPgrgwgRQhogmhAguQhKgKAKgiQAfgFAmAXQAyAeANAEIBCAeQAnAQAkAGQAMgWAGgeIAcACIgKA+QASAMAhAIIA/AMQAUAEAoAHQAiAIAOARQAFAQgMAUQgOAXABARQAGAQASAKQAJADAbAJQBDA4A8A2IgUAVQhyhmh5g3QgKgCgZgCQgWgBgLgDQh2BzhBDFgABLgzQApANALgFIAAgQQgBgJgDgDQgdAAgTAUg");
	this.shape_32.setTransform(-12.6,66.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AhNB6QgDgXAWgMQAMgHAZgKQAUgOALgWQAJgPAOgfQhPAbgdAIQhPAVgrgOQgDgZAWgIIAlgRQASgMAhgjQAfghAWgMIAHgLIASALQgUAXgmAjIg7A4QA6AEA0geQBDgrAVgFQAFAHACAGQAJAagcAqQglA7gDAKIBYgWQA1gMAhgLIAIAYQgXAHgjAaQgqgDhKAXQgvAOggAAQgNAAgKgCg");
	this.shape_33.setTransform(-34.4,-183.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AAkBAIAYgpQAOgXAHgSQgogDhOAgQgLgCgUACIgfADQgiABAAghQAFgKAQgEIAbgHIApgUIAKASQgTAMgIALQAsgEAxgUIBVghQABAFAJAGQAHAGAAAHQgXBAg4A+g");
	this.shape_34.setTransform(-41.3,-202.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFBE00").s().p("AqfGvIA7g6QAmgjAUgXQA4g/AXhBQABgIgIgGQgIgGgBgEIhVAhQgzATgsAEQAHgLATgLIAcgMQARgIAJgGQBzhcA5hBQAKgHAagNQAUgQgIgWQgPgIgVAJQgWAMgKADQjIARhQg5QBtgBB1gvIBggpQA5gaApgNQAIgIAkgNQAegMAGgTQgDgUgWAHQgaALgJACQhYAEgJAAQg4gDgTgZQBwgICDgzIDXhUIAwgNQCZgGBoAKQB9AsAzBsIAegGQATgEALgCQAtAIAZAKQAiAOAQAYQAIAhAOBEQANA7ARAgQgZACgPgRQgPgXgJgKQgMgBgJAIIgPANQAIARAQASIAcAdQATA6gQBCQgQBFgrAWQAiiIg1h8QgvhthehGQgPABgOAGIgXANQgEADgDALQgDALgCADQgZATgHARQg3Avh3AZQiOAXhBAPQhDAQgrAUQg0AbgcApQgjBAgdAhQACgKgEgNQgDgNABgIQgsgYgmAMQgiAKgYAlQgaAogHA4QgHA4AQAuIgVAIQgCgGgFgHQgVAFhFArQguAcgyAAIgOAAg");
	this.shape_35.setTransform(19.7,-226.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AhJB8QB+hDBMhrQiPAMjAg4QgGgRACgTIAjgGIAhgFIAEATQBQA4DHgQQAJgDAWgNQAVgIAQAIQAIAVgUAQQgbAPgJAIQg5A+hyBcQgJAHgRAHIgbAMg");
	this.shape_36.setTransform(-38.4,-221.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#006B33").s().p("AgbAAIAOg0QANAAANAKIAUASQgGAXgVAUIgjAjQgHgWAJggg");
	this.shape_37.setTransform(-31.6,118.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFBE00").s().p("Ag5AEQAcgqgJgaIAVgIQAQAsAeATQASADARgGQAYgJAFAAIAEAUQACALgCALIgWAHQghALgzAMIhYAWQADgKAlg7g");
	this.shape_38.setTransform(-22.8,-183.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#00A23D").s().p("AgLElQgygRhQghQhegogkgNQhkg9hOhmQhDhWg6iAIgVgyQABgZgMggQgMgjgBgUQBcgoBkAAQBDgjCHgTQDIgdAXgFQB0AACKAZQBfASCNAlQADAlgFAbQgFAegNAWQgjgGgngPIhCgfQgOgEgxgeQgmgXgfAFQgLAiBLAKQA/AvBpAlQAvARCRArQhKAwg5BMQgyBDgrBgQgTAqgQAyQgMAlgfBvQgaBegUA2Qh1hbimheg");
	this.shape_39.setTransform(-67.1,76);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FBD4C9").s().p("AAcAXQgRgMgKAAQgIABgQAJQgPAIgLACQgCgWAOgOQAYgfAiAIQAlAIgJAzIgDAAQgGAAgMgIg");
	this.shape_40.setTransform(-15.6,-209.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FBD4C9").s().p("AkFI2QgigogWhkQgciEgJgYQgRgbgnglQARglAGhDIAJh2QgLgegVgGQgLAAgMAJQgMAKgJABQgogIgNg2QgLgxAQgxQASAOASgJIAkgRIAJAOQAEAKgBAMQgsgHgQAuQgQAuAoAPQAygKASgSQgGgMgXAGQgZAHgGgFIgEgNQgDgJAHgCIAugRQAXgGAXALQALgGAAgSIgDggQALgqAbgqQAPgZAjgwQAZgYAqgXQAVgMA4gZIAIgBQDEgaBEgTQCHgoAzhWQBEAPA1BjQAwBdAABZQgBAWgHAjQg/gVgRABQgGAAgDAHQgFAHgCACQACAUAlAAQAsABAJAHIgBARIgDAcQgCARACAOIhsENQhCCWhLBXIgdATQgRALgKAKIhPAQQgvAIgqgEQg9gIg8gdQgigQhDgrQgVgdgLgOQgUgZgUgMQgJgYgGgLQgKgTgXACQgEABgCAHQgCAIgEAAQBfCpCtA7QgNAXgOA+QgNA9gQAXQgcAHgXAAQg6AAgigogAA6CJIgOAJQANAiAsAgQA4ApALANQAfAEAYgFQAegHAHgUQgJgQgeADQgoADgFgCQgagKgdgfQgjgmgOgJQgCgDgEAAQgDAAgFACgAD6AOQgSAzAYAhQAzAKAYgBQAogBASgYQgQhtAHhtQAVgzgpADQgPApABBWQACBogEAbQgigDgFgCQgUgFgFgOIARg8QALgngYgPQgIAYgaA2gAGkihQgUAcAAApQAFAHAPABIAdAAQAKgKAEgaQADgfADgNQgNgOgMAAQgNAAgLARgACEj6QgPAGgKAWQgZA2AeAcQAkAEAJgkQAEguADgWQgLgMgMAAQgEAAgFACgACOldQgbADgSANQgVANAAAUQAIACAEAGQAMgDAbgRQAWgNAXABIAPALQAIAHANgDQAAgWgVgLQgOgHgUAAIgLAAg");
	this.shape_41.setTransform(28.4,-184.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AirCEQAQguAsAHQACgMgFgKIgJgOIgkARQgRAJgTgOIAMgYQALgCAPgIQAQgJAKgBQAKAAARAMQAPAKAGgCQAJgzglgIQgkgIgYAdIgcgHQAYgjAigKQAmgMAsAYQgBAIADANQAEAMgCAJQAdgfAhhAQAcgpA0gbQArgWBDgQIADAVIgJABQg3AZgWAMQgpAXgaAYQgiAwgOAZQgbAogLAqIADAgQABASgMAGQgXgLgXAGIguARQgHACADAJIAEANQAHAFAYgHQAXgGAGAMQgRASgzAKQgngPAPgug");
	this.shape_42.setTransform(-2.2,-210.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AiCHdQAKiuAIhXQAQiYAhhVQgBgKAEgOQADgOgBgLQAfhfAwhyQAehFA9iDIATAJIhdDaQg3CDgRBrQALALAaAOQAdARALAJIgJAVQgkgRgogUQgfBQgMCMIgUDvg");
	this.shape_43.setTransform(-2.3,-29.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AhXNIQABg0gDgfQgNiQhvh9QgaANgHA4QgJBFgKAPIgeAWQgSAOgQAEQgTAAgbgDIgqgFQgTgIgQgRQgLgLgQgXIAbgKQAwA4BfgXQAQgXANg9QAOg+ANgXQitg7hfipQAEAAACgIQACgHAEgBQAXgCAKATQAGALAJAYQAUAMAUAZQALAOAVAdQBDArAiAQQA8AdA/AIQAqAEAvgIIBNgQQAKgKARgLIAdgTQBLhXBCiWIBskNQgCgOACgRIADgcIAdADQArgWAQhFQAPhCgSg8IgcgdQgRgSgHgRIAPgNQAJgIAMABQAJAKAPAXQAPARAZgCQgSgggNg7QgNhEgIghQgQgYgigOQgZgKgtgIQgMACgSAEIgfAGQgzhsh9gsQhmgKiYAGIgxANIgEgOIA5gTQBygHBHAFQBhAHA8AfQAPAVAdAZIAxAqQB3APBBAlQASAYALArQAHAZALA1QAXBhAyAWQABALgEAIIgJANQgOAAgUgIQgVgHgNgBQgFBwgXBJQgWAiguAuQgqBehNC/QhJCkhRBZQgpAagVAKQgjASglAGQgWgBgfACIgzADQBTB6AZBjQABAkgCBgg");
	this.shape_44.setTransform(47.5,-188.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#006B33").s().p("AgZAFQAUgSAaAAQAEADAAAJIAAAOIgHABQgOAAgdgJg");
	this.shape_45.setTransform(-2.4,60.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgLAVQiVgjhpgsIAJgVQApAJC4AzQCHAlBiANIALAHQAGAFAHAAIAoAJIgGAcQi1gkhagXg");
	this.shape_46.setTransform(27.8,-17.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("Ag/DlIhUgGIgTgIQAzhrAYg1QA0hwAnhCQADgLAJgsQAGgjAJgSQAmANgeBPQgPAqgfA9QgQAfgkA8QgGAdgVAnQgXAtgGATQBZAKAngCQBMgEAigjQAAgoAEhBIAGhnIAdABQgCBOABAnQACBAAIAyQgUAMglAMIg/ATIABAGIgZACIgSABQgfAAglgDg");
	this.shape_47.setTransform(25.7,-98.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AEcDZIAAgRQgIgHgtgBQgkAAgDgUQADgCAEgHQAEgHAFAAQASgBA+AVQAIgjAAgWQABhZgxhbQg0hjhEgPQgzBWiFAoQhFATjFAaIgDgVQBDgPCOgXQB1gZA3gvQAHgRAZgTQACgDADgLQADgLAEgDIAXgNQAOgGAPgBQBeBGAvBtQA1B8giCIg");
	this.shape_48.setTransform(50.1,-227.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AAYgqQgSAMgjApQglAjgogGQgfgEgFgZQgEgQAMghQANgkAZghQAfgjAPgUQhShghEg9IAUgVQBcBSBoBsQAwBmAyCFQAhBZA2CgIgZAIQhKjbhOilgAhugZQgIAfAfAHQAfAJAGgcQgGgZgWgMQgIgEgFAAQgOAAgFAWgAgyhzIgQAhQAGATAGAHQAIAMAQACQAcgHAKgdQgOgogMgQQgUAAgMATg");
	this.shape_49.setTransform(40.5,112.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FBD4C9").s().p("ABhGWQhqicg0iYQADgWgFgRQgDgKgLgYQg1g6ighBQihhBg2g6QAPhHAVg/QBAjFB4h1QALACAXACQAYACAKACQB6A5BvBmQBEA9BSBgQgPAUgfAjQgZAhgNAkQgMAhAEASQAFAZAfAEQAoAGAlgjQAlgrASgMQBOCnBKDZQAsCABEDnQh9A+hPBaQicjBgxhHg");
	this.shape_50.setTransform(18.7,130.8);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#E49E65").s().p("AgFAeQgegIAHgfQAIgfAWANQAWANAGAXQgEAXgVAAQgFAAgFgCg");
	this.shape_51.setTransform(32.2,110.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FBD4C9").s().p("AFdFKQgtgZhXgOQhlgOgvgKIgogJQgHAAgHgEIgKgIQhggNiJgnQi4gygqgKQgLgJgdgRQgcgQgMgKQARhpA5iEIBejaIBUAFQAwAEApgBQAEBngNC6QAKAKASABIAdAAQApAKBBAgQBJAiAfALICwA7QBqAbBigXQAiAFAOAFQAYAHAMAMQALAbgMAmQgPAyAAANQAAADAKAkQAGAWgMAPQgTABgIgQQgEgKgDgbQgGg5gggDIgfANQgTAHgKAIQgNgCgPgGIgYgMQgDAhAgAPQAfAPAogPQAQAZAEAfQgFAIgYARQgUANgDASQghgQgTgcg");
	this.shape_52.setTransform(47.6,-38.9);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AAPBAQgLgNg2gpQgrgegOgiIAPgJQAKgFADAGQAOAJAkAmQAcAdAZAKQAEACApgDQAegDAIAQQgHAUgeAHQgNADgQAAQgMAAgOgCg");
	this.shape_53.setTransform(43.7,-164.1);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AhAAUQgBgTAVgMQATgMAZgDQAagDASAKQAVALAAAUQgNADgIgHIgPgKQgWgBgVAMQgbARgMACQgEgFgHgDg");
	this.shape_54.setTransform(42.7,-216.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#DC781D").s().p("AgZAgQgFgIgHgTIARgfQAMgSARgBQAMAQARAmQgMAegbAGQgPgBgJgMg");
	this.shape_55.setTransform(37.5,103.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AB4DZIiug7QgfgKhLglQhCgggpgJIgdgBQgRgBgKgKQAMi4gDhnIAYgCQAGA9AABBQAAAugDBZQAvAOBTAjQBUAjAyAQQAtAOBjAjQBdAaBagHIAPgCIAFAaQgsAKgvAAQg3AAg6gPg");
	this.shape_56.setTransform(59.7,-52.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgQA3QgfgbAZg0QAKgWANgHQARgHAQARQgEAWgEAtQgIAggbAAIgHgBg");
	this.shape_57.setTransform(41.5,-204);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("Ag6CJQgYghASgzQAag2AIgYQAYAPgLAmIgRA9QAFAPAUAFQAFABAgADQAEgagChpQgBhVAPgqQApgDgVAzQgHBrAQBvQgSAYgoABIgFAAQgWAAgugJg");
	this.shape_58.setTransform(60,-188.2);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FF4000").s().p("AhmBFIgRgeQA9hYB2guQArAaARAyQg/AGg2AkQgeAVg4A0QgJgJgKgSg");
	this.shape_59.setTransform(63.3,196.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgNAuQgPgBgFgHQAAgnAUgcQAUggAbAdQgDAOgDAcQgEAagKAKIgPABIgMgBg");
	this.shape_60.setTransform(71.9,-197.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FF4000").s().p("Ag1CLQgJgXgggwQgdgrgKgcQASg2BCgkQAagOBZghQAvAwAVBFQgNAYgjBSIgmAWQgVANgOANIgfAIQgIACgIAAQgJAAgKgCg");
	this.shape_61.setTransform(70.3,211.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("ACQDQQgwgJgSghQgtgBgjgeQgnglgXgQQhTgTifgfIAGgdQAvAKBlAOQBYAPAtAYQASAcAgAQQACgSAUgNQAYgRAFgIQgEgfgQgXQgoANgdgNQgggPADghIAZAMQANAHANABQAJgIATgHIAggNQAfADAGA3QADAcAFAJQAHARAUgCQALgOgGgXQgKgiAAgDQABgNAPgxQALgngKgbQgNgMgYgHQgOgEghgFIgGgaIAZgFQAPgCAJABQAVADAdAXQAhAcASAGQAFACAoAHQAXAFAMAOQAIAbAAAZQgPALgFAfQgDAdALATQgJAPgGAaIgKAvQgQAJgNAYQgLAegHANQgWAYgjAAQgKAAgMgCgACFCqQA3AOAPgqQgjAHgigJQgNgDgugTQAGAnA0ANgACqBaQgbAJgEAHQAfADAUgBQAPgBAdgFIAGgVQACgMAAgLQgIAAgRADQgPADgMgCQADAUgXAIgAC6gcQgFAcAJAeQAQACASgHQATgHAMAAQACgSgFgPQgDgJgKgQQgmAAgPAMgADGhwIgIAwQAGgBAogFQAYgDAKgPQgRgYguAAIgJAAg");
	this.shape_62.setTransform(84.7,-12.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#9A1919").s().p("AlbF3QANgnAkgxQAsg7ALgVQBEhBBghjICeikQBWhZBDg+QACgFALgMQAIgKADgJQATgJAVgRIAkgeQgBgEACgDQADgDAAgCIAMAAQgOAfgtAqQgvAqgOAdQhDAwhdBoQhpB3guAnQgoA8g/BHQglAqhMBQQgGAJgLAYQgHANgNAAQgFAAgGgCg");
	this.shape_63.setTransform(118.2,222.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#8E0000").s().p("AkzBGQBUglAigXQA9glAag1QACgbAEgOQAGgSAMgKQAKAJAOAwQAMAoAfAAQAVgDAJgaQAEgOAAgiIAUAbQAOANAWgEQAPgGABggQADgsACgFQAJACALAPQAKAOAOAAQAhgCABgvQABhFAEgJQADgHAGgGQAggLAHgdQALAaAQA5QATAvAfAOQgBAHgJALQgJAJADAOQgKgHgIAKQgJANgJgBQg6BBhaBXIiWCWQgUAbgjA5QghAxghAYQh4hBgYjDg");
	this.shape_64.setTransform(95.8,224.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgTgCQABgwAdgEQAMAWgEAiQgDAigNAUQgYgMACgug");
	this.shape_65.setTransform(93.4,207.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FBD4C9").s().p("AgEAYQg0gOgGgkQAuATANADQAgAHAjgFQgMAdghAAQgLAAgMgDg");
	this.shape_66.setTransform(98.6,2);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgWgEQAIg2AigPQAHAPgEAWQgDARgIAOQgCAMADAhQAAAcgNAGQgegZAIg1g");
	this.shape_67.setTransform(102.1,203.3);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FBD4C9").s().p("AgyAWQAEgHAbgJQAVgGgCgUQALACAPgDQARgDAIAAQAAALgCAMIgGATQgdAFgOABIgKABQgRAAgXgDg");
	this.shape_68.setTransform(103.8,-4.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FBD4C9").s().p("AgcAjQgKggAGgaQAPgMAjAAQAKAQADAJQAGAOgDATQgMAAgTAHQgMAGgMAAIgHgBg");
	this.shape_69.setTransform(106.7,-13);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FBD4C9").s().p("AgfgWQA0gDASAZQgKAPgYADQgmAEgGACIAIgug");
	this.shape_70.setTransform(107.8,-21.5);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgYAGQADgoAXgWQAJgJALgCQAIAUgLAaIgOAcIAFAjQAAAXgLADQgZgRACgtg");
	this.shape_71.setTransform(110.4,198.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AioEmQCOi7DUjkQgBgJgHABIhfBbIgRgSQAOgdAvgrQAtgpAOggIgMAAQAAACgDAEQgCADABADIgkAfQgVARgTAIQgDAJgIAKQgLANgCAFQhDA9hUBXIgLgKQgDgNAIgKQAKgLABgGQgggNgSguQgQg5gLgbQgHAdghALQgFAHgDAGIgSgDQALgagIgUQgLACgJAJIgZgPQAXgNANgPQAJADALgCQAPgBAKAAQArgkBBglQAhgSBVgtQALAEAlAAQAhABALAHQAVAVAvAkQAoAiAQAhQgSAogpAoQgXAWgyAqIiKCnQhSBig/BCgAhgi9QgaAwATAyQARAvAqATQAfgkBDhCQBFhCAfgkQgbgegtAAQhEAAhuBGg");
	this.shape_72.setTransform(134.4,205.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#2D0606").s().p("Ag/AgQB1iCCbiWIBfhbQAHgBABAJQjWDmiMC5QgXAcgZAkQhVBEhEBgQgJADgWAOQgTALgSAAQBsiYCMicg");
	this.shape_73.setTransform(121.8,226.3);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("Ah8AzQgTgzAagtQC3h0BDBMQgfAjhFBBQhDBBgfAlQgqgTgRgvg");
	this.shape_74.setTransform(136.5,190.9);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("ABSIpIAPgEQBBghBXgbQCIhRBJhYQBdhwAXiXQgEhkgHg0QgLhQgagvQgBgEgHgEQAAACgDAEQgCADABADQgEBBgFAlQgIAxgPAqQgkBcgeAzIgWgNQA2h6ARhCQAchygTh1Qgvg5gYgcQgrgxgrgWQBEB2g4CuQgeBgheCfIgkAlQgVAUgTAPQg/AvhHAoQhYAuhEAPIhNAQQguAIghAAQgdAAgxgQQgwgRgeABQgKgBgUgUQgQgQgGAJQAfBRApAyIgUAVQhgh0ggisQAIgrgNgVQAGh1AohsQAehRA9hlQCPhwAigWQBshFB3gVQCugdCLAzQCFAxBJBxIAMAKQAIAFAMgDQACAYARAUIAdAgQAjBKAUBWQAXBngGBYQgDAogNAuQgIAbgQAvQgKAVgYAnQgYAmgKAWQgzA8hJA1Qg8AshVAvQgbAIgrAOIhGAWgAkhm+QgIAIg/AwQgrAhgSAfQgnCiAvCxQArCkBdBoQBBgHBPgVIgGgTQgCgJAEgMQihkcARlvQAAgFgEABQAAgEgDAAIgBAAgAotg1QgYB/AcBrQBCBRCKATQgBgXgVgiIgig3QgmiEgQhDQgdh5ADhjQgzBRgVB0gAiLoCIhaAgQgeB/AaDBQAQBxAuBnQAtBmA9BFQAwgRA0giIBag9Qgfg3gpgxQg4ijgYheQgqinAgh3QgxAFg1APgAANoeQgdArACBHQABAXAOBrQALBLAZBPIAsCDIAlAtQAXAaAUAPQBKhiAkhVQAxhyACh6QgIgpgYgwQgcgzgNgcQhHgVgpgGQghgFggAAQgeAAgdAEg");
	this.shape_75.setTransform(272.2,119.7);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("ABUBpQg3gGgbABQizg/hnh8IAUgUQAwA8BDAdQCEARB5goIAJAaQhiAehoANQBEAjBnAFQBhAFBbgVIAHAcQg+ATg1AJIgTAAQgaAAglgDg");
	this.shape_76.setTransform(252.9,169.8);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#015353").s().p("AhdCmQgchrAYh/QAVh0AzhRQgDBjAcB5QAPBDAmCEIAiA3QAVAiABAXQiIgThChRg");
	this.shape_77.setTransform(226.2,121.2);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#015353").s().p("Ah+BgQgvixAniiQASgfAsghQA+gwAIgIQACgBAAAFQAEgBAAAFQgOFtCfEeQgFAMADAJIAFATQhPAVhBAHQhahogsikg");
	this.shape_78.setTransform(243.4,111.4);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("Aj5CkQBDgWBMgpQAggSBdg6QAugjA9hDIBlhwIAXAOIgHAKQhTB8h5BZQh7BcicAyg");
	this.shape_79.setTransform(288.8,149.2);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#015353").s().p("AhvDRQguhpgQhvQgajBAeh/IBbggQA1gPAvgFQgeB3AoCnQAXBdA7CkQAoAxAgA3IhbA9Qg2AigtARQg+hFgthmg");
	this.shape_80.setTransform(266.1,104.2);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#015353").s().p("AghENIglgvIgtiCQgYhQgLhIQgQhsgBgWQgChIAfgqQA8gKBAAKQAnAHBHAVQANAbAcA0QAXAvAIAqQgBB3gxByQglBVhJBkQgTgOgWgbg");
	this.shape_81.setTransform(287.5,95.9);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#015353").s().p("Ak7HZQhDgdgwg8QgpgygghRQAGgJARAQQAUAUAJABQAfgBAwARQAwAQAdAAQAhAAAvgIIBNgQQBDgPBWguQBJgoBAgvQATgPAUgUIAlglQBdifAfhgQA4iuhEh2QAqAWArAxQAZAcAuA5QATB1gcByQgRBCg2B6IhlBvQg9BDguAmQhfA6ggARQhMAphBAWQhWAchaAAQgnAAgogGg");
	this.shape_82.setTransform(269.9,120.5);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#015353").s().p("Aj8GQQhqgGhDgjQBqgNBhgfQCdgyB6hcQB5haBUh6IAHgLQAdgzAkheQAQgqAHgxQAGglADhBQAAgDACgDQACgEAAgCQAHAEABAEQAbAvAKBQQAIA0ADBmQgXCVhcBwQhKBYiIBRQhXAbg/AhIgPAEQhKAShOAAIgkgBg");
	this.shape_83.setTransform(287,136.7);

	this.addChild(this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-260.8,-272.2,593.9,545.4);


(lib.sec5 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8D2C6").s().p("A+XVzIAArVQAmgJBQgfQBJgdAvgJQAegXBAgRIBrgcQDFhfAqgSQCLg/B2glQBPg9BggRQAlgZAtgUQGPiNEQkRQANghAdgmQAjgqAPgVQANgsAbgsQARgbAlgwQBKieAphMQBHiEBUhCIAlgRQA/AUBDgdIA0gZQAdgOAVgDQAdgEA0AUQA0ASArgGQArgrBZALQAyAGBrAVQA8guBbhLICVh5QA2gQCNhGQB0g7BIgGQAGAJADAIQAKAYgJAWQgEAMgTAZQggAvgRAQQgeAfghAHQgLgCgRgSQgPgOgUABQgtBMhmCQQhYCEgjBtQglA6gRAiQgdA4gFAqIAOAIQAGAGgBAIQBYAHBNgjQAmgQBag7QBOgzA4gRQBVgaBnASQAMAMAbAUQAWAUACAaQgVAbg8AOQhGAMgfAJQgZAdg5A3Qg4A2gZAfQABANgHASQgHATAAAMIggAeQgQASgCAZQgcAHgXAZIglAuQiLBAimBfQhJAqjaCAQgTACgZAMQgcAMgPACQiEgBg+ACQhpADhHANQgRAOgdAKQgLAEgsAMQhhBNjcCAQjhCBhgBLQicBWi8CAQgxAgkWDGQhkAshwBOIi9COQgHAHgWAGQgVAHgHAIQgBACgbARQgTALAQADQATAEARAAIAAAIg");
	this.shape.setTransform(-87.4,165);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F8D2C6").s().p("AiMAsQAsgvAkgXQA5gkAxASQAvgKAwAKQhKA0g2AWQgzAVguAAQgdAAgbgHg");
	this.shape_1.setTransform(-3.1,53.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F8D2C6").s().p("AirBHQAQgRBAggQA3gZAQgfQAdgJA4gZQA0gUA3AEQhDBJgeAVQg9AvhOAJQgLAIgIAIQgkAEgPAAIgBAAQgYAAgMgPg");
	this.shape_2.setTransform(26.9,49.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AbpVFQgDgqgHgHQgFg8hOthQgzo3gRl+QhtALhTBNQhGBBgtBqIhSBLQgzAvgeAdQiZBCipBiQhrA8jAB6Qg8ANhZgGQh1gIgdABQhVAEh0A6Qg+AhhkBDQh7BVgnAXQikBjoHFCQgpAlhRAxQh1BGgSAMIl/EDQgZARgxAlQgsAcgpAAQgQAAgTgEQgRgDAUgLQAbgRABgCQAGgIAVgHQAXgHAGgGIC+iOQBvhOBlgsQEWjGAwggQC8iACdhWQBghMDgiAQDeiABihOQApgLALgEQAegKAQgOQBIgNBogDQA/gCCDABQAQgCAbgMQAagMATgCQDaiBBIgpQCmhfCMhAIAkguQAXgaAcgHQACgYARgTIAggeQAAgLAHgTQAGgSgBgNQAagfA4g2QA5g3AYgdQAggJBGgMQA7gOAVgbQgBgagWgUQgcgUgMgMQhmgShVAaQg5ARhOAzQhaA7glAQQhOAihXgGQAAgJgGgFIgNgIQAEgqAdg4QARgiAmg7QAjhtBYiEQBmiPAshMQAUgCAPAPQASASAKACQAhgHAegfQARgRAhguQATgaAEgLQAJgWgKgZIAcAAQAXAYgCApQgBAYgNAzQARARAnABQAZAAAsgGIAIAcIg6ARIADA3QAFAlARAUQgWAvASBhQAXCAAAAfQAKATAZAhQAUAgABAiQADAZgRASIgeAeQAHCZAVEYQAXEqAGB4QAJCwAiEfQAqFYAJBsQABAKgCAYQgBAWACAMQADAZAVAtQAJAmgoAUQgYAAgDgigAVZx5QhAAogwAJQigDnhnECQBXgCBKgwQBNg8AsgZQCgg6CaAYQgBgqgOhNQgNhFACgwQgKgSgHgeIgKg1QgOhAgugUQgpAKhDAqg");
	this.shape_3.setTransform(-55.8,165.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#ECA66E").s().p("AgCBcQgmgBgSgQQAOgzAAgYQACgogWgYQASgNAegHQAOgEAYgEQAhBDAKBvQgpAHgYAAIgCgBg");
	this.shape_4.setTransform(102.2,33.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#006B33").s().p("AgYAxQgJgFhShCQAQgrBOgMQA5gKBPAJQACA7gDAcQgDAugOAcIgHAAQg/AAgzgig");
	this.shape_5.setTransform(97.2,-205.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgXCfIBBgQQAKgrgHg2QgFgygRgkQgVAGgfAFIg5AJIgFgcIADgDIADgFIgCgCQgBgPgWgYIADgCIAOAFIAGAIIgEgHIAgAMIAAACIAKABQAFgUgKgSQgNgVgggHQgcgGgGALQgEAIAKAPQgSgTgFgOQgHgTANgSQAqgCAlAnQAWAXAeA0QApgDBggQIAEAbQgdAEgTAFQgJAuAHAzQAGA5AVAdQAbgBASgEIAEAUIgGAIIAEADIioAkg");
	this.shape_6.setTransform(125.2,22.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF0000").s().p("AARAbQgTgUgWgeIAFgDQAQAYANAPQAKALAFACIAAABg");
	this.shape_7.setTransform(113.8,14.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF0000").s().p("AAIANQgNgPgQgYIAsA1QgFgDgKgLg");
	this.shape_8.setTransform(114,14.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF0000").s().p("AAfAgIAAgCIAFACQAEgLgEgOQgJgZgjgIQgUgEgGAEIgBAAIAAABQgGAGAMARQAGAHAIAHIgDADIgRgRQgKgQAEgIQAGgKAcAFQAeAIANAUQAKARgFAUg");
	this.shape_9.setTransform(116,11.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF0000").s().p("AgWgYIAEgDQAWAhATAQIgBAGg");
	this.shape_10.setTransform(114,14.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF0000").s().p("AgDADQgMgPAGgGIADAEIAAABIASAdIgDADQgIgHgEgJg");
	this.shape_11.setTransform(113.4,10.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FF0000").s().p("AgHgJIAPARIgBABQgJgJgFgJg");
	this.shape_12.setTransform(113.3,12.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF0000").s().p("AgCAAIABgBIADABIgCACg");
	this.shape_13.setTransform(112.7,9.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FF0000").s().p("AABAPIADgEIgSgcIABgCIAcAng");
	this.shape_14.setTransform(114.2,11.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FF0000").s().p("AAeAdQABgEAAgHQgBgLgFgHQgKgQgagGQgNgDgGABIgGgDQAHgFATAFQAkAIAIAZQAEANgDAMg");
	this.shape_15.setTransform(116.2,11.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FF0000").s().p("AAOAUIgdgmIADgCIADADQALANAOAZg");
	this.shape_16.setTransform(114.4,11.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FF0000").s().p("AAAAPQgOgZgNgMIgDgEQAGgBANADQAaAGAKARQAFAHABAKQAAAIgBADg");
	this.shape_17.setTransform(116.2,11.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgbBtQgKhwghhCQgaADgPAEIgGgYQATgEA5gYQAqgUAmgCIAEADIAFAcQgpAGgVAIQAJBhAtBQQAigCAmgKIAGAdQheAWgrAMg");
	this.shape_18.setTransform(111.6,31.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FF0000").s().p("AgCAAIAFAAIgDABg");
	this.shape_19.setTransform(115.9,17.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FF0000").s().p("AAAgCIABACIgBADg");
	this.shape_20.setTransform(116.5,17.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#DC781D").s().p("AhjhHQAXgIApgGIA4gJQAggFAWgGQAQAkAGA0QAGA0gKArIhCAQQgkAKgiACQgvhQgJhhg");
	this.shape_21.setTransform(120.1,29.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FF0000").s().p("AgDAAIADgCIADAEIgDABg");
	this.shape_22.setTransform(140.5,37.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FF0000").s().p("AgDgBIAHADIgDAAg");
	this.shape_23.setTransform(140.8,37.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FF0000").s().p("AgGgCIAFgBIAIAHg");
	this.shape_24.setTransform(141.2,38.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FF0000").s().p("AgGAAIADgDIAKAFIgHACg");
	this.shape_25.setTransform(141.1,37.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FF0000").s().p("AgRgEIgJgJIACgBQAYAOATAHIAIAIQgUgHgYgMg");
	this.shape_26.setTransform(143.7,39.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FF0000").s().p("AgVgJIAHgCQAOAKANADIAJAKQgUgIgXgNg");
	this.shape_27.setTransform(143.4,39.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#ECA66E").s().p("Ah6AMQgHgzAJguQATgFAdgEQBagLA5AbQBBAggSBHIhRAnQguAVgtAIQgSAEgbABQgVgdgGg5g");
	this.shape_28.setTransform(145.4,25.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#F8D2C6").s().p("AgNgGIABAAQANADANAKQgOgGgNgHg");
	this.shape_29.setTransform(143.3,38.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FF0000").s().p("AANALIgBgGQgCgFgKAAIgJgDIgIgIIASAGQASADgBAOg");
	this.shape_30.setTransform(147.5,41.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FF0000").s().p("AAUAQQABgQgSgBIgSgGIgJgJQARAIALACQAPADAEAJQACAGAAAFg");
	this.shape_31.setTransform(147.3,41.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FF0000").s().p("AgKgGIAKACQAIACACAEIABAFQgLgFgKgIg");
	this.shape_32.setTransform(147.7,41.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FF0000").s().p("AgigdQAaAOASAGQALAJANAFQABAKgJAPg");
	this.shape_33.setTransform(145.4,42.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FF0000").s().p("AgFAKQAHgNgBgKIAFABQAAAMgIAOg");
	this.shape_34.setTransform(148.7,44.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FF0000").s().p("AgGAMQAIgNAAgNIAFABQAAANgIAPg");
	this.shape_35.setTransform(149.1,44.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#F8D2C6").s().p("EgKcAofIAAgHQAogUgKglQgUgugEgZQgCgMACgWQABgYgBgKQgJhsgplYQgjkfgJivQgGh4gXktQgVkXgGiaIAdgdQARgTgCgZQgBghgVggQgZgigKgSQABgggYiAQgShhAWgvQgQgUgFgkIgEg4IA6gOQAtgNBegWICqgkIAOAJIA+A9IgBABIAJADQAKgNAAgOQAMACAKgCQAYgPgTgZQgVgbAEgGQAJgBAmgTQAdgPASAIQALAygiBCQgmBLgCAlQAqgYAeg6QARgfAehHQgXhEANhaQAGgtAdhpQgFhBgHgdQgNgwg4AHQgLAZAUAeQAaAmACAOQgEAJgNA5QgKApgRAQQglgbg+gEQgugDhKAKQhfAPgrAEQgfg1gVgXQglgmgrABQgMASAHATQAFAOASAUQAFAIALALIABgBQAWAYAAAPQgSgPgYgjIgIAFQAVAgAVAUQgmADgsATQg4AYgUAFQgSAEgRABQgSgtAPhPQAQhZgHgiQBQiyAHkaQABhSgEikQgEioAChQQAIm5ALifQAWlGBBjzQCpAED5AqQFsA+AsAFQApAMEbBIQDGAyB2AoQBvAWAUAFQBGASAlAcQgiDdhlEkIhVDyQgzCOgeBmQhKCPh/EhQiCEphGCIQAKBQgJByQgNClgBAVQASAeAFA4IADBpIBkIxQA0FWgIEDIgEBPQgMCggsDRQgZB3g1DhQAAA/gcCdQgXCBANBHQADAHARAAIAAAFg");
	this.shape_36.setTransform(190.8,45.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AAxDIQAhhBgKgzQgSgHgdAPQgkATgKABQgEAGAVAbQARAYgVAQQgLACgLgCQABgGgCgGQgFgKgOgDQgOgDgRgIQgNgLgPgDIgBAAIgMgIIgEgUQAugIAwgVIBPgnQARhHhAggQg4gbhcALIgEgbQBKgKAuADQA8AFAlAbQARgRAKgpQANg4AEgKQgCgOgagmQgUgdALgaQA4gHANAxQAHAdAFBAQgeBqgFAtQgNBYAXBEQgeBHgRAhQgeA6gqAXQACglAmhNg");
	this.shape_37.setTransform(153,24.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AhfIzQgOhHAYiBQAbidAAhAQA1jeAXh3QAtjRAMihIAaACQgOC2gmDjQgPBhg2ErQgBAMgIATQgJASgBAMQAEA6gFBTQgGBdABAeQgDACgJADQgJACgKAAQgQAAgDgHg");
	this.shape_38.setTransform(223.8,247);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#006B33").s().p("AACA/Qg4gChYgTQgFgWALggQAKgfAQgUQBWATA3AWQBGAZAsAnQg9AWhEAAIgOgBg");
	this.shape_39.setTransform(303.7,-169);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("EgxqApDQDSgyD/hqQEeh+CRg8QCOhAEeh+QDyhyCShwQCOiCCMj5QCVkfBTiJQAUgJAggfQAfgdAYgJQAhgBA+gPQA5gOAqACQBmhyCihCQBrARBqALQA/g6BDgXQBYgeBXAmQEFh/CTg6QgGhuAyivQA5jHAFhRQAGhSgEh2IgIjHQgKliAdlcIANjiQAIiEAXhKQgZAFgYgIQgIgCglgRIgtgSQgegMgNgKQgfgWgqg/QgrhAgDgeQgEghAPhAQAThLAHgkQBMl9AskrIAyAAQhtIigkFKQANgCASgMQASgMAOgCQAvgFBQABQAoAABhAEQBgAEBoANQD/AgEdBAQA+ALCAASQBsATA7AeQCXAfDUA/IFnBsQAsASBWAlQBOAfBDAKQAWghAOg0IAVhfQAQhMAijWQAfjBAZhlQAQiKAbiZIA0kaIAlAAQgbBugiEHQggD3ggBuQgMBSgSCWQgQB+gXBLQABAugJAkQgIAigWAjIAAA4QgyBIiCAPQhgALidgTQg4CNgyDmQgUAfgJAWQgNAfgCAhQgrBGglB9QgtCagTAtQgeBDg4BsQhGCFgUAmQgPAgg7CXQgrBwguBAQgTBGgECAQgEB+gRA/QAMC6ArEaIBNHcQAhEHgXEyIgbgCIAEhPQAIkCgzlXIhloxIgDhoQgEg5gSgeQAAgWAOimQAJhxgLhRQBGiICCkpQB/kfBLiOQAehmAyiPIBWjxQBlkkAijeQgmgchGgSQgUgFhugWQh3gojFgyQkbhIgpgMQgsgFlug9Qj6gqiogEQhCDygWFHQgLCegIG5QgBBQAECoQAECkgCBSQgGEZhQCxQAGAigQBZQgOBPASAtQAQgBATgEIAGAYQgeAHgSANIgcABQgDgIgGgJQhIAHh1A6QiNBGg1AQIiVB6QhZBKg9AuQhqgVgzgGQhZgKgrAqQgrAGgzgSQg0gTgdADQgWADgdAOIgzAZQhDAeg/gVIgmARQhTBChHCEQgpBMhKCeQgmAxgQAaQgcAsgNAsQgQAWgjApQgeAmgNAhQkPETmQCNQgtAVgkAYQhgAShQA8Qh2AliKA/QgrATjEBfIhrAcQhBAQgdAXQgwAKhJAcQhPAfgmAKgAnENhQglAXgrAxQBGAVBVgiQA2gXBJg2QgwgJguAJQgRgGgSAAQgjAAgmAYgAgZMRQg3AZgfAJQgQAfg3AbQhAAggQARQAMAPAZAAQAPAAAkgEQAIgIALgIQBPgJA+gvQAbgXBEhJIgRgBQguAAgrARgEAnrgVBQgLAhAFAWQBYAUA6ACQBMACBDgYQgsgnhGgbQg5gWhWgSQgQAUgKAfgAJM7sQhNANgQArQBRBDAJAGQA4AjBDgCQAOgcAEguQACgegBg6QgngFgiAAQgjAAgfAFg");
	this.shape_40.setTransform(36,-35.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#00A23D").s().p("AOoJzQhWglgsgSIlnhsQjUg/iXgfQg7gehqgTQiAgSg+gLQkdhAj/ggQhogNhggEQhhgEgoAAQhQgBgvAFQgOACgSAMQgSAMgNACQAklIBtoiMAnkAAAIg0EaQgbCZgQCKQgZBjgfDBQgiDWgQBMIgVBfQgOA0gWAhQhDgKhOgfg");
	this.shape_41.setTransform(216.3,-236.6);

	this.addChild(this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-281.9,-303.5,636,608.1);


(lib.sec4 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(4,0,0,4).p("AF4gMIrvAZ");
	this.shape.setTransform(-267.8,253.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(4,0,0,4).p("AF+hBIgHAAQizAJi4AZQk/Aog4BA");
	this.shape_1.setTransform(-269,161.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(4,0,0,4).p("AF9AYIgHABQjHAKivgGQlGgJgjg9");
	this.shape_2.setTransform(-268.9,-69.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(4,0,0,4).p("AFwAEIgNgBQizgIiigDQkhgFhYAX");
	this.shape_3.setTransform(-267,-160.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(4,0,0,4).p("AhyAYQAQgFBLgMQA3gIAagQQg6AFggAFQg6AHgYAYg");
	this.shape_4.setTransform(109.8,123.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFD5C9").s().p("AgEAlQlIgKgjg8IARAAIAAgFILOBFIAAABQiAAHh3AAQhBAAg8gCg");
	this.shape_5.setTransform(-268.3,-70);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgGADIgCgFIASACIAAADg");
	this.shape_6.setTransform(-304.5,-73.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAKgCIAAAFIgSAAQAHgDALgCg");
	this.shape_7.setTransform(-304.5,-159.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFD5C9").s().p("AAHgjQC4gYCzgJIAAAAIriCJQA3g/FAgpg");
	this.shape_8.setTransform(-268.5,162.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AlmAHQBYgXEhAFQCiACCzAJIAAABIrOAMg");
	this.shape_9.setTransform(-267.5,-160.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFD5C9").s().p("AlmGLIAAtPILOgNIAAOjg");
	this.shape_10.setTransform(-267.5,-113.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFD5C9").s().p("AlwljILiiMIAAPEIriAag");
	this.shape_11.setTransform(-268.5,204.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgFAAIALAAIgLAAg");
	this.shape_12.setTransform(-230.8,-160.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgCAAIAFAAIgFAAg");
	this.shape_13.setTransform(-231.1,155.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AzNBhIAAgWIANgBIgNgBIAAgSQFvgHLLAGQJjgFF6g7QBZgPBqgZQA8gOB/ghIAGAUQhTAVhCAhQgRgBgeAFQgdAFgTgDQhcAeiaATQizAThWAKQgZADhHAPQg5AMgiAAQj3gDnzAGQloAEjsAAIivgBg");
	this.shape_14.setTransform(-108.4,-167.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AmaBBIAAgYIAHgBIgHAAIAAgRICQAAQEzg1FvgjIADAdQhcAIk5AzQjyArijAAIgLgBg");
	this.shape_15.setTransform(-190.3,151.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AsdDcIAAgrQBIgCCWADQB/gEA7ghIBCAAQCAg4FqhiQFChZCZhUQA/gJBWgbIAHAYQi5BfluBpQmuB9iMA4QiOAXhMAIQhRAJhOAAQgxAAgwgDg");
	this.shape_16.setTransform(-151.6,232.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("Au4CSIAGgBIgGAAIAAgXQHvABEKgbQGIgoDuhzQBqgZCSgdIEAgzIAGAdQheASicAmQi0ArhCAOQj0BzmLAqQkTAdnvAAg");
	this.shape_17.setTransform(-136.1,-81.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFD5C9").s().p("A+6JZIAAt1QEGACH9gGQH1gGD4ADQAhABA5gNQBHgPAZgDQBWgKCzgTQCZgTBbgfQAUACAcgEQAegGASACQBBghBTgWQBBgRBfgRICmgbQCfgzA6gMQCCgcBcAZQBjAaB+A8QAeAPClBXQAMAHBWAxQA8AiAdAgIBTBIQAsAwgBAyQgUABgggOQgjgQgVgBQhBgGiYAWQiWAWhOgIQgXgWgeglIgxg/QgVgIgfg0QgagsgqABQgHAhAfAjQARAUAlAhQAPARAhArQAdAmATASIgEAWQgBAJAFAMQBpAlA4AxQBHBAAOBnQgPAYgtAYQgzAbgPAQQALAyAwAZQAgAQBHANQAOgBAbgbQAVgUAQARQAJBOhrAGQgrACgsgLQgsgMgXgUQgJgUgxhPQgmg8gMgwQgGgHgWgKQgUgJgGgKQhHgGh5ghQh9ghhJgHQgdgNhXg+QhFgvg+gKQBhBdAsAhQBXBABgAVQgeAUgIBQQgJBWgYAaQAIAIgEAOQgDAIgHANQABANAaASQAVAQgHAOQingghQgTQiIgihPgxQgJgbgkgVQgxgdgIgJIhagJQg1gGgrAEQhzAbi7AmIkAAyQiSAdhpAaQjvB0mKAoQkAAanWAAIgjAAg");
	this.shape_18.setTransform(-33.5,-129.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AvSDZQD1gWESgQIAxgSQAegLASgIQCUgVDjgpQEtg2BIgLQB5giCwhZQDMhpBSgfIAKAaQgtARheAyQhWAtg3ATQhdBKiZArQhwAii9AdIk5AyQivAghuAvQhlAKinADQi3AEhOAGg");
	this.shape_19.setTransform(-51.5,122.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AnPBDIgHgYIBngjQA+gUApgLQAOgDBYgGQBEgEAigXQB5gPCVAUQA+AIDHAmIgEAXQgfgFhAgDQhEgDgegEIhmgPQg3gIgpAAQgcAAgqAKQgxANgRAAQh3AHg7AGQhoAMhCAqg");
	this.shape_20.setTransform(-25.3,205.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AJ7K/QgCgngJgHQgCi0gtl9QgsltABjXQi6A/iIBCQivBUhsBhQgNgIg5AAQg8ABgagLQgfAAhNAHQhIAGgqgBQgwAAhFgUIh1gjIgMgCIAEgZQCSAcBdAGQCFAKB0gXIAiAGQAUADAMAEQAKgDAngVQAdgPAeACQA8gzBngvQA8gcB8gyQBugvA/gqQBXg5AuhJQhVAAh9BJQhHApgZAMQg3AagvAGQAeguBWgrQBlgxAdgaQB8gPBag2IAUAUQgBA4gtAzQgIAKhOBIQAACVAcDeIAsFqQAFAwAICYQAHB7AKBJQADAVASAzQAJAsgkARIgDAAQgUAAgCghg");
	this.shape_21.setTransform(91,231.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("EgGoAi8QAZgNA0gYQAtgWAZgSQCdgPCBh+IBphuQA/hDAxgjQgIgSgBgYQgBglgCgMQAjgbAegJQApgNAnASQAig0gzgZQgxgYgxAcQhLApgzAsQh2ASh+BWIhmBJQg9ArgwAYQgcAChJAUQg9AQgwgCQhTAOifAxQiaAwhOALQAAgxA2gPIAygJQAegFAQgHQCLhQAJgEQBZgsBXgMQAUAHAegCIA0gFQALgDAmgYQAcgSAfACQAqgoAKgLQAbgfALghQgFgigNgPQgQgUggACQgNAKgGAwQgHAsgVAHQg8gDg/gfQhDglgngOQgkAEhAANQhJAQgaAEQh1AThQgmQgrgCg2AFIhZAJQgWAHgWAIIgKgaQA3gWA6gPQCUgIBdAaQBBACBegVQBkgXA2gBQBwhGB6hqQgDhDgOhAIgahqQgzhdgMiCQgJhrASiWQAEgfANgzQANg3AEgWQANhXgvg7QgugOghgnQgbgggUg2QhmgFgphhQgSgpgZifQgMgHgVAOQgXAPgWgGQgegNgNgIQgZgOgKgSQiIgHiqgmQhkgXi8g2Qgggcg0ghQg9gjgegTQjHgBjmAuIgHgdQC9glBzgcQAsgDA1AFIBZAKQAJAJAwAcQAkAVAJAcQBPAxCJAhQBQAUCmAfQAIgOgWgPQgagSgBgOQAIgNACgHQAFgOgJgIQAZgaAIhWQAIhQAegVQhggVhWhAQgsgghihgQA/ALBEAxQBXA+AdAMQBJAIB+AhQB4AgBHAGQAGALAUAJQAWAKAGAGQAMAxAmA7QAxBPAKAUQAXAUArAMQAtAMAqgDQBsgGgKhNQgQgSgUAVQgcAbgOAAQhGgMghgRQgwgZgLgxQAPgQAzgbQAtgYAPgZQgOhmhGhAQg4gzhqgmQgFgLACgJIADgWQgTgTgdglQghgsgPgQQglgigRgTQgegjAGgiQAqAAAaAsQAfA0AVAIIAxA+QAfAmAWAVQBPAICWgVQCXgWBBAFQAVACAjAPQAgAOAUgBQACgxgtgwIhThJQgdggg7ghQhXgxgLgIQilhXgfgOQh+g9hjgaQhcgYiBAbQg7AMieA0IinAbQheAQhCASIgFgUQDNg3BygXIC/guQBvgbBBAAQCCABCjBRICBBCQBIAlA1AQQAFg/AFgkQAIg0ALglQgUAEgWgHQgIgCghgOQhHgcg9hBQhDhFgGg/QgCgfANhBQAThLAHgjQAfijAfi+QAgjAAUiJIAvAAQgwEDgeCyQgoD2gTDBQANgBARgLQARgLAMgBQA0gGBLABIB+AFQBmAECVAXIEBAoQE0AsGJB1QDgBDGfCJQAoAcAeALQAqARAygCQBCjsBBmsQBQoSAeiQIAkAAQgfCBgWDBIglE9QgDARgNAfQgMAggDARQgKA+gQCFQgPCAgNBCIgWBzQgQBQgKA3Qg0BIh6AQQheAMiSgVQg2CLgwDoQgOAgibGnQhmERhaCeQgXBUgpBbQgZA2g3BpQABAfgNAMQgHA1gEB+QgCBlgRBCQAQA5ABBaQAACHABAQIAEAjIgbAEQgPhtgKhkQACgOgJgMQgLgNAAgKQABgbAMikQAJh2gKhKQAag9BHiXQA+iGAhhPQAag+BEiZQA9iJAghOQAZhAAqiPQApiMAdhJQAmhgAdh1IAziyQAfhtAIhaQhug4jXg3QkOhFhIgaQiSgljXgnIl0hAQgpADhOgPQhJgOgoAHQgNBKggCPQgaCBgIBiQBsBHAZASQBIA0AwAwQA1CDAEEyQACDCACAtQAGCBAVBXQgcA5ggAhQgnAqg3AOQAAAPAFAjQADAfgCAWQgmAjhMAaQgMAfAKBcQAHBRgYAbQgSASgyABIgJgEIAAAEQgeAAgegHQgkBmgDCQQgDCNAdB8QAFANAVAKQAXAKAFAKQANAnAABGQgBBLAMAvQC/g7AYgGQCVgnBhAGQBBAFApAdQAtAgALA4QAAASgNAdQgMAaACAYQAIAPAdgEQAggFAIAHQBDBghbBYQgXAVhAAvQg3AogUAYQgGAFAAAWQABAXgHAFQgkAwg9B8Qg6B1grAzIgjASQgVAKgUACIgVgUQCNhWA6i5QgcANhgBPQhUBChCASQhSADhKAlQggAQhZA7Qg7ANgfASQAUg1BbgugApneRQg6AJgYAYQAQgFBLgMQA5gKAbgQQg8AFghAFgAjVboQgKAYASAIQAOgQAFgnIgBAAQgSAAgIAXgAhIXHIgSAFQgaBFgNApQgdBfgKBWQAPgEAYgOQAZgOAOgEQAIgXALgsIARhDQgGgFgXAFQgWAEgJgKQAGgNAZgEIApgHQAIgLAJgcQAHgdAIgLIAOAAQAAAOgHAWQgJAVAAAQQAMAAAkgFQAegEAWADQALgQAHghIAMg3Ig5ADQABgLgMgKIBEAAIAOgdQAIgQACgQQgqgJg5AGQgnAEg2ANQgoAEg3ALQg9AMgQAKIgfASQghAVgJALIgVAWIgDgBQhAArggAXQg4AogWAuQAzAKBNgjQBQgkAsAGQAIgNAFgeQAHggAFgMQAYgKAIgDQATgGAXgCQAagDARgKQAEgCAGAAQAHAAAKADgAEGbjQAzgLAKgrIgPgBQg0AAAGA3gAmLa2QAWgBAAgVQgHgIgMAEQgRAFgFgBQgCAXAVgBgAAhYyQghAHgSAAQggArgEBJQA5gQBPgoIBegxQA6ggAjgQQAAgNANgiQAKgbgFgdQgYgIguAHQg4AIgTgBQgKAggPBEQgPA6gaAZQgBgMAIgSQAHgRgCgOIgLgBQgTAAgZAGgAihXcIgfAIIgSA0QgKAhgJASQAVAFANAcQAQAhALAHQADghASg8QASg7ADgkIgHgBQgOAAgOAFgACzVvQgUAMABAgQARAKApgGQApgHAPAJQAEgRgRgRQgRgPgYgGQgJgCgIAAQgOAAgKAHgAkaJTQAMAJAMgCQAAgIAJgEIAPgGQgChKgCgZQgEgrgKgpQguAAgSACQghAEgSAMQAFAnAWAyQAbA9AHAVIAIgBQAJAAAHAGgAkyEfQhvAMhAARQACAXAVANQAMAHAZAMQBKgDAkgFQA7gHAkgQQAjAJAagQQAfgSgIgqIiuAOgArRlfQANEFAIA4QAZC/BKBKQBlAWAyAIQESgOCMhHQAGgMARgQQARgRAGgKQAJi5gPi7QgNjCgniiQg8hFiPAGQiuAWhWgBQADAaA1AaQA7AcALAXQAJAhAPAyIAYBRQAKAiA8AwQA4AsABAnQACAyg2AmQgkAZhLAbQhlAChIg9QgZgWgfgmIg1hAQgLgpgGgUQgKgfgeAAIgJABgAueiqIgpAUQAVAUBCAgQA7AdAWAcQAeADAMgGQARgIgFgZQg5AAgjgrQgkg4gWgXQgIARgXAMgAt5mQQAPAyAcBwQAgBaA5AKQABgwgOhGQgPhOgCgjQgMgQglgJQgZgGgTAAIgJAAgAvskuQgQAzALAuQA/gTAzABQgNhMgFgQQgOgvgigNQgcAcgPAtgAnCkcQAFAeApAJQAkAIAlgLQgfhAglAAQgZAAgaAcgAXKvmQgMAjAGAWQBRARA6ACQBMADA9gWQglgohJgcQgcgLhsgeQgQAYgIAcgAl+2TQhJAOgUAoQA2A3AiAVQA2AiA/AAQAMgdAEguQADgjgBg2QgjgFggAAQghAAgeAFg");
	this.shape_22.setTransform(168.1,-70.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFD5C9").s().p("AgwgKQAPguAcgbQAfANAPAvQAFAQANBKQgzgBg+ATQgKgvAQgwg");
	this.shape_23.setTransform(72.5,-100.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFD5C9").s().p("AA4BOQgWgcg5gdQhCgegVgUIApgUQAYgMAHgRQAWAXAiA3QAkAqA4AAQAFAZgRAIQgIAEgSAAIgQgBg");
	this.shape_24.setTransform(82.3,-83);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFD5C9").s().p("AgWAfQgchvgPgxQAWgCAfAIQAjAJAMAPQACAjAPBNQAOBFgBAwQg5gKgehZg");
	this.shape_25.setTransform(85.6,-97.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgfAZIAVgqQAbgyAoAFQgiBfhOAfQAKgMAOgbg");
	this.shape_26.setTransform(108.2,176.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFD5C9").s().p("AgDgKQAegFA8gFQgbAQg5AIQhJAMgQAFQAYgWA7gJg");
	this.shape_27.setTransform(106.9,123.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFD5C9").s().p("AgTgHQAGABAPgFQALgEAIAIQgBATgUABIgCAAQgTAAACgUg");
	this.shape_28.setTransform(128.5,99.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFD5C9").s().p("AgMAfQgpgJgFgcQBBhFA0BnQgVAHgVAAQgQAAgNgEg");
	this.shape_29.setTransform(128.9,-98.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#DCD4CF").s().p("AiJBKQAVgtA5gnQAfgWA/gsIACACQglApAlgDQgCAJAAAGQAOgHAKgMQArgKAkgQQgFAMgHAhQgGAcgHANQgtgHhNAkQg9AcgrAAQgNAAgLgDg");
	this.shape_30.setTransform(132.5,87);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#8E0000").s().p("AAHgSQAGAGgBALIgFATIgGABQgdAAAjglg");
	this.shape_31.setTransform(135.5,81.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgIgEQAHgBANgDQgKALgMAGQgBgGADgHg");
	this.shape_32.setTransform(137.2,83.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#8E0000").s().p("Ai3A0QABgLgGgGIAWgXQAIgKAhgTIAggSQAPgLA9gMQA1gKAogEIgQAEQgCAIAAATQAAAUACAIQA1gLBBgBQAMAKgBALIg7AEQgvAEgdAGQgSgFgJAFQgQAJgYADQgYADgSAGQgJACgYALQAHgPALgIQBZgEAXhIQhgAShYAuQgGAlgSAXQgPADgHABIAFgVg");
	this.shape_33.setTransform(155.2,75.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#8E0000").s().p("AgqBVIAQj+IAJAAIANAGIgRAAIAGAPQAHAYADAsIgDACQAAACgEAHIgFAAIACAJQAEAUAHARQAABAgJAwQgFAaAEAAIAVACQAPABAAgHQAAgLgJhZQALAPAMAJQAJA/gCAVQgDATgOAQQgPAPgOAAIgCABQgpAAAEhVg");
	this.shape_34.setTransform(142.4,11.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#8E0000").s().p("AgDACIAAgDIAHADg");
	this.shape_35.setTransform(140.2,-5.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#8E0000").s().p("AgDgMIgCgJIAFgBQgDAFABAEIADAHIAFAOIAAAPQgGgRgDgSg");
	this.shape_36.setTransform(141.3,6.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#8E0000").s().p("AgBAAQgBgCACgFIAAAAIADAPg");
	this.shape_37.setTransform(141.1,5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#8E0000").s().p("AAAAFIgDgOIAFAHIABADIAAAJQgDgCAAgDg");
	this.shape_38.setTransform(141.5,5.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#8E0000").s().p("AgCgCIADgBIACAHg");
	this.shape_39.setTransform(141.4,4.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#8E0000").s().p("AgBgGQABADACACIAAAIg");
	this.shape_40.setTransform(141.7,6.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#8E0000").s().p("AADAIIgCgIIgDABIAAAAQACgFAAgCIADgCIABARg");
	this.shape_41.setTransform(141.5,4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#8E0000").s().p("AgCACIgEgMIAAgDIALANIACAPg");
	this.shape_42.setTransform(142.6,6.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#8E0000").s().p("AgFgZIgGgPIAPAAIAAABIAIBMIgJAEQgDgqgFgYg");
	this.shape_43.setTransform(141.4,-1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#8E0000").s().p("AAAACIAAgHIABALg");
	this.shape_44.setTransform(142,6.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#8B8B8B").s().p("AASBdQgKgJgMAEQgHgVgag9QgXgwgFgnQASgMAhgEQAQgCAuAAQAKApAEArQACAXACBKIgPAGQgJAEAAAIIgFAAQgJAAgKgHg");
	this.shape_45.setTransform(137.9,-20.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#8E0000").s().p("AAEAmIgEAAIgIhMIAQBNg");
	this.shape_46.setTransform(142.8,-1.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#8E0000").s().p("AAEBGIgVgCQgEAAAFgaQAJguABhCQAGAVAKAPQAKBXAAALQAAAHgMAAIgEgBg");
	this.shape_47.setTransform(142.7,15.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#8E0000").s().p("AgIgJIAAgPQAHAWAJAPIABAMQgJgPgIgTg");
	this.shape_48.setTransform(142.8,9.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#8E0000").s().p("AgHgNIAAgKIADAEQAEARAHAOIABAMQgJgRgGgUg");
	this.shape_49.setTransform(142.8,8.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#006B33").s().p("AgXAyQghgVg2g1QAUgoBJgOQA5gKBGAKQACA2gDAhQgEAugNAdIgCAAQg+AAgzgig");
	this.shape_50.setTransform(131.6,-205.8);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#8E0000").s().p("AgEAEIgBgSIAHgDIAEAkg");
	this.shape_51.setTransform(142.5,4.6);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#8E0000").s().p("AgFAJIgFgkIAGAAIAEABIALA2g");
	this.shape_52.setTransform(143.8,5.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#8E0000").s().p("AgFgPIAJANIACASQgGgQgFgPg");
	this.shape_53.setTransform(142.9,8.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#8E0000").s().p("AgJgGIgCgNQALATAKAMIACAIQgMgNgJgNg");
	this.shape_54.setTransform(144.7,12);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AApBvQgSgbgWgaQgBgIgDgDIgUgvIgDAAIgegDIgGgHQgBgLgGgNIgEACIgkgoIgMg5IAOAEIAAABQAiAvAIASIAGAKIADAIIAGADIAVAKQANAIAEgFQADgDgEgIQgFgNgZgdIAAgBIglgiQAyAdAjBMQAGAIASARQASAQAGALQAJACAPALQAOAJAKACQAIANANANQgXgUghgMIgfgHIgBAKIAGAAIAoAwIgCARQgTgMgSgHg");
	this.shape_55.setTransform(155.9,15.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#8E0000").s().p("AgHgBIgCgQIAQASIADARg");
	this.shape_56.setTransform(144.2,8.3);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFD5C9").s().p("EgKDAopIAAgGIADgBQAkgQgJgsQgSgzgDgWQgKhIgHh7QgIiZgFgvIgslsQgcjfAAiVQBOhIAIgJQAtg0ABg4QAUgCAWgKIAkgSQArgzA6h1QA9h8AlgwQAGgFAAgXQgBgWAGgFQAUgYA4goQA/gvAXgVQBbhYhChgQgJgHggAFQgcAEgJgPQgCgYAMgaQANgdABgSQgMg4gsggQgqgdhBgFQhhgGiXAnQgYAGi+A7QgMgvAAhLQAAhGgMgnQgGgKgXgKQgVgKgEgLQgeh8ADiNQADiQAkhmQAeAHAeAAIgQEAQgEBWArgCQAQAAAPgPQAOgQADgTQACgVgJg/IABABQAVAQAJgGQACgCABgDIgBAJIADAAIAGARIgCABIAEAEIADAEIADgCQADgBADABQANAFAAA1QAAAogHANQgEAIAAAJQgCAPADAjQACAiADALQACAHAGAAQANAAAAg+IABgWQADgcAAgyIABgiIACAGIAKgDIgCgHQAWAZASAcQASAHATAMIAAANIgFAAIABAHIgDAFQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBAAgBAAQgFABgBAKIAFABIAAAAQADAOACA4QACBMgKAbQgCAHAAAIQAAARASAIQALAEAFgFQAFgEgDgIQgGgPADiHIAAgBIgGgqIAdALIAGACIADgTIBWBmIgFAAQAAAKAKBtIAKABIABgCQAQgzAAg8IgBgOQAbALAYgQQgTgsg2gpIhZhFIgBAAIgIgJQgNgNgIgNQgKgCgOgJQgPgLgJgCQgGgLgSgRQgSgQgGgLQglhMgygcIgUgTIgHAGIAAABIgOgEIgShPIAAgBIgNgGQAygBATgSQAXgbgHhRQgJhcALgfQBNgaAlgjQACgWgDgfQgFgjAAgPQA3gOApgqQAgghAcg5QgVhXgGiDQgCgtgCjCQgEkyg3iDQgvgwhJg0QgZgShrhHQAHhiAaiBQAgiPANhKQAogHBJAOQBQAPApgDIF0BAQDVAnCSAlQBIAaEOBFQDXA3BuA4QgIBagfBtIgzCyQgcB1gmBgQgdBJgqCMQgqCPgZBAQggBQg9CJQhECZgaA+QggBPg/CGQhGCXgbA9QALBKgKB2QgMCkgBAZQAAAKALANQAJAMgCAOQAKBkAPBtQAZCzA2FfQAqE4gCEBIg0GbQgiDqguCXQAAA/gbCeQgWCBANBGQACAGALAAIAAAGgAkinkIAVAlQANAXABALQgSAvgOBGIgWB+QAlA5ggBSQgIAXgVAsQgQApgCAfQAngZAdg6IAuhoQgUgyAFhBQADggARhUQAPhHgBgoQgBg7gegrIgGAAQg0AAARAng");
	this.shape_57.setTransform(221.2,45.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FF0000").s().p("AAdAuIgUgLIgGgDIgDgHIgEgLQgJgQghgvIASARQATAbAJAQIAIASIAYAMQAVANgTgbIgWgbIgkgjIgFgIIAKAFIAiAiIAAABQAZAbAGANQADAIgDADQAAABgBAAQAAAAgBABQAAAAgBAAQgBAAAAAAQgFAAgIgEg");
	this.shape_58.setTransform(149.9,8.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FF0000").s().p("AgIgHIAAgBIAIADIAJANg");
	this.shape_59.setTransform(146,4.1);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#8E0000").s().p("AgJgFIgCgUIARAWIAGAdQgMgMgJgTg");
	this.shape_60.setTransform(144.5,10.6);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FF0000").s().p("AgCAAIACgBIAEADg");
	this.shape_61.setTransform(145.5,3.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FF0000").s().p("AABAEIgGgFIADgEIAIALg");
	this.shape_62.setTransform(146.1,3.2);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#8E0000").s().p("AgJgFIgBgLQAIAPAMALIABAIQgLgKgJgNg");
	this.shape_63.setTransform(144.9,13);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FF0000").s().p("AgOAAIgBgBIgCgHIAGAEQAcAWgFgaIAGAGIgBAEIAAABQgBADgCACQgDABgDAAQgIAAgOgJg");
	this.shape_64.setTransform(147.7,15);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FF0000").s().p("AgIAAIgFgCIgCgIIAKAIQALAIAFAAIAAgCIgDgNIAHAIQADAMgHAAQgHAAgMgLg");
	this.shape_65.setTransform(147.4,14.4);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FF0000").s().p("AgEgEIAEACIAEAGg");
	this.shape_66.setTransform(146.8,4.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FF0000").s().p("AAZAlIgYgNIgIgRQgJgQgTgbIAQAPIgMgTIAkAkIAWAbQANASgGAAQgDAAgGgEgAAfAnIABgCIACgBIgGgDIADAGgAgCAFIADALQACAEADACQALAFAKAGIABAAQgIgNgTgVIgUgUQALAPAGALg");
	this.shape_67.setTransform(150.6,8.7);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FF0000").s().p("AAAAOIgKgIIgFgdIAcAeIADAPIAAACQgFAAgLgKg");
	this.shape_68.setTransform(146.9,12.6);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FF0000").s().p("AgBAAIgLgOIAEACIAIAKIANARg");
	this.shape_69.setTransform(147.2,5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FF0000").s().p("AAAADIgIgLIASARg");
	this.shape_70.setTransform(146.8,3.4);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FF0000").s().p("AgNgGIgDgRIAhAmIgFADIADAGg");
	this.shape_71.setTransform(146.7,10.9);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FF0000").s().p("AgBAAIgCgEIADgDIAFAPg");
	this.shape_72.setTransform(148.5,13.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#DCD4CF").s().p("AgLgDQAJgYARABQgFAlgMAQQgSgHAJgXg");
	this.shape_73.setTransform(147.8,106.3);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FF0000").s().p("AAAAGIgEgPIAEgCQAFALAAAMg");
	this.shape_74.setTransform(149,13.5);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FF0000").s().p("AAAACIAAgDIABADg");
	this.shape_75.setTransform(149.5,16.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FF0000").s().p("AAXAbQgKgFgLgFQgCgCgBgEIgFgLQgGgLgLgPIAWATQARAWAIAMg");
	this.shape_76.setTransform(151,9.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFD5C9").s().p("AgCACIABgEIAEAFg");
	this.shape_77.setTransform(149.8,15.1);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FF0000").s().p("AgFABIAAgDIAGABIAFAEg");
	this.shape_78.setTransform(150.1,15.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FF0000").s().p("AgBBuQgDgLgDgiQgCgjACgPQAAgJAEgGQAEgNAAgoQABg1gLgGQgEAAgCABIgDACIgEgFIAPgCQAOAJAAA2QAAAogHAOQgFAMAEAzQABAgABAMQADAIADgIQAGgSAAgkIACgdQABgWABguQgBggADgLIADAJIgBAiQAAAwgCAcIgBAVQgBA/gNAAQgEAAgBgHg");
	this.shape_79.setTransform(152.8,30);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#DCD4CF").s().p("AgQA2QgOgcgUgFQAIgSALgfIASg1IAdgIQASgFARABQgDAlgSA4QgSA8gEAiQgIgHgQghg");
	this.shape_80.setTransform(150.2,88.1);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FF0000").s().p("AAAgXQgHgEgJAHIgGgRIAQACIAYAbIAFAMQgEAGAAAcQgBg1gSgIg");
	this.shape_81.setTransform(152,20.2);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FF0000").s().p("AgGABIgCgDIALABIAGAEg");
	this.shape_82.setTransform(150.4,16.2);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FF0000").s().p("AgLgMIAMABIALAYg");
	this.shape_83.setTransform(152.6,17.9);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FF0000").s().p("AADBIQgDgzAFgMQAIgOAAgpQAAg2gNgIIgPACIgCgEQAJgHAIAEQASAJAAA6QAAAqgHAOQgEAGgBAJQgBAOADAhIADAhIgDALQgDgMgCggg");
	this.shape_84.setTransform(152.1,29.2);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FF0000").s().p("AAKAKIgKgYIgNgBIgGgFIAWACIARAng");
	this.shape_85.setTransform(152.8,18.1);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FF0000").s().p("AgBAAIABgBIACABQAAAAAAAAQgBAAAAABQgBAAAAABQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAgBgBAAQAAAAAAAAg");
	this.shape_86.setTransform(153.2,40.9);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FF0000").s().p("AAAAEIgBABIABgJQABAGABADIgCgBg");
	this.shape_87.setTransform(153.2,40.3);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FF0000").s().p("AgDAmQgCghABgMQAAgJAEgGQAEgOABgiQAAAzgCAYIgBAXQAAAWgCAVg");
	this.shape_88.setTransform(153.4,32.6);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FF0000").s().p("AgGBZQAEgUAAgWIABgXQABgYAAgzIAAgKQAAggAEgGIADAGIAAAAQgDAKAAAgQAAAwgBAUIgCAeQAAAkgEARQgCgCgBgJg");
	this.shape_89.setTransform(154,30.7);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FF0000").s().p("AgCgCIAFACIgCAAIgBADIgCgFg");
	this.shape_90.setTransform(153.7,12.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FF0000").s().p("AgEgGIAIAKQgCAAgCADg");
	this.shape_91.setTransform(154.4,19.9);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FF0000").s().p("AgCAAQACgDABAAIACAEQgCgBgBAEg");
	this.shape_92.setTransform(154.7,20.8);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FF0000").s().p("AgBAAIAAgBQABgFAAACIACADIgCABIgBgBIABAGIAAABg");
	this.shape_93.setTransform(155,21.4);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#666666").s().p("AiYAdQgUgNgCgVQBAgRBugLICtgOQAIApgfARQgbAPgigIQglAQg4AHQgkAEhKADQgagMgMgHg");
	this.shape_94.setTransform(137.4,-38.6);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FF0000").s().p("AgBgCIABABIACgBIgCAFIgBgFg");
	this.shape_95.setTransform(155,21.6);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FF0000").s().p("AgDgEIgCgFIAIAJIADAJIgEABQgCgMgDgCg");
	this.shape_96.setTransform(155.5,21.4);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FF0000").s().p("AAUAXIAAAAIgSgnIgVgDIgGgFIAcACIADABIAUAuQgDgDgDABg");
	this.shape_97.setTransform(152.8,18);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FF0000").s().p("AgEgEIABAAQACgBABADIAFAHg");
	this.shape_98.setTransform(155.4,20.9);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FF0000").s().p("AgCAAIABgFIAEAKIgDABg");
	this.shape_99.setTransform(155.4,21.9);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#DCD4CF").s().p("AgQhZIAPAFQAHAJAWgEQAXgEAGAFIgSBDQgLApgHAXQgPAEgWAPQgYAOgQAEQAKhWAehdg");
	this.shape_100.setTransform(156.8,97.6);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#DCD4CF").s().p("Ag6A3QANgpAahEIASgFIASAJQATAIAXABQgIAKgHAdQgJAbgIAKIgnAHQgZAFgGANg");
	this.shape_101.setTransform(161,83);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#8E0000").s().p("AhQADQBXgvBigSQgYBJhZAEQgLAHgGAPQgkAQgrAKQATgXAFglg");
	this.shape_102.setTransform(149,76.5);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FF0000").s().p("AgCACIABgEIAEAEg");
	this.shape_103.setTransform(159.7,22.1);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FF0000").s().p("AA8A/IgUgxQgQgigkgWQgYgNgagFIgFgGIAuAOQAvAWASAqIAYA3g");
	this.shape_104.setTransform(166.3,28.6);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FF0000").s().p("AAABqQgRgIAAgRQAAgHACgIQAKgbgChLQgCg5gDgNIAEAAIABgBQADARACA1QACBBgGAbIgGAaQAAAPANAGQAQAGgFgNQgEgLAAhIIABhFIgGgsIAFACIAGAqIAAABQgDCHAGAOQADAIgFAEQgDADgEAAQgEAAgEgCg");
	this.shape_105.setTransform(163.8,43.3);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FF0000").s().p("AgEAFQABgIADgCQABAAABABQABAAAAAAQABAAAAAAQABABAAAAIgCADQgDgBAAAEIAAgBIAAADIAAABg");
	this.shape_106.setTransform(162.5,31.9);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FF0000").s().p("AAAABQAAgEABADIgBACg");
	this.shape_107.setTransform(162.7,32);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FF0000").s().p("AAAABIAAgBIABABIgBAAg");
	this.shape_108.setTransform(162.8,32.1);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FF0000").s().p("AABBtQgNgGAAgPIAGgaQAGgbgChBQgCg1gDgRIABgDIgBABIgCgEIADgEIACACQAEAHABBHQACBPgIAcQgCAFAAAGQAAAIAHAGQAEADAEAAIAAgBQgFgLAAhEIABhLIgEguIADACIAGAsIgBBFQAABIAEALQAEAJgHAAIgIgCg");
	this.shape_109.setTransform(163.8,42.6);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FF0000").s().p("AgBABIAAgBIABAAIAAAAIACAAIAAAAIAAABg");
	this.shape_110.setTransform(162.7,32.4);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFBE00").s().p("Aj3G0QhKhKgZjBQgIg4gNkDQAlgGAMAkQAHAUALApIA0A+QAfAmAaAWQBHA9BmgCQBIgbAkgZQA2gmgCgwQgBgng4gsQg8gwgJgiIgXhRQgPgygIghQgLgXg8gcQg1gagCgaQBWABCrgWQCPgGA8BFQAnCiAPDCQAPC5gJC7QgGAKgSARQgSAQgGAMQiMBHkQAOQgygIhlgWg");
	this.shape_111.setTransform(132.6,-91.4);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FF0000").s().p("ABABBIgCgBIgXg4QgTgpgvgWIgugPIABgEIAfAHQAgAMAVAUIAJAJIABAAQANAQAIARIAQAmQAKAYAFAHg");
	this.shape_112.setTransform(166.9,28.9);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FF0000").s().p("AAABsQgHgHAAgHQAAgGACgGQAIgbgChPQgBhHgEgIIgCgCIADgFIACARIAAADIABAAIAEAuIgBBLQABBDAEAMIAAABQgDAAgFgDg");
	this.shape_113.setTransform(163.8,42);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FF0000").s().p("AAAgEIABgGIgBAUIAAABg");
	this.shape_114.setTransform(163.6,31.4);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FF0000").s().p("AgBgBIADgBIAAABIgCAEg");
	this.shape_115.setTransform(163.5,30.5);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FF0000").s().p("AgBgFIADADIAAAHIgDABg");
	this.shape_116.setTransform(164,29.5);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FF0000").s().p("AgBAMIAAgDIAAgBIABgUIAAgBIACAbg");
	this.shape_117.setTransform(163.9,31.6);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FF0000").s().p("AAAANIgDgaIADgBIAAAWIADACIABAFg");
	this.shape_118.setTransform(164.2,31.6);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FF0000").s().p("AgBALIABgXIACATIgCgBIACAFIAAACg");
	this.shape_119.setTransform(164.4,31.4);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FF0000").s().p("AgBAHIABgPIACAFIgBAMg");
	this.shape_120.setTransform(164.1,28.2);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FF0000").s().p("AgBgBIAAgBIADABIgBAEg");
	this.shape_121.setTransform(164.2,27.4);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FF0000").s().p("AAAgBIABABIAAACg");
	this.shape_122.setTransform(164.4,32.3);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FF0000").s().p("AgMgBIAAgFIAZAIIAAAFg");
	this.shape_123.setTransform(166,32.9);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FF0000").s().p("AAAAOIgBgTIAAgJIADAEIgCAYg");
	this.shape_124.setTransform(164.5,30.7);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FF0000").s().p("AgBAFIABgMIACAFIAAALg");
	this.shape_125.setTransform(164.6,28.6);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FF0000").s().p("AgBAAIABgEIACAEIgBAFg");
	this.shape_126.setTransform(164.7,27.7);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FF0000").s().p("AgBgBIADAAIAAADg");
	this.shape_127.setTransform(164.7,27.5);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#DCD4CF").s().p("AAEAhQgbgbgQgHQgOgJgVgCIgVAAQA3gNAngEQA4gGApAJQgCAQgIAOIgNAdIhFAAg");
	this.shape_128.setTransform(172.6,69.8);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FF0000").s().p("AgOAIIACgZIAbAVIgBgBIgDAPg");
	this.shape_129.setTransform(166.2,31.3);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FF0000").s().p("AAXAkIABgEIgFgBIgegnIAAgFIgKgBIAAAAIgngvQAZAFAYANQAlAWAPAiIAVAxQgOgHgZgTg");
	this.shape_130.setTransform(166.2,28.7);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FF0000").s().p("AAKAJIgbgJIgBgFIAZAIIAAABIABgBIAEACIAAgEIACgBIgBAAIACgLIAEAFIgDASg");
	this.shape_131.setTransform(166.5,33.3);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FF0000").s().p("AgNgDIAAgNIAbAhg");
	this.shape_132.setTransform(166.3,30);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FF0000").s().p("AgBAAIADgBIgBADg");
	this.shape_133.setTransform(167.6,33.6);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FF0000").s().p("AgBACIAAgDIADABIAAAAIgDACg");
	this.shape_134.setTransform(167.6,33.4);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#8E0000").s().p("AgRAFIgVgGQAdgHAugFIACAPQgKADgGAJQgXgBgRgIg");
	this.shape_135.setTransform(164.6,77.2);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FF0000").s().p("AgCAGIACgNIAAABIADADIgCAKg");
	this.shape_136.setTransform(167.7,32.5);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FF0000").s().p("AAAAAIABAAIAAAAg");
	this.shape_137.setTransform(168,31.9);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FF0000").s().p("AANATIgcghIABgFIAeAng");
	this.shape_138.setTransform(166.5,29.8);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FF0000").s().p("AgBgBIAAgBIADACIgBADg");
	this.shape_139.setTransform(168.3,32.3);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#8E0000").s().p("AgcgLIA5gEQgBAMgQAIQgOAJgXACg");
	this.shape_140.setTransform(171.2,77);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#8E0000").s().p("AgHAGQAHgHAHgEIABAKIgKABIgFAAg");
	this.shape_141.setTransform(167.7,78.1);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FF0000").s().p("AgBAAIAAgBIADABIgBACg");
	this.shape_142.setTransform(168.3,32.1);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FF0000").s().p("AAlAGIgFAAIhVhkIABgDQAZATAOAIIAKAWIAPAUQAKALAOgBQAJAIAHAFIABASQAAAtgJAoIgHhcg");
	this.shape_143.setTransform(173.9,42.1);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#000000").s().p("AAeBNQgBgUgHgHQgEgDgLABQgJABgFgEIgVgYQgEgHgKgVIgQgnQgIgTgOgPIBYBEQA2AnATAsQgPAKgPAAQgLAAgKgEg");
	this.shape_144.setTransform(177.2,34.4);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#8E0000").s().p("Ag6ACQAAgRACgJIAQgEIAVAAQATACAOAJQAQAJAdAZQg/ABg0ALQgCgIAAgTg");
	this.shape_145.setTransform(167.1,71.4);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FF0000").s().p("AABAPIgPgSIgKgWIAHAEQAFALAEAGQADAEAJAMQAIAJAJAAIAEAFIgCAAQgNAAgJgLg");
	this.shape_146.setTransform(175,37.6);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FF0000").s().p("AADAMQgJgMgDgDQgFgHgEgKIACABIAJAKQAFAIAJAKIAMAMQgIAAgIgJg");
	this.shape_147.setTransform(175.1,37.5);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#DCD4CF").s().p("AgjgyQATAAAggHQAggHAXACQACAOgHARQgHASAAAMIAGAJQhNAog7AQQAEhHAggrg");
	this.shape_148.setTransform(169.7,93.5);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFD5C9").s().p("AAFAHQgJgKgFgIIATAXg");
	this.shape_149.setTransform(175.3,37.7);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#DCD4CF").s().p("AhpBaQAagYAQg7QAOhCAKgfQATABA3gJQAtgGAYAIQAFAdgKAbQgNAiAAALQgjAQg4AfIheAyg");
	this.shape_150.setTransform(186.3,84.2);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FF0000").s().p("AAOAMQgBgRgIgCQgIABgHgBIgIgHQAGADAKgBQAJgBAFAEQAGAHABARg");
	this.shape_151.setTransform(178.3,40.5);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FF0000").s().p("AAAA7QgJhsAAgKIAFAAIAHBoIgDAMIAEABIAAABIABgBIAEAAIABAAIgBACg");
	this.shape_152.setTransform(177.6,48.9);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FF0000").s().p("AgFg0IAFAAIAGBaIgEAPIgHhpg");
	this.shape_153.setTransform(177.7,48.1);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FF0000").s().p("AAHAHQgBgJgDgCQgBgBgEABIgFAAIgFgFQAHABAJgBQAHACACARg");
	this.shape_154.setTransform(178.4,40.8);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FF0000").s().p("AgBAFIABgKIACALg");
	this.shape_155.setTransform(177.9,54.1);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FF0000").s().p("AAAANIgBgMIACgNIABANIgCAMg");
	this.shape_156.setTransform(178.2,53.3);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FF0000").s().p("AgBAFIACgKIABALg");
	this.shape_157.setTransform(178.4,54.1);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FF0000").s().p("AgHgFIAFAAQAFgBABABQACADABAIQgHgFgHgGg");
	this.shape_158.setTransform(178.4,40.8);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FF0000").s().p("AgGBAIgBgMQAKguAAg1IAAgQIAFADIAAANQAAA9gOAyg");
	this.shape_159.setTransform(179.4,48.3);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FF0000").s().p("AgGAsQAHgoAAgrIgBgUIAGAEIABAQQAAA0gLAvg");
	this.shape_160.setTransform(179.1,47.5);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#DCD4CF").s().p("Ag3ASQAJgUAAgPQAXgCAQgJQAOgKABgMIA6gDIgNA1QgGAhgMAPQgWgCgcAEQglAEgMAAQAAgPAJgVg");
	this.shape_161.setTransform(173.3,80.5);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#DCD4CF").s().p("Ag4AWQgBgeATgMQAQgLAYAGQAYAGAQAPQASAPgEARQgPgJgpAHQgOACgMAAQgTAAgLgGg");
	this.shape_162.setTransform(189.9,70.3);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#000000").s().p("AgvD0QAVguAIgXQAehSgjg5IAWh8QAMhGASgvQgBgLgNgXIgTglQgSgpA5ACQAeArABA7QABAogPBHQgRBUgDAeQgFBBAUAyIguBqQgbA6gnAZQACgfAQgpg");
	this.shape_163.setTransform(192.6,24.5);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FFD5C9").s().p("EgiHAMnIAAubQClACD9gsQE5g1BcgIQBPgHC2gDQCogEBkgKQBuguCwghIE6gxQC9geBugiQCZgtBdhKQA3gSBWguQBegyAtgRQAXgIAVgHIBagJQA1gFAsACQBQAmB1gTQAZgEBKgQQA/gNAlgEQAmAOBEAlQA/AfA7ADQAWgHAGgsQAHgwANgKQAggCAQAUQAMAPAGAiQgLAhgbAfQgKALgqAoQgfgCgdASQgmAYgKADIg0AFQgeACgUgHQhXAMhZAsQgKAEiKBQQgQAHgfAFIgxAJQg3APABAxQBNgLCbgwQCfgxBTgOQAwACA9gQQBJgUAcgCQAwgYA9grIBmhJQB+hWB4gSQAzgsBLgpQAwgcAyAYQAzAZgjA0QgmgSgqANQgdAJgjAbQACAMABAlQAAAYAJASQgxAjhABDIhoBuQiDB+idAPQgZASgtAWQg0AYgZANQhbAugUA1QAegSA8gNQBYg7AhgQQBKglBRgDQBDgSBThCQBjhPAcgNQg6C5iPBWQhaA3h8AOQgcAahlAwQhWAqgfAuQAvgFA3gbQAZgLBIgqQB8hGBWgBQgvBIhWA5QhAAqhuAuQh8Azg8AbQhmAwg+AyQgegBgdAPQgnAVgKACQgNgDgUgEIghgFQh1AWiFgJQhcgHiSgcQjIgmg+gIQiTgUh7APQgiAXhEAEQhYAGgOADQgpALg+AWIhnAjQhWAbg+AJQiZBTlCBZQlsBliAA3IhCAAQg8Aih+ADQiXgChIACgASxAxIgWAsQgNAbgLAMQBRgfAhhhIgHgBQgjAAgaAug");
	this.shape_164.setTransform(-13,169.4);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFFFFF").s().p("AAegZQgKApgwALQgHg8BBAIg");
	this.shape_165.setTransform(197.3,102.6);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#000000").s().p("AheJcQgNhGAWiAQAbieAAg/QAuiYAgjnIA0mcIAcABQgLDGgoECQgXCVgwEeIgKAeQgGARgCAOQAFCZgRByQgEgBgKABIgPABQgLAAgCgHg");
	this.shape_166.setTransform(253.1,243.8);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#000000").s().p("AArImQABkBgpk2Qg1lfgYiyIAbgEQAGAoAWBRQATBRAHArQASB2AeD1QAeDkgPEJg");
	this.shape_167.setTransform(256.1,127.6);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#006B33").s().p("AACBAQg5gChQgRQgGgXALggQAJgcAQgZQBqAfAcALQBJAZAlApQg3AThDAAIgPAAg");
	this.shape_168.setTransform(329.4,-169.6);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#00A23D").s().p("AO1KNQgdgLgpgcQmfiJjghDQmGh1k0gsIkCgoQiWgXhmgEIh+gFQhMgBgzAGQgNABgQALQgSALgNABQAUjBAoj0QAeiyAwkDMAl5AAAQgeCQhQIQQhBGshCDsIgIABQgtAAgngQg");
	this.shape_169.setTransform(245.7,-237.5);

	this.addChild(this.shape_169,this.shape_168,this.shape_167,this.shape_166,this.shape_165,this.shape_164,this.shape_163,this.shape_162,this.shape_161,this.shape_160,this.shape_159,this.shape_158,this.shape_157,this.shape_156,this.shape_155,this.shape_154,this.shape_153,this.shape_152,this.shape_151,this.shape_150,this.shape_149,this.shape_148,this.shape_147,this.shape_146,this.shape_145,this.shape_144,this.shape_143,this.shape_142,this.shape_141,this.shape_140,this.shape_139,this.shape_138,this.shape_137,this.shape_136,this.shape_135,this.shape_134,this.shape_133,this.shape_132,this.shape_131,this.shape_130,this.shape_129,this.shape_128,this.shape_127,this.shape_126,this.shape_125,this.shape_124,this.shape_123,this.shape_122,this.shape_121,this.shape_120,this.shape_119,this.shape_118,this.shape_117,this.shape_116,this.shape_115,this.shape_114,this.shape_113,this.shape_112,this.shape_111,this.shape_110,this.shape_109,this.shape_108,this.shape_107,this.shape_106,this.shape_105,this.shape_104,this.shape_103,this.shape_102,this.shape_101,this.shape_100,this.shape_99,this.shape_98,this.shape_97,this.shape_96,this.shape_95,this.shape_94,this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-305.5,-304.4,683.1,610);


(lib.sec3 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A23D").s().p("AiUAVQgXAXgiAfQgmh7gPh7QCAAbCBgIQgXAjgSAZQCJBWCkAjQgjBKgsBFQi1gyiThlg");
	this.shape.setTransform(13,-8.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A23D").s().p("AA/BKQi6AHizg0IAriMQCfAvCjgJIgDhIQBtBICGAmQhnBpiGBMg");
	this.shape_1.setTransform(113.3,40.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(1,0,0,4).p("Aheg9IAKAfQANAeAWgCQAWgDAiAYQAUANAbAYQANAJAPgQQAHgIAFgKIgKg0");
	this.shape_2.setTransform(83.2,32.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AA3A5QgcgXgTgOQgigXgXADQgWABgNgdIgKggICyAoIAKA0QgEAKgIAIQgKALgIAAQgFAAgEgEg");
	this.shape_3.setTransform(83.2,32.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FF0000").ss(1,0,0,4).p("AARh5IAIAuQAGAggJAjQgMApAAAiQAAAugKAOIgNAEQgHgDgEgOQgHgcASg7QARg4AJg3IAEglIgBgHIgBgG");
	this.shape_4.setTransform(71.6,48.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("AgYB0QgHgcASg7QARg4AJg3IAEglIgCgNIADAGIgBAHIAIAuQAGAggJAjQgMApAAAiQAAAugKAOIgNAEQgHgDgEgOg");
	this.shape_5.setTransform(71.6,47.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FF0000").ss(1,0,0,4).p("AgMhnIgUAUIgDAGQAAAKASASQAWAYAFAKQAGAMAAAaQAAAoAFAZIAPhYIgFhA");
	this.shape_6.setTransform(81.5,43.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF0000").s().p("AAQAfQAAgcgGgKQgFgKgWgYQgSgSAAgKIADgGIAUgUIArAoIAFA+IgPBZQgFgZAAgog");
	this.shape_7.setTransform(81.5,42.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FF0000").ss(1,0,0,4).p("AgSiOIABADQADANAGArQAEAhgEADQgIAGgCAyQgEBGAWAtQAGASAHgCQAHgCAAgZIAAiw");
	this.shape_8.setTransform(77.6,46.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF0000").s().p("AAAB+QgWguAEhFQACgyAIgGQAEgEgEggIgJg4IgBgEIAmBPIAACwQAAAZgHACIgCABQgGAAgFgQg");
	this.shape_9.setTransform(77.6,46.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FF0000").ss(1,0,0,4).p("AhmhLIAtAnQAyAsAXAiQAZAiAhgBQAQgBALgH");
	this.shape_10.setTransform(72,22.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF0000").s().p("AARAqQgXghgygsIgtgnIDLCNQgLAIgQAAIgCAAQggAAgYghg");
	this.shape_11.setTransform(71.9,22.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FF0000").ss(1,0,0,4).p("AhMgMIAQgDQAXABAlAQQAkATAWgHQALgEADgI");
	this.shape_12.setTransform(57.4,12.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF0000").s().p("AABACIgWgIIBfAIQgDAIgKAEQgHACgHAAQgTAAgbgOgAhKgMIAQgDQAPABAWAIg");
	this.shape_13.setTransform(57.2,12.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A23D").s().p("AjFCrQA1iRBfiBQgygSgpgLQCghFCygZQACB3gHCEQgmgZglgTQhoBvhDCHQhCghhOgXg");
	this.shape_14.setTransform(78.1,-18.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AiDBTQFRjZBkhLQB7hYBuheIARAUQknD5mlENQhBAph+BeQhzBPhZAfQCTiBEVi0g");
	this.shape_15.setTransform(-262.8,262.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AkTEAQEIjgEEkzIAbAKQhCBthLBVQgbAdg6AtQhBA2gZAYQhiBdh4Bmg");
	this.shape_16.setTransform(-181.3,197.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgqgCQBchlFtl0IA7gSIAEAcQjoC3j2EnQg6AfhDBQQhRBjggAZQgnAqhABhQg+BThKAYQCzjjEAkNg");
	this.shape_17.setTransform(-135.5,252.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AknCWQFxh1DPjSIAPAVIhUBUQgwAugpAeQirBjjzBLg");
	this.shape_18.setTransform(-58.4,188.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AmoI0IC6lyQBujbBaiHQCriMDJjZQAkgSAlgmIARAQQifClg5A4Qh7B5hnBWQhYB/huDhQh/EGg2BZg");
	this.shape_19.setTransform(-113.8,113.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FBD2C7").s().p("A6aVeIAAgUQBZgfBzhQQB+hdBBgqQGnkOEnj5QB4hnBihdQAZgYBDg1QA6gvAagdQBMhVBChuQAzhXB/kGQBujjBYh/QBphWB8h5QA4g4CgikQC4i9BuhjQBqAEB0ASQBPANB9AaQgHA0gUAwQgdBGg6A3QgQgBgvgOQglgLgjAGQgVgOgUhAQgSg5gjgIQAyClh5CEQhuB4i3AgQAdArBMgeQApgRBIglQBxhHA+gcQBqguBzgIQAVAGAaAOIAqAZQA2AcBBgLQAggegbg5QgQgigDgKQgHgZAKgSQBQAtAHBAQAGA5gyA5QgvA3hOAgQhQAihNgHQhdAyg/B5QgYAwhEC6Qg2CUg3BGQhOBlh+AWQBiAhBYhaQAdgeAng4QAwhGAJgMQATAQAUAfIAhA0QAqA9A/AEQgtBBg5A5QjPDUlzB0Ig6ASQltF0hfBlQj9EPizDjIAAAUg");
	this.shape_20.setTransform(-149.3,166.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FBD2C7").s().p("AgSgjQA9gWA3AqIhfAgQg3AUgtAHQASg6A9gVg");
	this.shape_21.setTransform(-23.7,63.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AhzJ6QA5g7AthBQhAgEgpg9Ighg0QgUgfgTgQQgJAMgxBGQgmA4gdAeQhYBchjgjQB/gWBOhlQA2hGA3iUQBEi6AYguQA+h5BcgyQBMAHBRgiQBOggAvg3QAyg5gGg5QgIhAhPgtQgLASAIAZQACAKARAiQAbA5ghAeQhBALg1gcIgrgZQgZgOgWgGQhxAIhpAuQg+AchxBHQhIAlgpARQhMAegdgrQC3ggBth4QB6iEgyilQAiAIATA5QAUBAAVAOQAigGAkALQAuAOARABQA6g3AdhGIAZALQgZA/gZBSQAzgBArgiQBFg3ADgCQBAAJApA8IAfAvQATAaAWALIgqAAQgBAtgeAzQgjA6gGAeQgpAUhdAXQhgAXgnARQhEAegbAzQgeA7AWBmQBCAtBfANQBzARA2g2QBbAOBFgyIAZANQhuBNgxA6QhJBYgPB0Qg5AXgeAKQg0ARgwABQgvAeguArQghAdg1A1gAgeGCQgOAjAAAbQAtAfBbgNQBHgKA9gcQAVgtAVhYQgpgMhiAOQhhANgfgKIgMgFQgagJgZgwQgZgvgcgIQgoAzAVBTQATBOA0AhQAHgtAFgUQAKgjAegCQgBAWgQAmgAgzCsQAdApBFAzICfgNQBXgLAugbQgagehDARQhTAWgggJQhUgbgvgmQg5gvgThIQgVBNAuBCgADPm5QgTAKgGAXQAKAYAiAMQAkALAZgQQAEgagNgTQgLgRgWgFQgIgCgIAAQgMAAgKAFgAhFnUQg9AVgSA7QAugGA5gUIBcgjQgjgbgmAAQgVAAgWAIg");
	this.shape_22.setTransform(-18.6,106.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FBD2C7").s().p("Ag/ALQgUhQAog0QAcAJAXAvQAZAvAaAJIAMAFIgMAYQgeACgKAkQgGATgGAtQgyghgUhOg");
	this.shape_23.setTransform(-26,137.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#E1DDDB").s().p("AkRIcQhfgOhEgsQgWhmAgg9QAbgzBEgeQAngRBhgYQBcgWApgUQAGgfAjg5QAcgzACgrIApAAQgWgMgTgZIgdgvQgpg9g/gJQgEAChFA3QgrAjgzAAQAZhRAZhAQA/iZBbhOQA5gwBGgZQAPgDADAKQACADABAUQBFg7CHAoQB0AjBBBCQAACzg1CmQg1CihcBzQAJAMABAMIAAAGQgjAdhABcQg9BXgsAgQhDAyhbgOQgpAqhNAAQgYAAgbgEgAh0G6QgLATAXAVQgGgWAVgFQAZgHACgHQgPACgDgUQgEgWgJgBQgBADgWAngAjqHeQAHADgBgKQgMAFAGACgAjjGlQgIAGgOAOQAVAHAAAXIAcgeQAQgRgNgOQgRABgNAKgAkxGwQAYABABgNQgxAIAHgwQgXANACAmIAIgBIAeACgAk+FhQgJALAFAQQAXgOgCgmQALgEgGgCQgGgDABAJIgLAAQACAMgIANgAg+FIQAJAfAAgfQAAgPgCAAQgCAAgFAPgAi8FFQgBAFAFAFQAFAFADgEQADgDgDgPQgLABgBAGgAiyEcQAEAJgCAZQAYgiALgUQAVglgPgVQADAcglAWQgTALgUAKQAIgCAGAAQAMAAAEAJgAk4EVQAIAIAUAEQAXAEABgQQgHgHgUgEIgJgBQgOAAgCAMgAAzEgQAQgCgGgTQgmgFgEAZIAKAAIAWABgAgqEKQgIAUgCABQAiADgCghIgHgBQgLAAgEAKgABcCvIAVAAIAAgUIgVAAgAAECLQgOAEgKAMQAfAjATguQgGgGgKAAIgKABgAC7AFQAFANAZgGQAAgWgVgHQgNANAEAJgABNgaQgPACgBAHQAJASAXgNQAXgPgYgKQAAAIgPADgAEChtIAgAAIAAgfIggAAgAAgi8QgTAKgEAIQAJAAACAOQADAPAHABQAAgPAagFQAagFAAgQQgNACgEgPQgFgRgKAAQgBANgRAKgACcixQgYABACAaIApAAQAFgbgVAAIgDAAgAgpi/QgIACAFAFQAGAFAJAAQALgBAIgLQgMgCgIAAQgHAAgEACgABGkPQgBAUANgBQgDgSASgNQATgMgDgSQgKgCgLAGQgMAGgJAAQABADgCAdgADXkiQgSAMgBAQQAbAFAKgPQAIgMgDgdQgEAJgTAOgAgTkuQATACAAgNQgLgMgTACQgVACgBASIAFAAIAcABgADuk5QALgFgGgCIgCgBQgEAAABAIgAD3lbQgBAFAEAEQAFAFADgDQAEgEgEgOQgKAAgBAHgAEPmJQgTALgEAHQAGABACAHIACANQAXgKANgOQASgWgWgQQgCAOgRAJgACImWQgWAeAUAWQgDgVASgKQAXgPADgFQgRgEAJgMQANgRgFgIQAMgFgGgCQgGgDAAAKQgbAYgMAQgAhVmQQgRAWATAOQgEgVAVgJQAYgJABgNQgHAAgEgJQgFgKgFgBQAAAHgXAdgAAFmlQgSAIgHASQAOAOATgJQAUgIAHgSQgIgIgMAAQgHAAgIADgAFBnJQAJAfAAgfQAAgPgCAAQgDAAgEAPgADEndQAJAeAAgeQAAgPgCAAQgCAAgFAPgACvm+IAAAAg");
	this.shape_24.setTransform(24.7,69.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAGAZQgfgCgFABQgCgkAXgNQgHAuAvgHQgBAMgTAAIgFgBg");
	this.shape_25.setTransform(-6.5,110.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgEAAQAGgNgCgLIALAAQACAkgVANQgFgPAJgKg");
	this.shape_26.setTransform(-6.6,105.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AABgBQAGABgJADQgBgHAEADg");
	this.shape_27.setTransform(-5.1,102.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AABALQgSgEgHgHQABgOAXAEQASAEAIAGQgCAMgOAAIgJgBg");
	this.shape_28.setTransform(-4,97.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("Am7CoQASgTAlgrQAmgsAVgWQA4hEAfglQA5hDArgKQBPgTCPAmQCnAsBNgCQAqgyA7g0IATAWQhbBOg+CXIgZgKQAUgwAHgyQh9gbhQgMQhygThqgDQhuBii4C7g");
	this.shape_29.setTransform(-28.6,39.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAAADQgGgCAJgDQABAFgEAAIAAAAg");
	this.shape_30.setTransform(1.3,117.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgcAAQAOgMAIgGQAMgKAQgBQAOANgRAQIgaAeQABgXgWgHg");
	this.shape_31.setTransform(2.5,113.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FBD2C7").s().p("AiaBEQAAgbAOgjQAPgkACgWIAMgaQAhAKBfgNQBigOAoAMQgUBWgVAtQg9AchFAKQgcAEgXAAQg3AAgggWg");
	this.shape_32.setTransform(-7.6,144.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgHAiQgjgLgJgXQAFgXATgKQARgIATAFQAWAGALARQAOARgFAZQgPAKgSAAQgNAAgMgFg");
	this.shape_33.setTransform(4.9,66);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgBAGQgFgEABgDQABgHAJAAQADAMgDAEIgDABQgCAAgBgDg");
	this.shape_34.setTransform(6.4,102.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FBD2C7").s().p("AizAZQguhAAWhNQASBIA7AsQAvAnBSAbQAgAJBUgWQBCgRAaAeQguAbhXALIicANQhIgzgdgpg");
	this.shape_35.setTransform(-5.8,121.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgIAVQgHgNgXAHQAUgKASgJQAkgXgDgcQAOAVgUAjQgLAVgXAiQADgagEgJg");
	this.shape_36.setTransform(7.7,96);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgYAAQAWgkABgEQAHACAEAWQADASAPgCQgCAHgZAHQgTAFAGAWQgXgVALgUg");
	this.shape_37.setTransform(15.5,113.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgQAAQAVgbAAgIQAFACAEAKQAEAJAHAAQgBANgXAHQgUAIAFAVQgTgNARgWg");
	this.shape_38.setTransform(17.8,29.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgDAAQAHgdAAAdQAAAPgCAAQgCAAgDgPg");
	this.shape_39.setTransform(18.8,102.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgOAPQABgBAIgSQAFgNAPAEQACAcgaAAIgFAAg");
	this.shape_40.setTransform(20.9,97);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AAGAKQgbgCgEABQABgQAVgCQARgCALALQABAKgPAAIgFAAg");
	this.shape_41.setTransform(22,38.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgOACQgFgDAHgDQAJgDAUAEQgHAIgKABIgBAAQgIAAgFgEg");
	this.shape_42.setTransform(21.7,51);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgYAAQAJgJAPgEQAQgFAKAKQgLAYgPAAQgKAAgOgQg");
	this.shape_43.setTransform(25.1,85.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgeAKQAHgQAUgIQAUgIAOANQgHAQgUAIQgGADgHAAQgMAAgJgIg");
	this.shape_44.setTransform(25.6,29.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgUAKQADgXAkAFQAHARgRABQgUgBgJABg");
	this.shape_45.setTransform(28.8,97.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgXATQgDgOgJAAQAEgGATgKQAPgKABgNQAKAAAFARQAFAPAMgCQAAAOgaAFQgYAFAAAPQgHgBgCgPg");
	this.shape_46.setTransform(29.3,52.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("ABhMXQgIizgIhdQgsj3gcmWQgopngLhuQgfAYhBAtIgZgNQAsggA9hXQA+hcAjgdIAAgGIAaAOIg5BeQgBFQAyIkQAcEyA6JAQAEAnAPBXQAHBKgaAZQgjhpgLiag");
	this.shape_47.setTransform(46.6,196.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgUAEQABgFAPgCQANgDAAgIQAYAKgXANQgKAGgFAAQgKAAgFgLg");
	this.shape_48.setTransform(33,67.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgUALQACgbgBgDQAJABAKgGQALgGAKABQADASgTALQgQAMADASIgCAAQgLAAABgTg");
	this.shape_49.setTransform(33.9,41.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_50.setTransform(35,86.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgUANQgCgYAXgBQAYgCgFAbg");
	this.shape_51.setTransform(40.2,53.3);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgNgEQAMgQAZgZQAFAJgNAQQgJAMARAFQgDADgVAPQgSAKADAUQgUgWAWgbg");
	this.shape_52.setTransform(39.8,29.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AABgCQAGACgJADQgBgHAEACg");
	this.shape_53.setTransform(42.6,24.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgDAAQAHgdAAAdQAAAPgCAAQgCAAgDgPg");
	this.shape_54.setTransform(44.8,21.9);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgNAIQgEgKANgNQATAIAAAVQgIACgGAAQgLAAgDgIg");
	this.shape_55.setTransform(44.9,69.5);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#006B33").s().p("AglAwQg4gegUg5QAegeBCgIQApgFBaACQADBagYBIQhSgHgwgbg");
	this.shape_56.setTransform(35,-204.9);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgUAYQABgPASgLQARgOAEgJQADAbgIANQgHALgPAAIgNgCg");
	this.shape_57.setTransform(46.5,40.9);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AABgCQAGACgJADQgBgHAEACg");
	this.shape_58.setTransform(48.9,37.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgCAGQgEgEABgDQABgHAIAAQAEAMgEAEIgCABQgCAAgCgDg");
	this.shape_59.setTransform(50.1,35.2);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgRARQgCgHgHAAQAEgIAUgIQAOgKACgNQAXAQgTATQgNAPgUAJIgCgNg");
	this.shape_60.setTransform(52.2,31.1);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AgOAPIAAgdIAdAAIAAAdg");
	this.shape_61.setTransform(52.1,57.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgDAAQAHgdAAAdQAAAPgCAAQgCAAgDgPg");
	this.shape_62.setTransform(57.3,24);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FBD2C7").s().p("EgKTAoZIAAgUQAagagHhJQgQhYgDgmQg6pBgckzQgyolABlPIA5heQBUiRAsh3QA7iaAQihQARgSASAIQALAGAWAZQAwA6AogHQgNgyg/g2QhNg6giggIhphjQg/g9gogiQgaAMAMAdQANAggJAIQgkABgpgHIhGgOQAJhjApiaQAsinALhRQgjnVATm1QAVnMBOlpQGdAZHJBlQFwBSGyCMQhGG5jXIVQhGCuh9EWQiYFVgsBnQACBZgHBuQgFA+gKBpQAgDZBJGxQA5F9AEEfQAABGgFBKQgLB5gfCiQgTBdgnC6QhIFXAVDQIAAAKgAkdnPQAYAcgDAcQghBRgIC0QgHCmgtBSQAhgfAcgwQAUgjAXg6QgTg2AKhKQACgRAZhsQAQhIgGgnQgIg2g0ggIgUAAQgDAcAXAdg");
	this.shape_63.setTransform(127,45.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("EACiAmoQAGhKAAhGQgEkfg6l9QhJmxggjZQAKhrAFg+QAIhugChZQAshnCYlVQB8kUBGiuQDXoVBHm5QmziMlthSQnLhlmdgZQhOFpgVHMQgTG1AjHTQgLBRgtCnQgoCagJBjIBGAOQAoAHAkgBQAJgIgMggQgMgdAZgMQAoAiBAA9IBoBjQAjAgBNA6QA/A2AMAyQgnAHgxg6QgWgZgKgGQgSgIgRASQgRCjg6CaQgtB3hUCRIgagPQgBgMgJgMQBdhzA0ijQA1imAAizQhBhDh0giQiGgohGA7QgBgUgCgDQgDgLgPADQhHAZg6AwIgTgWQBAg4BUg4QABhOApiFQAuiYAGg4QALhbgJiRQgNjOAAgkQgCnLBBp7Qjdg8hHjDQBhnfA7mQIAqAAIhJGsQgsEAgSC5QD7grGYA9QBwARDkAqQDaAoBmAPQCNA0D+BFQEYBMBzAmQAaAJAnAUIBBAhQBOAlA/gHQBIjoBBmjQBWooAah9IAgAAQgbCNgeDXIgzFpQhAGxhPD6Qg9Axh1AHIjjgFQhsGVirGtQiIFSjRGuQgiDWAQEBQAKCsAnEBQAzFEAPCiQAaEPgTDgIgBANgALZxFQBFAVBGAEQBPAFA/gUQgSgbgvgdQgwgegvgNQgagGgVAAQhNAAADBfgAyS4jQhCAIgeAeQAUA7A5AeQAxAbBTAHQAYhIgEhcIg0gBQgzAAgeAEg");
	this.shape_64.setTransform(150.3,-55.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgNA9QAHiyAghRQADgcgYgcQgVgcADgcIASAAQAzAfAJA2QAGAogQBIQgZBsgCAPQgKBKATA2QgXA5gTAmQgbAwghAeQAthSAHiog");
	this.shape_65.setTransform(97.8,24.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AghAFQAmi4AShdQAgiiAKh5IAZACQgRDFgWCUQgdC8gsCdQgBAsgHBFIgMBwQgDAiAABJQgFA9giAaQgUjQBHlXg");
	this.shape_66.setTransform(160,247.3);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("EgSqAvbIAAgKQAigaAFg9QgBhJADgjIAMhvQAIhGAAgsQAuifAdi8QAWiTARjFIABgNQATjggakPQgPiigzlEQgnkBgKisQgQkCAijVQDRmtCIlUQCrmsBsmVIDjAFQB1gHA+gxQBOj7A+mwIAzlpQAejXAbiOIQPAAMAAABe1g");
	this.shape_67.setTransform(271.1,0.5);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#006B33").s().p("AAAA7QhGgEhFgVQgDh3B8AgQAtANAxAeQAuAbASAbQgzAQg/AAIgagBg");
	this.shape_68.setTransform(237.2,-168.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#00A23D").s().p("AOdJ5IhBghQgngUgagJQhzgmkYhMQj+hFiNg0QhmgPjagoQjkgqhwgRQmYg9j7ArQASi5Asj+IBJmsMAm+AAAQgaB9hWImQhBGjhIDoIgVABQg2AAhCgfg");
	this.shape_69.setTransform(152,-236.5);

	this.addChild(this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-318.5,-303,709.3,607);


(lib.sec2 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3F6970").s().p("AhcAIQhZhRgihKQBOAnCIA1QCsBDAsATQg1BWhyAfQgWgbh2hxg");
	this.shape.setTransform(-288.5,163.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AwLEiQGNjlIoiXQHqiJJ1hPIADAUQptBkngCHQojCWmeDQg");
	this.shape_1.setTransform(-139,-69.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("A+oYCQGdj6DOh+QFtjfDkivQi+jTg3hCQiEihhPiSQjKlzAuncQAgkpCTjsQB/jKDhiyIAPAXQj/DIiFFOQiJFZAnF/QAQCbBECgQAtBrBjCqQB4BRC9BGQBoAnD2BLQBqhNAygoQBWhHAvhCQipg3iahfQiChRiHh1Qi1imAcl/QALieAvicQAtiWA+hmQC3ikDviKIAJAQIheBRQg3AvgfAfQgdAeg3AeQg4AegbAbQhKBJgwCGQgtB8gPCaQgPCVAQCNQAQCRAtBiQCECRCrBnQC7ByDBAoQD6l5CIi0QDrk2DxirQFgh6DGg5QE6haEfgqIABADQgZAEgRAOQgRAOAAARQAAAHADAGQkWAYk1BhQhhAeikA6Qi5BBhLAZQnZGdj3HxQlZFppoGFQiyBxloDVQlsDYiuBtgAs+JGQB4BwAWAbQBygeA2hWQgtgUiuhEQiIg1hNgoQAhBKBZBUg");
	this.shape_2.setTransform(-214.7,105.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("EAvOARnQgfgkhBhWQh7ijhhg5QgzAog2BFIhYB7QhvCZh0AyQAthBCZizQB+iWA8hoQgkggiFiDQhohmhLg2QlsBDqyBPQrKBRlXA8QnsAho4hIQkvgnq7iHQjXiMjRCUQhEAxhcBjQh0B7gUASQAjA1BABEIBpBxQAiAQAZAhQARAXAUAsQANAQAyAnQAlAkgcAPIkokbQhEhWhEgsQg9AkhGBBIh4B4QiUCUh0AiQBuhfCfiTQCwilBZhRQFAkkD5ikQMih/HKnRQBlgKCQgyQCgg2BLgNQADgTgqgmQgvgtgJgXQAJACANAAQAbAAASgMQATgNAAgSQAAgIgEgHQAwgGAZgEICiiGQBthfBQhLIAVAQQhEA+gSBXQBCgGBcgNICbgVIAFAAQDWgdCHgDQC7gFCaAkQAHgMAkgEQAjgDAGgOQihhPg3ilQjTACh+ANQgagegsAAQgeAAgZARIgagHIAIgFIhXAAQg0AAgRAPIgVgPQA6hHAfg5IAWAKIgBAGQAAALAJAIIgOAoQBqAIBbACQANAFAPAAQANAAALgDIAAAAQCsADB5gOIARAAQAfABAagNQAbgGARgEQByAsDoANQEIAOBiAYQAdAHA4AaQA2AYAcAHQAgAHBRgBQBEAIALAxQhWgIhmgYIiwgrQjbg2isACQgQAIg4A3QgqApg2ACQg9gIgXg+QgPglgFgJQgOgYgagJQgoCeCrBIQCDA2DOgIQB6AlBKCMQARAiAnBbQAjBRAZAqQArAwBoBEQB7BRARAPQiGgKhbhKQhDg2hChxIhti7QhFhlhXgsQgUgBiXgQQhqgLgvAHQgSA8ARBLQAJAnAkBdQAgBSAGArQAJBDgfAxQgBgngHgrQgEgYgMg0QhZACjJAWQizAVh3gDQgNAJhPAPQg9AMgDAmQBCAoBsAKQBJAGCGgHQCZgIA0ABQBsADA+AeQBXA1CKBsQCaB3BDAsQESC3FDALQApAqFJE6QDiDYB8CgQA4ArA0BTQAMATAwAyQAkArgYAPQg7gng5hAgA2LCVQhjAvjKA6QjjA/hUAhQBzBCD+AxIDNAmQB1AYBNAZQIUBCD/ARQG0AcFnglQDKgUEfgkIHjg8QF6gvBwgSQENgrC8g/Qgqgrh7gWQijgdgfgMIh8hLQhKgshCgTQkMAxjgAaQj0Acj/AXQkSAYjHAKQkvAPn0g6QktgkhTgIQjSgTilAAIgIAAgAgvrcQgmAHgOAwQgHAHAKAGIAbAMQAqASgMAfQgaBChGBJQgnAHgwAaQg6AhgXAIQkMAjj9CdQhKAtiGBhQiJBhhGAsQJ8CCMFgUQLAgRK1iIQjiiwjyhsQhtgNi6AGQjqAJgvgCQhIgYgfgRQg1geAAg4QAXgxBDgXQAzgRBegFQA1gEBtgEQBcgHAzgTQhcgYiIAGQgZABjWATQiNANhQgJQhugNhCg4QAhg/AnghQCIgkEggWQEkgXCIgkQjLgnkdAcQhuALlGA2QgwgOgcAAIgOABgAjepYQgzAbgqADQAQBJBcALQAwgOAXgqQAZgtgYgvQgfAFg4AdgADCp5Qg1AEgCAlIAAAqQBKAxCCgaQAlgIBLgTQBEgPAwgBQBbgDCvAQQC7ASBXAAQADgvgIgxIgThUQkTASiGANQjoAUiXAiIgygBQghAAgSACgARtwSQAPAUAjAGQA2gQASgwQgOgLgoAAQguACgUgCQgRAcAPAVg");
	this.shape_3.setTransform(44.2,159.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AnYDUIAAgWQB0ghCUiVIB4h1QBGhBA7gkICICBIB9CgQBOBYBdAiIAAALg");
	this.shape_4.setTransform(-223.1,262.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgVAUIh+igIEnEZQhdgihMhXg");
	this.shape_5.setTransform(-190.5,268.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3F6970").s().p("EgjIAGiIAAgKQAcgQgmgkQgxgngNgPQgUgtgSgXQgZghghgQIhqhxQhAhEgigyQAUgTBzh7QBdhjBDgwQDRiVDYCNQK7CGEvAnQI4BJHrgiQFYg8LKhRQKyhPFshCQBLA2BoBlQCFCDAkAgQg8Bmh/CWQiYCzgtBBIAAAVg");
	this.shape_6.setTransform(49.2,242.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#6CABBA").s().p("A0TV9Qi8hHh5hQQhiiqguhrQhEiigQicQgml/CJlWQCElOEAjIIAdgWQG/kuHWixQIYjLJtg9QAtgDAlAkQAnAnAjACQCEACB5goQA9gUCLhCQB7g6BUgVQCAggCTAMQgHBPgYBqIgoCwQkJAWj+AgQp1BPntCJQolCZmNDlQjvCKi4ClQg+BmgsCTQgvCdgMCdQgcGAC1ClQCHB4CDBQQCZBfCpA3QgvBDhWBGQgyAphpBNQj3hLhogng");
	this.shape_7.setTransform(-161.1,10.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("EA53AqdQhNhAgQgMQg3gpgwgTQhTheh+hzIjdjEQkUj0h6i+QhWhghciKQgxhHhui1QjMlMiPiTQifiVkEh6Qi1hWlDhuQjOgNhigKQiqgRhmgiQiEgJiRADQgFgPgLgJQgLgKgNAAIAAgMQAkgCAoABQhKmYhQonQgwlNhUqIQgFhXgKgsQgQhOg0gjQigAShNAHQiGAMhKgaQgcFwiHJxQhLFegZCAQgzEMgWDVQAcgxAngjIgBAKQAAAeAWAVQgaAUgkAhQgQgOgUAAQgYAAgRAQQgQAOAAAWQAAASAMAPQgwArgVAbIgFgEQAIgIABgLQAAgOgOgIQAegiAVgeIgsABIAAgFQAAgUgVgOQgWgOgeAAIgQABIAAgDQBCgKBPgJQAXi1BKkcQBUlEAXiGQhagSiiALQjBAMhHgFIgDgUQD+ggEJgWIAoiwQAYhqAIhPQiUgMiAAgQhUAVh7A6QiKBCg+AUQh5AoiEgCQgigCgngnQgmgkgtADQptA9oaDLQnWCxm+EuIgeAWIgPgXQB3heCjhlQBqhCDFhuQEXiMGqhvQD4hAIihtQgZhChBhTQhUhsgSgeQCXiwCdhcQDHhzEFgUQBDAVA4BYQAkA5AJAMQAcAlAgATQAThDA4jZQAuixAjhlQBrk2C0iIQCMg0CwAFQC1AFBxA/QB6CoA3EvQAbCSAlGnQAfgZAYgxQAHgQAchLQAqh1BHgaQENgFC1A4QDcBGA/CbQgWBChGB7QhEB1gUBMQI5CRF+CfQHZDGEvEGQGTIQAdHzQAICHg1DFIgrCgQgYBdgIBJQhiCHhjCoQhSCLhdC4QDSEXFoE9QBsBeIKGnQhVgKhzhhgEApwAYJQgsAUgJAIQAFAhAGAPQAMAWAZAEQAwg7AFgJQAdgxgigVQgJAUgiAQgAAz2eQAJBDATCDQAQB3AFBWQCGAYDBABQECABBKAGQIpAnHDDXQGUDBE0FHQB3DCA1BnQBXCtApClQAPChgjCWQgZBpg/CSQglA8hkBEQh2BRghAjQAeA0BCBrQBABoAgA3QA+gSBMg4QBahDAkgSQB1i2BLi9QBTjRAljiQgeoujtlsQjulunHjEQlgiWjWhNQk8hykmg+QgrAThIARIh9AcQhcgDhfgrQgNgFiPhPQhdgyhIgOQgjgHgmAAQhCAAhJAVgABvvBQAjDEBDFuQBHGAAgCxQCHAvEOAYQFqAhBIAMQBEAdD2BhQDCBOB0AzQCDBuChCyQBbBmC1DMQA+gHA+grQBTg6AVgJQBhiAAjiyQAki2gkjJQgxhjgXhnQg7hkhch9IihjaQjRi1i+hyQjpiNkAhKQjyhGlnghQg2gFp1goQgZAKgLALgA410cQAvBABUgDQgdhFgjgoQgrgyg9gWQgEBBApA3gA5OzfQgBgcgQgYQgGgKgZgcQgsgvAIg2QA6gxAuANQAiAKArA1QA/BMANAMQAxAtA2gBQgBgkgRghQgJgPgbgmQgxhCAHhDQALgBAPgSQANgPAVACQAvACAiAZQAVAQAcAmQAfAqARAOQAfAcArAFQACgdgTghQgJgQghgqQg/hRAChAQBKgoBEA2IA2AzQAgAeAYALQABhXhJhTQgxg3gIgLQgegogJgqIgkAAQg6CfjWBTQhRAfh8AdIjbAwQA/BxAuAzQBHBRBgAfIAAAAgA1E2CQAKAPAWAdQAUAaAGASQA5ACAbgsQgTgOgwhGQgmg4gzgJQgWAvAkA4gAMn00QBJAAAehAQAHgRANgqQALgnAKgTQh9AhgTCUgAMb5TQgFA6giBTQglBZgHAuQAjgXAigrQANgQAqg+QBFhmBGgeQABAKATAFQASAEgCANQADAggeBFQgZA7AQAfQAegsAnhMQA0hnAMgVQi1gki1hPQh6g2i9hrQgMBJg5BpQg8BwgPA8QAjgFAcglIAvhMQAdgxAggVQArgeA/AGQAaAngPAwQgJAegkA4QglA6gJAaQgQAvAYAkQAbgQAlgxIA/hUQAxg5A0AAQAjAAAkAZgAJn3pQgjAygMBYQADABAbAOQATAKAXgEQAmgpAYg+QAVg2AMhMQhOAPgqA7gEgNzgghQgiCAg9EEQAIAWAVAqQAVApAJAWIghA8QgTAkgHAgQDDgIB0gtIBIn+QgrgRgWgKQglgQgSgUQAFhFgMiFQgLh6AHg6IgkAAQg/COg6DfgAyF5SQgYADgBARIA1BWQAjAtA3AHQAPgjgjgtQgug7gFgUIgvABgAGV5PQgoBSA7A0IA2hpQAghAAJg2QhMAKgmBPgEAA2glpQAJCKABAfQAEDMhXBOQAUBGAQCdQAQCiASBDQCeASAuhcQgjhegPiZIgTkUQgLikgYhgQggiDhEhJQgFA1AIBlgA4E9iQguAUhJAqQhRAugeAPQgMAahNA4Qg/AuAIApQCaALCog0QCFgpCFhNQgNg2AxgkQAbgUAIgKQAPgUgCgdQgtgIgsAAQhpAAhoAsgAH7+cQDBB8BfApQC8BTChgZQgtiMjRhCQhzglhtAAQhRAAhOAUgAlJ/uQDMgFB3gyQhdgIjXAGQjrAGhegEQBcA9DegGgEgKOgilQgPAEACARQAwA0CQAIQBPAEChgLICOgIQBRgMAGgrQhfALjggMQi+gLhdAAIguABgEgFvgrMQhrANhOAnQhUArgfBAIAAE+QCYAdCvAGQC2AHCYgVQANhLgEiTQgDikADgxQhBgshngQQg2gJg4AAQguAAguAGg");
	this.shape_8.setTransform(92.6,-0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgDAEQBbhSBHhKIARAXQhGBihQBCQhZBMhwAqQBshbBAg6g");
	this.shape_9.setTransform(-81.2,114.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#8AA09F").s().p("AguAdQgpg1AFhBQA9AWApAyQAiAmAeBFIgIAAQhMAAgug9g");
	this.shape_10.setTransform(-61.7,-134.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AlmBgQA1glBagWICdglQAzgNBlghQAOANAUAAQARAAAOgKQAOgLAFgQQBCgSA5gIQAUARAbAAIAIgBIADAUQhVANhqAgIiwA2Qi4A6h/AAIgngBg");
	this.shape_11.setTransform(-66.6,32.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F9D8CD").s().p("EghvAWCIAAjJQCthtFtjYQFnjUCzhxQJnmFFclnQD0n0HamdQBKgYC5hCQCkg5BigfQE1hgEVgYQAHAQATAKQAUALAZAAQAdAAAVgNQAVgNACgTIAsgBQgUAegeAiQgHgFgKAAQgMAAgJAIQgJAIAAALQAAAKAIAIQgYAXhaBKIgFAAQASgTAAgaQAAgMgFgMQALAHAOAAQAQAAAMgKQAMgJAAgOQAAgOgMgKQgMgKgQAAQgRAAgLAKQgMAKAAAOIAAACQgVgWggAAQgfAAgVAUQgWAVAAAdQAAAhAaAUQg4AIhCASQADgJAAgKQAAgYgQgQQgPgRgWAAQgXAAgPARQgQAQAAAYQAAAaATARQhmAhgzAPIieAlQhaAWg0AlQCIAKDVhDICyg4QBrggBUgNQBQgMBNAAQAkAHAyAtQAuApAwADQBggLgFhKIgJg+QgGgkAJgTIAAAAQAOAFAOAAQAQAAANgGQAnAPACA4QACA1gdAZQgKAlgoApQguAxgLAWQhBAwiWAhQjKArgnAOQhnA3hGB5QgnBEhACqQhHBKhdBUQhAA6hsBbQBwgqBbhMQBQhEBGhiQA+hWBNiVQAxALAfAeQAxAwADB9IAABnQACA7AKAlQAWgDAAgpQAAgsAOgHQA0gHB4giQBpgeBNgDIAGACQAJAXAwAtQApAmgCATQhMANigA3QiPAxhlAKQnKHRsiB/Qj5Ckk/EkQhZBSiwCkQieCThvBfIAAAVgAWK1BQgPAMAAAQQAAARAPAMQAQALAWAAQAWAAAQgLQAQgMAAgRQAAgQgQgMQgQgMgWAAQgWAAgQAMg");
	this.shape_12.setTransform(-194.7,142.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#DFF5F7").s().p("AgpAFQAkgJAvgNQgGAQgNAJQgOAKgPAAQgUAAgPgNg");
	this.shape_13.setTransform(-52.9,27.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#DFF5F7").s().p("Ag0AGQAAgVAQgRQAPgRAVAAQAWAAAPARQAQARAAAVQAAAKgDAJQgxANgiALQgTgRAAgag");
	this.shape_14.setTransform(-53.7,22.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#DFF5F7").s().p("AglAcQgPgMAAgQQAAgPAPgMQARgLAUgBQAWABAPALQAQAMAAAPQAAAQgQAMQgPALgWABQgUgBgRgLg");
	this.shape_15.setTransform(-49.1,11.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#D8D8D8").s().p("AlOCnQgJgqA/guQBNg4ANgYQAegOBRgvQBIgpAtgUQCThACXAbQACAdgPAVQgIAKgbAUQgxAkANA0QiGBNiCAoQiMAsiCAAQgaAAgagCg");
	this.shape_16.setTransform(-65.3,-177.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#8AA09F").s().p("AAABfQgHgSgTgbQgWgdgKgPQglg1AXgvQAzAJAkA3QAwBFATANQgaArg2AAIgCAAg");
	this.shape_17.setTransform(-36.3,-142.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#DFF5F7").s().p("AgRAhQgIgOAAgTQAAgSAIgOQAHgNAKAAQALAAAHANQAIAOAAASQAAATgIAOQgHANgLAAQgKAAgHgNg");
	this.shape_18.setTransform(-33.1,71.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#DFF5F7").s().p("AgygDQA0gHAxgBQgTAUgdACIgFABQgbAAgVgPg");
	this.shape_19.setTransform(-31.3,23.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#DFF5F7").s().p("AgGgLQAJALAEAMQgMgJgBgOg");
	this.shape_20.setTransform(-25.6,13.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#DFF5F7").s().p("AhIAIQAAgbAWgVQAVgUAdAAQAgAAAVAWQABAPAOAJQAFAMAAAKQAAAagSATQgxABg0AHQgagUAAghg");
	this.shape_21.setTransform(-31.7,16.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#DCE5E5").s().p("AlUDJQgtg0hAhwIDbguQB8gdBRgfQDUhTA6ifIAkAAQAKAqAdAoQAIALAxA2QBKBUgCBUQgYgIgggeIg2gzQhEg3hKAoQgCBAA/BPQAhArAKAQQASAhgCAdQgrgFgfgcQgRgOgfgqQgcgmgVgQQgigXgvgCQgVgCgMANQgPARgMACQgFBDAvBCQAcAmAIAPQARAgABAlQg2ABgvgtQgMgMg/hNQgsg0ghgKQgvgOg6AxQgIA3AsAvQAZAbAHALQAPAYABAbQhggehHhRg");
	this.shape_22.setTransform(-51.5,-156.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#C0F1F9").s().p("AhAg0QAmABAkAbQAqAdAaAFQgUAVgwAKIhWALQgEhDAQglg");
	this.shape_23.setTransform(-23.9,99.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#DFF5F7").s().p("AgXAaQgEgNgLgLIAAgCQgBgMAMgKQAMgKAPAAQAQAAAMAKQAMAKAAAMQAAAOgMAJQgMAKgQAAQgMAAgLgHg");
	this.shape_24.setTransform(-22.4,12.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#8AA09F").s().p("AgTAbIg1hUQAAgRAYgEIAwAAQADATAuA7QAjAsgPAjQg3gHghgtg");
	this.shape_25.setTransform(-18.3,-154.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgCACQgIgCAAgEIANACQAIACAAAFIgNgDg");
	this.shape_26.setTransform(-18.5,92.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#EFDB89").s().p("AkoIwQgygNgNgbQBOAOBRgGQBQgGA9gXQBshSCpiVQDMizBFg5QAGggAjgpQAkgsAHgeQATgFALgYQAKgXgCgaQgHhBhDAQQgRAOATAeQAXAjgNAbQhUCBiMCCQhVBQi0CRIAAgBQAAgIgEgGQgEgGgFAAQgGAAgDAGQgEAGAAAIQAAALAGAGQhOBAg7AyIiXAAQhYAAgkgWQgYAFACAPQABAKAJAYQg7gOg0gfQgpgZgsgqIhEhFQAUhbB/goQA7gTClgUQCcg2BahYQBqhoAAiQQAegCAVgRQAVgSAAgXQAAgZgYgRQgXgSghAAQgWAAgTAIQgDgcgUgUQgTgUgcAAQgXAAgSANQgSANgJAVIgDgBQAEgIAAgLQAAgZgUgPQAkghAagUQAUATAcAAQAbAAAUgUQAVgUAAgeQAAgMgFgOQAigRAdgKQCCgJBlAgQBVAbBKA8IgBAAQgnAAgbAcQgcAdAAAoQAAAoAcAcQAbAcAnAAQAmAAAcgcQAbgcAAgoIgBgJIA7BDQABBjgDAkQgEBGgSAnIgPAfQgfA3g7BHQg+BLhcBYQhPBMhwBeIihCGQgXAEgxAGQgHgMgQgIQgQgIgUAAQgaAAgTANQgSAMAAASIAAABIghAGQgGgDhLgVgAkQFmQgYASAAAYQAAAZAYASQAXARAhAAQAhAAAYgRQAXgSAAgZQAAgYgXgSQgYgSghAAQghAAgXASgAoXELQgHAOAAATQAAAUAHAOQAIANALAAQALAAAIgNQAIgOAAgUQAAgTgIgOQgIgNgLAAQgLAAgIANgAhGBvQgaAXAAAhQAAAhAaAYQAZAXAkAAQAiAAAZgXQAagYAAghQAAghgagXQgZgYgiAAQgkAAgZAYgAlSDbQgEAFAAAGQAAAHAEAFQADAFAGAAQAFAAAEgFQAEgFAAgHQAAgHgEgEQgEgFgFAAQgGAAgDAFgAA2hHQgSATAAAcQAAAaASATQATATAaAAQAaAAATgTQASgUAAgZQAAgcgSgTQgTgUgaAAQgaAAgTAUgABamzQgIAIAAANQAAAMAIAJQAIAJALAAQALAAAIgJQAIgJAAgMQAAgNgIgIQgIgJgLAAQgLAAgIAJg");
	this.shape_27.setTransform(18.6,41);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#DFF5F7").s().p("AgIALQgEgFAAgGQAAgFAEgFQAEgFAEAAQAFAAAEAFQAEAEAAAGQAAAGgEAFQgEAFgFAAQgEAAgEgFg");
	this.shape_28.setTransform(-14.4,64.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#DFF5F7").s().p("AgWAEQAAgJAJgIQAJgIAKAAQAKAAAHAFQgNAOgZAYQgHgIAAgKg");
	this.shape_29.setTransform(-12.7,10);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#DFF5F7").s().p("AhIASQAAgSARgMQAQgNAZgEIAOgBQAeAAAWAPQAVAPAAASIAAAFQhNAChBAGQgDgHAAgGg");
	this.shape_30.setTransform(-17.1,-0.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#DFF5F7").s().p("AgsALQgUgKgGgOQBBgGBNgCQgDATgVALQgVANgbAAQgZAAgTgLg");
	this.shape_31.setTransform(-17,4.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAdBKQgwgtgjgHQhNAAhQAMIgDgUQAdgCASgUIAFAAQBahKAYgXQAJAIAOAAQANAAAIgHIAEAEQgZAkAHAZQAlgHA6gbIBfgsQAMAZAZAKIgBAAQgJATAGAkIAKA8QAFBKhgALQgxgDgugpgABHgcIgrAnQAOANAZAcQAYAVAhACQAlgMAGgmQAGgigZgeQgOgDgMAAQgeAAgVAOg");
	this.shape_32.setTransform(-9.4,22.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#DFF5F7").s().p("AgZAPQAZgYANgOQANAJAAANQAAAJgJAIQgIAIgLAAQgOAAgJgJg");
	this.shape_33.setTransform(-11.7,10.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AitBhIgBhlQgCh9gygwIAYgPQAsAqAqAZQAzAfA7AOQAAAGAHACIAPACQANAbAyANQBKAVAHADIAggGQAAAMAKAIQAJAKAQAGQhOADhoAeQh3Aig0AHQgNAHAAAsQgBApgWADQgKglgBg7gAh+AtIBZgMQAugJATgWQgagDgogeQgmgbgmgBQgQAkAEBEg");
	this.shape_34.setTransform(-19,100.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#DFF5F7").s().p("Ag8AVQAAgSATgLQASgMAYAAQAVAAAQAIQAQAHAHALIh5AQg");
	this.shape_35.setTransform(6.3,96.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#DFF5F7").s().p("Ag3AqQgYgSAAgYQAAgXAYgSQAXgRAgAAQAhAAAXARQAYASgBAXQABAYgYASQgXARghABQgggBgXgRg");
	this.shape_36.setTransform(-3.1,81.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#DFF5F7").s().p("AgtAKQAAgUAQgQQARgQAVAAQAVAAAQAOIhPBHQgMgPAAgSg");
	this.shape_37.setTransform(0.9,1.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#DFF5F7").s().p("AgBAAIADAAIABABg");
	this.shape_38.setTransform(4,102.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#047391").s().p("AyhPlQirhoiEiRQgshjgRiRQgQiNAPiVQAQiaAsh6QAxiGBJhJQAcgbA3geQA3gdAegeQAfgfA3gwIBehQQGejQIjiYQHgiHJthkQBHAFDBgMQCigLBaASQgYCGhTFEQhKEcgXC1QhPAJhCAKQkgAqk6BaQjFA5lgB3QjwCsjqE1QiIC0j8F7QjCgni7hzg");
	this.shape_39.setTransform(-139.5,16.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgeAkQgZgcgOgLIArgpQAcgUAvAJQAZAegGAiQgGAmglAMQgegCgZgVg");
	this.shape_40.setTransform(0.4,24.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#EFDB89").s().p("AhKALQAUgZAxgrQAOAVAcAAQASAAAPgKQAOgJAGgQIADABQgGAPAAAPQAAAVAJAQIhfApQg3AbgoAHQgGgZAagkg");
	this.shape_41.setTransform(-1.8,11.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#DFF5F7").s().p("AgxAaIBPhHQAUAPAAAZQAAAJgDAIQgHAPgOAKQgPAJgPAAQgcAAgRgUg");
	this.shape_42.setTransform(2.5,3.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#DFF5F7").s().p("AgVAaIgBgCIgFAAQgQgGgJgJQgKgJAAgMIB5gQQAEAHAAAIQAAAQgTANQgSANgaAAQgMgBgJgCg");
	this.shape_43.setTransform(6.5,100.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#DFF5F7").s().p("AgbAAQAfgJAYAJQgNAFgPAAQgNAAgOgFg");
	this.shape_44.setTransform(14.3,14.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#DFF5F7").s().p("AgTgLQATgRAYAAQALAAAJADQgxAWgmAgQAEgZAUgPg");
	this.shape_45.setTransform(14,-15.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#DFF5F7").s().p("AgzgHQA2gVAxADQgHAMAAANQAAAKAFAKIgJAFQgXgJggAKQgYgKgNgXg");
	this.shape_46.setTransform(13,11.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AnJGfQBAipAohEQBGh5Bmg3QAngMDIgsQCWggBBgwQALgXAugwQApgqAJgkQAdgZgCg1QgCg4gngQIAJgFQAKARATALQAVALAZAAIAIgBQABCRhtBqQhaBXibA3QijARg8ATQh/ApgUBbIBEBEIgYAPQgegdgygMQhNCVg+BXg");
	this.shape_47.setTransform(-19.4,57.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#DFF5F7").s().p("AgRABQAAgLAHgMIAcAFQgIAZgVAPQgGgKAAgMg");
	this.shape_48.setTransform(19.3,11.6);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#DFF5F7").s().p("AhIATQABgPAFgMQAJgWASgMQASgNAVAAQAcAAAVAUQAUATAEAbQgWAKgLARQgugEg5AWQgIgQgBgVg");
	this.shape_49.setTransform(14.2,5.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#DFF5F7").s().p("AgPALQALgPAUgKIAAAIQAAALgEAKIgbgEg");
	this.shape_50.setTransform(19.9,8.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#DFF5F7").s().p("AhCAIIABgJQAmgjAwgVQAhAJANAfQg1Aag6AyQgWgWAAgdg");
	this.shape_51.setTransform(16.3,-12.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#DFF5F7").s().p("Ag6AdQA7gwA1gcQAEAOAAANQAAAbgUAUQgUAUgbABQgcgBgVgSg");
	this.shape_52.setTransform(17.6,-9.7);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#DFF5F7").s().p("Ag8A4QgZgYAAggQAAggAZgXQAZgXAjAAQAjAAAaAXQAZAXAAAgQAAAggZAYQgaAXgjAAQgjAAgZgXg");
	this.shape_53.setTransform(17.5,57.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#DFF5F7").s().p("AgMABQAAgGAEgGQAEgGAEAAQAFAAAEAGQAEAFAAAHIAAABIgTAQQgGgGAAgLg");
	this.shape_54.setTransform(23.5,75.6);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#DFF5F7").s().p("AgJAGIATgOQgBAIgEAEQgDAFgEAAQgDAAgEgDg");
	this.shape_55.setTransform(23.8,76.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#DFF5F7").s().p("AgLAdQgUgLgJgRQAYgNAHgbQAVAGAXALQAGAcAAAhIgIABQgZAAgTgLg");
	this.shape_56.setTransform(22.2,13.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#BFD1D0").s().p("AikG0IAhg8QgJgWgVgpQgVgqgIgWQA9kCAiiAQA6jfA9iPIAkAAQgHA6ALB7QAMCFgFBFQASATAlARQAWAKArARIhIH7Qh0AujBAHQAHgfATgkg");
	this.shape_57.setTransform(13.8,-194.9);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#F9D8CD").s().p("AhfgJQArgCAzgbQA1gdAfgGQAZAwgZArQgYApgwAPQhagLgQhIg");
	this.shape_58.setTransform(22.2,103.6);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#DFF5F7").s().p("AgOgCQgXgLgXgGQADgKAAgNIAAgIQATgIAVAAQAgAAAXARQAXASAAAXQAAAXgVARQgUARgdACQAAghgFgcg");
	this.shape_59.setTransform(27.3,11.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#DFF5F7").s().p("AgRAUQgIgIAAgMQAAgLAIgIQAHgKAKABQAKgBAIAKQAIAIAAALQAAAMgIAIQgIAJgKAAQgKAAgHgJg");
	this.shape_60.setTransform(29.5,-0.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#DFF5F7").s().p("AgrAvQgTgTAAgcQAAgaATgUQASgTAZAAQAZAAATATQATAUAAAaQAAAbgTAUQgSATgaAAQgZAAgSgTg");
	this.shape_61.setTransform(28.5,38.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgIAFQAMgYgEgMQATAHgJAXQgKAeAAACQgTgHALgTg");
	this.shape_62.setTransform(39,-119.1);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgBAQQgGgGABgJQABgKAKgIQAFAVgEAJQgCAFgDAAQgBAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAg");
	this.shape_63.setTransform(40.8,-126.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgFgRQAEgLAEAFQAGAFgBAOQgBAPgLAPQgFgdAEgOg");
	this.shape_64.setTransform(41.9,-131.2);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#C0F1F9").s().p("A16GAQBFgsCKhjQCGhgBKguQD8iaENgkQAWgIA6ggQAxgbAmgHQBGhIAahCQANgfgrgTIgbgMQgKgGAHgGQAOgxAngHQAcgFA/ASQFEg2BvgLQEcgcDLAoQiIAjkkAXQkgAWiGAlQgnAgghA/QBCA4BtANQBQAJCNgMQDWgUAYgBQCIgFBcAYQgyAThcAGQhuAEg1AEQheAFgzASQhDAWgXAxQABA4A1AcQAeARBIAZQAwABDqgJQC6gGBsAOQDzBrDhCzQq0CHrBASQhhAChhAAQqUAAoqhxg");
	this.shape_65.setTransform(60.6,129.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AgCAUQgEgFABgeQAJgJACALQABAKgEAMQgDALgBAAIgBAAg");
	this.shape_66.setTransform(43.2,-138.6);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgFATQACgwgCgMQALgRAAAoIgBA8QgDAFgCAAQgFAAAAgcg");
	this.shape_67.setTransform(44.4,-149.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgWCAQAEg7gCgLQgHgzADhDQAEhDAMg5QAJgCAIAGQALAGAGAAQgIAbgGBZQgEBKgQAfIAACKQgQgNACgsg");
	this.shape_68.setTransform(47.1,-177.9);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#C0F1F9").s().p("AEfQKQgBgmgKgUQgihKhRhCQhOhAhkgnQhogphngFQhtgGhXAlQgJgDgKAAQgaAAgUARQgTARgEAZQgnAkgcAxQAWjVAzkMQAZiBBLlbQCHpyAclvQBKAaCGgMQBLgHCggSQA0AjAQBNQAKAsAFBYQBWKIAwFLQBQInBKGZQgoAAgkACQgrACg/AIIhqAKIAAhFgAD7JcQALAfAAgfQAAgPgDAAQgCAAgGAPgADwG9QgCAhADAFQAEADAEgOQAFgOgCgLQgBgGgEAAQgDAAgEAEgAguDpIAAAtQABAdAKgVQABgegBgPQAAgRgEAAQgDAAgEAJgADjB0IAACVQAFAcADgDQACgDACgXQAGhDAGgHQgMgBABgxQAAgcgHAAQgCAAgEAEgAgigWQgKB1AVBKQABgzARiYQANh/gIg9QgZBqgJBegADXh0QABAIgCBXQgBA7AOgGQgBgHADhWQABg3gMAAIgDAAgADMkIQABAKgCAuQAAAlAMgTIABg3QAAgZgGAAQgCAAgEAGgAjgkYQgKATATAIQAAgDAMggQAJgWgVgHQAGAMgPAZgACXoxQArDPAKA6QgKi4gPhqQgXiYgxhjQAIBxAkCjgAjMlpQgBAKAGAFQAGAFAEgIQADgJgEgWQAMgPABgRQABgOgGgGQgGgFgDAMQgFAOAGAfQgNAIgBALgAiznxQgBAhAEAEQADAEAEgOQAFgPgCgKQgBgGgEAAQgDAAgFAEgAinp7QADAMgDAxQAAAoANgQIABg+QAAgcgHAAQgDAAgEAFgAiPwkQgMA6gDBDQgEBFAIAyQABAMgDA6QgCAtAPANIAAiKQATgfAEhMQAGhZAHgbQgFAAgLgGQgHgFgIAAIgFAAgAi+l8IAAAAg");
	this.shape_69.setTransform(60.6,-90.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AgFASIAAgrQAJgVABAdQABAQgBAbQgEAJgBAAQgEAAgBgRg");
	this.shape_70.setTransform(56.4,-64.4);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgQACQAJhbAYhqQAIA8gOCAQgQCXAAA0QgWhKALh4g");
	this.shape_71.setTransform(58.8,-93.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#D8D8D8").s().p("AgIECQiwgHiXgdIAAk8QAfg/BUgrQBOgoBqgNQBmgNBjAQQBnARBDAsQgGAxAGChQAECTgQBMQhzAPiEAAQgqAAgqgBg");
	this.shape_72.setTransform(59.4,-251.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#DFF5F7").s().p("AgVAIQgEglAZgXQATAIADAjQABASgBAsQgngEgEgpg");
	this.shape_73.setTransform(69.1,5);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#DFF5F7").s().p("AhABEQgcgcAAgoQAAgmAcgdQAbgcAlAAIABAAQAsAkAvA0IABAHQAAAogbAcQgcAcgmAAQglAAgbgcgAgLAXQAEAqAmADQACgsgCgTQgDghgVgIQgWAXAEAkg");
	this.shape_74.setTransform(68.2,3.4);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AitBJQBchWA+hLIATAQQgMAMACAZQASgOA8gJQA8gLAUgNIAaAHQgUANgIAWQhhAThEAcQhRAhg0Axg");
	this.shape_75.setTransform(72.5,58.5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AhGgKQARgPA0AAIBVAAIgIAGQgUANg6AIQg8AKgUAOQgCgZAOgLg");
	this.shape_76.setTransform(79.7,52.2);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#DFF5F7").s().p("AgMAQQgFgHAAgJQAAgSAOgGIAEgBQALAAAGAMQgPAOgEAZQgHgCgEgIg");
	this.shape_77.setTransform(72,64.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#DFF5F7").s().p("AgLAUQAGgXANgQQAEAHAAAHQAAAKgGAHQgGAIgGAAg");
	this.shape_78.setTransform(73,65);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#DFF5F7").s().p("AgsgrQAkABAYAZQAbAYACAkQgtgygsgkg");
	this.shape_79.setTransform(72.9,-1.8);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AnVF6QAAgGgIgCIgPgCQgJgYgBgKQgCgPAYgFQAkAWBYAAICXAAQA7gyBQhAQAEADADAAQAFAAAEgFQAEgGAAgIQCyiRBVhOQCMiEBUiBQANgbgXgjQgTgeARgOQBDgQAHBBQACAagKAXQgLAYgTAFQgHAegkAsQgjAqgGAhQhFA5jMCxQinCVhuBSQg9AXhQAGQgYACgYAAQg4AAg3gKg");
	this.shape_80.setTransform(29.6,55.2);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AgDAEQgkiggIhxQAvBiAXCYQAPBoAKC5QgKg6gpjQg");
	this.shape_81.setTransform(76.2,-147.2);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#F9D8CD").s().p("AhFggQA1gyBPggIALAaQgPAGAAATQAAAKAFAHQAFAIAGACQgDANABALQgBAiAXAbQAWAaAgABIAHgBIiaAVQhbANhCAGQAShXBEg8g");
	this.shape_82.setTransform(64.2,70.8);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#8AA09F").s().p("Ak9gYQBeAEDpgGQDXgGBdAIQh3AwjKAFIgnABQi/AAhUg2g");
	this.shape_83.setTransform(60,-206.6);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#8AA09F").s().p("AiJAoQiPgIgwgyQgDgRAPgEQBTgED1AOQDfAMBfgLQgFAphRAMIiOAIQhxAIhJAAIg1gBg");
	this.shape_84.setTransform(58.7,-217.9);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#F9D8CD").s().p("AnlBFIAAgrQACgiA1gFQAegDBHACQCXghDmgVQCGgMETgTIATBUQAIAwgDAuQhXAAi7gRQivgRhZADQgwABhEAPQhLATglAIQguAJgnAAQhHAAgwgfgAkLgLQgFAIAAAJQAAALAFAIQAFAHAHAAQAHAAAFgHQAFgIAAgLQAAgJgFgIQgFgIgHAAQgHAAgFAIgAAWgsQgJAHAAALQAAAMAJAHQAJAHAMAAQANAAAIgHQAJgIAAgLQAAgLgJgHQgIgIgNAAQgMAAgJAIg");
	this.shape_85.setTransform(106.8,97.8);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgFASQACgsgCgKQAKgSABAlIgBA2QgEAGgBAAQgFAAAAgZg");
	this.shape_86.setTransform(81.6,-113.2);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("ACVEfIAPgfQASgmAEhGQADglgBhiIg7hBQgCglgbgZQgagZgkgBQhIg8hVgbQhlghiCAJQgdAKgiASQgNggghgJQBWglBuAFQBnAGBoApQBkAnBOBAQBQBBAiBKQALATABAmIAABFIBpgLQBAgHAqgCIABAMQgOAAgLAKQgLAJgFAQIhSACQgLgRgTAAQgVAAgLATIgPAAQgjApgeBVQgUAHgEAPg");
	this.shape_87.setTransform(64.5,7.9);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#DFF5F7").s().p("AgKASQgFgHAAgLQAAgKAFgHQAFgIAFAAQAHAAAEAIQAFAHAAAKQAAALgFAHQgEAIgHAAQgFAAgFgIg");
	this.shape_88.setTransform(81.2,98.4);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#DFF5F7").s().p("AgLAEIABgEQAEgPASgHIgPAtQgIgIAAgLg");
	this.shape_89.setTransform(82.8,37.9);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgGATQAChUgBgIQANgGgBA9QgDBWABAGIgCABQgKAAABg4g");
	this.shape_90.setTransform(82.8,-94.6);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgLA/IAAiSQALgQAAAoQAAAwALACQgGAGgFBBQgBAYgCADIgBAAQgCAAgFgag");
	this.shape_91.setTransform(84.6,-70.3);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#DFF5F7").s().p("Ag1A/QgWgbAAgkQAAgJACgNIAFAAQAIAAAGgIQAGgHAAgMQAAgHgEgHQAWgaAeABQAfgBAXAbQAWAaAAAkQAAAhgSAZQgTAZgbAGIgMABQgegBgXgag");
	this.shape_92.setTransform(79.2,69.4);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AgDAUQgEgFACgfQAJgJACAMQABAKgEAMQgDAMgBAAIgCgBg");
	this.shape_93.setTransform(85.2,-44.1);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgEAAQAJgeAAAeQAAAPgDAAQgCAAgEgPg");
	this.shape_94.setTransform(86.3,-29.9);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#DFF5F7").s().p("AgsASIAQgtQAMgFANAAQATAAAPAKQAOAJAAANQAAANgOAKQgPAKgTAAQgaAAgPgPg");
	this.shape_95.setTransform(86.9,38.4);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#F9D8CD").s().p("AiKBnIAOgoQAPAPAaAAQAVAAAPgKQAOgKAAgOQAAgOgOgJQgPgKgVAAQgNAAgLAFQAehTAjgpIAPAAQgFAKgBALQAAARALALQALAMANAAQAPAAAMgMQAKgLAAgRQAAgMgHgLIBTgCQgDAHAAALQAAARAIANQAHANAMAGIgJACQgVgLgYAAQgmAAgcAaQgYAZAAAiQAAAdAPAXQASAWAdAIQhZgChqgIg");
	this.shape_96.setTransform(94.9,33.9);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#DFF5F7").s().p("AAAgIQATAAALAPIg7ACQALgRASAAg");
	this.shape_97.setTransform(95.1,22);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#DFF5F7").s().p("AgYATQgLgLAAgPQAAgLAFgKIA8gCQAGALAAAMQAAAPgKALQgLAMgPAAQgOAAgKgMg");
	this.shape_98.setTransform(95.2,25.9);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#DFF5F7").s().p("AgvgIQAYgRAdAAQAsAAAaAcQhVAKhCANQAIgWAUgMg");
	this.shape_99.setTransform(94.9,51.7);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#DFF5F7").s().p("Ag8AkQgZgVAAgdQAAgLADgKQBCgMBVgKQARAVAAAWQAAAdgZAVQgaAWgjAAQgjAAgZgWg");
	this.shape_100.setTransform(95.5,57.9);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#DFF5F7").s().p("AgYgBIAxABQgKACgNAAQgNAAgNgDg");
	this.shape_101.setTransform(103.3,45.5);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#F9D8CD").s().p("ALVUcIAAgLQAYgPgkgsQgwgxgMgTQg0hUg4grQh8ifjijYQlHk6gpgrQlDgLkSi2QhDgtiah2QiKhshXg2Qg+gdhsgDQg0gBiZAIQiGAHhJgHQhsgJhCgoQADgmA9gMQBPgPANgJQB3ADCzgVQDJgXBZgCQAMA1AEAXQAHAsABAnQAfgxgJhDQgGgrgghSQgkhdgJgnQgRhMASg8QAvgGBqALQCXAPAUABQBXAtBFBlIBtC7QBCBwBDA3QBbBKCGAKQgRgPh7hRQhohEgrgwQgZgqgjhRQgnhcgRghQhKiNh6gkQjOAHiDg2QirhHAoieQAaAJAOAYQAFAJAPAlQAXA+A9AIQA2gCAqgpQA4g3AQgIQCsgCDbA1ICwAsQBmAXBWAJQgLgxhEgIQhRABgggHQgcgHg2gYQg4gagdgHQhigYkIgPQjogNhygsQgRAFgbAFQARgIAKgMQAJgNAAgOQAAgYgbgSQgcgSgmAAQgnAAgbASQgcASAAAYQAAAWAWARQAWAQAhAEQh5APisgDQAfgHATgYQAUgXAAgeQAAgYgOgVQgNgUgWgLIAJgCQAHAFAJAAQASAAANgQQANgQAAgWQAAgJgEgLQCRgCCEAIQBnAiCpASQBiAKDOANQFDBuC1BVQEEB7CdCUQCPCUDMFLQBvC1AwBHQBcCIBWBhQB7C9ETD1IDeDEQB9ByBTBeQAxATA2ApQAQAMBNBBQBzBgBVAKIAAAWg");
	this.shape_102.setTransform(285.5,153.1);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#DFF5F7").s().p("AAXBVIgygCQgdgIgSgWQgSgXAAgdQAAgiAbgZQAcgaAlAAQAXAAAVALQAWALANAUQAOAVAAAWQAAAegUAXQgTAYgfAHg");
	this.shape_103.setTransform(103.5,36.9);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#BFD1D0").s().p("AhBIRQgShDgQijQgQicgWhHQBZhLgEjMQgBgfgJiKQgIhlAFg1QBCBJAgCCQAYBgALClIATERQAPCaAjBdQgmBNhzAAQgXAAgagCg");
	this.shape_104.setTransform(104.4,-203.8);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#DFF5F7").s().p("AgUASQgJgHABgLQgBgKAJgHQAJgIALAAQAMAAAIAIQAKAHgBAKQABAKgKAIQgIAIgMAAQgLAAgJgIg");
	this.shape_105.setTransform(111.2,95.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#DFF5F7").s().p("AgXgGQALgKAMAAQANAAALAJQALAIAFAPIhPABQAFgQALgHg");
	this.shape_106.setTransform(110.5,20.8);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#DFF5F7").s().p("AgPAgQgMgGgHgNQgIgNAAgPQAAgLADgIIBOgBQAEAKAAAKQAAAUgNAQQgNAPgRAAQgIAAgHgEg");
	this.shape_107.setTransform(110.5,26.1);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#8AA09F").s().p("AgwgVQAmhPBLgKQgKA2ggA+Ig0BpQg6g1AnhPg");
	this.shape_108.setTransform(138,-159.9);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#DFF5F7").s().p("AgUAcQgIgMgBgQQABgPAIgLQAJgNALAAQAMAAAJANQAIALABAPQgBAQgIAMQgJALgMAAQgLAAgJgLg");
	this.shape_109.setTransform(133.2,59.1);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#DFF5F7").s().p("AgjAFQAkgFAkgFQgbALgdAAIgQgBg");
	this.shape_110.setTransform(138.9,43.8);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#DFF5F7").s().p("AhGAmQgWgQAAgWQAAgWAcgTQAbgRAlAAQAmAAAbARQAcATAAAWQAAAOgKANQgKAMgQAIQgkAHgkAFQghgEgWgRg");
	this.shape_111.setTransform(136.9,38.4);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#F9D8CD").s().p("AkiBsQATgZAAgiQAAglgXgZQgWgaggAAQggAAgVAZQgGgMgLABIgGAAIgLgaQBGgeBhgTQgDAJAAAMQAAAfAZAVQAZAWAkgBQAkABAagWQAZgVAAgfQAAgXgRgVQB8gMDTgCQA3CjChBPQgGANgjAEQgkAEgHALQiagji7AFQiFADjWAcQAcgGASgYgACphQQgJALAAARQAAAQAJAMQAJALAMAAQANAAAIgLQAJgMAAgQQAAgRgJgLQgIgNgNAAQgMAAgJANg");
	this.shape_112.setTransform(114.1,64.5);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#8AA09F").s().p("Ag0BuQgbgOgDgBQAMhZAjgwQAog7BOgOQgMBLgVA0QgYA/gkApIgMAAQgQAAgOgGg");
	this.shape_113.setTransform(157.8,-147.7);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#D8D8D8").s().p("AgdA8QhfgqjBh5QC4gvDFA/QDRBDAtCKQgmAGgmAAQiBAAiOhAg");
	this.shape_114.setTransform(175.2,-185);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("Ag4ALQgPgTARgcQAUACAsgCQAoAAAOALQgSAug0AQQgjgGgPgUg");
	this.shape_115.setTransform(163.3,54.3);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#8AA09F").s().p("AhHBaQATiSB7ghQgKATgLAnQgNAogHARQgeBAhFAAIgCAAg");
	this.shape_116.setTransform(180.6,-142.9);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#DCE5E5").s().p("AA4CXQAihTAFg6Qhbg9hPBdIg/BUQglAxgbAPQgYgkAQguQAJgbAlg5QAkg2AJgeQAPgwgagnQg/gGgrAeQggAVgdAxIgvBKQgcAlgjAFQAPg8A8huQA5hqAMhIQC9BrB4A2QC1BPC1AkQgMATg0BnQgnBMgeAsQgQgfAZg7QAehGgDgfQACgNgSgEQgTgGgBgJQhGAdhFBnQgqA+gNAQQgiAqgjAYQAHguAlhZg");
	this.shape_117.setTransform(162.6,-163.6);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#6CABBA").s().p("ApDEHQj/gRoUhCQhNgZh1gXIjOgnQj9gwhzhAQBUgiDjg/QDKg5BjgwQCnAADYAUQBTAIEtAjQH0A6EvgPQDHgKESgYQD/gXD0gcQDggaELgwQBDASBJAsIB9BMQAfAMCiAcQB7AWArAsQi8A8kNArQhxASl6AvIniA8QkgAkjKAUQjLAVjhAAQiwAAi+gMg");
	this.shape_118.setTransform(54.6,197);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#047391").s().p("AKOLtQihiyiDhuQhzgzjDhOQjzhhhEgdQhJgMlqghQkOgYiHgvQggixhGmAQhElugijEQAKgLAagKQJ0AoA2AFQFnAhDwBGQEABKDqCNQC9ByDRC1IChDaQBcB/A7BiQAXBnAxBjQAkDJgjC2QgjCyhiCAQgUAJhUA6Qg+Arg+AHQi0jMhchmg");
	this.shape_119.setTransform(234.2,6.6);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#3F6970").s().p("AgsAqQgHgOgFgfQAJgJAsgTQAggQAJgUQAjAUgdAwQgGAJguA6QgZgDgLgXg");
	this.shape_120.setTransform(360.2,157.2);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#6CABBA").s().p("ANrU4QhBhrgfg0QAhgjB2hRQBkhEAlg8QBAiSAYhpQAjiWgPihQgpilhXitQg1hnh3jCQkzlHmVjBQnBjXoognQhLgGkCgBQjBgBiGgYQgEhWgRh3QgTiDgIhDQBxghBjATQBIAOBcAyQCQBPAMAFQBfArBdADIB8gcQBIgRAsgTQElA+E6ByQDXBNFfCWQHIDEDtFuQDtFuAeIsQglDihTDRQhLC9h1C2QgkAShaBDQhLA4g/ASQggg3hAhog");
	this.shape_121.setTransform(252.5,2.9);

	this.addChild(this.shape_121,this.shape_120,this.shape_119,this.shape_118,this.shape_117,this.shape_116,this.shape_115,this.shape_114,this.shape_113,this.shape_112,this.shape_111,this.shape_110,this.shape_109,this.shape_108,this.shape_107,this.shape_106,this.shape_105,this.shape_104,this.shape_103,this.shape_102,this.shape_101,this.shape_100,this.shape_99,this.shape_98,this.shape_97,this.shape_96,this.shape_95,this.shape_94,this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-410.8,-283,893.8,567);


(lib.sec1 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,0,4).p("AzuAAMAndAAA");
	this.shape.setTransform(-7.9,-295.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,0,0,4).p("AnGAAIONAA");
	this.shape_1.setTransform(43.2,312.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AzKABIAAgBMAmVAAAIAAABg");
	this.shape_2.setTransform(-8.3,-295.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006B33").s().p("AiPApQApghBJgaQAogQBXgdQAWAOAJAjQAGARAJAqQgLgBgXACQgYACgMAAQgMAJgTAGIgjABQhUAAhDgXg");
	this.shape_3.setTransform(-85.9,-161.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("EANuAvkQgSAAgHgGIAAgCIAAgXQAAgLgJgJQAGgJAPgfIAZjXQAPiMAAhWQAFgOADgrQADgnAHgQQgBgaAKhCQAIg6gFgdQAQgiAEg1QAEgvgFghQAMgdgBgyQgBg2AFgQQgBgVAEhGQAEg3gHgcQALgNgBgWQgFgaABgLIAJhJQAHgtgHgcQAIgYAEg2QAEg0AIgWIgGgfQAQg7gDhuQgDhvALgwIgCgOQgCgHgFgGQAIgXAEgsQADgqAKgZQABgtAMhJQAMhQACgbQgRgQAFgbQAEgYARgPQAAgGgDgOQgDgOAAgLQAFgKAUgJQAVgJAGgJQAFgIAFgXIAIgnQAJgqADg6QABgHAEgMQAEgMAAgGQABgKgFgVQgFgWAAgKQABg8gCgbQgEgugNgcQACgIACgNIACgUIgMggQgHgSgLgLQAEgRgIgaQgLgdgEgQQgCgZgNgpQgMgogDgfQgHhJAHiZQAIiWgIhGQAKgRgCgfIgFgvQACgRABgaQABgaACgQQgKgRACgeQABgRAHghQgGgGgBgMIABgWQAAhYgBgUQgDg5gLgpQAAgGAGgEQAHgEgBgHQgGgPgBgpQgBgngKgPQAMgOgDgYQgFgcgBgNIABgKQACgIAAgDQgBgEgEgIQgEgHAAgFIABgpQACgYgJgOQAVinhJjYQAFhTgXhCQg2gGhaAMIiUAYQg8AChHATQhCAChjAWQiEAegcAEQi3AbiAAuQgXACggAKIg2ASQg5ANiDAlQh2AhhHAPQgTAJgkAMIg3AVQABAcALA2QANA+ADAeQABAJAHAKQAJALABAGQABAaAOAlIAWA+QAOA2AYBuQAYBdAjA1QAEAkAVA0IAkBVQAKBIApBTQAAAPAGARIAJAdQAfA0AnBdQAzB6ANAbQAMAfA0B4QAnBcAWA9QBHBtAXBsQAKAEAEAJQAGALAEADQgSBKAMBaQABAJAGAVQAGASgBAHQgEB4AIAsQgBAGgFAJQgIAJgCAHQgBAFABAKIAAASQgEBFgRCZQgMA5gbBnQgTBaAABFQgLAXgDAxQgEBAgDAQQgLA7gHBFIgLB8QgHBVgEAiQgBALABAWIAAAlIgCAhQAAASACAMQgEARACAbQABAYgFARIAOBxQAJBFgEAlQANAWAFA4QAFBAAHATQABAZAKA9QAJA1gCAdQAPAnADAPQAFAZAWBQQASBCAEAnQACAVAAAiQABAbAMAPQgGAxATBPQABAhAIA8QAIA+ABAcIABAFQgSAEgUgBQgZAAgLgGQARgVgEgiIgNg/QALgSgFgaQgEgeAEgLQABgFgCgCQgCgDAAgDQACgggDgWQgEgWgKgYQAEgUgGgXIgIgeQgBgFABgNQABgMgBgGQgCgLgGgTQgIgVgCgKIgFghQgDgTgKgJQAEgMgHgcIgMgtQAAgXgEgVIgIgmIAAgkQgHgigHgwIgLhZIgJgzQgLhRgHhcIgJiuQgCgiAHg/QAIhDgBgeQAAgeAGhBQAFg9gCghQAHgLACgSIADgfQACgLAGgUQAGgUABgHQABgFgCgKIgCgQQAGgUAAgKIAJhiQAGg7AHgsIAQg5QAKgkgIgcQAagzAHhNIANiFQgEgJgBgNQgBgNgEgIQAOgUgDg1QgDgyAUgUQgYgcADhEQAEhMgOgfIAKgfQgLgFADgIQAFgOgEgMIgJglQgDgRADgQQgHgLgCgMIgDgYQgKgLgPgkQgOghgQgLQgCgUgJgRIgTghQgCgUgQghIgYg1QgQhCghgsQgHghgYgvQgbg3gJgaIgkhSQgWgygVgaQgPg2gIgZQgNgqgTgcQAHgHgFgKIgIgQIgFgZQgDgQgHgFIgMgtQgGgXgMgOQADgNgDgOQgVgdgVhBQgWhGgPgZQgQhagtiAQgQhfgYg2QggAGhQAEQhLAEgjAHQgGgIgWgDQgZgDgHgEQgKgBgVgIQgTgGgOAAQgVgNgYgYIgogqQAOgdgRgqQgXgtgFgSQAHgNgCgSIgFgkQACgIgJgEQgKgEgBgFQAHgbgEgfQgFgdgNgXQAAh6gbhaQAEgjgNg3IgZhgQAKgrgZg5QgBgHADgIQACgJgBgGQgGgdgIgrIgKg7QgCgIABgMIABgUQAAgDgFgFQgEgGAAgEIAAgVQgBgZgIg3IgKhLQgCgXgNgtQgMgpAAgZIAAgDIAlAAIAAACQAWBWAZCtQAZCrAWBVQAAA7ANBAIAaByQAJBjASBxIAiDJQARAzAFAWQALArAEAnQAFAKAKAFQAzACBDggQBNglAkgGQAIgCAIgHIAOgMQAFAAAFACQAGADAFgCQBLgaCSg2QCCgsBsgTQAPgIAngLQAlgKAQgKQAFgBAFACIAIACQAFgEAVgFQASgDAEgJQAhgEBBgVQA5gUAjgBQAFABADgFQAEgFADAAQBtgOCMgjIAZAAQA/gPBmgPICvgYICYgZQBagOBBgBQBTgCB4AOQAOgIAWAAQAYAAAKgEQALAUAOANQAOgJgBgXQAAgWgNgJQAAgqgFgfQgEgjgMgjIAAgoQgMgrgNhwQgLhggWg4QgDhIgShdIgfihIAAgCIAxAAQACBjAlBvQABA3AXBqQAXBqACA9QAHAYALBAQALA5AKAcQgBAiAMAxIAUBRQgEADAAALIABARQg/Bkg+BGQgRgEgJAKQgOAOgDABQgSAEgWAMQgXAPgMAGQgJgFgPAAQgUABgIgCQAcBcAFBjQACAWgDA7QgCA0ADAcIALBFQAHApABAYIAAB6QAABLADAuQAEAMACAVQADAvAABdQAAAEgEAIQgDAHABACQAAAGAFAKQAEAJAAAGQAAAHgEAOQgFAOAAAHQgBAKAFASQAFAUAAAKQABAvgEAzQgCAcgHA/QAEAygDCDQgCB3AHA0QALAyAgB3QAcBnAOBCQAMDFgDA9QgGCZg6BMIgHAqQgFAVgJAQQAFANgHASIgKAeQgDAMABAaQABAcgCAMIgWCJQgNBXgFA1QgDAhgBBAIgCBfIgEB0QgDBOgFAuIgNBfQgIA8gEAkQgCAYACAmQABAlgBAKQgCAigIBEQgGA7AEArQgECDgbDZQggD7gGBbIAAAbQABASgBAKQgBAHgHANQgHAOgBAIQgBANgBAYIgBAnQgBAVgBAqQgCAmgIAYQAGAEACAOQADASABADQgLALgEAaIgDAqQgKAEgOAAIgDgBgAt760QhJAcgoAhQBQAbBsgGQATgGALgJQANABAXgCQAXgCALAAQgJgpgFgUQgKgjgVgNQhYAdgqAQgEAQJghdQgEABABAFQgEAlAFAuQAEAqAKAkQARABAWgJQARgHARAGIBLgvQAogdATgiQgPgKgTgUQgJAAhQgOQgkgGgfAAQgPAAgOACg");
	this.shape_4.setTransform(0.1,8.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAjEuQgWgngFgDQgIgVgUgoQgVglgHgYQAIgiACg0QACg6ADgSQAAgGgHgFQgHgGgBgEQgBgFADgCQAEgDAAgCQgSg2gGgpQgIgxAFgzIAQglQALgZAPgFQAEgBAKAEQAJADAEgGIARAcQgFAJgSAfQgQAYgFAVQADASAYBUQARA9gDAvIAFAPQADAJABAHQghA+AcBRIAdBDQATApAGAcQgIAGgHAAQgMAAgKgSg");
	this.shape_5.setTransform(52.5,32.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFD8CC").s().p("EgDUAoeQgBgcgIg+QgIg8gBghQgVhPAGgxQgMgPgBgbQAAgigCgVQgEgngShCQgWhQgFgZQgDgPgPgnQACgdgJg1QgKg9gBgZQgHgTgFhAQgFg4gNgWQAEglgJhFIgOhxQAFgRgBgYQgCgbAEgRQgCgMAAgSIACghIAAglQgBgWABgLQAEgiAHhVIALh8QAHhFALg7QADgQAEhAQADgxALgXQAAhFAThaQAbhnAMg5QARiZAEhFIAAgSQgBgKABgFQACgHAIgJQAHgJABgGQgKgqAEh4QABgHgGgSQgGgVgBgJQgMhaAShKQgEgDgGgLQgEgJgKgEQgXhuhHhtQgWg9gnhcQg0h4gMgfQgNgbgzh6Qgnhdgfg0IgJgdQgGgRAAgPQgphTgKhIIgkhVQgVg0gEgkQgjg1gYhdQgYhugOg2IgWg+QgOglgBgaQgBgGgJgLQgHgKgBgJQgDgegNg+QgLg2gBgcIA3gVQAkgMATgJQBHgPB2ghQCDglA5gNIA2gSQAggKAXgCQCCguC3gbQAagECEgeQBjgWBCgCQBHgTA8gCICUgYQBagMA2AGQAXBCgFBTQBJDYgVCnQAJAOgCAYIgBApQAAAFAEAHQAEAIABAEQAAADgCAIIgBAKQABANAFAcQADAYgMAOQAKAPABAnQABApAGAPQABAHgHAEQgGAEAAAGQALApADA5QABAUAABYIgBAWQABAMAGAGQgHAhgBARQgCAeAKARQgCAQgBAaQgBAagCARIAFAvQACAfgKARQAIBGgICWQgHCZAHBJQADAfAMAoQANApACAZQAEAQALAdQAIAagEARQALALAHASIAMAgIgCAWQgCANgCAIQANAcAEAuQACAbgBA8QAAAKAFAWQAFAVgBAKQAAAGgEAMQgEAMgBAHQgDA6gJAqIgIAnQgFAXgFAGQgGAJgVAJQgUAJgFAKQAAALADAOQADAOAAAGQgRAPgEAYQgFAbARAQQgCAbgMBQQgMBJgBAtQgKAZgDAqQgEAsgIAXQAFAGACAHIACAOQgLAwADBvQADBugQA7IAGAfQgIAWgEA0QgEA2gIAYQAHAcgHAtIgJBJQgBALAFAaQABAWgLANQAHAcgEA3QgEBGABAVQgFAQABA2QABAygMAdQAFAhgEAvQgEA1gQAiQAFAdgIA6QgKBCABAaQgHAQgDAnQgDArgFAOQAABWgPCMIgZDXQgPAfgGAJQAJAJAAALIAAAXgAEFoMQgPAFgMAZIgQAlQgFAzAIAxQAHApASA2QAAACgEADQgEACABAFQACAEAHAGQAGAFABAGQgDASgDA8QgCA0gIAiQAIAYAVAlQAWAmAHAVQAGADAWAnQAPAcAVgQQgGgcgSgpIgdhBQgehRAig+QgBgHgDgJIgFgPQAEgxgSg9QgZhUgDgSQAEgVAQgYQAVgfAEgJIgSgcQgFAGgIgDQgIgDgEAAIgCAAgAIvhuIgBAJQgHAzgaAsQgIAMgBAFQAAAHAMAGQAWALAOg6QAOg6gKgNQgDgEgDgIQATAcAAgNQAAgLAGgOQAOghAJgZIAJgGIABgBQAGgDADgFQAQAWAngYIAFgDQgBAsgFAtQgFAnAJAUQAFAKAHADIAHACIAHhyIAAAAIgMg5QAkgaAFgaIgBgUIheA5IACgDQAPgRA2g0QAsgqAWggQgBgHACgJQADgKgCgHIAFAAQAAgNgIgBQgFgBgEAEQgLgHgQADQgOADgMASQgMARgIABIgCgDIgIAGIAAABIgGAGIgCgBQgCADAAACIjhDSQghARgkAoIAEADIAEAEQgPALgQAIQAAAFgCAEIgEAIQgDgEgCgBIgDAAIgDADQgCAEADAKQADALAGAIQAVAWApgPQAggMAFgDQAFgDgBgGQgCgKAfgcQALAAAOgCQAcgEgCgHQAAgCgRgOIAEgDIARgHIAFACQAEgIgGgFQgHgFgZATIgDgEQAPgLATgHgAKPjgIBJgsQAbgQAEgUIgBgRg");
	this.shape_6.setTransform(23.5,53.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF0000").s().p("Ag7AUQgGgIgDgLQgDgIACgEIADgDIADAAQACABADAEIgCACIAAABIAAAAQAAABgBAAQAAAAAAABQAAAAgBAAQAAAAAAAAQgBgBAAgBQAAgBAAgBQgBAAAAgBQAAAAAAAAQgBABAAAAQAAAAAAABQAAABAAAAQAAABABABQgBAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAgBIACAGIADAAQAEAQANAIQASAKAcgLQAmgPgBgEQgCgKAdgbIAHAAQgfAcACAIQABAGgFADQgFADggAMQgPAHgNAAQgUAAgMgOg");
	this.shape_7.setTransform(65.3,49.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF0000").s().p("AgBgDQAAABABAAQAAABAAAAQAAAAAAAAQAAAAABAAIABAEIgCABg");
	this.shape_8.setTransform(58.6,48.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF0000").s().p("AAAgBIAAAAIAAAAIABADIgBAAIAAgDg");
	this.shape_9.setTransform(58.9,48.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF0000").s().p("AAAACQAAgBAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQABAAAAACIgBAAg");
	this.shape_10.setTransform(58.8,48.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF0000").s().p("AAAgCIAAAAIABAEIgBABIAAgFg");
	this.shape_11.setTransform(59.2,48.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FF0000").s().p("AAAAAIABAAIAAAAg");
	this.shape_12.setTransform(59.2,49.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF0000").s().p("AguAbQgNgIgEgQIACgBIAEADQADAJAHAGIACABIACADIABAAQAOAGAYgHIAFAAIgCgBIABgBIAhgOQgDgLAcgbIAGABQgdAbACAKQACAEgnAPQgOAGgMAAQgLAAgJgFgAAhAHIAAABIABgCg");
	this.shape_13.setTransform(65.3,48.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FF0000").s().p("AAAgBIAAgDIABAHIgBABIAAgFg");
	this.shape_14.setTransform(59.4,48.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FF0000").s().p("AAAAAIAAAAIABABg");
	this.shape_15.setTransform(59.3,49.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FF0000").s().p("AADAHQgEgGgEgIIAFAHQADAGACACg");
	this.shape_16.setTransform(60.1,50.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AhTA4IAEgHQACgFAAgEQAQgJAPgKIAigYQASgPASgIIACgGQAAgBAAgBQAAgBAAAAQAAgBgBAAQAAAAgBgBIAagKQAUgHALgKIADAEQgLAIgIAVQgFANAIAMIgJAHIgRAPIgPAGIAOgQIgPAEQgnALgVAaIgvASg");
	this.shape_17.setTransform(67.8,42.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FF0000").s().p("AglAcIAtgqQAOgJAQgIIgEAFIADABQgWALgQAOQgNAKgUAWg");
	this.shape_18.setTransform(66.6,41.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFD8CC").s().p("AgkAcQAUgVANgJQAQgPAWgLQAAAAABABQAAAAAAAAQABABAAABQAAAAAAABIgCAHQgSAHgSANIgiAag");
	this.shape_19.setTransform(66.8,41.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FF0000").s().p("AgKASIAAAAQgDgCgDgGIgGgJIgBgBIACAAIAAgBIAtgSIgCADQgOASAPALQgMAGgSABg");
	this.shape_20.setTransform(61.8,49.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FF0000").s().p("AghAbQAignAhgRIgRAQQgTANgbAeg");
	this.shape_21.setTransform(65.7,41.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FF0000").s().p("AgSABQASgBAMgEIAHAEIgCAAIABAAQgNAFgHAAQgJAAgHgEg");
	this.shape_22.setTransform(62.9,51.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FF0000").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_23.setTransform(64.9,51.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FF0000").s().p("AgIACQAIgCAJgFIgLALIgGgEg");
	this.shape_24.setTransform(65.1,50.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FF0000").s().p("AgcAAIACgDIA+gZIgFAGIgCgCIAAAEIgkAnQgKAGgKAEQgPgMAOgRg");
	this.shape_25.setTransform(67,47.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FF0000").s().p("AAPgTIgCAKIAJgJQgaAbgSALg");
	this.shape_26.setTransform(68.4,47.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FF0000").s().p("AgeAaIANgOQARgLAbgbIAEABQgcAZADANIghAOIgBAAg");
	this.shape_27.setTransform(68,48.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FF0000").s().p("AAXgPIAPgEIgOAQIg9AXQAVgYAngLg");
	this.shape_28.setTransform(68.1,45.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FF0000").s().p("AgSAEQAOgFARgHQAMgEALgHQgEAFgQAHQgQAHgGAEQgQAHgNAJg");
	this.shape_29.setTransform(71.2,37.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FF0000").s().p("AgBgDIABgCIAEADIgIAIg");
	this.shape_30.setTransform(70.2,45.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FF0000").s().p("AgQASQAQgHACgFQAKgGAJgOIADgDIAQgNQgJALgOATQgOAOgUAIIgXAJQAHgGARgHg");
	this.shape_31.setTransform(74.6,34.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FF0000").s().p("AgLAIIACgDIAKgJIALgEIgTARg");
	this.shape_32.setTransform(72,44.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FF0000").s().p("AgQAMIATgSIAOgFIgbAXg");
	this.shape_33.setTransform(72.9,44.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FF0000").s().p("AgIAEIAFgEIAMgGIgJAKIgCADg");
	this.shape_34.setTransform(71.1,44.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FF0000").s().p("AgTAPIAcgYIAKgFIABACQgMAIgSARIgCACg");
	this.shape_35.setTransform(73.8,44.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FF0000").s().p("AhIA3IAFgFIAWgJQAXgIANgPQAMgSAKgLIAmgcIABAAQAJgFAEgEIAIgHQgBAGgFAFQgFAGgQAJQgRAJgKALQgIAHgIALQgIAMgHAHQgLALgUAHIgZAKg");
	this.shape_36.setTransform(77.3,33);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FF0000").s().p("AALgKIADAEIgQANIgLAEg");
	this.shape_37.setTransform(73.6,42.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FF0000").s().p("AAHgGIAEADIgIAFIgNAFg");
	this.shape_38.setTransform(74.4,42.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FF0000").s().p("AAEgDIAAABIgHAGg");
	this.shape_39.setTransform(74.3,42.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgQANIAagZIAHAKQgRAEgPAMg");
	this.shape_40.setTransform(76.4,40.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FF0000").s().p("ABthnIADACIADAFQgHAHgSAIQgBAEAEACQAEACAAABIgBABQgPAOgOAKQgZASgJALQgGAIABAIQABACgDACQgEAEgPAIQgXAOgTAaIgSAPQgBAGgDAEQgLAHgMAFQgUAHgOAGg");
	this.shape_41.setTransform(80.7,27.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FF0000").s().p("AgGACIAQgNIgCAEQgIALgJAIQACgEABgGg");
	this.shape_42.setTransform(75.9,34.3);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FF0000").s().p("AACgCIADACIgJADg");
	this.shape_43.setTransform(75.2,42.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FF0000").s().p("AgQAFQAWgRAIAFQAGAFgFAGIgEgCQADgDgDgBQgFgDgTAOg");
	this.shape_44.setTransform(76.9,41.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("Ah8B2QAIgHAJgMQAIgNAIgHQALgLAQgJQARgJAFgGQAFgFAAgGQAcgWANgVQAigaALgWQAGgOgEgJQAIgCAMgRQAMgSAOgDQARgCAKAGQgIAIgMAXQgGANgCAJIgoAnQgyAdgZAdQgSATgEAOIAKADQAAgDAGgKIAAAAIAtguQASgNAXgNIAEgCIiGCBQglAAgOALg");
	this.shape_45.setTransform(88.5,24);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FF0000").s().p("AAEgDIAEACIgPAFIALgHg");
	this.shape_46.setTransform(77.2,42.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FF0000").s().p("AgMAFQATgOAEADQAEACgEAEIgDgBIgMAGIgFACg");
	this.shape_47.setTransform(76.8,41.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FF0000").s().p("AgWAMQAUgQAJgJQARANABABQACAHgbAEQgNACgLAAg");
	this.shape_48.setTransform(75.1,44.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FF0000").s().p("AgVAXQAPgIAEgEQACgDAAgDQgBgGAEgIQAJgLAZgSQAOgKAPgOIgGANQgFAEgPALQghAYgDAKIgDANIgLAJIAAABIgIAFQgQAIgPAOIgQANQATgaAZgOg");
	this.shape_49.setTransform(83.7,26.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FF0000").s().p("AghAHQAIgSAMgJQANgLAkAAIgJAIIgGAEQgBgKgEANIgCABIgMgGIADAMIgLAIIAFAGIgcAbQgJgMAFgNg");
	this.shape_50.setTransform(77.8,38.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FF0000").s().p("AgGAAIALgGIACAGIgIAHg");
	this.shape_51.setTransform(77.7,38.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FF0000").s().p("AgFAAIAHgIIAEAOIAAABIgGACg");
	this.shape_52.setTransform(78.2,39);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FF0000").s().p("AALgHIAIgFIglAZQAPgNAOgHg");
	this.shape_53.setTransform(80.6,30.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FF0000").s().p("AgFgHIAFgCIAAgBIAGASIAAADg");
	this.shape_54.setTransform(78.8,40.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FF0000").s().p("AgFgFIALAFIgIAGg");
	this.shape_55.setTransform(78.6,36.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FF0000").s().p("AgDgCQADgIAEgFIgDAfg");
	this.shape_56.setTransform(79.4,40);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FF0000").s().p("AAAAAIAAgCIABAFg");
	this.shape_57.setTransform(79.6,42);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FF0000").s().p("AgPBCQgLgFAAgHQAAgFAJgPQAXgqAHgyIABgJIADAEQADAIADADQAKANgNA5QgMAygQAAQgDAAgEgCg");
	this.shape_58.setTransform(78,48.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FF0000").s().p("AgHABIAIgDIABAAIAAgBIAFgEIABACIgNANg");
	this.shape_59.setTransform(79.1,37.2);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FF0000").s().p("AgGAAIANgOIgBAOIAAACQgGAFgCAIIgEgPg");
	this.shape_60.setTransform(79.2,38.1);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FF0000").s().p("AACAAIgDADQACgLABAIg");
	this.shape_61.setTransform(79.7,36.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FF0000").s().p("AgCAAIAFgBIgEADg");
	this.shape_62.setTransform(80.2,36.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FF0000").s().p("AhOBIICGiBIAXgOIgQAPQguAqgZAsIgDAEIgYAOIgBABIglAXg");
	this.shape_63.setTransform(89.4,27.9);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AABgCIAGAAIgMAGg");
	this.shape_64.setTransform(81.2,35.6);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FF0000").s().p("AgVAYIgDgHIAEgeQAIgIAMgIIAZgNQgJAZgOAfQgEAOAAALQAAABAAABQAAAAAAABQAAAAgBABQAAAAgBAAQgEAAgNgTg");
	this.shape_65.setTransform(82,39.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FF0000").s().p("AgXAOIABgOIAGgGIAOgIIAMAAIAOgBIAAABIgCAEIgWALQgPAIgIAHg");
	this.shape_66.setTransform(82.3,36.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FF0000").s().p("AgZARQAEgLAegVQAQgLAEgFIgIANIgJAHQgiAXABALIABACIgIAHIADgPg");
	this.shape_67.setTransform(86.8,24.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFD8CC").s().p("AgUATQgCgKAigXIAJgHQgPAVgaAWg");
	this.shape_68.setTransform(86.7,25.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FF0000").s().p("AgwAtQAEgOASgTQAagbAxgfIgPAQQgnAbgVAWQgOAQgDAMg");
	this.shape_69.setTransform(89.2,26.1);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FF0000").s().p("AgVALQAVgWAngbIgVAVQggAYgMAUIgBAAIgLAMQADgMAOgQg");
	this.shape_70.setTransform(88.6,26.9);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FF0000").s().p("AgEAFIAJgKQgFAHAAAEg");
	this.shape_71.setTransform(85.3,30.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgCAAIAAAAQADAAADgCIAAABIgIAEg");
	this.shape_72.setTransform(85.1,35.2);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FF0000").s().p("AASgKQgCACgHARIgMABIgOABg");
	this.shape_73.setTransform(83.8,34.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FF0000").s().p("AABgJIABgBQABAAAEAJIgHAJQgBACgFABQAGgRABgDg");
	this.shape_74.setTransform(85.5,33.9);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FF0000").s().p("AACgEIACADQgDADgEADg");
	this.shape_75.setTransform(86,34.3);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FF0000").s().p("AAXgVIgtAsQANgVAggXg");
	this.shape_76.setTransform(88.2,27.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FF0000").s().p("AgKACIAVgMQgKAKgGALQgEgJgBAAg");
	this.shape_77.setTransform(86.9,32.6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FF0000").s().p("AgIAKQAHgKAJgLIABgBQgLAWgEADg");
	this.shape_78.setTransform(87.3,32.7);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AADAAIAQgNIAAAAIAQgLQAEgEgBgEQAfgegHACIgNAJIgNANQAAgIAHgQIAZgYIAAgBQABAIgCAJQgDAKABAHQgVAfgsAoQg1A1gPARQAbguAsgqg");
	this.shape_79.setTransform(95.4,22.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FF0000").s().p("AAygvIACARQgFAUgbAOIhHAsg");
	this.shape_80.setTransform(94.3,25.7);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FF0000").s().p("AgLAOQgDgCABgEQAQgIAGgFIgDgFIgCgCIAEgFIAGACQgCAOgTASQAAgBgEgCg");
	this.shape_81.setTransform(91.2,18.5);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FF0000").s().p("AgKAMQAUgTACgOQAEABABgDQgBAUggAbg");
	this.shape_82.setTransform(91.5,19.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AAAgBIABABIgBACQgBgCABgBg");
	this.shape_83.setTransform(91.9,16.9);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FF0000").s().p("AACBTQgFgDgFgKQgJgUAEgnQAFgrABgsIAEgCIABAIQgBAhgFAxQgFAvANAQIAAADIABgBIADABIAAgDIABgBIgBgBIAGhjIgJgsIABgNIACgBIALA5IgHBwg");
	this.shape_84.setTransform(93.3,41.3);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FF0000").s().p("Ag3AlQAEgEANgYIBdg4IABAVQgGAagjAXIgCgJIgKABIAAARIgDADQgVANgOAAQgNAAgHgLg");
	this.shape_85.setTransform(92.2,30.3);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FF0000").s().p("AAAgGIABALIgBADg");
	this.shape_86.setTransform(92.6,32.8);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FF0000").s().p("AgPAWQAhgbABgUQABgDgCgEIAAgBIAAgBIgBAAIAGAAQAEAJgHAOQgLAUggAag");
	this.shape_87.setTransform(91.3,19.3);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FF0000").s().p("AgCACIAFgEQABACgBADg");
	this.shape_88.setTransform(92.4,16.5);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FF0000").s().p("AgDAKQADgxABghIAEAUIgFA+QgCAmAGAQIAAAJQgMgQAFgvg");
	this.shape_89.setTransform(92.8,41.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FF0000").s().p("AgBAFQABgEgBgCIACgDIAAAAIABABIAAABIAAAFQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAAAAAIgBAAg");
	this.shape_90.setTransform(93,16.3);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FF0000").s().p("AAAgCIABgBIgBAHg");
	this.shape_91.setTransform(92.9,33.7);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FF0000").s().p("AgBgFIADgBIAAALIgCACg");
	this.shape_92.setTransform(92.8,32.6);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FF0000").s().p("AAAgFIABAJIgBACg");
	this.shape_93.setTransform(93.1,32.6);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FF0000").s().p("AAAAAIAAAAIAAABg");
	this.shape_94.setTransform(93.3,49);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FF0000").s().p("AgBgDIABgJIAAgCIACALIgBASg");
	this.shape_95.setTransform(93.2,34.6);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FF0000").s().p("AAAgDIABgCIgBALg");
	this.shape_96.setTransform(93.4,33.5);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FF0000").s().p("AgBgEIADAAIAAAIIgCABg");
	this.shape_97.setTransform(93.3,32.5);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FF0000").s().p("AgBABIACgBIABABg");
	this.shape_98.setTransform(93.4,15.6);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FF0000").s().p("AAAAAIABAAIAAABIgBgBg");
	this.shape_99.setTransform(93.6,49);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FF0000").s().p("AgBADIABgHIACAFIAAACIgCACg");
	this.shape_100.setTransform(93.5,48.5);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FF0000").s().p("AgDAFIADg/IAFAYIgFBdQgHgRAEglg");
	this.shape_101.setTransform(93.3,42.1);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FF0000").s().p("AAAAAIAAAAIAAAAg");
	this.shape_102.setTransform(93.8,48.7);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FF0000").s().p("AgEBCIAEhdIgDgYIABgUIAHAsIgFBjIgEgGg");
	this.shape_103.setTransform(93.8,41.4);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FF0000").s().p("AgLADIAngWIgRAQIgmAXg");
	this.shape_104.setTransform(95.4,21);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FF0000").s().p("AgIABIAmgWIgQAPIgDACQgVAMgTAPg");
	this.shape_105.setTransform(93.5,22.8);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FF0000").s().p("AgEAEQARgJACgDQABgBgBgFIAEgEIABAEIABADIgTAQIAAAAIgWAOg");
	this.shape_106.setTransform(97.1,20.1);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FF0000").s().p("AATgSQgCAIADAHIgnAWg");
	this.shape_107.setTransform(96.2,19.4);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FF0000").s().p("AgHAEQAKgVAIgIIAFADQgHAEgMAYIgFAMIgHAIQACgJAGgNg");
	this.shape_108.setTransform(99.8,14.8);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FF0000").s().p("AgCgCIAFgIQgDALABAGIgCAEQgCgHABgGg");
	this.shape_109.setTransform(98.4,17.8);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FF0000").s().p("AAJgIQACAFgCABQgCACgQAJg");
	this.shape_110.setTransform(97.6,19.5);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FF0000").s().p("AgKAJQALgZAHgDIAIAIIAAAAIgEAAIgBgFQgHAFgKAWIAAAAIgKAJgAALgQIABAAIgCAAg");
	this.shape_111.setTransform(100.5,14.6);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FF0000").s().p("AAJgIQABAEgEAEIgOAJg");
	this.shape_112.setTransform(98.3,19.7);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FF0000").s().p("AgCgDIAIgJQgGAOAAAHIgEAFQgCgHAEgKg");
	this.shape_113.setTransform(99.1,17.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FF0000").s().p("AgLALIgBgEIAMgLIAMgIQAHgDgdAdg");
	this.shape_114.setTransform(100.4,17.4);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FF0000").s().p("AAGgMIAAAEIAFAAIgVAVQAKgUAGgFg");
	this.shape_115.setTransform(101,14.3);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FF0000").s().p("AADAHIgBgGQgCgDgDACIgEgCQAEgEADABQAIABAAALg");
	this.shape_116.setTransform(101.8,12.6);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FF0000").s().p("AgDgCQADgDACAFIABAEg");
	this.shape_117.setTransform(101.8,12.8);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#006B33").s().p("AheBUQgJgkgFgqQgEgsADglQAAgFADgBQArgFA2AJQBNAOAJAAQAUAUAOAKQgSAhgpAcIhJAvQgQgGgSAHQgTAIgQAAIgEAAg");
	this.shape_118.setTransform(114.2,-197.4);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#00A33D").s().p("AwdKbQgJgFgGgKQgDgogLgqQgGgXgQgyIgijKQgThxgIhjIgbhvQgMhAgBg8QgWhUgYirQgZiugWhVMAmVAAAIAfCgQASBdACBJQAWA3AMBgQANBxALArIAAAlQAMAkAFAiQAEAfAAAqQANAKABAWQABAWgPAKQgNgOgLgTQgKAEgYAAQgWAAgOAIQh4gOhUACQhAABhaANIiZAZIivAZQhmAOg/AQIgYAAQiMAjhtANQgDABgEAFQgEAEgFgBQgiABg6AUQhAAWghADQgEAJgSAEQgWAEgFAEIgIgCQgFgCgFABQgPALglAKQgoALgOAIQhtATiBAsQiTA2hKAaQgGABgFgCQgGgDgEABIgPALQgIAIgIACQgjAFhOAmQg+AegxAAIgHAAg");
	this.shape_119.setTransform(-1,-229);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#000000").s().p("AgBAAIABgDQAAAAABABQAAAAABAAQAAABAAABQAAAAAAAAIgCAEQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAAAg");
	this.shape_120.setTransform(222.6,-208.6);

	this.addChild(this.shape_120,this.shape_119,this.shape_118,this.shape_117,this.shape_116,this.shape_115,this.shape_114,this.shape_113,this.shape_112,this.shape_111,this.shape_110,this.shape_109,this.shape_108,this.shape_107,this.shape_106,this.shape_105,this.shape_104,this.shape_103,this.shape_102,this.shape_101,this.shape_100,this.shape_99,this.shape_98,this.shape_97,this.shape_96,this.shape_95,this.shape_94,this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-134.7,-296,357.6,609);


(lib.quemaduras = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag+BXIAJgaQAXANAYAAQAQAAAKgIQAJgHAAgNQAAgNgIgIQgIgHgSgIQgzgRAAgkQAAgYASgQQASgRAcAAQAcAAAUAMIgJAaQgTgMgUAAQgNAAgJAIQgIAHAAAMQAAAMAIAHQAIAGASAIQAaAKAMALQANAOAAAVQAAAbgTAPQgUARgfAAQgfAAgYgOg");
	this.shape.setTransform(179.1,20.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag9BUQgPgQAAgXQAAgjAegRQAegSA3AAIAAgEQAAgtgqAAQgdAAgWAPIgIgYQAbgRAjAAQBKAAAABQIAABGQAAAbADATIggAAIgDgYIgBAAQgJANgOAHQgRAJgSAAQgbAAgRgRgAgpApQAAARAKAJQAJAIAOAAQAQAAAOgKQALgJAFgOQABgDAAgIIAAgfIgHAAQhJAAAAApg");
	this.shape_1.setTransform(161.1,20.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgtBjIAAiDQAAgrgCgSIAfAAIABAmIABAAQAHgUANgLQAPgLARAAQAFAAAFABIAAAgIgMAAQgSAAgNANQgLAMgDATIgCB3g");
	this.shape_2.setTransform(146.8,20.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ag7BSQgWgWAAguIAAhvIAjAAIAABpQAAA9ArAAQAPAAANgKQALgIAGgOQADgHAAgLIAAh0IAkAAIAACKQAAAfABAWIgfAAIgCgfIgBAAQgJAOgOAJQgRANgWAAQgbAAgSgRg");
	this.shape_3.setTransform(128.1,20.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhCB1QgYgcAAgsQAAgtAagdQAZgcAkAAQATAAAQAJQAOAIAHANIABAAIAAh0IAjAAIAADoQAAAfACATIggAAIgBghIgBAAQgIARgRAKQgSALgVAAQgjAAgYgbgAgngHQgPASAAAgQAAAgAOATQAQAVAZAAQASAAAOgLQAPgMAEgTQACgEAAgLIAAghQAAgLgCgFQgEgPgNgLQgOgMgTAAQgZAAgQAWg");
	this.shape_4.setTransform(105.2,16.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag8BUQgQgQABgXQAAgjAdgRQAegSA3AAIAAgEQgBgtgpAAQgdAAgWAPIgIgYQAbgRAjAAQBKAAAABQIAABGQAAAeACAQIgfAAIgDgYIgCAAQgHAMgQAIQgQAJgSAAQgbAAgQgRgAgoApQgBARALAJQAIAIAOAAQARAAANgKQAMgJAEgOQABgFABgGIAAgfIgHAAQhJAAAAApg");
	this.shape_5.setTransform(84.4,20.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ABoBjIAAhsQAAg7gpAAQgPAAgMAJQgKAJgGANQgCAJAAAIIAAB3IghAAIAAhyQAAgYgKgOQgLgQgUABQgPgBgMALQgMALgEAOQgDAGAAALIAABzIgiAAIAAiMIgCg0IAfAAIACAgIABAAQAUgkApAAQATAAAPALQAMAKAHARIABAAQAIgOANgLQATgNAXAAQAZgBASASQAVAWAAAsIAABxg");
	this.shape_6.setTransform(58.6,20.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("Ag7BJQgZgaAAgsQAAgrAZgdQAZgfAnABQAqAAAWAfQAQAZAAAjQAAAIgCAHIiFgBQABAiATARQARAQAbAAQAeAAAXgJIAHAZQgcAMglgBQgqAAgagbgAgjg3QgMAQgDAWIBlAAQAAgWgKgPQgNgUgagBQgWABgPATg");
	this.shape_7.setTransform(31.9,20.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("Ag7BSQgWgWAAguIAAhvIAjAAIAABpQAAA9AsAAQAOAAANgKQAMgIAFgOQADgIAAgKIAAh0IAjAAIAACKQAAAfACAWIgfAAIgCgfIgBAAQgIAOgOAJQgTANgVAAQgcAAgRgRg");
	this.shape_8.setTransform(10.8,20.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AA2CKIAAhtIgBAAQgTAigqAAQgjAAgXgaQgYgcAAgqQAAgyAdgdQAYgZAjAAQAoAAARAiIABAAIABgeIAiAAQgCAYAAAeIAADZgAgnhYQgPAUAAAhQAAAfAOASQAPAVAaAAQARAAAOgKQANgKAGgQQADgJAAgIIAAgkQAAgIgBgHQgFgRgNgLQgOgMgTAAQgZAAgQAVg");
	this.shape_9.setTransform(-12,24.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("Ag9BUQgPgQAAgXQAAgjAegRQAegSA3AAIAAgEQAAgtgqAAQgdAAgWAPIgIgYQAbgRAjAAQBKAAAABQIAABGQAAAbADATIggAAIgDgYIgBAAQgJAMgOAIQgRAJgRAAQgcAAgRgRgAgoApQAAARAJAJQAJAIAOAAQAQAAAOgKQALgJAFgOQACgFAAgGIAAgfIgHAAQhJAAAAApg");
	this.shape_10.setTransform(181.7,-27.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AguBiIABiCQAAglgCgYIAfAAIABAmIACAAQAGgUANgLQAPgMASAAIAJACIAAAgIgMAAQgTAAgMAMQgLANgDAUIgCARIAABkg");
	this.shape_11.setTransform(167.4,-27.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("Ag9BUQgPgQAAgXQAAgjAegRQAegSA3AAIAAgEQAAgtgqAAQgdAAgWAPIgIgYQAbgRAjAAQBKAAAABQIAABGQAAAbADATIggAAIgDgYIgBAAQgJAMgPAIQgQAJgSAAQgbAAgRgRgAgpApQAAARAKAJQAJAIAOAAQAQAAAOgKQALgJAFgOQABgFAAgGIAAgfIgHAAQhJAAAAApg");
	this.shape_12.setTransform(149.6,-27.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AhaCKIAAjPQABgkgCgcIAgAAIACAiIABAAQAWgmArAAQAkAAAXAbQAYAcAAArQAAAwgbAcQgZAagkAAQgnAAgTgeIgBAAIAABpgAgghhQgPAMgGATIgCAPIAAAhQAAAJACAGQAFAQAOALQAPAMASAAQAaAAAQgVQAQgSAAgiQAAgfgPgUQgQgVgaAAQgRAAgPAMg");
	this.shape_13.setTransform(129.7,-23.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("Ag8BUQgPgQgBgXQAAgjAfgRQAegSA1AAIAAgEQAAgtgqAAQgcAAgWAPIgIgYQAbgRAjAAQBKAAAABQIAABGQAAAeACAQIgfAAIgDgYIgCAAQgHAMgPAIQgRAJgRAAQgcAAgQgRgAgpApQAAARAKAJQAJAIAPAAQAPAAAOgKQALgJAFgOQACgFgBgGIAAgfIgGAAQhKAAAAApg");
	this.shape_14.setTransform(99.1,-27.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AhCB1QgYgcAAgsQAAgtAagdQAZgcAkAAQATAAAQAJQAOAIAHANIABAAIAAh0IAjAAIAADoQAAAfACATIggAAIgBghIgBAAQgIARgRAKQgSALgVAAQgjAAgYgbgAgngHQgPASAAAgQAAAgAOATQAQAVAZAAQASAAAOgLQAPgMAFgTQABgGAAgJIAAghQAAgIgBgIQgFgPgNgLQgOgMgTAAQgZAAgQAWg");
	this.shape_15.setTransform(78,-31.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("Ag9BUQgPgQAAgXQAAgjAegRQAegSA3AAIAAgEQAAgtgqAAQgdAAgWAPIgIgYQAbgRAjAAQBKAAAABQIAABGQAAAbADATIggAAIgDgYIgBAAQgJAMgPAIQgQAJgSAAQgbAAgRgRgAgpApQAAARAKAJQAJAIAOAAQAQAAAOgKQALgJAFgOQABgFAAgGIAAgfIgHAAQhJAAAAApg");
	this.shape_16.setTransform(57.2,-27.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("ABoBiIAAhrQAAg8gqABQgOgBgMAKQgKAJgGANQgDALAAAHIAAB1IggAAIAAhyQAAgXgKgPQgLgOgTAAQgQAAgMALQgLAJgFAOQgDAIAAAKIAAByIgiAAIAAiKIgCg1IAfAAIACAfIABAAQAVgjAogBQATAAAPAMQAMAKAGASIABAAQAIgPAOgKQASgPAZAAQAYAAASARQAWAWAAAuIAABvg");
	this.shape_17.setTransform(31.4,-27.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAABlQgoAAgagbQgbgcAAgtQAAgtAcgdQAagbAoAAQAqAAAaAcQAZAbAAAtQAAAwgfAcQgbAZgkAAgAgrgxQgPAVAAAcQAAAgARAVQAQAVAZAAIAAAAQAYAAARgVQAQgVAAggQAAgcgMgUQgQgZgdAAQgbAAgQAYg");
	this.shape_18.setTransform(3.8,-27.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AhRCHIAAkIQAegFAkAAQAwAAAZAWQAYAVABAkQgBAkgUATQgcAeg1AAQgSAAgKgDIAABsgAgvhoIAABoQAKACATAAQAeAAARgNQASgPAAgbQAAgbgRgNQgRgOgbAAQgPAAgSADg");
	this.shape_19.setTransform(-16.1,-31.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("EAocANHQgCgMgMgNQgNgOgDgHQgKgWACglQABgqgFgVQhKgBjcgXQjEgUhuAFQgIABgKgFQgJgEgHABQhAADjBgOQifgMhhATQlBAGkiAYQgOgDgRABIgfACIgUgHQgMgEgKAAQhDALhvAAQikgBgdABQgQANgigBQgfAAgSgMQgWAEhPgEQhIgDgiALQgWgLgkADIg3AIQgWACgjgEIg9gGQgUgBgiADIg1ACQgyAAh6gHQhogGg5ACQgGgFgUAAIgfABQkiAokvgNQgagRhCABQhaACgNgCQgHAAgKAIQgKAGgLgCQgvgFgmgoQg6g+gGgEIgEgSQgCgKACgKQgngogZhTIgriNQgtgYhCACQhMAIgngBQhYgFgxABIg1ABQgfABgUgCQgIgBgQgHQgSgGgHgCQgsgHhqgBQhmgBgzgKIgugJQgZgEgYACQgbACgkgGIg/gIQhLgFgygIQhDgLg4gSQgDgLgMgJIgUgOQABgsgUgdQgDglgCgUQgEgkgKgXQAJgVgCgvQgCgVgFgtQAbgSAAgjQgGgpABgVQAKgJAUgJQAagMAGgEQAoAgA7goQALACAMAGIATALQBjgCC3gNIEvgXQCNAEBigBQBxAAB+gHQACAAADgIQACgHAJAEQAFgCALADQALADALgEQgHgNAOgLQAPgNABgJQAGg1AqhRQAwhaALgsIAWgSQANgLADgNQALACAKgEIARgGQAZACBjgQQBMgMAtATQAhgGBTgJQBMgLApgMQBlALAwADQBPAGBDgBQA2gBB8gMQBygLA/ABQAfAAA8AEQA3ACAmgGQAtAQBygPQB1gPAvAOIBLgCQApAAAdAGQB7AADrgUQDngUBjABQADgFAMgBQANgBADgEQBOAFCUAAQCSABBTAFQBlAYDFACQDXACBXAOIAfgHQAOAJAUgCIAjgDQBcgBDBAPQCoAIBageQAJgBAJAEQALAEAFABQCVgjAkgEQB3gQBDAkQAXgKAXABQAVABAcALQgBAOARAFQATAGAAAKQADANgEAcIgHAvQAMAeAAA5IAABgQABAKAFAZQAFAWABAMQAAAIgFARQgEARABAIQAKCOAID9QAIEiAEBZQgNAbACAvIAIBaQgZAyAcBcQgEALgBANIgCAaQAEAHAHgHQAEgFAAAIQAKAMgDAPQgFAPAJAMQgLAFAAAGQACAMgCAEQgSAKguAQQgpAPgVAQQiEAWhcABIgKAAQiCAAhQgmgEAppgLfQgGAFgLAFIgWAJQgPAzAAB/QAABHAEB6IgHAQQgEAKgEAFIAGATQAEALABAIQAAAIgFAIQgFAJgBAGQANBaABCPQAACQAJBAQgNAbgBAwQAAArAKAjQgKA9gFBMIgIB7QADAKAPAPQAOANACAMQgBAJgMAHQgOAIgDADQAHAKgBAUQgBAXADAIQAEAOARANQAUAOAFAJQBUAaBogKQBggJBOgiQASgCARACQAJgKAHgPQAFgKAOgHQgQhVANjFQANjJgOhbQABmLgBhIQgEkLgbjBIgcADQgQACgCgFQAAAOgJAMQgLARgDALQgmAKg5gQQg+gSgeAFIgiAEQgWABgVgFQgJgCgIAHQgJAHgIgBQgIADgDgGQgCgFgEAAIgCAAgAulJjQEHgWBTAFQBzAWC2gCIExgFQADgCALgDQAKgCADgEQBDANBEABQBMABBAgPQBDALCXgGQCzgIA2ADQAJABAGgFQAIgHAEgBQDVAUDUgnQAZAFAogBQAwgCAUACQBlgKCqAGQDgAIA0AAQBOgBB8ALQCnAPAcACQAJAAAJADIARAEQArgGBAADQBHACAhgCQAFhVAGi1QAFi3AGhmIgLguQAHhBgMjLQgJioAZhaQgFgdAAhFQgBhAgJghQgEgFAFgLQAHgMgEgKQgYABhjgEQhPgEgjAHIgxgKQgfgGgQgHQhBANhsgIQiHgKgoABQhogOi+gDQjsgEhKgFQgLgBgXgHQgXgHgMgBQgOgBgaAEQgcAFgMAAQgVAAglgEQgogEgQAAQg5AAhoAHQhxAIg4ABQguABhYAMQhbAMgqABQhzAEhKgBQhmgBhUgJQiVAKhLACQiBAFhdgOQgqAMhKgDQhdgDgbACQgLABgSAHQgUAHgJAAQgLABhcgBQg9gBgnARIhNgJQgqgGgagMQgnAJhkAIQhYAHgwASQhqgbhwAbQgFADAEAPQAFAPgPAFQgBAFADAXQAEAWgDAPQAOAgAGBQQAFBMASAeQgFA1AMBmIAPCbQAAAIAHAGQAHAIABAFQgKARAKARQAAABAAAAQAAABAAAAQAAAAgBABQAAAAgBAAIgFABQgGgBgCAFQAKAJgCAIIgIATQAFASAAAfQgBAaAIARQACAKgFAJQgFALAAAEQAPAwAHBDQAEAnAFBIQgQBBgEAXQgHAzAPAdQgCAEgQAPQgMALADAYQBEABAkAWQARgGAVACQAUACAKAJQAGgDASAAQASAAAEgEQB9AYDagTgA4mI/QgCgNALgXQAIgUgGgNQATgNAFgkIAIhCQAIgOAAgdQAAgRgFgjQAKgmgKg6QgGgjgRg5IAGgyQAEgigKgTQAJg3ABg0QAAhCgOgrIAAgbQgZhBAOhIQgNg1gIhBQgJhBAAg2QgPgUgMgmQgYAUgYA0QgbA9gNARQAJAWgQAhQgUAoAAATQgBAFADACIAJABQAAAFgGACIgJAEQAAAHAGABQAFAAAEgEQABAZATASQALALAXATQABAPACAXIAFAmQApALgLBGIAJARQAGAJALAAQAAAKgOgCQAOAQAFAVQAFAXgKAUIANAAQADAXgRAeQgPAbAJASIgbAxQgOAeADAYQgWAPgHAKQgPATANARQgFAJgHgDIgOgGQgIAtAJAoQAHAdASAnQABAHgGAEQgFAEgBAEQAOATAPAkIAYA8QAXABAOAdQAPAfARAEIAAAAgEgruACDQAkAIBRAAQBTAAAlAIQAiAGBRACQBaACApAFQAbAEAuAIQAnAHAdgEQAIgBBUAAQA8gBAggNQATAGArABQAmAAAOAIQALgIAcgBQAaAAAIgKQgIgRgjAAQglAAgIgKQg9AAhpgRQh0gSgrgDQgjgMg3gOIhegYQgEgJgPgJQgTgMgEgEIgCgkQAAgWgFgRQACgMAUABQAGAAAZAEQAKgJASgDQAWgDAHgEQBBACCIgCQB4ACBFAYQAwABBRANQBRANAyAAQgEgHADgWQACgRgMgDQgJgBACAFQADAJAAACQgQgFgGgDQgMgGAAgNQgQADglgJQgegHgVAJQgIADgEgHQgEgIgGABQhRABh3gdQiFgjhBgOQglAHgugOQgvgOgegcQgGgcAagPQAcgQABgSQAgACATgCQAXgDAZgIQCFARB5AGQBpAFCOgCQgDgGgLgNQgIgLgFgIQghAGhIgHQhUgIgsACQhTADhsgHQgRgGgRACQgIAEgJABQgNADgZAAIgpAAQgeABg/AJQg7AIgcABQhQgCgoACQhEACg0AVQgbgOguAAQg4ADgggBQgHAUAIApQAIAmgJAQQAGAfADCCQACBrAYA7IAagCQAjAAApAJgA7KBhQAPgNAIgWQAGgNAFgZQgJgEgagGQgYgFgKgIQjEgWhmgKQi3gThoAeQAIANAaAIQAcALAHAJIBMANQAtAIAcAJQBEABBNASQAXgFArAJQAoAHAZgHQA2AWBIABgEgvXABOQAQAOASAFQAEgWgGg+QgGg8AFgeQgFgWAFhfQAEhOgYgiQgNADgIANQgFAKgEAUQgPADgIAZQgJAfgGAGQAIATADAHQgLARAGAqQAFAlAMAbQgMAIAEAPQADANAMAKQAAAHgHAWQgBATAUgBQAAADgEABIgIAAIAbAbgA6sipQAAgNgHgTQgIgUAAgNQg2gOh8gDQizgEgZgCQg8gFgggCQg4gDgkAHQARAQA6AJQA5AJARAPQAHgBATAEQARAEAHgHQAVALA0AGQAvAGAVAPIB+gFIANAAQBBAAAlAJg");
	this.shape_20.setTransform(44,8.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFBF00").s().p("Ai7MIQgFgJgTgOQgSgNgEgOQgDgIABgXQABgUgHgKQADgDAPgIQALgHACgJQgDgMgOgNQgOgPgEgKIAIh7QAGhMAJg9QgJgjAAgrQAAgwANgbQgJhAAAiQQgBiPgNhaQABgGAFgJQAFgIAAgIQgBgIgEgLIgGgTQAEgFAEgKIAHgQQgEh6AAhHQAAh/AQgzIAWgJQALgFAFgFQAGgBADAGQADAGAHgDQAJABAIgHQAIgHAKACQAUAFAXgBIAhgEQAegFA8ASQA5AQAmgKQAEgLALgRQAIgMAAgOQACAFARgCIAbgDQAbDBAEELQACBIgCGLQAOBbgNDJQgMDFAPBVQgOAHgFAKQgHAPgJAKQgRgCgRACQhPAihfAJQgbADgaAAQhJAAg9gTg");
	this.shape_21.setTransform(328.3,10.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FF7F00").s().p("A7yLCQgFAEgSAAQgSAAgFAEQgKgKgVgBQgUgCgSAFQgkgWhDgBQgEgYAMgKQARgQABgDQgPgeAHgzQAEgXAQhBQgEhIgEgmQgHhDgQgwQABgEAFgMQAEgJgCgKQgIgRABgZQAAgfgEgTIAIgVQACgHgKgKQABgEAGAAIAFAAQABgBAAAAQABAAAAgBQAAAAAAAAQABgBAAAAQgLgRALgSQgBgFgIgHQgHgHABgIIgQiYQgMhmAFg1QgRgfgGhLQgFhRgOgfQACgQgDgWQgEgWABgFQAPgGgEgOQgEgQAEgCQBwgbBqAbQAxgSBYgHQBkgIAmgKQAaAMAqAHIBOAIQAmgRA+ABQBbACALgBQAKgBATgHQATgGAKgBQAbgDBdAEQBKACArgLQBcANCBgEQBLgDCXgKQBUAJBmACQBKAABzgDQArgBBYgNQBYgMAvgBQA3gBBxgHQBogHA5AAQARAAAnAEQAmAEAUgBQAMAAAdgEQAZgEAOABQANABAWAGQAXAHALABQBKAFDsAEQC+ADBpAPQAngCCHALQBsAIBBgNQARAGAeAGIAxALQAjgIBQAEQBiAFAYgBQAEAKgHAMQgFAKAEAGQAJAhABA/QAABFAGAeQgaBZAKCpQALDIgHBDIAMAuQgHBngFC2QgGC2gFBUQggADhIgDQg/gCgsAGIgQgFQgKgDgIAAQgdgBingPQh8gMhOABQg0ABjggIQiqgHhlALQgUgCgvABQgpABgZgEQjUAmjVgTQgEABgIAGQgGAFgJgBQg1gCi0AHQiVAHhDgMQhAAPhMgBQhEAAhDgOQgDAEgKADQgLACgDADIkzAEQi2ADhzgXQhTgEkGAWQhgAIhNAAQhkAAhGgOg");
	this.shape_22.setTransform(94.3,-1.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFBF00").s().p("AAaJMQgPgdgUgBIgYg8QgPgkgOgTQAAgEAGgEQAGgEgBgHQgTgngGgdQgJgoAHgtIAPAGQAHADAFgJQgNgRAOgTQAIgKAWgPQgDgYAOgeIAZgxQgJgSAPgbQARgggEgXIgMAAQAJgSgFgXQgEgVgPgQQAPACAAgKQgLAAgGgJIgHgRQAIhGgngLIgEgmQgDgXAAgPQgYgTgKgLQgTgSgBgZQgEAEgFAAQgGgBAAgHIAJgEQAFgCABgFIgJgBQgEgCACgFQAAgTAUgoQAQghgKgWQANgRAcg9QAXg0AWgUQANAmAOAUQABA2AJBBQAIBBANA1QgOBIAZBBIAAAbQAOArAABCQgBA0gJA3QAKATgEAiIgGAyQARA5AGAjQAKA6gKAmQAFAjAAARQAAAdgJAOIgHBCQgGAkgSANQAGANgIAUQgLAXACANQgRgEgPgfg");
	this.shape_23.setTransform(-119.3,3.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#D3D2D1").s().p("ABGEFQgtgJgagDQgogFhagCQhSgCghgHQgmgHhSAAQhRgBgkgHQg5gNguAFQgXg7gChsQgDiAgGggQAIgPgHgmQgIgpAHgUQAgABA3gEQAuAAAbAOQA0gUBFgDQAogBBQABQAbAAA8gJQA+gJAfgBIAnAAQAZAAANgCIABAVQgZAJgWACQgSACgggBQgBARgcARQgaAPAFAbQAfAcAvAPQAsAOAlgHQBBANCFAkQB3AcBQgBQAGAAAEAIQAEAHAJgDQAVgJAeAHQAkAIARgCQAAAMAMAEQAGAEAQAEQAAgBgDgJQgCgEAJABQAMACgCAQQgDAXAEAHQgzgBhRgNQhRgNgvAAQhFgWh4gDQiJACg+gCQgIAEgWACQgRACgKAJQgZgEgGAAQgUAAgDAMQAGAQAAAXIACAlQAEAFATALQAOAJAFAKIBcAXQA2AOAkANQArACB0ATQBoAQA+ABQAHAKAmAAQAjAAAHARQgHAJgaABQgdAAgKAJQgPgIglgBQgrAAgUgGQggANg7AAQhUABgIABIgWABQgVAAgagEg");
	this.shape_24.setTransform(-187.4,-0.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#D3D2D1").s().p("AADAXQh3gGiFgRIgBgUQAJgBAIgEQARgCARAGQBsAHBTgDQAqgCBUAIQBIAHAigGQAEAIAIAJQALANADAGIhOABQheAAhLgEg");
	this.shape_25.setTransform(-158.4,-24.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#7C7670").s().p("ACvAmIh+AFQgVgPgugGQg0gGgUgLQgIAHgQgEQgUgEgGABQgRgNg6gJQg5gJgRgQQAjgHA5ADQAgACA7AFQAaACCwAEQB8ADA3AOQAAANAIASQAHATAAANQgpgKhKABg");
	this.shape_26.setTransform(-155.9,-13.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#7C7670").s().p("ACmAtQgZAIgogIQgqgIgXAFQhMgShDgCQgdgJgsgIIhNgLQgHgJgcgLQgagKgHgMQBngeC3ASQBlALDEAYQAJAHAYAFQAbAGAIAFQgFAWgFAOQgJAVgPANQhIAAg2gXg");
	this.shape_27.setTransform(-159.1,11.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#D3D2D1").s().p("AALC3IgZgbIAHAAQAEgBAAgDQgUABACgTQAGgWABgJQgNgKgDgNQgEgOAMgJQgMgbgFgiQgGgrAMgRQgEgHgIgTQAGgGAJgfQAIgYAQgEQADgUAEgJQAHgOAOgDQAYAjgFBNQgFBeAFAVQgFAeAGA+QAGA/gDAVQgSgFgQgOg");
	this.shape_28.setTransform(-260.2,-2);

	this.addChild(this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-272.9,-79.2,634,175.6);


(lib.pinzas = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AHJD9QiogHh5gPQgJABgGgGQgIgGgEgBQhLACgqgEQg2gGgxgTQgzABhZgIIiLgMQhMgchcgOQgMgCgpgQQgggNgSABQgtghhNgJQgdgQhbgbQhOgVgjgeQgFAAgEADQgFADgFgCQhuhIh8gfQgPgSgVgHQgagHgSgHIgQAKQgJAFgFABQg9gIh9ACQh1AAhAgKQhtAKhngHQhSgGh3gTQAKgFgFgGQgIgJgBgDQAsgDCOAaQB6AXBSgUQBTADBxgJIDGgRQAggCBCgWQA+gVAiAAQAMAAAoAJQAgAJAUgHQDHAyCFA1QBxAbDbA8QDHAzCVARQAYANA+AHQBBAHAXALIB8AJQBMAFA0AFIB1ANQBEAIAwACQAjACBHAHQBBAFAogCQAXgCAvgNQAqgIAdAPQAegKA9gGQBBgGAbgJIAngMQAbgJAWgCIBZgGQAzgFAkgIQAXgFAmgMQArgLASgEQAJgCAKADQALADAFAAQAWgOA0gFQA8gHAXgJQAhAKBWAFQBLAEAjAQQArgTA0AOQAvANAaAcQgYAXgjAPQgfANgdADQgTgShAAFQhEAGgcgQQgdAJhtAMQhPAKgnAeQglAEgtAMIhPAWQgLADgUADIgmAFQgNADgmAPQgjANgYAEIgjADQgWACgMACQiwAkiCgFQgNAKgrABQgtABgOAHIkjgIg");
	this.shape.setTransform(29.6,36.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AIqJbQgGAAgLgGQgLgFgFgBQgaAAhGAGQg9AFgjgDIhRgPQgwgJgjANIgLgEQgIgDADgJQhBAIhrgOQiEgQgxgBQgUgIgqgIQgugIgSgGQieAIjAg3QjPhHhogbIhTggQgwgSgpgIQhgg5gYgKQhMgjhHADQgJgLgYgHQgegJgGgEQiWADkTgOQkDgMiKAEQgVhjAAhbQAAh4AogzIBLgkQAsgVAbgTICsgRQBrgLBMgDICeAJQBdAAA7gcQAIgDAIAHQAGAEAEgEQALgCAVgJQATgGALAJQAegNBZgOQBRgNAggVQAIACANgCQALgDADADQBYgaA7gPQBNgTBOgMQAbgOAigIQAUgEA1gJQAjgFBOgWQBUgXAngHQCHgaCBADQBCgLBwgEQCagGAdgCQABgDAFgDQAGgDAAAFQAMACAlAAQAfAAATAGQApAABJgCQA8AAAkAKQAYAGAtARQApAOAjgDQAUAHAOAMQBFAOB5AtQB5AtBEAOQADAHAMAFQAMAGAEAFIAmAAQAgAWBQAQQBUAQAhATQA9AECOAbQB5AXBNAAQAKgDABAJQABAMAEABID5ALQCVAHBXAIQAOANAmAbQAjAYAQARQhGBQgkAoQg+BCg2ApQhIADgTgCQgzgEgZgYQigglgmgKQhugbhLgfQg6gEgcgEQgwgGgfgNIicgKQhbgGg2gWQhkgNjshDQjOg6iHgHQgkgMhOgHQhXgIgggHIiAAJQhHAEg6gGQg0AOh3ABQhsABg2AWQgLgEgOACQgWADgGgBQgnAQhlAaQhdAYgrAWQgigBgeANQgQAIgeAWIhHASQgmAMgWAQQgnACg4AUQg4ATgjABQAUARAoAFQAVADA4AEQCgBEDsA/QCHAkETBCQA6AABvATQBtATBIAAQBFARBRAIQBhAKA6gIQBLARBSAEQBBADBcgFQAJgGAXgEQAYgGAJgDQAeAJAjgDQAVgCAvgIQAIAEAAgIQAAgIAEABQAWgCA/gLQAvgJAoACQATgHBTgLQBGgJAbgWQAZgCAKgCQAOgEAMgLQAeAJAegKQAVgGAhgUQAOgBAOAHIAaANQAlgHAyABIBVACQA5AXBJgLQAMARAcADQAZADATgIQATAKAjAGQAgAFASgCQAOADAJAPIAPAcQgXAlgxAuQg+A6gQATIgmAAQgSgCgEgNQgcAIgggFQgfgFgYgNQgiACg9gDQg5gDgcAEQgRACg6AXQgsARgegIQgpAShlAZQhhAYgrAVQhQADhgAQQgqAGh+AZIgTgFQgLgDgJAAQgVAGgiACIg7AEQgMABguAJQgeAFgSAAIgGAAgAE4IZIEkAJQAOgIAtgBQArAAANgKQCCAFCwgkQAMgDAWgBIAigEQAZgDAjgOQAlgPAOgCIAmgGQATgCAMgEIBPgWQAtgMAlgEQAngeBPgJQBtgNAcgJQAdAQBEgGQA/gFAUASQAcgCAggOQAigOAZgXQgagfgwgMQgzgOgrASQgjgQhLgEQhWgEgigKQgWAJg8AGQg0AGgWANQgFAAgMgDQgKgCgIABQgTAFgqANQgmAMgXAFQgkAIgzAEIhZAHQgWACgbAIIgnANQgcAIhAAGQg9AGgeALQgdgQgqAJQgvANgYABQgoADhAgFQhHgHgjgCQgwgDhEgHIh1gNQg0gGhMgFIh6gIQgXgMhCgHQhAgHgXgNQiVgSjHg0Qjbg8hxgaQiGg1jGgyQgUAGghgIQgngKgMAAQgjAAg9AVQhDAWgfADIjGARQhxAIhTgCQhTATh6gWQiNgagsACQABADAIAKQAFAFgKAFQB2AUBSAFQBoAHBsgJQBAAKB1gBQB+gBA9AHQAFgBAIgFIARgJQASAGAaAHQAVAHAPASQB8AgBtBHQAGACAEgDQAFgDAEABQAkAeBOAXQBbAaAcAQQBOAKAtAgQASAAAgAMQApAQAMADQBcANBMAdICLALQBZAIAzAAQAxATA4AFQAqAEBKgBQADAAAIAHQAGAFAIgBQB5APCoAHgEghJgDPQgvAPhnA0QgHAMgQAWQgNAVgCAVQAoAggVAWIBTAKQAyAGArABQARAOAsAIQA3ALANAFQA6AACDgKQBwgKA+AFQALgDBOgKQAzgGAcgOQA5gCAfgGQAqgKAUgYQAWgFArAFQADgIAQgFQASgGAEgEIAfAAQAKgIAcgJQAdgIAJgJQAOACATgHQARgGAQADQATgNAhgJQAQgEAugIQAugbBugdQBxgfAsgYQAygGCPgfQB0gYBVgEQAsACCRgLQB0gJBDALQCBgECjAZQBcAOCzAhIAMAKQAJAFAJABIAZABQANABAMgCQAxAfA/ARQBEATBEgCQBGAfBfAKQBdALA/gOQgGAMAJgDQANgEAAAKQBCgIBQAXQBjAdAdACQBIAmBwAcQBAAOCKAdQAEgLARgLQARgJAFgJQApgEArgfQAggVAlgoQgjgmg5gTQg8gDh1gRQh+gSgxgEQgDAFgLACQgOACgDACQgJgHgPAAQgJAAgUADQgegSg0ACQhKACgIgBQgQgCg8gWQgugSggAIQgqgVghAJIhRgWQgvgOgegNQgrgEgcgIQgdgJgdgSQhDgJhdglQiDg0gPgFIhNgWQgugNgegOQgsgDgxgNIhTgaIjLgDQh3gBhLALQgeACgWgGQgdAHgQADQgbAEgTgGQgjAThagGQhZgGgjAUQh4AHi4AwQjcA6hQANQgVASgmAIQgaAFg0ADQgyAah5AWQh5AWg0AaQhaAKh+AAQi9AAgbABQgHAHgSAEQgWAFgGADQgfgJgiAAQgxAAg5ATg");
	this.shape_1.setTransform(44,8.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B2B2B2").s().p("A/nEXQgsgIgSgOQgrgBgxgHIhUgLQAWgWgpggQACgVANgVQAQgWAIgMQBmg0AvgPQBhggBKAWQAGgDAWgFQATgEAGgHQAbgBC9AAQB+AABagKQA0gYB6gWQB5gWAxgaQA0gDAagFQAngIAVgSQBPgNDdg6QC4gwB4gHQAjgUBZAGQBZAGAjgTQATAGAcgEQAQgDAdgHQATAGAhgCQBLgLB2ABIDMADIBTAaQAxANArADQAfAOAuANIBMAWQAPAFCDA0QBdAlBDAJQAeASAdAJQAbAIAsAEQAdANAvAOIBRAWQAigJAqATQAggGAtAQQA9AWAPACQAJABBKgCQA0gCAeASQAUgDAIAAQAQAAAJAHQADgCAOgCQAKgCADgFQAxAEB/ASQB1ARA7ADQA6ATAiAmQglAogfAVQgsAfgpAEQgEAJgRALQgRALgEALQiKgdhBgQQhwgchHgmQgdgChjgdQhQgXhDAIQAAgKgMAEQgKADAHgMQhAAOhdgLQhfgKhFgfQhEAChEgTQhAgRgxgfQgMACgMgBIgZgBQgKgBgIgEIgNgJQiyghhdgOQiigZiBAEQhDgLh3AJQiPALgsgCQhVAEh0AYQiPAfgxAGQgtAWhxAfQhuAdgtAbQguAIgQAEQgiAJgTANQgPgDgSAGQgSAHgOgCQgJAJgdAIQgdAJgKAIIgeAAQgEAEgTAGQgPAFgEAIQgrgFgWAFQgUAYgqAKQgeAGg5ACQgdAQgyAGQhPAKgKADQg+gFhxAKQiCAKg6AAQgOgFg2gLg");
	this.shape_2.setTransform(41.1,-16.4);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-190.3,-51.8,468.7,120.7);


(lib.picaduras = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text(txt['picaduras'], "35px Verdana");
	this.text.lineHeight = 37;
	this.text.setTransform(-94.9,-10.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag9BUQgPgQAAgXQAAgjAfgRQAegSA2AAIAAgEQAAgtgqAAQgdAAgWAPIgIgYQAbgRAjAAQBKAAAABQIAABGQAAAeADAQIggAAIgDgYIgBAAQgJAMgOAIQgRAJgRAAQgcAAgRgRgAgoApQAAARAJAJQAJAIAOAAQAQAAAOgKQALgJAFgOQACgFAAgGIAAgfIgHAAQhJAAAAApg");
	this.shape.setTransform(88.7,-31.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AguBiIABiCQAAgigCgbIAfAAIABAmIABAAQAHgUANgLQAPgMARAAQAFAAAFACIAAAgIgMAAQgSAAgOAMQgKANgDAUIgCARIAABkg");
	this.shape_1.setTransform(74.4,-32);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Ag9BUQgPgQAAgXQAAgjAegRQAegSA3AAIAAgEQAAgtgqAAQgdAAgWAPIgIgYQAbgRAjAAQBKAAAABQIAABGQAAAbADATIggAAIgDgYIgBAAQgJANgOAHQgRAJgSAAQgbAAgRgRgAgpApQAAARAKAJQAJAIAOAAQAQAAAOgKQALgJAFgOQABgDAAgIIAAgfIgHAAQhJAAAAApg");
	this.shape_2.setTransform(56.6,-31.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhZCKIAAjPQgBgkgBgcIAfAAIACAiIACAAQAVgmAtAAQAjAAAYAbQAXAcAAArQAAAwgbAcQgYAaglAAQgoAAgRgeIgBAAIAABpgAgghhQgPAMgFATQgCAJAAAGIAAAhQAAAKABAFQAFAQAOALQAPAMATAAQAZAAAQgVQAPgSAAgiQAAgfgOgUQgQgVgaAAQgRAAgPAMg");
	this.shape_3.setTransform(36.7,-28);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("Ag8BUQgQgQABgXQAAgjAdgRQAegSA3AAIAAgEQgBgtgpAAQgdAAgWAPIgIgYQAbgRAjAAQBKAAAABQIAABGQAAAeADAQIggAAIgDgYIgBAAQgIAMgQAIQgQAJgSAAQgbAAgQgRgAgoApQgBARALAJQAIAIAOAAQARAAANgKQAMgJAEgOQABgFABgGIAAgfIgHAAQhJAAAAApg");
	this.shape_4.setTransform(6.1,-31.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhCB1QgYgcAAgsQAAgtAagdQAZgcAkAAQATAAAQAJQAOAIAHANIABAAIAAh0IAjAAIAADoQAAAfACATIggAAIgBghIgBAAQgIARgRAKQgSALgVAAQgjAAgYgbgAgngHQgPASAAAgQAAAgAOATQAQAVAZAAQASAAAOgLQAPgMAFgTQABgGAAgJIAAghQAAgIgBgIQgFgPgNgLQgOgMgTAAQgZAAgQAWg");
	this.shape_5.setTransform(-14.9,-36.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("Ag9BUQgPgQAAgXQAAgjAegRQAegSA3AAIAAgEQAAgtgqAAQgdAAgWAPIgIgYQAbgRAjAAQBKAAAABQIAABGQAAAbADATIggAAIgDgYIgBAAQgJAMgPAIQgQAJgSAAQgbAAgRgRgAgpApQAAARAKAJQAJAIAOAAQAQAAAOgKQALgJAFgOQABgFAAgGIAAgfIgHAAQhJAAAAApg");
	this.shape_6.setTransform(-35.7,-31.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("ABoBiIAAhrQAAg8gqABQgOgBgMAKQgKAJgGANQgDALAAAGIAAB2IggAAIAAhyQAAgXgKgPQgLgOgTAAQgQAAgMALQgLAJgFAOQgDAIAAAKIAAByIgiAAIAAiKIgCg1IAfAAIACAfIABAAQAVgjAogBQATAAAPAMQAMAKAGASIABAAQAIgPAOgKQASgPAZAAQAYAAASARQAWAWAAAuIAABvg");
	this.shape_7.setTransform(-61.5,-32);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgBBlQgoAAgZgbQgbgcAAgtQAAgtAcgdQAbgbAnAAQApAAAaAcQAaAbAAAtQAAAwgeAcQgbAZglAAgAgrgxQgOAVgBAcQAAAgARAVQAQAVAZAAIAAAAQAYAAARgVQAQgVAAggQABgcgNgUQgRgZgcAAQgbAAgQAYg");
	this.shape_8.setTransform(-89.2,-31.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AhSCHIAAkIQAfgFAkAAQAxAAAYAWQAZAVAAAkQAAAkgWATQgbAeg1AAQgSAAgKgDIAABsgAgvhoIAABoQAJACAUAAQAeAAASgNQARgPABgbQAAgbgSgNQgRgOgbAAQgPAAgSADg");
	this.shape_9.setTransform(-109.1,-35.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#95E7F4").s().p("AAAMYQhegJhPgiQgRgCgRACQgJgKgHgPQgFgKgOgHQAPhVgMjFQgNjJAOhbQgCmLAChIQAEkLAbjBIAbADQARACACgFQAAAOAIAMQALARAEALQAmAKA5gQQA8gSAeAFIAhAEQAXABAUgFQAKgCAIAHQAIAHAJgBQAHADADgGQAEgGAFABQAFAFALAFIAWAJQAQAzAAB/QAABHgEB6IAHAQQAEAKAEAFIgGATQgEALgBAIQAAAIAFAIQAFAJABAGQgNBagBCPQAACQgJBAQANAbAAAwQAAArgJAjQAJA9AGBMIAIB7QgEAKgOAPQgOANgDAMQACAJALAHQAQAIACADQgHAKABAUQABAXgDAIQgEAOgSANQgTAOgEAJQg+AThJAAQgaAAgcgDg");
	this.shape_10.setTransform(-240.2,10.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3FBEC4").s().p("AWcLIQkGgWhTAEQhzAXi2gDQjNgGhmACQgDgDgLgCQgKgDgDgEQhDAOhEAAQhMABhAgPQhDAMiVgHQi0gHg1ACQgJABgGgFQgIgGgEgBQjVATjUgmQgZAEgpgBQgvgBgUACQhlgLiqAHQjgAIg0gBQhOgBh8AMQinAPgdABQgIAAgKADIgQAFQgsgGg/ACQhHADghgDQgFhUgGi2QgFi2gHhnIAMguQgHhDALjIQAKipgahZQAGgeAAhFQABg/AJghQAEgGgFgKQgHgMAEgKQAYABBigFQBQgEAjAIIAxgLQAegGARgGQBBANBsgIQCHgLAnACQBpgPC+gDQDsgEBKgFQALgBAXgHQAWgGANgBQAOgBAZAEQAdAEAMAAQAUABAmgEQAngEARAAQA5AABoAHQBxAHA3ABQAvABBYAMQBYANArABQBzADBKAAQBmgCBUgJIDiANQCBAEBcgNQArALBKgCQBdgEAbADQAKABATAGQATAHAKABQALABBbgCQA+gBAmARIBOgIQAqgHAagMQAmAKBkAIQBYAHAxASQBqgbBwAbQAEACgEAQQgEAOAPAGQABAFgDAWQgEAWACAQQgOAfgFBRQgGBLgRAfQAFA1gMBmIgQCYQABAIgHAHQgIAHgBAFQALASgLARQAAAAABABQAAAAAAAAQAAABABAAQAAAAABABIAFAAQAGAAABAEQgKAKACAHIAIAVQgEATAAAfQABAZgIARQgCAKAEAJQAFAMABAEQgQAwgGBDQgEAmgFBIQARBDADAVQAHAzgPAeQABADARAQQAMAKgEAYQhDABgkAWQgSgFgUACQgVABgKAKQgFgEgSAAQgSAAgFgEQhGAOhkAAQhNAAhggIg");
	this.shape_11.setTransform(-6.2,-1.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#B9EAEF").s().p("AhBJLQgJgUAGgNQgSgNgGgkIgHhCQgJgOAAgdQAAgRAFgjQgKgmAKg6QAGgjARg5IgGgyQgEgiAKgTQgJg3gBg0QAAhCAOgrIAAgbQAZhBgOhIQANg1AJhBQAIhBABg2QAOgUANgmQAWAUAXA0QAcA9ANARQgKAWAQAhQAUAoAAATQACAFgEACIgJABQABAFAFACIAJAEQAAAHgGABQgFAAgEgEQgBAZgTASIgiAeQAAAPgDAXIgEAmQgnALAIBGQgDAMgEAFQgGAJgLAAQAAAKAPgCQgPAQgEAVQgFAXAJASIgMAAQgDAXARAgQAOAbgJASIAZAxQAOAegDAYQAWAPAIAKQAOATgNARQAFAJAHgDIAPgGQAHAtgJAoQgGAdgTAnQgBAHAGAEQAGAEAAAEQgOATgPAkIgYA8QgUABgPAdQgPAfgRAEQACgNgKgXg");
	this.shape_12.setTransform(207.4,3.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#7C7670").s().p("AkaAPQAIgSAAgNQA3gOB8gDQCwgEAagCIBcgHQA4gDAjAHQgRAQg5AJQg6AJgRANQgGgBgUAEQgQAEgIgHQgUALg0AGQguAGgVAPIh+gFQhKgBgpAKQAAgNAHgTg");
	this.shape_13.setTransform(244,-13.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#D3D2D1").s().p("Aj6AaQAEgGALgNQAJgJADgIQAiAGBIgHQBUgIApACQBTADBtgHQAQgGASACQAIAEAJABIgBAUQiGARh2AGQhLAEheAAIhPgBg");
	this.shape_14.setTransform(246.5,-24.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#7C7670").s().p("Ak7AiQgEgMgGgYQAIgFAbgGQAYgFAJgHQBcgGDNgdQC4gSBmAeQgHAMgaAKQgcALgHAJIhNALQgsAIgdAJQhDAChMASQgXgFgqAIQgoAIgZgIQg2AXhIAAQgPgNgJgVg");
	this.shape_15.setTransform(247.2,11.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#D3D2D1").s().p("AiKEIQgIgBhTgBQg8AAgggNQgUAGgrAAQglABgPAIQgKgJgdAAQgagBgHgJQAHgRAjAAQAmAAAHgKQA+gBBogQQB0gTArgCQAkgNA3gOIBbgXQAFgKAOgJQATgLAEgFIACglQAAgXAGgQQgDgMgUAAQgGAAgZAEQgKgJgRgCQgWgCgIgEQiDgBhEABQh4ADhFAWQgvAAhRANQhRANgzABQAEgHgDgXQgCgQAMgCQAJgBgCAEQgDAJAAABIAWgIQAMgEAAgMQARACAkgIQAegHAVAJQAJADAEgHQAEgIAGAAQBQABB3gcIDGgxQAlAHAtgOQAugPAfgcQAFgbgagPQgcgRgBgRQggABgSgCQgWgCgZgJIABgVQAWAEA3gCQAfABA+AJQA8AJAbAAQApABBPgBQBFADA0AUQAbgOAuAAIBXADQAHAUgIApQgHAmAIAPQgGAggDCAQgCBsgXA7QgugFg5ANQgjAHhRABQhTAAgmAHQghAHhSACQhaACgoAFIhHAMQgZAEgWAAIgWgBg");
	this.shape_16.setTransform(275.5,-0.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#D3D2D1").s().p("AgpB2QAGg+gFgeQAFgVgFheQgFhNAYgjQAOADAHAOQAEAJAEAUQAPAEAIAYQAJAfAGAGQgIATgEAHQAMARgGArQgFAigMAbQAMAJgEAOQgDANgNAKQABAJAGAWQACATgUgBQAAADAEABIAHAAIgYAbQgRAOgSAFQgDgVAGg/g");
	this.shape_17.setTransform(348.3,-2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("Egr3ANtQhcgBiEgWQgWgQgpgPQgtgQgSgKQgBgEAAgMQABgGgLgFQAJgMgFgPQgEgPALgMQAAgIAFAFQAGAHAFgHIgDgaQgBgNgFgLQAchcgYgyQAHg+ABgcQACgvgOgbQAFhZAIkiQAIj9AKiOQABgIgEgRQgFgRABgIQAAgMAFgWQAFgYABgLIAAhgQAAg5ALgeIgGgvQgEgcADgNQABgKASgGQARgFgCgOQAdgLAWgBQAXgBAWAKQBEgkB2AQQAkAECVAjQAFgBALgEQAJgEAJABQBaAeCogIICPgJQBYgGA2ABQALAAAYADQAUACAOgJIAeAHQBZgODWgCQDFgCBlgYQBTgFCSgBQCUAABOgFQADAEANABQANABACAFQBjgBDoAUQDqAUB7AAQAegGAoAAIBLACQAvgOB2APQBxAPAtgQQAmAGA3gCIBbgEQBAgBBxALQB8AMA2ABQBDABBQgGQAugDBmgLQAqAMBLALIB0APQAsgTBOAMQBhAQAZgCIARAGQALAEALgCQADANANALIAWASQALAsAvBaQArBRAHA1QAAAJAPANQAOALgHANQAMAEALgDQAKgDAFACQAJgEACAHQACAIACAAQB+AHBzAAQBhABCMgEIEwAXQC3ANBiACIAUgLQANgGAKgCQA7AoAoggQAGAEAbAMQATAJAKAJQACAVgHApQgBAjAcASQgFAtgBAVQgDAvAJAVQgJAXgEAkIgGA5QgTAdAAAsIgUAOQgMAJgCALQg5AShCALQgzAIhLAFIg+AIQgmAGgagCQgZgCgYAEIgvAJQgyAKhmABQhpABgtAHQgHACgRAGQgRAHgIABQgUACgggBIg0gBQgcgBgqACIhEADIhygHQhCgCgtAYIgrCNQgZBTgnAoQABAKgCAKIgDASQgGAEg6A+QgnAoguAFQgLACgKgGQgKgIgHAAQgNAChZgCQhCgBgbARQkvANkigoIgfgBQgTAAgHAFQg5gChpAGQh6AHgxAAIg2gCQghgDgUABIg9AGQgjAEgXgCQgjgGgTgCQgjgDgXALQgigLhIADQhPAEgWgEQgSAMgfAAQgiABgQgNQgdgBikABQhvAAhDgLQgKAAgMAEIgUAHIgfgCQgQgBgOADQkjgYlBgGQhhgTigAMQjAAOg/gDQgIgBgJAEQgKAFgIgBQhugFjEAUQjcAXhKABQgGAWACApQACAlgJAWQgDAHgOAOQgMANgCAMQhQAmiCAAIgKAAgEgvHAMCQBPAiBfAJQBoAKBVgaQAEgJAUgOQARgNAEgOQAEgIgCgXQgBgUAHgKQgCgDgQgIQgLgHgBgJQADgMAOgNQAOgPADgKIgIh7QgGhMgJg9QAJgjAAgrQAAgwgMgbQAIhAABiQQAAiPANhaQgBgGgFgJQgFgIAAgIQABgIAEgLIAGgTQgEgFgEgKIgHgQQAEh6AAhHQAAh/gQgzIgVgJQgLgFgGgFQgFgBgDAGQgDAGgIgDQgIABgJgHQgIgHgJACQgVAFgXgBIgggEQgfgFg+ASQg5AQgmgKQgDgLgMgRQgIgMAAgOQgBAFgSgCIgbgDQgbDBgEELQgBBIACGLQgOBbANDJQALDFgPBVQAOAHAFAKQAHAPAJAKIARgBIASABgAOmJjQDaATB8gYQAFAEASAAQASAAAFADQALgJAVgCQATgCASAGQAkgWBDgBQAFgYgNgLQgQgPgCgEQAPgdgHgzQgDgVgRhDQAFhIAEgnQAHhDAPgwQgBgEgEgLQgFgJACgKQAIgRgBgaQAAgfAFgSIgIgTQgCgIAKgJQgBgFgHABIgFgBQgBAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBQALgRgLgRQABgFAIgIQAHgGAAgIIAQibQALhmgFg1QASgeAFhMQAGhQANggQgCgPAEgWQADgXgBgFQgPgFAEgPQAFgPgFgDQhwgbhqAbQgxgShXgHQhlgIgmgJQgaAMgqAGIhOAJQgmgRg+ABQhbABgLgBQgJAAgTgHQgUgHgKgBQgbgChdADQhKADgrgMQhcAOiBgFIjggMQhTAJhnABQhKABhygEQgsgBhZgMQhZgMgugBQg4gBhxgIQhngHg6AAQgRAAgnAEQglAEgVAAQgMAAgdgFQgZgEgOABQgNABgWAHQgXAHgLABQhKAFjsAEQi+ADhoAOQgngBiHAKQhtAIhBgNQgQAHgfAGIgxAKQgjgHhPAEQhjAEgYgBQgDAKAGAMQAGALgFAFQgJAhAABAQgBBFgGAdQAaBagJCoQgMDLAHBBIgMAuQAHBmAFC3QAGC1AGBVQAgACBHgCQBAgDArAGIARgEQAKgDAIAAQAcgCCogPQB7gLBOABQA1AADfgIQCqgGBlAKQAUgCAvACQApABAagFQDTAnDVgUQAEABAIAHQAHAFAIgBQA1gDC1AIQCWAGBDgLQBAAPBMgBQBEgBBDgNQAEAEAJACQALADADACQBkgCDOAHQC2ACBygWIAhgBQBfAADaASgAY+pkQgBA2gIBBQgJBBgNA1QAOBIgaBBIAAAbQgNArAABCQABA0AJA3QgKATAEAiIAGAyQgRA5gGAjQgKA6AKAmQgFAjAAARQAAAdAIAOIAHBCQAHAkASANQgGANAIAUQALAXgCANQAQgEAQgfQAOgdAXgBIAYg8QAOgkAPgTQgBgEgGgEQgFgEABgHQASgnAHgdQAIgogHgtIgOAGQgIADgEgJQAMgRgOgTQgHgKgWgPQADgYgOgeIgbgxQAJgSgPgbQgQgeADgXIAMAAQgKgUAGgXQAEgVAPgQQgPACAAgKQALAAAGgJQAEgFAFgMQgKhGAogLIAFgmQADgXAAgPIAigeQATgSABgZQAEAEAFAAQAFgBABgHIgJgEQgFgCgBgFIAIgBQAEgCgBgFQAAgTgUgoQgQghAJgWQgNgRgbg9QgYg0gXgUQgNAmgOAUgEAgkACwQBTAAAIABQAeAEAngHIBJgMQAogFBagCQBRgCAigGQAmgIBSAAQBSAAAigIQA6gMAuAFQAXg7AChrQADiCAGgfQgJgQAIgmQAIgpgHgUIhXgCQgvAAgaAOQg1gVhFgCQhPABgogBQgbgBg9gIQg+gJgegBQg5ACgWgFQgJgBgIgEQgSgCgQAGQhtAHhTgDQgrgChUAIQhIAHgigGQgDAIgJALQgLANgEAGQCPACBpgFQB4gGCGgRQAZAIAXADQATACAggCQABASAcAQQAaAPgGAcQgeAcguAOQgvAOglgHIjGAxQh3AdhRgBQgFgBgFAIQgDAHgJgDQgVgJgeAHQglAJgQgDQgBANgLAGIgWAIQgBgCAEgJQACgFgJABQgMADACARQACAWgDAHQAzAABRgNQBQgNAwgBQBFgYB4gCQBDgBCFABQAJAEAVADQASADAKAJQAZgEAGAAQAUgBACAMQgFARAAAWIgCAkQgEAEgTAMQgPAJgEAJIhdAYQg4AOgjAMQgrADh0ASQhpARg9AAQgIAKglAAQgjAAgHARQAHAKAaAAQAcABALAIQAOgIAmAAQArgBATgGQAhANA8ABgEAu5gDCQAFBfgFAWQAFAegGA8QgGA+ADAWQATgFAQgOIAbgbIgIAAQgEgBAAgDQAUABgBgTQgHgWAAgHQAMgKADgNQAEgPgMgIQAMgbAFglQAGgqgMgRQAEgHAIgTQgGgGgJgfQgHgZgQgDQgEgUgFgKQgIgNgNgDQgYAiAEBOgEAgYgAfQjOAdhdADQgJAIgYAFQgaAGgJAEQAGAaAFAMQAIAWAPANQBIgBA2gWQAaAHAogHQApgJAYAFQBNgSBEgBQAcgJAsgIIBNgNQAHgJAdgLQAZgIAHgNQg/gSheAAQg7AAhGAHgEAiWgEIIhcAHQgZACiyAEQh9ADg2AOQAAANgIAUQgHATgBANQAqgKBKABIB+AFQAUgPAwgGQA0gGAVgLQAIAHAPgEQAVgEAGABQARgPA5gJQA6gJARgQQgYgFgiAAIgiABg");
	this.shape_18.setTransform(44,8.5);

	this.addChild(this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-272.9,-79.2,634,175.6);


(lib.imagen3 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A9He7MAAAg91MA6PAAAMAAAA91g");
	mask.setTransform(116.5,198);

	// Capa 2
	this.instance = new lib._112_OPT();
	this.instance.setTransform(-174.9,2.4);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-174.9,2.4,600,400);


(lib.Imagen2 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3pe7MAAAg91MAvTAAAMAAAA91g");
	mask.setTransform(151.5,198);

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.imagen = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3pe7MAAAg91MAvTAAAMAAAA91g");
	mask.setTransform(151.5,198);

	// Capa 2
	this.instance = new lib.botiquin2_OPT();
	this.instance.setTransform(2,-4.9);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2,-4.9,300,450);


(lib.gasas = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AguAtQAPgnATgUQAXgbAkgIQgPAQgWA0QgPAfgXAAQgIAAgKgFg");
	this.shape.setTransform(-123.5,149);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("APPaRIABgWQANgbgahBQgahAALgZQAqALAGA7IgBBlQDbAXGZgXQBUiZAMk8QAIjhgckUQgZAIg0gJQg0gKgXgRQAcgNAvADQAbACAyAIQgIqOAJoHQAKpiAloEQh0AQjLgHQjrgHhmAHQgQAFgKAbQgLAdgLAGQgLgEADgoQACgkgWAEQg8ALhvgBQihgCgUABQgSAOgMAvQgOAxgNAOQgPgUAHgnQAJgzgBgOQh5ABhagDIjQgHQgNAJgKAwQgJArgZAEIAAhfIl6AAQgKAOgHA7QgHAygYAKQAEgcgGgjQgIgoABgUQh6gHk0gBQkkgBiZgKQAAAMAPA5QALAqgQAWIgbg7QgPgkAEgmQgeADicAEQh1AEhEARQgmDAAACgQAaAOA8ASQA0AUAOAiQgOgDg8gXQgrgSgtAGQgHBTAECDQAFCcgCAwQAHADBJARQAyALANAaQggAEgtgHQgwgIgbACQABBNgOCnQgMCYAGBiQAVAEAdgHQAQgEAdgKQAwgOAJApQgTAKg4AAQg6AAgTAJQgPBfgBB2QgBCigCAfQAHANAzgEQAugEAAAYQgEAQguABQgrAAgCAVQgIAzgDCDQgECegEAyIAygKQAhgGAMAQQgKASgmAKQguAMgKAHQgHA0gQBmQgNBbgCBFQALACAtgIQAbgFAMAVQgQALgjAKQgqALgMAGQgZEjAZC4QDJASFDAEIAAAdQkvgEkMAKQgZkQArmnQAYjkALhyQATjFAEiRQAYvZA0tsQgBgWAUgHQJwAPQqgEQUIgFGoAEQAYBqgTCmQgKBdgYC6QgIBrABDAQABDggDBWQgFB6gCC6IgDE0QgCCmAOENQARFPACBaQALHlh2EGIgzAAQkmAAlVgQg");
	this.shape_1.setTransform(44,8.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgEAQIgvhDQAnACAVApQAgA0ALAIIgGAAQgXAAgbgkg");
	this.shape_2.setTransform(-105.9,-144.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("ACuLqQlSgEhrgEQhcgDhggKQhqgKhEgPQBXpdASoDQACg3ARhyQAQhxACg5IAVABQgSISgLC4QgZGQg0EyQEBANFaAUIJfAkIgCAdQitgLkdgDg");
	this.shape_3.setTransform(-42.9,54.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AiuIUIABgXQAAg2gLh7QgLhxADg+QADhBAOhcIAYihQAbjDgVh6QCnghCpgUIADAcQioAWhxApQgcDXgQEJQgMC/gKEtg");
	this.shape_4.setTransform(-74.6,-74.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgDg8QAGgCAHAFQAIAGAGAAQgHAUgHAtQgJAogXAIQgFhUAYgmg");
	this.shape_5.setTransform(-78.3,148.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#C2CECC").s().p("APnZsIABhlQgGg7grgLQgLAYAbBBQAaBAgNAbQqZhLuYgnQgKgNACg8QACg1gXgHQgeANANAvQASBEgBAFQhfgCi1gBIkvgDQlDgFjJgRQgZi4AZkkQAMgFAqgMQAjgJAQgMQgNgVgbAFQgsAIgMgBQAChGAOhbQAQhlAGg0QALgHAugMQAmgKAKgTQgMgQghAHIgyAJQAEgyADidQAEiDAIgzQACgWArAAQAtAAAFgRQAAgXgvADQgzAFgGgNQABgfACiiQABh2APhgQATgIA5AAQA4gBAUgKQgJgpgwAOQgeAKgQAEQgcAIgVgEQgHhiANiYQAOingBhOQAbgCAvAIQAtAIAhgEQgNgbgygLQhJgQgHgDQABgwgFidQgDiCAHhUQAtgFArARQA8AYAOACQgOghg0gUQg8gTgagNQgBigAmjAQBFgSB1gDQCcgFAdgDQgDAnAPAkIAbA6QAQgVgMgrQgOg5AAgMQCYALElABQE0AAB6AHQgBAUAHAoQAHAkgEAcQAYgKAGgyQAIg8AKgNIF6AAIAABfQAZgFAIgqQALgwANgKIDQAIQBaACB4AAQACANgKA0QgGAmAOAUQAOgOANgxQANguARgOQAVgBChACQBvABA8gMQAWgDgCAjQgDAoALAEQALgGAKgdQALgaAQgFQBmgHDqAHQDMAGB0gQQglIEgKJiQgKIHAJKOQgzgHgbgCQgugDgcAMQAXARA0AKQA0AKAZgIQAcEUgIDhQgME8hUCZQjNALidAAQidAAhtgLgAHWXrQAHAzAcAVQgHgWAMhIQAKg0gigGQgZAcAJA0gAUEXUQAUAlAQARQAYAZAkAGQgig5gFgHQgTgZgVAAQgIAAgJAEgAh4V+QACBMACAOQAJAtAiAIQgJgMAAgbIACgxQAAg3gjAAIgFAAgAXwXkQANANAbAJQAAgcgRgRQgOgOgagIQABAcAQARgAzIUyQgYAmAFBWQAZgIAJgoQAHgvAHgUQgGAAgHgGQgGgEgGAAIgEABgA6UVoQgTAWgPAmQAiARAYgrQAWg2APgPQgkAIgZAbgAjh2IQmiAIlcArQipAVioAhQAUB5gbDDIgYChQgNBfgEBBQgDA9ALBxQAMB7gBA3IgBAWQgCA5gQBxQgRBxgCA2QgSIFhWJdQBEAOBqALQBfAKBcADQBsAEFTAEQEeADCsAKIBnAHQJAAvC4ALQGsAaFCgIQBAjTgHlxQgGjNgChnQgDi1AKiBQAJhfAEh4QASl7gfl1QgEifgGhOQgJiHgrhMQgTghgXgXImbgWQlKgRj0gGQjAgFirAAQhsAAhlACgAYiQLQgBAPALAOQARgFArgCQAjgEAJgSQgQgLgpAAQgpAAgQALgAZBEoQAaAEAcgGQAEgdgkgBQgtAEgSgDQAFAaAkAFgAY2isQg6ADgKAbQAZAJApAEQAqAEAQgHQAEgog0AAIgIAAgAZNoUQgtACgIAbIBFAOQAsAFABgdQgRgTgmAAIgGAAgAZMuJQgkALgQAUQAvAEARgBQAugEAEgbQgMgJgSAAQgOAAgSAGgAZTymQgUAAg6AMQAJAbAygDIBKgFQAAgfgxAAIgGAAgAYU3oQgxAqAFAtQAOghA7gmQA5glANgjQg7AWgoAigA3c3uQAgApAagFQgLgIggg2QgXgpgngCIAvBFgAr74FQANA0AoAHQgUgTAFhHQAEg8glgDQgQAuALAwg");
	this.shape_6.setTransform(43.7,9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgWARQgMguAQguQAkADgFA8QgFBFAUATQglgHgNg0g");
	this.shape_7.setTransform(-30.3,-146.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AALBEQqfgrm0gFIAAgbIEvADQC2ACBeACQABgGgShDQgMgvAdgNQAXAHgCA0QgBA9AJANQOYAkKZBMIgBAWQivgIuOg6g");
	this.shape_8.setTransform(31.9,163.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("Al+ALQFcgqGggIIABAYQgtABggAFQhrAKjpAMQjnAMhxAOg");
	this.shape_9.setTransform(-17.2,-128.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAWKwQi2gLpCguIhngHIACgdQHNAcFEAPQGpAVFqAKQAYhuAOiPQAIhTAMiyQAGhogIizQgKjLAChSQACgyARhhQARhkACgwIAWABQgEB7gJBfQgKCBADC1QACBnAGDKQAHFxhADUQhJAChNAAQkMAAlMgVg");
	this.shape_10.setTransform(104.5,68.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AGHAXIi6gCIjOgGQiBgDhRgBQg2AAiBgJQh0gFg+ABIAAgXQEFgFE3AIQD0AGFJAQIgBAcQhLgDhqgCg");
	this.shape_11.setTransform(78.4,-130);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgRASQgDgOgChKQAmgEAAA7IgBAvQAAAbAIAMQgfgIgJgtg");
	this.shape_12.setTransform(33.8,156.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgTAEQgIgzAZgcQAgAHgKA0QgMBGAHAVQgagUgIgzg");
	this.shape_13.setTransform(92.7,160.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgKANQgRgPgTglQAdgOAaAjQAFAHAhA3QgjgGgWgZg");
	this.shape_14.setTransform(176.9,162.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AjhgNIABgeIGZAWQAXAWASAgIgWALQipgukEgLg");
	this.shape_15.setTransform(158.4,-125.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#DAEAE7").s().p("AIwUSQlEgPnLgcIpfgkQlbgUkBgNQAzkyAZmSQALi4AToQQAKktALi/QARkLAbjXQBzgpCpgWQBxgODngMQDrgMBrgNQAggEAtgBQA+gCB0AIQB+AIA2ABQBRAACCAEIDQAFIC5ADQBrACBLADQEGALCpAwQBAIrAMJdIAAAcQgCAwgRBiQgRBhgCAyQgCBSAKDLQAJC1gHBoQgMCygIBTQgOCPgXBuQlrgKmrgVg");
	this.shape_16.setTransform(42.8,2.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAXJWIAAgcQgMpag+osIAXgLQApBNAJCHQAGBOAFCfQAeFzgRF6g");
	this.shape_17.setTransform(184,-62.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgagOQAmgiA7gWQgNAjg5AjQg5AmgOAhQgGgtAygog");
	this.shape_18.setTransform(202.1,-140.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgKALQgQgPgBgcQAaAIAMAOQARAPAAAcQgbgJgLgNg");
	this.shape_19.setTransform(196.9,158.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AADAUQgngDgZgJQAKgaA5gDQA7gDgEApQgJAFgVAAIgcgCg");
	this.shape_20.setTransform(202.1,-6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgFAPQglgGgEgXQASADArgEQAjABgDAaQgSAEgQAAIgSgBg");
	this.shape_21.setTransform(204.5,37.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AALAVIhDgPQAIgZAtgBQApgCATAVQgCAWghAAIgLAAg");
	this.shape_22.setTransform(205.4,-42);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("Ag4gHQARgLAnAAQAoAAARALQgJAQgkAEQgoACgSAEQgKgNAAgNg");
	this.shape_23.setTransform(206.4,113.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AhBgFQA6gLASgBQA3gCAAAfIhIAFIgKABQgpAAgIgXg");
	this.shape_24.setTransform(204.5,-108.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("Ag4ARQAQgSAkgMQAmgMAXAPQgFAZguAEIgKAAQgSAAgigCg");
	this.shape_25.setTransform(205.4,-80.1);

	this.addChild(this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-135.8,-161.2,359.8,339.5);


(lib.Path = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#F09122","#DF081F"],[0,1],22.6,52.5,-22,-52.8).s().p("AEVG3IlKlxIjbFxQg1gdgvglQhehKAhglIECkIIjbjkQARhAAZg6QAzh1AmAdIDYFRIEWkqIBGAlQBBArgbAfIkXEXIF/EWQgbA4gjAxQg0BLghAAQgKAAgJgIg");
	this.shape.setTransform(102.6,102.6,1,1,0,0,0,0.8,-0.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(57.5,58.2,88.7,89.5);


(lib.Path_1 = function() {
	this.initialize();

	// Capa 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#0B6635","#95C030"],[0,1],34.5,77.7,-16.7,-68.8).s().p("ApNImQhWg8hWgzIhFgnIg/kOIAKAAQCVAUD6CeQB9BPBfBLQAhogGXnoQCAiZCWiAQBLhBAyghIE7E3QpsF1kSKEQhVDKgpDNQgVBmgDA+QiljQkSjAg");
	this.shape_1.setTransform(97.9,103.7,0.5,0.5);

	this.addChild(this.shape_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(53.3,56.2,89.4,95.1);


(lib.Grupodeclips0 = function() {
	this.initialize();

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1410").s().p("AgIAnQgMAAgJgJQgJgIAAgNIAAgRQAAgNAJgIQAJgJAMAAIARAAQANAAAIAJQAJAIAAANIAAARQAAANgJAIQgIAJgNAAg");
	this.shape.setTransform(314.9,260.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1F1410").s().p("AgIAnQgNAAgIgJQgJgIAAgNIAAgRQAAgNAJgIQAIgJANAAIARAAQANAAAIAJQAJAIAAANIAAARQAAANgJAIQgIAJgNAAg");
	this.shape_1.setTransform(303.8,260.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1F1410").s().p("AgIAnQgNAAgIgJQgJgIAAgNIAAgRQAAgNAJgIQAIgJANAAIASAAQAMAAAIAJQAJAIAAANIAAARQAAANgJAIQgIAJgMAAg");
	this.shape_2.setTransform(292.6,260.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1F1410").s().p("AgIAnQgMAAgJgJQgJgIAAgMIAAgTQAAgLAJgJQAJgJAMAAIARAAQANAAAIAJQAJAJAAALIAAATQAAAMgJAIQgIAJgNAAg");
	this.shape_3.setTransform(314.9,249.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1F1410").s().p("AgIAnQgNAAgIgJQgJgIAAgMIAAgTQAAgLAJgJQAIgJANAAIARAAQANAAAIAJQAJAJAAALIAAATQAAAMgJAIQgIAJgNAAg");
	this.shape_4.setTransform(303.8,249.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1F1410").s().p("AgIAnQgNAAgIgJQgJgIAAgMIAAgTQAAgLAJgJQAIgJANAAIASAAQAMAAAIAJQAJAJAAALIAAATQAAAMgJAIQgIAJgMAAg");
	this.shape_5.setTransform(292.6,249.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1F1410").s().p("AgIAnQgMAAgJgJQgJgIAAgNIAAgRQAAgNAJgIQAJgJAMAAIARAAQANAAAIAJQAJAIAAANIAAARQAAANgJAIQgIAJgNAAg");
	this.shape_6.setTransform(314.9,238.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1F1410").s().p("AgIAnQgNAAgIgJQgJgIAAgNIAAgRQAAgNAJgIQAIgJANAAIARAAQANAAAIAJQAJAIAAANIAAARQAAANgJAIQgIAJgNAAg");
	this.shape_7.setTransform(303.8,238.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1F1410").s().p("AgIAnQgNAAgIgJQgJgIAAgNIAAgRQAAgNAJgIQAIgJANAAIASAAQAMAAAIAJQAJAIAAANIAAARQAAANgJAIQgIAJgMAAg");
	this.shape_8.setTransform(292.6,238.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ah3C8QgcAAgUgUQgUgUAAgcIAAjvQAAgcAUgUQAUgUAcAAIDvAAQAcAAAUAUQAUAUAAAcIAADvQAAAcgUAUQgUAUgcAAg");
	this.shape_9.setTransform(303.7,249.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1F1410").s().p("AFNDVQgXAAgPgYQgRgXABgiIAChWQkZgbkYAbIACBWQAAAigQAXQgPAYgXAAIiuAAQgXAAgRgRQgQgQAAgXIAAigQAAgYAPgZQAPgaAWgMQECh6D8AAQD9AAECB6QAWAMAPAaQAPAZAAAYIAACgQAAAXgQAQQgQARgYAAg");
	this.shape_10.setTransform(303.8,198);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1F1410").s().p("AnVFoQgkAAgWgZQgVgYAAgkQAAgVAyimQAwibAQgnQAMgfAfgWQAegUAdAAQAaAAATgJQASgIASgSQAVgWALgeQAMgfgBgiIgBgVQBqgHBnAAQBoAABpAHIAAAVQAAAiAKAfQALAeAWAWQARASASAIQAUAJAaAAQAdAAAeAUQAfAWAMAfQARApAuCZQAzCmAAAVQAAAkgVAYQgXAZgjAAg");
	this.shape_11.setTransform(303.8,244.3);

	this.addChild(this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(247.4,176.7,112.7,103.7);


(lib.espadadrapo = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Axqf1Ig1gSQAFgFgBgKQgMAEgFgEIgJgLQgcACgJANQgeAAgOgWQgEgHgMgjQgTAMgbABQgfABgTgOQgFgHAAgLQAAgMgDgHQAAgDgGgCQgGgBABgFQg2AOgSgBQgjgDgEgrQgUAAgnAKQggAJgcgEQgMgNgCgZQgDgZAJgQIgnAMQgWAGgRABQgTgTgGgPQgHgUANgUQgJgMgLAEQgUAIgEAAQgdgJgLgMQgPgRAHgdQAcgLAFgiQAhgSAfghQATgUAggsQAugnAcgdQAlgoAXgpQAIgBAHAFQAEgWAZgZQAagZAEgVQAkgbAsg/QAzhJAWgXQAPgvA/hrQA1hbAOhOQAEgDAHgKQAGgKAFgDQgDgQALgXQAJgWgGgNQgmAKgfgDQgmgFgTgZQgHgBgHADQgHADgFgBQABgLgLgCQgOAAgGgCQACgHgEgEQgFgFAAgCQghgJghgnQgmgtgTgLQgDgXgRgTQgFgGgbgXQAEgLgKgKQgIgIAHgIQgbgogJgVQgRglAAgrQgVgzgBhaQAAhrgHgdIAFgUQABgIgGgJQADgrAFjNQADigAShpQAEhkAehdQAAgFgDgJQgCgJABgHIA5jsQAhiJAlhUQABgHgDgJQgCgHAEgDIAJgTQAFgKAIgIQAFgmAbgzQAdg3AGgfQAngiANhOQAkgPAQgZQADgFgHgHQABgDAQgWQAKgNgFgRQAGgBAKgIQAJgGAJAAQAfghAnhHQAigIAdgXQAcgWARghIAxgTQAagKASgPQA2gIBGgUIBzggQCJgkB2ASIAIgEQAFgCgBgGQAKAFAlAFQAdAEANAMQAGACAFgDQAGgEAFACIBxA/QBFAmAeAoQAPAGAHABQAIAcAZAZIArAoQgCAYAPAOQAIAJAUANQgBAPADAIQACAGALAPQACAlAgA/QAeA8gBA0QAEADAIAEQAGAFgDAKQADADAOAGQALAGACAIQgCAEgGAGQgGAGgBAGQAIAHAlAGQAfAEAGARIAbgXQARgMAPgGQAegcA1g+QAyg1AxgVQAFgCAFgHQAGgIADgCQAFABAHgDQAHgDAHACQAfgdBGgWQBnghALgFQAIAAALgCQAJgBAGAGIAQgGIARgFQBWgFBwAaQBAAPCAAjQAIAHAUAKQAUAJAIAHQA3ANA/AoQBdA8AMAGIA6BHQAiAoAjATQBSCCBrDFIAaCCQAQBOgJA8IADAOQABAJAIgBQgLAiADBmQACBkgNAnQAMCggSC9QgQCyglCfQgNAkgiBIQgdBCgCAxQgwBdgXBVQgeAcghBLQgiBOgaAbQACAUgSAWQgRAVAEAPQgiAOgPA1IhFBKQgqAtgXAhQgTAGgiAYQgkAagSAIQgIADgRABQgRABgHACQgmANggAYQhgADitAOQiuAPhRACQgPAAgwgLQgigHgWAKQgXgPgggEQgvgGgNgEQACgKgEgHQgFgKgBgDIhcgqQgygagdgdQghgCgggdQglghgUgGQgcgxgaAIQgSgNgdgnQgbgkgXgNQgIgMgdhDQgWgygagTQgIgYgSgoQgTgqgHgVQgMALABAnIADA6QgdBcg3CXQhBCugWBCQgQAYgFAJQgKAUgCAWQgHABgFAHQgFAJgFABQgjBWhRBvQhrCPgXAnQgpAihPBoQhIBdg5AlQgRAAgOALIgYATQgDABABAGQABAHgDAEQgRANgVAAQgIAAgJgCgAx0dtQAZAAAVAOQABADgCAEQgCAEAAADQAVABAMgMQATgTAHgDQA2gQAthAQA0hLAfgUQAFgQARgVQASgXAFgOQAcgSAjgzQAkg3AXgRQAIgnAlgVQAJghAkg3QAjg2AJgoQAMAAAGgRQAGgSAKgCQAHgpAUgtIAkhNQACgbARgrQAPgngBgdQAKgCADgHQACgHgHgGQAKgHAMgMIANg3QAIggAJgVQgDgbgBhFQAAg1gIgdQAMgOAOgfQAPgkAIgMQgEhDgPiNQgPiIgDhMIAHgHQAEgFAAgGQgChTAIhGQAHhAAUhWQAUh8BFidQBcjUAQgyQALgHAFgNQAFgMgCgMQAPgYAMgdQAOggADgXQAjgYAGgnQAUgUAUgfQAOgWATgnQAkgjAug7IBNhjQhKgcgngMQhFgXgyAAQgggbhdgKQhjgKgggUQgfAEgZgPQACAGgFACIgIADQgngDgwAlQg0AugZAQIgHAXQhfBbhYB5QhMBohPCJQgcBFhACDQgzB4gJBvQgOAtgIA7QgJBBAEAvQgJABABAIQACAQgBAFQgJASgGAWQACAigNAhQAGAjgGA/QgIBQABAgIAMBxQAHBDgMAoQAJBegZCBQgKA6gpCdQgLAOgRAuQgOApgRAOQgqB2hkCMIhVBzQgzBEgfAyQgkAZg3BEQg3BEgkAZQgEALgWAUQgUARgCASQAcgJAYAkQgCAHgBAPQAAALgFAHQAQAKAZgCQAOgCAfgGQAEAGAMAGQAKAFAEAJQAFAPgGARIgLAYQAZAEA1gJQApgCAIApQAwADAWgPIAiAVQARANABAWQBIgRAkAZQgCAFABAKQABALgDAHIAXgIQALgDAOAHQALgRAaAAIACAAgA3tdkIAFgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAAAAAQgHABAAACgAHFS6QAoAJBbAIQBDgGCSgGQCIgGBOgIQArgQBWgeQBKgcAngiIAqgvQAZgeAPgTQAhgVAegyQAvhPAFgGIBmjJQA8h4AYhjQAMgKAKghQAKghAMgKQABglAchJQAZhCgFgkQARgeAIgoQAJgrgEglQADgLAEgaQAEgaADgLQgHggADgeQACgXAKgiQgMg6AGhpQAIh3gGg1QANgSgDgoQgDgigLgXQALg8gBglQgBg2gXgbQAHgKgDgMQgEgPADgMIgPguQgJgbgCgXQgRgYg7hyQgshXgvgjQgLgegqgjQgsgjgLgbQgMgLgqgbQgjgXgPgVQglgMhIglQhEgjgqgMQgHAGgXAJQgrgOgwgCQg3gBggARQgxgCg6AlQhGArgfAHQgJASgVAQQgNgHgNAIQgQALgKgBQgNAVgWASQgOANgdASQh2CBg/BVQhdB8g1B7QgeAfgjBLQgmBRgYAdQAAAfgPAdQgUAfgJARQgFAkgZBGQgXA+ABAvQgWAjgGAVQACAegMBXQgLBNAKAoQgIAKgLAbQAAArgFBMQgFBSgBAnQAJAZgGAtIgKBLQAQBIgBBuQAFAKAEAgQAEAeAJAKQAAAnAUA7QASA8ABAmQAiA0AZBSIAbAdQAOASAEAUQAOAGAaAbQAWAXAXAEIAGAJQADAGgBAHQAFABAFgGQAFgFAHACQAjAhAOAJQAfAVAggDQAlAfBJAPgALc46Qg4AQgvAbQhYAYhBA+QhiAtg2BkQgNAFgRATQgQATgOAFQglBEheBtQhgBvgkBBIgIAYQgGANgHAIQgJAgghBKQgeBBgJAsQgaA4g3BpQguBggPBVQgcAnACBmQgQAagCAuIgEBUQgBAGgFAOQgEAMgBAHQgHBEAKCJQAMCkAAAoQADAIAGASQAFASAEAIQAIBfAvBpIBPCwQAPAKAlArQAfAkAdALQAGAHAKASQAHAPAQABQgEgNgdhEQgUgsAGgrQgSgdgJgrIgOhUQgOgNgIgFQgFhNgDgmQgGhAgQgoQAOgkAAg8QgDhGAAgjQAAgGgGgHQgFgGAAgHQALgmABg6QABhLACgTQABgHAHgQQAGgRABgKQAAgJgDgVQgDgTACgKQAKgcAEgOQAGgagQgSQAKgCABgPQABgOgIgGQAIADACgJQACgLADgBQgBgSAKgnQAIgigGgVQAQgiAchhQAXhbAYgqQACgHgEgEQgFgFgBgCQAMgNARglQARgiAOgNQAIgiAohIQAjhAACgiQASgFAPgYQASgcAJgHQANgnAuhCQAshBAMgiQAWgQAWgdIAmg0QAHACAGgFQAHgEAGAAQAjgoBFhSQA/hDA/giQAGgCAEADQAFADAEAAQAWgWA0gZQA6gbAUgQIgWgBQgsAAgyAOgAn990IhAAaQg6AGhAAfQhDAmgmAPQgKAMgmAaQgfAVgKAWQgJACgKAJQgLAKgIACIgWAdQgOARgPAGQgkA3hKBqQg9BhgXBbQgIACgEAOQgFAOgFAEQABAJgEAKQgFAKAAAIQgFAEgJALQgHAjg/DEQgtCKgBB1QgFANgEAgQgEAggFANIAAAwIgFAMQgDAHAAAHQgBAZgUDKQgNCQABBWQABAzgGBsQgCBhAWA2QgFBVAUBPQAUBOAnA0QAVAAAOANQAGAGAPAWQAAAFgJAJQgHAGAFAGQAVAEAmANQAiAJAagIQAJgsAGhDQAIhRADgUQAAgDgGgBQgFAAAAgDIAHgNQAEgIAAgJQgJg7ADh+QAEh3gNg+QALgcAGg+QAGhCAKgdQgBgfAKg2QAKg5AAglQAIgWAShLQAOg+ATgmQACgoAXgxQAcg8ADgOQAPgaAFgMQALgYgBgQQATgPAOgbQAKgVAJgiQBYiHAthDQBPh3BKg+QAcgqBGg/QBIhBAbgmQAKADAIgFQAJgGAGABQAIABABAFQAAAFAGAAIATgJQAMgFAKgBQARAHAgAXQAfACBaAbQBHAWA1gKQAOAIAbAIIAuANQACgigNgfIgagyQAEABAAgIIgBgMQgFgHgJgVQgJgSgGgJQgJgrgfgxQgrg/gIgUQgJgCgOgMQgOgKgLgCQgZgzhBgkQgKgGhwgwQgRABgnAGQgeAFgagBQgTARgnAQgAqh+ZQg6AYgKACQhVAEhSAtQhXA4gvAZQgDABAAAJQAAAJgEAAQgiATglAxQguA+gRAPQgDAHgQAaQgMAUgCARQgYAXgYA1QgeA/gMASQAAAFgEAKQgEAJABAJQhCBmgrC+QgNA0gWBqQgVBdgVA/QgWCtgHBBQgPCMAABtIgBBcQgBA0gJAmQAEAKAAAcQAAAbAHANQgGAMgCAQQAFB1AFAlQALBYAfAwQgBAKAHAKQAGALgBAJQANAMAYArQAUAlAVAMQAEgSgHgRIgPggIAGgIQADgGgCgIQgeiZgGiYQgHikAZiVQABgGgFgEQgFgDABgGQAJgRAAgLQAAgIgFgYQAJgXAHg8QAJhKAFgVQgDgjAGgmQAEgYALgsQgEgsAQhZQAShjAAgkQAWg4AKgdQASg0ACglQAHgDAEgOQAFgOAGgDQALg1AohbQAohZAKg5QAuhSBMhhQAsg4BahuQAugTAVgtQAhgUBEghQBCggAigWQAMgCAbgCQAVgEADgPIgIAAQgbAAgjAPg");
	this.shape.setTransform(44,8.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AADAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQgBAAAAAAIgDABQAAgBAFAAg");
	this.shape_1.setTransform(-107.4,197.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A0C6").s().p("AlzSFQgYgrgMgMQAAgKgGgKQgHgLABgKQgfgwgLhYQgEglgFh1QABgQAGgOQgHgNAAgbQAAgcgEgKQAJglABg0IABhdQABhtAOiLQAHhBAWisQAVg/AVhdQAXhqAMg0QAsi+BBhlQgBgJAEgJQAEgLABgFQAMgRAdhAQAZg0AXgXQADgSALgTQARgaADgIQAQgPAug9QAlgyAggSQAEgBABgIQAAgJACgBQAvgZBXg5QBSgsBWgEQAJgDA6gYQApgRAdADQgDAPgVADQgbACgMACQgiAXhBAfQhFAhggAVQgWAtguASQhaBugsA5QhJBhgvBSQgKA4goBZQgoBcgKA1QgHACgFAPQgEANgHADQgCAlgRA0QgLAegWA4QAAAjgSBkQgQBXAFArQgMAtgEAYQgGAmADAjQgEAUgKBLQgHA8gJAXQAGAXgBAJQAAALgJARQgBAFAGAEQAFADgCAGQgZCVAHCnQAGCXAeCaQADAIgEAFIgGAJIAPAfQAHARgEATQgVgMgUglg");
	this.shape_2.setTransform(-64,-67);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#DD781D").s().p("AlSaVQAAgDACgEQACgEgBgEQgVgNgZAAQgcgBgLASQgOgHgLACIgXAJQADgIgBgLQgBgKACgFQgkgYhIARQgBgWgRgOIgigUQgWAPgwgEQgIgpgpACQg1AKgZgEIALgYQAGgSgFgOQgEgJgKgFQgMgHgEgFQgfAGgOABQgZACgQgJQAFgIAAgKQABgPACgIQgYgkgcAKQACgTAUgRQAWgUAEgLQAkgZA3hEQA3hEAkgZQAfgxAzhFIBVhzQBkiMAqh1QARgPAOgpQARguALgOQApidAKg5QAZiBgJhfQAMgogHhDIgMhuQgBghAIhQQAGhBgGgiQANgigCghQAGgWAJgTQABgEgCgRQgBgIAJgBQgEguAJhBQAIg8AOgsQAJhwAzh3QBAiDAchFQBPiKBKhnQBYh5BfhcIAHgWQAZgRA0guQAwgkAnACIAIgDQAFgCgCgGQAZAPAfgEQAgAUBjALQBdAJAgAbQA0ABBFAWQAnANBKAbIhNBjQguA7gkAkQgTAmgOAWQgUAfgWAUQgGAogjAXQgDAXgOAgQgMAegPAXQACAMgFANQgFAMgLAIQgQAyhcDTQhFCegUB7QgUBXgHBAQgIBFACBVQAAAHgEAEIgHAIQADBMAPCFQAPCOAEBDQgIAMgPAjQgOAfgMAOQAIAdAAA2QABBEADAcQgJAUgIAgIgNA4QgMALgKAHQAHAGgCAHQgDAHgKADQABAdgPAnQgRAqgCAbIgkBNQgUAugHApQgKABgGASQgGASgMAAQgJAngjA2QgkA4gJAhQglAVgIAmQgXASgkA2QghA0gcASQgFAOgSAWQgRAWgFAQQgfATg0BMQgtA/g2AQQgHAEgTASQgLAMgVAAIgBAAg");
	this.shape_3.setTransform(-31.8,32.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#047391").s().p("AoZT3QgmgNgVgEQgFgFAHgHQAJgJAAgFQgPgWgGgFQgOgNgVgBQgng0gUhNQgUhPAFhVQgWg3AChhQAGhtgBgzQgBhXANiPQAUjKABgZQAAgHADgIIAFgMIAAgwQAFgNAEgfQAEgeAFgNQABh1AtiLQA/jEAHgjQAJgLAFgEQAAgHAFgLQAEgKgBgJQAFgDAFgPQAEgNAIgCQAXhbA9hhQBKhrAkg3QAPgFAOgSIAWgdQAIgCALgJQAKgKAJgBQAKgWAfgWQAmgZAKgNQAmgPBDglQA+ggA6gFIBAgbQAngPATgRQAaABAegFQAngHARgBQBwAxAKAFQBBAkAZA0QALABAOALQAOALAJADQAIATArA/QAhAyAJAqQAGAJAJATQAJAUAFAIIABAMQAAAHgEAAIAaAyQANAegCAjIgugNQgbgIgQgJQg1ALhHgWQhagcgfgCQgggXgRgGQgKABgMAFIgTAIQgGAAAAgFQgBgFgIgBQgGAAgJAFQgIAFgKgCQgbAlhIBCQhGA+gcArQhIA+hPB3QgtBChYCIQgJAigKAVQgOAbgTAOQABARgLAXQgFANgPAZQgDAPgcA5QgXAygCAoQgTAmgOA+QgSBLgIAWQAAAkgKA6QgKA2ABAeQgKAdgGBDQgGA+gLAcQANBAgEB2QgDB+AJA8QAAAJgEAIIgHANQAAACAFABQAGABAAADQgDATgIBSQgGBCgJAtQgMADgNAAQgQAAgTgFgAFNtOQAAAAgBAAQAAAAAAABQgBAAAAAAQAAABAAABIAFgBQABgBAAAAQAAAAABgBQAAAAAAgBQAAAAAAAAIgFABg");
	this.shape_4.setTransform(-22,-59.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAAAAIADAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQgBAAAAAAIgDABQAAAAAAgBQAAAAAAAAQABAAAAAAQABAAAAAAg");
	this.shape_5.setTransform(11.4,-143.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A0C6").s().p("AkWUHQgKgSgGgHQgdgLgfgkQglgrgPgKIhPiwQgvhpgIhfQgEgIgFgSQgGgSgDgIQAAgogMikQgKiJAHhEQABgHAEgOQAFgOABgGIAEhUQACguAQgaQgChmAcglQAPhVAuhgQA3hpAag4QAJgsAehBQAhhKAJggQAHgIAGgNIAKgYQAkhBBghvQBehtAlhEQAMgFAQgTQARgTANgFQA2hkBigtQBBg+BYgYQAvgbA4gQQA/gRA1AEQgUAQg6AbQg0AZgWAWQgEAAgFgDQgEgDgGACQg/Aig/BDQhFBSgjAoQgGAAgHAEQgGAFgHgCIgmA0QgWAdgWAQQgMAigsBBQgsBCgNAnQgJAHgSAcQgPAYgSAFQgCAigjBAQgoBIgIAiQgOANgRAiQgRAlgMANQABACAFAFQAEAEgCAHQgYAqgZBbQgcBhgQAiQAGAVgIAgQgKAnABASQgDABgCALQgCAJgIgDQAIAGgBAOQgBAPgKACQAQASgGAaQgEAOgKAcQgCAKADATQADAVAAAJQgBAKgGARQgHASgBAHQgCATgBBLQgBA6gLAmQAAAHAFAGQAGAHAAAGQAAAjADBGQAAA8gOAkQAQAoAGBAQADAmAFBNQAIAFAOANIAOBUQAJArASAdQgGArAUAsQAfBEAEANQgQgBgJgPg");
	this.shape_6.setTransform(71.1,-22.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#047391").s().p("AmWVhQhJgQglgfQggAEgfgVQgOgKgjggQgHgCgFAFQgFAFgFgBQABgHgDgFIgGgKQgXgDgWgYQgagbgOgFQgEgVgOgRIgbgdQgZhSgig0QgBgmgUg8QgUg7AAgoQgJgKgEgeQgEgggFgKQABhtgQhJIAKhKQAGgtgJgaQABgnAFhRQAFhNAAgsQALgbAIgKQgKgoALhMQAMhXgCgeQAGgVAYgiQgBgwAXg9QAZhHAFgkQAJgQAUgfQAPgdAAggQAYgcAmhRQAjhMAegeQA1h8Bdh8QA/hUB2iBQAdgTAOgMQAWgTANgVQAKABAQgKQANgJANAHQAVgQAJgRQAfgHBGgsQA4glAxACQAggRA3ACQAwABArAOQAXgIAHgHQAqANBEAjQBIAkAlANQAPAUAjAXQAqAbAMAMQALAaAsAkQAqAjALAdQAvAkAsBWQA7BzARAXQACAYAJAbIAPAuQgDALAEAPQADAMgHAKQAXAbABA2QABAmgLA8QALAWADAiQADAogNATQAGA1gIB2QgGBqAMA5QgKAigCAWQgDAeAHAfQgDALgEAaQgEAagDALQAEAogJAqQgIAogRAfQAFAkgZBBQgcBKgBAlQgMAJgKAiQgKAhgMAJQgYBjg8B4IhmDJQgFAHgvBPQgeAxghAVQgPAUgZAdIgqAwQgnAhhKAdQhWAegrAQQhOAHiGAHQiSAGhDAGQhbgJgogIgAlkNhIALAIQAhAIA3AUQAvANAjgSQAYAHAZAAQAFABABgHQABgIAEgBIAaAAQANgJBUgoQA+gdAVglQAHgBAPgHQA3hMAugqIADgMQACgHgCgHQAigkAshfQAsheAigkQAihYAuiYQA6i5ATg4QAAgTALhUQAIg9gMghQABgFAEgGIAGgLQAAgfgMg1QgPg9gDgaQgQgigagtIgrhNQhjhXgygrQgXgFg1gcQgtgYgmgDQgFABABADQgEABgEAHQgKABgTgFQhdAZghAOQhBAcgeAwQguAdg6BGQhCBQgfAaQgUAygJATQgRAmgVAXQgLAsg1B2QgsBhgDBAQgJAOgKArQgJAmgNAOQgJAzgFBBIgJBvQgCAWAIA7QAHAugNAdQAKAMgBAZQgCAjABAGQAAAEAHAIQAHAJABAFQAJA3AaBCIArBqQA2AhAQApQAHADAQARQANAOANgEQgCAJAGAFg");
	this.shape_7.setTransform(130.1,-8.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AjwNtQg3gVgigHIgKgIQgHgFACgKQgNAEgMgNQgQgSgHgCQgQgqg3ggIgrhqQgahCgJg3QgBgGgGgIQgHgJgBgDQgBgHACgiQACgZgKgMQAMgdgGguQgIg8ACgVIAIhwQAFhAAJgzQANgMAJgoQAKgsAJgOQAEg/AshiQA0h2ALgsQAVgXASglQAJgTATgzQAfgZBDhQQA6hHAtgcQAfgwBBgdQAegOBfgZQATAFALgBQAEgGADgBQAAgDAEgBQAnACAtAYQA1AcAXAGQAyAqBiBYIAsBNQAZAtARAiQADAaAOA9QAMA0ABAgIgHAKQgDAGgBAGQALAggIA9QgLBVAAATQgTA3g5C6QgvCYghBYQgiAkgsBeQgtBeghAkQABAHgCAHIgDAMQgtAqg3BNQgQAHgHAAQgVAlg9AdQhVApgNAJIgaAAQgDAAgBAIQgBAHgGgBQgYABgYgIQgVALgZAAQgRAAgTgFgAjiMWIAmAOQBIgWAzAAIApgXQAYgNAWgFQBKgyBIhpQAog8BOh7QADgYAVgnQAUgkABgUQAGgDAIgKQAIgLAHgCQgBgXAJgTIASggQAKhRAjgjQAoh/ARhcQAVh3gEhxQAAgGgFgJQgGgIAAgHQACgogVguQgZg5gEgYQgagggXgnQg3glgaglIg3gdQghgSgQgQQgQAEgQgMQgPgLgJAEQgPgBgWAGQgVAFgQgCQgfALguAXIhKAkQgVAggxAYIgiAlQgUAVgRAMQgLAegwA/QgqA3gHAxQgIAGgNANQgNAOgHAFQgGAaggBHQgbA5gCAyQgxBZgUCiQgOBvgCCkQAIA5AhCtQAPAkApArQAxA0AOAVQAhAVAwAUQAJgDALAAQALAAANAEg");
	this.shape_8.setTransform(128.4,-5.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#332922").s().p("AjfMXQgYgIgUAHQgwgUghgVQgOgWgxgzQgpgsgPgjQghiugIg5QACijAOhvQAUijAxhZQACgxAbg6QAghHAGgaQAHgFANgOQANgMAIgGQAHgyAqg2QAwhAALgdQARgNAUgVIAiglQAxgXAVggIBKgkQAugXAfgMQAQADAVgGQAWgGAPACQAJgFAPALQAQANAQgFQAQARAhARIA3AeQAaAkA3AmQAXAnAaAfQAEAZAZA5QAVAugCAoQAAAGAGAJQAFAIAAAHQAEBxgVB3QgRBbgoCAQgjAigKBRIgSAgQgJAUABAWQgHADgIAKQgIALgGACQgBAUgUAlQgVAmgDAYQhOB8goA7QhIBqhKAxQgXAGgXAMIgpAXQgzABhIAWIgmgOg");
	this.shape_9.setTransform(128.1,-5.7);

	this.addChild(this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-140.7,-195.4,369.6,407.9);


(lib.btn6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text(txt['btn6'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 234;
	this.text.setTransform(35,-9.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,10,1,1.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,10,1,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,10,1,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.6,-13.9,242,48);


(lib.btn5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text(txt['btn5'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 234;
	this.text.setTransform(35,-9.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,10,1,1.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,10,1,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,10,1,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.6,-13.9,242,48);


(lib.btn4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text(txt['btn4'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 234;
	this.text.setTransform(35,-9.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,10,1,1.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,10,1,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,10,1,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.6,-13.9,242,48);


(lib.btn3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text(txt['btn3'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 234;
	this.text.setTransform(35,-10.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,10,1,1.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,10,1,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,10,1,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.6,-13.9,242,48);


(lib.btn2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text(txt['btn2'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 234;
	this.text.setTransform(35,-10.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,10,1,1.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,10,1,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,10,1,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.6,-13.9,242,48);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_close = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-1.9,-17);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ABeidIi6AAQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0.1,1.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg6AAAAg8IAAjDQAAg8A6AAIC6AAQA5AAAAA8IAADDQAAA8g5AAg");
	this.shape_1.setTransform(0.1,1.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("ABti5IjZAAQhEAAAABHIAADlQAABHBEAAIDZAAQBEAAAAhHIAAjlQAAhHhEAAg");
	this.shape_2.setTransform(0.5,0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhsC6QhDAAAAhHIAAjlQAAhHBDAAIDZAAQBDAAAABHIAADlQAABHhDAAg");
	this.shape_3.setTransform(0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{scaleX:1,scaleY:1,x:-1.9,y:-17}}]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.text,p:{scaleX:1.171,scaleY:1.174,x:-4.2,y:-20.8}}]},1).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{scaleX:1,scaleY:1,x:-1.9,y:-17}}]},1).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{scaleX:1,scaleY:1,x:-1.9,y:-17}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.4,-17,31,34.2);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-6,-16.6,1.247,1.197);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0,5.2,1.247,1.197);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_1.setTransform(0,5.2,1.247,1.197);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.shape,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.text,p:{scaleX:1.412,scaleY:1.356,x:-8.5,y:-19.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.5,-16.7,38.7,40.9);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.botiquin = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("ABXAwQgggBgXgDQgBAAAAAAQAAAAgBAAQAAAAAAgBQgBAAAAAAIgDgBQgaAAgOgGIg1gDQgSgGgOgCQgOgGgGAAQgHgGgRgCQgFgDgRgFQgPgDgHgFQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQgVgOgXgFQgDgEgEgBIgJgDIgFADQgMgBgYAAQgXAAgMgCQgiADgsgHQAAAAABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIgCgCQAIgBAbAFQAXAEAQgDQAPAAA9gFQAGAAAMgEQAMgEAHgBIAKACQAGACAEgBQAiAIAdALIBAARQAlAKAdABQAFADAKABQAMACAFACIAwADIAsAFIAVABIAUABIANgDQAIgBAGACQAGgCALgBQANgBAFgBQALgEAGgBIAhgDIAYgFQACgBAEACQAEgDAKgBQAMgBAEgCQAGACARABQAOAAAHAEQAIgEAKADQAJABAFAFQgKAJgNABQgDgDgNABQgMABgGgDIgaAEQgPACgIAGIgfAHIgNACIgKADIgLAEIgNABQglAHgWgBQgCACgIAAQgJAAgCACIg4gCg");
	this.shape.setTransform(146.3,193.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABjBwIgSABIgTABIgPgDQgJgCgHADIgCgBQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAgBAAAAQgMABgTgCQgagDgJgBIgMgCIgMgDQgeABglgKQgngOgUgFQgZgJgIgCIgXgNQgPgGgNAAQgCgCgEgBIgHgDQgdAAg1gCQgxgCgaAAQgEgSAAgQQAAgXAHgKQAWgLAGgDIBEgHIAeACQASABALgGIADABQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIAGgCQAEgCACADQAGgDARgDQAPgDAGgEIAEAAIADAAQAhgJAZgEQAGgDATgEQANgCAhgJQAagEAYAAQAVgEAuAAIACgBQAAgBAAAAQAAAAABAAQAAAAAAAAQAAAAAAABIAJAAIAKABIAVAAQAMAAAHABIANAFQAIACAGAAIAHAEQAOACAWAJQAYAJAMADQABACAFACIAIAAQAGAEAPADQAQADAGAEIAnAFQAXAFAPAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAABAAAAIABACIBdAGIAKAIIAJAHIgUAXQgMALgKAIIgRABQgKgCgFgEQg4gMgRgGQgXgCgJgEIgegCQgRgBgKgEQgTgCgtgNQgogLgagCQgGgCgPgBIgXgEIgYADQgNAAgLgBQgKADgWAAQgVAAgKAEQgCgBgDABIgGAAQgHAEgTAEQgSAFgIAEQgKAAgLAIQgVAGgEADQgIABgLADQgKAEgHAAQAFADAVABQAfANAtAMIBOAUQAMgBAVAEQATADAOAAQAjAJAXgDQAYAFAkgCQADgBAJgCQAGACAHgBIANgCQABAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIABgBIAQgDQAKgBAHAAQAEgBAQgCQANgCAFgFQAIABAEgEQAJADANgIIAKAEIAQgBIARAAQAKAEAPgCQACADAFABQAFABAEgCQAJAFAKgBQADAAACADIADAGQgFAHgJAIIgPAPQgKAAgBgDQgMADgKgGQgHABgLgBIgRAAIgOAFQgIAEgGgCQgIAEgTAEQgTAFgIAEQgUABguAIIgHgBIgLABIgLABQgPADgGAAIgHgDgAA7BnIA4ABQADgBAIAAQAIgBADgCQAWABAkgHIAOgBIALgDIAKgEIANgCIAfgHQAHgGAPgCIAbgEQAFAEANgCQAMgBAEADQAMAAALgKQgFgFgJgDQgKgCgJADQgGgEgPAAQgQgBgGgBQgEABgMABQgKACgEACQgEgBgDAAIgXAHIgiADQgGABgLAEQgFACgMAAQgMABgGADQgFgDgIABIgOADIgUAAIgUgCIgtgFIgugDQgEgCgNgCQgMgBgEgCQgdgEgmgKIg/gRQgdgKgjgJQgEABgGgCIgKgBQgGAAgMAEQgMAEgHABQg9AEgOAAQgQAEgXgFQgbgFgJABIACACQAAAAABABQAAAAgBAAQAAAAAAABQAAAAgBAAQAsAHAjgCQAMACAWgBQAYAAAMABIAGgCIAIACQAEACADADQAXAGAWAOQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAAAQAHAGAPAEQARAFAGADQAQACAHAGQAHAAANAGQAPACARAGIA2AEQANAFAcAAIABABQABAAAAABQAAAAABAAQAAAAABAAQAAAAAAAAQAXADAgACgAmUgnQgLAEgSAKIgEAGQgDAEAAAEQAHAGgEAEIAiACQADACAJACIANADIAkgCQAVgCAMABIARgCQAKgBAFgCQAXgBAGgGQAEgCAIACQAAgBABAAQAAgBABAAQAAAAABAAQABgBAAAAIAEgCIAGAAQACgCAGgBQAFgCACgCIAGAAQADgBADAAQAGgEAQgDQAJgFAVgFQAVgGAJgFIAlgHQAWgFAQAAQAJAAAbgBQAVgDANADQAYgBAfAFIA0AIQADADADAAIAKAAQAVANAaAAQANAGASACQASACAMgCQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAABAAAAQANgCAPAFQATAFAGABQANAIAWAEIAnAHIAEgEIAEgCQANgBAQgRQgHgIgLgDQgLgBgWgDIgigEIgGACQgDgCgHABQgFgDgKABIgQAAIgPgFQgJgDgGABQgIgEgGABIgegJQgOgBgLgGQgNgCgRgHIgcgLIgegJQgKgBgXgIIgnAAQgXAAgOACIgIgBQgOADgEgBQgGAEgSgBQgRgCgGAEQgXABgkAKQgqALgPACQgGAFgUABQgKAFgXAEQgXAFgKAFQgRACgYAAIgpAAQgDACgIACQgFgCgHAAQgJAAgLADg");
	this.shape_1.setTransform(149,187.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B2B2B2").s().p("AmCA1QgIgCgEgCIghgEQAEgEgHgGQAAgEACgEIAFgGQASgKALgEQASgFAOAEQAIgCADgCIAoAAQAZAAARgCQAKgDAXgFQAXgEAJgFQAVgBAGgFQAPgCAqgLQAjgKAYgBQAGgEARACQARABAHgEQADABAOgDIAIABQAPgCAWAAIAoAAQAWAIALABIAeAJIAcALQARAHANACQAKAGAPABIAdAJQAHgBAIACQAGAAAJACIAOAFIARAAQAKgBAFADQAHgBADACIAGgCIAhAEQAXADALABQALADAHAIQgRARgMABIgFAEIgDAEIgogJQgVgEgOgIQgFgBgTgFQgQgFgMACQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQgMACgSgCQgSgCgNgGQgaAAgWgNIgJAAQgDAAgDgBIg0gIQgggFgXABQgNgDgXADQgZABgJAAQgQAAgXAFIglAHQgIADgVAGQgVAFgJAFQgRADgFAEQgDAAgEABIgFAAQgDACgEACQgGABgCACIgGAAIgEACQgBAAAAABQgBAAgBAAQAAAAAAABQgBAAAAABQgIgCgFACQgFAGgXABQgFAEgKABIgRACQgMgBgVACIgkACIgOgDg");
	this.shape_2.setTransform(148.5,182.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgFA0IAAhoIALAAIAABog");
	this.shape_3.setTransform(179.7,118.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAAAlQgOAAgKgKQgKgKAAgRQAAgQALgKQAKgKANAAQAQAAAJAKQAKAKAAAQQAAASgMAKQgJAJgOAAgAgPgRQgFAHAAAKQAAALAGAIQAGAIAIAAQAJAAAGgIQAGgHAAgMQAAgJgFgIQgGgJgKAAQgJAAgGAJg");
	this.shape_4.setTransform(173.8,119.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AARA0IAAgpQAAgUgRAAQgLABgEALIgBAGIAAArIgNAAIAAhoIANAAIAAAtQAEgFAGgEQAGgEAFABQAKgBAGAHQAJAIAAAOIAAArg");
	this.shape_5.setTransform(165.6,118.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgYAbQgKgKABgRQAAgQAKgKQAJgKAOAAQAPAAAKAKQAKAKAAAQQAAASgMAKQgKAJgNAAQgOAAgKgKgAgPgRQgFAHgBAKQABALAFAIQAHAIAIAAQAJAAAFgIQAHgHAAgMQAAgJgFgIQgGgJgKAAQgKAAgFAJg");
	this.shape_6.setTransform(157.4,119.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgRAbQgKgKAAgRQAAgPAKgKQALgLAPAAQAMAAAHAEIgDAKQgIgEgIAAQgKAAgHAIQgGAIAAAKQAAAMAHAHQAHAIAJAAQAHAAAJgEIACAKQgIAEgMAAQgPAAgJgKg");
	this.shape_7.setTransform(150.2,119.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgFA0IAAhoIALAAIAABog");
	this.shape_8.setTransform(145,118.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAcAyIgLggIghAAIgLAgIgNAAIAihjIANAAIAiBjgAgOAIIAcAAIgKgbIgEgSg");
	this.shape_9.setTransform(138.8,118.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgSL/IgKAAIAAgMQASAAANgCQAhAEA0gFIBUgJQAYAAAngIQAtgJASgCIAMgDQAIgCAEgDQAGAAALgCIASgDIARgKQACgJgCgOIgDgXQADgPgBgHIgDgTQgBgJAAgQIAAgaQgCgWAEg5QADgxgFgdIAChFQACgwgBgaQAAgJgDgFQACgGAAgOQAAgPACgHQgEgkAAgyIgBhXQADgOAAgIIgCg1QADgHgCgOQAAgOACgIIgDglIgCgnIADgKQABhYgIgyQgMhHgkgiIgIAAQgTgVgTgOQgRgFgvgVIgHgCIgJAAIgGgFQgFgCgBgDQgZABgtAEIhHAHQhGAFgjgDQhHgGgogTQgMgEgHAAQgBgBAAAAQAAgBgBAAQAAgBAAAAQgBAAgBAAQgGAAgLAEQgKAEgIAAQAAADgFADQgEADgBACQgKADgOALQgOALgJACQgEAHgPANQgVAngMASQgGAMgFAUIgKAhQgCAVgFAvQgDArADAYIAGgCIAFgDQACADAIACIANADQARgDAZADIApAFIAbgBQAPAAAKADQAnADByAAIAzABIAxACIBhADQA5ACAkgFQANAAADABQAPgFAIADQADAAACgCQADgCAEABIAKAHQAFAEADAEQAAAEgDAHQgEAGAAADQgBAQAAAjIAAA5IgGBRIgLgBIAGiMQAAgLgCgWQgCgVABgMQgZACgHgBQgaAGgpAAIhJgEIhAgBQgoAAgSgCQgZgChOACQhAABglgHQgCACgHAAIgJABQgSgEgggBQgkgBgOgCQgWAAgXAGQgEAdADBKIACA0QABBKACASQgDAvABBUQAABlAAAbIgLABIgBgCIgCgDQACgFAAgDQgDg1ABhoQABhygCgzQgDgNABgZQABgegCgNQgCgJACgbQAAgZgCgKQAFgoAAg+QAAgLADgSIADgcIABgYIAIgTIAIgdQAFgQAFgIQAAgBAAAAQgBgBAAgBQAAAAAAgBQAAAAAAgBIABgFQAEgCAFgJQAFgKAEgCIAHgNQAFgIACgFIAYgUQAPgMANgFIAOgOQAHAAAIgHQAIgHAFgCQACgBAFABIAHgBQAEgBAIgFIALgBQAIAAAFgCQgCgKAAgGQAFgSgBgdIgBgxIgEgFQgCgDgBgDQADgDgBgFIgCgGQABAAAAgBQABAAAAgBQAAAAAAAAQAAgBAAAAIgDgRQgDgrALgWQALgIAJgDQAHADASgDQAQgCAHAEQAEgDALAAQAMAAAGgBQASABAZgBIApgDQAAgBAAAAQAAAAAAAAQAAgBABAAQAAAAABABIABACQARgBAjACQAhADATgBQAZAJAQgFIASAIQAKAFABAKQgHAKAOAIIAWAOQgBAFAAAMQgBAKgHADQgNAAgJAGQgBANAKADIgBAIQgDAFgDABQAFADgBAKQgEANACAdIAFAuQgFAPAGARIAKAAQAIAHAUAFIAfAKQADAGAKAJQAMADAMAIIATAOQACAJAHAGIAPALQAIAUASARIADATQACAMACAHIgBAIQADAGAEASQAEARAFAHQgFASACAdIAEAvQgCAEgBAMQABAHAAAMQgBAOACAGIAABUIgBApQAAAUACAQQgEAOAAAaIACAsQgFAGACAKIACAUIgBAQQABAJADAFQgCAcAAA7QAAA3gBAaIACAFIgCAmIADAJQgDBRAACEQACAEABALQgDASAEAaIAHAvIgCABQgBAAAAAAQgBAAAAABQAAAAAAAAQAAABAAAAQgCACgDgCQgDgBgDAAQgBACgGAAQgGAFgOAEIgWAHQgbAChAAMQg7ALgiACQgQgBgHABIgRADIgSADQgUACgcAAQgbAAghgCgAiBnxIACADQARAEAgACIA0AFIBlgKIAdgBQAQgBAJgEQAMACAUgGIAKgUQAAgTgCglIgEg9QgXgGgxABQg6ABgKgBQgVAAgiADIg2AEIgfgCQgSAAgLAEQgOgGgGACQACAGAAAKQAAAJACADQgDAMABAaQAAAbgDAQIACANQABAHgCAGIAPAFQAIADAJgCIABgBQAAAAABABQAAAAAAAAQABAAAAABQAAAAAAABgAhkqRQAJAAAHACIA1gCQAUgFAfACIA3ABIBZgBQABgHgBgEIgDgIQAAgJALgDQAHgBAKgBIAAgBQgCgCgHgBIgKgBQgDAAgEgFQgCgDgFAAIABgLQABgFAEgDQgBgEgDgEIgFgFQhrgPhtAKIhXACIgFAEIgGADQgFAFgDABQAAALgCAUQAGAFAAAMQAAAQACAGQAFACALgEQAOAHARgGQAFACALAAg");
	this.shape_10.setTransform(162.9,114.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D3D2D1").s().p("AhIJ0IgtgCQgVgFgsABQgxABgTgDIgPgEQgJgCgFABIgYgJQgOgFgLAAQgHgDghgLQgEgKADggQABgMgCgVQgDgZAAgJQgBhkACgvQAPAGAfACQAjADANADQAyAFBJgBIB8gCIAbABQAPABALgBIBOABQAvABAegHQAQACAYgCIAmgGQAYgCAOgEQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAIACgDIgGgMQgCgGgBgFQAEgIAAgIIgCgQIABgKQACgGgBgDIgCgJQgCgFAAgEIADhAQgCgCAAgFQAAgFgDgCQADgBAAgFIgBgHIADgxQADgLgBgVIAAgiIAEgSQAAgLgCgbQgBgZAAgNIAGhTIABg5QgBgjACgQQAAgDADgGQADgHAAgEQgDgEgFgEIgKgHQgDgBgDACQgDACgDAAQgIgDgPAFQgCgBgNAAQglAFg5gCIhggDIgygCIgzgBQhyAAgngDQgKgDgPAAIgaABIgqgFQgYgDgSADIgNgDQgIgCgCgDIgFADIgGACQgDgYAEgrQAFgvABgVIAKghQAGgUAGgMQALgSAVgnQAPgNAEgHQAJgCAOgLQAOgLAKgDQABgCAEgDQAFgDABgDQAHAAAKgEQALgEAHAAQABAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAHAAAMAEQAoATBIAGQAiADBGgFIBHgHQAtgEAZgBQACADAFACIAGAFIAIAAIAHACQAvAVARAFQATAOATAVIAIAAQAkAiAMBHQAJAygCBYIgDAKIACAnIADAlQgCAIABAOQABAOgDAHIACA3QAAAIgDAOIABBXQAAAwAEAkQgCAHAAAPQAAAOgCAGQADAFAAAJQABAagCAwIgCBFQAFAdgDAxQgDA5ABAWIABAaQgBAQABAJIADATQABAHgDAPIADAXQACAOgCAJIgRAKIgSADQgKACgHAAQgEADgHACIgMADQgTACgtAJQgnAIgYAAIhUAJQgzAFgigEQgNACgSAAIgtgCg");
	this.shape_11.setTransform(162.8,126.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgGBlQgDgFABgQIADgYIABgWQABgOgDgJIAEhwIAJAAQgBANACAaQACAbgBANIgDASIAAAgQAAAUgCAMIgDAqg");
	this.shape_12.setTransform(191.4,129.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AhcD6QhKgEgpAAIhVgYQgHAAgJgCIgQgEQAAABAAAAQAAAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAAAQAAAAgBAAQAAAAgBAAIgLABQgDgIgDgEIAEgOQACgmgCgVIgBgfIAAgfIgChyQAAhCACgvQACgIAAgBIAKgBQADAOgBAdQgBAiABAKQALAEASACIAfAEIAfAFIAjAEQAcACA8gBQAtACBigCQAkAABJABQBBAAAsgFQAJgEAWgCQAYgCAIgCIAJgIIACgqQACgagFgPQADgPAAgZIgBgmIAAgIQAAgFADgCIAJABIAAAHIABAHQAAAEgDABQACACAAAFQABAGACACIgDBAQAAADACAGIACAJQAAACgBAHIgBAJIABAQQAAAIgDAIQAAAGADAFIAFAMIgBADQgBABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgPAEgXADIgnAFQgXADgQgCQgeAHgvgBIhPgBQgKABgRgBIgcgBIh6ACQhJAAgxgEQgNgEgkgCQgfgDgPgGQgCAvABBjQAAAJADAYQACAVgBANQgCAgADAJQAiALAHAEQALgBAOAFIAYAJQAFgBAIADIAQAEQATADAxgBQAsgBAUAFIAuACIAqACIAAALIgJABQgjAAhCgEg");
	this.shape_13.setTransform(158,165.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3F3F3F").s().p("AhRBMQgggDgRgDIgCgDQAAgBAAgBQAAAAgBAAQAAAAAAgBQgBAAgBABQgIABgJgCIgPgGQACgFgBgHIgCgOQAEgPgBgZQgBgaADgMQgCgEAAgIQABgLgDgFQAGgCAOAGQALgEASAAIAfACIA2gEQAigEAVAAQAKACA7gBQAwgBAYAGIADA9QADAjgBATIgKATQgUAHgLgCQgKAEgQABIgcABIhmAJIg0gEg");
	this.shape_14.setTransform(163.2,57.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#666666").s().p("AhtAsQgKgBgGgBQgQAGgOgHQgMADgFgBQgBgGAAgRQAAgMgHgFQACgRAAgMQAEgBAEgFIAGgDIAGgDIBWgCQBtgLBrAPIAFAGQADADABAEQgDADgBAGIgBAKQAEAAADAEQADACADAAIAKACQAHABACACIABABQgLAAgGACQgMACAAAJIAEAJQABAEgBAHIhZABIg3gCQgfgBgUAFIg1ACQgIgCgJAAg");
	this.shape_15.setTransform(163.8,43.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F4E3D3").s().p("AAeE2QhiACgtgCQg8ABgcgCIgjgEIgfgFIgfgEQgSgDgLgEQgBgJABgiQABgdgDgOQABgbgBhmQAAhRADgwQgCgSgChMIgCg0QgChJADgeQAYgGAWAAQAOACAkACQAgAAARAEIAKgBQAHAAACgCQAlAHBAgBQBMgBAYACQAVABAoAAIBAABIBJAEQApAAAagFQAHAAAZgBQgBALACAVQACAXAAAKIgKD/QADAIgBAOIgBAXIgDAXQgBAQADAGQgDABAAAFIAAAIIABAnQAAAZgDAPQAFAPgCAZIgCAqIgJAIQgIADgYACQgWABgJAFQgsAFhBAAQhJgCgkABg");
	this.shape_16.setTransform(158.2,128.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAAAnQgJAAgHgKQgHgLAAgSQAAgQAHgLQAHgLAJAAQALAAAGALQAHALAAAQQAAASgIALQgHAKgJAAgAgKgSQgEAIAAAKQAAAMAEAIQAFAJAFAAQAGAAAEgJQAEgIAAgMQAAgKgDgIQgEgJgHAAQgGAAgEAJg");
	this.shape_17.setTransform(-66.5,153);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgLAcQgHgKAAgSQAAgPAHgLQAIgMAJAAQAJAAAEAFIgCAKQgFgEgGAAQgGAAgEAJQgFAIAAAKQAAANAFAHQAEAIAGAAQAHAAAEgEIACALQgHAEgHAAQgKAAgGgLg");
	this.shape_18.setTransform(-71.5,153);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgDA1IAAhJIAHAAIAABJgAAAgiQgEAAAAgJQAAgJAEAAQAFAAAAAJQAAAJgFAAg");
	this.shape_19.setTransform(-75.1,151.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgCApQgEgFAAgOIAAgnIgIAAIAAgLIAIAAIAAgOIAHgEIAAASIAOAAIAAALIgOAAIAAAmQAAAPAHAAIAGgBIAAAKQgCACgGAAQgGAAgCgGg");
	this.shape_20.setTransform(-78,152.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgWA1IAAhnIAIAAIAAANIABAAQAFgPAKAAQAJAAAGAKQAGALAAARQAAARgHALQgGAKgJAAQgJAAgFgLIAAAogAgHglQgEAFgBAIIgBAFIAAANIABAGQACAOAKAAQAGAAAEgIQAEgGAAgNQAAgMgDgIQgFgIgGAAQgDAAgEAEg");
	this.shape_21.setTransform(-82.4,154.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgOArQgGgLAAgQQAAgQAGgLQAHgMAIAAQALAAAFANQAEAJAAALIAAAHIghAAQABAaAOAAQAHAAAHgEIACAJQgHAGgKAAQgJAAgHgLgAgMAHIAZAAQAAgUgNAAQgJAAgDAUgAgCgeIAHgWIAKAAIgNAWg");
	this.shape_22.setTransform(-88.1,151.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgPAiIACgLQAGAGAGAAQAIAAAAgLQAAgJgHgFQgOgGAAgOQAAgJAFgGQAFgHAGAAQAIAAAEAFIgCAKQgGgEgFAAQgGAAAAAKQAAAHAHAGQAOAFAAAPQAAAKgFAHQgFAGgHAAQgIAAgGgFg");
	this.shape_23.setTransform(-92.7,153);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgDA1IAAhJIAHAAIAABJgAgEgrQAAgJAEAAQAFAAAAAJQAAAJgFAAQgEAAAAgJg");
	this.shape_24.setTransform(-95.9,151.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgCApQgEgFAAgOIAAgnIgHAAIAAgLIAHAAIAAgOIAHgEIAAASIANAAIAAALIgNAAIAAAmQAAAPAHAAIAFgBIABAKQgDACgFAAQgGAAgCgGg");
	this.shape_25.setTransform(-98.9,152.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAMAmIAAgpQAAgXgLAAQgIAAgDAOIgBAHIAAArIgJAAIAAhJIAIAAIAAAMIABAAQAFgOAKAAQAGAAAEAHQAHAIAAARIAAArg");
	this.shape_26.setTransform(-103.4,153);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AATA0IgHghIgXAAIgIAhIgJAAIAYhnIAJAAIAYBngAgJAIIASAAIgJgvg");
	this.shape_27.setTransform(-109.3,151.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgRAVQgHgJAAgMQAAgLAHgJQAIgJAJAAQAKAAAIAJQAHAJAAALQAAAMgHAJQgIAJgKAAQgJAAgIgJg");
	this.shape_28.setTransform(-90.4,83.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(1.9,0,0,4).p("AgRgLIAjAX");
	this.shape_29.setTransform(-71.5,121.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AiOJbIgIgFQhTgFgtgVIgEAAIgEABQgEgBgEgDIgFgHIABgKQAAgGAEgBIADgNIAAgLIACgEIgBgBQgBAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQACgRAAgKQgBgLABgVIgBgfIgDguQgCgbABgQIgDgHQACgFgBgJIgBgRQAGgrgFgfQABgGABgBQgCgJgBgEIABhDQABgngCgdQABgTAAgnQAAgmABgUQAFgkAXgoIAKgIQAGgFABgHQAOgIAIgLQAFAAAFgGQAFABAAgDQAFAAAIgDIALgDIALgEQAHgCABgFQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAAAABIAAACQgBAAAAgBQgBAAAAgBQAAAAAAgBQAAAAABgBIADgFIgDgMQgBgHAEgFQgBgHABgHQACgHgCgHIADgGQADgEgEgDQADgDADgFQADgFACgCQAEgCAKABIAEgCIAHAAIAMAAQAGAAAFgBQAAADAHgBQAGgBADACQAHgJABgRQgCgFAAgMQABgLgDgFQAEgEABgOIABgVQABgEAAgNQAAgMACgGQgEgTAGgGQgCgUACgcQADgfABgSIgFgKIAFgKQADgGgBgHIAKgPQAGgIAIgDQAEgNAXgDQAMgCAZgBQAVAIAKAGQAQAKAGAOQAAAFACAFIAAAVQABAKgCAIQADAMAAAnQAAAjAHASQgCAJACAQQABAOgBAIQAIASgFAtIADALQABADAAAGQAWgGAVAHQAKADAZAQQAJAXgEA/QgCAKgDAEIgDAFIgJAEQgEACgBADIgKACQgFABgBADQgKABgSAFQgUAGgKABQgcgEgngCIhGAAIgvgJQgdgGgQgFIgFABIgEAAQgJgCgBgCQgcAJgmAcQgvA+AHBAQgDAHABAMIADAUQAAAEgDAEIABBPIgBApQgCAYAFAQQABAqgBBHIAEB0IACALQAAAIACAFQgDAMABAaQgBAdgCAOIADAHQACADAAADQATANAjAFQAUAEAqADQAEAAAFADQBaAMBPgGQAFgBAQAAQAQAAAHgCQAnACAsgKQAZgFAugOQAcgNAUgGQgBgHAIgHQACgWgDgHQADgPACgTIADgfQABgMgBgSIgDgeIACgLQABgIgEgEQACgKACgDQgDhEAEgcQgEgFADgQQACgRgFgIQAEgFAAgDIgBgcQgBgQgDgJQAEgOAAgUIgCgmIgDgMQADgYgFgdQgIgmAAgRQgFgNAAgJQgFgGAAgIQgPgRgXgOQgXgOgVgGQgBAAAAAAQgBAAAAAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQgBAAgBAAQAAAAgBABQgCgKADgFQACgFAGgBQAQAEAXAPQAbARALAFQATARAMAxQgBAQAFAfQAFAeAAAOQAEARgCAmQgBAnACAQIgBAxQAAAcACATQgHBTAJBUQgEAYgCAqIgDA/QAGAEgCAIIgFANIgGACIgHAAQgEAEgEABQgOACgSAHIggALQhEARgmAFQhEgDhJAIQgtgEg4gCgABAidQANACAIgBQADgDAHgBQAJgBACgCQgGgHABgHIADgEQABAAAAAAQABAAAAgBQAAAAAAgBQAAAAAAgBQADgOgDgUIgGgiQAFgGAEgBQAIACABAGQABAJAAAhQAAAaAFAKIgBADQgBAAAAAAQAAAAAAAAQgBABAAAAQAAAAABABIAHgBIAHgBIALgMQAGgGACgHQACgLgEgSQgDgTABgHQgNgLgIgFIgZgCQgMgBgLACQgLABgWABIgnADQgSgDgvAFQgyADgUgCIgGADQgDACgCgCQgBAEgFACIgHAEQgIApAMATQAAADgBAGIAKACIAKACQAAgDgCgCIgDgFIABgSQAAgJgEgFQACgDADgPQADgLAHgCIAFACIAGADQgCACACAEQABAFgBADQAAACgFABIAAAYQABANAGAKIgCADQgBABAAAAQgBABAAAAQAAABAAAAQAAABAAABQBUARBCgJIADACQAAAAAAABQABAAAAAAQABAAAAAAQABAAAAAAIAFAAIANABgABqimIABABIACAAQABAAAAgBQAAAAAAAAQAAgBgBAAQAAAAgBAAIgBAAQAAAAAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAgAikj+IACAAIABgDIgDAAgAgLpMQgPAFgNAIIgGAKQgCAFgGABQgLAoADAhQgCAXAAAgIgCA5QgEAMAAAcQAAAggBAHIADAIQABAEgBADQAXADAsgEQAqgEAWACIgDgNIAGgRQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAEgOgEgYIADgIQgHhWgBggQAAAAAAgBQAAAAAAAAQgBgBAAAAQAAAAgBgBQAAAAgBAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAABAAQAAAAAAgBQAAAAAAAAQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIgCgkQgBgUgFgQQgEAAgCgEIgEgFQgCgCgFgBIgIgCQgBgEgCgBQgJgDgKAAQgFAAgJACg");
	this.shape_30.setTransform(-88.8,137.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFBF00").s().p("AiTFzQgEgDgEAAQgqgDgVgEQgigGgUgMQAAgDgCgEIgCgGQACgOAAgdQAAgbACgMQgBgEAAgIIgCgLIgEh0QABhHgBgpQgFgPABgYIACgpIgBhPQADgEAAgEIgDgVQgCgMAEgIQgHhBAvg9QAmgcAbgJQACACAIACIAFgBIAFAAQAQAFAdAFIAvAJIBFABQAoABAcAFQAKgBAUgGQASgGAKAAQABgEAFgBIAJgBQABgEAFgCIAJgDIADgFIAEADQgCAFACAJQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAABAAAAQABAAAAABQAAAAABAAQAAAAAAAAQAWAGAXAOQAWAOAQARQAAAHAFAHQgBAJAGANQAAAQAHAmQAGAggDAYIADAMIACAlQAAAVgEAOQADAJABAQIABAcQgBADgDAFQAEAIgCAPQgCAPAEAGQgEAcADBDQgCAEgCAKQAEAEgBAHIgCAMIACAeQACASgBALIgDAgQgCATgEAOQAEAIgDAWQgHAHABAHQgUAGgcAMQgvAOgZAGQgrAKgngDQgIADgPgBQgQAAgGACQgXACgaAAQg6AAg+gIg");
	this.shape_31.setTransform(-88.8,159);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAAABIAAgBIABAAIgBABg");
	this.shape_32.setTransform(-105.2,112.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#3F3F3F").s().p("AA/A3QgMgCgGABQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAIgCgCQhCAJhVgSQAAAAAAgBQABgBAAAAQAAgBAAAAQABgBAAAAIADgEQgGgJgBgNIAAgWQAEgCABgBQABgDgCgFQgBgFABgCIgFgCIgFgCQgIACgCALQgDAPgCACQAEAEAAAJIgBASIADAFQACACAAADIgLgCIgKgDQACgFgBgDQgLgTAIgnIAHgEQAFgDAAgDQADABADgBIAGgDQAUACAxgEQAwgEASADIAmgDQAXgBALgCQALgCAMABIAZADQAIAFAMALQgBAGAEATQAEARgCALQgCAHgGAGIgLALIgHACIgIAAQAAAAAAAAQAAgBAAAAQAAAAABAAQAAgBAAAAIACgCQgFgLAAgZQAAgfgBgJQgCgGgHgCQgEABgFAGIAGAiQACARgCAPQAAABAAAAQAAABAAAAQgBAAAAABQgBAAAAAAIgDADQgBAIAGAHQgDACgIABQgIABgDADIgGAAIgOgBgAAtgiQALAdgBAaQgDADAAAGIgCALQAFAJAKgCQAKgDgBgLQgHgLgBgbQgBgegFgIIgGgBQgGAAgDAJgAhAgmQgHAAgCAHQAAAIAFAZQADATgDAPQADAGAHADQADgBACgDIAFgEQAAAAAAAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAAAABAAQAAgBAAAAQAAAAAAAAQgNgSAGgwQgCgGgFAAIgCAAgAgCAqQAHgCAFgDQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBIABgDQgFgFgCgEQgDgKgBgVQgBgVgBgKQgEgCgEACIgGADIgBAJQgBAFADACQgBAEABAEIADAGQACAFAAAKQgBAKACAFQgBABgEAAQABACgBAHQABAAABAAQABAAAAAAQABAAAAABQAAAAAAABIAAAFIACAAQACAAADADg");
	this.shape_33.setTransform(-88.7,116.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgHAiQADgQgDgSQgEgZAAgIQACgHAHgBQAEgBACAIQgEAwAMASQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAABAAQAAABAAAAIgFAEQgDADgDAAQgEgCgEgGg");
	this.shape_34.setTransform(-94.9,116.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgGAoIAAgGQAAgBgBAAQAAAAAAgBQgBAAgBAAQAAAAgBABQABgIgBgCQADABACgCQgCgEAAgLQAAgJgBgGIgDgGQgCgEACgDQgEgDABgFIACgJIAGgDQAEgCACACQADAKABAWQAAAVADAJQACAEAGAGIgCADQAAAAAAABQAAAAgBABQAAAAABABQAAAAAAABQgGADgHACQgDgEgDABg");
	this.shape_35.setTransform(-88.9,116.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#666666").s().p("AhBCaQABgDgBgFIgDgHQABgIAAgfQAAgcAEgNIABg5QABgdACgXQgDghALgoQAFgBADgFIAFgKQANgJAQgEQARgEAPAFQACABABAEIAJACQAFABACACIAEAFQACAEADAAQAFAPACAVIABAkQAAABABAAQAAABAAAAQAAAAgBABQAAAAAAAAQgBAAAAAAQAAABAAAAQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAAAABQAAAgAIBTIgDAJQAEAXgEAPQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAABQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABIgGARIADANQgWgCgsAEQgaACgUAAIgTgBg");
	this.shape_36.setTransform(-89,94.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgIAnIABgLQABgGADgDQAAgagKgdQADgNAKAFQAEAIABAeQABAbAIALQAAALgKADIgDAAQgFAAgEgHg");
	this.shape_37.setTransform(-82.6,116.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAAABIAAgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAABg");
	this.shape_38.setTransform(-77.9,121.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AhuBLIgsgEIgPABQgJAAgFgBQgHABgJgBQgJgCgFgEQgDABgEgDQgEgEgCABQAAAAAAAAQAAgBgBAAQAAgBAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAAAABgBQgKgBADgGIgDgBIACgCQgDgEgCgBQAAgKgDgDIgDgSIABgCIAAgBIgCgFQAAgDADgCQABgFADgGIAFgLQAFgDAHgKIANgIIADAAIALgEIAQgDIAEgCIACABQADAAAFgCIADAAIAKgBQAGgCAMAAIAUgDIAYgBQAPgCAKABQATgDAsAAIAEgBQAMAAAogDQANABAPgDQALACAUAAIAfABIADAAQAPgBAcAEIANADQADgBAEACQAFADACAAQADADADgBIAEAEQACADADABQAAADAFAEIAEAIQACAEAAAEQADADACAJQACAJACADQgBABABAEIgBAJIACAEIgBALIgCAKQgEAHgLAKQgHACgGAEQgKABgSAGIgQAAQgLACgGgBIgGABIgEABIgkABQgYABgMAAIgEABIhIABQgBABgGABQgUACgHgDQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAABAAAAIgBABIgeAAQgJACgNAAIgWgBgAA3hDIgkACIgQABQgHABgoAAIgXADIgXABIgCAHQACAHAAAMIABATIAEAQIABAQQACARAAALQADAHACANQAAAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAQAMAAAOgDQAvABASgDQA3AAAjgDIAAgEIgBgCQACgKgBgRIAAgaQgCgCAAgGIgBgVIAAgYIgCgIIgCgJIgSABIgGgCIgRACgAh3BCQAGADAbAAIgBgDIgBgCIAAgFIgBgTQgIgzgCgnQgCgGABgCQgRAAgZADIgpAGQgGACgKABQgQAHgHAFQgBADgHAHQgFAKgFAOIAAAJQABAGgBAEQACACACAHQABAHADABQAAAAAAABQAAAAAAAAQgBABAAAAQAAABAAABQAEACAAADQACgBADAGIACAAIACAAIADAEIAFACIAFAEIALAEIAIAAQAFAAACABIAJAAIA1ABgABphDIADBCQACACAAANQAAAOACAFIgBAJIABAKQABAFgCAEIA6gDQAjgDATgJQABAAAAgBQABAAABgBQAAAAAAAAQABAAAAAAIAIgIQAFgJABgEQABgQgCgHQABgKgFgGIgFgPQABgBgBABIgBgBQgEgPgTgKQgDAAgGgDQgGgDgFABIgEgCQgpgEgkAAg");
	this.shape_39.setTransform(39.8,191.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#F2B17C").s().p("AArA9QgpgCgTABQgCgBgFABIgHgBIgMgEIgFgDIgFgDIgCgEIgCAAIgCAAQgDgGgDABQAAgDgDgCQAAgBAAgBQAAAAAAgBQAAAAAAAAQABAAAAAAQgDgCgCgGQgCgIgCgCQABgEAAgFIgBgKQAFgOAGgKQAHgHABgDQAHgEAQgIQAJAAAGgDIAngGQAZgDARAAQAAACACAGQACAnAIAzIABATIgBAFIACACIABADQgbAAgHgDg");
	this.shape_40.setTransform(23.3,191.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#DD781D").s().p("AhUBEQABAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQgBgNgDgGQAAgMgDgQIgBgQIgDgQIgCgTQAAgNgBgGIABgIIAXgBIAYgCQAnAAAJgCIAPgBIAjgBIASgCIAFABIASgBIACAJIACAIIAAAYIACAVQAAAGABACIABAbQABAQgDAKIABADIABAEQgkACg2AAQgSAEgwgBQgNACgNAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBg");
	this.shape_41.setTransform(40.3,191.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#F2B17C").s().p("Ag7A4IgCgKIABgJQgBgFAAgOQAAgNgDgEIgChBIAAAAQAkAAAnAEIAEABQAFAAAGACQAHADADABQATAJADAQIABAAQABAAAAABIAEAOQAFAHgBAJQACAHgBARQAAADgFAKIgIAIQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAABQgTAJgiADIg6ADQACgEAAgFg");
	this.shape_42.setTransform(57.1,191);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#D3D2D1").s().p("AGTArIgKABIgCgDIgDgCQggADgPgCQgCgJABgPIACgXQgCgCgDgBQgFADgBACQAAABAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIADACIgCAnIgHAAQgFgPAHgGQgBgFgDgCIgGACIgBAaIgEAAQgHgCACgLIAAgQIgDAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQgFAEABAJQABANAAADIgFAAIgCgMQgCgIABgGQgBgBgHgDQgFAKAGAMIgBAIIgIAAQgEgVAAgFQgCgDgEAAQgEAAgCAEQgBAHAGACIACAIQABAEgBAEQgHgBgEABIABgEQgJgXAEgRQgBgEgDgCQAAAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAIgDACIABAQQADAMgBAFQAAADACACIgEAFIACABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQgDABgGgBIAAgCQAAAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAgBAAIgEgBIACgPQABgIgEgDQgGABgCADQAEAFgBAJIgBAOIgCAAQgEgDgBgIQAAgIADgGQgCgEgEAAQgFADAAAKIAAAQQgDgEgCgIQAAgHABgGQgBgGgDAAQgHACABAKQADAOgCAEQgDABgDgCIgEgEQgBgEABgLQABgJgEgDQgGADgCgBQgBAGAEAOQACALgMgBQgFgdACgPQgCgEgFABQgGABAAADIAFAGIABAVQAAALgCAGQgDgCgDACQgEgEgBgJQgBgJAEgFQgBgEgEgBQgEAAgDACQgBAGACAJIACAOQgBAAAAAAQgBAAAAgBQgBAAAAgBQgBAAAAgBQgBgEgCgBQgCgMADgFQgCgEgCgCQgDgBgDACIgDADQACAGACAVIgEAAQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAAAAAQgEgDAAgKQAAgLgDgDQgGABgBACIACAMQACAGgDAEIABACIAAACQAAAAAAABQAAAAgBAAQAAAAAAAAQgBAAAAAAIgCgBQAAAAgBgBQAAgBAAAAQAAgBAAAAQgBgBAAAAIgDgEQgBgFABgHIABgKQgEgBgFACIABAOQABAJgBAFQgDADgEgEIAAgDQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAgBABAAQAAAAAAgBQAAAAgBAAQAAgBgBAAQgBABgBAAQgDgaACgIQAAAAAAAAQAAgBgBAAQAAAAgBgBQgBAAAAAAIgEABIgDACIACATQACANgBAIQgEACgHgFIAAgLQABgHACgDQgBgFgFAAQgGgBAAAGQADAFgCATIgEAAQgDgEgBgIQgBgHADgGQgBgBAAAAQAAgBAAgBQgBAAAAAAQAAgBgBAAQgDgCgDABIgDAGQAHAQgGAHQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAgBIABgDQgEgBgBgHQgBgGACgGQgBgFgFAAQgFABAAAFQAEANgBAKIgGAAQACgFgFgDIgBgTQgBgFgGABIgCABQAAABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAIAAAEQAHAFgDAUIgDAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAgGgEgJIgBgQQAAgGADgGQgDgGgJADIADAtQgCACgJgCIgBgLQgBgHACgEQgCgDgGgBQgEADACAJQABALgBAEIgFgBQAAgPACgIQgDgDgDABQgDABgCADIABAIQAAAGABADIgCAFQgLgCAGgWQgBgDgDgBQAAgBgBAAQAAAAgBAAQAAAAgBAAQAAAAgBABIgCADQAAAAgBABQAAAAAAAAQAAABAAAAQgBABAAAAQAEAHgDAOIgEABQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgFgEABgMQACgLgFgDQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBABAAAAIgCAAQgDABAAAFIgBABIACAGQADADAAADQAAAFgBAIIgJAAIgCgHQgEgFAAgOIACgTQAAgEgFAAQgFAAgBADQADAGgBAMQgBAQACAGIgBAFQgIADgDgEIAAgRQAAgIgIACIgBAZQgDAAgBgDIgBgGIgBgHQgBgFACgDQAAgDgFgBQgFADABAKQABAMgDADQgFgDABgHIgBgOQgDgEgEACQgEADADAKQACAKgFACIAAgFQgBgEgDAAIAAgMQABgHgEgCQgCAAgEAHQABADAAAJQAAAIABAEIgIgBQgBgEgDAAQAAgQgCgUQACgDAAgDQgBgCgGgCQgHAGAGATIAAAOQgBAIgCAEIgHAAQgBgCAAgPQgBgKgHAAQgFADADAJQAEAKgDAFIgFAAQgEgHACgUQgHgCgDAEQAAABAAAAQABABAAABQAAAAgBAAQAAABgBAAQABACABAHQAAAHABADQgBAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAQACgEgFAAIAAgPQABgIgFgDQgDABgDADQAEAQgDAKIgGAAIAAgBIABgCQgEgCgBgIQAAgHADgEQgCgGgFABIgEACIgCADIACALQACAIgBAEQgDADgEgCQgGgUACgcQgBgEgFAAQgFABAAAEQADAJAAANIAAAYIgJABQgFgNACgHIACgFQACgDgDgCQgGgBgDABQAAABAAABQAAAAAAABQgBAAAAAAQgBAAAAAAQAAAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAQgCAEACAEQAAAIABAIIgGABIABgDQgGgFACgSQgBgDgEAAQgEABgBADQADAQgBAJQgBABgEgBQAAgBAAAAQAAgBABAAQAAAAAAAAQABAAABAAQgGgHACgRQgCgEgFAAQgEABAAAFQAAAEADADIgBAIQAAAEABADQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAgBAAIgEgBQACgBAAgEQAAgDgCgCIgBgIQgBgGABgDQgBgDgEAAQgDAAgCACQAAAFABAJIABAMIABABQAAAAABABQAAAAAAAAQAAAAAAAAQAAAAAAABQgCABgEgBIgGAAQAAgBAAAAQAAAAAAAAQAAAAAAAAQABgBAAAAIACAAQgFgPACgHQgDgJABgPQAAgBAAAAQAAgBABAAQAAAAAAgBQAAAAABAAQAAgBgBgBQAAAAAAgBQAAAAAAAAQAAgBABAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAgBAAIgFgBIgDAEQABAGgBAEQACADAAAGIAAAJQACAHgDAKQADADgCAGIgNgBIABgLQABgHACgEQgCgFgDgCQgGABgCACQgCADACAFQAFADgDAPQgDABgEgBQgCgFAAgHIgBgLQgFgEgDADQgCADACAIQACAJgCAFQAAAAgBAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAAAABgBIgCABIgBgHQgBgFACgCQgCgEAAgEQgBgCgEAAIgFADIADAOQAAAHgDAEQgBgBgBgHQgBgGgBgCQAAgBAAgEIABgGQgEgEgEABQgEAEACALIADAPIgGAAQAAAAAAgBQAAAAAAAAQgBgBAAAAQAAAAgBAAIgBgYQgBgMABgJQgDgHgIADIACAZQACAQgDAKQgEABgLgCQgJgCgFADQgagCgHgGQAAgDgCgGQgDgFACgEIgBgEIACgZQACgQAIgGIAJADQAFAAAEgDQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAgBQAIACAOgDQCbACBsgBIBMAAIAQABIAVgBICcABIAlACIAvABIAJgBQAGAAACABQAugCB0AGQAHgCAFAEIARgBQAJgBAFAEIAMgEQAPABANAIQABAFAHAAQAAABAAAAQAAABAAAAQAAAAAAABQABAAAAAAIAEACIADAEQACACAHAAQAGAAADACQAHgBAmAAQgBALACAGQgEAFADAEIAAACQgNADgMgFQgDADgFgDIgCACQgDgCgGAAIgJgBQgHAHgCAIIgCAAQAAAAgBABQAAAAAAAAQAAAAAAABQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBABgBAAQgCACABADIgCABQgFAFgIABIgOABg");
	this.shape_43.setTransform(131,-13.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AFDA4IgjgBQgEgCgRAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABIgCABIgFAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAgBIgCgCQgDABgJgBQgJgBgEADQgDgCgGABIgEgCIgXAAQgFgCgHABIgNAAQgOgCgIAAIgJACQhJgDgfABIgqgEIgygBIgzgBQgCADgEAAQgDAAgDgDIjUAAIgGADIgGgDIg6ABQgjABgVgCIhyABIgOgIQgBgFgEgEIgBgOQgBgKADgDQgBgFABgJIABgNQACgRANgGQAEABADgCIAHgDQADACAHACQAgABA3AAIBXABIApAAIBKAAQAxAAAcABIBgAAQApAABQABQAyAAANgBQAdADAyAAQA8AAAUABIAEACQAKABASgDQADAAAHADIAOgCQALgCAUADQAFACAAABQAEAAAGACIAJAEIACADQAAAAAAABQAAAAAAAAQABABAAAAQAAAAABAAIAFACQAAABABAAQAAAAABABQAAAAAAABQAAABgBAAQAFAAAIAFQARgBAIADQAQgDAaABQAdACAMgCQAJABAWAAQASAAAJACQAJgCAOABIAQAJQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABIADACQgCACACAGQgFAGgCAGQgkALhEgBIgHACQgMgBgjABQgIgDgNABQgPABgEgBQgEAFgFgBQgDAGgHAFIgLAKQgNABgQAAIgJAAgAFMAwIAOgBQAJgBAEgFIADgBQgBgDACgCQAAAAABgBQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQABgBAAAAIACAAQACgIAIgHIAJABQAFAAADACIADgCQAEADADgDQAMAFANgDIABgCQgEgEAFgFQgDgGABgLQgmAAgHABQgDgCgGAAQgHAAgCgCIgDgEIgEgCQAAAAgBAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQgGAAgCgFQgMgIgQgBIgMAEQgEgEgKABIgQABQgGgEgHACQhzgGguACQgDgBgGAAIgIABIgwgBIglgCIibgBIgWABIgQgBIhMAAQhsABiagCQgPADgHgCQgBABgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBAAAAAAQgDADgFAAIgKgDQgHAGgDAQIgCAZIABAEQgBAEACAFQADAGAAADQAGAGAaACQAFgDAJACQALACAFgBQADgKgCgQIgCgZQAHgDADAHQgBAJABAMIACAYQAAAAAAAAQAAAAABAAQAAABAAAAQAAABAAAAIAHAAIgDgPQgDgLAEgEQAEgBAEAEIgBAGQABAEgBABQABACABAGQABAHABABQAEgEgBgHIgDgOIAFgDQAEAAABACQAAAEACAEQgCACABAFIABAHIACgBQgBABAAAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAABQAAAAAAAAQABAAAAABQABAAAAAAQADgFgCgJQgCgIACgDQADgDAFAEIAAALQAAAHACAFQAFABACgBQADgPgFgDQgBgFABgDQACgCAGgBQADACADAFQgDAEAAAHIgCALIANABQADgGgEgDQAEgKgDgHIABgKQAAgFgDgDQACgEgBgGIACgEIAFABQABAAAAAAQABAAABAAQAAAAABABQAAAAABAAQgBAAAAABQAAAAAAAAQAAABAAAAQABABAAABQAAAAgBAAQAAABAAAAQgBAAAAABQAAAAAAABQgBAPADAJQgCAHAFAPIgCAAQAAAAgBAAQAAABAAAAQAAAAAAAAQAAAAAAABIAHAAQADABACgBQAAgBAAAAQAAAAAAAAQAAAAAAgBQgBAAAAAAIgBgBIgBgMQgBgJAAgFQACgCAEAAQAEAAAAADQgBADABAGIABAIQADACgBADQAAAEgCABIAFABQAAAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQgBgDAAgEIABgIQgCgDAAgEQAAgFADgBQAFAAACAEQgCARAGAHQgBAAgBAAQAAAAAAAAQgBAAAAABQAAAAAAABQAEABACgBQAAgJgDgQQABgDAEgBQAEAAACADQgDASAGAFIAAADIAGgBQgCgIABgIQgCgEABgEQAAAAAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAAAABAAQAAAAABAAQAAgBAAAAQABgBAAgBQADgBAFABQADACgCADIgCAFQgBAHAEANIAKgBIAAgYQgBgNgDgJQABgEAEgBQAFAAABAEQgCAcAGAUQAEACADgDQABgEgCgIIgBgLIACgDIADgCQAGgBABAGQgDAEABAHQABAIADACIgBACIAAABIAGAAQADgKgEgQQADgDADgBQAFADAAAIIAAAPQAEAAgCAEQAAAAABAAQAAAAABgBQAAAAABAAQAAgBABAAQgBgDAAgHQAAgHgCgCQABAAAAgBQABAAAAgBQAAAAgBgBQAAAAAAgBQAEgEAGACQgCAUAFAHIAEAAQADgFgEgKQgDgJAFgDQAHAAABAKQAAAPABACIAHAAQACgEABgIIAAgOQgGgTAHgGQAHACAAACQAAADgCADQACAUAAAQQADAAABAEIAJABQgCgEAAgIQAAgJgBgDQAEgHACAAQAFACgBAHIgBAMQADAAABAEIABAFQAEgCgCgKQgDgKAEgDQAFgCACAEIABAOQAAAHAEADQAEgDgCgMQgBgKAFgDQAFABABADQgCADAAAFIABAHIABAGQABADAEAAIAAgZQAJgCAAAIIgBARQADAEAJgDIABgFQgCgGABgQQAAgMgDgGQABgDAFAAQAFAAAAAEIgCATQAAAOAEAFIACAHIAJAAQABgIAAgFQAAgDgCgDIgDgGIABgBQAAgFADgBIACAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAEADgBALQgBAMAEAEQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAIAFgBQACgOgDgHQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAIACgDQABgBAAAAQABAAAAAAQABAAABAAQAAAAABABQACABABADQgGAWAMACIACgFQgCgDABgGIgBgIQABgDADgBQAEgBACADQgCAIAAAPIAFABQACgEgCgLQgBgJADgDQAGABACADQgCAEABAHIABALQAJACADgCIgEgtQAKgDACAGQgDAGAAAGIABAQQAFAJAAAGQAAAAAAAAQABAAAAAAQABAAAAAAQABAAABAAIAEAAQACgUgHgFIAAgEQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAgBIACgBQAGgBACAFIABATQAEADgBAFIAFAAQABgKgEgNQAAgFAFgBQAGAAAAAFQgCAGABAGQABAHAEABIAAADQgBAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAQAFgHgHgQIADgGQADgBADACQABAAAAABQAAAAABAAQAAABAAABQAAAAABABQgCAGABAHQAAAIADAEIAEAAQACgTgDgFQABgGAFABQAFAAABAFQgCADAAAHIgBALQAIAFAEgCQABgIgCgNIgDgTIAEgCIACgBQAAAAAAAAQABABAAAAQABAAAAAAQAAABABAAQgDAIAEAaQAAgBABAAQABAAAAABQABAAAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQAAAAAAABQAAAAAAABIAAADQAEAEADgDQABgFgBgJIgBgOQAGgCADABIAAAKQgBAHABAFIACAEQAAAAABABQAAAAAAABQAAAAAAABQABABAAAAIACABQAAAAABAAQAAAAAAAAQABAAAAAAQAAgBABAAIAAgCIgBgCQACgEgCgGIgCgMQABgCAGgBQAEADgBALQAAAKAEADQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAIAEAAQgBgVgDgGIADgDQADgCADABQADACABAEQgDAFACAMQACABABAEQAAABABAAQAAABABAAQAAABABAAQAAAAABAAIgCgOQgBgJABgGQACgCAEAAQAEABABAEQgEAFABAJQABAJAEAEQADgCADACQACgGAAgLIgBgVIgFgGQABgDAFgBQAFgBACAEQgCAPAFAdQAMABgCgLQgEgOABgGQACABAGgDQAEADgBAJQgBALACAEIAEAEQACACADgBQACgEgCgOQgCgKAHgCQAEAAABAGQgCAGABAHQABAIADAEIAAgQQAAgKAFgDQAEAAACAEQgCAGAAAIQAAAIAEADIADAAIAAgOQABgJgEgFQACgDAGgBQAEADAAAIIgCAPIADABQABAAAAAAQABAAAAAAQAAAAAAABQABAAAAAAQAAABAAAAQAAAAAAAAQAAABgBAAQAAAAAAAAIAAACQAGABADgBQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIgBgBIADgFQgCgCAAgDQABgFgCgMIgCgQIADgCQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQACACACAEQgFARAJAXIgBAEQAEgBAIABQAAgEgBgEIgCgIQgGgCABgHQACgEAEAAQAEAAACADQAAAFAFAVIAHAAIACgIQgHgMAFgKQAIADAAABQgBAGACAIIADAMIAEAAQABgDgCgNQgBgJAFgEQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABAAIACAAIAAAQQgBALAGACIAEAAIABgaIAHgCQACACABAFQgGAGAEAPIAHAAIACgpIgCAAQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQABgCAGgDQADABABACIgCAXQgBAPACAJQAPACAggDIADACIACADIAKgBgAHMAXQADAAACgBQAZABANgCIAWgBQANAAAIgDIADABIAEABQADgDALgCIADACQACgCADgBQAAAAABgBQABAAAAAAQABAAAAgBQABAAAAAAIABgGIADAAQgCgFgDgCQgUgHgnABIgDgCIAAACQgcACgtgDQgCAFACAEIACAMQAAAAAAAAQABAAAAAAQAAABAAAAQAAABAAAAQgDAFAAACQAJACAEgCIAEACg");
	this.shape_44.setTransform(138.6,-13.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#A3B6B7").s().p("AgzARIgEgCQgEACgJgCQAAgCADgFQAAAAAAgBQAAAAAAgBQAAAAAAAAQgBAAAAAAIgCgKQgCgGACgFQAtADAagCIAAgCIADACQAngBAUAHQADACACAGIgDAAIgBAFQAAAAgBAAQAAABgBAAQAAAAgBAAQAAABgBAAQgDABgCACIgDgCQgLACgDADIgEgBIgDgBQgIADgNAAIgUABQgNACgZgBIgDABIgCAAg");
	this.shape_45.setTransform(189.9,-13);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AABIZQgjgGgOAFIgEgCQAAAAgBAAQAAAAgBAAQAAABAAAAQAAABAAAAIgGgDIgFgDQgHgKAHgKQAAgRAHgjQgCgQAEgaQAFgeAAgNQgBgBAAAAQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIACgjQABgTgDgOQADgOgFgVIgHggQgBgDgJgPQAAgHgGgLIgJgRIgjgYQgUgOgWgDQgBgCgFgCQgEgCgCgBQgHgCgXAAQgUgBgKgFQgRABgagIIgqgLIgKgEQgGgDgBgEQgMgDgOgMQgQgNgIgDQgEgFgBgEQgCABgEgDIgZgcQgOgRgMgHQAAgHgGgBQgGgPgKgcQABgLgEgWQgFgWABgMQgEgNgCgCQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAIABgEQgHgeAJg+QABgBgCgFQABgMAEgUIAHggQAGgJAAgHQADgCADgGQAEgQAQgZQAQgYAFgRQAHgHAEgIQAjgUAPgRQAKAAAHgFQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAgBAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAAAAAAAQAPgIAygJQAHgFABgDQAQADAZgCIAkgDQATgFA0gEQAvgEAWgIQAtADAwgKIBMgFQAvgDAcAAQAAAAABAAQAAAAAAAAQABgBAAAAQABAAAAAAIAEgCIAMACQAIAAAFABIAQgCQAJAAAGACQAEgBAGABQAKACAOAFQAPAGAIABQAAAAABAAQAAAAAAAAQABABAAAAQAAAAAAAAQAAABAAAAQABABAAAAQAAAAAAAAQAAABABAAQAKABALAIQANAJAHACIAYARQAOAKAIAIIARASIAJAVQAGAOAGAFQANAvAJAPQAEAPAEAcIAHAqIgCBBQgCAogJAaQgBAGACADQgFAKgJAgQgIAagIALQABADgBADIgBAHQgGABgFAKQgFAAgFADIgHAHIgGAAIgFAAQACADAFACQAHADACACQgBAEADAFQAKALAIASIAMAiQgCAKADALQADANgBAFIADAJQABAKgCAPIgDAXQAAAEADAKIACAPQAAAFgDALQgCAMAAAGIACARQgIAqgBAfIgDAyIgDAsQgCAYgKANQgIAAgKAHQgLAHgIABIgEAHQgEAAgEADIgGAEQgiAJgTANQgOADgbAHQgaAIgPACIgIAAIgIAAQgRAFgfACIgyADQgZgCgIAEQgzgHglAEgAB3IKQA9AAAmgLQAPABAUgFQAYgHAJgBQAWgHAqgRQAEgGAOgEIADgCIANgHQAIgDAFgEIAAgBQADgCAEgFQAHgBAKgGQgBgQAEgIIABgiQAAgJACgOIAEgZIAAgaQAAgGACgMIAEgSIACgjQAAgXACgNIgCgLQADgLAAgRQAAgUABgJQgEgHgBgRQgCgRgEgFQABgIgHgOQgIgOAAgFQgCgBgCgDQgDgDgCgBIgCgFIgCgFIgKgHQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQgBAAAAgBQgFgFgGgBQgIgCgEAFIgCgBIgUAHIgBgCQgEgBgEACIgHACQgegDgiANQgYAAgYAMQgpAKgZALQgiAGgUAAIhGAPQgoAJghABQgDACgFAEQgFAEgEABIgIgCQgFgBgCABIgBgCQgKAGgTAEIAAABQgTADgPAFIgJABQgEABgCADIA3AdIADADQAAABABAAQAAABAAAAQABABAAAAQAAABAAAAIAFABQARATAXAsIAIAkQAFAUAAATIABACQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAABIgBAeQACADAAAGIgBAKQgDAUgDApQgDAogDAPQAAAJgBASIgDAKQAAAEAEAEQADAFAAAEQAUADASAAIAAgBIASABIAAgBIBqADgAiWBYIgIAIQgQADgDAFQAaABAfgKIAzgOIABgCIAqgGIAAgDQAbAAAngJIBDgOQAkgBA7gVQA8gVAkgBQAUgHAYABIAAgCQAJACAMgFQAPgHAGAAIABgDIADABQATgMAHgBQgCgEAIgDQgCgEAFgGQAFgGAAgEQACAAACgDQACgEACgBQgBgDADgGQACgFgCgCQAMgSADgnQACgBACgGQACgWAFgPIAChCQgGgPACgNIgFgYQgDgPAAgMQgDgFgEgMQgEgNgEgFQgCgMgIgSIgMgfQgFgKgNgNQgRgRgEgGQgGgDgKgKIg1gaQgfgPgfACIABABIAAABIgXgCQgOgBgJgEIgBABQgbAAg2AGQg2AEgcAAQgLABggAFQgcAEgRgCIgaAFQgPACgKAEQgHAAgHABIAAgBQgFgCgIACIgNACIAAACQgWAAghAHIgJgBQgGAAgBACQA0ATAsAxQADAHAMAUQALAPADAMQACABAHALQAEAVAKAUQADAJACAWQADAXADAJIgBANQAJBLgDA3IgFAOQABAHgCAOQgHAWgRApIgUAYQgMAPgGAPQgUATgFAKIgDAAQgCAGgEAEgAmGljQgEAIABAJQgNASgKAfQgHATgJAnIgCAQQAAALgBAEIgFAKQABAMgEAEIAAAJQgBASAIAcQAIAfABAMIAHALQAAAHADAIQAEAIAAAFQAGAJAHASQAHARAFAIQAcAZA/ArQAEAAAEADIAHADQAYAEAagBIAtgDQAWgNAIgCIAOgRQAIgLAHgFQACgEAAgEQAGgFAKgPQALgNAFgGIATgpQAKgZAAgUQACgHACgRQABgQACgHQgCgEABgTIgEgKQAEgQgHglQgBAAAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAIABgDQgCgIgFgmQgDgcgIgOQgCgMgHgOQgIgRgCgJQgEgEgOgVQgLgPgKgGQgCgMgSgLQgXgNgEgFQgVgIgLgEQg/gMgfAWQgDAAgCABIgEABQAAABAAAAQgBAAAAAAQAAAAgBAAQAAAAAAgBIgEgBQgIAJgWAOQgVANgIAKIgDABIgDABQgRAcgEANQgIAHgIARIgNAaIgKAbQgFAQgBAOQgIAdABAZQgJAjAJAbIACATIAHA3QAFAfAJATQAdAcAIAPIAJAJQAGAGAFAAQgLgOgGgEIgHgRQgEgJgGgFQABgEgDgFIgEgHIAAgHIgDgGQgCgEACgDQgEgEgDgNQgCgMgFgFQAAgQgNgdQACgIgBgaQgBgWAGgKQgCgDABgGQABgGgCgDQADgCACgFQAOhMAWgkQABgLAJgRQAJgTACgIIAJgKQALgFADgFQAGgCALgFQAKgFAIAAQAEgFAJgEQALgEADgCQACABAEgBIAFgDQAIgCAIAAIARACIALgCQAUAFAYALIAqATQABAEAFADIAIAGQALARAMAJQAKAdAFARQAGAZACAbQgCATAGARQgFAbAFAMQgCAMgDAoQgDAegGASQABANgJAIIAAAHIgLAYQgHAPgJAEIgLATQgHAIgIAEIgDABIgEABQgFAIgKAGQgIADgRARQgOAOgOgDIgFADIgHACIglgKQgWgFgKgGQgEgNgMgHIgMgTQgIgKgGgHQgEgKgIgGQABgFgDgIQgCgGgEgFQAAgCgCgGIgEgIQgBgfgMgnQgBgOAEgYQAEgaAAgMQAHgGgEgHQACgBACgGIABgOQAAgGAEgDQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAAAAAgBIAIgWQAEgOAHgIQABgHAFgIIAHgOIASgOQALgJAGgHIAGAAQAIgKASgFIAggGIAIABQAGABABACQAHgDARADQABABAGABQAEACABADQAEgCAHAEQAGAIANARQAOAQAGAIQAGAYAFAMQACAMgCAZQgCAXACAJIgMA/QgIAngIAXQgFAGgEADIAAAFIgTAdQgMARgMAHQgKADgNAGIgWAMIgJAAQgBgDgHAAIgMgBQgHgFgKgMIgQgRQgMgkgCgKQgBAAgBAAQgBAAAAAAQAAAAgBgBQAAAAAAgBQgHhIAAghQAFgEgCgKIANgjQAIgUAKgMIABgJIAQgRQAJgLAIgEIAMgCQAHgBAEgCQAQABANANQASASADABQACAHAJAPQAHANABALQgBAeAAAzQgPApgZASQgKAGgQAAIgdgBQgRgOgJgEQgFgZABgfQABggAJgbIAEAAQABgIALgFIAQgHQARgBAIAKQAJAJAEATQAFASgBAQQgHATgKAKQgOAMgPgOQgDgDACgEIgCAAQgBABAAAAQAAAAAAAAQAAAAgBAAQAAgBAAAAQACgDgCgCIgCgGIACgDQAAgBAAAAQAAgBAAAAQABAAAAAAQABAAAAAAQgDgDAAgFQAAgGAEgBQAAgBAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAgBABgBQADACAFgHQAGgIAEgBQAFgBAHADQABgJgFgHQgFgHgIgDQgaAEgHAlQgFAdAHAhQAHAKAPAEQAMAFAPAAQAmgPALgwQgCgOAAgSIABghQgNgtghgTIgYAAQAAAAAAABQgBAAAAAAQAAAAAAABQAAAAAAABQgBABAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAQgDgCgDACIgGADIgVAhQgNAVgEATIgCAEQgCAEgBAAQgJAzALBDIADAEQAHAvAkAXQARAEASgJIAdgPQAFgEgBgGQAUgLAGgaQAKgIAIgWQgBgFACgFQACgFgCgEQADgDABgGQABgGgCgEQADgDACgJQACgIADgEIACgTQACgMgCgGQACgHABgNQAAgOACgHIgDgKQACgDgBgDQgBgRgJgSIgRgeIgRgOQgKgJgLgCIgagBQgNgBgIAEQgKgCgMAGQgPAJgGAAQgBAFgIADQgNAMgPAXQgJAOgEAHQgHAOACANQgHAMgEAZIgIApQABAKgCAYQAAAUAGAKIAAAIQADAUAKAlQAUArAnAoQAQAGAFAFQAkAIAZgHQAJgKATgPQAVgPAIgHIAHgDIAZgjQAOgVABgXQAFgCABgDQAQhGgHhHIABgDQAAAAABgBQAAAAAAAAQAAAAABgBQAAAAAAAAQgDgEAAgEIABgJQgGgoAAgNQgKgYgCgPQgFgDgGgLQgFgLgIgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBgBAAIgBgDQgHgCgHgFIgMgJIgggOQgSgIgQAAQgCgFgEABQgkgCgRAPQgIAAgLAFQgLAHgHAAQgFAEgFAMIgJAQIgOgEIgHAPgAlWBJQAHAEAEAAQgIgIgOgGQADAFAIAFgAkTi8QgFAFgBAIQABABAIAEIAGgLQgBgDABgCIACgGIgCAAQgFAAgEAEg");
	this.shape_46.setTransform(-6.5,-17.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#BCB8B5").s().p("AAcBMIgKgJQgIgPgbgeQgJgTgFgcIgHg3IAIgCQANAeABAQQAFAEACAMQACANAFAEQgDADACACIADAHIAAAGIACAHQADAFAAAEQAGAFAEALIAGASQAGADAMAPQgFAAgGgHg");
	this.shape_47.setTransform(-49.3,-22.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#BCB8B5").s().p("AgPEZIgHgEQgEgCgFAAQg/grgcgZQgEgIgIgTQgHgSgFgJQAAgFgEgJQgEgIAAgGIgHgMQAAgLgJgfQgIgcACgTIAAgIQADgFAAgLIAEgIQACgFAAgKIABgQQAKgnAGgTQALgfANgTQgBgIAEgJIAHgOIAOAEIAJgRQAFgLAFgEQAHgBALgGQAKgGAJAAQAQgPAjADQADgBACAEQAQABATAHIAgAPIALAJQAHAFAHACIACADQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAABQAHABAFALQAGALAFADQACAPALAYQgBANAHAnIgCAKQABAEACADQAAABAAAAQAAAAAAABQAAAAgBAAQAAAAAAABIgBADQAHBEgRBGQAAAEgFACQgBAXgOAVIgaAjIgGADQgJAJgUAPQgUAPgJAKQgYAHgigJQgFgEgQgHQgngpgVgrQgJgmgEgTIABgIQgHgKABgVQACgXgBgLIAIgmQAEgZAGgMQgBgNAHgOQAEgIAJgNQAOgXAOgNQAIgCABgFQAGgBAPgIQAMgGAKABQAIgDALABIAZABQAMACAKAIIAQAPIARAeQAJASACARQAAADgCADIAEAKQgCAGgBAOQAAAOgCAGQABAHgCAMIgCARQgDADgCAJQgCAJgCADQACAEgBAGQgBAGgDADQABAEgBAFQgCAFAAAEQgIAWgKAJQgGAagTALQAAAFgFAFIgdAPQgPAJgSgEQgjgXgIgwIgCgDQgLhEAIgwQACgBABgDIADgEQAEgTAMgVIAWghIAGgDQADgCACACQAAAAABAAQAAAAAAgBQABAAAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAQAAAAABAAIAWAAQAgATANAtIgBAhQAAAQACANQgKAxglAOQgOABgNgFQgPgEgHgKQgHghAGgbQAHglAZgEQAIADAFAHQAGAHgCAIQgHgCgFABQgEABgFAIQgGAHgDgCQAAABAAAAQAAABAAAAQAAABAAAAQAAAAABAAQAAAAAAgBQABAAAAABQAAAAAAAAQABAAAAAAQgEACAAADQAAAFADAEQgBAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAABIgBADIACAFQABADgBADQAAAAAAAAQAAAAAAABQAAAAABgBQAAAAAAAAIACAAQgCAEAEADQAPAOAMgMQAKgKAGgUQABgOgEgRQgFgTgIgJQgGgKgRABIgRAHQgKAEgBAJIgFAAQgIAagBAfQgCAfAGAZQAJADAQAPIAeABQANgBALgGQAZgRAPgqQgBgwACgeQgCgLgHgNQgIgPgCgHQgDgBgTgSQgMgNgPgBQgEACgHABIgMABQgIAFgJALIgPARIgCAJQgJAMgIATIgNAkQACAJgFAFQAAAfAHBIQAAABAAAAQAAAAAAABQABAAABAAQAAAAABAAQACAKAMAkIARARQAKAMAHAFIAMABQAGAAACADIAJgBIATgLQAOgHAJgCQAMgHAMgRIAUgdIAAgGQADgCAFgHQAIgWAIgnIANg9QgDgKACgWQACgZgBgMQgFgMgHgYQgFgJgOgQQgOgQgGgJQgGgDgEACQgBgDgFgCQgFgBgBgCQgRgDgIADQgBgCgFAAIgHgBIggAGQgRAFgJAJIgGABQgGAHgKAJIgTAOIgHAOQgEAIgBAHQgHAIgFANIgHAXQAAAAAAABQAAAAAAAAQABAAAAABQAAAAABAAQgDADgBAGIAAANQgDAHgCABQAEAGgGAHQgBALgEAZQgDAYAAAOQAMAnACAfIAEAIQACAFgBADQAEAEADAHQACAIAAAFQAHAFAEALQAHAHAHALIANAUQAMAHADANQALAFAVAGIAkAKIAGgCIAGgDQANADAOgPQARgRAJgCQAKgGAEgJIAEgBIAEAAQAIgFAHgKIALgSQAJgEAGgPIAMgYIgBgHQAJgIgBgOQAHgRACgfQAEgoACgJQgFgMAFgcQgHgQADgTQgDgbgGgZQgEgRgLgeQgMgIgLgSIgIgFQgFgDgBgEIgpgTQgZgLgUgFIgKACIgPgCQgIgBgIACIgGADQgDACgDgCQgDADgKAEQgKAEgDAEQgIABgKAFQgMAFgFABQgEAGgKAFIgKAKQgBAIgKATQgIARgBALQgXAkgOBMQgBAFgDACQACACgBAHQgBAGACACQgHAJABAWQACAagDAIIgIABIgCgUQgIgaAJghQgCgaAIgcQACgPAFgQIAJgaIAOgbQAIgRAIgGQAEgNAQgdIADAAIADgBQAJgKAUgOQAWgNAIgJIAEABQAAAAABABQAAAAAAAAQABAAAAAAQAAgBABAAIADgBQACgCADABQAggWA8AMQAMADAUAJQAEAEAYAOQARALADALQAKAHALAPQAOAVADAEQACAJAIAQQAIAPABALQAIAPAEAcQAFAmACAIIgBADQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAHAigEARIAEAKQgBATACAEQgCAGgBARQgBAQgDAIQABAUgKAZIgTApQgGAFgKAQQgKAOgHAGQABAEgCAEQgHAFgJAKIgOASQgIACgVANIgtACIgPABQgSAAgPgDgAh8C9IADABQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAAAAAg");
	this.shape_48.setTransform(-33.2,-36.7);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AAAAAIAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAABIgBgBg");
	this.shape_49.setTransform(-45.6,-17.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AAAACQgGgDgDgFQALAGAIAGIAAABQgFAAgFgFg");
	this.shape_50.setTransform(-40.9,-10.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#BCB8B5").s().p("AgHAGQABgGAFgFQADgGAGACIgCAFQgBADABABIgGALQgGgEgBgBg");
	this.shape_51.setTransform(-33.9,-35.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#E2DDD7").s().p("AhMErQADgFAQgDIAIgIQAEgFACgFIADAAQAFgKAUgUQAGgOAKgPIAUgbQARgoAHgXQACgNgBgHIAFgPQADg3gJhIIABgOQgDgJgDgWQgCgWgDgKQgKgUgEgUQgHgLgCgCQgDgMgJgPQgMgTgDgHQgsgyg0gSQABgDAGABIAJABQAhgIAWABIACADIAEAFQAKgBAIAGQAGAEABAIQAIgDACANQAAAAABAAQAAAAAAAAQAAgBABAAQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAAAAAQABABAAAAIAMAQQAHALAFAEQADANAKAHIAEAKIAEALQAAAAAAAAQABAAAAABQAAAAABAAQAAAAAAAAIADABQANAcACAMQABADAFADQAEATALAgQALAgAFASIgCASQADAFAAALIgBAQQAAAIAEAPQAAALgCAUQADAVgBAJIgCAIQACARgFAYIgHAoQABABgBAAQAAABAAAAQAAAAgBAAQgBABgBAAQACAGgFAKQgFAJAAAFQgEAIgLAOQgMAPgEAIIgEAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAABgBAAIgBAEIgFgBQAAAEgCABIgGABQgDABgBADIgBACIgxAOQgdAJgZAAIgDAAg");
	this.shape_52.setTransform(-16.6,-37);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FF0000").s().p("AgGEdIAGgBQAAgCAAgDIAEAAIACgDQAAAAABgBQAAAAAAAAQABAAABAAQAAgBABAAIADgBQAFgIALgOQALgOAFgJQgBgEAFgKQAFgJgBgHQABAAAAAAQABAAAAAAQABAAAAgBQAAAAAAgBIAHgoQAFgZgDgQIADgIQABgJgDgVQACgVgBgKQgEgPAAgIIABgSQAAgJgCgFIABgSQgEgTgLggQgLgggFgSQgFgEgBgDQgBgLgNgdIgDgBQgBABAAAAQAAAAgBgBQAAAAAAAAQAAAAgBgBIgEgKIgCgKQgKgHgDgNQgEgFgIgLIgMgPQAAAAAAgBQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAABAAAAQAAAAAAAAQgBABAAAAQAAAAgBgBQgDgMgIACQgBgHgHgFQgHgFgLAAIgDgEIgDgEIAAgCIAOgCQAHgCAGADIAAAAIgDABQAWAIARAYIAbApQAHAPAQAbQABAHAEAIIAIANQAEAeAOAVQABAJAKAfQAHAYAAAUQgBAHADAUQADASgEAMQADACgCAPQADAFACAFIgDAIQACACgBAFIgCAGQgBAFACAKQABAQgEAXQgFAaAAAKIgCAJQgCAEABAEQgEAGgHAUQgGATgHAGQAAAEgCAEIgCAGQgLAGgEAEIABAAIAAACIgoAGQABgCAEgBg");
	this.shape_53.setTransform(-12.3,-38.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FF0000").s().p("AAgDUQgCgEAAgFIACgBQABAAAAgBQABAAAAAAQAAAAAAgBQAAAAAAAAQAFgagDgQQAFgGABgRQAAgRADgGQgBgUADgaIAFgyIgDgJQABgJgCgTQgDgVABgIQgFgHADgGQgGgHgFgWQgGgVgFgGQAAgBABAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIgBgFQgPgRgHgNIgEAAQgPgXgjgKQgFgJgFgBIgBAAIAAgBQATgFAKgFIABACQgDABAAADQABADAFADIAGAFIAKADQAYAXANASQATAZAFAdIACACQABABAAAAQAAAAAAABQABAAAAAAQAAABgBAAQADAWAJASIACAcQABASACAHQABAOgDAWQgEAZAAAKIABANQABAIAAAFIgDAdIgEAeIADAMQgHAHADAQQACARgCADIgBABg");
	this.shape_54.setTransform(-10.5,13.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#E2DDD7").s().p("AAaDMQAAgDgEgFQgDgEAAgEIACgLQACgRgBgJQADgQADgoQADgpAEgTIAAgLQAAgGgBgDIABgcQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBgBAAIgBgDQAAgSgEgVIgJgkQgUgrgSgUIgEAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBgBAAIgDgEIg2gdQABgCAFgBIAIgCQAQgFASgCIABAAQAFABAFAJQAhAJAPAYIAGAAQAHANAPARIABAEQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAABQAFAGAGAVQAFAVAGAIQgDAGAFAGQgBAJADAVQACATgBAJIADAJIgFAxQgDAbABAUQgDAFAAASQgBARgFAGQADAQgFAZQAAABAAAAQAAAAAAABQAAAAgBAAQAAAAgBABIgCABQAAAFACAEIABABQgTgBgTgDg");
	this.shape_55.setTransform(-13.6,13.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#E2DDD7").s().p("AiOD+QADgEgDgRQgDgQAHgGIgDgNIAEgeIADgdQAAgFgBgIIgBgNQAAgJAEgaQAEgWgCgNQgCgJgBgSIgCgbQgIgSgDgVQAAgBAAAAQAAAAAAgBQgBAAAAgBQAAAAgBAAIgCgCQgFgdgSgZQgNgSgbgXIgKgDIgGgGQgEgDgCgCQAAgEADgBQADgBAFABIAIACQAEgBAFgEQAEgEAEgBQAhgCApgJIBHgPQAUAAAigGQAXgLApgJQAYgNAXAAQAjgNAeADIAGgCQAEgCAFABIAAACQAHANALAKIgCAMIAFAEQABADADABIAPA6IgBAMQAEAFACAIIgFBtQgDA/gEAkIABAFIACAGQgDANgDAlQgEAfgFANIACAFQABACgBAEIAAAAIgDACQgOAFgFAFQgpARgWAHQgJABgYAHQgUAFgPAAQgnAKg6AAIhqgCg");
	this.shape_56.setTransform(9.1,9);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FF0000").s().p("AAgEEQAAgDAHgEQADgEgBgFQAEAAAEgDQAEgEADAAQABgGAHgOQgBgIAEgKIAHgPQACgMgBgEIAHgQQAGgbADgmIAEg+QgCgIAAgLIAAgTIgHgZQgFgQAAgKQgGgGABgIIgRgeQgKgSgKgKQgDgNgLgMIgTgUIgCgFIgDgFQgEgDgOgMQgLgLgKgDQgHgKgOgHIgbgJQgDADgLgCQgDgKgEgDIABgCQAJAFAOABIAXABIAAAAQAYANAoAgQAFAIATAVQAPARAFAOQAGAFADAEQABAEAGAIQAEAIABAFQARAVAJAkQAGAVAHAtQgCA1gCAZQgDAsgHAfQABAEgCAIQgJAJgBAXIgHARQgFALgCAJIAHAEIgCACQgGABgPAHQgJAEgHAAIgFgBg");
	this.shape_57.setTransform(24.4,-44.2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#E2DDD7").s().p("AiqEqQAEgEALgGIACgGQACgEgBgEQAHgFAGgTQAHgVAFgFQgBgEABgFIADgIQAAgLAEgZQAEgXAAgQQgDgLABgEIACgHQABgEgCgDIADgHQgBgGgEgFQACgOgCgDQADgMgCgRQgEgVABgJQABgRgIgYQgJgfgCgJQgNgWgFgeIgHgNQgEgHgBgHQgRgcgHgPIgdgoQgRgYgVgIIACgBQAHgCAHABQAKgEAPgCIAagFQARACAcgEQAigGALAAQAcAAA2gFQA0gFAbAAQAEADADAKQALACADgDIAaAJQAOAHAIAKQAKADALALQANAMAHADIADAFIACAFIATAUQAKAMAEANQAJAKALASIAQAeQAAAIAGAGQAAAKAEAQIAIAZIgBAVQAAALACAIIgEA8QgDAmgFAbIgIAQQACAEgCAMIgHAPQgEAKABAIQgHAOgBAGQgDAAgEAEQgEADgEAAQABAFgEAEQgGAEAAADIAAABQgYAAgUAIQgkACg8AVQg7AVgiABIhDAOQgnAIgdABg");
	this.shape_58.setTransform(7.7,-40.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FF0000").s().p("AAAgDQgCgBgCgCIgFgFIACgLQgLgLgGgNIAUgGIACABIgBACIADAKQAAAIAAADQAGAHAEAMIAEAVIAIAQQgBAJAEAMIgBABIgCAAIAAABIgJACIgNg4g");
	this.shape_59.setTransform(30.9,-11.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#E2DDD7").s().p("AgODfIgBgKIAAgMQADgHABgbQAAgbAFgLQgEgQAEglQADgmgDgPQgBgMAEgRIADgdIAAgSQgBgNAAgHQABgXAAgGIgFgOQgEgNABgIIgIgQIgEgXQgEgMgGgHQAAgEgCgHIgDgLIABgBQAEgGAIACQAGACAFAFQABAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQAAAAAAABQAAAAABAAIAKAHIAAAFIACAGQACAAADADQACADACABQAAAFAIAPQAHANgBAIQAEAGACARQABAQAEAHQgBAJAAAUQAAARgDALIACAMQgCANAAAUIgCAjIgEATQgCALAAAHIAAAaIgEAYQgCAPAAAIIgBAiQgEAIABAQQgKAGgFABQgEAGgDABIgDABIgDAAg");
	this.shape_60.setTransform(34.1,5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIAAAAg");
	this.shape_61.setTransform(33.2,-6.6);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FF0000").s().p("AgPCxQABgEgBgCIgCgFQAFgNADgfQAEglADgNIgCgGIgBgFQAEgkABg/IAFhtQgCgIgDgFIAAgMIAIgCIACAAIAAgBIACgBIAFAOQABAGgCAXQgBAHACANIABASIgFAdQgEATABAMQADAPgDAkQgDAlADAQQgEALgBAbQgBAbgDAHIABAMIABAKQADABACgCIABABQgFAEgGAEIgOAGg");
	this.shape_62.setTransform(32.2,11);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#E2DDD7").s().p("AAcD7IgGgFQACgIAEgLIAIgRQABgXAJgJQACgJgCgDQAIgfADgsQACgaACg1QgHgtgGgVQgJgkgRgUQgBgGgFgHQgFgIgBgFQgDgDgHgFQgCgPgQgRQgTgUgEgIQgqgggYgOIgBAAQAfgCAfAOIAzAaQAKAKAGADQAEAHARAQQANANAFALIAMAeQAIASACANQAEAFAEAMQAEANADAFQAAALADAPIAFAYQgCALAGAPIgCBCQgFAPgCAWQgCAHgCAAQgDAogMARQACACgCAFQgDAGABAEQgCAAgCAEQgCADgCAAQAAAEgFAHQgFAGACADQgIADACAEQgHABgTANg");
	this.shape_63.setTransform(29.1,-44.5);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#DD781D").s().p("AAwEMIgEgEQgIgCgIgKQgIgNgFgDQAAgCgEgEQgDgDAAgDQgEgCgEgJQgGgIgDgDQgCgHgGgDQgCgFgFgJQgGgJgBgGQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAgBgBgBQAAAAAAgBQAAAAgBgBQAAAAgBAAQAAgBAAAAQgCgJgIgRIgEgLQgCgGAAgFQgBgBgBAAQAAAAAAgBQAAAAAAgBQAAAAABgBIgDgDIgGgRQAAgUACgJIgIgOQAGgqAAgYIgBgDQABgVgHgcQgDgTgKgaIgSgqQgEgDABgEQgGgKgBgHQgGgEgBgGQgGgFgGgNQgGgGgHgJIgMgQIASgHQALgDAIAAQAFgFAPgBQAQgCAFgDQAGABADgDQAAABAAAAQAAAAABABQAAAAAAAAQAAAAABAAQAGAAAIAGIAMAKIACADQAbAaAZAvIAOAgQAIATACASQAFARgBASQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAgBABIAAADIADAHQAAAFABAGQgBAFABALIACASIgCAPQgBALABAHQgBAPAEAVIAJAiIAEAKQADAGACACQAHATAPAXIAbAlQAHAEAIALQAJALAFAEIAFAFQADADAAADQgFgCgDAGIABAGQgDACgLgCIgCACIgDADQgBADAEAGIgNgBQgHgBgBAHQgHABgEgDQgIAEgBAFQgLgDgGAEIABAGQgGgCgCABQgCgDgEAAQgFAAgCACQgBABAAAAQAAAAAAABQAAAAABAAQAAAAAAABQgDAAgDgCg");
	this.shape_64.setTransform(43.3,123.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("ACsFEIAAgDQgHgEgCAAQgJgGgMgPQgNgRgGgFIgVgeQgNgRgGgOQAAgBAAAAQgBgBAAAAQgBgBAAAAQgBAAAAAAQgBgFgFgHQgTgzgIgbIAAgJQABgGgCgCIgJAUQgEADgDAJIgGAMQgEACgEAGQgFAGgDACQgEgBgEAIQgCABgGAFQgFAFgFAAQgGAGgWAKIgBACIAAADQgMAAgGAEQgEgBgGABIgKABQg2gEgegBQgEgEgHgCIgIgBIgIgFIgJgFIgVgZQgDgJgFgBQABgDgDgDQgDgEAAgDQgEgEgFgNQgGgMgFgEQgDgOgIgPQAAgHgFgLIgHgSQgOg0AEg4QgCgGAAgQQABgRgCgFQABAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAgBQgBgJACgNIAEgUQATgiAMgTQAGgDAOgSIARgKQAKgHAJgCQAGgDADgCIAfgIQASgEANAAIAGACIACgBIADABIASAGQAMADAEAFIAFABIADADQAIADAIAIIANAPQADABAGAFQABgCAFgBQAGgBABgBIgCgEIAFgDQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBIACgBQAAgIAFgKQAFgKAAgGQADgDAAgEIAEgDQADgCgBgEIAFgHQAFgEABgEIADgBQAFgHALgGIASgKQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABAAQACgBAFgBIAHgCQAAABAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABABQATgDAWAGIAmAKIAPAHQAGALALACQAHAMAFAFQACAAADADQgBAEAFAEIgBACQABADAHAEQADAMAGAGQABAEAFAJQAEAJABAGIADAGQABAAAAAAQAAABAAAAQAAABAAABQAAAAgBABQAGAOAFAVIAJAmIAAAFQAFAOAAARQADARABAZIABAoIAAAGQgBADAAARQAAAOgEAJQAAAKgIAMQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAgBABQAAAAAAABQAAAAgBAAQAAABAAAAQABABAAAAQgIAHgBAFQgDABgGAIQgFAGgFABIgBACQAAAAgBAAQAAAAAAABQAAAAAAAAQAAAAAAAAIgDABQAAAAgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBAAgBAAQgFAIgPgEQgBACACADIABAHIAEAEQACAMAIAPQAKARADAIIALAPQAHAKAGAEQABAEAEAEQAEAEABADIACAAQAHAMAPAMQAJANAJAFQABAGAEABQACAIgJADIgEgBQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBABAAAAQAEAGgHAGQgEAAgJgDQACACgBAEQAAAEgCACQgFABgFgBIgJgCQgBAHgGAAQgCABgJgDQAAABAAAAQAAAAAAABQAAAAgBAAQAAAAgBAAIgBAGQgDACgFAAQgFAAgDgCQgCALgHgBQgBgBgFgBQgBAAAAABQgBAAAAABQgBAAAAAAQgBAAAAAAIAAACIgIADIgDABQgDAAgDgDgAAXjfQgPABgFAFQgGAAgLADIgTAHIANAQQAHAJAGAGQAGANAEAFQABAGAFAEQACAHAGAKQgCAEAFADIARAqQALAaADATQAGAcAAATIABADQgBAYgFAsIAIAOQgCAJAAAUIAFARIAEADQgBABAAABQgBAAABAAQAAABAAAAQABABABAAQAAAFACAGIADALQAJARABAJQABAAAAABQABAAAAAAQAAABABAAQAAABAAAAQABABAAABQAAAAAAABQABAAAAAAQAAAAABAAQABAGAGAJQAFAJACAFQAGADABAHQAEADAGAIQAFAJAFACQAAADADADQADAEABACQAFADAIANQAIAKAIACIAEAEQACACAEAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQADgCAFAAQAEAAACADQACgBAGACIgBgGQAGgEALADQABgFAIgEQAEADAHgBQABgHAHABIAMABQgDgGABgDIACgDIADgCQAKACAEgCIgBgGQADgGAFACQAAgDgDgDIgFgFQgFgEgJgLQgJgLgGgEIgbglQgQgXgGgTQgDgCgCgGIgFgKIgIgiQgEgVABgPQgCgHACgLIACgRIgCgSQgBgJABgFQgCgGABgFIgDgHIAAgDQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBAAAAAAQABgSgFgRQgCgSgIgTIgPggQgagvgcgaIgBgDIgMgKQgIgGgGAAQgBAAAAAAQAAAAgBAAQAAgBAAAAQAAAAAAgBQgEADgFgBQgFADgQACgAjHjxIgRAIQgEAFgNAIQgCAEgHAGQgGAFgCAFQgIAGgHAOIgMAWQAAADgEAMIAAAFQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQgGAHAEAWQgCADAAAGQgBAGACADQgBAJACATQABAQgCAKQADAKgCAJIACAMQgBAKAGAMQgBAGAEALQAFALAAAGQACACACAFQABAFACACQAEAQAKATIAQAgIAIAOQAFAIAFADIANAQQAHAFAMAFIAUAHIAjACIAiACIAVgCQALgDAGgFQAIABAKgLQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABIABgEQAEAAADgEIAHgFQAAgEAHgHQAEgNAFgJQABgGABgJQADgKAAgGQACgCAAgFIACgGQAAgSACgMIgCgLQgBgIACgEIgCglIgDgFQACgHgCgMQgCgOAAgFQgBgEgCgFQABgHgEgKQgEgMgBgGIgEgHQgDgFAAgFQgEgEgGgNQgGgNgEgEQgOgggngqQgIgFgEgHIgEgBQgBAAAAgBQgBAAgBAAQAAAAgBAAQAAABgBAAIgEgGQgGgBgLgHQgJgGgIABQgFgDgJAAQgHAAgHADIgFgDQgHACgLAGgAANgeQAAABAAAAQABABAAAAQAAAAAAABQAAAAABAAQgDADABAEIACAHIAAAJQAAADACADIABAPQAAAKACAGQAAAAAAABQAAAAgBABQAAABAAAAQgBABAAAAIgBARQAAAKADAFQgDAHgCAcIgEADQgDATgDAGQABAHgEAHIgDANQAAAAABAAQAAAAAAAAQAAgBAAAAQAAgBABAAIACgEQAFgCAFgGQAGgHACgBIANgdQAIgRABgPIADgIIACghQABgWgBgLIgCgEIAAgOQAAgHgDgEQABgQgFgHQgDgNgHgQIgNgaQgCgHgEgKIgHgRIgDgHQgFgLgPgRQgPgSgGgLQgCAAgDgEQgCgDgDgBQgIgPgQgIQgKgKgOgEQgUgKgQABIANAHQAIAEAEAEIADgBQAKAGAKAKIARAUIAEABQAJAMAEAEQACAFAHAKQAIALACAGIAEAGQACAEADAAQABAGAFAKQAGAMACAFQACACADAGQACAGACACIgBADQADAGADAPIAHAVQgBAEABAFIACAJIABACQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQgBABAAAAQAAABAAAAQAAABAAAAgABPjgQALAKAFAGQAMAKAMATIAWAhQADALAFAEQAAAEAFAJIAFALQADAIABAHIAFAQIAEAPIACAQQACAIgBAFIADAPQAAAKACAFQgCAIABATQABAUgCAKQAAADACACQAAAAAAAAQAAABgBAAQAAAAAAAAQAAAAgBAAIAEAiQAFABAFgBIAJgDQABAAAAgBQAAAAAAAAQAAAAAAgBQAAAAgBAAIgBgCQAEgHAEAAQAOgRgCgeQAEgJAAgPIgBgYQAAgOgCgXIgEgkIgBgEIAAgIIgDgPQAAgSgHgWIgLgmIgDgCQgBgDAAgDQgBgFgCAAQgEgPgKgPIgRgaIgFgEIgEgFQgDgDgDAAQgBgEgFgDIgIgGIgRgJQgKgFgJgBIgLgEQgGgCgDgDQgEAAgFgBIgJgBIgUAJQgKAFgEAJIgEACQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAIgIANQgEAIgBAHIgEAJIAAADIgEAIQgCAFAAAFQALgDACgCQAIACAMgDQAOgFAFAAIAIgFIAGADIABgBQAAAAAAgBQABAAAAAAQAAAAAAAAQAAAAABAAIACAAQABABAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQAFAGALALgABgk5QABACADABIAHAAQAKAHAWALQADAGAHAEQAhApAJAOQABAJAHAPQAGAOACAJIACADIABACQABAHAIAVQAAAGADAQQACAOgBAHQAEAPgBAIIADAPQABAKABADQgBAGACAEQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAgBAAIAAACQAHAtgKA0IABAEIgDAFIAAAGQADgCADgGIAGgJIABgDIABgEQAHgKABgkIgBgDIABgGIABgGQgCgHAAgXQAAgVgHg5QgCgGgKgsQgHgfgLgQIgBgFIgHgNQgEgJgDgDIgCgGIgEgGIgKgMQgFgIgGgDQAAAAAAgBQAAAAAAgBQgBAAAAAAQAAAAAAgBIgWgNQgNgHgOgBIgKgEQgGgCgEAAIgCAAg");
	this.shape_65.setTransform(31.1,119.2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#00A0C6").s().p("AA1C7IADgFIgBgDQAKg0gHgwIAAgBQAAgBABAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQgCgDABgGQgBgEgBgKIgDgPQABgIgEgPQABgHgCgMQgDgQAAgFQgIgVgBgHIgBgDIgCgDQgCgIgGgPQgHgOgBgJQgJgPgfgpQgHgDgDgHQgWgKgKgHIgHgBQgDAAgBgDQAFAAAHADIAKAEQAOAAANAIIAWANQAAAAAAAAQAAAAABABQAAAAAAAAQAAABAAABQAEADAFAIIAKAMIAEAFIACAGQADAEAEAIIAHANIABAGQALAQAHAeQAKAsACAGQAHA4AAAVQAAAWACAHIgBAGIgBAHIABAEQgBAkgHALIgBADIgBADIgGAJQgDAGgDACIAAgGg");
	this.shape_66.setTransform(48.4,107.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#047391").s().p("ABMDMIgEgiQABAAAAAAQAAAAAAgBQABAAAAAAQAAAAAAAAQgCgCAAgDQACgKgBgUQgBgTACgKQgCgFAAgKIgDgPQABgFgCgIIgCgQIgEgPIgFgQQgBgHgDgIIgFgJQgFgJAAgEQgFgEgDgLIgWghQgMgTgKgKQgFgGgLgKQgLgLgFgGQAAAAAAAAQgBAAAAAAQgBAAAAAAQAAgBgBAAIgCAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAABIgBABIgGgDIgIAFQgFAAgOAFQgMADgIgCQgCACgNADQAAgFACgFIAEgIIAAgDIAEgJQACgHAFgIIAIgNQABAAAAgBQABAAAAAAQABAAAAAAQABgBAAAAIAEgCQAEgJAKgFIAUgJIAJABQAFABAEAAQADADAGACIALAEQAJABAIAFIARAJIAIAGQAFADABAEQADAAADADIAEAFIAFAEIARAaQAKAPAEAPQACAAABAFQAAADABADIADACIALAmQAHAWAAASIADANIAAAIIABAEIAEAkQACAXAAAOIABAaQAAAPgEAJQACAegOARQgEAAgEAHIABACQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAgBABIgJADIgFAAIgFAAg");
	this.shape_67.setTransform(41.7,108.3);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#00A0C6").s().p("AAuDEQADgHgBgHQAEgGADgTIADgDQADgdACgGQgCgGAAgKIAAgQQABgBAAgBQABAAAAgBQAAAAAAgBQAAAAAAgBQgCgGAAgJIAAgPQgDgFAAgDIABgKIgCgHQgBgEACgDQAAAAAAAAQgBAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAgBAAAAIgBgCIgBgJQgBgDABgDIgHgVQgEgPgEgHIABgDQgCgCgDgGQgCgFgDgCQgBgGgGgLQgGgLAAgFQgDgBgDgDIgEgGQgCgHgFgKQgHgKgCgGQgFgDgJgMIgEgCIgRgTQgKgLgKgFIgDAAQgDgDgJgEIgMgHQAQgCATALQAOAEALAKQAQAHAIAQQACABADADQACADAAABQAGAKAQASQAPASAGAKIADAHIAHARQAFALABAHIANAaQAIAPACAOQAFAFgBAPQADAFAAAHIABANIACAHQABALgCAWIgCAhIgDAIQgBAPgHARIgNAcQgDACgFAHQgFAFgFACIgDAEQAAABgBAAQAAAAAAABQgBAAgBAAQAAAAgBABIAGgNg");
	this.shape_68.setTransform(26.8,114.3);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#047391").s().p("AAKDdIghgCIgUgHQgMgFgHgFIgNgQQgFgDgFgIIgIgOIgQggQgKgTgEgQQgCgCgBgFQgCgFgCgCQAAgGgFgLQgEgLABgGQgGgMABgMIgCgMQACgJgDgIQACgKgBgQQgCgTABgJQgCgDABgGQAAgGACgDQgEgWAGgHQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAIAAgFQAEgMAAgDIAMgWQAHgOAIgGQACgFAGgFQAHgGACgEQANgIAEgFIARgIQALgGAHgCIAFADQAHgDAHAAQAJAAAFADQAIgBAHAGQALAHAGABIAEAGQABgBAAAAQABAAAAAAQABAAABAAQAAAAABABIAEABQAEAHAIAFQAnAqAOAgQAEAEAGANQAGANAEAEQAAAFADAFIAEAHQABAGAEAMQAEAKgBAHQAEAFABAEQAAAFACANQACALgCAHIADAFIACAnQgCAEABAIIACALQgCAMAAASIgCAGQAAAFgCACQAAAGgDAKQgDAJgBAGQgFAJgEANQgHAHAAAEIgHAFQgDAEgEAAIgBAEQAAgBgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQgKALgIgBQgGAFgLADIgVACIgigCgAApCQIAOgEQABgBAAAAQABAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAIAEgEQADgGAIgGIAIgQQAEgLABgJIACgEQgBgJADgEQgCgEABgIIABgNIgEgkQgCgCgBgFIgEgJQAAgKgHgQIgKgaQgFgFgGgQQgGgEgKgMQgJgMgHgEQgFgIgLgFQgFgCgNgEIgFABIgBgBIgBgBQgGAAgHAEIgMAGIgYAUIgOAZQgBAKgEASIACADQgBAGABAJIABARIAZBLQAGAGAHAPQAHAQAFAFIABAEIAQATIAEACQADAGAKAEIAOAIIAEAAIABABQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAIAIgBQAFADAIgCg");
	this.shape_69.setTransform(17.3,116.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AAZCLIgIABQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAgBIAAgBIgFAAIgNgIQgKgEgEgGIgDgCIgQgTIgBgEQgFgFgIgQQgHgPgFgGIgZhLIgCgRQgBgJACgGIgCgDQAEgSABgKIANgZIAYgUIAMgGQAIgEAGAAIAAABIACABIAEgBQAPAEAEACQAKAFAFAIQAHAEAKAMQAKAMAFAEQAHAQAEAFIAKAaQAHAQABAKIADAJQACAGACABIADAkIgBANQgBAIACAEQgDAEACAJIgCAEQgCAJgEALIgHAQQgJAGgCAGIgEAEQgBAAAAABQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAABAAABQAAAAAAAAQgBABAAAAQgBABAAAAIgPAEIgFABQgEAAgEgCgAgxhzQgGAHgHAFIgIALQgBAEgEAJQgDAIAAAGQAAABAAAAQAAABAAAAQgBABAAABQAAAAgBABQAAAgAMAnQAGAFACANIAEAMIAEAEIAEAJQADAGABAEQAHAKAMAUQALARAMAHIAMAHQAKAAAKAEIAGgDQAEgBADABIANgGIAKgMQAHgHACgGIAHglQgBg8gNgWQAAgIgEgJQgGgMgBgEIgGgGQgBgIgHgJIgKgPIgLgLQgHgEgEgFIgXgLIgGgBIgGgBQAAAAgBAAQAAAAAAAAQgBABAAAAQgBAAAAABQgDACgCgBQgFAEgMAGg");
	this.shape_70.setTransform(17.6,116.9);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#332922").s().p("AAKB9IgNgHQgLgHgMgRQgMgUgHgKQAAgEgEgGIgDgJIgFgEIgEgMQgBgNgGgFQgNgnABggQAAgBABAAQAAgBAAgBQABAAAAgBQAAAAAAgBQgBgGAEgIQAEgJAAgEIAIgLQAIgFAFgHQANgGAEgEQADABACgCQABgBAAAAQABAAAAgBQABAAAAAAQAAAAABAAIAGABIAGABIAWALQAEAFAIAEIALALIAJAPQAHAJABAIIAHAGQABAEAFAMQAEAJABAIQAMAWABA8IgGAlQgDAGgGAHIgKAMIgNAGQgEgBgDABIgHADQgKgEgJAAg");
	this.shape_71.setTransform(17.6,116.9);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AhuBLIgsgDQgVABgIgBQgHABgJgCQgJgCgFgEQgDABgEgDQgEgDgCAAQAAAAAAgBQAAAAgBAAQAAgBAAAAQgBgBAAAAQgBAAAAAAQAAgBgBAAQAAAAAAgBQAAAAABAAQgKgBADgHQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAAAAAABIACgDIgFgFQAAgKgDgDIgDgSIABgBQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIgCgEQAAgDADgCQABgGADgGIAFgLQAFgEAHgJIANgHIADAAIALgFIAQgDIAEgBIACAAIAIgCIADABIAFgCIAFAAIASgCIAUgDIAYgBQAPgCAKABQATgCAsAAIAEgCQAIABAsgEQANACAPgDQAMABATAAIAfABQAAgBABAAQAAAAAAABQABAAAAAAQAAAAABABIAWAAIAVACIANADQADgBAEACQAFADACAAQADADADgBIAEAFQACADADAAQAAADAFAEIAEAIIACAIQADADACAJIAEANIAAAEIgBAJIACAEIgBALIgCALQgCADgGAFIgHAJQgIABgFAEQgMABgQAGQgFgBgLACQgLABgGgBIgGABQgBAAAAAAQgBAAgBAAQAAAAgBABQAAAAAAAAQgOAAgWABQgXACgNgBIgEABIhIABQgBACgGAAIgOABQgJAAgEgBIgCABIgeAAQgKABgMAAIgWAAgAhag7IgCAHQACAHAAANIABATIAEAQIABAPQACARAAALQADAHACANIgBACQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAQAOAAAMgDQAqACAXgEQAyABAogDIAAgEIgBgDQACgKgBgQIAAgbQgCgCAAgGIgBgVIgBgYIgBgIQgBgGgBgDIgSABIgGgBIgRABIgkACIgQABQgIACgOAAIgZgBIgXADIgKAAIgNABgAh4BCQAGACALABIARAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgCgDIABgFIgBgTQgIgygCgoQgCgGABgCQgRAAgZAEIgpAFQgGACgKABQgOAHgJAFQgBADgHAHIgLAYIABAKQABAGgBADQACACACAIQABAGADACQAAAAAAAAQAAAAAAAAQgBABAAAAQAAABAAABQAEACAAADQACAAADAFIACABIACAAIADADIAFADIAFADIALAEIAIAAIAHABIALAAIAyABgABphDIADBCQACADAAAMQAAAOACAFIgBAJIABAKQABAGgCAEIA6gDQAjgDATgJIACgCQAAgBAAAAQAAAAABAAQAAAAAAAAQABAAAAAAIAIgIQAFgJABgEQABgQgCgHQABgJgFgHQgEgJgBgGQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQgEgPgTgKIgJgDQgGgCgFAAIgEgBQgpgEgkAAg");
	this.shape_72.setTransform(23.1,189.6);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#F2B17C").s().p("AA7BAQgKgBgGgCQgpgBgTAAIgHgBIgHAAIgMgEIgFgDIgFgDIgCgDIgCAAIgCgBQgEgFgCAAQAAgDgDgCQAAgBAAgBQAAAAAAgBQAAAAABAAQAAAAAAAAQgDgCgCgGQgCgIgCgCQABgDAAgGIgBgKIALgYQAHgHABgDQAIgFAOgHQAKgBAGgCIAngFQAagEAQAAQAAACACAGQACAoAIAyIABATIgBAFIABADQABAAAAAAQABABAAAAQAAAAAAAAQAAABAAAAIgSAAg");
	this.shape_73.setTransform(6.7,190.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#DD781D").s().p("AhUBEIABgCQgBgNgDgHQAAgLgDgRIgBgPIgDgQIgCgTQAAgNgBgHIABgHQAIgBAPAAIAYgDIAYABQAPAAAJgCIAPgBIAjgCIASgBIAFABIASgBQACADAAAGIACAIIAAAYIACAVQAAAGABACIABAbQABAQgDAKIABADIABAEQgpADgxgBQgXAEgrgCQgMADgOAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAg");
	this.shape_74.setTransform(23.7,189.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#F2B17C").s().p("Ag7A4IgCgLIABgJQgBgEAAgOQAAgNgDgEIgChAIAAgBQAkAAAnAEIAEABQAFAAAGACIAKAEQATAJADAPQAAABAAAAQAAAAAAABQAAAAABAAQAAAAABAAQABAGADAIQAFAHgBAJQACAHgBARQAAADgFAJIgIAIQgBAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAAAIgBACQgTAJgiADIg6ADQACgEAAgFg");
	this.shape_75.setTransform(40.5,189.3);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgwDLIgKgGQgGgDgGAAIAAgCQgBAAAAAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQgTgDgYgOQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAgBABAAQgJgFgSgOQgQgOgLgEQgHgIAAgMQgCgOgEgHQAAgFgCgFQAHgHgBgNQAEgLAMgSQAOgUAEgKIAEgBQAGgEAAgFQAFgDAJgJQAJgIAIgEQAPgQAYgRQAmgnAogdQAMgLAZgQQAbgTALgIIAFgDQANgDAFgHQATgDAGgDQAEABAIgBIANgBQAEAFAPAFQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAIABAGIADAEQgBAbgEAQQgGAVgNANQABAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQgHAJgKAQIgOAaQAAADgCAEIgLANQgEANgGAHIgBAGQggAtgXArQgLAOgPAeQgQAegKAOQAAAGgBAFIgHAJQADAFgCAEIgGAIQgCABgDAAQgDgBgEABQgOgGgKABgAgbC+IAGgFQAAgQAJgEQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAABgBQAAAAABgBQACgDADAAQACgKAGgMIANgUQgDgMASgNQABgDADgHQAEgFAAgFQAngzAfg9QAMgPAMgVIATgmQAAAAAAAAQABAAAAAAQAAgBABAAQAAAAAAgBIADgCQAAgFAGgKQAHgJgDgHQAEgCgBgDIAAgIQgBgEABgCQgEgEgGgLQgMgCgHAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAIgDACQgYgBgmAdQgKAEgTAQQgFACgMAJIgDAAQgDAFgLAGQgKALgMAIIgYAXQgRAOgIAJQgHAEgOAOQgNAMgKAFIgaAWQgWAegJAQQgBAFgEAJIgDAPQgBAUARAWIAOALQAJAHAHADQAjAeArAKIAEAEIAHgBIAIABg");
	this.shape_76.setTransform(32.9,-45.7);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#0060B6").s().p("AgcEyQgIABgBACQgRgCgUgFIgkgLIgFgFQgMgCgSgIIgegNIgBgDIgQgHQgKgFgEgGQgqgUgdgnQABgBgCgFQgLgTAGgXQAKgaAEgMIAEgDQAIgQARgYQAVgbAGgLQAJgOAWgWQAXgZAJgMIAhgaQAWgQALgKQAEgBAEgCQAcgfAsgbIAEgBQAEgCACABQAbgQAMgGQAZgLAUgBQABAAAAAAQAAAAABAAQAAAAABgBQAAAAAAAAIADgCQAKAAAXgFQAWgFAIABQAvgTAaglQAAgPAMgKIADgJIADAAQABAGAHAGQAFAFAAAHIAEAGQACADADABIAOAZQACAGgHAFIABABIACgBQgDANgKAIQgDALgKAWQgJAVgDANQgNAOgCAMQgEADgEAHQgFAJgCACQAAADgBAEQgMARgNAbIgcA5QgpBEgQAhIAAABQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAABIgBABQgBAFgGAHQgFAGAAAGIgEABIgCAHQgHAIgJASQgIASgIAHQgBAGgEALQgIAIgJASQgKATgFAHIgEAAQgKARgMAbQgDgBgCACIgGADQgBgDgEAAgAg2EFQADgBADABQAEAAACgBIAGgIQACgEgDgFIAGgJQADgFABgGQAKgOAPgeQAOgeAKgOQAYgrAggvIABgGQAGgHAEgNIALgNQACgEgBgCIAPgZQAJgQAIgJQAAAAAAgBQAAAAAAgBQAAgBAAAAQgBgBAAAAQANgNAGgVQAEgQAAgbIgCgEIgBgGQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQgPgFgEgFIgMABQgIABgEgBQgGADgTADQgFAHgNADIgGADQgKAIgbATQgXAQgMALQgqAdgmAnQgYAPgPAQQgIAEgJAIQgJAJgGADQAAAFgFAGIgEABQgFAKgNAUQgMASgFALQABANgGAHQACAFAAAFQAEAHABAOQABAMAGAIQALAEARAOQARAOAJAFQAAAAAAABQAAAAAAABQAAAAABABQAAAAABABQAXAOAUADQAAABAAAAQAAAAAAAAQAAABAAAAQABAAAAAAIABACQAGAAAGADIAKAGIAEAAQAIAAAMAFg");
	this.shape_77.setTransform(35.9,-51);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("ACMIuQgFgDgMgBQgMgBgFgDQgFADgIgEQgIgEgFABIgCgDQgMgDgOgIIgYgNIgDgBQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBABIgDgFQgHgBgMgGQgNgGgIgBIgFgDQgDgCgBgDQgIgDgbgPQgVgMgOgDQgGgGAAgEQgIABgFgGQgDACgEAAQgFgBgBgEQgPACgUgGQgXgIgKAAQgDgFgKgDQgLgDgDgEQgDABgFgDQgFgCgEABQgJgGgbgNQgXgLgLgLQgEAAgGgEQgFgEgEAAIgfgbQgSgRgKgSIgBgIQgBgEgDgCQAAAAAAAAQAAgBABAAQAAAAAAAAQABgBAAAAQgDgGADgLQAEgMAAgGQAAAAAAgBQAAAAAAAAQAAAAgBgBQAAAAAAAAIgCgDQAGgIAGgOIAKgYQALgIAGgQQAIgHAMgQQAFgKAMgPIARgZQAJgHACgGQAKgHARgVQAQgTANgHQABgEAHgEQAIgFABgDQASgLAigbQAggbAVgMIAJgGIAJgGQAOgFADgGQAFABAHgEIAJgHQARgFAkgIQAfgHAQgFQAmgFAZgbQARgRAQgmIAAgEQAAAAAAAAQAAgBgBAAQAAAAAAAAQgBgBAAAAIAOgVQAHgNACgLQAEgBADgFIAAgFQAMgPACgMQAAAAABgBQAAAAABAAQAAgBAAAAQABgBAAAAIACgDQAGgfAVgqQAbg4AFgNIADgCQAAgBAAAAQAAgBABAAQAAAAAAAAQABgBAAAAQAGgRAHgGIAJABQgZA3gOAaQABAHgHAGIAAAGIgGAGIgoBrQgMAMgFAWQAAAAgBAAQAAAAAAAAQAAABgBAAQAAAAAAAAQAAABAAAAQAAAAAAAAQgBABAAAAQAAAAgBAAIAAADQAGAOAOAYQAQAaAFANQAEgBAGgDIAqgGQAYgDAQACQARgCAMgJIAIgRQAFgKABgIIgCgBQgBAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgDgDgGQgEgGgEgCQgCgFgGgGQgGgGgBgEQgFAAgEgGQgEgIgEAAIAAgEIgEgBQgCgHgFgEIgKgIQAAgMgDgFIADgQQADgJAGgEQABgGAHgPQAGgNAAgKQAHgGAFgPQAGgQAFgFQABgKAKgSQAIgRACgLQAHgMAOgeQAOgcAJgOQACgFgBgDIACgDIAGAAQAAABAAAAQAAAAABAAQAAABAAAAQAAAAAAAAIAHgCIACAJIgDgBIgEABQgEAKgPAcQgMAXgFAPQgIAMgKAaQgLAagIAMIgDANQgDAHAAAFQgHAMgHATIgKAhQgHAFAAAMIADAFQACAEgBADIAOAQQAJALAGAEQACAHAIAHIALAKIAFAIQAEAEAEAAIAHAHQgBAHgHAMQgGAKABAKQgLAPADAQQgBAAAAAAQAAABgBAAQAAAAgBAAQgBAAAAAAIgEACIgBABIgHAOQgEAJgFAFQgFAWgMAYQABAHgCAGQAAABAAAAQAAABABAAQAAABABAAQAAABABAAQABABAAAAQABAAAAABQABAAAAAAQAAABAAAAQgBADADAIQAGAGADAJIAFAQQAIAUAIAlQABADgCADQACAHABAiQACAIACAPQAAAPADAHIgCBDQgDAHABAVQAAASgFAIQgLBEgLAeQACADgBADQgKAbAAAMQgaA3gRAZQgdArgwAOQgFgBgNACIgSABIgDAAgACNIaIATADIAXgFQAPgDAKgGIADgFQAIgEAJgKQAJgLAFgEQAEgOAKgHQADgHAQgaIADgLQACgGAEgEQgBgGAEgKQAEgKgBgGQAJgJgEgJQAKgkAGgRIgCgGQAKgZAEgrIAEhJIgDgRIABgCQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQgDgpgGgSQABgWgHgRQACgCAAgEIgCgGQgDgGgEgNQgEgNgFgGQgEgBgBgDQABgGgHgLQgIgLABgJIgDgBQgBAAAAgBQgBAAAAAAQgBAAAAgBQAAAAgBAAQAEgCgEgGIAJgLQAEgHAAgIQALgPANgjQgEgEgSACQgygCgaAMQAAADgEAEQgEADAAAEQAAgBgBAAQAAAAgBAAQAAAAAAABQgBAAAAAAIgFAIQgDAEgDACIgSAmQgKAXgGAQQgGAHgGAJIgIASQgHAHgJATQgIATgJAHIgJgFQAOgbALgRQACgEgBgDQADgCAEgJQAEgFAEgDQADgMAMgOQADgNAKgVQAKgWADgLQAKgIADgNIgCABIgCgBQAHgFgCgGIgOgZQgCgBgDgDIgEgGQABgHgGgFQgGgGgCgGIgDAAIgDAJQgMAKAAAPQgZAlgvATQgJgBgVAFQgXAFgJAAIgCACQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAQgVABgYALQgNAGgbAQQgCgBgDACIgHABQgrAbgdAdQgEACgDABQgLAKgWAQIgiAaQgIAMgYAZQgVAYgKAOQgGALgUAbQgSAYgHAQIgFADQgDAMgKAaQgGAXAKATQACAFgBABQAdAnAqAUQAFAGAJAFIARAHIABADIAdANQASAIANACIAFAFIAjALQAUAFARACQABgCAJgBQADAAACADIAFgDQADgCADABQANgbALgRIADAAQAGgHAKgTQAJgSAIgIQAEgLABgGQAHgHAJgSQAIgSAIgIIABgHIAFgBQAAgGAFgGQAEgHAAgFIACgBQAAgBAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIABgBIAJAFQgDAIgKAPQgHAPgDAJQgUAbgDARQgEADgFAJQgEAIgEADQAAAKgNAOQgMAOAAALIgFAIQgEAFgBADQgKAIgEAFQgGAIACAKQADgBACAAIAFAAQAFAIAPAHQAQAHAFAFQAHACALAIQALAIAIABQALAGAUAJQAYAJAKAGQAJAAAEAGQAGABAWAIQARAFALgBQAGADANABg");
	this.shape_78.setTransform(45.7,-62.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgtBOQAQgiAmhCIAcg7IAJAFQABAEgCAEIgTAnQgNAYgJAMQABACgBAEQgGALgNAXQgNAYgIALg");
	this.shape_79.setTransform(51.1,-48.2);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#0060B6").s().p("AAcFOQgNgBgGgDQgJABgRgFQgWgIgGgBQgEgGgJAAQgKgGgYgJQgWgJgLgGQgIgBgLgIQgLgIgHgCQgFgFgQgHQgPgHgFgIIgFAAQgCAAgDABQgCgKAGgIQAEgFAKgIQABgDAEgFIAFgIQAAgLAMgOQANgOAAgKQAEgDAEgIQAFgJAEgDQADgRAUgbQADgJAJgPQAKgPADgIQAIgLANgWQANgXAIgLQABgEgBgCQAJgOANgYIATgnQACgFgBgDQAJgHAGgTQAJgTAHgHIAIgTQAGgKAGgHQAGgQAKgXIASgmQADgCADgEIAFgIQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAABQAAgEAEgDQAEgEAAgDQAagMAyACQASgCAEAEQgNAjgLAPQAAAIgEAHIgJALQAEAGgEACQABAAAAAAQAAABABAAQAAAAABAAQAAABABAAIADABQgBAJAIALQAHALgBAGQABADAEABQAFAIAEANQAEANADAGIACAGQAAAEgCACQAHARgBAWQAGASADApQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAIgBACIADARIgEBHQgEArgKAZIACAGQgGARgKAkQAEAJgJAJQABAGgEAKQgEAKABAGQgEAEgCAGIgDALQgQAagDAHQgKAHgEAOQgFAEgJALQgJAKgIAEIgDAFQgKAGgPADIgXAFIgTgDgAAXEQQAJAAAEgDQAPgQAMgBQAXgZAIgMQADgNAJgLQAGgXATgjIAKghQAHgUgBgPIADgCQAJhSAHgpIgBgLIgBgLQACgDAAgHQgBgIACgDQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAQAHgPgIgSQACgSgLgTQgKgSgNgIQgEAAgFgCIgJgDQgEADgIgBQAAAAgBABQAAABgBAAQAAAAgBAAQAAAAgBAAQgJAAgIAHQgKAKgFABIAAAGQgDABgDAGQgCAGgFABQgHASgGAHIABAEIgRAfQgJASgLAJQgBAKgGAPIgMAZQgDADgDABQgEASgLALQgBALgFAMIgJAWQgEAYgVAfQgGATgQAfQgSAigGAPIgDADQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAgBAAQABADgEADIADAEQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAEABADAFIAFAIIAHgCIAHAHQANAAAFAJQADgBAFACQARANAbAAQAUALAYgEQAFACAJAAg");
	this.shape_80.setTransform(57,-42.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AgGDuQgaAEgUgKQgbAAgRgNQgFgCgDAAQgFgIgNAAIgHgIIgHACIgFgIQgDgEgEgBQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAgBgBIgDgDQAEgEgBgCQABAAABgBQAAAAABAAQAAAAABgBQAAAAAAgBIADgDQAGgPASgiQAQgeAGgTQAVggAEgYIAJgTQAFgNABgKQALgOAEgRQADgBADgDIAMgZQAIgPABgKQALgKAHgSIARgeIgBgEQAGgIAHgSQAFgBACgGQADgGADgBIAAgFQAFgCAKgJQAIgIAJABQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAgBQAIABAEgDIAJAEQAFACAEgBQANAIAKASQALAUgCARQAIASgHAPQAAABABAAQAAAAAAABQAAAAAAAAQABAAAAABQAAAAABAAQAAAAAAAAQAAABAAAAQAAAAAAABQgCADABAHQAAAIgCADIABALIABALQgHAogJBTIgDABQABAQgHAUIgKAhQgTAjgGAXQgJAKgDAOQgIAMgXAYQgMACgPAPQgEAEgJAAQgHAAgFgDgABCjUQABABAAABQAAAAAAABQAAAAAAAAQAAABgBAAIgOAMQgJAVgaArQgWAogJAYQgIAJgHARQgJATgEAHIgNAiQgJAYgEANQgIAMgMAaQgMAbgIAMIgLAXQgHAPgBALQATAQARAFQADACAAADQAQAHAYAEIAqAHIALgEIAKgCQAFgFAGgBQAFgIAOgFQADgFAFgCIAFgLQAEgGAEgDQADgLANgZQAMgWACgPQATgkAAgdQAJgSgDgOIADgDQAAgLACgQIADgbQgEAAgCgFIADgDIAFAAIAEgmQgFgdADgSIgCgKQADgIgDgKQgDgOAAgFIgHgHQgFgEgBgFQgIgJgOAAIgCAAQgNAAgMAHgACCg4QABAAABAAQAAAAAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAg");
	this.shape_81.setTransform(58.7,-39.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AAAABIAAgCQAAAAAAABQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAQAAABAAAAIAAgBg");
	this.shape_82.setTransform(71.9,-45.3);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#A3CECD").s().p("AgDAQQgKgQAJgPQAEAAADgEQAEAFAAAMQAAAMADAGIgEABIABADQgDAAgHgEg");
	this.shape_83.setTransform(69.1,-84.6);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#A3CECD").s().p("AgHACIABgRIAGgEQABgBAEADQAEAMgCAJQgCAMgJAFQgDgIAAgLg");
	this.shape_84.setTransform(72.2,-84.3);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgCAnQgPgFgEAAQgFgDgGgLIgJgRIAIgSQAFgMAIgFIANgEQAHgBACgDQAGABAIADIAOAGQAFAFADALIAEATQgDAFgCAOIgIAKQgGAEgFACIgIABQgGAAgGgCgAARgQIgGAEIgBARQgBALADAIQALgFACgMQADgJgFgMQgDgDgCAAIgBABgAgRgPQgJAPAKARQAKADACAAIAAgDIADAAQgCgHgBgMQAAgLgEgGQgEAEgFAAg");
	this.shape_85.setTransform(70.4,-84.6);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("Ag4BoQgBgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIAAgDQADAAACgFQABgHAGgKQAHgLABgHIASgeQAKgSAEgNQADgCACgHQABgHAEgCIgBgEIADgBQALgbAegxIAKACQgEALgNAVQgMATgEAMIgBACIgCABQgBAEgDAHIgEAKQgHAIgGAMIgIAYQgLAOgJAZIgUAjg");
	this.shape_86.setTransform(77.8,-120.4);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#D0D8D8").s().p("AihE6QgOgZgGgOIAAgDQABAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQAFgWAMgNIAohrIAGgGIAAgFQAHgHgBgHQAOgaAZg3IAUghQAJgZALgOIAKgYQAGgOAHgIIAEgKQACgHAAgEIACgBIABgCQAEgMAMgTQANgVAEgLQAFgEAGgLQAFgMAFgEQANgdANgNQADgKAIgLIAQgTQARgoA3gPIgGAIQgEAFACAEQAAABAAAAQAAAAgBAAQAAABgBAAQgBAAgBAAQgCAOgKAOQgDAOgLAVQgNAXgDALQgJAMgNAbQgNAbgJANQAAAFgEAIQgFAIAAAFQgCABgCADIgEADQgMAlgPAVIgCAEQABADgCAEQgJAPgOAcQgOAcgFAMQgCALgIARQgKASgBAJQgFAGgGAQQgFAPgHAGQAAAJgGANQgHAPgBAHQgGADgDAKIgDAQQADAFAAALIAKAIQAFAFACAHIAEAAIAAAEQAEABAEAHQAEAHAFgBQABAEAGAGQAGAHACAFQAEACAEAFQADAGAAADQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAABAAIACABQgBAIgFALIgIARQgMAJgRABQgQgCgYAEIgqAFQgGAEgEAAQgFgMgQgagAhoDuIgMAEQgJAFgFAMIgIAUIAJARQAGALAFADQAEAAAQAFQANADAIgCQAGgCAFgEIAIgKQADgOADgFIgFgVQgCgLgGgFIgOgGQgIgDgGgBQgEADgHABg");
	this.shape_87.setTransform(80,-112.2);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AAAAAIABAAQAAAAAAAAQAAAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAg");
	this.shape_88.setTransform(84.9,-118.8);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AhPCWIgCABIgGAAQAOgVANglIAEgDQABgEACgBQABgFAEgHQAFgIAAgGQAIgMAOgbQANgZAIgNQABgKANgXQAMgWACgNQALgOACgOQABAAABAAQAAgBABAAQAAAAABAAQAAgBAAAAQgDgEAEgFIAGgIQg1APgRAoIgPATQgIALgDAJQgOAOgMAbQgFAEgGAMQgGAKgEAFIgKgCIAUghQAFgOASgaQATgcAGgPQAKgHAPgZQAOgJAMgOQAGABAKgGQALgGAIgBQANABANADIADAFQADACACAAQAAAHANAMQAGAagJARQABAEgCAHQgBAGAAAEQgDAFgEARQgFAQgFAHQABACAAADQgHAMgNAkQgLAggJARIgLACQACgLAHgTQAIgSABgJQAKgMgCgKQAGgHADgMQAEgRAEgFQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAQADgBABgFQACgFACgBQAAgIAFgRQAEgPgDgMQACgCAAgGQgBgEgDgHIgFgJQgDgCgCABQgBADgHAHQgGAGAAAFQAAAAgBABQAAAAAAAAQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAAAAAAAQgBAAAAAAIgCAFIgDADQgPAjgTAhQgDALgMAUQgMAVgDANQgOAWgPAgIgaA4IgHACQAAAAABgBQAAAAAAAAQABgBAAAAQgBgBAAAAg");
	this.shape_89.setTransform(93,-134);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#D0D8D8").s().p("AhNE0IgFgIIgLgLQgIgGgCgIQgGgEgJgKIgOgRQABgDgCgDIgDgGQAAgLAHgGIAKghQAHgSAHgMQAAgFADgIIADgMQAIgMALgaQAKgbAIgLQAFgQAMgXQAPgaAEgKIAEAAIADAAIgCgIIAYg4QAQghAOgVQADgOAMgVQANgWADgLQATggAQgkIADgDIABgEQABAAAAAAQABgBAAAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAQAAAAABAAQgBgGAGgGQAHgHABgDQADgBACACIAFAJQAEAHABAEQAAAGgCACQADAMgFAPQgFARABAIQgDACgBAEQgBAFgDABQAAABAAAAQAAAAABABQAAAAAAAAQABAAAAAAQgEAGgDAQQgEAPgGAGQACAKgKAMQgBAJgHATQgIASgBALQgDABgBAEQgBAEgDABQgDAZgNAVQgGAggTAnQAAAEgBAEIgDAIIgGASQgDALgEAGQgEAUgMAiQgPAjgEATIgFAGIABAGQgHATgPAiQgRAkgGARIgBAAQgEAAgDgDg");
	this.shape_90.setTransform(87.7,-115.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AhPDIQAFgSARgjQAQgiAGgUIgBgGIAFgGQAEgSAPgkQANggADgUQAEgGAEgLIAGgRIACgIQABgFAAgDQATgqAHgfQAMgVAEgaQADAAAAgFQACgEACgBIALgBQgKAogUAsQgBAMgKASQgJAlgKAUQgGAagSAuQgSAvgGAaQgFAFgCAPIgSAoQgMAYgJANg");
	this.shape_91.setTransform(88.8,-104.2);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AgUAdIADgJQAJAFAHAAQALAAAAgKQAAgIgLgEQgRgFAAgMQAAgIAGgFQAGgGAJAAQAKAAAGAEIgDAIQgHgDgHAAQgDAAgDACQgDADAAAEQAAAGALAFQARAFAAANQAAAJgGAFQgHAGgJAAQgKAAgJgFg");
	this.shape_92.setTransform(155.8,-29.4);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AgUAcQgFgFAAgIQAAgMAKgFQALgGARABIAAgCQAAgPgNAAQgKAAgHAEIgDgHQAIgGAMAAQAZAAAAAbIAAAXIABAPIgLAAIgBgIIAAAAQgHAKgMAAQgJAAgGgGgAgNANQAAAMAMAAQAJAAAFgLIAAgEIAAgKQgaAAAAANg");
	this.shape_93.setTransform(149.6,-29.4);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgOAhIgBhAIAKAAIABANIAAAAQAEgOANAAIADAAIAAALIgEAAQgMAAgCAPIgBAGIAAAhg");
	this.shape_94.setTransform(144.7,-29.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgbAEIAAgkIAMAAIAAAiQAAAVAPAAQAJAAAFgLIABgGIAAgmIAMAAIABBAIgLAAIgBgLQgHAMgNAAQgXAAAAgdg");
	this.shape_95.setTransform(138.3,-29.3);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgVAoQgJgKAAgPQAAgPAJgJQAIgJANAAQANAAAFAKIAAAAIAAgoIAMAAIABBfIgLAAIgBgLQgHANgNAAQgMAAgIgJgAgMgCQgGAFAAALQAAALAFAHQAGAHAHAAQAOAAAEgOIAAgRIAAgFQgEgMgOAAQgHAAgFAHg");
	this.shape_96.setTransform(130.5,-30.8);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AgUAcQgFgFAAgIQAAgXAmABIAAgCQAAgPgNAAQgKAAgIAEIgCgHQAIgGAMAAQAZAAAAAbIABAmIgLAAIgBgIIgBAAQgGAKgLAAQgKAAgGgGgAgNANQAAAMALAAQAMAAADgLIAAgEIAAgKQgaAAAAANg");
	this.shape_97.setTransform(123.4,-29.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AAjAhIAAgjQAAgVgOAAQgLAAgDALIgBAGIAAAnIgKAAIAAglQAAgTgOAAQgLAAgEAMIgBAGIAAAmIgMAAIAAhAIAKAAIABALQAIgMANAAQAOAAADANIAAAAQACgEAGgFQAGgEAIAAQAJAAAGAFQAHAIAAAPIAAAlg");
	this.shape_98.setTransform(114.5,-29.4);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgTAZQgJgJAAgPQAAgOAJgKQAIgKAMAAQAPAAAHALQAGAIAAAMIgBAEIgsAAQAAAXAUAAQALAAAIgEIACAJQgJAEgNAAQgNAAgJgJgAgLgSQgEAGgBAHIAhAAQAAgHgDgFQgFgHgJAAQgGAAgFAGg");
	this.shape_99.setTransform(105.4,-29.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgTAbQgIgHAAgQIAAgkIAMAAIAAAiQAAAVAPAAQAKAAAEgLIABgGIAAgmIAMAAIABBAIgLAAIgBgLIAAAAQgHAMgNAAQgJAAgGgGg");
	this.shape_100.setTransform(98.2,-29.3);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AASAvIAAglIAAAAQgGALgOAAQgMAAgIgJQgIgJAAgNQAAgSAKgJQAIgJAMAAQANAAAGAMIAAgKIAMAAIgBBbgAgMgdQgGAHAAALQAAALAFAEQAFAIAIAAQAMAAAFgMIABgFIAAgNIAAgFQgEgNgOAAQgHAAgFAHg");
	this.shape_101.setTransform(90.4,-28.1);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgUAcQgFgFAAgIQAAgXAmAAIAAgBQAAgPgNAAQgLAAgHAFIgCgIQAKgGAKAAQAZAAAAAbIABAnIgLAAIgBgJIgBAAQgHAKgKAAQgKAAgGgGgAgNAOQAAALALAAQAMAAADgLIAAgEIAAgKIgDAAQgXAAAAAOg");
	this.shape_102.setTransform(156.7,-45.8);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#000000").s().p("AgPAhIAAhAIAKAAIABANIAAAAQAEgOANAAIADAAIAAALIgEAAQgMAAgCAPIgBAGIAAAhg");
	this.shape_103.setTransform(151.8,-45.9);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AgUAcQgFgFAAgIQAAgXAmAAIAAgBQAAgPgNAAQgLAAgHAFIgCgIQAJgGALAAQAZAAAAAbIABAnIgLAAIgBgJQgIAKgLAAQgJAAgGgGgAgNAOQAAALALAAQALAAAEgLIAAgEIAAgKIgDAAQgXAAAAAOg");
	this.shape_104.setTransform(145.7,-45.8);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AgeAvIAAhcIALAAIAAAMIABAAQAHgNAOAAQAMAAAIAJQAIAKAAAPQAAAOgJALQgIAJgNAAQgMAAgGgLIgBAAIAAAkgAgKggQgFAEgCAHIgBAEIAAAMIABAFQAEAMANAAQAIAAAGgHQAFgFAAgMQAAgKgFgHQgFgIgJAAQgFAAgFAFg");
	this.shape_105.setTransform(138.9,-44.5);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("AgUAcQgFgFAAgIQAAgXAmAAIAAgBQAAgPgOAAQgKAAgHAFIgDgIQAKgGALAAQAZAAAAAbIAAAXIABAQIgLAAIgBgJIgBAAQgGAKgMAAQgJAAgGgGgAgNAOQAAALALAAQALAAAEgLIAAgEIAAgKIgDAAQgXAAAAAOg");
	this.shape_106.setTransform(128.4,-45.8);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#000000").s().p("AgVAnQgJgJAAgPQAAgPAJgJQAJgJAMAAQAMAAAGAKIAAgoIAMAAIABBfIgLAAIAAgLIgBAAQgGANgOAAQgMAAgIgKgAgMgBQgFAEAAAMQAAAKAFAHQAFAHAHAAQAGAAAFgEQAFgEACgGIAAgGIAAgLIAAgFQgBgEgFgEQgFgEgHAAQgHAAgFAIg");
	this.shape_107.setTransform(121.2,-47.3);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AgUAcQgFgFAAgIQAAgXAmAAIAAgBQAAgPgNAAQgLAAgHAFIgCgIQAJgGALAAQAZAAAAAbIABAnIgLAAIgBgJQgHAKgMAAQgJAAgGgGgAgNAOQAAALALAAQALAAAEgLIAAgEIAAgKIgDAAQgXAAAAAOg");
	this.shape_108.setTransform(114.1,-45.8);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#000000").s().p("AAjAhIAAgjQAAgVgOABQgKAAgFAKIAAAGIAAAnIgKAAIAAglQAAgTgOABQgLgBgEAMIgBAHIAAAlIgMAAIAAhAIAKAAIABAKIAAAAQAIgLAOAAQANAAADANQABgDAHgGQAFgFAJABQAIAAAHAFQAHAIAAAQIAAAkg");
	this.shape_109.setTransform(105.3,-45.9);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#000000").s().p("AAAAiQgNAAgJgJQgJgKAAgPQAAgOAKgKQAJgJAMAAQAOAAAJAJQAJAKAAAOQAAAQgLAKQgJAIgMAAgAgOgQQgFAHAAAJQAAALAGAHQAGAHAHAAQAIAAAGgHQAGgIAAgKQAAgJgFgHQgGgIgJAAQgIAAgGAIg");
	this.shape_110.setTransform(95.8,-45.8);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("AgbAuIAAhZQAIgCAPAAQAQAAAIAHQAIAIAAAMQAAANgHAFQgKAJgQABIgKgBIAAAlgAgPgiIAAAiIAKAAQAVAAAAgSQAAgSgUAAg");
	this.shape_111.setTransform(89,-47.1);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#000000").s().p("AN1EfQgBgEgEgFQgEgFgCgCQgDgIABgMQABgOgCgIQgaAAhKgIQhEgHgmACQgCAAgEgBIgFgCQgWAChCgFQg2gFgiAHQhrAChmAJQgFgCgFABIgLABIgHgDIgHgBQgXADgmAAIhCABQgGAEgLAAQgLgBgGgDQgHABgcgBQgYgCgMAEQgGgDgMABIgTACIgTAAIgVgCIgTAAIgSABIg7gDQgjgCgUABQgCgCgHAAIgKABQhkANhogEQgJgGgWAAIgjABQgCAAgEACQgDACgEgBQgQgBgNgOIgWgXIgCgGIAAgHQgNgNgJgdIgOgwQgQgIgWABQgaACgNAAQgfgCgQABIgjAAIgRgGQgQgCgkgBQgjAAgRgDQgWgFgKABQgKAAgNgBIgVgDQg2gEgfgKQgBgEgEgDIgHgFQAAgPgGgKIgCgSQgCgNgDgIQAGgKgGgjQAKgGAAgMQgCgPAAgHQAFgFAQgGQAOALAUgOIAOAHQA5gCCPgMQBWADBOgEQAAAAAAAAQABAAAAAAQAAgBAAAAQAAgBABgBQAAAAAAAAQABgBAAAAQAAAAABAAQABAAAAAAIAGABQAEABAEgCQgCgEAEgEQAFgEAAgDQACgTAPgbQARgfADgPQALgHACgHQAHABAGgEQAJAAAhgFQAbgEAPAGIAngFQAagDAPgFQBCAIAigBQATgBAqgEQAngDAWAAIAfABQATABAMgCQAQAGAngFQApgGAOAFIAagBQAOAAAJACQArABBQgHQBPgHAiAAQABgCAEAAQAEAAACgCQAaACAyAAQAzABAcABQAjAJBDAAQBJABAfAFIAKgDQAFADAGAAIAMgCQAgAABCAFQA5ADAfgKQAFgBAHADIA/gNQApgFAXAMQAOgGASAHQAAAFAGACQAHACgBADQACAIgFAWQAEALABATIAAAhIACAMIACALIgCAJQgCAFABADQADAxADBWIAFCBQgFAJAAAQIADAfQgIARAKAfQgCAEAAAFIgBAIQAAABABAAQAAABABAAQAAAAABgBQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAAAABQAAAAAAABQAEAEgCAFQgBAFADAEQgEACAAACIAAAFQgGAEgPAFQgPAFgHAGQguAIgjAAQgtAAgagNgAOPj6IgMAGQgGASAAArIACBCQgDAIgDADIAEANQAAACgCADIgCAFQAFAfAAAxQAAAwADAWQgFAJAAAQQAAAPAEAMQgEAVgCAaIgCAqQABAEAFAEQAEAFABAEQAAADgEADIgGADQADAEgBAHIAAAKQACAFAGAEQAHAFACADQAcAJAkgDQAggDAcgMQAGgBAFABIAGgIQACgEAEgCQgFgdAEhEQAFhFgFgfIAAieQgBhbgKhCQgPABgBgBQAAAFgCAEQgEAFgBAEQgNADgTgFQgWgGgKABQgRADgKgDQgDAAgCACQgDADgDgBQgBABAAAAQgBAAAAAAQgBAAAAgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQgBAAAAAAQAAAAgBAAIgBAAgAk+DRQBagIAcACQAnAHA+AAIBogCIAEgCQABAAABAAQABAAAAAAQABgBAAAAQABAAAAgBQAzAKArgKQAXAEAzgCQA+gDASABQAEABACgCQAAgBABAAQAAgBABAAQAAAAABAAQAAgBAAAAQBJAHBJgNQAJABANAAIAYAAQAigDA7ACQBLADASgBQAuAABaAKQAGAAAHACQAPgCAVABQAZABALgBIADhbQACg/ADgjIgFgPQADgVgEhFQgDg6AJgfQgCgJgBgZQAAgVgDgLQgCgCACgEQACgEgBgEIgpgBQgcgBgMACIgRgDIgPgEQgXAEglgDQgvgDgNAAQgjgEhBgCQhPgBgbgCQgEAAgIgCIgLgDQgGgBgIACIgOACQgbgDgNAAQgTAAgkACIg5ADQgQABgeAEQgfAEgOAAQhPADgygFIhLAEQgsACgggFQgOAEgZgBQghgBgJABIgKACQgGADgEAAIgjAAQgUgBgNAGIgbgDQgPgCgIgEQgOADgiADQgeACgQAGQglgJgmAJQgBABAAAFQACAFgFACIABAKQABAIgBAFQAFALACAbQACAaAGAKQgCASAEAjIAFA1QAAADADACQAAABABABQAAAAABABQAAAAAAABQAAAAAAAAQgDAGADAGQAAABAAAAQAAAAAAAAQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAAAAAQgBAAAAAAQAAABgBAAQAEADgBADIgDAFQACAGAAALQAAAIADAGQAAAEgBADIgCAFQAFAQACAXIAEAmIgIAeQgBASAEAKIgGAGQgEAEABAIQAYABALAHQAGgCAHABQAIAAADADQABgBAHAAQAFAAADgBQArAIBKgGgAo/CAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAABQAAAAgBAAQAAABAAAAQAAABAAAAQAIALAKAcQAIABAEAJQAGALAFABQAAgEAEgIQADgHgCgEQAFgFADgMIACgWQAFgIgEgZQAGgVgOgrIACgSQACgLgEgHQAJgtgKgbIAAgJQgIgXAFgYQgKgngBgqQgGgJgEgLQgHAHgIARQgKAVgEAGQADAHgFAMQgIAOAAAGQAAABABABQAAAAAAAAQABABABAAQAAAAABAAIgCACIgDACQAAAAAAABQAAAAABABQAAAAAAAAQABAAAAAAIADgBQABAJAGAGIALAKIAEAaQANADgDAZIADAGQACADAEAAQgBADgFgBQANANgHAPIAEAAQABAHgFAJQgGAKAEAGIgKARQgFAKABAIQgRAMAHAJQgBABAAAAQgBABAAAAQgBAAAAAAQgBABAAgBIgFgCQgEAZANAbgAu8AtQANACAbAAQAcAAANADQALACAcABQAfAAAOACIAZAEQAOACAJgBIAgAAQAUAAALgFQAHACAPABQAMAAAGACQADgCAJgBQAKAAACgDQgCgGgMAAQgNAAgDgDQgUgBgkgFQgogGgPgBQgSgHgtgKQgCgEgFgDIgIgFQACgPgEgJQABgEAHAAIAKABQAEgDAGgBQAHgBADgCQAWABAvAAQAoAAAZAJQAQAAAcAEQAcAFARAAQgCgDABgHQABgGgFgBQAAAAgBAAQAAAAgBAAQAAAAAAABQAAAAAAAAQAAABABABQAAAAAAABQAAAAAAAAQAAABAAAAIgIgDQgEgCAAgEQgFABgNgDQgKgCgHADQgBAAAAAAQgBAAgBAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAgBgBAAQAAAAgBAAQgcAAgogKIhEgRQgMADgQgFQgQgFgLgKQgCgJAKgFQAJgGABgGQAUABAOgFQAtAGApACQAjACAyAAIgJgOQgMACgYgCQgdgDgPABQgeABgjgDQgGgBgHAAQgCACgDAAIgNABIgOAAIggADQgUADgJAAIgqAAQgYABgRAHQgJgFgQAAQgTACgLgBQgCAHADAOQACANgDAFQACALABAtQABAjAIAUIAIAAQAMAAAPADgApSAhQAJgHADgSIgMgEQgIgBgDgDIhngKQg+gGgkAKQADAFAJABQAJAEADADQAnAHAMADQAVAAAdAHQAIgCAPADQANACAIgCQAUAIAXAAgAwTARIgCAAIAJAJQAGAFAGACQABgIgCgVQgCgTACgKQgCgHACghQABgbgIgMQgHACgDAOQgGABgCAJQgDAKgCACIADAJQgDAGACAPQACAMAEAJQgFADACAFQABAEAEADIgCAKQgBAGAHAAQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAgApHg5QAAgEgCgHIgDgLQgTgFgqgBIhGgCIgfgCQgUgBgMACQAGAFAUADQATAEAGAFIAJABQAGABACgCQAHADASADQAQACAIAFIArgCIAGAAQAVAAAMADg");
	this.shape_112.setTransform(109.6,-33.5);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFBF00").s().p("Ag/EJQgCgDgHgFQgGgEgBgFIgBgKQABgHgDgEIAGgDQAEgDABgDQgBgEgFgFQgFgEgBgEIADgqQABgaAEgVQgEgMABgPQAAgQAEgJQgDgWAAgwQAAgxgFgfIACgFQACgDAAgCIgEgNQADgDADgIIgChCQAAgrAGgSIANgGQAAgBABAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQABAAAAAAQABAAAAAAQABAAAAAAQADABADgDQADgCADAAQAJADARgDQAKgBAUAGQATAFANgDQABgEAEgFQADgEAAgFQAAABAQgBQAJBCABBbIAACeQAFAfgEBFQgFBEAFAdQgEACgCAEIgFAIQgGgBgGABQgcAMgfADIgSAAQgYAAgVgGg");
	this.shape_113.setTransform(206.8,-32.8);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FF7F00").s().p("ApgDxQgCACgFAAQgHAAgBABQgEgDgHgBQgHgBgGACQgLgHgYgBQgBgIAEgDIAGgHQgFgKACgRIAHgeIgDgmQgCgYgFgQIABgFQACgDgBgDQgCgGAAgJQAAgKgCgHIADgHQABgCgEgEQABAAAAAAQAAgBAAAAQABAAAAAAQAAAAABAAQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAAAAAQgDgGADgGQAAgBAAAAQAAAAAAgBQgBAAAAgBQgBgBgBAAQgCgDAAgCIgFgzQgEgjABgSQgFgLgCgaQgCgbgFgLQABgFgCgIIAAgJQAFgCgCgFQgBgFACgBQAlgKAlAKQARgGAegDQAigCANgEQAJAEAPADIAaADQANgGAVAAIAjAAQAEAAAGgCIAKgDQAJgBAgABQAaABAOgEQAfAFAtgBIBNgFQAxAFBPgCQAPgBAdgEQAegEAQAAIA5gDQAjgDAUAAQANAAAbADIAOgCQAIgBAFAAIAMADQAIADAEAAQAbACBPABQBBABAjAFQANgBAvAEQAlADAWgFIAQAEIARAEQAMgDAbACIAqABQABADgCAFQgCADACACQADAMAAAVQABAYABAKQgIAeADA6QAEBDgDAXIAEAQQgCAjgCA+IgEBbQgKABgZgBQgWAAgPACQgHgDgFAAQhagKguABQgSAAhMgDQg6gCgjAEIgXAAQgOAAgIgCQhJANhJgGQAAAAAAAAQgBAAAAAAQgBABAAAAQgBABgBAAQgCACgDAAQgSgBg+ACQgxADgXgEQgrAKgzgKQAAAAgBAAQAAABgBAAQAAAAgBAAQgBABgBAAIgEACIhqABQg+ABgngIQgdgBhZAHQggADgaAAQgjAAgZgFg");
	this.shape_114.setTransform(126.8,-37);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFBF00").s().p("AAIDJQgFgKgFAAQgKgdgIgLQAAAAAAAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABgBQAAAAAAAAQABgBAAAAQAAgBgBAAQgNgcAEgZIAFADQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAgBQgGgJARgLQgBgIAFgLIAHgRQgDgGAFgJQAGgLgBgIIgEAAQAGgNgMgMQAFABABgEQgEAAgCgDIgCgGQACgYgMgDIgDgbIgLgKQgGgGgBgIIgDABQAAAAgBgBQAAAAAAAAQgBAAAAgBQAAAAAAgBIADgBIACgDQgBAAAAAAQgBAAgBAAQAAgBAAAAQgBgBAAAAQAAgHAHgOQAGgLgEgIQAFgGAJgUQAIgSAGgHQAEAMAGAIQABArAJAmQgEAYAIAXIAAAJQAJAbgIAuQAEAGgCAMIgCARQAOAsgGAUQAEAagFAHIgCAXQgDAMgGAEQACAFgDAGQgDAJAAAEQgFgCgGgKg");
	this.shape_115.setTransform(53.7,-35.2);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#D3D2D1").s().p("AAYBZIgYgEQgNgCgfAAQgcgBgLgCQgNgDgcAAQgcAAgMgCQgUgFgPACQgIgUgBglQgBgrgCgLQADgFgDgNQgCgOACgHQALABATgCQAQAAAJAFQARgHAYgBIApAAQAKAAAUgDIAggDIAMAAIANgBIAAAHQgNAFgTgBQAAAGgKAGQgJAFACAJQALAKAQAFQANAFANgDIBEARQAoAKAcAAQABAAAAAAQABAAAAAAQAAABABAAQAAAAAAABQABABAAAAQABABAAAAQABAAAAAAQABAAABAAQAHgDAKACQANADAFgBQAAADAEABIAIADQAAgBAAAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAEAAAAAGQgBAHABADQgRAAgcgFQgbgEgRAAQgYgHgpAAQguAAgUgBQgDABgHAAQgGABgEADIgKgBQgHAAgBAEQADAJgBARIAIAFQAFADACAEQAqAKATAHQAPABAnAGQAkAFAVABQACADANAAQAMAAADAGQgDADgJAAQgJABgEACQgFgCgNAAQgOgBgHgCQgLAFgUAAIggAAIgHAAIgQgBg");
	this.shape_116.setTransform(30.4,-36.5);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#D3D2D1").s().p("AABAHQgogCgtgFIAAgGQADAAACgCQAHAAAFABQAjADAegBQANgBAdADQAZACALgCIAJAMIgTAAQglAAgcgCg");
	this.shape_117.setTransform(40.3,-44.8);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#7C7670").s().p("AA8ANIgsABQgHgFgOgCQgSgCgHgEQgCADgGgCIgJgBQgGgDgTgDQgUgDgGgGQAMgCAUABIAfADIBEACQAqAAATAGIADAJQACAGAAAFQgOgEgZABg");
	this.shape_118.setTransform(41.2,-41);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#7C7670").s().p("AA5APQgJACgNgCQgPgDgIACQgbgHgVAAQgLgDgogFQgCgDgKgEQgJgDgCgFQAjgKA/AGIBkAMQADADAIABIAMAEQgDAQgIAHQgYAAgTgIg");
	this.shape_119.setTransform(40,-32.5);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#D3D2D1").s().p("AADA+IgHgJIADAAQAAAAAAAAQABAAAAAAQAAgBAAAAQAAAAAAAAQgHAAABgGIACgLQgEgEgBgEQgBgFAEgDQgEgJgCgKQgCgPAEgGIgEgJQACgCADgKQADgJAFgBQABgOAHgCQAJAMgCAbQgBAfABAHQgCAKACAVQACAVgBAIQgGgCgGgFg");
	this.shape_120.setTransform(5.4,-37.1);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#000000").s().p("AgSAbIADgJQAHAFAHAAQAKAAAAgJQAAgHgKgEQgPgEAAgLQAAgIAFgFQAGgFAIAAQAHAAAHAEIgDAIQgIgEgEAAQgIAAAAAJQAAAFAJAFQAQAEAAAMQAAAIgGAFQgFAFgJAAQgIAAgJgEg");
	this.shape_121.setTransform(2.9,165.2);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#000000").s().p("AgRAZQgFgEAAgHQAAgVAiAAIAAgBQAAgOgMAAQgIAAgHAFIgDgHQAIgGAKAAQAXAAAAAZIAAAiIgJAAIgBgHIgBAAQgFAJgLAAQgIAAgFgGgAgLAMQAAALAKAAQAJAAAEgKIAAgEIAAgJQgXAAAAAMg");
	this.shape_122.setTransform(-2.6,165.2);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#000000").s().p("AgNAeIgBg5IAKAAIAAALIABAAQADgNALAAIAEABIAAAKIgFAAQgKAAgCANIAAAFIAAAeg");
	this.shape_123.setTransform(-7,165.2);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#000000").s().p("AgRAYQgHgGAAgOIAAghIALAAIAAAfQAAATANAAQAIAAAFgKIABgGIAAgiIALAAIAAA6IgJAAIgBgKQgIALgKAAQgJAAgFgGg");
	this.shape_124.setTransform(-12.8,165.3);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#000000").s().p("AgTAjQgIgIAAgNQAAgOAIgIQAIgJALAAQALAAAFAJIAAgjIALAAIABBWIgKAAIAAgKIgBAAQgGALgMAAQgLAAgHgJgAgLgBQgFAEAAAKQAAAKAFAFQAFAHAGAAQANAAADgMIAAgGIAAgKIAAgFQgBgDgFgDQgEgEgGAAQgGAAgFAHg");
	this.shape_125.setTransform(-19.8,163.9);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#000000").s().p("AgSAZQgEgEAAgHQAAgVAiAAIAAgBQAAgOgMAAQgIAAgIAFIgCgHQAIgGAKAAQAWAAAAAZIABAiIgJAAIgBgHIgBAAQgGAJgKAAQgJAAgFgGgAgLAMQAAALAKAAQAJAAADgKIABgEIAAgJQgXAAAAAMg");
	this.shape_126.setTransform(-26.2,165.2);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#000000").s().p("AgOAWQgIgIAAgOQAAgMAIgJQAJgJANAAQAIAAAHAEIgDAIQgFgDgHAAQgIAAgGAHQgFAGAAAIQAAAKAGAGQAFAGAIAAQAFAAAIgDIACAIQgHAEgKAAQgMAAgIgJg");
	this.shape_127.setTransform(-31.8,165.2);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#000000").s().p("AgEAqIAAg6IAJAAIAAA6gAAAgbQgFAAAAgHQgBgHAGAAQAGAAABAHQgBAHgGAAg");
	this.shape_128.setTransform(-36,164);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#000000").s().p("AgaAqIgBhSIAKAAIABAKQAHgLALAAQAMAAAGAIQAIAJAAANQAAAOgIAIQgHAIgMAAQgLAAgGgJIAAAggAgPgTIgBAEIAAALIABAEQABAEAFADQAFAEAEAAQAIAAAEgHQAFgEAAgKQAAgKgFgGQgEgGgIAAQgMAAgDANg");
	this.shape_129.setTransform(-40.8,166.4);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#000000").s().p("AgSAZQgEgEAAgIQAAgTAhAAIAAgCQAAgOgLAAQgKABgGAEIgCgHQAIgGAKAAQAWAAAAAZIABAiIgKAAIgBgHQgGAIgKAAQgJAAgFgFgAgMAMQAAALALgBQAJABADgLIABgCIAAgKIgDAAQgVAAAAAMg");
	this.shape_130.setTransform(11,150.5);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#000000").s().p("AgNAeIAAg6IAJAAIABAMIAAAAQADgNAMAAIADAAIAAALIgEgBQgLAAgBAOIgBAFIAAAeg");
	this.shape_131.setTransform(6.6,150.4);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#000000").s().p("AgSAZQgEgEAAgIQAAgTAiAAIAAgCQAAgOgMAAQgJABgHAEIgCgHQAIgGAKAAQAWAAAAAZIABAiIgJAAIgBgHIgBAAQgFAIgLAAQgJAAgFgFgAgLAMQAAALAKgBQAJABADgLIABgCIAAgKIgDAAQgUAAAAAMg");
	this.shape_132.setTransform(1.1,150.5);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#000000").s().p("AgbAqIAAhSIAKAAIAAAKQAIgLAMAAQALAAAHAJQAHAHAAAOQAAAOgIAIQgHAIgMAAQgKAAgHgJIAAAggAgPgTIgBAEIAAALIABAEQADALAMAAQARAAAAgWQAAgJgEgGQgFgHgIABQgMAAgDANg");
	this.shape_133.setTransform(-4.9,151.6);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#000000").s().p("AgSAZQgEgEAAgIQAAgTAiAAIAAgCQAAgOgMAAQgJABgHAEIgCgHQAIgGAKAAQAWAAAAAZIABAiIgJAAIgBgHIgBAAQgGAIgKAAQgJAAgFgFgAgLAMQAAALAKgBQAJABADgLIABgCIAAgKIgDAAQgUAAAAAMg");
	this.shape_134.setTransform(-14.3,150.5);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#000000").s().p("AgTAkQgIgJABgNQAAgOAHgIQAIgIALAAQAMAAAEAJIABAAIAAgkIAKAAIABBWIgKAAIAAgLIgBAAQgFAMgNAAQgLAAgHgIgAgLgBQgFAEABAKQgBAKAFAGQAFAGAGAAQAGAAAEgDQAFgEABgGIABgEIAAgLIgBgEQgDgLgNAAQgGAAgFAHg");
	this.shape_135.setTransform(-20.8,149.1);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#000000").s().p("AgRAZQgFgEAAgIQAAgTAiAAIAAgCQAAgOgMAAQgJABgGAEIgDgHQAJgGAJAAQAXAAAAAZIAAAiIgJAAIgBgHIgBAAQgFAIgLAAQgIAAgFgFgAgLAMQAAALAKgBQAJABADgLIABgCIAAgKIgDAAQgUAAAAAMg");
	this.shape_136.setTransform(-27.2,150.5);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#000000").s().p("AAgAeIAAggQAAgSgNAAQgJAAgEAKIgBAFIAAAjIgIAAIAAgiQAAgQgNAAQgKAAgDALIgBAFIAAAiIgLAAIgBg6IAKAAIABAKIAAAAQAHgLAMAAQAMAAADAMIAAAAQACgEAEgEQAGgEAIAAQAHAAAFAFQAIAGgBAPIAAAhg");
	this.shape_137.setTransform(-35.2,150.4);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#000000").s().p("AgTAWQgJgIAAgOQAAgNAJgIQAIgJALAAQANAAAIAJQAIAIAAANQAAAOgKAJQgIAHgLAAQgLABgIgJgAgMgOQgFAHAAAHQAAAJAFAHQAFAGAHAAQAHAAAFgGQAFgHAAgJQAAgHgEgHQgFgHgIgBQgHABgFAHg");
	this.shape_138.setTransform(-43.7,150.5);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#000000").s().p("AgYApIAAhPQAKgCALAAQANAAAIAGQAHAHAAALQAAAMgGAEQgJAJgOAAIgJgBIAAAhgAgNgfIAAAfIAJAAQASAAAAgQQAAgQgRAAg");
	this.shape_139.setTransform(-49.8,149.3);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#000000").s().p("AukEHQgGgFgOgFIgTgIIAAgFQAAAAAAgBQAAAAgBAAQAAgBgBAAQgBgBAAAAQADgEgCgFQgCgEAEgEQAAAAAAgBQAAAAAAAAQABAAAAAAQAAAAAAAAQABABAAAAQABAAAAAAQABAAAAAAQABAAAAgBQAAgJgCgGQAIgdgHgPIACgcQABgOgEgIIAEhzQAChOADgsQgDgLAAgFIAEgVIAAgdQAAgSADgJIgBgPQgCgJABgEQAAgDAGgBQAFgCAAgEQARgHAMAGQAVgLAlAFQAMABAtALIAFgCQACgBADAAQAcAKA0gDIBYgEIAKABQAGAAAEgDIAKADQAbgFBCAAQA8gBAggHQAZgCAuAAQAsAAAZgCQAAABAAAAQABAAAAAAQABAAABABQAAAAACAAQABAAAAAAQABAAABABQAAAAABAAQAAABAAAAQAfAABHAGQBJAGAlAAQAMgDAhABQANgEAkAFQAjAEAOgFQAMACAQAAIAcgCQAUAAAjAEQAlADASAAQAfABA7gGQAWAGAyAFQAOgFAYADQAeAFAIAAIAFACIAGAAQACAHAKAGQAEANAOAcQANAZACAQQAAADAGAEQADAEgBAEQADABADgBQAEgBABABQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABABQAAABAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQBEADBPgCIBdAHQA5AEAeABQAJgFAEgBQATAMAMgJIAJAEQAGADADADQABAHgBAMQgBALAJAFQgEAiAEAIQgEAJgDAZQgFAKAAAMIgGAFQgEADgBADQgZAIgzAFQgaAEgNAAQgKgBgUAEQgPADgfAAQghAAgNADQgLAEgFABIgfAAIgrABIgjgCQgVgBgOAIIgMArQgJAagLAMQAAAFgCAHIgUAUQgMAMgOACQgDABgDgCQgDgDgDAAIgfAAQgVgBgIAGQhaAEhcgMQgOgCgEADQgQgBghACIg1ACQgWgBgLAAQgYAEgNgBIgRgDQgKgBgGAEQgKgEgXABQgYABgHgBQgFAEgKAAQgKAAgFgEIg8AAQgiAAgUgDIgHABIgGACQgQgBgDABQhWgHhngCQgegGgwADQg8AFgTgBIgFABQgDACgCgBQgjgBg8AGQhDAHgYAAQgCAHABANQABALgDAHIgGAGQgDAEAAAEQgYAMgpAAQgfAAgpgHgAugDtQAZALAdACQAgADAbgIQABgDAGgEQAFgEABgEQACgDgBgHQAAgGACgDQgJgDgBgFQABgEAFgEQAEgFABgDIgDgmQgBgXgDgTQADgLAAgNQAAgPgEgIQACgTABgsQAAgrAEgcQgDgGAAgEIADgMIgEgJQABgmAAgVQAAgogGgPQgIgEgDgCQAAAAgBAAQAAAAAAAAQgBAAAAABQAAAAAAAAQgBABAAAAQAAABgBAAQAAAAgBAAQAAAAgBgBQgCABgDgDQgCgCgEABQgJACgOgCQgJgCgTAGQgSAFgMgDQAAgEgEgFQgDgEAAgEQgBACgNgCQgIA7gBBTIAACOQgEAcADA+QAEA9gEAaQAEACABADIAFAIIAFAAIAFAAgAEfC8QBEAGAmgIQACABAFAAQAGAAABABQADgDAHAAQAFgBAGACQALgGAVgBQABgHgEgDIgFgGQAEgJgBgQIgHgbIADgiQACgVAEgPQgDgFABgFQADgGgBgHQAAgKABgGIgCgEQgBgDADgCQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAgBQAEgFgEgFQAAAAAAgBQAAAAABgBQAAAAAAgBQABAAAAgBQABgBABAAQAAgBAAAAQAAgBABAAQAAgBgBgBQAKhDgCgcQAFgJACgYQACgYAEgKQgBgFABgHIABgIQgFgCABgEQACgFgCgBQghgIghAIQgPgFgcgCQgfgDgMgDQgKAFgiADQgMgFgTABIgfAAIgJgCIgJgDQgJgBgdABQgWABgOgDQgbAEgogCIhEgDQgtAEhHgCQgNAAgbgEQgcgEgOAAQgSAAgigDQgggCgRAAQgXADgNgBIgLgBQgJgCgEABIgLACQgGADgEAAQgYABhIABQg6ABghAFQgMgBgpAEQgiACgUgEIgNAEIgQADQgLgCgYABQgfACgHgBQgBADACAEQACADgCACQgCAKAAATQgBAWgBAJQAHAbgDA0QgDA/ACASIgDAPIADBXIADBSIAhAAQATgBAOACIAKgCIA8gFQAngEAXABIBWgDQAzgCAgADIAUAAQANABAIgCQBAAMBCgGIAFACQAAABABAAQAAABABAAQAAAAABAAQAAAAABAAQAQgBA4ACQAuACAVgDQAmAJAvgJQACACAGABIBcACQA5AAAjgGIAMAAQAdAABBAFgAHsi8QAAAigKAoQAFAWgIAUIAAAIQgJAXAHAqQgCAGABAKIABAQQgLApAFARQgEAXAFAGIACAUQACALAFAEQgCAEADAGQADAIgBAEQAGgBAEgKQAFgJAHAAQAJgaAHgKIgCgCQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAgBAAgBQALgXgDgYIgFACQAAABAAAAQgBAAAAgBQgBAAAAAAQgBgBAAgBQAGgIgQgKQABgIgEgJIgIgPQACgGgEgIQgFgIABgHIADAAQgGgNALgMQgBABgBAAQgBAAAAgBQgBAAAAAAQgBgBAAgBQAEAAACgDIACgFQgDgWANgDIACgYIALgIQAGgGAAgIQAAABABAAQAAAAAAAAQABABAAAAQAAAAABgBQAAAAAAAAQABAAAAAAQAAgBAAAAQAAgBABAAIgDgBQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAAAAAgBQABAAABAAQAAAAABAAQAAAAAAgBQABAAAAgBQgBgGgGgMQgFgKADgHQgEgGgIgSQgIgQgHgGQgFANgDAEgAKCA2IAcAAQAIABAMgCIAXgDIAogDQAZAAAKgCQAMgCAZAAQAZAAALgDQAQgEAQACQAHgSABggQABgnACgLQgDgEADgMQACgNgCgGIgbAAQgOgBgJAFQgQgHgVAAIglAAQgIAAgTgDIgcgDQgSAAgHgBIgEgCQgHAAgEACQglACgWgBQgOgBgZADQgXACgKgCQgCAFgGAHQBSABBIgJQANAEASgBQAAAFAJAGQAIAEgCAJQgJAIgPAFQgOAEgLgCIg9APQgmAJgYAAQAAAAgBAAQAAAAgBAAQAAABAAAAQgBAAAAABQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBgBQgHgCgIACQgMACgEgBQgBAEgEACIgGACIABgDQAAAAAAAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQgEABAAAFQABAHgBACQAQAAAZgEQAZgEAOAAQAVgIAmAAIA9AAIAJACQAGABADACIAJgBQAHAAAAAEQgDAIABANIgHAFQgFADgBADIg5APQgNABgjAGQggAFgUAAQgCADgLAAQgMAAgCAFQADADAIAAQAIABAEACQAEgCALAAQAOAAAGgCQAJAEAUAAgAOcg7QACAegCAGQACAJgDASQgBATABAGQAFgBAFgEIAJgJQgBAAgBAAQgBAAAAAAQgBAAAAAAQAAAAAAgBQAHAAgCgFIgBgJQADgCACgEQABgEgEgDQADgIACgMQACgNgDgFIADgIQgCgCgDgKQgCgHgFgBQgDgNgGgBQgIAKACAYgAJ9gJQg+AJgdAAQgDACgHACIgLADQAEARAHAFQAVAAARgHQAIADAMgDQAOgCAGABQAagFATgBIAugJQACgDAJgDQAIgBACgEQgUgGgdAAQgSAAgWACgAKlhQIgdACIg/ACQglABgSAEQAAAEgCAGQgCAGAAAEQAMgDAYAAIAmACQAGgFAPgCQAQgCAHgDQACACAFgBIAIgBQAGgEARgDQASgDAFgFQgHgBgLAAIgKAAg");
	this.shape_140.setTransform(-2.7,162.9);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#95E7F4").s().p("AAAD0QgcgDgYgLIgLAAIgFgIQgBgCgEgDQAEgagEg8QgDg+AEgcIAAiPQABhSAIg7QAOABAAgBQABAEACAEQAEAFABADQALADASgFQARgFAJABQAOADAKgDQADAAACACQADACACAAQABAAAAAAQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQADADAJADQAFAQAAAnQAAAWgBAlIAEAKIgDAMQAAAEADAFQgEAcAAAsQAAArgDAUQAEAIAAAPQAAANgDALQADATACAXIACAmQgBADgEAEQgEAFgBADQABAFAIADQgCADAAAGQABAIgBACQgCAEgFAEQgGAFgBACQgUAGgXAAIgPAAg");
	this.shape_141.setTransform(-90.2,163.5);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#3FBEC4").s().p("AG6DbQhQgHgaACQgjAGg5AAIhegCQgHgBgCgCQguAJgmgJQgVADgsgCQg4gCgQABQgBAAAAAAQgBAAgBAAQAAgBgBAAQAAAAgBgBIgEgCQhCAGhAgMQgIACgNgBIgUAAQgggDg0ACIhVADQgYgBgmAEIg8AFIgLACQgNgCgUABIggAAIgDhSIgEhXIAEgPQgCgUADg9QADg0gIgbQACgJAAgWQAAgTADgKQACgCgCgDQgCgEABgDQAHABAfgCQAYgBALACIAPgDIAOgEQAUAEAigCQApgEAMABQAggFA7gBQBIgBAXgBQAEAAAHgDIALgCQAEgBAIACIAMABQAMABAYgDQARAAAgACQAiADASAAQAOAAAbAEQAaAEANAAQBHACAtgEIBFADQApACAbgEQANADAXgBQAcgBAJABIAJADIAJACIAgAAQATgBAMAFQAigDAKgFQAMADAfADQAbACAPAFQAigIAhAIQACABgCAFQgBAEAFACIgBAIQgBAHABAFQgFAKgBAYQgCAYgFAJQACAcgKBBQAAABAAAAQAAABAAABQAAAAgBABQAAAAgBABQAAAAgBABQAAAAgBABQAAAAAAABQAAAAAAABQADAFgDAFQAAAAAAABQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAAAABABQAAAAAAAAQAAAAAAABQgDACABADIACAGQgBAGAAAKQAAAHgCAGQgBAFADAFQgEAPgCAVIgDAiIAGAbQACAQgFAJIAGAGQAEADgBAHQgVABgLAGQgGgCgGABQgGAAgDADQgCgBgFAAQgGAAgBgBQgVAEgfAAQgYAAgegCg");
	this.shape_142.setTransform(-18.1,159.8);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#B9EAEF").s().p("AgTC0QgDgGACgEQgGgEgBgLIgDgUQgEgHADgXQgEgQALgpIgBgQQgCgKADgGQgHgqAJgXIAAgIQAHgVgEgWQAJgnAAgiQAEgEAFgOQAFAGAHAQQAJATAEAFQgDAIAFAKQAGAMAAAGQAAABAAAAQAAAAAAABQgBAAgBAAQAAAAgBAAQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAABIADABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAgBAAAAQgBAIgFAFIgLAJIgCAYQgLADABAWIgBAFQgCACgDABQAAABABAAQAAABAAAAQABAAABAAQABAAABAAQgLALAGAMIgEAAQgBAHAGAJQAEAJgDAFIAHAQQAEAJgBAIQAQAJgGAJQAAABABAAQAAABAAAAQABAAAAAAQABAAAAAAIAFgCQADAYgLAXQAAABAAAAQAAABAAAAQAAABAAAAQAAAAABAAIACADQgIAKgIAZQgFABgFAJQgEAKgGABQABgFgDgHg");
	this.shape_143.setTransform(47.6,161.4);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#D3D2D1").s().p("AgpBRIgcgBQgTAAgKgEQgGACgNAAQgMAAgEADQgDgDgJAAQgIAAgCgDQACgGALAAQALABADgDQATgBAggFQAjgFAOgBIA2gQQACgDAEgCIAHgFQgBgPAEgJQgBgDgGAAIgKABQgDgDgFAAIgKgBIg7AAQglABgWAFQgOABgZAEQgZAEgQAAQABgCAAgHQgBgFAEAAQAAAAABAAQAAAAABAAQAAAAAAAAQAAAAAAAAIgBADIAHgDQADAAABgDQAFABALgDQAJgCAGADQABAAAAAAQABAAABAAQAAAAAAgBQABAAAAgBQAAAAABgBQAAAAABAAQAAAAAAgBQABAAAAAAQAZABAlgJIA9gPQALACAMgFQAPgEAJgJQACgIgIgFQgJgFAAgFQgRABgMgFIABgGQAGABAQgBIAdADQASADAIAAIAlAAQAWABAQAGQAIgEAOAAIAbABQACAGgCANQgDALADAFQgCAKgBAmQgBAhgHASQgPgBgQAEQgLACgZAAQgZAAgMACQgKACgaABIgoACIgUAEIgPABIgGAAg");
	this.shape_144.setTransform(68.5,160.2);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#D3D2D1").s().p("AhMAIQAGgHACgDQAKACAXgCQAagDALABQAXABAkgCQAEgCAHAAIAFACIgBAFQg+AIhEAAIgWAAg");
	this.shape_145.setTransform(59.6,152.7);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#7C7670").s().p("AhWAEQACgEAAgEQASgEAlgBIA9gCIAdgCQARgBALACQgFAFgSADQgRADgGACIgIABQgFABgCgCQgHADgQACQgNACgGAFIgmgCQgYAAgMADQAAgEACgGg");
	this.shape_146.setTransform(58.9,156.2);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#7C7670").s().p("AhjAAIALgDQAHgBADgCQAdgCA9gJQA4gGAgAJQgCAEgIADQgJAEgCACIguAIQgTAAgYAGQgGgCgOADQgMACgIgCQgRAHgVAAQgGgFgFgQg");
	this.shape_147.setTransform(59.8,163.7);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#D3D2D1").s().p("AgMAkQACgTgBgJQABgHgBgbQgCgYAHgLQAGACACAMQAFABACAIQADAJACACIgEAJQAEAFgCANQgCAJgDAIQADADgBAEQgBAEgEADIACAKQABAGgGAAQAAAAAAAAQAAAAABAAQAAABABAAQABAAAAAAIgGAIQgFAEgGACQgBgHACgTg");
	this.shape_148.setTransform(91,159.6);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AAJAZIAEgaQACgOgMgBQgGgCgFAJIgBAEIgDAbIgJgBIAGguIAHABIAAAIIAAAAQAGgJAJACQARACgCAUIgEAbg");
	this.shape_149.setTransform(111.3,117.1);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AgCAiQgKgCgGgHQgGgIACgLQABgKAIgGQAIgGAIABQAKACAGAHQAFAGgBALQgCAMgIAHQgGAEgHAAIgCAAgAgIgDQgEADgBAHQgBAIADAFQADAGAHABQAEABAFgFQAFgEABgJQACgQgOgCIgBAAQgFAAgEAFgAAAgUIAJgNIAJABIgOANg");
	this.shape_150.setTransform(105.9,115.5);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AAJAiIAAgIQgGAJgJgCQgJgBgFgHQgFgIABgLQACgKAHgGQAHgGAIABQAJABAEAJIADgdIAJABIgIBFgAgKgEQgEAEgBAHQgCASAOACQAIABAEgKIACgNIAAgDQgBgIgKgBIAAgBQgGAAgEAEg");
	this.shape_151.setTransform(100.5,114.8);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AgCAZQgKgCgGgHQgGgIACgJQABgMAIgGQAIgGAIABQAKACAGAHQAFAIgBAJQgBAMgJAGQgGAFgHAAIgCAAgAgIgNQgEAFgBAIQgBAGADAFQADAGAHABQAEABAFgFQAFgFABgIQACgQgOgCIgCAAQgEAAgEAEg");
	this.shape_152.setTransform(94.8,115);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AgHAiQgKgBgGgFIADgGQAGAFAIAAQAOADACgRIAAgGQgGAIgIgCQgJgBgGgHQgEgGABgKQACgLAHgHQAHgGAHABQALACADAJIABgIIAIABIgFAoQgDAQgHAFQgGAEgGAAIgEgBgAgHgXQgFAFgBAIQgBAHADADQADAGAHABQAHABAEgIQAAAAABAAQAAAAAAAAQAAgBAAgBQABAAAAgBIAAgJIAAgEQgBgJgJgCIgCAAQgDAAgEAEg");
	this.shape_153.setTransform(89.3,115.3);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("AgHAiIAHhFIAJABIgJBFg");
	this.shape_154.setTransform(85.5,112.7);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AASAiIgEgWIgWgDIgKAUIgJgBIAeg+IAKABIAPBEgAgFACIASADIgGgfg");
	this.shape_155.setTransform(80.9,112.5);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#000000").s().p("AA1L5IgQgEQgkgVgFgiQgGAJgKAVQgKARgNAFIgPAAIgQgCQgXgKgNgjIgfAoQgWAVgcgJQgUgTgCgQIgEgHIgFgaQgCgOACgMQgEAAgDAEIgGAGQgKAJgCAEIgaAWIgZAJQgQAEgOgEQgSgHgIgGQgHgKgFgLQgCgPAEgUIAHggIgXABQgNABgJgEQgJgHABgUQABgYgBgJQAEgeAggVIgWgDQgNgCgHgEQgNgRgCgGQgIgPAEgRIAfgdQAUgSANgJQA0gYAZgNQAHAAAIgFQAYgCAMAAQAFgXAEgkIAGg9QAGgwABgZIACgKQAAgGABgNQACgNgBgEQAHgSABgnIABgBIABgCQAEgwAMhMIAUh+IAMhGIALhEQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAAAAAAAIgBgCQADgHACgNIAEgWQgKgOgTgOIghgYQglglgOgvQgBgKACgQIACgZQAfhWBqgQQAPACAQAIIAJgOQAGgIACgGQAFgDAKgLIAQgOIARgJIAQgLQAIgHAHgDIAIgCQAFgBACgCQBNABAOAvQABANACAEQAEgCAAgFIAZgTQARgKAPgBQAcAAANAMQAOALADAbQAIgGAIgLIANgTQAIgDANgLQASgIARgBQAVgCAOAKIAKANQALAggYAeQggAfgKARQAvABARAKQALAOAFAKQAIAOAAAPIgLATQgIAKgJAEIAWAJQAQAGAKAWQAGAMAIAcQgCALgLAKQgNANgDAFQgLAFgPABIACAaQABAPgFAKIABADQAAABABAAQAAABAAAAQAAAAAAABQAAAAAAABQgGADgMACIgSADQgQgGgGgEIgDAXIgDAXQgBATgFAlQgFAmgBASIgIBQQAAABAAABQAAAAgBABQAAAAAAAAQgBABAAgBQACAJgCAPIgEAYIAAATQAAALgDAHIgDApQgBARgGAhIgNB0IAAASQgBAIgEAQIgBAfIgEAqQgCAZAAASIgDAHQACAFgCAIQgDAJAAAEQACAFAMgDIATADQALABAFAEIADAFIADAGQgHAYgNAWQAhgCAOAKQADAHAEACQAKAggVAtIgbAYQgQAOgOAIIAGAJIAFAJQAFAYgRAfIgPAXQgJAMgVAQQgPAJgbABQgZABgUgHQgLAMgTALQgLAGgZALIgIABIgKgCgAjLKKQgBACgDACQgDADAAACQgDAgAHAXQAJAbATAIIAPgBIAHgEIAIgEIATgaQALgQAEgNQAFgEAHAEQgBABAAAAQAAABABAAQAAABAAAAQABABAAAAIADADQgCAIAFALIAIARQAJAIANAEQAQAEAKgHQAWgiAFgMQAAgMAGgHIABgBQAFgBAFAEIAEAJIgCACQAAABgBAAQAAAAAAABQAAAAAAAAQAAABAAAAIAAASQAEAMALALQAKALAHADQAPAIAQgDQALgCASgKQATgKAIgIIAAgKIAKgFQAGgLACgMQACgOgGgJIAHgIQAFgFAFACQABANgDATQgDAUgGALQAPAHAXAAQAVgBAPgHQAjgdAQgoQACgUgFgKQgCgDgLgGQgKgEgBgGQAAgEAEgDIAKgFIADACQABABAAAAQABAAAAAAQABABAAAAQABAAAAgBQAKgDAJgHIAPgOQAYgTAGgXIACgVQAAgMgEgHQgGgHgPgBQgMgBgNADQgIAIgGACIgIgBQgFgBgBgDIAAgMQATgGAJgSQAMgVgEgIQgRgHgUACQgIAHgFACQgFgCgEgFIgIgIIgzgCQgfgCgVABQgdgHg4ACQgtgIgjAEIiPgVIgUgEQgMgCgHADQgGgGgOgBIgagBQgyASghATQgpAYgYAfQABADgBACIgCADQAFArBBgJQAFgHAHAEQAIAEgBAJQgDADgHACIgMAEQgLAIgUARQgIANgCATQgDATAEASQAJAFAFAAQAGABAUgHQAPgFAIAGQABAFgEAGQgFAHAAAEQgEABAAAEIgGAVQgDAOABAMIADAOQAJALAKAEQAMAHARgCQAXgGAVgTQAWgYAMgLQgBgDACgEIABgGIAGgCIAFgBQAHADADAOgADhGQQAAAAAAAAQAAABAAAAQABAAAAAAQAAAAABAAQAAAAAAgBQABAAAAgBQAAAAgBAAQAAgBgBAAIgBACgAC5F/QAkABAQgIQAFgRACgbIACgvIACgPQAEgwAIhFIAOhzQAOiHAHhlQACgHACgPQACgQACgHQAAgVAFgvQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAgBQgCgDABgCQAGgNgFgJQgIgBgEgDIgLgBIgKAAIhPgOQgygIgbgJQiSgThSgCQgPACgGAFIgFAhQgEAVgBAOQgEASgFAkQgCASgIAkIgHA0QgEAfgFASQgGAcAAAHQgDANgCAZIgFAmQgYC5gJB5QgEANgBAaIAFABQABAAABABQAAAAABAAQAAABAAAAQABABAAABQAVAFAuAFIAwAJQAdAGAUABIAYAAQAPgBAJABIAuAEIAtABQAaABASADIAIAAIAyACgAFJldQAFAFACAAQAIAEAKgBQAJgCAHgEIAEgVQgCgMgCgEQgEgIgHgDQABAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAgBIgCgCQABgLALgCQAEAAAJAHQAFABAGgDQAGgDAEAAQAMgSAIgHQgCgQgMgdQgQgUgdgCQgDACgEgBIgIgBQgEgGAAgEQACgGAFgCQAPABALgLQALgLAAgQQgEgGACgGQgKgZgggFQgEABgNgBQgMAAgFACQgJAIgEgBQgFgBgDgOQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBQADAAACgCIAFgDQADgFAJgKQAIgJADgGIALgIQAFgFACgGIACgBIADAAIAIgRQAEgKABgJIgCgNQgCgHgEgDQgCgDgHgCIgKgDQgJACgFgBQgQAIgMACQgYARgSAiQgBABAAAAQAAAAAAABQAAAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgGAIgFABQgJgDgGgJQAEgEABgDQABgXgMgSIgLgFIgYgCQgMAAgJADQgJAGgWAXQgBADgDAGQABAHgBADQgBAEgEAEQgJACgIgEQABgDgCgDQgCgEABgDQAAAAAAAAQAAAAABAAQAAAAAAgBQABAAABAAQAAAAABAAQAAAAAAAAQABgBAAAAQAAgBAAAAQADgJgCgMIgFgVQgOgVgmgGIgZAAIgLADIgfAVQgVANgLALQgSASgCARQACADAGAEQAGAEACACQgBAJgHAEIgIAAIgDgGQgDgDAAgCQgKAAgCgCQgDgDgCgFIgMgEIgNgCQgMgBgRAHQgWAIgGABQghAUgPAUQgVAagCAmQABAeAYApIAgAfQAIAEAQANQAOALALAEIAJgDQAYAHA6ACQA8ACAYAEIAFAAQAIACASACQASABAHACIALAAIBuAYQAPAAAbAEIAsAGQAAgEACgCQAHgDAFAEQAGAEACAJIAAAAQADAAADADg");
	this.shape_156.setTransform(90.9,119.5);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#EAE6E4").s().p("AieCiQgHgYADgfQAAgDADgCQADgCABgCQgDgOgHgEIgFACIgGACIgBAGQgCAEABADQgMALgWAYQgVATgXAGQgRABgMgGQgKgFgJgLIgDgNQgBgNADgNIAGgVQAAgEAEgBQAAgFAFgGQAEgGgBgFQgIgGgPAFQgUAGgGAAQgFAAgJgFQgEgSADgUQACgQAIgNQAUgSALgHIAMgEQAHgCADgEQABgJgIgDQgHgFgFAIQhBAJgFgrIACgDQABgCgBgEQAYgeApgYQAhgTAygSIAaABQAOABAGAFQAHgCAMACIAUAEICOAVQAigEAvAHQA4gCAdAIQAVgBAfACIAzABIAIAJQAEAFAFACQAFgDAIgGQAUgDARAIQAEAIgMAVQgJARgTAHIAAALQABAEAFABIAIABQAGgCAIgIQANgDAMABQAPAAAGAIQAEAHAAAMIgCAVQgGAXgYARIgPAOQgJAHgKADQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAgBgBAAIgDgCIgKAFQgEADAAAEQABAFAKAFQALAFACAEQAFAKgCAUQgQAogjAcQgPAIgVAAQgXABgPgHQAGgMADgTQADgTgBgNQgFgCgFAFIgHAIQAGAJgCAOQgCAMgGALIgKAEIAAALQgIAIgTAKQgSAKgLACQgQADgPgIQgHgDgKgLQgLgLgEgNIAAgRQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAIACgCIgEgJQgHgEgFABIgBAAQgGAIAAAMQgFAMgWAiQgIAHgQgEQgNgEgJgIIgIgRQgFgLACgIIgDgDQAAAAgBgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQgHgEgFAEQgEANgLAPIgTAbIgIAEIgHAEIgPABQgTgIgJgbg");
	this.shape_157.setTransform(86.1,174.7);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#EAE6E4").s().p("AD2DIQgCAAgEgFQgEgEgDABQgBgJgHgEQgFgEgHADQgCACAAAEIgsgGQgbgEgPAAIhugYIgKAAQgGgCgSgBQgSgCgIgCIgFAAQgYgEg+gCQg6gCgXgHIgKADQgKgEgPgLQgPgNgJgEIgfgfQgZgpgBgcQACgmAVgaQAQgUAggUQAGgBAWgIQARgHAMABIAOACIALAEQACAFADADQACACAKAAQABACACADIAEAGIAHAAQAHgEACgJQgDgCgGgEQgGgEgCgDQACgRASgSQALgLAVgNIAhgVIALgDIAZAAQAkAGAOAVIAFAVQADAMgEAJQAAAAAAABQAAAAAAAAQAAABgBAAQAAAAgBAAQgBAAAAAAQgBAAAAAAQAAABgBAAQAAAAAAAAQgBADACAEQADADgCADQAIAEAJgCQAEgEABgEQABgDgBgHQADgGABgDQAXgXAIgGQAKgDAMAAIAXACIALAFQAMASgBAXQgBADgEAEQAGAJAJADQAFgBAGgIQAAgBABAAQAAgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQASgiAZgRQALgCARgIQAEABAJgCIALADQAGACADADQADADACAHIADANQgCAJgEAKIgIARIgCAAIgCABQgDAGgFAFIgKAIQgEAGgIAJQgJAKgDAFIgFADQgCACgCAAQAAABgBAAQAAABAAABQAAAAAAAAQgBABAAAAQADAOAGABQADABAJgIQAGgCALAAQANABAEgBQAgAFALAZQgDAGAFAGQgBAOgLALQgLALgOgBQgFACgDAGQAAAEAEAGIAIABQAEABADgCQAeACAQAUQALAdACAQQgIAHgMASQgEAAgGADQgGADgFgBQgJgHgDAAQgLACgCALIACACQABAAAAAAQAAABAAAAQAAAAgBAAQAAABgBAAQAIADADAIQACAEACAMIgEAVQgGAEgKACIgEAAQgHAAgHgDg");
	this.shape_158.setTransform(99.9,64.9);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#047391").s().p("ACQGHQgwgCgKABQgRgEgbAAIgrgBIgwgEQgIgBgPABIgYAAQgVgCgcgFIgxgKQgtgEgWgGQAAgBAAAAQAAgBAAAAQgBgBgBAAQAAAAgBAAIgFgBQAAgbAFgMQAIh5AZi7IAEgkQADgaACgMQABgHAGgdQAEgSAEgfIAHg0QAIgjACgSQAFgkAFgTQABgNADgVIAGgiQAFgEAPgCQBTABCSAUQAbAJAxAIIBQANIAKAAIAKABQAFAEAIABQAFAIgHAOQAAACABADQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQgFAwgBAVQgCAGgCAQQgBAPgDAIQgGBkgPCIIgNByQgJBFgDAxIgDAOIgCAvQgBAbgFASQgOAGgcAAIgLAAg");
	this.shape_159.setTransform(94.9,118.6);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFFFFF").s().p("AAAAAIAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQgBABAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAg");
	this.shape_160.setTransform(113.6,159.5);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#000000").s().p("AgOAUQgEgEAAgFQAAgRAbABIAAgBQAAgLgJAAQgHAAgFAEIgCgGQAHgFAHAAQASAAAAAUIABAcIgIAAIgBgGQgFAHgIAAQgHAAgEgFgAgJAKQAAAIAIAAQAIAAACgIIAAgDIAAgHIgDAAQgPAAAAAKg");
	this.shape_161.setTransform(-54.6,-61.3);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#000000").s().p("AgPAcQgGgGAAgLQAAgLAHgGQAGgHAIAAQAKAAADAHIAAgcIAJAAIAABEIgHAAIgBgIQgFAJgKAAQgIAAgGgHgAgJgBQgDADAAAIQAAASAMAAQAKAAADgKIAAgEIAAgIIAAgEQgCgIgLAAQgEAAgFAFg");
	this.shape_162.setTransform(-59.8,-62.3);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#000000").s().p("AgOAUQgDgDgBgGQABgRAaABIAAgBQAAgLgJAAQgHAAgFAEIgDgGQAHgFAIAAQASAAAAAUIAAAcIgIAAIAAgGIgBAAQgEAHgIAAQgHAAgEgFgAgJAKQAAAIAIAAQAHAAADgIIAAgDIAAgHIgDAAQgPAAAAAKg");
	this.shape_163.setTransform(-65,-61.3);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#000000").s().p("AALAYIAAgaQAAgOgLAAQgHAAgCAJIgBAEIAAAbIgJAAIAAguIAIAAIAAAIQAFgJAJAAQAHAAAEAEQAGAFAAALIAAAbg");
	this.shape_164.setTransform(-70,-61.3);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#000000").s().p("AgNASQgHgHABgLQgBgJAHgHQAGgIAIAAQALAAAEAIQAEAHABAIIAAACIggAAQAAARAOAAQAIAAAFgDIACAHQgJADgHAAQgJAAgGgHgAgIgMQgDADAAAGIAXAAQAAgFgCgEQgDgFgHAAQgEAAgEAFg");
	this.shape_165.setTransform(-75.2,-61.3);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#000000").s().p("AgRAeIACgGQAHAEAHAAQAOAAAAgRIAAgFQgFAHgJAAQgIABgGgHQgGgHAAgIQAAgMAHgGQAGgIAIAAQAKABAEAIIAAgHIAIAAIAAAnQAAAPgHAHQgHAFgJABQgJAAgHgFgAgIgWQgEAGAAAIQAAAHADADQAEAFAFAAQAJAAADgHIABgFIAAgJIgBgDQgCgJgKAAQgEAAgEAEg");
	this.shape_166.setTransform(-80.6,-60.3);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#000000").s().p("AgDAiIAAguIAHAAIAAAugAAAgVQgEAAAAgGQAAgGAEAAQAFAAAAAGQAAAGgFAAg");
	this.shape_167.setTransform(-84.4,-62.3);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#000000").s().p("AALAYIgLgUIgKAUIgKAAIARgYIgQgWIAJAAIAKASIALgSIAKAAIgQAWIARAYg");
	this.shape_168.setTransform(-87.9,-61.3);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#000000").s().p("AgUAZQgJgKAAgPQAAgNAJgLQAJgJALAAQAOAAAIAJQAIAKAAAOQAAAPgJAKQgIAJgNAAQgMAAgIgJgAgOgRQgGAHAAAKQAAALAGAIQAGAIAIAAQAKAAAFgIQAGgIAAgLQAAgKgGgHQgFgJgKAAQgJAAgFAJg");
	this.shape_169.setTransform(-93.6,-62.2);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#000000").s().p("AgOAUQgEgEABgFQAAgQAaAAIAAgBQAAgLgJAAQgGAAgHADIgBgFQAHgFAHAAQASAAAAAUIABAcIgIAAIgBgHIAAAAQgFAIgIAAQgHAAgEgFgAgJAKQAAAIAIAAQAHAAADgIIABgDIAAgHIgEAAQgPAAAAAKg");
	this.shape_170.setTransform(-66.2,-73.2);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#000000").s().p("AgTADIAAgaIAJAAIAAAYQAAAPAKABQAHgBADgHIABgFIAAgbIAIAAIABAuIgHAAIgBgIIAAAAQgFAJgJAAQgRAAAAgVg");
	this.shape_171.setTransform(-71.2,-73.1);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#000000").s().p("AgRAeIADgGQAFADAIABQAOAAAAgRIAAgGIAAAAQgFAJgJgBQgIAAgGgGQgGgHAAgIQAAgMAHgGQAGgIAIABQAKAAADAIIABAAIAAgHIAIAAIAAAmQAAARgIAGQgFAGgKAAQgKgBgGgEgAgIgWQgEAFAAAJQAAAPAMAAQAKAAACgHIABgFIAAgJIAAgDQgEgJgJAAQgEAAgEAEg");
	this.shape_172.setTransform(-76.8,-72.2);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#000000").s().p("AATAhIgIgVIgWAAIgGAVIgJAAIAWhBIAJAAIAXBBgAgIAFIASAAIgKgdIAAAAg");
	this.shape_173.setTransform(-82.4,-74.1);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#000000").s().p("AhaL/QgWgGgMgBIgXAAQgjgCg6gKQhAgMgbgDQgEgCgSgEQgOgEgGgFQgHAAAAgCIgGABQgDABgCgBQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAgBAAIgCgBIAHgwQAEgZgEgTQACgCAAgFIACgHQgBiggCg2IADgIIgCgmIACgGQgBgZAAg3QAAg6gCgdQADgGAAgIIAAgQIADgUQABgLgFgGIACgrQAAgagFgPQAEgVgCg4IAAhUQABgFgBgOQAAgMACgHQgBgMgCgEIADgvQADgdgFgTQAFgHADgQQAFgSADgHQgCgDABgFQADgHABgLIADgTQARgRAJgUIAOgLQAIgHACgIIATgOQAMgIAMgDIAHgIIAGgIIAfgJQATgFAJgIIAJAAQAHgRgFgPIAFgtQACgdgDgOQgCgKAFgCQgEgBgCgFIgCgJQALgCgCgNQgIgHgNAAQgHgDgBgJQAAgMgBgGQAFgEARgJQAOgJgHgKQABgKAKgFQAFgDANgFQAQAFAZgJQATABAigCQAjgCAPAAQABAAABgBQABAAAAAAQAAgBABABQAAAAAAAAIApAEQAZABASgCQAGACANAAQAKAAAEACQAHgEAQADQASACAGgDIAVAMQAKAWgDArQAAAGgCALQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAIgBAGQgBAEACADQABADgDADIgEAGQABAQgCAgQgBAeAFASIgBAIIAAAIQAEACAHAAIAMABIAGADIAFADQADABAFgBIAHABQAEABAJAIQAIAGAHAAIAOAPQANAEAPANIAZATQABAGAFAIIAHAMQAEADAEAJQAFAJAFADIAAAFIAAAEQAFAJAFAQIAIAcIAEAKIAEAKQABAIAAAQIADAcQADASAAALQgBA2AGAvQgCALAAAYQACAbgCAKQgCANABAeQABAZgDANQgCAzABBxQACBpgFA0QAAADADAGQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAgBAAIgCADIgKgBQAAgdAAhjQABhUgEgvQACgSABgfIABgsIACg0QADhJgEgdQgWgGgXAAQgNACglABQghAAgRAFQgCgBgIAAQgGgBgDgBQglAGg/gBQhOgBgYACQgTABgoABIhAABQg0ADgVAAQgpAAgagFQgMABgUgCQABALgCAVQgCAXAAAKIAFCNIgKAAIgGhRIgBg4QABgkgBgPQAAgEgDgGIgEgKQAEgHANgJQAEgBADADQADACADgBQAGgCARAEQAEgBAMAAQAlAGA4gCIBggEQAjAABCgDIBMAAQAsAAAhgDQAJgDAQABIAaAAIAqgFQAYgDASAEIANgEQAIgBACgDQACADAJACQADgZgEgrIgGhDIgKghQgGgVgFgLQgHgKgKgTIgQgcQgQgPgDgFQgJgCgOgMQgOgKgKgDQgBgDgEgDQgEgDgBgCQgHgBgLgDQgLgEgHgBQgBABAAAAQgBAAAAABQAAAAgBABQAAAAAAABIgTAEQgqAThFAGQgiAChIgFIhHgGQgsgEgagBIgFAFQgGACgBACIgIABQgEACgEgBQgsAVgTAFQgQAMgWAYIgIAAQgjAhgMBIQgKAyACBXIADALIgCAnQgBAUgCAQQACAIgBAPQgBAOADAHIgCA1QAAAHADAPIgBBWQgBAzgDAkQACAHAAAOQAAAOACAGQgDAEAAALQgBAvAEBgQgFAcADAyQAEA5gCAVQgBASAAAiIgDATQgBAHADAPIgDAXQgCANACAJIASALQAGAAAKACQAMADAGAAQAGAEARAEQATACAsAJQAoAIAYAAIBUAIQAzAGAigEQAPACARAAIAAAMIgMAAIg+ACQgbAAgTgCgAhnnuIAcABIBmAJIA0gEQAfgDATgDIABgEQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAAAAAQAKACAIgDIAPgGQgBgGAAgGIACgOQgDgPAAgbQAAgagDgMQADgEAAgJQAAgKACgFQgEgBgGACIgKADQgLgFgTABQgUACgKAAIg2gEQgigDgVgBQgNACg3gBQgygBgXAGQAAASgDAqQgCAnAAASIAKATQAUAHAMgCQAJAEAQABgAAfqRIA2ACQAHgCAJAAQAKgBAGgBQAHACAJAAQAIAAAGgDIAJACQAEABAEgBIABgEIABgDIAAgTQAAgJAGgEIgCggQgDAAgCgDIgGgFIgDgBIgGgDIgbgBIgKAAIgxgBQhsgLhsAPIgFAGQgEADAAAFQADADACAFIABAKQgEAAgCACIgDAEQgCACgDABIgCAAIgJABQgHABgCADIAOABQAJABAEAFIACAGIgEAKIAAAKIBZABIA4gCIANAAQAWAAAPAEg");
	this.shape_174.setTransform(-81.5,-78.4);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#DDBE6F").s().p("AgDJ1QgiADgzgFIhUgJQgYAAgogIQgsgJgTgBQgRgEgGgFQgHAAgLgCQgLgDgGAAIgSgKQgBgJACgOIADgXQgDgOAAgIIAEgSQgBgjACgRQABgVgDg6QgDgxAFgdQgEhfAAgwQABgKADgEQgCgGAAgOQAAgPgDgHQAEgkABgwIABhXQgDgOAAgIIACg3QgDgHABgOQABgOgDgIQADgQABgUIACgoIgDgKQgChYAJgyQAMhHAkgiIAIAAQAWgXAQgMQATgFAsgVQADAAAFgBIAIgBQABgCAFgDIAGgEQAaAAAsAEIBHAHQBHAFAigDQBGgGAqgTIATgEQAAAAAAgBQAAAAABgBQAAAAABAAQAAgBABAAQAHAAALAEQALAEAGAAQABADAFADQAEADABADQAKACAOALQAOALAJADQADAFAQAOIAQAdQAKATAGAJQAGAMAGAUIAKAiIAGBDQAEAqgDAZQgJgBgCgEQgCADgIACIgNADQgSgDgZADIgpAFIgagBQgQAAgJADQghADgsAAIhMAAQhCADgjAAIhgADQg5ACglgFQgLgBgEACQgRgEgGACQgDAAgDgCQgDgCgEABQgNAIgEAHIADALQADAGAAADQACAQgBAjIABA5IAFBTQABANgCAZQgBAbAAAMQAAAFADAMQABAJAAAZQgBAVACAMIAEAwIgBAHQAAAFADABQgDACAAAFQgBAFgCACIAEBBIgCAJQgDAFAAADIABAKQACAGgBADIgBAQQABAIADAIQgBAJgIAOIACADQAAAAAAABQAAAAABABQAAAAAAABQgBAAAAABQAMADAbADIAmAGQAXADAQgDQAeAHAwgBIBOAAQASABAjgCIB8ABQBKABAxgEQAMgEAkgCQAfgDAPgGQABAcAAB3QAAAJgDAZQgCAVABANQACAfgDAKQggAJgJAGQgLgBgOAFIgXAJQgFgBgJACIgPAEQgUAEgwgCQgtgBgUAFIgtACIgtACQgRAAgOgBg");
	this.shape_175.setTransform(-81.4,-66);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#000000").s().p("AAABmIgDgqQgCgLABgVQAAgZgBgHQgDgMAAgGQAAgOABgaQACgZgBgOIAJAAIAEBwQgDAIABAOIABAXIADAYQABAPgDAHg");
	this.shape_176.setTransform(-110.1,-62.8);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#000000").s().p("AgRDyIAqgDIAtgCQAVgEAsABQAxABATgDIAQgFQAIgCAFABIAYgJQAOgEALAAQAJgFAfgJQAEgLgDgfQgBgNADgUQADgaAAgIQAAh2gCgcQgPAGgeADQgkACgNAEQgxAEhKgBIh6gBQgkACgTgBIhOAAQgvACgegHQgQACgYgDIgmgGQgbgDgLgDQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBgBAAIgBgDQAHgOABgJQgDgHAAgJIABgQQAAgDgBgGIgBgKQAAgDACgFIACgJIgDhBQACgCAAgFQAAgFADgCQgDgBAAgFIABgHIAAgGIAIAAQAEABAAAFIgBAIIAAAmQAAAZADAPQgFAPACAZIABAqQAGADAEAGQAIADAYABQAWABAJAFQAsAFBBAAIBtAAQBtABAigBIAtgBIArgBQANAAA0gJIAggDQARgDALgFQACgLgBggQgBgdADgOIAKABIACAJQACAwAABBIgCByQAAA0gBAKQgCAUACAoIAEAMQgEAFgCAIIgMgBQAAAAgBAAQAAAAAAAAQgBAAAAgBQABAAAAgBIAAgDIgPAEQgJACgIAAIhVAYQgpAAhJAEQhLADgjAAg");
	this.shape_177.setTransform(-76.6,-27.1);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#666666").s().p("AAoAsQgUgGgeACIg4ABIhZgBIAAgJQAAgEAEgGIgCgHQgEgEgJgBIgOgCQACgCAHgBIAJgCIACAAQADAAACgCIADgCQACgDAEABIgBgKQgCgGgDgDQAAgEAEgEIAFgFQBsgPBsAKIAxABIAKABIAbABIAGADIADABIAGAEQACADADABIACAdQgGAFAAAJIAAASIgBAEIgBADQgEACgEgBIgJgDQgGADgIABQgJAAgHgDQgGACgKAAQgJAAgHADIg2gCg");
	this.shape_178.setTransform(-82.4,-148.7);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#3F3F3F").s().p("AhIBHIgcgBQgQgBgKgEQgLACgUgHIgKgTQgBgSADgkQADgrAAgSQAXgFAxAAQA4ABANgCQAUABAjADIA2AEQAKABAUgDQATAAALAEIAKgDQAGgCAEABQgCAGAAAKQAAAIgDAEQADAMAAAaQgBAZAEAPIgCAOQgBAGACAHIgPAFQgJADgJgCQAAAAgBAAQAAAAgBAAQAAAAAAABQAAAAAAABIgCADQgSADgfADIg0AEIhmgJg");
	this.shape_179.setTransform(-81.8,-135.1);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#EFE3C7").s().p("AgdE2IhtABQhBAAgsgFQgJgFgWgBQgYgCgIgCQgEgGgGgDIgBgqQgCgZAFgQQgDgPAAgYIAAgmIABgIQAAgFgEgCQAEgGgCgQIgDgYIgBgWQgBgPADgHIgJj/QAAgLACgWQACgVgBgMQAUADAMgCQAaAGApAAQAVAAA0gDIBAgCQAoAAAVgCQAYgCBMACQBAABAlgHQACACAHAAQAHAAACABQARgEAhgBQAlAAANgDQAXAAAXAGQADAdgCBKIgCA0IgBAuQgBAegDASQAEAvAABSQgBBkABAcQgDAPABAdQABAggCALQgLAFgRACIggAEQg0AIgNABIgrABIgtAAIg1ABIhagBg");
	this.shape_180.setTransform(-76.8,-63.8);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#000000").s().p("AgbAnIAEgMQAKAGALAAQAPAAAAgNQAAgJgOgHQgYgGABgRQgBgKAJgIQAIgHALAAQANAAAJAFIgEALQgJgEgJAAQgMgBAAAMQAAAGAEADQADADAHAEQAXAGAAASQAAALgJAIQgJAHgNAAQgNAAgLgGg");
	this.shape_181.setTransform(-27.9,78.9);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#000000").s().p("AgbAlQgGgHAAgKQAAgQANgGQAOgJAXAAIAAgBQAAgVgSABQgMAAgKAGIgEgLQAMgHAPAAQAhAAAAAkIAAAeIABAVIgOAAIgBgLIgBAAQgJANgQAAQgMAAgIgIgAgRASQAAAIAEADQAEAEAGAAQAPAAAFgOIABgGIAAgNIgEAAQgfAAAAASg");
	this.shape_182.setTransform(-36,78.9);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#000000").s().p("AgbAnIAEgMQAKAGALAAQAPAAAAgNQAAgJgOgHQgXgGgBgRQABgKAHgIQAJgHAMAAQAMAAAJAFIgEALQgJgEgJAAQgEAAgFADQgDAEAAAEQAAAGAEADQADADAHAEQAXAGAAASQAAALgJAIQgIAHgNAAQgOAAgLgGg");
	this.shape_183.setTransform(-43.7,78.9);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#000000").s().p("AgbAlQgGgHAAgKQAAgQANgGQAOgJAXAAIAAgBQAAgVgSABQgMAAgKAGIgEgLQAMgHAPAAQAhAAAAAkIAAAeIABAVIgOAAIgBgLIgBAAQgJANgQAAQgMAAgIgIgAgRASQAAAPAOAAQAPAAAFgOIABgGIAAgNIgEAAQgfAAAAASg");
	this.shape_184.setTransform(-51.8,78.9);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#000000").s().p("AgfAuQgRgSAAgcQAAgaARgQQASgSAcAAQAUAAALAFIgEANQgMgGgPAAQgUAAgNAOQgOANAAAVQAAAWANAOQANANATgBQAPABAGgEIAAgkIgYAAIAAgLIAnAAIAAA5QgQAGgVABQgaAAgRgQg");
	this.shape_185.setTransform(-62.1,77.2);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#000000").s().p("AgNANQAKgXARgEQgFAFgGAPQgDAJgHAAIgGgCg");
	this.shape_186.setTransform(-97.6,126.4);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#000000").s().p("AEnH+IABgHQAEgIgIgUQgIgUADgHQANADACASQABAKgBAVQA/AGB/gGQAZguAEhgQAChFgIhTQgIACgPgDQgQgDgHgFQAIgEAOABIAYADQgFmeATkaQgjAFg9gCQhHgCggACQgEACgDAIQgEAIgDACQgDgBAAgMQABgLgHABQgSAEghgBIg3AAQgGAEgEAOQgEAPgEAFQgEgHACgLQADgQgBgEQgwAAhPgDQgEADgDAPQgCAMgIACIAAgdIhxAAQgDAEgDASQgBAPgIADQACgIgCgLQgDgMAAgGQglgChdAAQhYgBgvgDIAFAVQADANgFAHIgIgSQgEgLABgMIg4ACQgkABgVAGQgLA6AAAxQAIAEASAFQAQAGAEAKQgFAAgSgHQgNgGgNACQgDAaACAnIABA+IAYAGQAPADAEAIQgKABgOgCQgOgCgIAAQAAAYgEAzQgEAuACAdQAHACAWgHQAPgEACAMQgGADgRAAQgRAAgGADQgEAdgBAkIgBA5QACAEAQgBQAOgCAAAIQgCAEgNABQgNAAgBAGQgCAQgBAoIgDA+IAQgDQAJgBAEAEQgDAGgLADQgOADgEADIgGAuQgEAcgBAVQADAAAOgCQAIgCAEAHQgFADgLADIgQAFQgIBXAIA5QA3AFBoACIAAAJQhcgBhRADQgIhTANiAQARimABgpQAHkpAQkLQAAgHAGgBQC8AEFDgBQGCgCCFACQAHAggFAyIgLBVQgCAgAAA7IgBBdQgCA+gBB8QgBBYALCtQADCTgkBPIgQAAQhTAAhtgEg");
	this.shape_187.setTransform(-46.8,83.8);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#000000").s().p("AAAAEIgOgTQALABAGAMQAJAPADACIgBABQgHAAgHgMg");
	this.shape_188.setTransform(-92.3,37.4);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#000000").s().p("AA0DiIiFgDQg/gBgvgKQAbi9AFiWQAAgQAFgjQAGgiAAgRIAGAAQgFCZgDBAQgIB3gQBeQB4AGD2APIgBAIQg1gDhWgBg");
	this.shape_189.setTransform(-73.2,97.9);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#000000").s().p("Ag0ChIAAgHQAAgQgDglQgDgjABgTQAAgNAMhSQAIg8gGgkQApgIA7gIIABAJQgyAGgiANQgNBqgHC7g");
	this.shape_190.setTransform(-82.8,58.7);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#000000").s().p("AAAgRQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABIAEACQgCAGgCAMQgDAMgGACQgBgYAHgLg");
	this.shape_191.setTransform(-83.9,126.2);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#000000").s().p("AADAVQjKgNiFgCIAAgHICxABIgGgVQgEgPAKgDQAGABgBARQAAASADADQEUAKDLAYIAAAHQg3gDkSgRg");
	this.shape_192.setTransform(-50.5,130.7);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#C2CECC").s().p("AEvHyQABgUgBgKQgCgSgMgEQgEAIAIAUQAIATgEAIQjLgXkVgLQgDgEABgTQAAgQgGgCQgJAEAEAPIAFAWIiwgCQhngCg4gFQgHg5AHhXIARgFQAKgDAFgEQgEgGgIABQgOADgDgBQABgVAEgbIAHgvQADgCAOgEQAMgDACgFQgDgFgKACIgQADIADg/QABgoADgPQAAgHANAAQAOAAABgFQAAgHgOABQgQABgCgEIABg5QABgkAEgdQAGgCASAAQARAAAFgDQgCgNgPAFQgWAGgHgBQgCgeAEguQAFgygBgYQAJgBANACQAPADAJgBQgEgIgPgEIgYgGIgBg+QgCgnADgaQANgBAOAFQARAHAFABQgEgKgQgGQgSgGgIgEQAAgwAMg7QAVgFAjgBIA4gCQgBAMAEAKIAIASQAFgGgDgNIgFgVQAvADBYAAQBeAAAkACQAAAGADANQACAKgBAJQAHgDACgPQACgSADgEIBxAAIAAAcQAIgBACgNQAEgOADgDQBQADAvAAQABAEgDAPQgCAMAEAGQAEgEAEgPQAEgOAGgEIA3AAQAhAAASgDQAIgBgBAKQgBAMADACQAEgCADgJQADgIAFgBQAfgCBHACQA9ABAkgEQgUEZAFGfIgYgDQgOgBgIAEQAHAFAQADQAPADAIgDQAIBUgCBEQgDBggaAuQg/ADgwAAQgvAAgggDgACOHMQADAPAIAGQgCgGAEgWQACgQgKgCQgHAIACARgAGFHEQAMAXARADIgLgTQgGgIgHAAIgFABgAgjGqIABAbQADAOAKADQgDgEABgXQAAgRgLAAIgBAAgAHZHQQAAgPgSgFQABAOARAGgAlyGTQgHALABAbQAIgDADgLQABgPACgGIgDgCIgEgBIgBAAgAoIG2QAKAFAIgNQAGgQAFgFQgTAEgKAZgAhDmsQiBAChoANQg9AIgoAIQAFAlgHA7QgMBUgBAOQgBASADAjQADAlABAQIAAAHQgBARgGAjQgEAigBAPQgFCYgbC8QAwAKA+ACICHACQBXABA1ADIAeACQCrAOA7AEQCBAIBigCQAThBgChwQgCiaACghIAFhAQAFh4gKhsQgBgwgCgYQgDgpgMgXQgGgJgHgIIh9gGQilgJh3AAIg+ABgAHcE6QAAAEADAEIASgCQALgBACgFQgFgEgLAAQgNAAgFAEgAH2BZQABgJgLAAQgOABgFgBQACAOAbgFgAHigzQgSABgCAIQAHADAMABQANABAFgCQABgMgPAAIgDAAgAHpigQgOABgCAIIAVAEQANACAAgJQgFgGgLAAIgCAAgAHpkRQgMADgEAGIATABQAOgBABgJQgDgCgFAAQgEAAgGACgAHqloIgXAEQACAIAQgBIAWgBQAAgKgPAAIgCAAgAHYnKQgPANACAOQAEgKARgLQASgMAEgKQgSAGgMAKgAnGnLQAKAMAHgBQgDgDgJgQQgHgMgMgBIAOAVgAjmnSQAEAQAMACQgHgGACgWQACgSgMgBQgEAOADAPg");
	this.shape_193.setTransform(-46.9,83.9);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#000000").s().p("AgGAFQgDgNAFgOQAJABgBASQgCAUAGAGQgKgCgEgQg");
	this.shape_194.setTransform(-69.3,36.6);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#000000").s().p("AhzADQBogLB/gDIAAAIIgYABQghAChEAEQhHADgiAFg");
	this.shape_195.setTransform(-65.4,42.2);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#000000").s().p("AAGDQQg4gDitgOIgfgCIAAgJQEaARDCAGQALgzAGhpQACgggCg1QgDg9AAgZQABgPAGgeQAFgeAAgPIAHABIgEBCQgCAgACCZQACBwgTBAIgpABQhTAAhogHg");
	this.shape_196.setTransform(-28.5,102);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#000000").s().p("AA+AGIh9gDQgSAAglgDIg2AAIAAgHQCJgDDQAKIAAAIQgYgBhXgBg");
	this.shape_197.setTransform(-36.4,41.8);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#000000").s().p("AgEAFIgCgZQALgBAAARQgBAWADADQgIgCgDgOg");
	this.shape_198.setTransform(-49.9,128.8);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#000000").s().p("AgFABQgCgOAHgJQAJACgDAQQgEAUACAHQgGgHgDgPg");
	this.shape_199.setTransform(-32,129.8);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#000000").s().p("AgNgLQAJgEAHALIALARQgPgDgMgVg");
	this.shape_200.setTransform(-6.5,130.4);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#000000").s().p("AhDgDIAAgJIB7AHQAHAFAGAKIgIADQgzgNhNgDg");
	this.shape_201.setTransform(-12.1,43.1);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#DAEAE7").s().p("AhDF8Qj3gPh4gGQAQhdAHh6QAEg/AFiXQAGi9AOhqQAkgNAygHQAigEBGgDQBHgEAhgEIAYgCIA2ACQAjADASAAIB/ADQBXABAYABQBQAEAzAOQAUCqADC2IAAAIQAAAOgFAdQgGAegBAPQAAAZADA9QACA3gCAgQgGBpgLAzQjCgGkagRg");
	this.shape_202.setTransform(-47.2,82);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#000000").s().p("AAHC1IAAgJQgEizgRirIAHgCQAKAXADAoQACAYACAwQAJBrgFB3g");
	this.shape_203.setTransform(-4.3,62.3);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#000000").s().p("AgHgEQAKgKASgGQgEAKgRAKQgQALgEAKQgCgNAPgMg");
	this.shape_204.setTransform(1.1,38.5);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#000000").s().p("AgHgJQAPAGAAAMQgPgFAAgNg");
	this.shape_205.setTransform(-0.4,129.4);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#000000").s().p("AABAFQgLgBgHgCQADgHAQAAQASgBgCALQgCABgGAAIgJgBg");
	this.shape_206.setTransform(1.1,79.4);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#000000").s().p("AgNgDQAFABAMgCQALABgBAGIgNACQgMAAgCgIg");
	this.shape_207.setTransform(1.8,92.5);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#000000").s().p("AADAGIgTgEQACgGAOgBQALgBAGAGQgBAGgJAAIgEAAg");
	this.shape_208.setTransform(2.1,68.4);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#000000").s().p("AgQgBQAFgEALABQAMgBAFAEQgDADgLACIgQABQgDgDAAgDg");
	this.shape_209.setTransform(2.4,115.6);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#000000").s().p("AgTgBIAWgDQARgBAAAJIgVABIgCAAQgNAAgDgGg");
	this.shape_210.setTransform(1.8,48.4);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#000000").s().p("AgQAFQAFgFALgDQAKgEAHAFQgCAGgOACIgRgBg");
	this.shape_211.setTransform(2.1,56.9);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#000000").s().p("AAAQNQAAhAgEhPQgDg4ABhtQAAhvgCg2QgMkFAAmeQABmrgGnyIAXAAQACCSAMJ+QAJHYAAE6QAADeAFEZg");
	this.shape_212.setTransform(-290.5,76);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#000000").s().p("AgRGmQgHicADkLQAEk3gDh0IAZAAQAFEWANIqIgCAZQgUgBgSgGg");
	this.shape_213.setTransform(-288.3,222.7);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#000000").s().p("AgdSjIgOwiIgHk4QgFjJABiEQAAg6gEiqQgEiwAAhcQgCg/AAgiQACg/AQgFQgBgHAIgCQAiAEBGAEIgCAWQgPABgWgCQgXgCgLAAQgIADgEADQgLB8ACDCIAFFIQAADgAIGzQAIG1AADbQAACsACDPg");
	this.shape_214.setTransform(-290,-146.4);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#BFD7DD").s().p("EgATApEQgNosgFkWQgFkZAAjeQAAk6gJnaQgNp9gCiRQgDjPAAisQAAjbgHm1QgIm1AAjgIgFlIQgDjCAMh8QADgDAIgDQANAAAXACQAXACAMgBIAdXoQAkcwAOP/IAKNqQgUADgiAAIg4AAg");
	this.shape_215.setTransform(-284,0.3);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#000000").s().p("AAfWYIgBgBIgUABQgMv/gk8wIAVAAIABABIAEAAQACCTALGbQALFhgBDdQAADqAMG+QAMG/AADaQAAC3AEDKg");
	this.shape_216.setTransform(-276.9,32.2);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#1BC4E0").s().p("AgQAFQgEgsAWgUQAMAWgCAlQgCAqAIASQgdgJgFgug");
	this.shape_217.setTransform(-257.9,11.3);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#00A0C6").s().p("AggAGQgBgsAQgaQAyADAAA4QABA0gkASQgdgHgBg0g");
	this.shape_218.setTransform(-250.3,10.4);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#00A0C6").s().p("AAAAZQgRgMgVgBQACgMgCgOIgEgaQAwgOAZAjQAZAggbAgIgdgUg");
	this.shape_219.setTransform(-239.5,10.9);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#000000").s().p("AhIBlQgggFgTgRQgrg9AVg8QAZhHBlAOQALAFALAKIAWAPQBXgYAgBAQANAagFAcQgGAfgVAUQgWAAgQgJQgKgGgNgPQgDAAgIADQgHACgCgFQgQAGgQAQQgSAXgGAEQgTAHgWAAQgJAAgKgBgAh0AGQAFAvAfAIQgIgRACgqQABgmgLgVQgYATAEAsgAg5AAQACAzAcAHQAlgSgBg0QgBg4gygEQgQAaABAugAAogqIAEAaQABAPgBALQAVABASAMIAeAUQAbgggZggQgSgZgeAAQgNAAgOAEg");
	this.shape_220.setTransform(-247.9,11.1);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#FFFFFF").s().p("AgfABQgEgCACgGIAjAAQAUABAMgBQgFAIgTAEQgKACgZACIgGgIg");
	this.shape_221.setTransform(-232.7,202.4);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#000000").s().p("AjgHDQguAAgSgCIACgZIA5AAQAiAAAUgDIgKtpIAVgBIABABIAIAAQADCqAHEJIAMGtQDKhLDVhaIAHATIm9C7QgZgCgrAAg");
	this.shape_222.setTransform(-257.2,220.8);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#000000").s().p("ABsEEQgSgEgPACQgTgLgugLQgxgNgSgHQgJgEgVABQgXACgEgCQAFgOgKgFIgWgFQAFi8gDkIIAVAAQABD7ALCxQBiAoCWAoIgFATIgDAAQgKAAgQgEg");
	this.shape_223.setTransform(-241.4,-94.1);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#FFFFFF").s().p("AgVAbQgXgFgDgWQALgIAVgHIAjgLQAfAIgEAQQgCAMgYAKQgRAHgOAAIgLAAg");
	this.shape_224.setTransform(-228.6,210);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#000000").s().p("AgmChQgjgDgQggIgWhAQAegpAJgaQgGgDgUAEQgWAEgOgCQgRgLgGgeIgEgxQAdgdA5gSQA3gRBAgFIABAZQgZABgUADQgcAFgkAOQgsATgHACQgLAMACAQQACAQALANQAbAEAUgSQAOgMAMgaQAbgIA0ABIBYACIACAXIgCABQAEAHgLAKQgLALADAFQAtAMADAYQACAXgcAVQgcAWgjACQgnACgYgbQgHgUAOgSIAYgdQgZADgNgIQgJgHgFgPQgRACgFARQgCAIABAZQgcAagFAqQgEAvAlARIA/gLQAogHAcgHIAFAPIhJAaQgjAMgZAAIgHgBgABJAAQgVAFgLAJQACAXAYAFQAUADAYgKQAXgKADgOQADgOgegIIglALgAAOhEQgCAGADAEIAHAIQAagCALgCQASgEAGgKQgNABgTgBIgbAAIgKAAg");
	this.shape_225.setTransform(-237.5,208.5);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#FFFFFF").s().p("AiKAyQgLgNgCgPQgCgQALgLQAHgCAsgSQAkgPAcgEQAWgDAXgCQA0gDAiAHQAqAJAGAWQgSAIggABIhYgBQg0gBgbAHQgMAYgOANQgQAOgVAAIgKgBg");
	this.shape_226.setTransform(-234.8,199.8);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#FFFFFF").s().p("AiDAmQAEgoAcgaQAAgbACgIQAEgRARgCQAFAPALAHQAOAIAYgDIgXAfQgPASAHASQAYAbAmgCQAigCAdgWQAcgTgDgXQgDgagtgMQgCgFALgLQAKgKgEgHIACgBQAFAAAGAGQAGAFAIgBQgCATAPAQIAaAZQALApgeAcQgYAXg3AQQgbAHgmAHIhCALQglgRAFgvg");
	this.shape_227.setTransform(-231.1,211.7);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#000000").s().p("AgoCAQA1gPAYgXQAegdgMgrIgZgXQgPgPACgUQgJACgFgFQgEgGgFAAIgCgYQAegBASgIQgGgWgogJQgigHg0ADIgBgYQBYgGBEAUQACAIAPANQAOALAAANQAAAOgPAMQgRAOgDAIQAiAggHBQQgJAOgUAQIghAbQgYgBgjAKg");
	this.shape_228.setTransform(-223.6,206.6);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#000000").s().p("ACIFlQgvgEgcgHQgKgLABgNQABgJAIgSIACh1QABhIgDg0Qg1gyhfgEQgRgGgvgPQgrgNgUgMQgBgJAKgMQAMgOACgHQAJgcgKhzQgJheAhgbQAUgCAOAMQASAPAGACIBdAZQA1AOAsAGQAGggAAg0IAdAAIAAAJQAAAVAEArQgBAkgbAOQhvgSh8gtQgNAmACBOQACBfgDAXQAeAVBGAUQBRAXAYAJIAfAAQARABAGAFQAKAMgHARIgLAfQgDAVAGAsQAGAwgBAXQgBATgGAjQgEAgAHAWQAlAOBPALIgEAbIhLgIg");
	this.shape_229.setTransform(-219.6,-123.1);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#000000").s().p("AAND5QgEg/gDhhIgEigQgMAIgVAfQgTAbgYAFQACgUgCgcIgDgvQBAgzAWhjQASABAcgEQAPBUACCYQADDGADAwIghAKQgRAFgKAAIgFAAg");
	this.shape_230.setTransform(-200.2,188.3);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#000000").s().p("AlJISIgDohIgCi7IgCjGIgDhGQgBgpAIgMQADgCAIgEQAEAAAAADQAZAIAdAZQAVABAWAOQAgAWAGACQALAFAZAHQAZAHAMAFQFpCfBYAlIgGAQQl7idjtheQgJADgDAGQgOAIAAA8QAAAhADBBIgCGdQgCEFABCWg");
	this.shape_231.setTransform(-222.3,-173.7);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#000000").s().p("AgSCjIgagQQgYgIglgFIAEgcIBEAIQASg0AFhSIAEiMQAGAAAFgDIAKgGQAmAHA2AQIgIAcQgkgHgdABQgGAzgHBeIgKCUIgJABQgJAAgLgHg");
	this.shape_232.setTransform(-187.8,-99.9);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#000000").s().p("AALDjQgFh5gIioQgMAHgSAYQgQAWgQAHQACgQgDgaQgDgcAAgOQAmg1AGgKQAVglADgmQAQACAWgGQAJBOAHCQQAJCdAGBBQgGAAgYAJQgMADgIAAIgIgBg");
	this.shape_233.setTransform(-177.4,184.8);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#FF0000").s().p("AAQGeQhNgLglgOQgIgWAEggQAHgjABgTQABgXgGgwQgGgsADgVIALgfQAGgRgJgMQgHgFgQgBIgfAAQgZgLhTgXQhGgUgdgVQADgVgChfQgChOAMgmQB8AtByASQAagOABgkQgEgrAAgVIAAgJQABgWAFgrQAGgpAAgSQgEgEAAgFIB0AlQBHAWAhAaIgDB4QgDBJgJAmQAmAQBOAdQBFAcApAXIgGBeQgFBAAAAmQgmgFhSgXQg1gPgmgIIgKAGQgGAEgHgBIgECNQgFBTgSA1g");
	this.shape_234.setTransform(-199.6,-130.7);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#000000").s().p("ACWFKQg2gSgVgEIAIgdQBRAXAmAFQABgmAEhAIAGhgQgpgXhEgcQhPgdgkgQQAJgkAChJIADh4QgggahHgWIh2glQAAAFAEAEQAAASgFApQgGArgBAWIgcAAIgBhVQAAgzAGgkQAGgBAJgFQAyATBWAbICHAsQABAngDBVQgEBRACAkQAbAZBTAbQBWAbAbAYQgBAVgIApQgJAqgBAWQgBAXAEAvQABApgUAWQgbgCgsgPg");
	this.shape_235.setTransform(-185.4,-142.7);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#FFFFFF").s().p("ADpMVIj5hEIh2gfIh3geQiYgohigoQgKizgBj7QgBiWACkEIACmfQgDhAAAghQAAg8AOgIQADgGAJgDQDtBeF7CcIFwCZIAHAWQADAOAKADQABCHgDC5IgGFBIgEEzQgEC8gLB5QhvgXiRgmgAlajjQghAbAIBfQALBwgJAdQgCAHgNAOQgKAMACAJQATALArAOQAvAOASAJQBgAEA1AyQADA0AABHIgDB1QgIATgBAIQgBANAKALQAdAHAuAFIBJAIQAmAFAXAIIAbAQQAPAKAQgEIAKiUQAHhgAGgzQAdgBAkAHQAUAFA3ASQArAOAcACQAUgVgBgpQgFgwABgWQACgWAJgrQAIgoABgVQgbgWhWgcQhTgagbgcQgCgjAEhRQADhVgBgnIiJgsQhUgcgygSQgJAEgGACQgGAkAAAyIABBVQAAA0gHAgQgrgGg3gOIhdgZQgHgCgSgPQgMgKgRAAIgEAAg");
	this.shape_236.setTransform(-201.7,-135.6);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#000000").s().p("AgeAtQAuhoACg5IgJgTQgFgLgHgDQgWACgGAWQgDAMAAAeQgGACgQgBQgOgBgKgDQgJg5AbgrQAggzA7AfQAsBAgSBgQgKA2grBjQALADAYgGQAcgIAKgBQAGAPACAcQABAWgBAUQhBAShTAVQgIhQArheg");
	this.shape_237.setTransform(-156.9,182.6);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#000000").s().p("AERLhQhEgWgggIQl+hijPg+IAFgTIB2AeIB3AfID5BFQCQAmBvAXQALh6AEi8IAEkzIAGlAQADi6gBiHQgJgDgEgOIgGgWIlviYIAHgQQBdAoBiAmIBaAlQA2AWAkAKIAlAGQATACAKANQAHAMgLAPQgPATgBAFIgQIaQgHElAADtQAAAiAFBJQAEBCgBAdQgSAEgUAAQggAAglgKg");
	this.shape_238.setTransform(-185.9,-122.5);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#BFD7DD").s().p("EgKUAiGQgHkJgDipQgEjLAAi3QAAjZgMnAQgMm/AAjqQAAjbgLlhQgMmbgCiUIgBipQAAhwgFogQgDmVAEkCIAEgHQACgEABAFQBTAbBtA1QA/AfB2A/QCXBHDMBwQCGBCCzBeQErCdBmAyQgNAJAEAOIAJAZQACAeAAA8QAABCACAbIABBTIgBCkQAACngEFHQgCEiAJDHQACAkAAAsQAAArgFCeQgEB6AEBJIABAiQAFB7AACpQAABqgDDbQgDDaAAB1IgCH4QgBEuADDJQhHAahmAsIjeBgIiTA6QhYAjg6AaQigBJhsAuQjUBajNBKIgMmvgEgGGAgYQgJAcgeApIAWBAQAQAgAjADQAbACAqgNIBJgaQAjgKAaACIAhgbQAUgQAJgOQAHhSgiggQADgIARgOQAPgNAAgOQAAgMgOgMQgPgNgCgIQhGgThYAFQhCAFg3ARQg5ASgdAdIAEAxQAGAeARALQAOACAWgEQAMgCAHAAIAHABgAA+euQACBhAEA/QALABAVgGIAhgKQgDgwgCjIQgCiYgQhUQgcAEgSgBQgYBjg+AzIADAvQACAcgBAVQAVgGATgbQAVgfAOgIIAFCigEAEnAgVQAKADASgGQAYgJAFAAQgGhAgIigQgIiQgJhNQgWAFgQgCQgEAmgWAmQgFAJgmA1QgBAOADAcQADAagBAQQAPgHARgWQARgYAMgHQALCqAFB6gAHxaTIAJATQgCA5gwBqQgrBeAIBQQBVgVBBgSQABgUgBgWQgCgcgGgPQgKABgcAIQgYAGgLgDQArhjAKg4QAShggshAQg9gfggAzQgbArAJA5QAKADAOABQAQABAGgCQAAgeADgMQAGgWAWgCQAJADAFALgAo2A8QgVA/ArA9QATAQAfAFQAhAFAcgLQAFgDAVgXQAQgRAQgFQACAFAGgCQAJgEACABQAOAPAKAFQAQAKAWAAQAVgUAFgfQAFgegNgaQgghAhWAYIgWgQQgOgKgKgEQgRgDgPAAQhKAAgUA7gAFzoLQAhAIBDAWQA+AQAugKQABgdgEhCQgFhJAAgiQAAjtAHklIAQocQABgFAOgTQALgPgHgMQgJgNgTgCIglgGQglgKg1gWIhaglQhigmhggoQhYgllpifQgMgFgZgHQgZgHgLgFQgGgCgggWQgWgOgVgBQgdgZgZgIQAAgDgEAAQgIAEgDACQgIAMABApIADBGIACDGIACC7IADIjQACELgFC7IAWAFQAKAFgFAOQAEACAXgBQAWgCAJAEQASAIAyAMQAuAMAUAKQAOgCASAFQASAEALgBQDPA+F+Big");
	this.shape_239.setTransform(-205.7,0.6);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#00A0C6").s().p("AgIBLQgNgJgBgUIACgpIAAhRIAVAAQATAoACAoQACA0gcAVQAAAAAAAAQAAgBgBAAQAAgBgBAAQgBAAgBAAg");
	this.shape_240.setTransform(-127.3,109);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#00A0C6").s().p("AgOBnQgIgeAChBQADhWgBgYQALgBAHAFIAPAIQAAAhAFBBQADA6gMAlg");
	this.shape_241.setTransform(-128.2,-121.9);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#000000").s().p("AgpJlQAAgsgCgkQgJjHACkiQADlFAAinIACikIAcAAIABDUQAGAFAbAEQAZADAFAJQAKB4gKB5QgHADgbABQgWACgHAGQgCCYAADWIACF1gAgQlyQABAZgDBYQgCBBAHAeIAZAAQAMglgCg7QgFhCgBgiIgOgIQgGgEgJAAIgDAAg");
	this.shape_242.setTransform(-128.4,-95.2);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#80A1A8").s().p("AiAIbIgBlfIAigFQAVgDAGgHQAMgkgDg8QgCgYgLhNQgGgHgRgCQgLgBgXABQgGjjABlxIABj/QA1gHBQABICCADQAFHxAAFvQAAGbgFE2QgXAagkAcQgWARguAgIhBAwQgnAbgcAPQACiKgBjWg");
	this.shape_243.setTransform(-116.3,101.6);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#80A1A8").s().p("AgLN/QhPgCgsgHIAAj6IgBl2QgBjWACiYQAHgGAYgBQAbgBAHgEQALh4gLh4QgFgJgZgEQgcgEgHgEIgBjVQABjEAEhmQADgHAIgCQAIABAGAFIAKAJQA9ALA9AcQAWAKBUAsQAEFEAAENQAAIQgMI2IiIgDg");
	this.shape_244.setTransform(-116.6,-97.4);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#000000").s().p("As+OLIDehfQBmgsBGgbQgCjIABkvIABn2QAAh0AEjbQADjbAAhpIAbAAQgBFwAFDkQAXgBALABQARACAHAHQALBPABAYQAEA7gMAkQgGAIgVADIgjAFIACFdQABDWgDCKQAcgPAogcIBDgvQAtggAXgSQAkgcAWgZQAFk3AAmaIAZAAIABHmIgCB+QABBHANAsQERAEIlADIAAAaQnjgDlIAEQgIABgDAFIgMAAQgSgBgVARQgMAJgWAUQgkAZhOAxQhDAtgiAoIgBAiQgBARACAPQNMAJF9gCIAAAYIy9ACQglAShfAgQhYAegpAWIiDAzIgxASgAmOjVIgCAoQABAVANAIQABAAABABQAAAAABAAQAAABABAAQAAAAAAABQAegVgCg0QgCgqgTgpIgXAAg");
	this.shape_245.setTransform(-89.5,131);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#000000").s().p("AqyJWQgEhLAEh6QAFidAAgsIAZAAIAAD6QAsAIBPACICKADQAMo1AAoRIAaAAIABEKIgCGaQgBDqAGC4QDDgCFGADIIRACIAAAaQsmgCofAGQgFAaABApQACAzgCARIgdABg");
	this.shape_246.setTransform(-64,-53.9);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#000000").s().p("ApEHCQAAlwgFnuIiDgDQhRgBg1AHIAAD/IgbAAQAAiqgFh7IAdgBQR2ABJSgCIAAAaQtBADpNAFQgQFOAAITg");
	this.shape_247.setTransform(-44.7,54.1);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#000000").s().p("A58BtQBsgtCihHQA6gaBXgjICTg7IAIASQgyAVgUAVQAJAjARAZQAWAfAgAJQAYAHAhgDQAtgFAKABQAOAAAeAEQAdAEAPABQDUAHEfgCIH9gFQBjgBGXABIHygBQEkAADIAEIAlAAIAAAWI1kAHQtEADoQgFQhwgtgHhSQihA9kiB6g");
	this.shape_248.setTransform(-62.8,234.6);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#61878C").s().p("AgCADIAAgFIAGAAIAAAFg");
	this.shape_249.setTransform(108.5,99.1);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#000000").s().p("ArEgGQMGgDKCgIIABAWIgCAAQgBAAAAAAQgBAAAAABQgBAAAAABQgBAAAAABQAAABgBAAQAAABgBAAQAAABgBAAQAAAAAAAAQgBADgEAAQngACubACg");
	this.shape_250.setTransform(114.5,9.8);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#61878C").s().p("AuPNMQlHgCjDABQgGi4AAjqIACmcIgBkIQgBlwAKjYIADgFQABgEADAAQEWgBG+ACILKACQNPAAI1AJQAWNqgSMeQjsAGnXgCQoRgEjAADQjSADivAAIoSgCg");
	this.shape_251.setTransform(43.5,-91.9);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#61878C").s().p("ApeMrQolgDkTgEQgNgsAAhHIACh9IgBnpQAAoTAQlOQJPgFNBgCQOagCHhgDQADABABgEQAAAAABAAQAAAAABAAQAAgBABAAQAAgBAAgBQABAAAAgBQABgBAAAAQABAAAAAAQABgBAAAAIAEAAQAbgBABAYQAAAPgFApQAAPKgPIzQsGALsTAAInVgBgAKBBNIAIAAIAAgGIgIAAg");
	this.shape_252.setTransform(44,91.6);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#80A1A8").s().p("AVRAsIiLgBQ2pAAzYgMQgPgJgegLQgkgLgLgGIgrgVQgZgLgYgEQKFgCQAABIZiAEQgKAOgXAMIgsARIgrATQgaAKgTAEQgtAHhIAAIgJAAg");
	this.shape_253.setTransform(45.4,-182.6);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#80A1A8").s().p("A7DCHQgCgPABgRIABgiQAigoBDgrQBOgxAkgaQAWgTAMgJQAVgRASAAIAMAAQADgEAIgCQFKgDHjACINLAGQHnADFigFQBngCA6ACIBXgBQAzgBAbAFQAsAJAqAeIBEA5QAeATBDAdQA6AeAVAiQgJADAFATQAEAUgLAEQgSAJgdABIgxgBQj/AEorAAQoTAAkoAFQjtAEkAAAIhWABQmAAAr1gIg");
	this.shape_254.setTransform(44.1,189.5);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#00A0C6").s().p("AgKBTQgHg7gCgcQgCg1AVgaIAIACQAEACADgBQAFAcAAAvIgBBPQgFABgJAFQgFAEgIAAIgCgBg");
	this.shape_255.setTransform(216.7,109.6);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#80A1A8").s().p("ABiN5QgagQgKgEQgugVg1gmIhahDQACgMgFgMIgJgSQAGjjgEoPQgEnsAKkOQABgKADgPIAIgaQADgJgLgIQgKgHAGgGQAwAFBQgGQBPgHAwAFQAQAYAAAlQAAAWgFArQgFB8AGDvQAFDtgGCIQgrADgWATQgKAWABAuQABAaAFA2QABAOgBAbQAAAYAOAKQANAFAPgDIAagFQgGEfADGaQgMAAgWgNg");
	this.shape_256.setTransform(205.1,101);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#BFD7DD").s().p("A7RBHQACgRgCgzQgBgnAFgaQIfgFMoABIS/ABQH9AAGcgGIAAB8IlRAGQqCAJsFACQmNACqAAAIq+gBg");
	this.shape_257.setTransform(44.4,2);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#00A0C6").s().p("AgOBSQADgOABhFQABg1AMgbIAMAAIAACgQgHgBgIADQgEABgGAAIgEAAg");
	this.shape_258.setTransform(217.9,-120.7);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#80A1A8").s().p("AgBN8QhQAAgugDQgQgfgBguIAChPIAA22QBehVCVg1QAGgBAEgIQAEgIAGgBIAFgEIAGgCQADgBABAEQALBjgDCiIgEEDQgGAEgZAEQgWAEgFAJIgFBxQgCA+ADAyQALAKAUgCQAagDAFABIABGbQAAEjgFEyIiJAAg");
	this.shape_259.setTransform(205.4,-96.8);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#000000").s().p("AVrWkQhugsg/gPIimhAQhggkhMgYQgPACgNgDIgWgIQn6AB6oADIAAgXQEAAADtgFQEqgEITAAQIpAAD/gFIAxACQAdgCASgJQALgDgEgUQgFgTAJgDQgVgig6gfQhDgegegTIhEg6QgqgegsgIQgbgGgzACIhXABQg6gChnACQlgAFnngDItNgGIAAgaQQFAEPogOQAQoyAAvLQAFgpgBgOQgBgYgaABIgDAAIAAgZIFRgFIAAiWQAEkzAAkjIAZAAQAADIADRFQADMTgIHnQAPAWAAAnQAAAkgMASQAWAEACAJQABAIgJARQBSAfHrC4IgHAUQhAgVgegNgANdRUQgDmbAHkeIgbAFQgPADgMgFQgOgLgBgXQABgbgBgOQgFg2AAgaQgBguAKgYQAVgTAsgDQAFiIgFjrQgFjwAFh7QAEgrAAgWQAAglgQgYQgvgFhSAHQhQAGgwgFQgGAGAKAGQAMAJgEAIIgHAaQgEAPgBALQgJEOADHqQAEIRgGDjIAJASQAFALgCANIBbBDQA2AmAvAVQAJADAbARQAVANAMAAIAAAAgAM5EeQABAdAIA8QAIAAAIgEQAKgFAFAAIAAhSQAAgvgEgcQgEABgEgCIgHgBQgYAaADA1g");
	this.shape_260.setTransform(132.1,80.5);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#000000").s().p("AnxQyIAAgaQCvgBDVgCQC9gDIRAEQHYACDsgHQASsdgWtrQo1gJtNAAIrNgBQm9gCkWABQgDAAgCADIgCAGQgKDYABFwIgaAAQAAkNgElEQhTgsgXgKQg/gcg9gMIgKgJQgGgEgIgBQgHACgEAHQgEBmAADEIgdAAIgBhSQgBgbgBhDQABg8gDgeIgIgYQgFgPANgJQhmgykridIAKgTQAfAQB6A5QB3BICOA8QZ8ADHcAAILIABQGfgBEZgDQAzgcBsg0QBvg1A1gdQB1hAB9g5IAhgNIAJASQlXCujtCAQgBANgGASQgJAUgDAQQgJAsAABIIABB5QgJFzgCEyIgBDcIgZAAIgBmcQgFgBgZACQgVADgLgKQgDgxACg9IAGhxQAEgKAWgDQAZgEAGgFIAFkCQADiigLhkQgBgEgEABIgFADIgGAEQgGAAgDAJQgFAHgFACQiYA1heBUIAAW3IgCBPQABAuAQAeQAuADBQABICMAAIAAAYQmdAGn9AAIy/gBgAZQhYQgBBIgCAOQAGABAJgCQAIgEAHACIAAiiIgLAAQgPAbgBA0gA7UrsQAYAFAZALIArAUQALAHAkAMQAeAMAPAIQTYAMWpABICLABQBOAAAwgIQATgDAagKIArgUIAsgSQAXgNAKgOI5ggDIsqgBItdABg");
	this.shape_261.setTransform(55.1,-112.1);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#BFD7DD").s().p("EggBACiQgPgBgdgEQgdgEgPAAQgKgBgtAFQggADgYgHQgggJgWghQgSgZgIgjQATgVAzgVIAwgQICDg0QApgWBYgeQBgggAkgSITAgCQangEH7AAIAVAHQANAEAPgCQBNAYBfAkICmA/QBAAQBtAqQAfANA/AVQArAQAZARQgLASgWAQQgOAKgfAQQrrAMsgAAIhpACIhrABIglAAQjIgEkiAAInyABQmXgBhkABIn+AFIhkABQjhAAivgGg");
	this.shape_262.setTransform(54,222.6);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#BFD7DD").s().p("AE1C8QncAA58gEQiNg8h4hHQh6g3gegRQg6gegrggQASgyAjgcQAsgKBIgOUARZgADAiVAAAQCKAAEQAEQD2ADCxgHQBhgDBuADQAdABBCAAQA2AEANAfQAJAYgiAQIghAOQh8A5h2A9Qg1AdhuA1QhsA0gzAcQkaAEmeABIrJgBg");
	this.shape_263.setTransform(51.4,-208.6);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#000000").s().p("ALBBNQhggFgpgBQingDkMADQkmAEiBgBQlCgClUAAIAAgWIBrgBIBqgCQMdAALsgMQAegQAOgKQAWgOALgSQgYgRgrgQIAHgUICCAxIgHASIgOgFIguAuQgcAbgdAJQghAJg/AAIgcAAg");
	this.shape_264.setTransform(198.7,234.1);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#00A0C6").s().p("AgcASQgMgQADgQQADgUAOgHQAMgFAOAHQAnATgIArIgRAMQgKAHgKACQgTgPgJgLg");
	this.shape_265.setTransform(342.7,0.2);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#1BC4E0").s().p("AgCAAQgFgXgHgKIAOAAQAIAAADADQgCAFAFAZQAFAYgMAKQgFgJgEgZg");
	this.shape_266.setTransform(349.2,-1.4);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#000000").s().p("AgvBGIgqgUQgUgfAHgdQAGgcAagUQA8gsBJAiQARAIAMATQANAUAAAVIgMARQgIAKAEAOIgqAXQgZANgVAGQgXgDgZgKgAgxglQgOAGgDAUQgCAQAMAQQAJAMAUAOQAKgCALgHIAPgMQAIgrglgSQgJgEgJAAQgFAAgGACgAAhgNQAGAYAFAJQALgKgEgVQgFgcABgFQgDgDgIAAIgQAAQAHAKAGAYg");
	this.shape_267.setTransform(345.5,0);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#BFD7DD").s().p("EgAGAkVIiCgxQnri4hTgfQAJgRgBgIQgCgJgVgEQAMgSAAgkQgBgngPgWQAInngCsVQgExDABjIIABjdQACk0AJlyIgBh6QAAhHAJgtQADgPAIgVQAHgSABgMQDsiAFYivIGcjQQERiICOhIIAEACQAAAAAAABQABAAAAAAQABAAAAAAQABAAAAAAQgHIrAHTCQAHSRgKJ3IgFChQgDBgAEBAQAHB3gFDNQgFDnADBbQACBYgBCIIgBD1IAABNQgCArgOAfQkqhmmcibgAG0gtQgbATgGAaQgGAfAUAfIApAUQAaAKAZAEQAVgHAZgNIAqgXQgEgNAHgLIAMgSQABgUgNgUQgMgTgSgHQghgPgdAAQgnAAghAZg");
	this.shape_268.setTransform(294.8,-1.3);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#BFD7DD").s().p("EgACAoxIgZgEQgQADAAgNQADgRgCgHQgOh8AAjBIgBlAQgCg9AEhlIAFijQAEn6AAqGIAAxbIgCk9QgBi/ADiEQAFjDgCkkQgDlDAAihIABioQABhhAGhCQAAgHAHgCQAPAEAbgCQAcgBANADQAIGZgBI4IgENFQgDIVAAEZIAAFEQAAC9gECHQgBAyABBOIACCAQAAAsgCArQgKC3AGBzQAFBdABB2QAABxgGEXQgGD7ACCKQABAsgCBHIgCB0IAAAlQgCAXgOAMQgJACgIAAIgGAAg");
	this.shape_269.setTransform(375.8,-0.9);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#000000").s().p("EAyzApNQg5gGgRAFQgPggg7gWIhigkQhKgWh6gyQhNgbhvgqIi6hGIAHgSQGeCbEqBlQAOgeACgsIAAhMIABj2QABiHgChYQgDhcAFjmQAFjNgHh3QgEhAADhgIAFiiQAKp2gHyRQgHzDAHoqQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAgBAAAAIgEgCQiOBIkRCIImeDQIgJgSQAigQgKgYQgNgfg2gFQhCABgcgBQhvgDhgADQixAGj3gCQkPgEiKAAUgiVAAAgRaAADQhIAOgrAKQgjAcgTAyQArAgA6AeIgKAUQizhfiGhBQjOhxiXhHQh2g+g/gfQhtg2hTgbQgBgFgCAFIgEAGQgEEDADGVQAFIfAABxIABCpIgFAAIgBgBIgUAAIgd3oIACgWIAoAEQD9BgDTCBQBSAkCVBPQCYBPBOAjQAJgNAPgeQAOgaAQgMQBpgbCagBQBZgBC1AFIa8AAIJBACQFYABDkgDQCdgDGnAEQF1ACDSgGQASgBAjgEQAggDATAFQAUAFAJARIARAjQFwiuGrjiIAeAAIAAAVQgHACAAAHQgGBCgBBhIgBCoQAACgADFEQACEkgFDDQgDCEABC+IACE+IAARbQAAKFgEH7IgFCjQgEBlACA9IABFAQAADBAOB8QACAGgDARQAAAOAQgEIAZAFQALABAOgDQAOgMACgXIAAglIACh0QAChHgBgsQgCiKAGj7QAGkXAAhyIAWAAIADDnQABCHgFBhQgFBhAGDmQAGDQgLByQgPAJgeAAQgOAAgRgCg");
	this.shape_270.setTransform(49.8,-0.4);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#000000").s().p("AgNBXQgGhyAKi2QABgrAAgsIAUAAIAABUIADCiQADBigDA/QgDBKAABwIgUAAQgBh1gEhdg");
	this.shape_271.setTransform(381.7,121.6);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#000000").s().p("AgQT+IgBiAQgChOACgyQAEiIAAi8IgBlFQAAkaADoTIAEtFIASAAQAADGAEB7QAGDAgEEzQgGGtAABQQAADpgDGDIgEJeg");
	this.shape_272.setTransform(382.5,-35.9);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#000000").s().p("AAeH1QABo2gImaQgMgDgaABQgdACgPgDIAAgVIA8gBQAkAAAVAEQAFDDgFEtIgIH1g");
	this.shape_273.setTransform(378.6,-213.9);

	this.addChild(this.shape_273,this.shape_272,this.shape_271,this.shape_270,this.shape_269,this.shape_268,this.shape_267,this.shape_266,this.shape_265,this.shape_264,this.shape_263,this.shape_262,this.shape_261,this.shape_260,this.shape_259,this.shape_258,this.shape_257,this.shape_256,this.shape_255,this.shape_254,this.shape_253,this.shape_252,this.shape_251,this.shape_250,this.shape_249,this.shape_248,this.shape_247,this.shape_246,this.shape_245,this.shape_244,this.shape_243,this.shape_242,this.shape_241,this.shape_240,this.shape_239,this.shape_238,this.shape_237,this.shape_236,this.shape_235,this.shape_234,this.shape_233,this.shape_232,this.shape_231,this.shape_230,this.shape_229,this.shape_228,this.shape_227,this.shape_226,this.shape_225,this.shape_224,this.shape_223,this.shape_222,this.shape_221,this.shape_220,this.shape_219,this.shape_218,this.shape_217,this.shape_216,this.shape_215,this.shape_214,this.shape_213,this.shape_212,this.shape_211,this.shape_210,this.shape_209,this.shape_208,this.shape_207,this.shape_206,this.shape_205,this.shape_204,this.shape_203,this.shape_202,this.shape_201,this.shape_200,this.shape_199,this.shape_198,this.shape_197,this.shape_196,this.shape_195,this.shape_194,this.shape_193,this.shape_192,this.shape_191,this.shape_190,this.shape_189,this.shape_188,this.shape_187,this.shape_186,this.shape_185,this.shape_184,this.shape_183,this.shape_182,this.shape_181,this.shape_180,this.shape_179,this.shape_178,this.shape_177,this.shape_176,this.shape_175,this.shape_174,this.shape_173,this.shape_172,this.shape_171,this.shape_170,this.shape_169,this.shape_168,this.shape_167,this.shape_166,this.shape_165,this.shape_164,this.shape_163,this.shape_162,this.shape_161,this.shape_160,this.shape_159,this.shape_158,this.shape_157,this.shape_156,this.shape_155,this.shape_154,this.shape_153,this.shape_152,this.shape_151,this.shape_150,this.shape_149,this.shape_148,this.shape_147,this.shape_146,this.shape_145,this.shape_144,this.shape_143,this.shape_142,this.shape_141,this.shape_140,this.shape_139,this.shape_138,this.shape_137,this.shape_136,this.shape_135,this.shape_134,this.shape_133,this.shape_132,this.shape_131,this.shape_130,this.shape_129,this.shape_128,this.shape_127,this.shape_126,this.shape_125,this.shape_124,this.shape_123,this.shape_122,this.shape_121,this.shape_120,this.shape_119,this.shape_118,this.shape_117,this.shape_116,this.shape_115,this.shape_114,this.shape_113,this.shape_112,this.shape_111,this.shape_110,this.shape_109,this.shape_108,this.shape_107,this.shape_106,this.shape_105,this.shape_104,this.shape_103,this.shape_102,this.shape_101,this.shape_100,this.shape_99,this.shape_98,this.shape_97,this.shape_96,this.shape_95,this.shape_94,this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-296.6,-265.2,681.4,531.4);


(lib.antiseptico = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAACYQgoAAgagoQgbgqAAhEQAAhFAcgrQAbgpAnAAQAqAAAaApQAZAqAABDQAABKgeAqQgbAlglAAgAgrhLQgOAfAAAsQAAAxAQAfQAQAgAZAAQAYAAARggQARggAAgwQAAgrgOgfQgQglgcAAQgbAAgQAkg");
	this.shape.setTransform(130.9,67.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgwBvQgbgpAAhDQAAhDAcgrQAdgsAtAAQAeAAATAQIgIAoQgQgOgZAAQgeAAgTAhQgRAeAAAuQAAAyATAeQATAdAbAAQAWAAAVgNIAGAnQgXARggAAQgqAAgagpg");
	this.shape_1.setTransform(111.4,67.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgQDPIAAkjIAhAAIAAEjgAAAiKQgJABgGgLQgGgKAAgOQAAgOAGgJQAHgKAIAAQAKAAAGAKQAGAJAAAOQAAAOgGAKQgGALgKgBg");
	this.shape_2.setTransform(97.5,61.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgMChQgOgWAAg2IAAieIgeAAIAAgoIAeAAIAAg2IAhgQIAABGIAyAAIAAAoIgyAAIAACcQAAAdAFANQAHAPAOAAQANAAAHgEIACApQgNAHgSAAQgYAAgMgXg");
	this.shape_3.setTransform(86.1,64.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhaDRIAAk7QAAg1gBgqIAgAAIACAyIAAAAQAWg5AtAAQAjAAAXApQAYAqAABCQAABIgbAsQgZAngkAAQgRAAgQgMQgQgMgJgWIgBAAIAACfgAggiUQgPATgGAdIgCAWIAAAyQABAMABAKQAEAZAQASQAOARASAAQAaAAAQgfQAQgdAAgzQAAgugPgeQgQgggaAAQgRAAgPARg");
	this.shape_4.setTransform(68.9,73.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag7CpQgZgpAAhCQAAhCAYgsQAaguAnAAQArAAAVAxQAQAlAAAyQAAAQgCAJIiFgBQAAA0AVAaQARAYAaAAQAdAAAZgPIAGAmQgdASgkAAQgqAAgagogAgjgaQgMAXgDAfIBlAAQAAgegJgXQgNgfgbAAQgWAAgPAegAgNh7IAihVIAmAAIgxBVg");
	this.shape_5.setTransform(46.9,61.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("Ag+CEIAJgoQAJAIALAGQAOAGAMAAQARAAAKgMQAJgLAAgUQAAgTgIgMQgJgMgRgLQg0gaAAg2QAAglASgYQATgZAcAAQAcAAATASIgIAmQgSgRgWAAQgNAAgIAMQgJALAAARQAAASAJALQAIAKASALQAZAPANASQANAVAAAgQAAAogTAYQgUAYgfAAQggAAgXgUg");
	this.shape_6.setTransform(28.9,67.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgQDPIAAkjIAhAAIAAEjgAgPiUQgGgKAAgOQAAgOAGgJQAGgKAJAAQAKAAAGAKQAGAJAAAOQAAAOgGAKQgGALgKgBQgJABgGgLg");
	this.shape_7.setTransform(16.3,61.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgNChQgNgWAAg2IAAieIgeAAIAAgoIAeAAIAAg2IAhgQIAABGIAyAAIAAAoIgyAAIAACcQAAA5AaAAQANAAAIgEIABApQgOAHgSAAQgXAAgNgXg");
	this.shape_8.setTransform(4.9,64.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAwCVIAAinQAAgmgKgWQgMgagXAAQgPgBgNARQgNAPgEAXQgDAIAAARIAACuIgjAAIAAjTQAAg3gCgYIAgAAIACAvIAAAAQAIgWAQgPQASgRAUAAQAaAAATAZQAYAhAABDIAACsg");
	this.shape_9.setTransform(-12.5,67.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("ABLDLIgdiAIhdAAIgcCAIgkAAIBbmVIAoAAIBcGVgAgOhSIgaB0IBPAAIgbhzIgMhLIgBAAQgFAlgIAlg");
	this.shape_10.setTransform(-35.6,61.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhFBUQgdgigBgyQABgwAdgjQAdgkAoAAQApAAAdAkQAeAjAAAwQAAAygeAiQgdAkgpAAQgoAAgdgkg");
	this.shape_11.setTransform(38,-202.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(7.3,0,0,4).p("AhIguICRBd");
	this.shape_12.setTransform(111.3,-55.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgFAGIAAgLIAKAAQABAEgCABQgDAEAAACg");
	this.shape_13.setTransform(-19.7,-91.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("EgIrAkrQgHgCgJgFIgQgJQiNgJh2gXQiTgchcgsQgIgCgJADQgKADgFAAQgOgFgOgNIgYgXQAEgIABghQABgXASgEQAFgXABgcIACgtQAAgDAEgDQAEgEAAgCQAAgBgFgCQgEgCABgDIAGg0QAEghgCgYQgDgnAAhRQABhWgCgnIgMiyQgGhoAGg7QgDgLgNgRQAJgTgDgmQgDg6ABgKQAJhSACg0QADhMgKhLQACgDABgMQABgLAEgCIgIgYQgFgRgDgHIAEkFQADiZgHhwQAFhJAAidQABiXAGhLQAIhTAfhOQAYg/AthKQAbgVAMgMQAWgUADgbQA4gbAdgtQAPABAKgIQAEgDALgOQAKAAAEgBQAGgCAAgFQAVgBAbgKQAegLAOgCQAEgCAogNQAbgIAGgSQgHgHgDAFIgCAKQgLgEAHgMQALgOABgGQgJgdgCgRQgDgeASgQQgIgaAIgfQAHgcgLgYIAPgYQAHgNgKgPQAKgKALgWQAJgSAKgGQAKgGAQABQAWACAIgBQAEAAAKgLQAEACAWgDIAuACQAcABAPgHQADANAXgDQAdgEAJAGQAQgUAHgXQAEgPAFgmQgJgXABgtQABgsgJgRQAQgSADg3IABhUQAGgOABgyQABgwAIgUQgGgbAAgYQAAgiAOgMQgKhPAIhsQALh9ADhFIgQgkQANgaAGgOQAKgYgFgdQAQgQAYgnQAYggAdgJQATg1BWgMQAwgHBmgEQBUAdApAZQA9AlAXA5QgBARAJAXQgCAYACA4QABAqgFAbQALAygBCXQAACHAaBGQgHAlAHA6QAIA3gIAiQAVAsABBIQABArgHBWQACAPAHAYQAEAPgBAXQBYgYBRAcQAoAOBgA6QAXA6ACBoQACBEgHBrQgIAigMAVQgFAKgHAIIggANQgUAJgEAOIgmAFQgTAEgDAPQgnABhHAVQhMAXgnADQhtgQibgEQizgBhhgDQgngJiPgaQhygUg+gVQgHgBgLADQgKADgIgBQgdgGgLgKQhDAWhFApQgvAdhGA0QhUBtgnBmQgyCHAQCQQgOAfAFAvQADAbAKA2QABAJgFAJIgIAOQAAA6ACBhIACCWQAAA1gGBrQgCBeAQA8QACBNgCCcQgDCLADBGIAQHFQAFAPABAcQACAdAEARQgIAtAABqQABBugJA4QABAKAIAPQAIAPgBAMQBOAvCFAXQBUAPCfAMQASABAOALQFlAuE0gWQAXgJA8ACQA8ABAegKQCXAKCqgnQBhgWC0g2QBugwBPgYQgDgNAIgQQAHgNAMgKQgBgNAEg1QACgigJgRQANg1AIhLQAGhTAFgqQAGgtgGhGQgHhfgBgTIAFguQADgcgMgSIAGgbQADgRADgIQgGiIAAg1QgBhkALhRQgOgWAIg+QAKhAgQggQABgHAFgJQAGgJAAgIIgDhrQgCg/gLgiQANg2AAhSIgFiSQgGgfgGgNQAJhegWh6QgaiUgBhAQgOgdgCgKQgHgVADgYQgKgNgFgKQgGgPABgSQg8hDhYg2QhYg2hWgWQgFABgEgJQgEgIgLAEQgJggAKgXQAJgVAWgEQBCATBZA5QBnBCAsASQAtApAfBIQAXA2AVBaQgEBAAVB3QAVB4gCA5QAPBCgGCRQgHCaAKBBQABA+gFB+QgCBxAKBEQgQCnABCaQABCcASCyQgMBYgHCnQgIC9gFA2QAYAQgHAhQgCAHgTAsIgXAGQgMADgNgFQgGADgJAKQgJAJgIACQg5AHhGAZQhQAegqAPQguAIieAlQh+AchUALQh5gEiXAFQiYAGiAANQjLgSi/gGgAD6poQAxAHAggCQANgMAcgEQAfgEAMgIQgMgLgEgKQgHgPADgUQABgGAKgGQAKgEgBgJQAJg5gKhKQgQhWgHgwQAPgVAVgHQAdAKAHAWQAFAjgBB/QAABkARAsQAAADgGAEQgEADACAGQANABAQgEQARgGAKABIApgrQAagaAFgcQAJgpgPhJQgPhKAFgZIgngfQgXgTgSgKQhGgJgcgDQgugDgpAHQgsAIhZADQhjADgxAGQhMgKi7AQQi9APhQgJQgOAJgHADQgNAFgLgFQgCAPgTAJQgWALgFAFQghCgAtBJQADAMgBAGIgGAPQAOACAaAIQAYAIAQACQAAgMgHgLIgNgSQAFgyAAgUQABgigOgYQAEgIANg8QAJgoAfgJIAVAHQAOAEAFAGQgGAIAGARQAGATgCAMQgCAEgHADIgLAFQABAhgBA9QAEA0AYAjQgCADgKALQgIAIAAAKQCbAgCRAJQCdAJCHgSQAEABAGAHQAFAGAJgCIASgBQATAAAfAEgAGfqLQAFAAgBAEIAIAAQAFgHgJgCIgDAAQgGAAABAFgAqDvhIAIAAQAAgCADgDQACgDgBgEIgMAAgEgAvgjxQg6AOg0AhQgQAigEAFQgNAUgTAFQgsCcAMB+QgIBXgDB8IgGDeQgMA1AABrQABB3gFAfQACAKAIATQAFASgHANQBcAHCrgNQCrgNBTAHQgBgPgDgKIgIgbIAYhBQACgJgIgHQgIgGACgKQAQg5gQhbQADgFADgLIAGgRIgUjhQgLiNgChbQACgHgIgDQgIgDACgHQgBgGAGgDQAGgEgDgIQgEhfgDguQgGhRgTg7QgLgCgJgNQgNgSgDgDQgIgHgUgEQgZgFgHgEQgDgBgCgHQgDgGgEgCQgigLglAAQgdAAghAIg");
	this.shape_14.setTransform(44,8.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFBF00").s().p("ApAWlQgOgLgSgBQifgMhUgPQiFgXhOgvQABgMgIgPQgIgPgBgKQAJg4gBhuQAAhqAIgtQgEgRgCgdQgBgcgFgPIgQnFQgDhGADiLQACicgChLQgQg8ACheQAGhrAAg1IgCiWQgChhAAg6IAIgOQAFgJgBgJQgKg2gDgbQgFgvAOghQgQiQAyiHQAnhmBUhtQBGg0AvgdQBFgpBDgWQALAKAdAGQAIABAKgDQALgDAHABQA+AVByAUQCPAaAnAJQBhADCzABQCbAEBtAQQAngDBMgXQBHgVAngBQADgPATgEIAmgFQAEgOAUgJIAggNQAHgIAFgKIARALQgKAXAJAgQALgEAEAIQAEAJAFgBQBWAWBYA2QBYA2A8BDQgBASAGAPQAFAKAKANQgDAYAHAVQACAKAOAdQABBAAaCUQAWB8gJBeQAGANAGAfIAFCSQAABSgNA2QALAiACA/IADBrQAAAIgGAJQgFAJgBAHQAQAggKA+QgIA+AOAWQgLBRABBkQAAA1AGCIQgDAIgDARIgGAbQAMASgDAcIgFAuQABATAHBfQAGBGgGAtQgFAqgGBTQgIBLgNA1QAJARgCAiQgEA1ABANQgMAKgHANQgIAQADANQhPAYhuAwQi0A2hhAWQiqAniXgKQgeAKg8gBQg8gCgXAJQhjAHhqAAQjcAAjwgfg");
	this.shape_15.setTransform(44.1,90.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgBAEQAAgEgEAAQgBgFAHACQAIACgEAFg");
	this.shape_16.setTransform(86.3,-56.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgjCbQADgIADgjQACgZAMgMQAChsgqhvQAGgUAOgJQAPgLAUAIQAUAfAEB0QAEByAcAqQABAqgmAKQgIACgHAAQgYAAgPgag");
	this.shape_17.setTransform(67.9,-73.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3F3F3F").s().p("AD1DWQgugHgWADQgJACgFgFQgGgIgEgBQiHATidgKQiRgJibggQAAgKAIgIQAKgLACgDQgYgjgEgzQABg8gBghIALgFQAHgDACgEQACgLgGgUQgGgQAGgJQgFgGgOgDIgVgHQgfAJgJAoQgNA8gEAHQAOAWgBAiQAAAVgFAyIANASQAHAKAAAMQgQgBgYgIQgagJgOgCIAGgPQABgGgDgLQgthJAhieQAFgFAWgMQATgJACgOQALAFANgGQAHgDAOgIQBQAJC9gQQC7gPBMAKQAxgHBjgDQBZgCAsgIQApgIAuAEQAcACBGAKQASAJAXATIAnAgQgFAZAPBKQAPBHgJApQgFAbgaAaIgpArQgKAAgRAFQgQAFgNgCQgCgGAEgDQAGgDAAgEQgRgrAAhkQABh9gFgjQgHgWgdgKQgVAGgPAWQAHAwAQBVQAKBIgJA6QABAIgKAFQgKAFgBAGQgDAVAHAOQAEAKAMALQgMAJgfAEQgcADgNAMIgSABQgbAAgkgFgADFimQgOAJgGAUQAqBvgCBsQgMAMgCAZQgDAjgDAIQATAhAlgJQAmgKgBgqQgcgqgEhyQgEh0gUgfQgJgDgIAAQgLAAgJAGgAj9iaQgaADgIAaQABAfAQBlQAMBMgNA7QARAZAYAHQAKgCALgLQANgMAGgDQgEAAAAgGQAAgFAEgBQgzhFAXjCQgHgZgWAAIgGAAgAgVCcQADACAEAIQAIgEARgFQATgEALgHQgDgJAFgHQAGgHAAgFQgVgVgHgPQgLgmgEhXQgDhUgMgmQgOgIgPAHQgPAKgJADQABAEgGAeQgFAVAOAJQgFAOAGAPIALAXQAGAUAAAsQgBAqAHARQgHAGgNgCQAEAIgBAJIgDATQAOgEACAKQABAGgBAQIAIgBQAGAAADADg");
	this.shape_18.setTransform(44.5,-74.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#666666").s().p("AkEJYQAHgNgFgRQgIgUgCgKQAFgfgBh2QAAhsAMg0IAGjeQADh6AIhYQgMh9AsicQATgGANgUQAEgFAQghQA0giA6gOQBHgSA+AWQAEABADAGQACAHADACQAHAEAZAEQAUAEAIAIQADACANASQAJANALADQATA6AGBRQADAvAEBfQADAIgGADQgGAEABAFQgCAIAIADQAIACgCAHQACBcALCLIAUDhIgGARQgDALgDAEQAQBcgQA5QgCAJAIAHQAIAHgCAJIgYBAIAIAcQADAKABAOQhTgGitANQhqAIhNAAQgsAAgigDg");
	this.shape_19.setTransform(43.4,-161);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgLCeQgFgFgLADQABgQgBgGQgDgKgNAEIADgTQABgJgEgIQAMACAIgGQgHgRAAgqQAAgsgFgUIgLgXQgHgPAGgOQgOgJAEgVQAGgeAAgEQAIgDAQgKQAOgHANAIQANAmAEBUQADBXALAmQAIAPAUAVQAAAFgFAHQgFAHACAJQgKAHgTAEQgUAFgFAEQgEgIgEgCg");
	this.shape_20.setTransform(43.5,-74.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgfCFQANg8gMhKQgQhngBgfQAIgaAagDQAZgDAIAcQgVDDAxBFQgEAAAAAGQAAAGAEAAQgGADgNAMQgLALgKACQgWgHgRgZg");
	this.shape_21.setTransform(20.5,-73.6);

	this.addChild(this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-73,-228.6,234.2,474.4);


(lib.algodon = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAjBcIAMhiQADgXgHgOQgIgRgVgDQgOgBgMAHQgMAIgGANQgDAGgBAJIgOBmIgfgEIAQh9QAEgbAAgTIAcADIgCAcIABABQAJgMAPgIQAPgHAUACQAYADAOARQATAWgFAnIgNBlg");
	this.shape.setTransform(117.3,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLB7IgBgBQgjgEgVgbQgUgcAFgoQAFgoAcgWQAbgVAjAEQAlAFAUAbQAUAagFAnQgGAtgeAWQgWAQgaAAIgLgBgAghgQQgPAQgDAaQgEAdAMAUQAMAVAXADIAAAAQAVADARgRQASgRADgeQAEgZgKgSQgLgYgagDIgIgBQgSAAgPARgAgDhLIAjgwIAjAFIgyAtg");
	this.shape_1.setTransform(97.9,-5.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAhB9IACgeIAAAAQgKANgQAIQgPAIgUgDQgggEgSgbQgSgbAFgnQAFgoAagXQAZgXAhAFQARACANAKQAMAJAFALIAAAAIANhnIAgAEIgbDQQgDAYgBAVgAgmgSQgQARgDAbQgEAcALATQALAVAYADQAPACAOgJQAOgIAGgRQADgGAAgHIAEgeIABgOQgCgOgLgMQgLgMgRgCIgFAAQgUAAgOAOg");
	this.shape_2.setTransform(78.4,-8.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLBaIgBgBQgjgEgVgbQgUgcAFgmQAFgqAdgWQAagVAjAEQAlAFAUAbQAUAcgFAlQgGAtgeAWQgWAPgaABIgLgBgAghgxQgPARgDAbQgEAbAMAUQANAVAWADQAVADARgRQASgRADgeQAEgXgKgUQgLgYgagDIgHgBQgTAAgPARg");
	this.shape_3.setTransform(58.1,-7.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgfB9QgmgGgSgQIALgXQATAQAeAEQA2AHAHg9IADgTIgBAAQgUAbglgFQgfgEgSgbQgSgYAFglQAFgqAbgWQAZgVAeAEQAmAFANAfIAAAAIAFgZIAcADQgEAPgEAgIgNBjQgHA5gbATQgUAOgcAAIgQgBgAgfhWQgRAQgDAeQgEAaALARQAMAVAYADQANACANgHQANgIAHgOQADgFABgKIAEgfQABgHgBgHQgDgPgJgLQgLgLgRgCIgGgBQgRAAgOAOg");
	this.shape_4.setTransform(38.2,-6.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgeB8IAej7IAfAEIgfD7g");
	this.shape_5.setTransform(24.7,-15.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ABDB7IgQhPIhUgLIgiBJIgggEIBujkIAlAEIA0D5gAAHg3IgeBBIBGAJIgPhGIgGguIgBAAQgIAWgKAUg");
	this.shape_6.setTransform(8.1,-16.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("EADBAqtIg8gQQg8gjgkgrQgogygPhDQgXAfgjBJQgjA/gvATQgYACgegEIg6gHQgwgUghgtQgagkgWg9QgQAWgjA0QggAugbAZQhOBKhlghQgigdgRgZQgYgigEglQgBgGgGgHQgHgHgBgEQgMhAgEgeQgHgyAEgqQgMgBgNAOIgUAXIgYAWQgOANgFALIgxAmQgcAWgSATQg9AagdAHQg4AOg0gNQgLgHgjgRQgegNgPgMQgcgmgPgjQgJg3ANhJIAbhxIhSAEQgwABgggOQgegYAAhJQAGhUgDggQAIhAAlgwQAdglA2glIhNgKQgvgHgZgOQgug7gLgWQgag2AMg/QAYgUBahSQBFhAAxgjICKhBQBXgpAxgZQAfgCAYgQQBXgJApAAQAUhQANiEQANiTAJhHQACgqAKhXQAKhWACgvQADgGACgMIAEgTQgCgSAGgvQAGgtgDgSQAYhDADiJQgBgDAFgCQAFgBAAgDQAMiyArkTQA0k0AViOQAShYAZiiQAbi1AMhCQACgFgDgCQgEgDgBgCQALgcAHguQAJg+AEgQQglgxhDgzQhQg5gngdQiEiCgwisQgEgmAGg3QAIhEAAgVQBwk2F6g4QA4AHA5AdQAIgTAWgfQAXggAIgSQASgOAjgkQAjgjAWgQQAJgGAUgKQAXgLAJgGIA4goQAjgZAZgLQAHgDAWgEQATgDAHgGQEUAEAyCnQAEArAFASQASgGgCgTIBbhEQA7glA2gBQBkgCAxApQAyAqALBgQAagTAdgqQAog5AJgKQARgHAWgRIAlgZQA/gfA+gFQBKgFAzAjQAIAHAKAPIASAYQAmBzhWBsQgQAThABDQgxA0gVAjQBQABAsAGQBCAJAnAXQAoAyASAjQAbA1AAA2QgfA4gIALQgaAjggAOIAlARQAXALAQAFQA8AXAiBMQAUAtAdBkQgHAognAkQgwAtgKATQgeAPg9AHIAIBdQABA2gSAkQAAAGAFAGQAFAFgBAHQgWAKgsAIIhBANQgMgIgbgLQgdgLgLgHIgJBTQgFAvgIAiQgDBCgRCFQgSCMgEBAQgHBfgVC/QACAOgLgCQAIAggIA0QgLBHgBAQIABBGQgBAngMAZQgDBVgGBBQgDAggJA7QgKA+gDAbIgwGiQgCALACAVQABAWgBAKQgCAOgHAdQgIAcgCAOQgBATAAAlQAAAmgCATIgOCVQgHBZAABDQgCALgHANQAGAQgIAcQgLAkAAAOQAEAJASABQAOAAANgEQAZAFAtAFQAmAGAUAMQAEAFAGAPQAGAOAGAFQgYBWgyBSQAxgEApAFQA0AGAdAVIAJASQAHAIAIAEQATA/gQBUQgMBCgeBAIhiBWQg5AwgxAfQAFAMAPAVQAOAVAFANQAKA0gPA2QgLAkgdA1QgcAygYAgQgTAZgiAdQgtAmgJAJQg4AihfAEQhdAEhGgbQgnAthEAmQgoAWhaAmQgLACgLAAQgTAAgVgEgEgLeAkdQgCAGgLAKQgKAJgBAIQgLBxAaBUQAeBgBHAeQAJgCAPgBIAcAAQAJgDARgNQARgLALgDQAzhBATgdQAkg3AQgxQASgKAZAKQgBAJAGAHIAKALQgHAcARAnQAKAWAUAnQAhAeAwAMQA2AOAmgWIAzhRQAcgwAQgnQABgtAUgWQADAAADgDQANgBAKADIASAHIAMAiQAAAEgFAEQgFAEABAGIAABAQAJAbALASQAJANAXAYQAmAoAXAMQA3AdA6gLQAogIA/giQBHgnAbgcQgBgJABgcQAFgFAMgEIATgGQAWgoAFgrQAHg0gWgeIAcgdQARgSATAFQAFAxgMBDQgLBGgVAqQA0AbBSgEQBNgDA2gaQB/hpA4iOQAIhFgUglQgIgNgogSQgkgRgCgTQgCgQAQgKIAjgRQAEAAAIAGQAHAFAIgCQAjgJAfgaQAjghAVgRQArgiAYggQAcgmAMgxQAHgzAAgYQABgqgOgaQgXgag1gEQgrgDgxAMQgXAcgZAIIgdgFQgQgDgEgKQgDgPAAgGIADgVQBDgYAhg+QAUgjAGgUQALgfgJgSQgigPgcgEQgfgFgpAGQgIAEgPAMQgOALgJAEQgRgFgQgUQgUgZgIgFQgsAAiJgHQhygGhKAEQhugbjCAIQhNgNg+gDQhQgFhLAJIkBgmQiigZhdgNIhHgOQgrgHgaAJQgXgVgygEQg9AAgfgCQi1BAh0BEQiSBVhXBwQADAKgFAHQgGAKgBADQAKBQBIAeQA/AaBpgOQASgcAbAPQAbAOgCAgQgLAMgZAJIgrANQgVAOgkAeQglAfgTANQgcAvgIBDQgIBEAOBEIAXAMQANAGAMABQAWABBIgYQA3gTAcAXQAFASgPAVQgSAYABAQQgOACgCAOQgGAbgQAzQgMAvAEAtQADAIADAQIAGAZQAiAnAiARQAsAWA+gFQBRgVBKhGQBPhWArgnQgBgMAEgMQAGgPAAgHQAIAAAMgGQALgGAJAAQAZANAIAwgAMqWbQAAAFAFAAQAGgHgJgFQgDADABAEgAKYVeQCBAGA7gcQASg+AFhjQADhwAEg4IAFgaQAEgRABgJQANirAej6IAwmbQAynOAamFQAIgbAHg4QAGg4AHgXQAChMATirQADgEgFgIQgGgKACgIQAXgvgRggQgQgCgHgCQgMgEgLgIQgLAAgagDQgVgDgPADQgegGj/gqQiygdhiggQjxggingRQjngXi4gFQg3AJgTAQQgDAdgRBbQgOBJgCAzQgQA9gSCGQgEAjgNA9QgPBEgEAcQgFAegUCcQgOBwgQBAIgPA/QgIAlgBAcQgKAsgIBbQgIBggIAoQhWKYghG5QgJAagEAwIgFBCQAEACAPgBQAMACgBAMQAtALBKAJQBgAMAaAEICuAiQBnATBJAFQAcACA5gCQA5gCAdACIBUAJQA1AFAgACQA3ACBrAAQBeACBAAOQAMgBAdAAQA3AABwAFgASfznQAQAQAGADQAeANAkgFQAggEAYgRQAGgtAJgfQgHgpgHgRQgMgdgZgHQAGgGgDgDIgJgHQADgnAqgJQANADAMAIIAVAQQARABAUgJQAWgKAOAAQArg/AegaQgHgrgNgrIgchOQg5hFhsgKQgJAIgNgBIgegEIgKgQQgEgKgBgLQALgYAQgGQA0ACAngnQAngnABg3QgGgJgCgLQgDgMAFgLQgkhZh0gVQgOADgugBQgqAAgUAHQgGADgSANQgOAKgIgBQgNgDgHgSQgEgJgGgZQAFgDABgJQAJAAAIgJQAJgJAIAAQALgSAggkQAdgiANgWIAkgdQATgSAJgUQADAAAEgCQADgDAFACQAVgnAJgVQAQgkADgjQgEgfgDgOQgGgagPgMQgKgIgXgHQgdgIgIgEQgdAIgTgFQg0AYgxANQhVA7hDB7QgEAFAEAHQAEAHgEAGIgSATQgKAMgMACQghgLgTgfQALgPAEgKQADgvgLgnQgKgggVgfQgIgCgLgHQgLgHgHgCIhXgGQgqgBggANQgdASgeAdQgQAPgmAmQgBAIgGAKQgHALgBAFQADAYgDANQgEAOgPANQgSAFgOgCQgMgBgQgIQAFgLgIgLQgJgMAFgMQABgDAKgCQAJgBgBgGQALgegIgtIgShKQg0hNiGgVIhZAAQgZAIgOABQgUAPhiA+QhMAvgnApQgfAfgPAYQgUAggHAmQAIAKAWANQAXANAIAJQgIAjgXALIgbAAQgDgJgJgLQgKgMgDgHQgJgCgRAAQgLAAgFgFIgHgKQgFgHgDgKIgsgPQgZgIgXgBQgpgChAAYQhNAdgWADQh1BJg4BGQhMBggHCIQADBEAcBGQASAqArBJQAkAnBMBKQAeANA4AtQA0ApAnAOQAZgIAIgBQBVAWDPAHQDaAIBZARQAKACALgFQAbAKBAAFQBDAFAZAIIAoAAQDaAyCvAjQA0AABiAPQB8ATAhADQAAgQAHgGQAYgLAWAOQAWAPAFAfIABAAQAKAAAMAMg");
	this.shape_7.setTransform(44,8.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EAE6E4").s().p("Ao7JGQgahVALhwQABgJAKgJQALgJACgHQgIgvgZgOQgJABgLAFQgMAGgIABQAAAHgGAOQgEANABALQgrAnhPBWQhKBHhRAVQg+AFgsgXQgigQgignIgGgZQgDgQgDgIQgEgtAMgvQAQgzAGgcQACgNAOgCQgBgQASgYQAPgWgFgRQgcgXg3ATQhIAYgWgCQgMgBgNgFIgXgMQgOhEAIhEQAIhCAcguQATgOAlgfQAkgdAVgPIArgNQAZgIALgMQACgggbgPQgbgOgSAbQhpAOg/gaQhIgdgKhQQABgDAGgKQAFgIgDgKQBXhwCShVQB0hDC1hBQAfACA9ABQAyADAXAVQAagJArAHIBHAPQBdAMCiAZIEBAnQBJgJBQAEQBAAEBNANQDCgJBuAbQBKgDByAGQCJAGAsAAQAIAFAUAaQAQATARAFQAJgEAOgLQAPgLAIgEQApgGAfAEQAcAEAiAQQAJARgLAfQgGAUgUAkQghA9hDAYIgDAWQAAAFADAQQAEAJAQAEIAdAFQAZgJAXgcQAxgLArADQA1ADAXAbQAOAZgBAqQAAAZgHAzQgMAwgcAmQgYAggrAgQgVASgjAgQgfAbgjAJQgIABgHgFQgIgFgEgBIgjARQgQALACAPQACAUAkAQQAoATAIAMQAUAmgIBFQg4COh/BpQg2AahNADQhSADg0gaQAVgrALhGQAMhCgFgyQgTgEgRASIgcAdQAWAdgHA0QgFArgWAoIgTAHQgMADgFAGQgBAbABAJQgbAchHAnQg/AjgoAHQg6ALg3gcQgXgMgmgoQgXgYgJgNQgLgSgJgcIAAg/QgBgHAFgEQAFgEAAgEIgMghIgSgIQgMgDgNACQgDADgDAAQgUAVgBAuQgQAngcAwIgzBQQgkAWg2gNQgwgMghgeQgUgogKgWQgRgnAHgbIgKgLQgGgHABgKQgZgKgSAKQgQAxgkA3QgTAdgzBBQgLADgRAMQgRAMgJAEIgcAAQgPAAgJADQhHgegehgg");
	this.shape_8.setTransform(26.8,206.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EAE6E4").s().p("ANzLQQgGgDgRgQQgLgMgLABQgGgggVgOQgWgPgYAMQgHAGAAAPQghgDh9gTQhhgPg0ABQiwgkjagyIgnAAQgYgIhDgFQg/gEgbgKQgLAFgKgCQhZgSjcgHQjPgIhVgWQgJABgYAIQgngNg0gpQg4gtgegOQhMhKglgmQgqhJgSgrQgdhGgChBQAHiIBMhgQA4hHB1hIQAWgEBNgdQBAgXApABQAXABAZAIIAsAPQADALAFAHIAGAKQAGAEALAAQARAAAJACQADAIAJAMQAKALADAJIAbAAQAXgMAHgiQgHgJgXgNQgWgNgJgLQAHgmAVggQAPgXAfggQAngoBLgvQBlg+AUgPQAOgBAZgIIBZAAQCEAUAzBNIASBLQAJAsgMAeQABAHgIABQgKABgBAEQgFALAIAMQAIAMgEAKQAPAIANACQAOACASgGQAOgMAFgOQADgOgDgYQABgEAHgMQAGgJABgIQAmgnAPgOQAfgdAdgTQAfgNArACIBXAFQAHACALAHQALAHAIACQAUAfAKAhQAMAngDAvQgEAJgLAPQASAfAiAMQALgDALgLIASgUQAEgGgEgHQgFgGAFgFQBDh7BVg8QAwgMA1gYQATAEAdgIQAIAEAcAJQAYAGAKAJQAPAMAFAZQAEAPAEAeQgDAjgQAkQgJAVgVAnQgFgBgDACQgEADgDgBQgJAUgTASIgkAdQgNAXgdAhQggAkgMASQgHABgJAJQgJAIgIAAQgCAKgEACQAGAaADAJQAIARANADQAHACAPgKQARgOAHgCQAUgIApABQAvABAOgDQBzAVAlBZQgFAKADANQACAKAGAJQgCA1gmAnQgnAog0gDQgQAGgLAZQABAKAEAKIAKAQIAeAEQANABAJgIQBsAKA5BFIAcBPQANAqAHAsQgeAZgrA/QgPABgVAJQgUAJgRAAIgVgQQgNgJgMgDQgqAJgDAoIAJAHQADACgHAGQAaAIALAcQAIARAHAqQgJAegGAuQgZAQggAEIgTABQgZAAgVgJg");
	this.shape_9.setTransform(76.2,-187.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgCABQgBgCADgEQAHAFgGAGQgDgBAAgEg");
	this.shape_10.setTransform(125.4,151.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#047391").s().p("AIIV8QisgHglAEQg/gOhegCQhsAAg1gDQgggBg1gGIhVgIQgdgCg5ACQg5ACgcgCQhJgFhogUIitghQgbgFhfgLQhLgJgsgLQAAgNgMgBQgOAAgFgCIAGhBQADgxAKgaQAgm4BXqaQAHgmAJhgQAIhbAJgsQACgdAHgkIAPg/QAQhAAPhxQATibAFgfQAFgbAOhFQANg9AFgjQASiGAPg9QADgzANhJQARhbAEgdQATgQA2gIQC5AEDpAYQClAQDxAgQBhAgCzAeQD+ApAfAHQAPgDAUADQAbADALAAQAKAIAMADQAHACAQACQARAhgXAuQgCAIAGAKQAFAJgDAEQgTCqgCBNQgGAXgHA4QgHA4gHAaQgbGFgyHOIgwGbQgdD6gOCrQAAAJgEARIgFAaQgFA5gDBwQgFBigSA+QgwAXhgAAIgrgBg");
	this.shape_11.setTransform(58.4,5.4);

	this.addChild(this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-113.1,-265.2,314.3,547.5);


(lib.alcohol = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgPCAIAAj/IAfAAIAAD/g");
	this.shape.setTransform(84.6,18.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAABaQgkABgYgYQgXgaAAgoQgBgpAagZQAYgYAjgBQAlAAAXAaQAYAYAAAoQAAArgcAaQgYAWghgBgAgngsQgNASAAAaQAAAdAPATQAPATAWAAIAAAAQAWAAAPgTQAPgTAAgdQAAgYgMgUQgOgVgaAAQgYgBgPAWg");
	this.shape_1.setTransform(70.5,22.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAqCAIAAhlQAAgxgoAAQgNAAgMAJQgLAIgFAMQgCAGAAAJIAABqIggAAIAAj/IAgAAIAABtIABAAQAIgOAPgIQAOgJAQAAQAXAAAQAPQAWATAAAmIAABpg");
	this.shape_2.setTransform(50.6,18.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAABaQgkABgYgYQgYgaAAgoQAAgpAagZQAYgYAjgBQAlAAAYAaQAXAYAAAoQAAArgcAaQgYAWghgBgAgngsQgNASAAAaQAAAdAPATQAPATAWAAIAAAAQAWAAAPgTQAPgTAAgdQAAgYgMgUQgOgVgaAAQgYgBgPAWg");
	this.shape_3.setTransform(30.7,22.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgsBCQgXgYAAgoQAAgnAZgaQAagaAogBQAcAAAQAKIgHAYQgQgIgVAAQgbgBgQAUQgQATAAAaQAAAeARASQARARAYAAQAVAAASgIIAFAXQgUAKgeAAQglAAgYgYg");
	this.shape_4.setTransform(13.2,22.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgPCAIAAj/IAfAAIAAD/g");
	this.shape_5.setTransform(0.7,18.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ABEB5IgahMIhUAAIgaBMIggAAIBSjxIAkAAIBTDxgAgMgxIgYBFIBHAAIgYhEQgFgPgGgdIAAAAQgGAZgGASg");
	this.shape_6.setTransform(-14.3,18.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("Agtc/IgaAAIAAgcQApAAAmgFQBSAKB6gOIDNgVQA7AABegUQBrgWAugDIAdgJQASgEAIgHQASAAAZgGQAcgGAOAAQAdgQAOgJQAEgWgFghIgHg4QAAgIADgSQADgRgBgJIgEgXIgDgWQgCgWABgpQgBgqgBgVQgDgzAIiLQAHh4gMhEIAFioQAEhxgChCQABgXgIgMQAFgOAAgiQABgkAEgQQgJhZgDh4IgBjRQAAgJAFgRQADgSAAgJQABgZgDgnIgDhEQAHgRgDgiQgCgiAFgUQgFglgCgyIgFhgQAFgLADgOQADjTgVh6QgeishVhSIgKAAIgKAAQg0g2gpgeQgggJgtgUIhMgiQgGgBgMgDQgLgCgJABQgDgFgMgGQgLgHgEgFQg/AChqAKQiFANgnADQhVAGgsABQhJACg2gFQipgNhmgvQgcgIgRgCQgBgFgGgCQgSABgZAJQgbAJgQABQgCAGgKAIQgKAHgDAHQgZAFghAaQgiAbgXAHQgHAMgOAOIgYAVQgNAVgaAwQgZAugOAYQgPAbgNAyQgSA9gHATQgCAxgNByQgKBmAIA9IAPgEQAKgDACgFQAGAIATADQAYAFAGAEQAsgJA8AHIBkAMIBAgBQAkgBAWAHQBQAHBrABIC5AAQAqgBBRAEQBSAEApAAQBMAACbAJQCLAEBZgNIAUAAQAMAAAFADIAagIQASgCAMAEQAGABAIgFQAHgFAJACIAWARQAOAKAHALQgCAIgGAQQgIAQAAAHQgDAmABBWQAABdgDAsIgNDGIgZgBQAIjfAFh3QABgagGg2QgFgzADgcIgoAEQgVABgRgCQg9ANhlAAQg1gBh7gHQgwgDhqAAQhhAAgxgFQg7gEi7ADQibADhagQQgFAEgQAAQgTACgFABQgpgLhQgCQhWgBghgGQg0AAg7APQgFA2AABDIACB/QABAuAFBPIABBuQACBJAHAsQgKBzACDKQACD2gCA/IgZADQAAgCgEgEQgEgDAAgEQABgCADgIQACgGgBgDQgJiAADj8QAFkTgGh7QgIggADg/QAChIgFggQgDgXAChBQADg7gGgaQAMhlAAiQQAAgcAGgqIAJhEIABgdQAAgSABgLQACgIAGgPIAKgYIAUhFQANgnAMgUQgDgFACgGIABgMQAKgHAMgVQALgXAKgGQADgLAOgUQALgTAEgNIA8gwQAjgdAhgLIAQgRIARgSQARAAATgQQAVgSALgDQAFgCAMAAIASgBQAFgCAIgFQAKgHAEgBQAIgCAVAAQASAAALgGQABgIgCgLQgCgLABgHQAJgtgBhHQgEhPAAgnQgBgDgHgJQgGgHAAgIQAGgHgDgKIgDgQQAEgDAAgEQABgGgEgOQgEgOAAgGQgGhqAXg0QAZgRAZgLQARAHAqgGQAogFARAJQAKgFAZgBQAeAAAPgEQAqAFA8gDQAbgCBNgIQgBgEAJAHQAmgBBVAGQBSAFAugDQAVAJAZADQAfAFAUgHIAtATQAZANADAYQgSAYAhAUIA3AhQgDAOAAAdQgDAXgQAHQggAAgVAQQgDAfAZAGIgFAUQgEAMgIADQAJAHgCAXQgIAhAFBGQADAmAIBJQgKAhAPAsIAWAAQAWARAuAOQBEASAHADQAFAKALALIARASQAbAGAdATIAvAiQAFAVASAQQALAKAYAQQATAwArAqQADALAEAiQAEAdAGAQQACAGgCAFIgCAKQAHAOAKAtQAKAnALARQgMAtAGBFIAJBzQgFAKgDAdQAFARgBAdQgBAiACANIAABiQABBBgBAoQgCBQAAATQAAA0AHAmQgMAiAABAIAEBpQgKAPADAZIAFAvIgBAoQAAAUAJAOQgEBFAACNQAACGgEA+IACAFQADAEAAADQgDBJgCATIAEAKIAEALQgHCjgBFhQADAFACANQACANADAFQgIAtAIA9QAFAkANBOQgBACgGABQgFAAACAEQgGAEgGgDQgIgDgFAAQgDAGgPgBQgPAMgiAKQgtALgJAFQg/AGidAdQiNAZhTAFIgdAAQgSgBgKABQgPACgbAGQgcAFgNACQgrAFhCAAQhCAAhZgFgAk6y1IADAIQAsAIBMAGIB+ALIB9gLIB8gLQAXgDAtAAQAngBAXgLQATADAVgDQAOgDAWgHQAFgJAHgPIAMgYQABgrgGheQgGhmgBgtQg5gNh2ACQiJACgdgDQgxAAhWAJQhcAIgoABIhKgFQgsgCgbALQgFAAgUgHQgPgFgHACQAFAOgBAYQABAWAEAJQgHAdACA/QACBAgJAnIAEAgQACAQgDAOQANAEAXAKQAUAGAVgEIACgBQAEAAABAFgAj144QAXABAQAFQAagCAngBIBCgBQAwgNBNAEQByAEAUgBIBtAAQBJgBAigBQABgPgBgJQgCgGgGgNIgCgFIABgFQABgGADgEQAJgLAXgDQAMgCAUgBIgCgCQgFgFgPgCIgZgEQgHgBgJgKQgHgJgKAAIADgZQACgNAIgHQgBgLgIgIQgKgIgEgFQkDgkkJAZQgwgBg5ADIhnADQgEADgLAFQgKADgDAFQgLAMgJACQAAAOgDAbIgCAjQAQAMAAAcQgBApAFAOQAKACAKgCIAUgFQAOAHAUABQAWABARgHQAOAEAYAAg");
	this.shape_7.setTransform(44,8.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D3D2D1").s().p("AivXwQhLgEgjgBQgxgNhrADQh2ADgvgIQgIgBgdgIQgVgHgMADIg6gVQghgMgbABQgSgLgfgKIgxgOQgIgYAGhMQACgfgFgyQgHg9AAgVIgBi2QAAhmADhIQAkAOBLAGQBVAGAgAJQB3AKCygBQBmgBDGgDIBDACQAoACAYgBQAegCCgADQByACBIgQQAnAFA5gHIBcgNQA7gGAigJQgCgGAEgEQADgFAAgDIgNgcQgGgOgBgNQAIgSAAgUIgDgoQgBgHADgPQADgQAAgHQAAgHgFgOQgFgOAAgHQAAghACgtIAFhOQgFgFAAgNQgBgNgGgEQAHgDAAgKIgCgRIAAgRIAHhlQAGgcgBgzQgCg8ACgWIAFgUQADgOAAgIQABgggEg/QgDg+ABggIAMjIQADgsAAhdQgBhWADgmQABgHAHgQQAGgQACgIQgGgLgOgKIgXgRQgJgCgHAFQgHAFgHgBQgMgEgRACIgaAIQgGgDgMAAIgUAAQhYANiLgEQicgJhMAAQgpAAhSgEQhRgEgqABIi5AAQhqgBhQgHQgXgHgkABIhAABIhkgMQg8gHgrAJQgHgEgYgFQgTgDgFgIQgDAFgKADIgPAEQgHg9AJhmQANhyADgxQAHgTARg9QANgyAPgbQAPgYAYguQAagwANgVIAZgVQANgOAHgMQAXgHAigbQAigaAZgFQACgHAKgHQAKgIADgGQAQgBAagJQAagJARgBQAGACABAFQASACAcAIQBlAvCpANQA2AFBJgCQAsgBBWgGQAmgDCFgNQBrgKA/gCQADAFALAHQAMAGAEAFQAJgBAKACQAMADAGABIBMAiQAtAUAgAJQApAeA0A2IAKAAIAKAAQBWBSAdCsQAVB6gDDTQgDAOgFALIAFBgQACAyAGAlQgGAUADAiQACAigHARIAEBEQACApgBAZQAAAJgDASQgEARAAAJIABDRQACB2AJBZQgEAQgBAkQAAAigFAOQAIAMAAAXQABBCgEBxIgFCoQAMBEgHB4QgICLADAzQACAVAAAqQgBApACAWIAEAWIADAXQABAJgDARQgDASAAAIIAHA4QAFAhgEAWQgNAJgeAQQgOAAgcAGQgZAGgSAAQgIAHgSAEIgdAJQgtADhsAWQheAUg7AAIjMAVQh7AOhSgKQgmAFgpAAQglAAhGgFg");
	this.shape_8.setTransform(43.7,38.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgQD3QgIgPAEglQAGgqABgRQgBgJADgtQADgigIgTIAKkTIAXABQgBAfAEA+QADA/gBAiQAAAIgDAOIgEAVQgCATABA9QACAzgGAbIgHBlg");
	this.shape_9.setTransform(113,46.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AjiJdQixgKhiABQiqgvgkgLQgSAAgXgFIgkgKQgBADACAGQACAEgGAAIgPAAIgMACIgHgPQgDgJgFgGIAJggQAFhcgFgzQgCgeAAgtIAAhMIgEkXQgBidAFh0IADgNIACgJIAZgDQAHAjgCBHQgCBPACAaQAbAKArAGIBMAJIBJAMQAwAIAkADQAlACBEgBQBLAAAhABQBLADBggBICzgCQBVgBCxADQCfABBpgNQAWgKA1gFQA7gEATgGQALgOALgGQAAgLAGhbQADg9gLgmQAIgkgCg7IgBhdIgBgTQAAgMAIgEIAVABIgBARIADAQQAAALgHADQAGAEABANQAAANAFAFIgFBOQgDAtAAAgQABAIAFAOQAEAOAAAHQABAHgDAPQgDAPABAIIACAoQABATgJATQABANAHAOIANAcQgBADgDAFQgDAEABAGQghAJg7AGIhdANQg5AHgmgFQhIAQhzgCQiggDgdABQgZACgpgCIhDgCQjEADhmABQizABh2gKQgggJhVgGQhLgGgkgOQgDBIgBBkIABC1QABAWAGA8QAGAzgDAeQgFBMAIAZIAxAOQAfAKASALQAagBAiALIA6AWQAMgDAUAGQAdAJAJABQAvAIB2gDQBrgDAxANQAjABBKAEQBFAFAlAAIAAAcIgJAAQhZAAitgJg");
	this.shape_10.setTransform(32.2,132.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3F3F3F").s().p("AjFC4QhNgGgrgIIgDgIQgCgGgFACQgVAEgVgGQgWgKgOgEQAEgOgCgQIgEggQAJgngCg+QgCg/AHgdQgFgJAAgWQABgYgGgOQAIgCAPAFQAUAHAFAAQAbgLAsACIBKAFQAogBBcgIQBWgJAxAAQAcADCKgCQB2gCA5ANQAAAtAHBmQAGBcgBArIgMAYQgHAPgGAJQgVAHgOADQgWADgSgDQgXALgnABQgtAAgYADIh8ALIh8ALIh+gLg");
	this.shape_11.setTransform(44.6,-128.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#666666").s().p("AkKBpQgZAAgNgEQgRAHgWgBQgVgBgNgHIgUAFQgKACgKgCQgFgPABgoQAAgdgQgLIACgiQADgaAAgOQAJgDALgMQADgEAKgEQALgEADgDIBogEQA5gCAvABQEKgaEDAkQAEAGAKAIQAIAIABALQgIAHgCANIgDAZQAKgBAHAKQAJAIAHABIAYADQAPACAGAGIACACQgUABgNACQgWADgJALQgDAEgCAFIgBAGIACAEQAHAOABAGQACAJgCAPQghABhJAAIhuABQgTABhzgFQhNgDgvAMIhCACQgnABgaACQgRgFgWgBg");
	this.shape_12.setTransform(46.1,-161.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#F4E3D3").s().p("AkTLvQgigChKABQhFAAgkgCQglgCgwgIIhJgMIhMgJQgrgGgbgLQgCgZAChQQAChGgHgjQAChAgCj2QgBjIAJhzQgGgsgChJIgChvQgEhQgBguIgDh/QAAhDAFg2QA7gPA0AAQAhAGBXACQBPABApALQAFgBATgBQAQgBAFgEQBaAQCbgDQC5gDA8AFQAyAEBhAAQBqAAAwADQB7AHA2ABQBkAAA9gNQASADAUgCIAogDQgDAbAGAzQAFA3gBAZQgFB4gIDhIgJETQAHATgCAiQgEAtABAJQgBARgGAqQgDAlAIAPQgJADAAAMIABAUIABBcQACA7gIAlQALAmgDA9QgGBbABAKQgLAHgMANQgTAGg7AFQg1AEgWALQhpAMifAAQixgDhVABIizACIgfAAQhNAAg+gCg");
	this.shape_13.setTransform(32.7,43.9);

	this.addChild(this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-51.8,-177.5,191.8,372);


(lib.agua = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgkAyQgJgJAAgOQAAgpBEAAIAAgDQAAgbgZABQgRAAgNAIIgFgOQARgKAUAAQAsAAAAAwIAAApQAAARACALIgTAAIgCgPIgBAAQgMARgVAAQgRAAgKgKgAgYAZQAAAUAUAAQAJAAAIgGQAHgGACgIIABgGIAAgTIgDAAQgsAAAAAZg");
	this.shape.setTransform(109.1,42);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgnBGQgOgRAAgaQAAgbAPgRQAPgRAVAAQAYAAAJASIABAAIAAhFIAWAAIAACKIABAfIgTAAIgBgVIgBAAQgLAXgbAAQgVAAgOgQgAgXgEQgJAKAAAUQAAATAJAMQAJAMAPAAQAKAAAJgHQAJgGACgMIAAgmQgCgIgIgIQgJgHgLAAQgOAAgKANg");
	this.shape_1.setTransform(96.5,39.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgkAyQgJgJAAgOQAAgVASgJQASgLAgAAIAAgDQAAgbgZABQgRAAgNAIIgEgOQAQgKAUAAQAsAAAAAwIAAApQAAARACALIgTAAIgCgPIAAAAQgNARgVAAQgRAAgKgKgAgYAZQAAAUAUAAQATAAAHgUIABgGIAAgTIgDAAQgrAAgBAZg");
	this.shape_2.setTransform(84,42);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAdA7IAAhBQAAgigcAAQgHAAgIAGQgIAGgDAJIgBAKIAABEIgWAAIAAhSIgBggIATAAIABATIABAAQAFgJAJgGQALgHAMAAQAPAAALAKQAOANAAAaIAABEg");
	this.shape_3.setTransform(71.9,41.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgjAsQgPgQAAgaQAAgZAPgSQAPgSAXAAQAZAAANATQAKAPAAAUIgBAJIhPgBQAAAVAMAKQAKAKAPAAQARAAAPgGIAEAPQgQAHgXAAQgYAAgQgQgAgUggQgHAJgCANIA7AAQABgNgGgJQgIgMgQAAQgMAAgJAMg");
	this.shape_4.setTransform(59.2,42);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgrBLIAFgQQAPAIAUABQAjAAAAgpIAAgNQgMAUgXAAQgWgBgOgQQgOgQAAgWQAAgdAQgRQAPgQAWAAQAXAAALAUIAAAAIABgRIATAAIgBBhQAAAmgRAPQgPAOgZAAQgZAAgOgJgAgWg2QgKALAAAVQAAARAJAKQAKAMAOAAQAKABAIgGQAIgGADgIQACgFAAgGIAAgWIgBgJQgHgWgXAAQgNAAgKAMg");
	this.shape_5.setTransform(46.1,44.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgJBSIAAhyIATAAIAABygAAAg2QgFAAgDgEQgEgDAAgGQAAgGAEgEQAEgEAEAAQAFAAAEAEQAEAEAAAGQAAAGgEADQgEAEgFAAg");
	this.shape_6.setTransform(37,39.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAdA6IgdgvIAAAAQgEAJgIAMIgRAaIgWAAIAog6Igng4IAYAAIAaArIABAAIAcgrIAWAAIgnA4IApA6g");
	this.shape_7.setTransform(28.6,42);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAABTQghAAgUgXQgTgWAAglQAAgkAUgYQAWgXAeAAQAiAAATAXQAUAXAAAkQAAAmgVAXQgWAWgeAAgAglgtQgNAUgBAaQAAAbAOASQAPAUAWAAQAXAAAOgUQAOgSAAgcQAAgagNgSQgOgVgYAAQgXAAgOAUg");
	this.shape_8.setTransform(14.9,39.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgkAyQgJgJAAgOQAAgVASgJQASgLAgAAIAAgDQAAgbgYABQgSAAgNAIIgFgOQARgKAUAAQAsAAAAAwIAAApQAAAQACAMIgTAAIgCgPIgBAAQgMARgVAAQgRAAgKgKgAgYAZQAAAUAUAAQAJAAAIgGQAHgGADgIIAAgZIgDAAQgsAAAAAZg");
	this.shape_9.setTransform(81.1,13.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgiAxQgOgNAAgcIAAhCIAVAAIAAA+QAAAlAaAAQASAAAIgTQACgFAAgGIAAhFIAVAAIAABTIABAfIgTAAIgBgTIAAAAQgMAWgZAAQgRAAgJgKg");
	this.shape_10.setTransform(69.1,13.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgqBLIAEgQQAPAIAUABQAjAAAAgpIAAgNIgBAAQgKAUgYgBQgWABgOgRQgOgQAAgWQAAgdAQgRQAPgQAWAAQAYAAAKAUIAAAAIABgRIATAAIgBAgIAABBQAAAmgQAPQgQAOgZAAQgaAAgMgJgAgVg3QgLAMABAVQgBARAKAKQAJAMAOAAQAKABAIgGQAIgGADgIQACgFAAgGIAAgWQAAgEgBgFQgHgWgXAAQgNAAgJALg");
	this.shape_11.setTransform(55.4,15.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAtBQIgRgzIg4AAIgRAzIgVAAIA3ifIAXAAIA3CfgAgIggIgPAtIAuAAIgQgsQgFgPgCgPIAAAAQgDARgFAMg");
	this.shape_12.setTransform(42,10.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("Ajac/QgOgCgcgFQgbgGgNgCQgLgBgSABIgeAAQhSgFiOgZQidgdg+gGQgJgFgugLQghgKgPgMQgPABgCgGQgGAAgIADQgGADgFgEQAAgEgEAAQgGgBAAgCQAMhOAFgkQAIg9gIgtQACgFADgNQACgMADgGQgBlhgHijIAEgLIAEgKQgCgTgDhJQAAgDADgEIACgFQgEg+AAiGQAAiNgEhFQAJgOAAgUIgBgoIAEgvQADgZgJgPIAEhpQAAhAgMgiQAHgmAAg0IgChjQgBgqAAg/IABhiQACgNgBgiQAAgdAEgRQgDgdgFgKIAJhzQAFhFgLgtQALgRAKgnQAJgsAHgPQgCgOAAgHQAGgQAEgdQAFgiACgLQAqgpAVgxQAYgQALgKQASgQAFgVIAvgiQAcgTAcgGIARgSQALgLAFgKIBLgVQAugOAVgRIAXAAQAPgrgKgiQAIhJADgmQAFhGgJghQgBgXAJgHQgIgDgEgMIgGgUQAZgGgCgfQgVgQggAAQgRgHgCgXQABgdgFgOQANgLArgWQAggUgRgYQADgYAYgNQAOgHAfgMQAVAHAfgFQAYgDAWgJQAuADBRgFQBWgGAmABQAJgHgBAEIBoAKQA7ADArgFQAPAEAfAAQAYABAKAFQARgJAnAFQAqAGASgHQAWAKAbASQAYA0gGBqIgEAUQgEAOAAAGQABAEAFADQgBAFgEALQgCAKAHAHQgBAIgGAHQgHAJgCADQABAngDBPQgCBHAKAtIgCASQgCALABAIQAKAGASAAQAVAAAJACQAEABAJAHQAJAFAFACIATABQAKAAAHACQAJADAWASQATAQARAAIAQASQAMAKAEAHQAhALAkAdQA0AsAHAEQAEANAMATQANAUAEALQAKAHALAWQALAVALAHIABAMQABAGgCAFQANAUAMAnIAUBFIAKAYQAGAPACAIQACAKAAATQgBAVABAIIAJBEQAGAqAAAcQgBCNAOBoQgIAbADA6QADBCgEAWQgEAgACBIQADA/gIAgQgGB8AEESQADD9gIB/QgBAEADAFQACAIAAACQABAEgEADQgDADgBADIgZgDQgDg/ADj2QABjKgJhzQAHgsABhJIAChuIAFh9IADh/QABhDgHg2Qg6gPgzAAQgiAGhWABQhQACgpALQgFgBgTgCQgQAAgGgEQhZAQibgDQi7gDg8AEQgwAFhhAAQhpAAgxADQh7AHg2ABQhjAAg+gNQgSACgUgBIgogEQADAdgFAyQgHA4ABAYQAJC6AECcIgZABIgGhkIgHhiQgCgqABhfQgBhVgCgnQgBgHgGgQQgIgQgBgIQAGgLAOgKIAXgRQAJgCAGAFQAIAFAHgBQAMgEARACIAaAIQAGgDAMAAIAUAAQBYANCMgEIDngJQApAABRgEQBRgEArABIC4AAQBrgBBQgHQAWgHAmABIA/ABQAjgCBCgKQA6gHAsAJQAHgEAZgFQASgDAFgIQADAFAKADIAPAEQAHg9gKhmQgMhygDgxQgGgRgSg/QgOgxgOgcQgPgYgZguQgZgwgNgVIgZgVQgOgOgGgMQgYgHghgbQgigagZgFQgCgHgKgHQgKgIgCgGQgRgBgagJQgbgJgQgBQgFACgDAFQgKABgMAEIgXAFQhlAviqANQg1AFhJgCQgsgBhWgGQgmgDiGgNQhqgKg+gCQgFAFgKAHQgMAGgEAFQgIgBgMACQgLADgHABIhLAiQgsAUghAJQgnAcg2A4IgKAAIgKAAQhVBSgeCsQgWB6AEDTIAIAZIgFBgQgDAwgFAnQAFAUgCAiQgCAiAGARQAAAVgCAvQgDAoAAAYQABAIAEATQADARAAAJIgBDRQgCB5gJBYQAEAQAAAkQABAiAEAOQgHANAAAWQgBBBAEByQAECCAAAmQgLBEAHB4QAICLgEAzQgBAVABAqQgBApgBAWIgEAWQgDAPAAAIQgBAIADASQADASgBAIIgGA4QgFAhAEAWQANAJAdAQQAOAAAcAGQAbAGARAAQAIAHASAEIAdAJQAuADBrAWQBeAUA7AAIDMAVQB7AOBRgKQAoAFAoAAIgBAcIgaAAQhYAFhCAAQhCAAgrgFgAj7ytIBEADQBWAICjAOIB+gLQBMgGArgIIADgIQACgGAFACQAWAEAVgGIAkgOQgEgOACgQIAEggQgJgnAChAQABg/gGgdQAEgJAAgWQAAgYAGgOQgJgCgPAFQgTAHgGAAQgbgLgrACQgyAFgZAAQgngBhcgIQhWgJgxAAQgdADiJgCQh2gCg5ANQgBArgGBoQgGBdAAAsIANAYQAHAPAFAJQAWAHAOADQAWADASgDQAXALAnABgABM42IBCABQAnABAZACQARgFAXgBQAYAAAOgEQARAHAVgBQAWgBAMgHIAUAFQALACAKgCQAEgOAAgpQAAgcAQgMIgDgjQgCgaAAgPQgJgCgLgMQgEgFgKgDQgKgFgEgDIhngDQg5gDgwABQkKgZkDAkIgNANQgJAIAAALQAIAHACANIACAZQgKAAgHAJQgHAKgIABIgaAEQgRACgFAHIAqAEQAbAHABAVQgHAQgCAFQgDAKADARQAhABBJABIBtAAQATABB0gEIAggBQA3AAAlAKg");
	this.shape_13.setTransform(44,0.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#DDBE6F").s().p("AgLXwQhRAKh7gOIjMgVQg7AAhegUQhsgWgtgDIgdgJQgSgEgIgHQgSAAgagGQgcgGgOAAQgdgQgNgJQgEgWAFghIAGg4QABgIgDgSQgDgSAAgIQABgIADgPIAEgWQABgWAAgpQAAgqABgVQAEgzgIiLQgHh4ALhEQAAgmgEiCQgEhyABhBQAAgWAHgNQgEgOgBgiQAAgkgFgQQAKhYACh3IABjRQAAgJgEgRQgDgTgBgIQAAgYACgqQADgvAAgVQgGgRACgiQACgigFgUQAFgnADgwIAEhgIgHgZQgEjTAVh6QAeisBWhSIAJAAIALAAQA2g4AngcQAggJAtgUIBLgiQAHgBALgDQALgCAJABQAEgFALgGQALgHAEgFQA/ACBqAKQCGANAmADQBWAGAsABQBJACA1gFQCqgNBlgvIAWgFQANgEAKgBQADgFAFgCQAQABAbAJQAaAJAQABQADAGAKAIQAKAHACAHQAZAFAhAaQAiAbAYAHQAGAMAOAOIAZAVQANAVAZAwQAZAuAOAYQAPAcAOAxQARA/AHARQADAxAMByQAKBmgIA9IgOgEQgKgDgDgFQgFAIgTADQgYAFgHAEQgsgJg7AHQhCAKgiACIhAgBQglgBgWAHQhQAHhrABIi4AAQgrgBhRAEQhRAEgpAAIjoAJQiLAEhYgNIgUAAQgMAAgGADIgagIQgRgCgMAEQgHABgIgFQgHgFgIACIgXARQgOAKgGALQABAIAHAQQAHAQAAAHQADAnAABVQAABfACAqIAHBkIAGBkQABAhgDA9QgEA/ABAgIADAWIAEAUQACAWgBA8QgBAzAFAcIAHBlIABARQAAAEgCANQAAAKAHADQgHAEAAANQAAANgGAFIAFBOQADAuAAAgQAAAHgFAOQgFAOAAAHQAAAHACAQQADAPAAAHIgDAoQAAAUAIASQgBANgHAOIgMAcQAAADADAFQADAEgBAGQAiAJA7AGQAdADA/AKQA5AHAngFQBIAQBygCQCggDAeACQAYABAogCIBDgCIEsAEQCyABB2gKQAggJBWgGQBLgGAjgOQAFBngCD9QAAAXgHA7QgFAyACAfQADAkAAARQAAAfgGAQIgwAOQgfAKgSALQgbgBghAMIg6AVQgMgDgVAHQgdAIgIABQgvAIh2gDQhrgDgxANQgjABhLAEQhGAFglAAQgoAAgogFg");
	this.shape_14.setTransform(44.3,30.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgJCSQgFgbABgzQABg9gCgTIgEgVIgDgWQgBghAEhAQADg9gBggIAXgBIAKETQgHASACAjQADArgBALIAIA7QADAkgIAQIgTAAIgHhlg");
	this.shape_15.setTransform(-25,38.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgsJmIAAgcQAmAABEgFQBKgEAjgBQAxgNBsADQB1ADAvgIQAJgBAcgJQAVgGAMADIA6gWQAhgLAbABQATgLAegKIAxgOQAGgRgBgfQAAgQgDglQgCgeAGgzQAGg6AAgYQACj6gEhnQgkAOhLAGQhVAGggAJQh3AKiygBIkqgEIhDACQgpACgZgCQgdgBigADQhyAChJgQQgmAFg5gHQg/gKgegDQg6gGgjgJQACgGgDgEQgEgFAAgDIANgcQAGgOABgNQgHgTAAgTIACgoQABgIgDgPQgDgPAAgHQABgHAEgOQAFgOAAgIQABgfgDguIgFhOQAFgFAAgNQABgNAGgEQgHgDABgLQACgMgBgEIAAgRIAUgBQAJAEAAAMIgBATIgBBdQgBA7AHAkQgLAmAEA9QAFBbAAALQAMAHAKANQAUAGA6AEQA1AFAWAKQBpANCfgBIEGgCICzACQBgABBLgDQAhgBBLAAQBEABAlgCQA+gEBggTQAZgEAygFQArgGAbgKQADgbgDhOQgChHAHgjIAZADIACAJQADAJAAAEQAGBzgCCeIgEEXIABBMQAAAtgDAeQgGA1AGBaQACALAIAVQgFAHgDAIIgHAPIgNgCIgPAAQgGAAACgEQACgGgBgDIglAKQgWAFgSAAQgqANg8ARIhoAcQhigBixAKQitAJhZAAIgJAAg");
	this.shape_16.setTransform(55.8,124.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3F3F3F").s().p("AixCtIhEgDQgngBgXgLQgSADgWgDQgOgDgVgHQgGgJgHgPIgMgYQgBgsAGhbQAGhoABgrQA5gNB2ACQCJACAdgDQAxAABWAJQBcAIAnABQAZAAAygFQAsgCAbALQAFAAATgHQAPgFAJACQgGAOABAYQAAAWgFAJQAHAdgCA/QgCA+AJAnIgEAgQgCAQAEAOIgkAOQgVAGgVgEQgGgCgBAGIgDAIQgsAIhMAGIh+ALQijgOhWgIg");
	this.shape_17.setTransform(43.4,-136.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#666666").s().p("ACkBsIhDgCQgvgMhNADQhzAFgUgBIhtgBQhJAAghgBQgCgRACgKQACgGAIgPQgCgVgbgHIgpgEQAFgHAQgCIAagEQAIgBAIgIQAHgKAKABIgDgZQgCgNgIgHQABgLAIgIIAOgOQEDgkEJAaQAxgBA5ACIBmAEQAEADALAEQAKAEADAEQALAMAKADQgBAPADAZIACAiQgQALAAAdQABAogFAPQgKACgKgCIgUgFQgNAHgVABQgVABgSgHQgNAEgZAAQgWABgRAFQgZgCgngBg");
	this.shape_18.setTransform(41.9,-169.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#EFE3C7").s().p("ABqLxIizgCIkGACQifAAhpgMQgWgLg1gEQg6gFgUgGQgKgMgMgIQAAgKgFhbQgEg9ALgmQgHglABg7IABhcIABgUQAAgMgJgDQAJgQgEgkIgHg7QABgLgDgrQgDgjAHgSIgJkTQgFiegIi7QgBgYAGg4QAFgygDgcIAoADQAUACASgDQA+ANBkAAQA1gBB8gHQAwgDBpAAQBhAAAygEQA8gFC5ADQCbADBagQQAFAEAQABQATABAFABQApgLBQgBQBXgCAhgGQAzAAA7APQAGA2gBBDIgDB/IgFB+IgCBvQgBBJgHAsQAJBzgBDIQgCD2ACBAQgHAjACBGQADBPgDAaQgbALgrAGQgyAFgZAEQhgASg+AEQglAChEAAQhLgBghACQg+AChNAAIggAAg");
	this.shape_19.setTransform(55.3,35.9);

	this.addChild(this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-51.8,-185.5,191.8,372);


(lib.telefono = function() {
	this.initialize();

	// Modo de aislamiento
	this.instance = new lib.Grupodeclips0();
	this.instance.setTransform(53.4,14.1,0.831,0.831,0,0,0,313.2,242.1);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1.2,-40.2,93.7,86.2);


(lib.Imagen15 = function() {
	this.initialize();

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AZY+/MAAAA9/MgyvAAAMAAAg9/g");
	this.shape.setTransform(140.5,197.5);

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A5XfAMAAAg9/MAyvAAAMAAAA9/g");
	mask.setTransform(140.5,197.5);

	// Capa 2
	this.instance = new lib.sec5();
	this.instance.setTransform(128.8,198,0.66,0.66,0,0,0,36.1,0.5);

	this.instance.mask = mask;

	this.addChild(this.instance,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-80.9,-2.5,419.5,401.1);


(lib.Imagen14 = function() {
	this.initialize();

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AZY+/MAAAA9/MgyvAAAMAAAg9/g");
	this.shape.setTransform(140.5,197.5);

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A5XfAMAAAg9/MAyvAAAMAAAA9/g");
	mask.setTransform(140.5,197.5);

	// Capa 2
	this.instance = new lib.sec4();
	this.instance.setTransform(100.9,197.8,0.657,0.657,0,0,0,35,0.5);

	this.instance.mask = mask;

	this.addChild(this.instance,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-122.7,-2.4,448.5,400.5);


(lib.Imagen13 = function() {
	this.initialize();

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AZYfAMgyvAAAMAAAg9/MAyvAAAg");
	this.shape.setTransform(140.5,197.5);

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A5XfAMAAAg9/MAyvAAAMAAAA9/g");
	mask.setTransform(140.5,197.5);

	// Capa 2
	this.instance = new lib.sec3();
	this.instance.setTransform(150.4,196.1,0.66,0.66,0,0,0,36.1,0.5);

	this.instance.mask = mask;

	this.addChild(this.instance,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-83.7,-4.2,468.2,400.7);


(lib.Imagen12 = function() {
	this.initialize();

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AZYfAMgyvAAAMAAAg9/MAyvAAAg");
	this.shape.setTransform(140.5,262.7,1,0.671);

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A5XfAMAAAg9/MAyvAAAMAAAA9/g");
	mask.setTransform(140.5,197.5);

	// Capa 2
	this.instance = new lib.sec2();
	this.instance.setTransform(139.9,291.4,0.375,0.375,0,0,0,36.1,0.5);

	this.instance.mask = mask;

	this.addChild(this.instance,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-27.5,129.5,334.8,268);


(lib.Imagen1 = function() {
	this.initialize();

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AZY+/MAAAA9/MgyvAAAMAAAg9/g");
	this.shape.setTransform(140.5,197.5);

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3pe7MAAAg91MAvTAAAMAAAA91g");
	mask.setTransform(151.5,198);

	// Capa 2
	this.instance = new lib.sec1();
	this.instance.setTransform(148.3,201.9,0.664,0.664,0,0,0,44,8.3);

	this.instance.mask = mask;

	this.addChild(this.instance,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-21.9,-0.9,325,405.3);


(lib.btn1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text(txt['btn1'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.setTransform(51.1,1+incremento);

	this.instance = new lib.telefono();
	this.instance.setTransform(10.9,10.2,0.248,0.248,0,0,0,44,0.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAnQgMAAgJgJQgJgIAAgNIAAgRQAAgNAJgIQAJgJAMAAIARAAQANAAAIAJQAJAIAAANIAAARQAAANgJAIQgIAJgNAAg");
	this.shape.setTransform(13.6,17.4,0.206,0.206);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgIAnQgNAAgIgJQgJgIAAgNIAAgRQAAgNAJgIQAIgJANAAIARAAQANAAAIAJQAJAIAAANIAAARQAAANgJAIQgIAJgNAAg");
	this.shape_1.setTransform(11.3,17.4,0.206,0.206);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgIAnQgNAAgIgJQgJgIAAgNIAAgRQAAgNAJgIQAIgJANAAIASAAQAMAAAIAJQAJAIAAANIAAARQAAANgJAIQgIAJgMAAg");
	this.shape_2.setTransform(9,17.4,0.206,0.206);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgIAnQgMAAgJgJQgJgIAAgMIAAgTQAAgLAJgJQAJgJAMAAIARAAQANAAAIAJQAJAJAAALIAAATQAAAMgJAIQgIAJgNAAg");
	this.shape_3.setTransform(13.6,15.2,0.206,0.206);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgIAnQgNAAgIgJQgJgIAAgMIAAgTQAAgLAJgJQAIgJANAAIARAAQANAAAIAJQAJAJAAALIAAATQAAAMgJAIQgIAJgNAAg");
	this.shape_4.setTransform(11.3,15.2,0.206,0.206);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgIAnQgNAAgIgJQgJgIAAgMIAAgTQAAgLAJgJQAIgJANAAIASAAQAMAAAIAJQAJAJAAALIAAATQAAAMgJAIQgIAJgMAAg");
	this.shape_5.setTransform(9,15.2,0.206,0.206);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgIAnQgMAAgJgJQgJgIAAgNIAAgRQAAgNAJgIQAJgJAMAAIARAAQANAAAIAJQAJAIAAANIAAARQAAANgJAIQgIAJgNAAg");
	this.shape_6.setTransform(13.6,12.9,0.206,0.206);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgIAnQgNAAgIgJQgJgIAAgNIAAgRQAAgNAJgIQAIgJANAAIARAAQANAAAIAJQAJAIAAANIAAARQAAANgJAIQgIAJgNAAg");
	this.shape_7.setTransform(11.3,12.9,0.206,0.206);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgIAnQgNAAgIgJQgJgIAAgNIAAgRQAAgNAJgIQAIgJANAAIASAAQAMAAAIAJQAJAIAAANIAAARQAAANgJAIQgIAJgMAAg");
	this.shape_8.setTransform(9,12.9,0.206,0.206);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("Ah3C8QgcAAgUgUQgUgUAAgcIAAjvQAAgcAUgUQAUgUAcAAIDvAAQAcAAAUAUQAUAUAAAcIAADvQAAAcgUAUQgUAUgcAAg");
	this.shape_9.setTransform(11.3,15.2,0.206,0.206);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AFNDVQgXAAgPgYQgRgXABgiIAChWQkZgbkYAbIACBWQAAAigQAXQgPAYgXAAIiuAAQgXAAgRgRQgQgQAAgXIAAigQAAgYAPgZQAPgaAWgMQECh6D8AAQD9AAECB6QAWAMAPAaQAPAZAAAYIAACgQAAAXgQAQQgQARgYAAg");
	this.shape_10.setTransform(11.3,4.5,0.206,0.206);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AnVFoQgkAAgWgZQgVgYAAgkQAAgVAyimQAwibAQgnQAMgfAfgWQAegUAdAAQAaAAATgJQASgIASgSQAVgWALgeQAMgfgBgiIgBgVQBqgHBnAAQBoAABpAHIAAAVQAAAiAKAfQALAeAWAWQARASASAIQAUAJAaAAQAdAAAeAUQAfAWAMAfQARApAuCZQAzCmAAAVQAAAkgVAYQgXAZgjAAg");
	this.shape_11.setTransform(11.3,14.1,0.206,0.206);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_12.setTransform(36.3,10,1,1.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_13.setTransform(36.3,10,1,1.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_14.setTransform(36.3,10,1,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12}]}).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_12}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.6,-13.9,242,48);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}