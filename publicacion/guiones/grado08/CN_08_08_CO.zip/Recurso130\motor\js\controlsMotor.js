function BaseElemento(_index, _width, _height, _radius) {
  
  this.element  = null;
  this.index = _index;
  this.width = _width;
  this.height = _height;
  this.radius = _radius;
  
  this.base = new createjs.Shape();
  
  this.contenedor = new createjs.Container();
  this.dibuixa();
}

BaseElemento.prototype.setElement = function(_element){
  this.element = _element;
  this.element.index = this.index;
  this.element.base = this;
  //this.contenedor.addChild( this.resposta.contenedor );
}

BaseElemento.prototype.dibuixa = function() {
  
  this.base.graphics.beginFill("#fde8c2").drawRoundRect(0, 0, this.width, this.height, this.radius);
  this.base.graphics.beginStroke("#f8B334").setStrokeStyle(1).drawRoundRect(0, 0, this.width, this.height, this.radius);
  this.base.mouseEnabled = false;
  this.contenedor.addChild( this.base );
  
}


function Elemento(_texte,orden, _width, _height, _radius) {
	this.width = _width;
  	this.height = _height;
  	this.radius = _radius;
  	this.texte = _texte;
  	this.orden = orden;
  	this.index = 0;
  	this.idElement = -1;
  	this.error = false;
  	this.base = null;
  	
  	this.correccio = new createjs.Shape();
  	
  	this.fons = new createjs.Shape();	
	this.text = new createjs.RichText();	
	this.contenedor = new createjs.Container();
  	this.dibuixa();
}

Elemento.prototype.lightResponse = function(){
	this.fons.graphics.clear();
	this.fons.graphics.beginFill("#f8B334").drawRoundRect(0, 0, this.width, this.height, this.radius);
	this.fons.shadow = new createjs.Shadow("#777", 4, 4, 10);
}
Elemento.prototype.unlightResponse = function(){
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, this.width, this.height, this.radius);
	this.fons.shadow = null;
}
Elemento.prototype.erronia = function(){
	this.error = true;
	this.correccio.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(-2, -2, this.width + 4, this.height + 4, this.radius);
	this.contenedor.addChild( this.correccio );
}
Elemento.prototype.correcte = function(){
	this.error = false
	this.correccio.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(-2, -2, this.width + 4, this.height + 4, this.radius);
	this.contenedor.addChild( this.correccio );
}
Elemento.prototype.removeError = function(){
	if(this.error) this.contenedor.removeChild( this.correccio );
}
Elemento.prototype.dibuixa = function() {
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, this.width, this.height, this.radius);
	
	this.text.font = (Contenedor.datosXML.plataforma.grado == 1)?  "16px Arial" : "14px Arial" ;
	this.text.fontSize = (Contenedor.datosXML.plataforma.grado == 1)?  16: 14 ;
	this.text.color = "#0D3158";
	this.text.text = this.texte ;
	this.text.x = 8;
	this.text.y = 7;
	this.text.lineWidth = this.width-10;
	this.text.lineHeight = 22;
	this.text.mouseEnabled = false;
	
	this.text.mask = new createjs.Shape();
	this.text.mask.graphics.beginFill("#fff").drawRoundRect(0, 0, this.width-5,  this.height-5, 1);
	this.text.mask.x = 8;
	this.text.mask.y = 3;
	
	this.contenedor.addChild( this.fons );
	this.contenedor.addChild( this.text );
}


function Numero(num) {
  	this.texte = "0"+num;
  	this.index = 0;
  	this.idNumero = -1;
  	
  	this.fons = new createjs.Shape();	
	this.text = new createjs.Text();	
	this.contenedor = new createjs.Container();
  	this.dibuixa();
}

Numero.prototype.dibuixa = function() {
	this.fons.graphics.beginFill("#fff").drawRoundRect( 0, 0, 32, 32, 5);
	
	this.text.font = (Contenedor.datosXML.plataforma.grado == 1)?  "20px Arial" : "18px Arial" ;
	this.text.color = "#F39613";
	this.text.text = this.texte ;
	this.text.x = 5;
	this.text.y = 4;
	this.text.mouseEnabled = false;
	
	this.contenedor.addChild( this.fons );
	this.contenedor.addChild( this.text );
}

function Imagen(  ){	    
	    // get imagen
    this.contenedor = new createjs.Container();
    
    //this.zoom = new createjs.Bitmap("motor/images/ico_zoom.png");
    this.zoom = new createjs.Bitmap(pppPreloader.from("module", 'motor/images/ico_zoom.png'));
	this.zoom.x = 285;
	this.zoom.y = 435;
	this.zoom.on("mouseover", function(evt){ document.body.style.cursor='pointer'; });
	this.zoom.on("mouseout", function(evt){ document.body.style.cursor='default'; });
	this.zoom.on("click", this.zooming , this);
	
    var img = new Image();
    var objeto = this;
	img.onload = function () {
	   	objeto.imagen = new createjs.Bitmap(this);
		objeto.imagen.x = 25;
		objeto.imagen.y = 175;
		//escalem imatges
		objeto.imagen.scaleX =  300 / this.width;
		objeto.imagen.scaleY =  300 / this.height;

		//mascara de cantonades arrodonides
		objeto.imagen.mask = new createjs.Shape();
		objeto.imagen.mask.graphics.beginFill("#fff").drawRoundRect(0, 0, 300, 300, 10);
		objeto.imagen.mask.x = 25;
	 	objeto.imagen.mask.y = 175;
		
		objeto.contenedor.addChild( objeto.imagen);
		
		// boton de ampliacion
		if( Motor.datosXML.ampliacion != "")
		{
			objeto.contenedor.addChild( objeto.zoom );
			objeto.imagen.on("click", objeto.zooming , objeto);
			objeto.imagen.on("mouseover", function(evt){ document.body.style.cursor='pointer'; });
			objeto.imagen.on("mouseout", function(evt){ document.body.style.cursor='default'; });
		}
	};
	img.src = pppPreloader.from( "data", Motor.IMG + Motor.datosXML.imagen );//Motor.IMG + Motor.datosXML.imagen;
	
	// imagen ampliada
	if( Motor.datosXML.ampliacion !=  "")
	{
	    this.ampliacion = new Ampliacion();
	    this.ampliacion.contenedor.x = 0;
		this.ampliacion.contenedor.y = 0;
		this.ampliacion.contenedor.alpha = 0;
		Main.stage.addChild( this.ampliacion.contenedor);
	}
}
Imagen.prototype.zooming = function(evt){
	if( evt.primary ){
		Main.stage.setChildIndex ( this.ampliacion.contenedor,  Main.stage.getNumChildren () - 1 );
		this.ampliacion.contenedor.visible = true;
		createjs.Tween.get(this.ampliacion.contenedor).to({alpha:1}, 500, createjs.Ease.circOut);
	}
}

function Ampliacion()
{
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, Main.stage_width, Main.stage_height, 5);
	this.fons.alpha = 0.60;
	
	this.contenedor = new createjs.Container();
	this.contenedor.addChild(this.fons);
	
	var img = new Image();
	var amplia = this;
	
	this.imagen = "";
	img.onload = function () {

	   	amplia.imagen = new createjs.Bitmap(this);
		
		
		amplia.imagen.scaleX =  500 / this.height;
		amplia.imagen.scaleY =  500 / this.height;
		
		amplia.imagen.x = (Main.stage_width - (this.width * 500 / this.height))/2;
		amplia.imagen.y = 50;
		
		//mascara de cantonades arrodonides
		amplia.imagen.mask = new createjs.Shape();
		amplia.imagen.mask.graphics.beginFill("#fff").drawRoundRect(0, 0, 500, this.height * 500 / this.width, 10);
		amplia.imagen.mask.x = (Main.stage_width - (this.width * 500 / this.height))/2;
	 	amplia.imagen.mask.y = 50;
		
		amplia.contenedor.addChild( amplia.imagen);
	};
	img.src = Motor.IMG + Motor.datosXML.ampliacion;
		
	
	this.contenedor.on("click", this.tancar);
	this.contenedor.on("mouseover", function(evt){ document.body.style.cursor='pointer'; });
	this.contenedor.on("mouseout", function(evt){ document.body.style.cursor='default'; });
}
Ampliacion.prototype.tancar= function(evt){
	if( evt.primary ){
		createjs.Tween.get(this).to({alpha:0}, 500, createjs.Ease.circOut);
	}
}
