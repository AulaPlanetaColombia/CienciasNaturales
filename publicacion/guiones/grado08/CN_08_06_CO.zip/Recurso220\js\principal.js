(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();

        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
        titulo1(this, txt['titulo']);



        this.entrar = new lib.BtnFalse();
        this.entrar.setTransform(442.9, 286.5, 1, 1, 0, 0, 0, 309.9, 163.5);
        new cjs.ButtonHelper(this.entrar, 0, 1, 2, false, new lib.BtnFalse(), 3);

        this.instance_1 = new lib.shutterstock_79359772_OPT();
        this.instance_1.setTransform(155, 151);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.entrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.titulo, this.instance_1, this.entrar, this.siguiente, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();

        clearTexts();
        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['pantalla1']);



        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.instance_1 = new lib.shutterstock_28533781();
        this.instance_1.setTransform(185.4, 125, 0.525, 0.525);

        this.addChild(this.titulo, this.instance_1, this.home, this.siguiente, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();

        clearTexts();
        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['pantalla2']);

        // Capa 1

        this.mujerPortadora = new cjs.Text(txt["mujerPortadora"], "20px Verdana");
        this.mujerPortadora.lineHeight = 22;
        this.mujerPortadora.lineWidth = 276;
        this.mujerPortadora.setTransform(550, 361.2);

        this.hombrePortador = new cjs.Text(txt["hombrePortador"], "20px Verdana");
        this.hombrePortador.lineHeight = 22;
        this.hombrePortador.lineWidth = 276;
        this.hombrePortador.setTransform(154, 366.9);

        this.mujerAfectada = new cjs.Text(txt["mujerAfectada"], "20px Verdana");
        this.mujerAfectada.lineHeight = 22;
        this.mujerAfectada.lineWidth = 276;
        this.mujerAfectada.setTransform(550, 269.2);

        this.hombreAfectado = new cjs.Text(txt["hombreAfectado"], "20px Verdana");
        this.hombreAfectado.lineHeight = 22;
        this.hombreAfectado.lineWidth = 276;
        this.hombreAfectado.setTransform(154, 268.9);

        this.mujer = new cjs.Text(txt["mujer"], "20px Verdana");
        this.mujer.lineHeight = 22;
        this.mujer.lineWidth = 276;
        this.mujer.setTransform(550, 171.2);

        this.hombre = new cjs.Text(txt["hombre"], "20px Verdana");
        this.hombre.lineHeight = 22;
        this.hombre.lineWidth = 276;
        this.hombre.setTransform(154, 170.9);

        this.instance_1 = new lib.mujerPortadora();
        this.instance_1.setTransform(509, 375.2, 1.3, 1.3, 0, 0, 0, 20, 20);

        this.instance_2 = new lib.hombrePortador();
        this.instance_2.setTransform(113, 381, 1.3, 1.3, 0, 0, 0, 20, 20);

        this.instance_3 = new lib.mujerAfectada();
        this.instance_3.setTransform(509, 283.5, 1.3, 1.3, 0, 0, 0, 20, 20);

        this.instance_4 = new lib.hombreAfectado();
        this.instance_4.setTransform(113, 283.5, 1.3, 1.3, 0, 0, 0, 20, 20);

        this.instance_5 = new lib.Mujer();
        this.instance_5.setTransform(509, 186, 1.3, 1.3, 0, 0, 0, 20, 20);

        this.instance_6 = new lib.hombre();
        this.instance_6.setTransform(113, 186, 1.3, 1.3, 0, 0, 0, 20, 20);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.titulo, this.anterior, this.home, this.siguiente, this.instance_6, this.instance_5, this.instance_4, this.instance_3, this.instance_2, this.instance_1, this.hombre, this.mujer, this.hombreAfectado, this.mujerAfectada, this.hombrePortador, this.mujerPortadora, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 850, 546.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['pantalla3']);

        // Capa 1


        this.instance_2 = new lib.IMG_01();
        this.instance_2.setTransform(281.4, 288.6, 1, 1, 0, 0, 0, 160.6, 187.5);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.titulo, this.anterior, this.home, this.siguiente, this.logo, this.instance_2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 850, 546.3);



    (lib.frame5 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['pantalla4']);

        // Capa 1



        this.instance_2 = new lib.IMG_01_A();
        this.instance_2.setTransform(281.4, 288.6, 1, 1, 0, 0, 0, 160.6, 187.5);



        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4())
        });

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6())
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1())
        });
        this.addChild(this.titulo, this.anterior, this.home, this.siguiente, this.pantalla2, this.logo, this.instance_2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 850, 546.3);

    (lib.frame6 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['pantalla5']);
        // Capa 1


        this.instance_2 = new lib.IMG_02();
        this.instance_2.setTransform(281.4, 288.6, 1, 1, 0, 0, 0, 160.6, 187.5);



        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.titulo, this.anterior, this.home, this.siguiente, this.pantalla2, this.logo, this.instance_2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 850, 546.3);



    (lib.frame7 = function (animacion) {

        this.initialize();
  clearTexts();
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['pantalla6']);
        // Capa 1

        if (animacion === undefined) {
            this.instance_2 = new lib.IMG_02_A();
            this.instance_2.setTransform(281.4, 288.6, 1, 1, 0, 0, 0, 160.6, 187.5);
        }
        else
        {
            this.instance_2 = new lib.grafico2();
            this.instance_2.setTransform(281.4, 288.6, 1, 1, 0, 0, 0, 160.6, 187.5);

        }


        this.practica = new lib.btn_practica();
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.practica.on("click", function (evt) {
            putStage(new lib.frame8());
        });

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.practica, this.titulo, this.anterior, this.home, this.pantalla2, this.logo, this.instance_2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 850, 546.3);

    (lib.frame8 = function () {
        this.initialize();

clearTexts();
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['practicatxt'],"23px");
        
      

        this.instance_1 = new lib.grafico3();
        this.instance_1.setTransform(175, 151);


     

        this.solucion = new lib.btn_solucion();
        this.solucion.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.solucion, 0, 1, 2, false, new lib.btn_solucion(), 3);

        this.solucion.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7("cucutras"));
        });
        this.addChild(this.solucion, this.titulo, this.cerrar, this.logo, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 850, 546.3);

    (lib.frame9 = function () {
        this.initialize();

clearTexts();
        basicos(this, 0, 1, 0, 0, 1);
        titulo2(this, txt['soluciontxt']);


        // Capa 1

        this.instance_1 = new lib.grafico3_resuelto();
        this.instance_1.setTransform(175, 151);



        this.anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7("cucutras"));
        });
        this.addChild(this.anterior, this.titulo, this.cerrar, this.logo, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 850, 546.3);
// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto,size) {
        size=size||'25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130 + ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }



    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(txt['practicaBoton'], "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.btn_solucion = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(txt['solucionBoton'], "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.mujerPortadora = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FF6600").s().p("AgoCNQg6g7AAhSQAAhRA6g8QA5g6BSAAIAAGOQhSAAg5g6g");
        this.shape.setTransform(10, 20);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#33CC00").s().p("AhjDHIAAmOIABAAQBTAAA4A6QA7A8AABRQAABSg7A7Qg4A6hTAAg");
        this.shape_1.setTransform(30, 20);

        this.addChild(this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 40, 40);


    (lib.mujerAfectada = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FF6600").s().p("AiMCNQg6g7gBhSQABhRA6g8QA7g6BRAAQBSAAA7A6QA7A8gBBRQABBSg7A7Qg7A6hSAAQhRAAg7g6g");
        this.shape.setTransform(20, 20);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 40, 40);


    (lib.Mujer = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#33CC00").s().p("AiMCNQg6g6gBhTQABhRA6g7QA7g6BRgBQBSABA7A6QA7A7gBBRQABBTg7A6Qg7A6hSAAQhRAAg7g6g");
        this.shape.setTransform(20, 20);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 40, 40);


    (lib.hombrePortador = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FF6600").s().p("AhdDHIAAmOIC7AAIAAGOg");
        this.shape.setTransform(9.5, 20);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#33CC00").s().p("AhoDHIAAmOIDRAAIAAGOg");
        this.shape_1.setTransform(29.5, 20);

        this.addChild(this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 40, 40);


    (lib.hombreAfectado = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FF6600").s().p("AjHDHIAAmOIGOAAIAAGOg");
        this.shape.setTransform(20, 20);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 40, 40);


    (lib.hombre = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#33CC00").s().p("AjHDHIAAmOIGOAAIAAGOg");
        this.shape.setTransform(20, 20);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 40, 40);


    (lib.shutterstock_79359772_OPT = function () {
        this.initialize(img.shutterstock_79359772_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 600, 291);

    (lib.shutterstock_28533781 = function () {
        this.initialize(img.shutterstock_28533781);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1000, 667);

    (lib.grafico1 = function () {
        this.initialize(img.grafico1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1000, 667);

    (lib.grafico2 = function () {
        this.initialize(img.grafico2);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1000, 667);

    (lib.grafico3 = function () {
        this.initialize(img.grafico3);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1000, 667);


    (lib.grafico3_resuelto = function () {
        this.initialize(img.grafico3_resuelto);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1000, 667);

    (lib.IMG_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        //mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        //mask.setTransform(160.6,187.5);
        mask.graphics.drawRect(0, 0, 800, 1);
        // Capa 2
        this.instance = new lib.grafico1();
        this.instance.setTransform(0, 0, 0.95, 0.95);

        this.instance.mask = mask;
        this.addChild(this.instance);
        this.timeline.addTween(cjs.Tween.get(mask).to({scaleY: 140}, 44).wait(10000));



    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 531.3, 374.9);

    (lib.IMG_01_A = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        //mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        //mask.setTransform(160.6,187.5);
        mask.graphics.drawRect(0, 0, 800, 140);
        // Capa 2
        this.instance = new lib.grafico1();
        this.instance.setTransform(0, 0, 0.95, 0.95);

        this.instance.mask = mask;
        this.addChild(this.instance);
        this.timeline.addTween(cjs.Tween.get(mask).to({scaleY: 3.1}, 74).wait(10000));



    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 531.3, 374.9);

    (lib.IMG_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        //mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        //mask.setTransform(160.6,187.5);
        mask.graphics.drawRect(0, 0, 800, 1);
        // Capa 2
        this.instance = new lib.grafico2();
        this.instance.setTransform(0, 0, 0.95, 0.95);

        this.instance.mask = mask;
        this.addChild(this.instance);
        this.timeline.addTween(cjs.Tween.get(mask).to({scaleY: 140}, 44).wait(10000));



    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 531.3, 374.9);

    (lib.IMG_02_A = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        //mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        //mask.setTransform(160.6,187.5);
        mask.graphics.drawRect(0, 0, 800, 140);
        // Capa 2
        this.instance = new lib.grafico2();
        this.instance.setTransform(0, 0, 0.95, 0.95);

        this.instance.mask = mask;
        this.addChild(this.instance);
        this.timeline.addTween(cjs.Tween.get(mask).to({scaleY: 3.1}, 74).wait(10000));



    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 531.3, 374.9);
    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);


    (lib.BtnFalse = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.4)").s().p("EgwaAZiMAAAgzDMBg1AAAMAAAAzDg");
        this.shape.setTransform(310, 163.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("EgwaAZiMAAAgzDMBg1AAAMAAAAzDg");
        this.shape_1.setTransform(310, 163.5);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 1).to({state: []}, 1).to({state: [{t: this.shape_1}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);

    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;

function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = 0; i < childNodes.length; i++) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}