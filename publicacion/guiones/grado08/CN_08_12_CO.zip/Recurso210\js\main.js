window.onresize = resize;
var scale 	= 1;
var iniciat;

$(document).ready(function(){
	resize();
	initialize();
});

function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}

function restart(){
	
}

var magnets;
var magnets2;
var volts = 0;
var rElectrons;
var rElectrons2;
var lElectrons;
var elecSpeed = 0;
var direction = 0;
var scene = 1;
var inverted = false;

function initialize(){
	iniciat = false;
	volts = 0;
	elecSpeed = 0;
	direction = 0;
	magnets = document.getElementsByClassName("fm");
	magnets2 = document.getElementsByClassName("fms2");
	rElectrons = document.getElementsByClassName("re");
	rElectrons2 = document.getElementsByClassName("re2");
	lElectrons = document.getElementsByClassName("le");
	
	for(var i=0;i<magnets.length;i++){
		var ang = calculateAngle(magnets[i],327,250);
	}
	for(var i=0;i<magnets2.length;i++){
		var ang = calculateAngle2(magnets2[i],327,150);
		$("#"+magnets2[i].id).fadeTo(0,0);
	}

	$("#barMagnet").draggable({
		scroll: false,
		containment: '#plantilla',
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);
			
			for(var i=0;i<magnets.length;i++){
				var ang = calculateAngle(magnets[i],ui.position.left,ui.position.top);
			}
			
			if(ui.position.top < 0){
				ui.position.top = 0;
			}
			if(ui.position.top > 497){
				ui.position.top = 497;
			}
			if(ui.position.left < 0){
				ui.position.left = 0;
			}
			if(ui.position.left > 722){
				ui.position.left = 722;
			}
		}        
	});
	$("#barMagnet").css('-ms-touch-action', 'none');
	
	$("#electroiman").draggable({
		scroll: false,
		containment: '#plantilla',
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);
			
			for(var i=0;i<magnets2.length;i++){
				var ang = calculateAngle2(magnets2[i],ui.position.left,ui.position.top);
			}
		}        
	});
	$("#electroiman").css('-ms-touch-action', 'none');
	
	$("#compass").draggable({
		scroll: false,
		containment: '#plantilla',
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);
			
			var dX = $("#barMagnet").css("left");
			var dY = $("#barMagnet").css("top");
			dX = parseInt(dX.substring(0,dX.length-2));
			dY = parseInt(dY.substring(0,dY.length-2));
			
			var cAngle = calculateAngleArrow(document.getElementById("compass"),dX,dY,1);
			/*for(var i=0;i<magnets.length;i++){
				var ang = calculateAngle(magnets[i],ui.position.left,ui.position.top);
			}*/
		}        
	});
	$("#compass").css('-ms-touch-action', 'none');
	
	$("#compass2").draggable({
		scroll: false,
		containment: '#plantilla',
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);
			
			var dX = $("#electroiman").css("left");
			var dY = $("#electroiman").css("top");
			dX = parseInt(dX.substring(0,dX.length-2));
			dY = parseInt(dY.substring(0,dY.length-2));
		
			var cAngle = calculateAngleArrow2(document.getElementById("compass2"),dX,dY,2);
		
			/*for(var i=0;i<magnets.length;i++){
				var ang = calculateAngle(magnets[i],ui.position.left,ui.position.top);
			}*/
		}        
	});
	$("#compass2").css('-ms-touch-action', 'none');
	
	$("#handle").draggable({
		axis: "x",
		scroll: false,
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);
			if(ui.position.left <18){
				ui.position.left = 18;
			}
			if(ui.position.left >167){
				ui.position.left = 167;
			}
			var handleX = ui.position.left;
			if(handleX >=18 && handleX < 31.5){
				volts = 10;
				direction = -5;
			}else if(handleX >=31.5 && handleX < 45){
				volts = 8;
				direction = -4;
			}else if(handleX >=45 && handleX < 58.5){
				volts = 6;
				direction = -3;
			}else if(handleX >=58.5 && handleX < 72){
				volts = 4;
				direction = -2;
			}else if(handleX >=72 && handleX < 85.5){
				volts = 2;
				direction = -1;
			}else if(handleX >=85.5 && handleX < 99){
				volts = 0;
				direction = 0;
			}else if(handleX >=99 && handleX < 112.5){
				volts = 2;
				direction = 1;
			}else if(handleX >=112.5 && handleX < 126){
				volts = 4;
				direction = 2;
			}else if(handleX >=126 && handleX < 139.5){
				volts = 6;
				direction = 3;
			}else if(handleX >=139.5 && handleX < 153){
				volts = 8;
				direction = 4;
			}else if(handleX >=153 && handleX < 167){
				volts = 10;
				direction = 5;
			}

			if(handleX < 92.5){
				if($("#pila").attr("src") != "images/pilaLeft.png"){
					$("#pila").attr("src","images/pilaLeft.png"); 
					$("#arrow2").attr("src","images/compassArrowInvert.png"); 
					$("#volts").removeClass("voltsRight");
					$("#volts").addClass("voltsLeft");
					for(var i=0;i<magnets2.length;i++){
						$("#"+magnets2[i].id).attr("src","images/fieldMagnetInvert.png");
					}
				}
			}else{
				if($("#pila").attr("src") != "images/pilaRight.png"){
					$("#pila").attr("src","images/pilaRight.png"); 
					$("#arrow2").attr("src","images/compassArrow.png"); 
					$("#volts").removeClass("voltsLeft");
					$("#volts").addClass("voltsRight");
					for(var i=0;i<magnets2.length;i++){
						$("#"+magnets2[i].id).attr("src","images/fieldMagnet.png");
					}
				}
			}
			for(var i=0;i<magnets2.length;i++){
				var newOpacity = volts/10;
				$("#"+magnets2[i].id).fadeTo(0,newOpacity);
			}
			
			$("#volts").html(volts+"v");
		}
	});
	$("#handle").css('-ms-touch-action', 'none');
	
	moveElectrons();
}

function moveElectrons(){
	setInterval(function(){
		if(scene == 2){
			for(var i=0;i<lElectrons.length;i++){
				var topElec = $("#"+lElectrons[i].id).css("top");
				topElec = parseInt(topElec.substring(0,topElec.length-2));
				topElec = topElec + (direction);
			
				var initTop = parseInt($("#"+lElectrons[i].id).attr("initTop"));
				if(topElec > (initTop+ 17) || topElec < (initTop-17)){
					topElec = initTop;
				}
				$("#"+lElectrons[i].id).css("top",topElec+"px");
			}
			for(var i=0;i<rElectrons.length;i++){
				var topElec = $("#"+rElectrons[i].id).css("top");
				topElec = parseInt(topElec.substring(0,topElec.length-2));
				topElec = topElec - (direction);
				var initTop = parseInt($("#"+rElectrons[i].id).attr("initTop"));
				if(topElec > (initTop+ 18) || topElec < (initTop-18)){
					topElec = initTop;
				}
				$("#"+rElectrons[i].id).css("top",topElec+"px");
			}
			for(var i=0;i<rElectrons2.length;i++){
				var topElec = $("#"+rElectrons2[i].id).css("top");
				topElec = parseInt(topElec.substring(0,topElec.length-2));
				topElec = topElec - (direction);
				var initTop = parseInt($("#"+rElectrons2[i].id).attr("initTop"));
				if(topElec > (initTop+ 18) || topElec < (initTop-18)){
					topElec = initTop;
				}
				$("#"+rElectrons2[i].id).css("top",topElec+"px");
			}
		}
	},33);
}

function calculateAngleArrow(element, barL, barT,n){
	var angle = 0;
	var dX = $("#"+element.id).css("left");
	var dY = $("#"+element.id).css("top");
	
	var distX = 0;
	var distY = parseInt(dY.substring(0,dY.length-2) - barT) +16;

	var doX =  parseInt(dX.substring(0,dX.length-2) - barL-113) +31;	
	
	if(doX <=0){
		distX = parseInt(dX.substring(0,dX.length-2) - barL)+31 ;
	}else{
		distX = parseInt(dX.substring(0,dX.length-2) - barL-226)+31;
	}
		
	angle = Math.atan2(distY, distX) * 180 / Math.PI;
	
	angle = angle + 90;
	
	if(doX>0){
		angle = angle+180;
	}
	if(doX > -130 && doX <= 0){
		if(distY<=0){
			angle = 0 + (90*(1-Math.abs(doX)/130));
		}else{
			angle = 180 - (90*(1-Math.abs(doX)/130));
		}
		
	}
	if(doX > 0 && doX < 130){
		if(distY<=0){
			angle = 180 - (90*(1-Math.abs(doX)/130));			
		}else{
			angle = 0 + (90*(1-Math.abs(doX)/130));
		}
	}

	$("#arrow").css({transform: 'rotateZ('+angle+'deg)'});
		
	return angle;
}
function calculateAngleArrow2(element, barL, barT,n){
	var angle = 0;
	var dX = $("#"+element.id).css("left");
	var dY = $("#"+element.id).css("top");
	
	var distX = 0;
	var distY = parseInt(dY.substring(0,dY.length-2) - barT-170) +16;

	var doX =  parseInt(dX.substring(0,dX.length-2) - barL-103) +31;	
	
	if(doX <=0){
		distX = parseInt(dX.substring(0,dX.length-2) - barL - 73)+31 ;
	}else{
		distX = parseInt(dX.substring(0,dX.length-2) - barL-133)+31;
	}
		
	angle = Math.atan2(distY, distX) * 180 / Math.PI;
	
	angle = angle + 90;
	
	if(doX>0){
		angle = angle+180;
	}
	if(distY<=-100){
		if(doX > -130 && doX <= 0){
			angle = 0 + (90*(1-Math.abs(doX)/130));
		}
	}else{
		if(doX > -20 && doX <= 0){
			angle = 180 - (90*(1-Math.abs(doX)/20));
		}
	}
	

	if(distY<=-100){
		if(doX > 0 && doX < 130){
			angle = 180 - (90*(1-Math.abs(doX)/130));		
		}				
	}else{
		if(doX > 0 && doX < 20){
			angle = 0 + (90*(1-Math.abs(doX)/20));
		}
	}

	$("#arrow2").css({transform: 'rotateZ('+angle+'deg)'});

	return angle;
}
function calculateAngle(element,barL,barT){
	var angle = 0;
	var dX = $("#"+element.id).css("left");
	var dY = $("#"+element.id).css("top");
	
	var distX = 0;
	var distY = parseInt(dY.substring(0,dY.length-2) - barT);

	var doX =  parseInt(dX.substring(0,dX.length-2) - barL-113);	
	
	if(doX <=0){
		distX = parseInt(dX.substring(0,dX.length-2) - barL);
	}else{
		distX = parseInt(dX.substring(0,dX.length-2) - barL-226);
	}
		
	angle = Math.atan2(distY, distX) * 180 / Math.PI;
	
	angle = angle + 90;
	
	if(doX>0){
		angle = angle+180	;
	}
	if(doX > -130 && doX <= 0){
		if(distY<=0){
			angle = 0 + (90*(1-Math.abs(doX)/130));
		}else{
			angle = 180 - (90*(1-Math.abs(doX)/130));
		}
		
	}
	if(doX > 0 && doX < 130){
		if(distY<=0){
			angle = 180 - (90*(1-Math.abs(doX)/130));			
		}else{
			angle = 0 + (90*(1-Math.abs(doX)/130));
		}
	}
	
	$("#"+element.id).css({transform: 'rotateZ('+angle+'deg)'});
	return angle;
}

function calculateAngle2(element,barL,barT){
	var angle = 0;
	var dX = $("#"+element.id).css("left");
	var dY = $("#"+element.id).css("top");
	
	var distX = 0;
	var distY = parseInt(dY.substring(0,dY.length-2) - barT -170);

	var doX =  parseInt(dX.substring(0,dX.length-2) - barL-103);	
	
	if(doX <=0){
		distX = parseInt(dX.substring(0,dX.length-2) - barL-73);
	}else{
		distX = parseInt(dX.substring(0,dX.length-2) - barL-133);
	}
		
	angle = Math.atan2(distY, distX) * 180 / Math.PI;
	
	angle = angle + 90;
	
	if(doX>0){
		angle = angle+180	;
	}
	
	if(distY<=-100){
		if(doX > -130 && doX <= 0){
			angle = 0 + (90*(1-Math.abs(doX)/130));
		}
	}else{
		if(doX > -20 && doX <= 0){
			angle = 180 - (90*(1-Math.abs(doX)/20));
		}
	}
	

	if(distY<=-100){
		if(doX > 0 && doX < 130){
			angle = 180 - (90*(1-Math.abs(doX)/130));		
		}				
	}else{
		if(doX > 0 && doX < 20){
			angle = 0 + (90*(1-Math.abs(doX)/20));
		}
	}

	
	$("#"+element.id).css({transform: 'rotateZ('+angle+'deg)'});
	return angle;
}
function invertirPolaridad(){
	if(inverted){
		inverted = false;
		$("#barMagnet").attr("src","images/barMagnet.png");
		$("#arrow").attr("src","images/compassArrow.png");
		for(var i=0;i<magnets.length;i++){
			$("#"+magnets[i].id).attr("src","images/fieldMagnet.png");
		}
		
	}else{
		inverted = true;
		$("#barMagnet").attr("src","images/barMagnetInvert.png");
		$("#arrow").attr("src","images/compassArrowInvert.png");
		for(var i=0;i<magnets.length;i++){
			$("#"+magnets[i].id).attr("src","images/fieldMagnetInvert.png");
		}
	}
}
function showScene1(){
	scene = 1;
	$("#scene2").css("display","none");
	$("#scene1").css("display","block");
	$("#btScene2").removeClass("sceneSelected");
	$("#btScene1").addClass("sceneSelected");
	$("#btInvertir").css("display","block");
}
function showScene2(){
	scene = 2;
	$("#scene1").css("display","none");
	$("#scene2").css("display","block");
	$("#btScene1").removeClass("sceneSelected");
	$("#btScene2").addClass("sceneSelected");
	$("#btInvertir").css("display","none");
}

function iniciar(){
	if(!iniciat){	
			
	}
}

function reiniciar(){
	if(canChange){
		restart();
		initialize();
	}
}