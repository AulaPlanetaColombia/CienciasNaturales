(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:


    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
        titulo1(this, txt['titulo']);
        this.mc_boto_02 = new lib.mc_boto_02();
        this.mc_boto_02.setTransform(673.1, 477, 1, 1, 0, 0, 0, 125, 15);
        new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_boto_02(), 3);

        this.mc_boto_01 = new lib.mc_boto_01();
        this.mc_boto_01.setTransform(275.1, 477, 1, 1, 0, 0, 0, 125, 15);
        new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_boto_01(), 3);

        this.texto_selecciona = new cjs.Text(txt['texto_selecciona'], "bold 16px Verdana");
        this.texto_selecciona.textAlign = "center";
        this.texto_selecciona.lineHeight = 16;
        this.texto_selecciona.lineWidth = 307;
        this.texto_selecciona.setTransform(473.9, 533.9 + incremento);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#999999").s().p("A3VCpIAAlRMAusAAAIAAFRg");
        this.shape.setTransform(475.9, 546);
        this.mc_boto_01.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });

        this.mc_boto_02.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.mc_boto_02, this.mc_boto_01, this.shape, this.texto_selecciona);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame2_1 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['titulo_ventana2']);
        this.txt_boto_09 = new cjs.Text(txt['txt_boto_09'], "bold 16px Verdana");
	this.txt_boto_09.textAlign = "center";
	this.txt_boto_09.lineHeight = 18;
	this.txt_boto_09.lineWidth = 244;
	this.txt_boto_09.setTransform(736.1,477.3+incremento);

	this.txt_boto_08 = new cjs.Text(txt['txt_boto_08'], "bold 16px Verdana");
	this.txt_boto_08.textAlign = "center";
	this.txt_boto_08.lineHeight = 18;
	this.txt_boto_08.lineWidth = 244;
	this.txt_boto_08.setTransform(236.1,297.3+incremento);

	this.txt_boto_07 = new cjs.Text(txt['txt_boto_07'], "bold 16px Verdana");
	this.txt_boto_07.textAlign = "center";
	this.txt_boto_07.lineHeight = 18;
	this.txt_boto_07.lineWidth = 244;
	this.txt_boto_07.setTransform(476.1,157.3+incremento);

	this.mc_boto_09 = new lib.mc_boto_03();
	this.mc_boto_09.setTransform(738.3,488.4,1,1,0,0,0,125,15);
        new cjs.ButtonHelper(this.mc_boto_09, 0, 1, 2, false, new lib.mc_boto_03(), 3);

	this.mc_boto_08 = new lib.mc_boto_03();
	this.mc_boto_08.setTransform(238.3,308.4,1,1,0,0,0,125,15);
        new cjs.ButtonHelper(this.mc_boto_08, 0, 1, 2, false, new lib.mc_boto_03(), 3);

	this.mc_boto_07 = new lib.mc_boto_03();
	this.mc_boto_07.setTransform(478.3,168.4,1,1,0,0,0,125,15);
        new cjs.ButtonHelper(this.mc_boto_07, 0, 1, 2, false, new lib.mc_boto_03(), 3);

	this.instance = new lib.CircuitoAnim();
	this.instance.setTransform(481.8,343.2,1,1,0,0,0,158,123.8);

	

        this.mc_boto_07.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.mc_boto_08.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.mc_boto_09.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });

      this.addChild(this.mc_boto_07,this.mc_boto_08,this.mc_boto_09,this.txt_boto_07,this.txt_boto_08,this.txt_boto_09,this.titulo,this.home,this.logo,this.instance);
        this.home.on("click", function (evt) {

            evt.target.removeAllEventListeners();
            this.removeAllEventListeners();
            putStage(new lib.frame1());
        });


        this.addChild(this.imagen, this.home, this.titulo, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
     (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_ventana_21'], 1, 320,-425);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(415, 169.8);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);
        
	this.text = new cjs.Text("V = I · R", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 107;
	this.text.setTransform(600,400);
        
        this.instance_1 = new lib.Imagen5MC();
        this.instance_1.setTransform(237,345.9,0.468,0.468,0,0,0,44,0.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCCCFF").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
        this.shape.setTransform(475.4, 345, 1, 0.992);
this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().dr(-129.65,-187.5,259.3,375);
	this.shape_1.setTransform(231.1,345,1.575,1);
	
	var html = createDiv('Donde: <i>R</i> es la resistencia en ohmios (Ω) e <i>I</i> la intensidad en amperios (A).', "Verdana", "20px", '400px', '40px',"20px", "185px", "left");
		this.texto_3 = new cjs.DOMElement(html);
		this.texto_3.setTransform(455, -180);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame2_3b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });


        this.addChild(this.shape,this.shape_1, this.logo, this.cerrar, this.instance_1, this.ampliar, this.texto,this.text, this.texto_3);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame2_3b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_08();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
      (lib.frame2_4 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_ventana_22'], 1, 320,-425);
       

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(415, 169.8);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);
        
		this.shape_2 = new cjs.Shape();
		this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AibAAIE3AA");
		this.shape_2.setTransform(695.8,376.4);
	
		this.text = new cjs.Text("R", "italic 20px Verdana");
		this.text.textAlign = "center";
		this.text.lineHeight = 22;
		this.text.lineWidth = 18;
		this.text.setTransform(693.8,380.8);
	
		this.text_1 = new cjs.Text("V", "italic 20px Verdana");
		this.text_1.textAlign = "center";
		this.text_1.lineHeight = 22;
		this.text_1.lineWidth = 18;
		this.text_1.setTransform(693.8,343.9);
	
		this.text_2 = new cjs.Text("I =", "italic 20px Verdana");
		this.text_2.lineHeight = 22;
		this.text_2.lineWidth = 39;
		this.text_2.setTransform(634.6,361.1);
	        
	    this.instance_1 = new lib.Imagen6MC();
	    this.instance_1.setTransform(232.4,337.1,0.411,0.411,0,0,0,44,0.5);
	
	    this.shape = new cjs.Shape();
	    this.shape.graphics.f("#CCCCFF").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
	    this.shape.setTransform(475.4, 345, 1, 0.992);
	        
	    this.shape_1 = new cjs.Shape();
		this.shape_1.graphics.f("#FFFFFF").s().dr(-129.65,-187.5,259.3,375);
		this.shape_1.setTransform(231.1,345,1.575,1);

		var html = createDiv('Donde: <i>R</i> es la resistencia en ohmios (Ω) y <i>V</i> el voltaje en voltios (V).', "Verdana", "20px", '400px', '40px',"20px", "185px", "left");
		this.texto_3 = new cjs.DOMElement(html);
		this.texto_3.setTransform(455, -200);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame2_4b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });


        this.addChild(this.shape,this.shape_1, this.logo, this.cerrar, this.instance_1, this.ampliar, this.texto,this.text,this.shape_2,this.text_1,this.text_2,this.texto_3);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame2_4b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_09();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
      (lib.frame2_5 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_ventana_23'], 1, 320,-425);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(415, 169.8);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);
        
		this.shape_2 = new cjs.Shape();
		this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AibAAIE3AA");
		this.shape_2.setTransform(675.8,368.9);
	
		this.text = new cjs.Text("I", "italic 20px Verdana");
		this.text.textAlign = "center";
		this.text.lineHeight = 22;
		this.text.lineWidth = 18;
		this.text.setTransform(673.8,373.3);
	
		this.text_1 = new cjs.Text("V", "italic 20px Verdana");
		this.text_1.textAlign = "center";
		this.text_1.lineHeight = 22;
		this.text_1.lineWidth = 18;
		this.text_1.setTransform(673.8,336.4);
	
		this.text_2 = new cjs.Text("R =", "italic 20px Verdana");
		this.text_2.lineHeight = 22;
		this.text_2.lineWidth = 39;
		this.text_2.setTransform(614.5,353.6);
        
        this.instance_1 = new lib.FQ_09_08_043();
        this.instance_1.setTransform(59.4,258.4,0.439,0.439);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCCCFF").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
        this.shape.setTransform(475.4, 345, 1, 0.992);
        
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().dr(-129.65,-187.5,259.3,375);
	this.shape_1.setTransform(231.1,345,1.575,1);

	var html = createDiv('Donde: <i>V</i> es el voltaje en voltios (V) e <i>I</i> la intensidad en amperios (A).', "Verdana", "20px", '400px', '40px',"20px", "185px", "left");
		this.texto_3 = new cjs.DOMElement(html);
		this.texto_3.setTransform(455, -180);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame2_5b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });


        this.addChild(this.shape,this.shape_1, this.logo, this.cerrar, this.instance_1, this.ampliar, this.texto,this.text,this.shape_2,this.text_1,this.text_2, this.texto_3);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame2_5b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_10();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    
    (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['titulo_ventana1']);
        this.txt_boto_04 = new cjs.Text(txt['txt_boto_04'], "bold 16px Verdana");
        this.txt_boto_04.textAlign = "center";
        this.txt_boto_04.lineHeight = 18;
        this.txt_boto_04.lineWidth = 244;
        this.txt_boto_04.setTransform(706.9, 148.5 + incremento);

        this.txt_boto_05 = new cjs.Text(txt['txt_boto_05'], "bold 16px Verdana");
        this.txt_boto_05.textAlign = "center";
        this.txt_boto_05.lineHeight = 18;
        this.txt_boto_05.lineWidth = 244;
        this.txt_boto_05.setTransform(776.9, 448.5 + incremento);

        this.txt_boto_03 = new cjs.Text(txt['txt_boto_03'], "bold 16px Verdana");
        this.txt_boto_03.textAlign = "center";
        this.txt_boto_03.lineHeight = 18;
        this.txt_boto_03.lineWidth = 244;
        this.txt_boto_03.setTransform(776.9, 308.5 + incremento);

        this.txt_boto_06 = new cjs.Text(txt['txt_boto_06'], "bold 16px Verdana");
        this.txt_boto_06.textAlign = "center";
        this.txt_boto_06.lineHeight = 18;
        this.txt_boto_06.lineWidth = 252;
        this.txt_boto_06.setTransform(167, 288.5 + incremento);

        this.mc_boto_03 = new lib.mc_boto_03();
        this.mc_boto_03.setTransform(779, 319.6, 1, 1, 0, 0, 0, 125, 15);
        new cjs.ButtonHelper(this.mc_boto_03, 0, 1, 2, false, new lib.mc_boto_03(), 3);

        this.mc_boto_05 = new lib.mc_boto_03();
        this.mc_boto_05.setTransform(779, 459.6, 1, 1, 0, 0, 0, 125, 15);
        new cjs.ButtonHelper(this.mc_boto_05, 0, 1, 2, false, new lib.mc_boto_03(), 3);

        this.mc_boto_04 = new lib.mc_boto_03();
        this.mc_boto_04.setTransform(709, 159.6, 1, 1, 0, 0, 0, 125, 15);
        new cjs.ButtonHelper(this.mc_boto_04, 0, 1, 2, false, new lib.mc_boto_03(), 3);

        this.mc_boto_06 = new lib.mc_boto_03();
        this.mc_boto_06.setTransform(169, 299.6, 1, 1, 0, 0, 0, 125, 15);
        new cjs.ButtonHelper(this.mc_boto_06, 0, 1, 2, false, new lib.mc_boto_03(), 3);

        this.mc_boto_03.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
        this.mc_boto_04.on("click", function (evt) {
            putStage(new lib.frame1_4());
        });
        this.mc_boto_05.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });
        this.mc_boto_06.on("click", function (evt) {
            putStage(new lib.frame1_6());
        });

        this.instance = new lib.circuitoMC();
        this.instance.setTransform(473.8, 318.6, 0.657, 0.657, 0, 0, 0, 37, -0.7);

        this.addChild(this.instance, this.mc_boto_06, this.mc_boto_04, this.mc_boto_05, this.mc_boto_03, this.txt_boto_04, this.txt_boto_05, this.txt_boto_06, this.txt_boto_03, this.titulo, this.home, this.logo);
        this.home.on("click", function (evt) {

            evt.target.removeAllEventListeners();
            this.removeAllEventListeners();
            putStage(new lib.frame1());
        });


        this.addChild(this.imagen, this.home, this.titulo, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame1_3 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_ventana_11'], 1, 300);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(324.1, 169.8);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);


        this.instance_1 = new lib.Imagen1MC();
        this.instance_1.setTransform(231.8, 345.1, 1, 1, 0, 0, 0, 150.5, 187.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8CB8A5").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
        this.shape.setTransform(475.4, 345, 1, 0.992);


        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_3b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });


        this.addChild(this.shape, this.logo, this.cerrar, this.instance_1, this.ampliar, this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame1_3b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_01();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
 (lib.frame1_4 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_ventana_12'], 1, 300);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(324.1, 169.8);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);


        this.instance_1 = new lib.Imagen2MC();
        this.instance_1.setTransform(231.8, 345.1, 1, 1, 0, 0, 0, 150.5, 187.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8CB8A5").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
        this.shape.setTransform(475.4, 345, 1, 0.992);


        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_4b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });


        this.addChild(this.shape, this.logo, this.cerrar, this.instance_1, this.ampliar, this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame1_4b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_02();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_4());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame1_5 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
        texto(this, txt['txt_ventana_13'], 1, 300);
        
        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(324.1, 169.8);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);
        this.instance_1 = new lib.Imagen3MC("single",0);
        this.instance_1.setTransform(231.8, 345.1, 1, 1, 0, 0, 0, 150.5, 187.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8CB8A5").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
        this.shape.setTransform(475.4, 345, 1, 0.992);
        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_5b());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_5_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.addChild(this.shape, this.logo, this.cerrar, this.instance_1, this.ampliar,this.siguiente, this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame1_5b = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0, 0, 0, 0, 1);
        this.imagen = new lib.popup_ampliar_03();
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });
        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame1_5_2 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
        texto(this, txt['txt_ventana_13'], 1, 300);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(324.1, 169.8);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);
        this.instance_1 = new lib.Imagen3MC("single",1);
        this.instance_1.setTransform(231.8, 345.1, 1, 1, 0, 0, 0, 150.5, 187.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8CB8A5").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
        this.shape.setTransform(475.4, 345, 1, 0.992);
        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_5_2b());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_5_3());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.addChild(this.shape, this.logo, this.cerrar, this.instance_1, this.ampliar, this.texto,this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame1_5_2b = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0, 0, 0, 0, 1);
        this.imagen = new lib.popup_ampliar_04();
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_5_2());
        });
        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
      (lib.frame1_5_3 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
        texto(this, txt['txt_ventana_13'], 1, 300);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(324.1, 169.8);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);
        this.instance_1 = new lib.Imagen3MC("single",2);
        this.instance_1.setTransform(231.8, 345.1, 1, 1, 0, 0, 0, 150.5, 187.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8CB8A5").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
        this.shape.setTransform(475.4, 345, 1, 0.992);
        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_5_3b());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_5_4());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.addChild(this.shape, this.logo, this.cerrar, this.instance_1, this.ampliar, this.texto,this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame1_5_3b = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0, 0, 0, 0, 1);
        this.imagen = new lib.popup_ampliar_05();
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_5_3());
        });
        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
      (lib.frame1_5_4 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
        texto(this, txt['txt_ventana_13'], 1, 300);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(324.1, 169.8);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);
        this.instance_1 = new lib.Imagen3MC("single",3);
        this.instance_1.setTransform(231.8, 345.1, 1, 1, 0, 0, 0, 150.5, 187.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8CB8A5").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
        this.shape.setTransform(475.4, 345, 1, 0.992);
        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_5_4b());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.addChild(this.shape, this.logo, this.cerrar, this.instance_1, this.ampliar, this.texto,this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame1_5_4b = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0, 0, 0, 0, 1);
        this.imagen = new lib.popup_ampliar_06();
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_5_4());
        });
        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    
    (lib.frame1_6 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_ventana_14'], 1, 300);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(324.1, 169.8);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);


        this.instance_1 = new lib.Imagen4MC();
        this.instance_1.setTransform(231.8, 345.1, 1, 1, 0, 0, 0, 150.5, 187.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#8CB8A5").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
        this.shape.setTransform(475.4, 345, 1, 0.992);


        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_6b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });


        this.addChild(this.shape, this.logo, this.cerrar, this.instance_1, this.ampliar, this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame1_6b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_07();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_6());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        top=top || -402;
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left", "texto");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(323, 515);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
      function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
(lib.popup_ampliar_09 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	

	// Capa 4
	this.instance = new lib.CdP_Ampliacio_09();
	this.instance.setTransform(475,303.9,1,1,0,0,0,475,303.9);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:304,y:304,alpha:0.071},0).wait(1).to({alpha:0.143},0).wait(1).to({alpha:0.214},0).wait(1).to({alpha:0.286},0).wait(1).to({alpha:0.357},0).wait(1).to({alpha:0.429},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.571},0).wait(1).to({alpha:0.643},0).wait(1).to({alpha:0.714},0).wait(1).to({alpha:0.786},0).wait(1).to({alpha:0.857},0).wait(1).to({alpha:0.929},0).wait(1).to({alpha:1},0).wait(100000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_08 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	

	// Capa 4
	this.instance = new lib.CdP_Ampliacio_08();
	this.instance.setTransform(475,303.9,1,1,0,0,0,475,303.9);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:304,y:304,alpha:0.071},0).wait(1).to({alpha:0.143},0).wait(1).to({alpha:0.214},0).wait(1).to({alpha:0.286},0).wait(1).to({alpha:0.357},0).wait(1).to({alpha:0.429},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.571},0).wait(1).to({alpha:0.643},0).wait(1).to({alpha:0.714},0).wait(1).to({alpha:0.786},0).wait(1).to({alpha:0.857},0).wait(1).to({alpha:0.929},0).wait(1).to({alpha:1},0).wait(100000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);

(lib.luzHalo = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,0,0.498)").s().p("AhxByQgwgvAAhDQAAhCAwgvQAvgwBCAAQBDAAAvAwQAwAvAABCQAABDgwAvQgvAwhDAAQhCAAgvgwg");
	this.shape.setTransform(16.3,16.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,32.5,32.5);


(lib.electricidad = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00FFFF").ss(1,1,1).p("AhAAAQAAgaATgTQATgTAaAAQAaAAAUATQATATAAAaQAAAagTAUQgUATgaAAQgaAAgTgTQgTgUAAgag");
	this.shape.setTransform(6.5,6.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgtAtQgSgSgBgbQABgZASgUQAUgSAZgBQAbABASASQAUAUgBAZQABAbgUASQgSAUgbgBQgZABgUgUg");
	this.shape_1.setTransform(6.5,6.5);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,13,13);


(lib.circuitoMC = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#2D73B5").ss(6).p("EAHfAg3QAGgdBgg/QA7gmCnhoQFmjnCYjrQBZiKhYhuQhDhUjDhVQjphbhpgtQi1hNgshGQhfiUAYiJQAOhMBZihQAagwBPhQQAtgtBkhiQC2jDgFiYQgEh+gYhSQglh6hdhTQjxjcqIAPQpoAOmDocQh5iphTjLQgahAgUg7IgOgv");
	this.shape.setTransform(229.2,-10.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#EDF6FB").ss(3).p("AAAjVIAAGr");
	this.shape_1.setTransform(130.6,-153);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#EDF6FB").ss(3).p("AjXAAIGwAA");
	this.shape_2.setTransform(130.6,-152.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#EDF6FB").ss(3).p("Ai3AAIFvAA");
	this.shape_3.setTransform(-44.4,-152.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#E76114").ss(3).p("AiXAsIABAcIANAOQASAQAWAIQBHAXBZhIIAAgkIAyhBQAvhFgKgF");
	this.shape_4.setTransform(262.2,209.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#E76114").ss(3).p("AirhOIB0BIIAGAmIAVAOQAaAQAZAIQBVAZA4hDIABgi");
	this.shape_5.setTransform(178.1,208.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#2D73B5").ss(6).p("AnoD1IBEAVQBSASBEgHQDWgagPkZQgPkdD2ArQBPANByAxQA7AaBKAg");
	this.shape_6.setTransform(112.1,216.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#E76114").ss(3).p("Aipg8IgJAVQgGAXAPAHQA1AXAjAEQBOAIAsg/ICTBb");
	this.shape_7.setTransform(45.9,235.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#E76114").ss(3).p("AjAhLIBNAcQBOAeAAAJIAAAmIAPAMQATAOAWAIQBMAbBZgqIAAgk");
	this.shape_8.setTransform(-42.3,223.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#1F1410").ss(2).p("Ag1ARQADgEAFgGQALgKAMgHQAmgUApAo");
	this.shape_9.setTransform(-258,188.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#2D73B5").ss(6).p("AvOjvIAsBnQA+B3BaBSQEgENHIjAQHXjED0AFQBYACBVAdQAwARBaAi");
	this.shape_10.setTransform(-160.9,212.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#1F1410").ss(2).p("AAAgsQAZAAASANQARANAAASQAAASgRAOQgSANgZAAQgYAAgRgNQgSgOAAgSQAAgSASgNQARgNAYAAg");
	this.shape_11.setTransform(-257.7,191.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#5D4E3E").s().p("AgqAgQgRgOAAgSQAAgSARgNQATgNAXAAQAZAAASANQARANAAASQAAASgRAOQgSANgZAAQgXAAgTgNg");
	this.shape_12.setTransform(-257.7,191.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#1F1410").ss(2).p("Aj1gKIHrAV");
	this.shape_13.setTransform(-255.7,134.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#1F1410").ss(2).p("AhhGeIgYitQBVivAShAICNmd");
	this.shape_14.setTransform(-218.8,111.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#1F1410").ss(2).p("AlwDjIAnCeIHcAnIDfrCIAAh3Im2gXIg2CmQg7CvgVAvQgUAshJBwQglA4gkAzg");
	this.shape_15.setTransform(-243.4,110.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#1F1410").ss(2).p("AgJiKIALBEQALBagFB5");
	this.shape_16.setTransform(-216.8,185.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#1F1410").ss(2).p("AogHZQBmAuCQAeQEiA9DXhPIFMxY");
	this.shape_17.setTransform(-238.5,118.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#1F1410").ss(2).p("ADls9IAwAIQA5ALAwATQCbA9AGBwQABAIgBAJIgLFjIkvP9QhgAoiMAMQkbAWjniOQgHgugGg5QgMhxAGg2QABhjAsi3QBYltDUmmQAUgwA/gxQB7hiDagCg");
	this.shape_18.setTransform(-238.9,121.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F6DBB6").s().p("AknKSQiQgehmguQABhjAti3QBXltDUmmQAUgwA/gxQB7hhDagDIAwAIQA5AMAxATQCaA9AGBwIlNRYQh6AtiRAAQhvAAh+gbgAl3GhIHcAnIDerCIAAh4Im1gWIg3ClQg7CvgUAvQgUAthKBvQglA5gjAyIAAAAg");
	this.shape_19.setTransform(-238.8,107.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FCE6CB").s().p("AlwE6QAjgzAlg4QBKhwAUguQAUgvA7itIA3imIG1AXIiPGdQgSBAhVCvg");
	this.shape_20.setTransform(-243.4,101.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#BFA37A").s().p("AjaA7IgnicIAAAAIHrAYIAYCrg");
	this.shape_21.setTransform(-254.5,143);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#BFA37A").s().p("AlsBJQgIgugGg3QgMhxAGg2QBmAuCQAeQEgA8DZhPIAMBFQAMBagGB4QhfAoiOAMQgnADgmAAQjsAAjHh7g");
	this.shape_22.setTransform(-254.5,185.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#BFA37A").s().p("Ah6DwQBWivAShAICNmdIAAB3IjdLCg");
	this.shape_23.setTransform(-218.7,111.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#BFA37A").s().p("AiZHkIgMhEIFLxYQABAIgBAJIgLFiIkuP+QAGh4gMhdg");
	this.shape_24.setTransform(-201.2,129.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAKAZQgqgBgTgUQADgeAoACQAfACAcASQAGAdgsAAIgDAAg");
	this.shape_25.setTransform(-258.5,189.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#E76114").ss(3).p("AgqADIAgABQAggDAGgN");
	this.shape_26.setTransform(19.3,-234.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#E76114").ss(3).p("AgQgYIACAQQAKAPAiAF");
	this.shape_27.setTransform(88.1,-231.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#E76114").ss(3).p("Agrh8IAVAJQAXAMAOAQQAvA1hABJIAOBh");
	this.shape_28.setTransform(91.6,-236.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#E76114").ss(3).p("ABIh+QgcAMgUAKQgjATgVAUQhBA8BMBMIgoA9");
	this.shape_29.setTransform(17.2,-241.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#2D73B5").ss(6).p("ARZ08QhwCZilCUQlLEokLgXQiZgMiJA/Qh8A5heBsQhYBkgoB1QgnB0AWBcQAZBnAKCdQAMC1gPCcQgqGhjMAIQjBAHimDVQhTBqgpBp");
	this.shape_30.setTransform(-100.3,-94.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#FFFFFF").ss(2).p("A1ZAAMAqzAAA");
	this.shape_31.setTransform(40.8,-28.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFFFFF").ss(2).p("A1aAAMAq0AAA");
	this.shape_32.setTransform(41,-54.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FFFFFF").ss(2).p("A1aAAMAq0AAA");
	this.shape_33.setTransform(41,-80.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#1F1410").ss(2).p("AHEEHIgth+ItlmcIAACGIN3F/g");
	this.shape_34.setTransform(116,-226.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#F6B63E").s().p("AGuD5It2l/IAAiGINlGcIAsB+g");
	this.shape_35.setTransform(115.4,-227.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#1F1410").ss(2).p("AJ3kpIzPG/IggA7QgcA/ASAWIAHgOQAJgPALgHQALgHJyjWQE7hpE4hqg");
	this.shape_36.setTransform(-16.3,-229.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#F6B63E").s().p("Ap4DTIAgg7ITPm/IASB7IpyDTQpzDWgKAHQgLAHgJAQIgHANQgTgWAcg/g");
	this.shape_37.setTransform(-16.3,-229.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#1F1410").ss(2).p("AUcheQAkAnAUA3QAVA3gHAoQgHAogfAAMgp7AAAQgfAAgEgoQgEgnAZg4QAZg3AmgnQAmgoAdAAMAmnAAAQAdAAAjAog");
	this.shape_38.setTransform(40.6,-203.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#ACDBF2").s().p("A0/CHQgfAAgEgoQgEgnAZg4QAZg3AmgnQAmgoAdAAMAmnAAAQAdAAAjAoQAkAnAUA3QAVA3gHAoQgHAogfAAg");
	this.shape_39.setTransform(40.6,-203.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#1F1410").ss(2).p("AViwfMAAAAg/QAAA7gqApQgqAqg7AAMgmlAAAQg7AAgqgqQgqgpAAg7MAAAgg/QAAg7AqgqQAqgpA7AAMAmlAAAQA8AAApApQAqAqAAA7g");
	this.shape_40.setTransform(41,-92.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#002B86","#87CAD7","#009DDA","#002B86"],[0.008,0.173,0.369,0.933],-137.7,0,137.9,0).s().p("AzSSuQg7AAgqgqQgqgpAAg7MAAAgg/QAAg7AqgqQAqgpA7AAMAmlAAAQA7AAAqApQAqAqAAA7MAAAAg/QAAA7gqApQgqAqg7AAg");
	this.shape_41.setTransform(41,-92.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#1F1410").s().p("AAAAAQABgJAAAJQAAAFgBAAQAAAAAAgFg");
	this.shape_42.setTransform(-89.7,-37.9);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#1F1410").s().p("AB0JiQirgahVgLQgogFhjgJQhXgHg0gIQgngFhggTQhZgQgxgHQAEgcgCgyQgDg9ABgMQAigeBAghQBggxAKgHQApgYBDgeIBwgyQAIgEAGACIANAFQgBgOABhaQABhIgJgmIAfgMQAQgFAPgBQAEgGAAgPIAAgaQAjACAHgUQAEgjggguQguhBgDgJQgphgA0hcQAxhXBegYQAlgJAwAHQAyAGAlASQA3AaAhBEQAgBCgFBKQgDAxgeA7QglBHgHAaQAOAQADAKQAEANgCAXQAIADAWAAQAVAAAHAEQAJAwgCBTQgDB3AAAWQBlAXB2ALQBQAHCcAFQgDATAIAoQAHAmgEATQgEATgyAvIhGA/Qg8A+h1BlIgFAAQh0AAiZgVgAqNF6QgGATABAXQACAngBANQG9BFA0AHQElAoDmAKQAJgNAAggQAAgZgFgYQhqgOhfAEQhPADh/gUIjYgiQhUgKh3gUQiDgXg7gIQAAgEgDAAIgBAAgAGSHcIgJA5QgDAlAQAOQANACAHgMQAGgOAEgFQApgpBMhEQBWhMAhgfIACguQAAgWgCgTIgMAAQiFCDh9BdgAoiElQgzAcgdAZQAlAKA3AHIBdAMQAUADBQAVQA9APAkAAQAZABATADIAhAHQBFAOBfAJICiANIAuAFQAcACASAAIA1AEQAhADASgDQASgDASgNIAegYQCOhsA7hIQhPgGh9gPIi+gWQADANAAAuQAAApAJAXQhNA6ifgBQiZgChUg3QANhkgQhGQgcgOglAQQgpAXgSAIQASACAgAJQAgAIATACQALANABAiIgBA6QgzAcg8gEQg8gDgtggQAEgKAAgUIAAgjgAjRCFIAEC1QBLAzCBgBQCCAABEg2QgGguAFiAQAFiEgHg7IgIAAQhQAYhxgCQg6gBiYgOQAFBKADBrgAnEEOQgFAIAFANIAHAXQAqAWBHgDQBPgEgGgsQgdAOguADQguADgmgJQgHgCgIgNQgHgLgLAAIgBAAgAlYD3QgiANgNAZQAqAQAogOQAsgQgKgoQgwAIgVAIgAmMDbQgiAMgHAdQAiAKBKgyQgRgHgRAAQgRAAgQAGgAimhoIAHAXIBNANQA0AHAjgCQA7gCAcgGQAygMgCgeQgqgGhcACQhiADg/gGQgMACABAOgAhLpTQhdAegiBCQgoBQA6BpIAtBQQAVAugDAjIAjAHQAXADAMgGQAEgvgGg9QgFg7gMguQgKgYgDgMQgGgXAPgJQAMAFAGAbQAFAYAPACQAQACAIgNQAHgKAEgXQASgEAHAVQAGAXANAAQAMgEADgZQAEgbAIgFQAUAEgFAUQgCAKgJAUQgMA6gFA4QgHBIAJAsQALgDAYABQAUABAKgGQgBgeASgdQAXggAKgVQAagwAEg+QAFhCgXgvQgHgOggghQgigigQgJQgrgXgyAAQglAAgqANgAgLlxIglASQAKAoAGA5IAIBpQAOADAPgDIAegEQAEgcABhLQABhFAGghQgPgMgHgHQgLgMgGgMQAAAVgTALg");
	this.shape_43.setTransform(0.9,196.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#737277").s().p("AgQA7Qg0gHm9hCQABgOgCgmQgBgYAGgSQAEgBAAAFQA6AICEAWQB2AVBVAKIDWAiQCAASBQgEQBfgEBqAPQAEAXAAAaQAAAfgIAOQjmgLklgog");
	this.shape_44.setTransform(-13.3,245.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#C3C161").s().p("AhWAMIgIgVQgFgNAFgIQAMAAAHALQAIANAIACQAmAHArgDQAvgBAcgOQAHAqhPAEIgRAAQg6AAgkgTg");
	this.shape_45.setTransform(-34.8,226.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#E7DD74").s().p("Ag0AWQAGgbAigMQAggMAiANQg8AogiAAQgHAAgFgCg");
	this.shape_46.setTransform(-37.4,220.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#E7DD74").s().p("Ag5AWQAMgWAjgNQATgIAwgJQAKAngsAPQgTAHgSAAQgVAAgWgJg");
	this.shape_47.setTransform(-32.3,222.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["#F2F3F5","#F2EFD0"],[0.09,1],0,-22.9,0,23.2).s().p("AhPDmIgjgGQADgkgVgtIgthRQg6hnAohPQAihCBdgeQBgggBMApQAQAJAiAiQAgAiAHANQAXAwgFBCQgEA7gaAxQgKAUgXAhQgSAdABAeQgKAGgUgBQgYgCgLAEQgJgsAHhJQAFg3AMg5QAJgTACgLQAFgTgUgFQgIAGgEAaQgDAZgMACQgNAAgGgVQgHgVgUAFQgEAWgFALQgIAKgQgCQgPgCgFgWQgGgagMgGQgPAKAGAWQADANAKAWQAMAtAFA8QAGA9gEAuQgIAEgNAAIgOgBg");
	this.shape_48.setTransform(0.2,158.6);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#F2EFD0").s().p("AgYB9IgHhpQgGg3gKgoIAlgSQATgLAAgVQAFAMAMAMQAGAHAQAMQgGAhgBBDQgBBLgEAcIgeAEIgNABQgJAAgIgBg");
	this.shape_49.setTransform(0.9,168.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#EFBC52").s().p("AhFAXIhNgNIgGgVQgCgOAMgCQBAAGBigDQBbgCAqAGQADAcgzAMQgcAGg7ACIgNAAQgfAAgrgFg");
	this.shape_50.setTransform(-0.3,187.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["#5E5E61","#F2F3F5","#5E5E61"],[0.043,0.29,0.663],-20.7,0,20.9,0).s().p("AjDCgIgEizQgDhrgFhMQCYAOA4ABQBzACBQgYIAIAAQAHA9gFCEQgFB+AGAuQhEA2iEAAIgDAAQh9AAhKgyg");
	this.shape_51.setTransform(0,211.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#1F1410").s().p("AhjAxQgLgVAFgZQAIgZACgNQAlgWA7gHQBGgIAhAaQABANAAAUQAAARACANQgXAlhDAKQgRADgRAAQgsAAgmgSgAhjAUQAZApBRgIQBUgHABgxIgBgFQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAQgOAhhCAAQgugEgeAAQgTAAgMABgAgKACQAkAHAagKQAagMAGgeQgKgEgKAAQglAAglAxgAgwgqQgeANACATQAYALAbgNQAYgMAIgWQgJgEgMAAQgRAAgRAIg");
	this.shape_52.setTransform(39.2,229.7);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#E7DD74").s().p("AgpAQQgCgRAegNQAbgMAcAIQgKAUgYANQgMAHgOAAQgMAAgLgGg");
	this.shape_53.setTransform(35.7,226.9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#ABA9B0").s().p("AEzCdIg1gEQgTAAgbgCIgvgFIihgNQhfgJhFgOIgigHQgTgDgYgBQglAAg8gPQhRgVgTgDIhdgMQg3gHglgKQAcgZA0gaIBWgwIAAAjQAAAUgEAKQAsAeA8ADQA9AEAzgcIAAg4QAAgigMgNQgTgCgfgIQghgJgRgCQASgIAogXQAlgQAcAOQARBGgNBiQBTA3CaACQCeABBNg6QgIgVAAgpQAAgugDgNIC9AWQB+APBOAGQg6BGiOBsIgeAYQgTANgRADIgWACIgdgCgAGDguQg+AHgkAWQgCANgIAZQgFAZALAVQA0AYBBgJQBEgKAXglQgCgNAAgTQAAgSgCgNQgZgUguAAQgPAAgQACg");
	this.shape_54.setTransform(0.7,227.9);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#E7DD74").s().p("AgvAYQAxhAAuATQgGAbgbANQgPAHgUAAQgNAAgOgCg");
	this.shape_55.setTransform(42.9,227.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#C3C161").s().p("AhfAAQAfgDBMAEQBCABAOgiQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABIABAEQgBAyhUAHIgWABQg/AAgVghg");
	this.shape_56.setTransform(38.8,231.9);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#737277").s().p("Ah+ClQgQgNADgmIAJg5QB9hbCDiCIAMAAQACASAAAXIgCAtQghAghWBKQhKBDgpApQgEAFgGAPQgGAJgKAAIgEAAg");
	this.shape_57.setTransform(54.3,238.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#1F1410").s().p("AB0JjQirgbhVgKQgrgGhggIQhZgIgxgHQgogGhggSQhZgRgxgGQAEgdgCgyQgDg8ABgMQAfgfBBgfQBbgrARgLQBgg5A+gaQAQgGAdgOQAYgKAUAFQgBgLABhcQABhGgJglIAfgMQARgGAOAAQAEgGAAgQIAAgZQAiABAIgTQAEgkggguQgthAgEgJQgbg/AOhDQANhCAugqQAUgRAbgSQAhgUAZgGQApgLA1AIQAtAIAkARQA3AaAhBGQAgBCgFBIQgDAugfA+QglBKgGAXQAOAQADAJQAFANgCAXQAHADAWAAQAVABAHAEQAJAvgCBTQgDB3AAAWQBkAYB3AKQBMAHCgAGQgDATAIAoQAHAmgEASQgEAUgyAvQg3AxgOAOQhEBEhuBeIgFAAQh0AAiZgUgAqNF7QgGATABAXQACAnAAANIHwBLQElApDmAKQAJgOAAgfQAAgagFgXQhsgPhcAEQhQAEh/gUIjXgiQhVgKh3gVQiEgXg6gHQgBgEgCAAIgBAAgAGSHcIgJA5QgDAmAQANQAOACAGgLIAKgUQApgpBMhDQBXhNAggfIACgtQAAgXgCgSIgMAAQiBCAiBBfgAoiEmQgzAcgdAZQAlAJA3AHIBdAMQAVAEBPAUQA9AQAkAAQAYAAAUAEIAhAHQBFAOBfAJICiANIAuAEIAuADIA1AEQAiACASgCQARgDATgNQALgIASgQQBCgzApgkQA7gzAjgqQhQgHh8gPQiUgRgqgEQADAMAAAuQAAApAJAXQhNA7ifgCQiagBhSg4QAMhlgQhEQgcgPglAQQgoAXgTAIQASACAgAJQAgAJATACQALANABAhIgBA6QgzAcg8gDQg8gDgtggQAFgKAAgVIgBgiIhWAwgAjRCFIAEC1QBJA0CDgBQCCAABEg2QgGguAFiBQAFiEgHg7IgIAAQhQAZhxgCQg7gBiXgPQAFBKADBrgAnEEPQgFAIAFANIAHAWQAqAXBHgEQBPgDgGgtQgdAPguADQguADglgKQgHgBgJgNQgHgLgLAAIgBAAgAlYD4QgiANgMAYQApARAogPQAsgPgKgpQgwAJgVAIgAmMDbQgiANgHAcQAjALBJgzQgRgGgRAAQgRAAgQAFgAimhnIAHAXQAxAMBDADQBDADA2gHQAggFANgGQAWgLgFgWQgrgFhbACQhiACg/gGQgMADABAOgAhdpNQhqArgOBYQgNBQA0BSQAdAuAHARQARAmgDAnQALAIAVACQAXADAOgGQAEgugGg9QgFg8gMgtQgKgYgDgNQgGgWAPgKQAMAHAGAaQAFAXAPACQARACAIgOIAOgfQAQgDAGAWQAGAWAQgCQAMgEADgZQAEgaAIgGQAUAFgFATQgCALgJATQgMA6gFA5QgHBIAJAsQALgEAYACQAUABAKgGQgBgeATgfIAggzQAZgvAEhBQAFhDgWgsQgHgOggghQghgigRgJQgtgZgzAAQgsAAgyAUgAgOlwQgaAKgLAIQAKAnAGA6QADAeAEBKQAgAFAjgMQgFhVANh0QgRgMgIgHQgNgLgEgOQgBAVgSAMg");
	this.shape_58.setTransform(219.5,180.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#737277").s().p("AgQA7InxhJQABgNgCgnQgBgXAGgTQADgBABAFQA5AHCFAXQB2AVBVAKIDWAiQCAASBQgEQBcgEBtAPQAFAXAAAaQgBAfgIAOQjmgKklgpg");
	this.shape_59.setTransform(205.2,229.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#C3C161").s().p("AhWAMIgIgUQgFgOAFgIQAMAAAIALQAIANAHACQAmAHAsgDQAugBAcgOQAGAqhPAEIgSAAQg4AAgkgTg");
	this.shape_60.setTransform(183.7,211.1);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#E7DD74").s().p("Ag0AWQAGgbAigMQAggMAiANQg7AogiAAQgIAAgFgCg");
	this.shape_61.setTransform(181.1,204.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#E7DD74").s().p("Ag5AWQAMgWAigNQATgIAwgJQAKAngsAPQgTAHgRAAQgVAAgWgJg");
	this.shape_62.setTransform(186.2,207.2);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#F2EFD0").s().p("AgaB9QgEhKgDgfQgFg3gLgoQALgHAagLQATgLAAgVQAEANAOAMQAIAHARALQgNBzAFBVQgaAIgXAAIgTgBg");
	this.shape_63.setTransform(219.3,153.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#F2F3F5","#F2EFD0"],[0.09,1],0,-23,0,23.2).s().p("AhVDmQgWgCgLgIQADgngQgmQgIgRgcguQg0hQAMhQQAOhYBrgrQBngqBXAvQAQAJAhAiQAhAhAGAOQAWAsgEBDQgEA/gZAvIghAzQgSAfABAeQgKAGgVgBQgYgCgLAEQgIgsAGhIQAFg5ANg4QAIgTADgLQAFgTgUgFQgJAGgDAaQgDAZgMACQgQACgHgUQgGgWgSADIgMAfQgHAMgRgCQgQgCgFgVQgFgagNgHQgOAKAFAWQADANAKAWQAMAtAGA8QAFA9gDAuQgKAEgNAAIgOgBg");
	this.shape_64.setTransform(218.9,143.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#EFBC52").s().p("AgeAaQhDgDgxgMIgHgVQgBgOAMgCQA/AGBigDQBbgCArAGQAFAUgWALQgNAGggAEQglAFgrAAIgpgBg");
	this.shape_65.setTransform(218.2,171.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#5E5E61","#F2F3F5","#5E5E61"],[0.043,0.29,0.663],-20.7,0,20.9,0).s().p("AjDCfIgEizQgDhrgFhMQCXAPA5ABQBzACBQgYIAIAAQAHA8gFCEQgFCAAGAtQhEA2iEABIgDAAQh/AAhIg0g");
	this.shape_66.setTransform(218.5,196.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#1F1410").s().p("AhjAxQgLgVAFgZQAIgZACgNQAlgWA7gHQBGgIAhAaQABANAAAUQAAARACANQgXAmhDAJQgRADgQAAQgtAAgmgSgAhjAUQAZApBRgHQBUgIABgxIgBgFQAAAAAAgBQAAAAgBgBQAAAAgBAAQAAAAgBAAQgOAihCgBQgvgEgfAAQgRAAgMABgAgKACQAkAIAagLQAagMAGgeQgKgEgLAAQgkAAglAxgAgwgqQgeANACATQAYALAbgNQAYgMAIgWQgJgEgMAAQgRAAgRAIg");
	this.shape_67.setTransform(257.8,214.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#E7DD74").s().p("AgpAQQgCgRAegNQAbgMAcAIQgKAUgYANQgMAHgOAAQgMAAgLgGg");
	this.shape_68.setTransform(254.3,211.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#ABA9B0").s().p("AEzCdIg1gDIgugDIgvgFIiigNQhegJhFgOIgigHQgTgDgZAAQgkgBg8gPQhPgVgVgDIhdgMQg3gHglgKQAcgYA0gbIBWgwIAAAjQAAAUgEAKQAsAfA8ADQA9ACAzgbIAAg4QAAgigMgNQgTgCgfgIQghgJgRgCQASgIApgXQAlgQAbAOQAQBEgMBkQBTA3CaACQCeABBNg6QgIgVAAgpQAAgugDgNQAqAECTASQB9APBPAGQgiArg7AxQgpAkhCAzQgTAQgLAHQgSAOgSACIgWACIgdgCgAGDguQg9AHgmAWQgCANgIAZQgEAZALAVQA0AYBBgJQBEgJAXgmQgCgNAAgTQAAgSgCgNQgZgUguAAQgPAAgQACg");
	this.shape_69.setTransform(219.3,212.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#737277").s().p("Ah+ClQgQgNADgmIAJg5QCBhdB/iAIAMAAQACASAAAXIgCAtQggAfhXBLQhKBDgpApIgKAUQgFAJgLAAIgEAAg");
	this.shape_70.setTransform(272.9,222.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#E7DD74").s().p("AguAYQAvhAAuATQgGAbgaANQgPAIgUAAQgMAAgOgDg");
	this.shape_71.setTransform(261.5,212.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#C3C161").s().p("AhfAAQAfgEBMAFQBCABAOgiQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAIABAFQgBAxhUAIIgVABQg/AAgWghg");
	this.shape_72.setTransform(257.4,216.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#1F1410").s().p("AAAAAQABgJAAAJQAAAFgBAAQAAAAAAgFg");
	this.shape_73.setTransform(38.6,-194.7);

	this.addChild(this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-293.3,-259.5,658.8,519.2);

(lib.CircuitoAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 5
	this.instance = new lib.luzHalo();
	this.instance.setTransform(139.3,196.3,1,1,0,0,0,16.3,16.3);

	this.instance_1 = new lib.luzHalo();
	this.instance_1.setTransform(139.3,196.3,1,1,0,0,0,16.3,16.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance,p:{x:139.3,y:196.3}}]},46).to({state:[{t:this.instance_1},{t:this.instance,p:{x:245.3,y:192.3}}]},7).to({state:[]},46).wait(20));

	// Capa 3
	this.instance_2 = new lib.electricidad();
	this.instance_2.setTransform(144.7,14.9,1,1,0,0,0,6.5,6.5);
	this.instance_2.shadow = new cjs.Shadow("rgba(0,255,255,1)",0,0,5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(9).to({_off:false},0).to({guide:{path:[144.6,15.1,139.2,22.4,131.3,29.4,115.5,43.6,102.7,42.5,95.4,41.9,88.7,45,82.8,47.7,78.2,52.9,74,57.7,72.3,63.2,70.5,68.6,71.5,73,72.5,77.9,73,85.6,73.6,94.2,72.8,101.7,71.9,111.7,69.1,116.8,66.2,121.8,61.3,122,52,122.4,44.1,132.6,43.4,133.4,42.8,134.2]}},20).to({_off:true},1).wait(3).to({x:17.8,y:219.4,_off:false},0).to({guide:{path:[17.9,219.4,20.9,225.1,25.2,229.1,39,241.9,60.6,232.8,83.2,223.3,94.9,223.6,99.1,223.6,103.2,225,105.5,225.8,109.8,227.6]}},12).to({_off:true},1).wait(2).to({x:169.6,y:239.5,_off:false},0).to({guide:{path:[169.6,239.4,171.2,239.9,172.9,240.4,176.8,241.3,180,241,190.3,239.7,189.6,226.2,188.8,212.6,200.7,214.6,204.5,215.2,209.9,217.5,212.8,218.8,216.3,220.3]}},4).to({_off:true},1).wait(2).to({x:274.9,y:216.9,_off:false},0).to({guide:{path:[274.7,216.8,275.6,216.2,276.8,215.5,279.6,213.7,287.6,208.7,304.7,197.6,312,186.4,316.2,179.8,312,174.5,308.8,170.5,299.5,166.5,288.4,162.1,283.3,159.9,274.7,156.2,272.5,152.9,268,145.8,269.2,139.3,269.8,135.6,274.1,127.9,275.4,125.7,279.1,121.8,281.3,119.6,286,114.9,294.8,105.7,294.5,98.5,294.3,92.4,293.2,88.5,291.4,82.7,287,78.7,275.4,68.2,244.4,68.9,214.9,69.6,196.4,43.7,190.6,35.7,186.6,25.9,185.4,22.9,184.4,20.1,184.1,18.9,183.8,17.8]}},19).to({_off:true},2).wait(43));

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC0000").ss(1,1,1).p("AAAByQhmAAhKgiQhJgiAAguQAAgsBJgjQBKghBmAAQBnAABIAhQBKAjAAAsQAAAuhKAiQhIAihnAAgADSBfQhXAoh7AAQh7AAhYgoQhXgoAAg3QAAg2BXgpQBYgnB7AAQB7AABXAnQBZApAAA2QAAA3hZAog");
	this.shape.setTransform(21.1,182.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC0000").s().p("AhNAiQgfgOAAgUQAAgTAfgPQAhgOAsAAQAtAAAgAOQAgAPAAATQAAAUggAOQggAPgtABQgsgBghgPg");
	this.shape_1.setTransform(21.1,182.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},9).to({state:[]},90).wait(20));

	// Capa 1
	this.instance_3 = new lib.circuitoMC();
	this.instance_3.setTransform(158,123.8,0.478,0.478,0,0,0,37,-0.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(119));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,315.1,248.3);

    (lib.CdP_Ampliacio_10 = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib.FQ_09_08_043();
        this.instance.setTransform(82.3, 123.5);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_07 = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib.interruptor81270151_OPT();
        this.instance.setTransform(318.4, 44.4, 1.27, 1.27);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_06 = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib.timbre100120078_OPT();
        this.instance.setTransform(326.2, 52.4, 1.225, 1.225);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_05 = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib.Motor118187653_OPT();
        this.instance.setTransform(157.3, 82.3, 1.08, 1.08);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_04 = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib.bombilla106470875_OPT();
        this.instance.setTransform(134, 69.4, 1.15, 1.15);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_03 = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib.Tostadora100748652_OPT();
        this.instance.setTransform(212.8, 98.4);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_02 = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib.Dinamo_shutter_43131142_OPT();
        this.instance.setTransform(178.3, 99.4);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_01 = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib._92211946_OPT();
        this.instance.setTransform(320.1, 61.4, 1.19, 1.19);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


  


    (lib.Imagen6MC = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#9B4118").ss(2).p("AjlAAQAAheBEhEQBDhDBeAAQBfAABDBDQBEBEAABeQAABfhEBDQhDBEhfAAQheAAhDhEQhEhDAAhfg");
        this.shape.setTransform(379, 7.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -16.9, 15.4, 17.1).s().p("AihCiQhEhDAAhfQAAheBEhDQBDhDBegBQBfABBDBDQBEBDAABeQAABfhEBDQhDBDhfAAQheAAhDhDg");
        this.shape_1.setTransform(379, 7.5);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#9B4118").ss(2).p("ACiihQBEBDAABeQAABfhEBDQhDBEhfAAQheAAhDhEQhEhDAAhfQAAheBEhDQBDhEBeAAQBfAABDBEg");
        this.shape_2.setTransform(310, -95.5);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -17, 15.4, 17.1).s().p("AiiCiQhDhDABhfQgBheBDhEQBEhCBeAAQBfAABDBCQBEBEAABeQAABfhEBDQhDBEhfAAQheAAhEhEg");
        this.shape_3.setTransform(310, -95.5);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#9B4118").ss(2).p("ACiiiQBEBEAABeQAABfhEBDQhDBEhfAAQheAAhDhEQhEhDAAhfQAAheBEhEQBDhDBeAAQBfAABDBDg");
        this.shape_4.setTransform(235, 7.5);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -17, 15.4, 17.1).s().p("AihCiQhEhDAAhfQAAheBEhDQBDhDBegBQBfABBDBDQBEBDAABeQAABfhEBDQhDBDhfAAQheAAhDhDg");
        this.shape_5.setTransform(235, 7.5);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f().s("#9B4118").ss(2).p("ACiiiQBEBEAABeQAABfhEBDQhDBEhfAAQheAAhDhEQhEhDAAhfQAAheBEhEQBDhDBeAAQBfAABDBDg");
        this.shape_6.setTransform(310, 100.5);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -17, 15.4, 17.1).s().p("AiiCiQhDhDABhfQgBheBDhDQBEhEBeAAQBfAABDBEQBEBDAABeQAABfhEBDQhDBEhfAAQheAAhEhEg");
        this.shape_7.setTransform(310, 100.5);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f().s("#9B4118").ss(2).p("ADmAAQAABfhEBDQhDBEhfAAQheAAhEhEQhDhDAAhfQAAheBDhDQBEhEBeAAQBfAABDBEQBEBDAABeg");
        this.shape_8.setTransform(-118.9, -66.5);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -16.9, 15.4, 17.1).s().p("AihCiQhDhDgBhfQABheBDhEQBDhDBeABQBfgBBDBDQBDBEAABeQAABfhDBDQhDBEhfAAQheAAhDhEg");
        this.shape_9.setTransform(-118.9, -66.5);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f().s("#9B4118").ss(2).p("ADmAAQAABfhEBDQhDBEhfAAQheAAhEhEQhDhDAAhfQAAheBDhEQBEhDBeAAQBfAABDBDQBEBEAABeg");
        this.shape_10.setTransform(-113.9, 77.5);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -17, 15.4, 17.1).s().p("AiiCiQhChDAAhfQAAheBChEQBEhDBeABQBfgBBDBDQBEBEAABeQAABfhEBDQhDBEhfAAQheAAhEhEg");
        this.shape_11.setTransform(-113.9, 77.5);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f().s("#9B4118").ss(2).p("ACiihQBEBDAABeQAABfhEBDQhDBEhfAAQheAAhEhEQhDhDAAhfQAAheBDhDQBEhEBeAAQBfAABDBEg");
        this.shape_12.setTransform(21, -95.5);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -16.9, 15.4, 17.1).s().p("AiiCiQhChDAAhfQAAheBChEQBEhCBeAAQBfAABDBCQBEBEAABeQAABfhEBDQhDBEhfAAQheAAhEhEg");
        this.shape_13.setTransform(21, -95.5);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f().s("#9B4118").ss(2).p("ACiiiQBEBEAABeQAABfhEBDQhDBEhfAAQheAAhEhEQhDhDAAhfQAAheBDhEQBEhDBeAAQBfAABDBDg");
        this.shape_14.setTransform(-17.9, 7.5);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -17, 15.4, 17.1).s().p("AihCiQhEhDAAhfQAAheBEhDQBDhDBegBQBfABBDBDQBDBDAABeQAABfhDBDQhDBDhfAAQheAAhDhDg");
        this.shape_15.setTransform(-17.9, 7.5);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f().s("#9B4118").ss(2).p("ACiihQBEBDAABeQAABfhEBDQhDBEhfAAQheAAhEhEQhDhDAAhfQAAheBDhDQBEhEBeAAQBfAABDBEg");
        this.shape_16.setTransform(154, -66.5);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -17, 15.4, 17.1).s().p("AihCiQhEhDAAhfQAAheBEhEQBDhDBeABQBfgBBDBDQBEBEAABeQAABfhEBDQhDBEhfAAQheAAhDhEg");
        this.shape_17.setTransform(154, -66.5);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f().s("#9B4118").ss(2).p("ADmAAQAABfhEBDQhDBEhfAAQheAAhEhEQhDhDAAhfQAAheBDhEQBEhDBeAAQBfAABDBDQBEBEAABeg");
        this.shape_18.setTransform(161, 69.5);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -17, 15.4, 17.1).s().p("AihCiQhDhDgBhfQABheBDhEQBDhDBeAAQBfAABDBDQBDBEAABeQAABfhDBDQhDBDhfAAQheAAhDhDg");
        this.shape_19.setTransform(161, 69.5);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f().s("#9B4118").ss(2).p("ACiCiQhDBEhfAAQheAAhEhEQhDhDAAhfQAAheBDhEQBEhDBeAAQBfAABDBDQBEBEAABeQAABfhEBDg");
        this.shape_20.setTransform(44, 100.5);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -17, 15.4, 17.1).s().p("AihCiQhDhDgBhfQABheBDhDQBDhEBeAAQBfAABDBEQBDBDAABeQAABfhDBDQhDBEhfAAQheAAhDhEg");
        this.shape_21.setTransform(44, 100.5);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f().s("#9B4118").ss(2).p("ACiiiQBEBEAABeQAABfhEBDQhDBEhfAAQheAAhDhEQhEhDAAhfQAAheBEhEQBDhDBeAAQBfAABDBDg");
        this.shape_22.setTransform(-291.9, 100.5);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -16.9, 15.4, 17.1).s().p("AiiCiQhDhDABhfQgBheBDhDQBEhEBeAAQBfAABDBEQBEBDAABeQAABfhEBDQhDBEhfAAQheAAhEhEg");
        this.shape_23.setTransform(-291.9, 100.5);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f().s("#9B4118").ss(2).p("AAAjlQBfAABDBDQBEBEAABeQAABfhEBDQhDBEhfAAQheAAhDhEQhEhDAAhfQAAheBEhEQBDhDBeAAg");
        this.shape_24.setTransform(-232.9, 7.5);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -16.9, 15.4, 17.1).s().p("AihCiQhEhDAAhfQAAheBEhDQBDhDBegBQBfABBDBDQBEBDAABeQAABfhEBDQhDBDhfAAQheAAhDhDg");
        this.shape_25.setTransform(-232.9, 7.5);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f().s("#9B4118").ss(2).p("ACiihQBEBDAABeQAABfhEBDQhDBEhfAAQheAAhDhEQhEhDAAhfQAAheBEhDQBDhEBeAAQBfAABDBEg");
        this.shape_26.setTransform(-291.9, -95.5);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.lf(["#FFFFFF", "#E19A59"], [0, 0.471], -15.3, -16.9, 15.4, 17.1).s().p("AiiCiQhDhDABhfQgBheBDhEQBEhCBeAAQBfAABDBCQBEBEAABeQAABfhEBDQhDBEhfAAQheAAhEhEg");
        this.shape_27.setTransform(-291.9, -95.5);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f().s("#2D73B5").ss(3).p("Eg9jAAAMB7HAAA");
        this.shape_28.setTransform(44, -145.5);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.f().s("#2D73B5").ss(3).p("EA9kAAAMh7HAAA");
        this.shape_29.setTransform(44, 146.5);

        this.shape_30 = new cjs.Shape();
        this.shape_30.graphics.lf(["#82C7CF", "#ECF6F9", "#82C7CF"], [0, 0.502, 0.988], 0, -145.9, 0, 146).s().p("Eg9jAWzMAAAgtlMB7HAAAMAAAAtlg");
        this.shape_30.setTransform(44, 0.5);

        this.addChild(this.shape_30, this.shape_29, this.shape_28, this.shape_27, this.shape_26, this.shape_25, this.shape_24, this.shape_23, this.shape_22, this.shape_21, this.shape_20, this.shape_19, this.shape_18, this.shape_17, this.shape_16, this.shape_15, this.shape_14, this.shape_13, this.shape_12, this.shape_11, this.shape_10, this.shape_9, this.shape_8, this.shape_7, this.shape_6, this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-349.9, -145.5, 788, 292);


    (lib.Imagen5MC = function () {
        this.initialize();

        // Capa 1
        this.text = new cjs.Text("Fuente de FEM", "28px Verdana", "#0066FF");
        this.text.textAlign = "center";
        this.text.lineHeight = 30;
        this.text.lineWidth = 353;
        this.text.setTransform(39.5, -4.4);

        this.text_1 = new cjs.Text("Diferencia de potencial", "28px Verdana");
        this.text_1.textAlign = "center";
        this.text_1.lineHeight = 30;
        this.text_1.lineWidth = 353;
        this.text_1.setTransform(39.5, -51.7);

        this.text_2 = new cjs.Text("Polo positivo (+)", "30px Verdana");
        this.text_2.lineHeight = 32;
        this.text_2.lineWidth = 267;
        this.text_2.setTransform(-394.1, -140.3);

        this.text_3 = new cjs.Text("Polo negativo (-)", "30px Verdana");
        this.text_3.lineHeight = 32;
        this.text_3.lineWidth = 299;
        this.text_3.setTransform(182.3, -216.2);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1F1410").ss(3).p("AAAiQIAAEh");
        this.shape.setTransform(-130.1, -27);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1F1410").ss(3).p("A4/FcMAx/gK3");
        this.shape_1.setTransform(44.3, -91.9);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1F1410").ss(3).p("A6FFfMA0MgK+");
        this.shape_2.setTransform(44, -125.9);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1F1410").ss(3).p("AGGDPQgkArgxAAIphAAQgyAAgjgrQgjgpAAg7IAAjVQAAgqATgjQATgiAegSQAYgOAcAAIJhAAQAxAAAkAqQAjAqAAA7IAADVQAAA7gjApg");
        this.shape_3.setTransform(246.9, -137.5);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1F1410").ss(3).p("AGphqIAADVQAAATgFATQgKAtggAeQghAegoAAIphAAQgyAAgjgrQgjgpAAg7IAAjVQAAg7AjgqQAjgqAyAAIJhAAQAVAAATAIQAjAPAWAlQAXAmAAAtg");
        this.shape_4.setTransform(-157.6, -66.5);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#1F1410").ss(3).p("A7kHsMA26AAAIAAvm");
        this.shape_5.setTransform(44.9, -61.7);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f().s("#1F1410").ss(3).p("EgkFgKkIAAEiIkFAAQgpAAgdAdQgdAeAAArIAAYSQAAArAdAdQAdAeApAAMBQUAAAQAqAAAdgeQAdgdAAgrIAA4SQAAgrgdgeQgdgdgqAAIkxAAIAAvo");
        this.shape_6.setTransform(47.9, 26.2);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_7.setTransform(183.2, 81.4);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_8.setTransform(-146.6, -49.3);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15).s().p("AgHCWQg+gDgqgvQgqguAEg8QAEg/AugpQAugqA9ADQA+ADApAvQAqAugDA9QgDA+gvAqQgrAmg5AAIgHAAg");
        this.shape_9.setTransform(225.3, 36.1);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_10.setTransform(208.8, 63.6);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_11.setTransform(154.6, 97.4);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_12.setTransform(124.5, 106.5);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.3).s().p("AhrBqQgtgsAAg+QAAg8AtgtQAtgsA+AAQA/AAAtAsQAtAtAAA8QAAA9gtAtQgtAsg/AAQg+AAgtgsg");
        this.shape_13.setTransform(92.3, 112);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg8AsgtQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_14.setTransform(59.2, 112);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_15.setTransform(27.8, 110);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAtAAA8QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_16.setTransform(-3.3, 108);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_17.setTransform(-34.4, 102.9);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_18.setTransform(-64.6, 93.9);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_19.setTransform(-94.9, 83.4);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_20.setTransform(-121, 66.4);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg8AAgtgsg");
        this.shape_21.setTransform(-141.2, 41.1);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_22.setTransform(-149.1, 11);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg8AAgtgsg");
        this.shape_23.setTransform(-153.2, -19.2);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_24.setTransform(238.3, 6);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_25.setTransform(240.3, -26);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg8AsgtQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_26.setTransform(239.3, -58.5);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_27.setTransform(239.3, -91.5);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg8AsgtQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_28.setTransform(238.3, -123.8);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_29.setTransform(214.3, -145);

        this.shape_30 = new cjs.Shape();
        this.shape_30.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_30.setTransform(183.2, -138.8);

        this.shape_31 = new cjs.Shape();
        this.shape_31.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_31.setTransform(151.8, -131.2);

        this.shape_32 = new cjs.Shape();
        this.shape_32.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAtAAA8QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_32.setTransform(121.7, -124.8);

        this.shape_33 = new cjs.Shape();
        this.shape_33.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAtAAA8QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_33.setTransform(89.3, -118.8);

        this.shape_34 = new cjs.Shape();
        this.shape_34.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_34.setTransform(59.2, -111.8);

        this.shape_35 = new cjs.Shape();
        this.shape_35.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg8AsgtQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_35.setTransform(29, -105.7);

        this.shape_36 = new cjs.Shape();
        this.shape_36.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_36.setTransform(-2.1, -99.5);

        this.shape_37 = new cjs.Shape();
        this.shape_37.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_37.setTransform(-33.4, -91.9);

        this.shape_38 = new cjs.Shape();
        this.shape_38.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_38.setTransform(-63.6, -85.5);

        this.shape_39 = new cjs.Shape();
        this.shape_39.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_39.setTransform(-95.9, -79.5);

        this.shape_40 = new cjs.Shape();
        this.shape_40.graphics.rf(["#E9E443", "#778C1C"], [0.012, 1], 0, 0, 0, 0, 0, 15.1).s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAQg9AAgsgsg");
        this.shape_40.setTransform(-126.1, -72.6);

        this.shape_41 = new cjs.Shape();
        this.shape_41.graphics.f("#EBC784").s().p("AmFDPQgigpgBg8IAAjUQABg7AigqQAkgpAyAAIJfAAQAWAAATAHQAjAQAWAkQAWAlABAuIAADHIgOBHQgWBHgsAGQgsAFkaADIlCAAQgyABgkgrg");
        this.shape_41.setTransform(-157.6, -66.5);

        this.shape_42 = new cjs.Shape();
        this.shape_42.graphics.f("#EBC784").s().p("AkwD5QgyABgigqQgjgqAAg8IAAjUQgBgqAUgjQARgiAfgSQAYgNAcAAIJhAAQAxAAAjApQAkAqgBA7IAADUQABA7gkArQgjAqgxgBg");
        this.shape_42.setTransform(246.9, -137.5);

        this.shape_43 = new cjs.Shape();
        this.shape_43.graphics.f("#EBC784").s().p("A42E/QAAgugWglQgWglgkgPMA0NgK+QgfASgSAhQgTAkAAApIAADXMgx5AK2g");
        this.shape_43.setTransform(44, -109.1);

        this.shape_44 = new cjs.Shape();
        this.shape_44.graphics.f("#EBC784").s().p("EgoKAVkQgpAAgdgeQgdgeAAgqIAA4TQAAgrAdgdQAdgeApAAIEFAAIAAkiIISAAIAAEiMA2rAAAIAAvoIIgAAIAAPoIEyAAQApAAAdAeQAdAdAAArIAAYTQAAAqgdAeQgdAegpAAg");
        this.shape_44.setTransform(47.9, 25.5);

        this.addChild(this.shape_44, this.shape_43, this.shape_42, this.shape_41, this.shape_40, this.shape_39, this.shape_38, this.shape_37, this.shape_36, this.shape_35, this.shape_34, this.shape_33, this.shape_32, this.shape_31, this.shape_30, this.shape_29, this.shape_28, this.shape_27, this.shape_26, this.shape_25, this.shape_24, this.shape_23, this.shape_22, this.shape_21, this.shape_20, this.shape_19, this.shape_18, this.shape_17, this.shape_16, this.shape_15, this.shape_14, this.shape_13, this.shape_12, this.shape_11, this.shape_10, this.shape_9, this.shape_8, this.shape_7, this.shape_6, this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape, this.text_3, this.text_2, this.text_1, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-394.1, -216.2, 879.9, 379.8);


    (lib.Imagen4MC = function () {
        this.initialize();

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A0P9NMAofAAAMAAAA6bMgofAAAg");
        mask.setTransform(129.6, 187);

        // Capa 2
        this.instance = new lib.interruptor81270151_OPT();
        this.instance.setTransform(-3.5, -16.6);

        this.instance.mask = mask;

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-3.5, -16.6, 267, 400);


    (lib.Imagen3MC = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A0P9SMAofAAAMAAAA6lMgofAAAg");
        mask.setTransform(129.6, 187.5);

        // Capa 2
        this.instance = new lib.Tostadora100748652_OPT();
        this.instance.setTransform(-20.1, 83.4, 0.535, 0.535);

        this.instance_1 = new lib.bombilla106470875_OPT();
        this.instance_1.setTransform(-31, -3.6, 0.99, 0.99);

        this.instance_2 = new lib.Motor118187653_OPT();
        this.instance_2.setTransform(-5.6, 76, 0.562, 0.562);

        this.instance_3 = new lib.timbre100120078_OPT();
        this.instance_3.setTransform(-1.1, -10.6);

        this.instance.mask = this.instance_1.mask = this.instance_2.mask = this.instance_3.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}]}).to({state: [{t: this.instance_1}]}, 1).to({state: [{t: this.instance_2}]}, 1).to({state: [{t: this.instance_3}]}, 1).to({state: []}, 1).wait(1));

        // Capa 4
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().dr(-129.65, -187.5, 259.3, 375);
        this.shape.setTransform(129.6, 187.5);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).wait(5));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-20.1, 0, 285.1, 375);


    (lib.Imagen2MC = function () {
        this.initialize();

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A0P9SMAofAAAMAAAA6lMgofAAAg");
        mask.setTransform(129.6, 187.5);

        // Capa 2
        this.instance = new lib.Dinamo_shutter_43131142_OPT();
        this.instance.setTransform(-75.9, 44.3, 0.715, 0.715);

        this.instance.mask = mask;

        // Capa 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().dr(-129.65, -187.5, 259.3, 375);
        this.shape.setTransform(129.6, 187.5);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-75.9, 0, 430.7, 375);


    (lib.Imagen1MC = function () {
        this.initialize();

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A0P9SMAofAAAMAAAA6lMgofAAAg");
        mask.setTransform(129.6, 187.5);

        // Capa 2
        this.instance = new lib._92211946_OPT();
        this.instance.setTransform(-7.5, -9.9);

        this.instance.mask = mask;

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-7.5, -9.9, 267, 400);



    (lib.popup_ampliar_10 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance = new lib.CdP_Ampliacio_10();
        this.instance.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(10000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_07 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance = new lib.CdP_Ampliacio_07();
        this.instance.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(1000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_06 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance = new lib.CdP_Ampliacio_06();
        this.instance.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(10000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_05 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance = new lib.CdP_Ampliacio_05();
        this.instance.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(10000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_04 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance = new lib.CdP_Ampliacio_04();
        this.instance.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(10000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_03 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance = new lib.CdP_Ampliacio_03();
        this.instance.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(10000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance = new lib.CdP_Ampliacio_02();
        this.instance.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(10000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance = new lib.CdP_Ampliacio_01();
        this.instance.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_09 = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib.Imagen6MC();
        this.instance.setTransform(479.3, 312.4, 1, 1, 0, 0, 0, 44, 0.5);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_08 = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib.Imagen5MC();
        this.instance.setTransform(480, 307.8, 1, 1, 0, 0, 0, 23.2, -21);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.Imagen4MC = function () {
        this.initialize();

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A0P9NMAofAAAMAAAA6bMgofAAAg");
        mask.setTransform(129.6, 187);

        // Capa 2
        this.instance = new lib.interruptor81270151_OPT();
        this.instance.setTransform(-3.5, -16.6);

        this.instance.mask = mask;

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-3.5, -16.6, 267, 400);

   

    (lib.mc_boto_03 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 2, 1).rr(-125, -15, 250, 30, 6);
        this.shape.setTransform(125, 15);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1, 2, 1).rr(-125, -15, 250, 30, 6);
        this.shape_1.setTransform(125, 15);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#666666").ss(1, 2, 1).rr(-125, -15, 250, 30, 6);
        this.shape_2.setTransform(125, 15);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 250, 30);

    (lib.mc_boto_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 5
        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.498)").s().p("A3wY0MAAAgxnMAvhAAAMAAAAxng");
        this.shape.setTransform(125, -166.2);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 1).to({state: []}, 1).wait(1));

        // recuadro
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#000000").ss(1, 1, 1).p("ATX3zMAAAAvnMgmtAAAMAAAgvng");
        this.shape_1.setTransform(123.9, -167.4);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}]}).wait(3));

        // IMG
        this.instance = new lib._101046284_OPT();
        this.instance.setTransform(14, -330.8, 0.801, 0.801);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}]}).wait(3));

        // Btn
        this.shape_2 = new cjs.Text(txt['txt_boto_02'], "bold 16px Verdana");
        this.shape_2.textAlign = "center";
        this.shape_2.lineHeight = 18;
        this.shape_2.lineWidth = 204;
        //this.shape_2.graphics.f("#FF00FF").s("#000000").ss(1,2,1).rr(-125,-15,250,30,6);
        this.shape_2.setTransform(125, 15);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2}]}).wait(3));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, -330.8, 250, 360.9);


    (lib.mc_boto_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 5
        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.498)").s().p("A3wY0MAAAgxnMAvhAAAMAAAAxng");
        this.shape.setTransform(125, -166.2);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 1).to({state: []}, 1).wait(1));

        // recuadro
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#000000").ss(1, 1, 1).p("ATX3zMAAAAvnMgmtAAAMAAAgvng");
        this.shape_1.setTransform(123.9, -167.4);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}]}).wait(3));

        // IMG
        this.instance = new lib._97750665_OPT();
        this.instance.setTransform(5.4, -323.3, 0.643, 0.643);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}]}).wait(3));

        // Btn
        this.shape_2 = new cjs.Text(txt['txt_boto_01'], "bold 16px Verdana");
        this.shape_2.textAlign = "center";
        this.shape_2.lineHeight = 18;
        this.shape_2.lineWidth = 204;
        this.shape_2.setTransform(125, 15);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2}]}).wait(3));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, -323.3, 250, 353.4);

    (lib._101046284_OPT = function () {
        this.initialize(img._101046284_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 268, 400);


    (lib._92211946_OPT = function () {
        this.initialize(img._92211946_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 267, 400);


    (lib._97750665_OPT = function () {
        this.initialize(img._97750665_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 370, 480);


    (lib.bombilla106470875_OPT = function () {
        this.initialize(img.bombilla106470875_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 600, 400);


    (lib.Dinamo_shutter_43131142_OPT = function () {
        this.initialize(img.Dinamo_shutter_43131142_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 602, 400);


    (lib.FQ_09_08_043 = function () {
        this.initialize(img.FQ_09_08_043);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 788, 375);


    (lib.FQ_10_08_03_03 = function () {
        this.initialize(img.FQ_10_08_03_03);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 912, 608);


    (lib.interruptor81270151_OPT = function () {
        this.initialize(img.interruptor81270151_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 267, 400);


    (lib.Motor118187653_OPT = function () {
        this.initialize(img.Motor118187653_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 598, 400);



    (lib.timbre100120078_OPT = function () {
        this.initialize(img.timbre100120078_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 263, 400);


    (lib.Tostadora100748652_OPT = function () {
        this.initialize(img.Tostadora100748652_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 533, 400);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}