/**
 * Created by lafactoria on 20/11/14.
 */
function Particle (item,parentID,id) {

    this.id = id;
    this.parentID = parentID;
    this.item = item;
    this.dirX = null;
    this.dirY = null;
    this.weight = 10;
    this.isParticleRunning = false;
    this.getX = function () {
        return parseInt($(this.item).css("left"));
    };
    this.getY = function () {
        return parseInt($(this.item).css("top"));
    };
    this.startMoving = function() {

        if (this.parentID == 4)
            console.log("PARTICLE START MOVING:"+this.id);

        if (this.isParticleRunning)
            return;

        this.isParticleRunning = true;
        this.dirX = Math.floor((Math.random()*100)) > 50 ? -1 : 1;
        this.dirY = Math.floor((Math.random()*100)) > 50 ? -1 : 1;
        animateMe(this);
    };
}
