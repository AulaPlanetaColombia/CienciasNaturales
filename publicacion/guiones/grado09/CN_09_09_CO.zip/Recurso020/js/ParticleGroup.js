/**
 * Created by lafactoria on 20/11/14.
 */
function ParticleGroup (id) {

    this.id = id;
    this.particles = new Array();
    this.complete = false;
    this.countRunning = 0;
    this.isRunning = true;
    var self = this;


    this.initialize = function init() {

        var left = Math.floor((Math.random() * 280) + 0);

        var div = document.createElement('div');
        $(div).append('<img src="images/green.png" style="left: '+(36+left)+'px; top: 10px">' +
        '<img src="images/red.png" style="left: '+(28+left)+'px; top: 11px;">' +
        '<img src="images/green.png" style="left: '+(24+left)+'px; top: 0px;">' +
        '<img src="images/red.png" style="left: '+(47+left)+'px; top: 10px">' +
        '<img src="images/red.png" style="left: '+(36+left)+'px; top: 2px;">');

        $(div).children().addClass("group");
        var particles = $(div).children();
        $(particles).appendTo($("#molecules"));
        for (var i=0; i<particles.length; i++) {
            self.particles.push(new Particle(particles[i],self.id,i));
        }

        self.animateDown();
    };
    this.animateDown = function animateDown () {
        for (var i=0; i<this.particles.length; i++) {
            var height = $("#molecules").height()-25;

            $(self.particles[i].item).animate({top: "+="+height},2000,function() {
                self.complete++;

                if (self.complete == self.particles.length) {
                    self.isRunning = false;
                    self.animateAll();
                }
            });
        }
    };
    this.animateAll = function animateParticles() {

        console.log("ANIMATE ALL");

        self.animateParticles(self.countRunning);
    };
    this.updateState = function (salt) {

        console.log("UPDATE STATE");

        self.countRunning = Math.floor(salt/10);

        if (self.id == 4) {
            console.log("RUNNING: " + self.isRunning ? "true" : "false");
        }

        if (!self.isRunning) {
            self.animateAll();
        }
    };
    this.animateParticles = function(count) {

        console.log("COUNT: " + count);

        for (var i=0; i<count; i++) {
            self.particles[i].startMoving();
        }
    };
}
