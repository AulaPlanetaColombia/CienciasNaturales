window.onresize = resize;
var scale 	= 1;

var solublidadValues = [];

solublidadValues[0] 	=35.6;
solublidadValues[1]		=35.7;
solublidadValues[2] 	=36;
solublidadValues[3]		=36.1;
solublidadValues[4]		=36.4;
solublidadValues[5]		=36.7;
solublidadValues[6]		=37;
solublidadValues[7]		=37.5;
solublidadValues[8]		=38;
solublidadValues[9]		=38.5;
solublidadValues[10]	=39;


/* BEGIN CONST */
var INITIAL_LITERS_HEIGHT 	= 45;
var INITIAL_LITERS 			= 0.5;

var INITIAL_TEMP 			= 50;
var INITIAL_TEMP_HEIGHT 	= 116;
var INITIAL_TEMP_FAKE_BOTTOM= 145;
/* END CONST */

var tempIsEnabled = true;

var incrementalSize = 0;

var currentLiters = INITIAL_LITERS;
var currentTemp = 50;
var lastTempValue;
var solublidad = 36.7;

var canvas;

var waterInterval;


$(document).ready(function(){
	addTouchListener();
	resize();
	initialize();
});

/*
		INITIALIZE
	 -------------------
*/
function initialize() {
	incrementalSize = 0;
	ParticlesManager.maxHeight = INITIAL_LITERS_HEIGHT;

	$("#water").height(INITIAL_LITERS_HEIGHT);
	currentLiters = INITIAL_LITERS;

    $("#working_temp").height(INITIAL_TEMP_HEIGHT);
    $("#fake_working_temp").css("bottom",INITIAL_TEMP_FAKE_BOTTOM+"px");
    $("#fake_working_temp").css("top","auto");

    currentTemp = INITIAL_TEMP;

	updateValues();
}

/*
 		TOUCH LISTENERS
 	------------------------
 */
function addTouchListener() {
	addTapListeners();
	addSaltListener();
	addTempListener();
}

function addTapListeners() {
	$('#tap img.action').on("touchstart mousedown",function(ev){
		startWater();
		ev.preventDefault();
	});

	$(document).on("touchend mouseup",function(ev){
		stopWater();
		ev.preventDefault();
	});
}

var lastHeight;
var lastPos;

function addTempListener() {
	$("#fake_working_temp").draggable({
		scroll: false,
		axis: "y",
		start: function(evt,ui){
			var pos = ui.position.top = Math.round(ui.position.top / scale);
			lastTempValue = pos;
			lastHeight = $("#working_temp").height();
		},
		drag: function(evt,ui){
			// zoom fix
			var height;
			var pos = Math.round(ui.position.top / scale);

			ui.position.left = Math.round(ui.position.left / scale);

			if (pos > lastPos && !tempIsEnabled) {
				ui.position.top = lastPos;
				height = lastHeight;
			}else {
				pos = ui.position.top = Math.round(ui.position.top / scale);
				height = lastTempValue - pos + lastHeight;

				if (height < 0) {
					height = 0;
					ui.position.top = lastPos;
				} else if (height > 232) {
					height = 232;
					ui.position.top = lastPos;
				} else {
					lastPos = pos;
				}
				$("#working_temp").height(height);
			}

			setTemperature();

		}
	});
	$("#fake_working_temp").css('-ms-touch-action', 'none');
}

var saltAdded = false;

function addSaltListener() {
	$("#salt").draggable({
		scroll: false,
		axis: "y",
		start: function(evt,ui){

		},
		drag: function(evt,ui){

			var pos = ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);

			if (pos < 50) {
				pos = 50;
			}else if (pos > 100) {
				pos = 100;

				if (!saltAdded) {

                    $("#pie").html(getText("salt_added"));
                    tempIsEnabled = false;

					saltAdded = true;
					ParticlesManager.addGroup();

					updateValues();
				}
			}else if (pos < 100) {
				saltAdded = false;
			}

			ui.position.top = pos;
		},
		stop : function(evt,ui) {
			var pos = ui.position.top-50;
			$(this).animate({top: "-="+pos},100);
		}
	});
	
	$("#salt").css('-ms-touch-action', 'none');
}

/*
			UPDATE
	----------------------
 */
function updateValues() {

    ParticlesManager.shouldStop = false;

	var maxSalt = getMaxSalt();
	var sal_disuelta = 0,sal_sin_disolver = 0;
	var totalSalt = ParticlesManager.getSalt();

	if (ParticlesManager.getSalt() > 0) {
		if (totalSalt > maxSalt) {
			sal_disuelta = maxSalt;
			sal_sin_disolver = ParticlesManager.getSalt() - maxSalt;
		}else{
			sal_disuelta = totalSalt;
		}
	}

	$("#solubilidad input").val(solublidad);
	$("#sal_disuelta input").val((sal_disuelta.toFixed(2)+"").replace(".",","));
	$("#sal_sin_disolver input").val((sal_sin_disolver.toFixed(2)+"").replace(".",","));
	$("#volumen input").val(((currentLiters)+"").replace(".",","));

	ParticlesManager.maxHeight = $("#water").height();

	ParticlesManager.update();
}

function getMaxSalt() {
	//solublidad = (currentTemp/29 + 35.6).toFixed(1);

	var value = Math.floor(currentTemp/10);
	solublidad = solublidadValues[value];
	return solublidad*currentLiters*10;
}

function startWater () {
	$("#working_water").show();
	waterInterval = setInterval(incrementWaterSize,50);
}

function incrementWaterSize() {

	if (incrementalSize < 130) {
		incrementalSize++;
		$("#water").height(INITIAL_LITERS_HEIGHT+incrementalSize);
	}

	currentLiters = incrementalSize*1.5/130;
	currentLiters = INITIAL_LITERS + currentLiters;
	currentLiters = currentLiters.toFixed(2);


	updateValues();
}

function stopWater() {
	$("#working_water").hide();
	clearInterval(waterInterval);
}

function setTemperature() {
	var temperatureHeight = parseInt($("#working_temp").height());
	currentTemp = temperatureHeight*100/232;

	updateValues();
}



/*
 		GLOBAL FUNCTIONS
 	-----------------------
 */
function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		//apply margin left
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
		console.log("aki");
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
		//apply margin top
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}

function reiniciar() {

	tempIsEnabled = true;

	incrementalSize = 0;

	currentLiters = INITIAL_LITERS;
	currentTemp = 50;
	lastTempValue;
	solublidad = 36.7;

    ParticlesManager.reset();
    $("#molecules").html("");
	//addTempListener();
	initialize();

}
