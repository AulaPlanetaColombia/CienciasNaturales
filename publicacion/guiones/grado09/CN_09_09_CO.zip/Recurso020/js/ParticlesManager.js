
var ParticlesManager = {
	particleGroups : new Array(),
	maxHeight : 45,
    shouldStop : false,
	addGroup : function () {
		var group = new ParticleGroup(this.particleGroups.length+1);
		group.initialize();

		this.particleGroups.push(group);
	},
	update : function () {

        var maxSalt = getMaxSalt();

		this.particleGroups.forEach(function(group) {

            if (maxSalt > 50) {
                maxSalt -= 50;
                group.updateState(50);
            }else {
                group.updateState(maxSalt);
                maxSalt = 0;
            }
		});
	},
	getSalt : function () {
		return this.particleGroups.length*50;
	},
	reset : function () {
        this.shouldStop = true;
        this.particleGroups.forEach(function(group) {

        });

		this.particleGroups = new Array();
	}
};

var animateMe = function(element) {

    if (ParticlesManager.shouldStop) {
        return;
    }

	var x = element.getX();
	var y = element.getY();
	var mov = 7;
	var newX = x;
	var newY = y;

	if(element.dirX==1){
		if(x<330){
			newX = mov;
		}else{
			element.dirX = -1;
			newX = -(mov*2);
		}
	}else{
		if(x>0){
			newX = -(mov);
		}else{
			element.dirX = 1;
			newX = mov*2;
		}
	}

	if(element.dirY==1){
		if(y<$("#molecules").height()-20){
			newY = mov;
		}else{
			element.dirY = -1;
			newY = -(mov*2);
		}
	}else{
		if(y>$("#molecules").height()-ParticlesManager.maxHeight+5){
			newY = -(mov);
		}else{
			element.dirY = 1;
			newY = mov*2;
		}
	}

	$(element.item).animate({
		left: 	x+newX+"px",
		top: 	y+newY+"px"
	},{
		duration: 8000/ParticlesManager.maxHeight,
		complete: function(){
            if (!ParticlesManager.shouldStop)
			    animateMe(element);
		}
	});

}


