Motor = new function()
{
	this.fons = "";
	this.respostes = new Array();
	this.preguntes = new Array();
	
	this.contenedor = "";

	this.INITIAL_Y = 118;
	this.PREG_Y_PADDING = 54;
	this.PREG_X_PADDING = 10;
	
	//inici
	this.PREG_INICI_X_PADDING = 315 ;
	//final
	this.PREG_FINAL_X_PADDING = 535 ;
	
	this.RESP_HEIGHT = 25;
	this.RESP_WIDTH = 250; 
	this.RESP_INNER_HEIGHT = 23;
	this.RESP_INNER_WIDTH = 248; 
	
	//line
	this.LINE_X = 510;
	this.LINE_Y_MIN = 20;
	this.LINE_Y_MAX = 535;
	this.LINE_SIZE = 3;
	
	this.itemX= 0;
	this.itemY= 0;
	
	this.separator = ""; 
	
	this.datosXML = "";
	this.solucion = false;
	this.IMG = "data/imagenes/";
	this.imagen= "";
	
	this.ponerContenedor = function(contenedorMotor) {
	  //alert("Estoy caminando!");
	};
	
	this.cargarDatos = function()
	{
		$.get(pppPreloader.from("data", "data/datos.xml" + "?time=" + new Date().getTime()), function (xml) {

			Motor.datosXML = new datosMotor();
			Motor.datosXML.cantidad = $(xml).find('textoatexto').attr('cantidad');
			Motor.datosXML.imagen = $(xml).find('imagen').text();
			Motor.datosXML.ampliacion = $(xml).find('ampliacion').text();
			
			var counter = 0;
			$(xml).find('cuestion').each(function(index) {
				//debugger;
				if( counter < Motor.datosXML.cantidad )
				{
					var cuestiona = new cuestion();
					
					cuestiona.correccionSinMayusculas = $(this).attr("correccionSinMayusculas");
					cuestiona.correccionSinPuntuacion = $(this).attr("correccionSinPuntuacion");
					cuestiona.correccionSinPuntuacionFinal = $(this).attr("correccionSinPuntuacionFinal");
					cuestiona.id=index;
					
					cuestiona.pregunta.text = $(this).find('pregunta').text();
					cuestiona.pregunta.id=index;
	
					cuestiona.respuesta.text = $(this).find('respuesta').text();
					cuestiona.respuesta.id = index;
					
				  	Motor.datosXML.cuestiones.push(cuestiona);
				  	Motor.datosXML.cuestionesbkup.push(cuestiona);
			  	}
			  	counter++;

			});
			
			//console.log(Motor.datosXML);
	       	Motor.inicializarEstructura();
	       	Contenedor.crearPaginacio();

		});
	}
	this.inicializarEstructura = function(estado) {
		
	 	this.init();
	 	if( this.solucion )
	 	{
	 		this.solucionar();
	 		this.desactivar();	
	 	}

	};
	this.reinicializarEstructuraMotor = function()
	{
		Main.stage.removeChild(Motor.contenedor);
		Motor.deleteInputs();
		Motor.cargarDatos();
	}
	this.estaCompletado = function(){
	 	for (key2 in Motor.respostes) 
   		{
			if( $( Motor.respostes[key2].inputDOM.htmlElement).val() == "")
			{
				return false;
			}
		}
		return true;
	};
	
	this.getEstado = function(){
		var estado = new Array();
		for( var i = 0 ; i < Motor.respostes.length ; i++ ){
			for ( key1 in Motor.respostes ) {
				if( i == Motor.respostes[key1].id ){
					estado.push( $( Motor.respostes[key1].inputDOM.htmlElement ).val() );
				}
			}
		}
		return estado.join("|");
	}
	
	this.revisar = function(){
		if(this.estado != "")
		{
			if( this.estado.indexOf("[") >= 0 )
			{
				var datos = this.estado.substring(1, this.estado.length-1).split("][");
				Contenedor.timeRevision = datos[0];
				var estado = datos[1].split("|");
			}else{
				var estado = this.estado.split("|");
			}
			
			for(var key in estado)
			{
				if(estado[key].trim() != ""){
					for(key1 in Motor.respostes)
					{
						if( key == Motor.respostes[key1].id )
						{
					   		 $( Motor.respostes[key1].inputDOM.htmlElement ).val( estado[key] );
						}
					}
				}
			}
		}
	}
	
	this.validar = function() {
		var total = 0;
	  	for(key1 in Motor.preguntes){
	   		for (key2 in Motor.respostes) 
	   		{
	   			if( Motor.preguntes[key1].id == Motor.respostes[key2].id)
	   			{
	   				//console.log(Motor.preguntas[key1].respuestas);
	   				var respuestaCorrecta =   Motor.respostes[key2].textCorrecte;
	   				var respuestaReal = $( Motor.respostes[key2].inputDOM.htmlElement).val();
	   				//console.log( respuestaCorrecta + " - " + respuestaReal );

	   				if( Motor.compareResults( respuestaCorrecta, respuestaReal ))
	   				{
	   					total++;
	   					Motor.respostes[key2].correct();
	   				}
	   				else if(respuestaReal != ""){
	   					Motor.respostes[key2].error();
	   				}
	   			}
			}
			
		}
		return total.toString() +  "/" + Motor.preguntes.length.toString();
	};
	this.compareResults = function( textoCorrecto, textoIntroducido ){
		
		var modo = "";
				
		modo |= CorrectorTexto.MODO_CI;
		modo |= CorrectorTexto.MODO_NOPUNCT
		modo |= CorrectorTexto.MODO_NOENDPUNCT;
		
		return CorrectorTexto.esValido(textoIntroducido, textoCorrecto, modo);

	};
	this.hideDomObjects = function(){
		for( key in this.respostes)
		{
			this.respostes[key].inputDOM.visible = false;
		}
	}
	this.showDomObjects = function(){
		for( key in this.respostes)
		{
			this.respostes[key].inputDOM.visible = true;
		}
	}
	this.obtenerEstado = function(){
	  //alert("Hola, Soy" + this.primerNombre);
	};
	this.reiniciar = function() {
	  //alert("Estoy caminando!");
	};
	this.activar = function(){
		for( key in this.respostes)
		{
			this.respostes[key].activar();
		}
	}
	this.desactivar = function() {
		for( key in this.respostes)
		{
			this.respostes[key].desactivar();
		}
	};
	this.numPaginas = function(){
		return 1;
	};
	this.ponerPagina = function(pag) {

	};
	this.obtenerPaginaActual = function(pag){

	};
	this.verSolucion = function(conEfecto){
	  
	  	this.recolocar();
	  	this.solucionar();
		this.desactivar();	
		
	};
	this.recolocar = function(){

	}
	this.solucionar = function(){
		var total = 0;
		this.solucion = false;
		
	  	for(key1 in Motor.respostes){
			Motor.respostes[key1].removeError();
			if(!Motor.respostes[key1].correcte)
			{
				Motor.respostes[key1].setCorreccio();
			}
		}
	}
	this.obtenerTipoEjercicio = function() {

	};
	this.obtenerVersion = function(){

	};
	
    this.init = function()
    {
		this.contenedor = new createjs.Container();

	    this.drawPreguntesRespostes();
	    this.drawImatge();
	    
	    Main.stage.addChild( this.contenedor);
	    
    }

    this.drawPreguntesRespostes = function()
    {   
    	Motor.preguntes = new Array();
    	Motor.respostes = new Array();
    	var questions = Motor.datosXML.cuestiones;
    	//dibuixem caixa i preguntes
    	for(i=0; i < Motor.datosXML.cantidad; i++)
    	{
    		// creem random o no.
    		var index = 0;
			if(Contenedor.datosXML.sinaleatoriedad == 0 && Scorm.modo != Scorm.MODO_REVISAR && Scorm.modo != Scorm.MODO_REVISARALUMNO )
			{
				index = Math.floor( Math.random()*questions.length);
			} 
			
			var quest = questions[index];
			questions.splice(index,1);
			
			var centrado =0;
			if( Motor.datosXML.imagen == "" ){
				centrado =150;
			}
			
			//PREGUNTES
	       	var pregunta = new Pregunta(quest.pregunta.text, this.RESP_WIDTH, this.RESP_HEIGHT);
	        pregunta.contenedor.x = this.PREG_X_PADDING +centrado;
	        pregunta.contenedor.y =  this.INITIAL_Y + this.PREG_Y_PADDING * i + 5 + i * ( (this.PREG_Y_PADDING  ) * ( 8 - Motor.datosXML.cantidad ) ) / (Motor.datosXML.cantidad-1);
			pregunta.id = quest.id;
			
	        this.contenedor.addChild( pregunta.contenedor );
 			Motor.preguntes.push(pregunta);
 			
	        //RESPOSTES
	        var resposta = new TextInputBox(quest.respuesta,  quest.id)
	        resposta.contenedor.x = this.PREG_X_PADDING + this.PREG_INICI_X_PADDING +centrado;
	        resposta.contenedor.y = this.INITIAL_Y + this.PREG_Y_PADDING * i + 5 + i * ( (this.PREG_Y_PADDING ) * ( 8 - Motor.datosXML.cantidad ) ) / (Motor.datosXML.cantidad-1);

	        this.contenedor.addChild( resposta.contenedor );
	        Motor.respostes.push(resposta);
    	}
    	
    }


    this.drawImatge = function()
    {
    	if( Motor.datosXML.imagen != "" ){
	    	this.imagen = new Imagen();
	    	this.imagen.contenedor.x = 610;
	    	this.contenedor.addChild(this.imagen.contenedor);
    	}
    }
    this.deleteInputs = function()
	{
		$( "input" ).each(function() {
		  $( this ).remove();
		});
	}

}