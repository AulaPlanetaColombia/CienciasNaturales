window.onresize = resize;
var scale 	= 1;
var mgLeft	= 0;
var mgTop	= 0;
var iniciat;

var flechaM;

$(document).ready(function(){
	resize();
	initialize();
});

function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}

function restart(){
	$("#pipe").addClass("pipe1");
	$("#pipe").removeClass("pipe2");
	$("#pipe").removeClass("pipe3");
	
	$("#lleno1").css("display","block");
	$("#vWater1").css("display","none");
	$("#vWater2").css("display","none");
	$("#cWaterHide").css("display","block");
	$("#hWater").css("display","none");
	$("#lleno2").css("display","none");
	$("#vWater3").css("display","none");
	
	$("#turbina").velocity({
		rotateZ: "0deg"
	},0);
	
	checkCross(1);
	
	$("#omega").velocity({
		scale: "1"
	},100);
}

function initialize(){	
	$("#luz").velocity({
		scale: "1.2"
	},0);
	nCheck = 1;
	nPipe  = 1;
	$("#resistencia").fadeTo(0, 0.3);
	iniciat = false;

	flechaM = -1;
	setInterval(function(){
		moveFlecha();
	},200);	
}

function moveFlecha(){	
	if(flechaM==(-1)){		
		$("#btValvula").velocity({
			duration: 	200,
			translateX:"-6px"
		});		
	}else{		
		$("#btValvula").velocity({
			duration: 	200,
			translateX:"0px"
		});
	}
	
	flechaM=flechaM*(-1);
}

var nPipe = 1;
var canRotate = true;
function rotateRueda(){
	if(canRotate){
		canRotate = false;
		$("#rueda").velocity({
			rotateZ: "360deg"
		},600);
		
		if(nPipe == 1){
			$("#pipe").removeClass("pipe1");
			$("#pipe").addClass("pipe2");
			nPipe++;
			$("#resistencia").fadeTo(100, 0.6);
			$("#omega").velocity({
				scale: "1.2"
			},100);
		}else if(nPipe == 2){
			$("#pipe").removeClass("pipe2");
			$("#pipe").addClass("pipe3");
			nPipe++;
			$("#resistencia").fadeTo(100, 1);
			$("#omega").velocity({
				scale: "1.4"
			},100);
		}else if(nPipe == 3){	
			$("#pipe").removeClass("pipe3");
			$("#pipe").addClass("pipe1");
			nPipe=1;
			$("#resistencia").fadeTo(100, 0.3);
			$("#omega").velocity({
				scale: "1"
			},100);
		}
		setTimeout(function(){
			canRotate = true;
			$("#rueda").velocity({
				rotateZ: "0deg"
			},0);
		},600);
	}
}

var totalTime = 10000;
var running = false;
function iniciar(){
	//nPipe,nCheck
	var speedLleno = 4000;
	var speedV1 = 300;
	var speedV2 = 100;
	var speedCHide = 400;
	var speedH1 = 100;
	var speedTurbina = 4000;
	if(!iniciat){	
		iniciat = true;
		running = true;
		if(nPipe == 1){
			if(nCheck == 1){
				$("#luz").velocity({
					scale: "1.2"
				},0);
				speedLleno = 4000;
			}else if(nCheck == 2){
				$("#luz").velocity({
					scale: "1.3"
				},0);
				speedLleno = 2700;
			}else if(nCheck == 3){
				$("#luz").velocity({
					scale: "1.4"
				},0);
				speedLleno = 1500;
			}
		}else if(nPipe == 2){
			if(nCheck == 1){
				$("#luz").velocity({
					scale: "1.1"
				},0);
				speedLleno = 7000;
			}else if(nCheck == 2){
				$("#luz").velocity({
					scale: "1.2"
				},0);
				speedLleno = 4200;
			}else if(nCheck == 3){
				$("#luz").velocity({
					scale: "1.3"
				},0);
				speedLleno = 2700;
			}
		}else if(nPipe == 3){
			if(nCheck == 1){
				$("#luz").velocity({
					scale: "1"
				},0);
				speedLleno = 10000;
			}else if(nCheck == 2){
				$("#luz").velocity({
					scale: "1.1"
				},0);
				speedLleno = 7000;
			}else if(nCheck == 3){
				$("#luz").velocity({
					scale: "1.2"
				},0);
				speedLleno = 4000;
			}
		}
	
		speedTurbina = speedLleno+1200;
		
		console.log("pipe: "+nPipe);
		console.log("check: "+nCheck);
		
		$("#cierre").velocity({
			rotateZ: "35deg",
			translateX: "-5px",
			translateY: "5px"
		},300, function(){
			$("#luz").fadeIn(100);
			$("#electron").fadeIn(100);
			$("#electron").addClass("elecAnim");
			$("#lleno1").hide("slide",{direction: 'down',duration:speedLleno,easing:"linear"}, function(){
				$("#vWater1").hide("slide",{direction: 'down',duration:speedV1,easing:"linear"},function(){
					$("#cWaterHide").css("height","0px");
					$("#cWaterHide").css("display","block");
					$("#cWaterHide").velocity({ height: "62px"},{duration: speedCHide,
						complete: function(){
							$("#vWater2").hide("slide",{direction: 'down',duration:speedV2,easing:"linear"},function(){
								$("#hWater").hide("slide",{direction: 'right', duration: speedH1 });
							});
						}
					});
				});
			});
			$("#vWater1").velocity("slideDown", { duration: speedV1, easing: "linear", 
				complete: function(){					
					$("#turbina").velocity({
						rotateZ: "2160deg"
					},speedTurbina);
					$("#cWaterHide").hide("slide",{direction: 'down',duration:speedCHide,easing:"linear"},function(){
						$("#vWater2").velocity("slideDown", { duration: speedV2, easing: "linear", 
							complete: function(){
								$("#hWater").show("slide",{ duration: speedH1, direction: 'left' },function(){
									$("#vWater3").show("slide",{direction: 'up',duration:50,easing:"linear"});
									$("#lleno2").show("slide",{direction: 'down',duration:speedLleno,easing:"linear"},function(){
										$("#luz").fadeOut(100);
										$("#electron").fadeOut(100, function(){
											$("#electron").removeClass("elecAnim");
											running = false;
										});	
										$("#cierre").velocity({
											rotateZ: "0deg",
											translateX: "0px",
											translateY: "0px"
										},300);
									});									
								});
							}
						});
					});					
				}
			});
		});			
	}
}

var nCheck = 1;

function checkCross(id){

	if (running)
		return;

	switch(id){
		case 1:
			nCheck = 1;
			$("#cross1").css("display","block");
			$("#cross2").css("display","none");
			$("#cross3").css("display","none");
			
			$("#bat2").css("display","none");
			$("#bat3").css("display","none");
			
			$("#d1").attr("src", "images/deposito1_3.png");
			$("#d1").css("top", "130px");
			$("#lleno1").css("top", "132px");
			
			$("#vWater1").css("top", "226px");
			$("#vWater1").css("height", "156px");
			break;		
		case 2:
			nCheck = 2;
			$("#cross2").css("display","block");
			$("#cross1").css("display","none");
			$("#cross3").css("display","none");
			
			$("#bat2").css("display","block");
			$("#bat3").css("display","none");
			
			$("#d1").attr("src", "images/deposito1_2.png");
			$("#d1").css("top", "110px");
			$("#lleno1").css("top", "112px");
			
			$("#vWater1").css("top", "206px");
			$("#vWater1").css("height", "176px");			
			break;		
		case 3:
			nCheck = 3;
			$("#cross3").css("display","block");
			$("#cross1").css("display","none");
			$("#cross2").css("display","none");
			
			$("#bat2").css("display","block");
			$("#bat3").css("display","block");
			
			$("#d1").attr("src", "images/deposito1.png");
			$("#d1").css("top", "90px");
			$("#lleno1").css("top", "92px");
			
			$("#vWater1").css("top", "186px");
			$("#vWater1").css("height", "196px");
			break;
	}	
}

function reiniciar(){
	if(!running){
		restart();
		initialize();
	}
}