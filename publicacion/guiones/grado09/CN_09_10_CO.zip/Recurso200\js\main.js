$(document).ready(function(){
	resize();
	initialize();
});

window.onresize = resize;
var scale 	= 1;
var mgLeft	= 0;
var mgTop	= 0;

var t1 = 800;
var t2 = 800;
var m1 = 50;
var m2 = 50;

var minH = 0;
var maxH = 0;

var dirX = new Array(40);
var dirY = new Array(40);
var positionsX = new Array(40);
var positionsY = new Array(40);
var posXInicial;
var posYInicial;

var particles;


function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}
function initialize(){
	$("#flecha1").css("display","block");
	$("#flecha2").css("display","none");

	$("#flecha3").css("display","block");
	$("#flecha4").css("display","none");
	
	
	
	particles = document.getElementsByClassName("particula");
	for(var i=0;i<dirX.length;i++){
		dirX[i]=1;
		dirY[i]=1;
	}

	$("#leftBig").css({
		display:	"none"
	});
	$("#rightBig").css({
		display:	"none"
	});


	positionsX = [5,45,165,125,205,35,115,185,35,135,195,195,65,95,100,210,125,155,55,15,45,125,225,35,130,175,145,225,195,25,135,105,75,205,220,30,175,185,75,45];
	positionsY = [45,5,95,275,65,255,205,235,125,20,5,275,205,255,125,105,145,195,85,20,25,45,15,85,155,185,235,255,45,195,20,80,275,155,95,155,115,275,35,245 ];

	posXInicial = positionsX;
	posYInicial = positionsY;
	
	for(var	i=0;i<40;i++){
		var particula = $("#"+particles[i].id);
		particula.css({
			left: 	posXInicial[i]+"px",
			top: 	posYInicial[i]+"px"
		});
	}

	$("#riseLeft").css("height","260px");
	$("#riseRight").css("height","260px");
	$("#k1").html("800K");
	$("#k2").html("800K");
	
	
	if(scale>0){
		minH = 33;
		maxH = 293;
	}else{
		minH = 33/scale;
		maxH = 293/scale;
	}

	$("#termLeft").click(function(e){
		var parentOffset = $(this).offset();
		var relY = (305)-(e.pageY - parentOffset.top)/scale;

		if(relY<minH){
			$("#riseLeft").css("height","33px");
			t1 = 100;
			$("#k1").html(t1+"K");
		}else if(relY>maxH){
			$("#riseLeft").css("height","293px");
			t1 = 900;
			$("#k1").html(t1+"K");
		}else if(relY >=(minH) && relY<=maxH){
			var nHeight = 0;
			nHeight = (relY);
			$("#riseLeft").css("height", nHeight+"px");
			t1 = parseInt(((800/(maxH-minH))*nHeight));
			$("#k1").html(t1+"K");
		}
	});
	$("#termRight").click(function(e){
		var parentOffset = $(this).offset();
		var relY = (305)-(e.pageY - parentOffset.top)/scale;

		if(relY<minH	){
			$("#riseRight").css("height","33px");
			t2 = 100;
			$("#k2").html(t2+"K");
		}else if(relY>maxH){
			$("#riseRight").css("height","293px");
			t2 = 900;
			$("#k2").html(t2+"K");
		}else if(relY >=(minH) && relY<=maxH){
			var nHeight = 0;
			nHeight = (relY);
			$("#riseRight").css("height", nHeight+"px");
			t2 = parseInt((800/(maxH-minH))*nHeight);
			$("#k2").html(t2+"K");
		}
	});
}

function toggleLeft(n){
	if(!iniciat){
		if(n==0){
			$("#leftBig").css("display","none");
			$("#flecha1").css("display","block");
			$("#flecha2").css("display","none");
			m1 = 50;
		}else{
			$("#leftBig").css("display","block");
			$("#flecha2").css("display","block");
			$("#flecha1").css("display","none");
			m1 = 100;
		}

		for(var i=0;i<dirX.length;i++){
			dirX[i]=1;
			dirY[i]=1;
		}
	}
}

function toggleRight(n){
	if(!iniciat){
		if(n==0){
			$("#rightBig").css("display","none");
			$("#flecha3").css("display","block");
			$("#flecha4").css("display","none");
			m2 = 50;
		}else{
			$("#rightBig").css("display","block");
			$("#flecha4").css("display","block");
			$("#flecha3").css("display","none");
			m1 = 100;
		}
		for(var i=0;i<dirX.length;i++){
			dirX[i]=1;
			dirY[i]=1;
		}
	}
}

function tempo(){
	for(var	i=0;i<20;i++){
		var particula = $("#"+particles[i].id);

		animateMe(particula,((1000-t1)/10),i);
	}
	for(var	i=20;i<40;i++){
		var particula = $("#"+particles[i].id);

		animateMe(particula,((1000-t2)/10),i);
	}
}

var animateMe = function(targetElement, speed,i){
	if(iniciat){
	
		var mov = 7;
		var changeMov = 14;
		var posY=positionsY[i];
		var posX=positionsX[i];
		var tY = 0;
		var tX = 0;

		if(dirX[i]==1){
			if(posX<245){
				tX = mov;
			}else{
				dirX[i] = -1;
				tX = -(changeMov);
			}
		}else{
			if(posX>0){
				tX = -(mov);
			}else{
				dirX[i] = 1;
				tX = changeMov;
			}
		}

		if(dirY[i]==1){
			if(posY<305){
				tY = mov;
			}else{
				dirY[i] = -1;
				tY = -(changeMov);
			}
		}else{
			if(posY>0){
				tY = -(mov);
			}else{
				dirY[i] = 1;
				tY = changeMov;
			}
		}

		positionsX[i] += tX;
		positionsY[i] += tY;

		targetElement.animate({
			left: 	positionsX[i]+"px",
			top: 	positionsY[i]+"px"
		},{
			duration: speed,
			complete: function(){
				if(i>=0 && i<= 19){
					speed = (1000-t1)/10;
				}else{
					speed = (1000-t2)/10;
				}
				animateMe(targetElement, speed,i);
			}
		});
	}
}

var iniciat = false;

function iniciar(){
	if(!iniciat){
		$("#btPlay").attr("src","images/pause.png");
		iniciat = true;
		tempo();
		var tFinal = ((m1*t1)+(m2*t2))/(m1+m2);
		var nHeight = parseInt(tFinal/(800/(maxH-minH)));
		

		$("#riseLeft").velocity({
									height : nHeight+"px"
								},{
									progress: function(elements, percentComplete, timeRemaining, timeStart) {
										var currHeight = $("#"+elements[0].id).height();
										var currT = (800/(maxH-minH))*currHeight;
										$("#k1").html(parseInt(currT)+"K");
										t1 = currT;
										if(!iniciat){
											$(this).velocity("stop");
										}
									},
									complete: function(elements){
										$("#k1").html(parseInt(tFinal)+"K");
									},
									step:0.1,
									duration: 15000,
									easing: "easeOutCubic"
								});
		$("#riseRight").velocity({
									height : nHeight+"px"
								},{
									progress: function(elements, percentComplete, timeRemaining, timeStart) {
										var currHeight = $("#"+elements[0].id).height();
										var currT = (800/(maxH-minH))*currHeight;
										$("#k2").html(parseInt(currT)+"K");
										t2 = currT;
										if(!iniciat){
											$(this).velocity("stop");
										}
									},
									complete: function(elements){
										$("#k2").html(parseInt(tFinal)+"K");
									},
									duration: 15000,
									easing: "easeOutCubic"
								});
	}else{
		$("#btPlay").attr("src","images/play.png");
		iniciat = false;
		
		$("#riseLeft").velocity("stop");
		$("#riseRight").velocity("stop");
	}
}

function reiniciar(){
	$("#btPlay").attr("src","images/play.png");
	iniciat = false;
	setTimeout(function(){
		t1 = 800;
		t2 = 800;
		m1 = 50;
		m2 = 50;

		minH = 0;
		maxH = 0;
		initialize();
	},200);
}