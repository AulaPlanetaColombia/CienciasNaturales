(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
       basicos(this, 0, 0, 0, 0, 0);
     
	// Capa 1
	this.btn_pulmon = new lib.btn_pulmon();
	this.btn_pulmon.setTransform(211.5,366,1,1,0,0,0,65,15);
	new cjs.ButtonHelper(this.btn_pulmon, 0, 1, 2, false, new lib.btn_pulmon(), 3);
this.btn_pulmon.on("click", function (evt) {
        putStage(new lib.frame5());
    });

	this.btn_bronquio = new lib.btn_bronquio();
	this.btn_bronquio.setTransform(763.5,348,1,1,0,0,0,65,15);
	new cjs.ButtonHelper(this.btn_bronquio, 0, 1, 2, false, new lib.btn_bronquio(), 3);
this.btn_bronquio.on("click", function (evt) {
        putStage(new lib.frame4());
    });

	this.btn_nasales = new lib.btn_fosasnasales();
	this.btn_nasales.setTransform(215.7,222,1,1,0,0,0,69,15);
	new cjs.ButtonHelper(this.btn_nasales, 0, 1, 2, false, new lib.btn_fosasnasales(), 3);
this.btn_nasales.on("click", function (evt) {
        putStage(new lib.frame6());
    });

	this.btn_traquea = new lib.btn_traquea();
	this.btn_traquea.setTransform(760.4,295,1,1,0,0,0,65,15);
	new cjs.ButtonHelper(this.btn_traquea, 0, 1, 2, false, new lib.btn_traquea(), 3);
this.btn_traquea.on("click", function (evt) {
        putStage(new lib.frame3());
    });

	this.text = new cjs.Text(txt['txtdiafragma'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(765.3,418.3+incremento);

	this.btn_laringe = new lib.btn_laringe();
	this.btn_laringe.setTransform(214.5,271.8,1,1,0,0,0,65,15);
	new cjs.ButtonHelper(this.btn_laringe, 0, 1, 2, false, new lib.btn_laringe(), 3);
  this.btn_laringe.on("click", function (evt) {
        putStage(new lib.frame2());
    });
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AQrAAMghVAAA");
	this.shape.setTransform(379.7,220.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").ss(2,1,1).p("AguAAQAAgFABgGQAFgTARgKQARgJARAFQATAFAKAQQALARgFARQAAABAAAAQgGASgRAJQgQALgSgFQgTgFgKgSQgGgLAAgLg");
	this.shape_1.setTransform(491.2,221);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgLAtQgTgFgKgSQgGgLAAgLIABgLQAFgTARgKQARgJARAFQATAFAKAQQALARgFARIAAABQgGASgRAJQgLAIgMAAIgLgCg");
	this.shape_2.setTransform(491.2,221);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AwbAAMAhjAAAAxHAAIAsAA");
	this.shape_3.setTransform(591.3,350.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#999999").ss(2,1,1).p("AAvAFQAAAEgBADQgFATgRAKQgRAJgRgFQgTgFgKgQQgLgRAFgRQAAgBAAAAQAGgSARgJQAQgLASAFQATAFAKASQAGALAAALQAAACAAACg");
	this.shape_4.setTransform(481.3,349.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgKAtQgTgFgKgQQgLgRAFgRIAAgBQAGgSARgJQAQgLASAFQATAFAKASQAGALAAALIAAAEIgsAAIAsAAIgBAHQgFATgRAKQgLAGgMAAQgEAAgHgCg");
	this.shape_5.setTransform(481.3,349.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AOaAAI8zAA");
	this.shape_6.setTransform(337.2,366.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#999999").ss(2,1,1).p("AgogVQgGALAAALQAAAFABAGQAFATARAKQARAJARgFQATgFAKgQQALgRgFgRQAAgBAAAAQgGgSgRgJQgQgLgSAFQgTAFgKASg");
	this.shape_7.setTransform(434.2,366);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgXApQgRgKgFgTIgBgLQAAgLAGgLQAKgSATgFQASgFAQALQARAJAGASIAAABQAFARgLARQgKAQgTAFQgHACgEAAQgMAAgLgGg");
	this.shape_8.setTransform(434.2,366);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AyUAAMAkpAAA");
	this.shape_9.setTransform(600.7,431.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#999999").ss(2,1,1).p("AA0ABQAAAFgCAGQgFATgSAKQgUAJgSgFQgVgFgLgQQgMgRAGgRQAAgBAAAAQAGgSASgJQASgLAUAFQAVAFALASQAHALAAALg");
	this.shape_10.setTransform(478.2,430.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgLAtQgVgFgLgQQgMgRAGgRIAAgBQAGgSASgJQASgLAUAFQAVAFALASQAHALAAALQAAAFgCAGQgFATgSAKQgNAGgNAAQgFAAgHgCg");
	this.shape_11.setTransform(478.2,430.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("Aw5AAMAhzAAA");
	this.shape_12.setTransform(592.9,294.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#999999").ss(2,1,1).p("AAwABQAAAFgBAGQgFATgRAKQgSAJgRgFQgTgFgKgQQgLgRAFgRQAAgBAAAAQAGgSARgJQARgLARAFQAUAFAKASQAGALAAALg");
	this.shape_13.setTransform(479.8,294);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgKAtQgTgFgKgQQgLgRAFgRIAAgBQAGgSARgJQARgLARAFQAUAFAKASQAGALAAALIgBALQgFATgRAKQgMAGgMAAQgFAAgGgCg");
	this.shape_14.setTransform(479.8,294);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AQrAAMghVAAA");
	this.shape_15.setTransform(363.7,270.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#999999").ss(2,1,1).p("AguAAQAAgFABgGQAFgTARgKQARgJARAFQATAFAKAQQALARgFARQAAABAAAAQgGASgRAJQgQALgSgFQgTgFgKgSQgGgLAAgLg");
	this.shape_16.setTransform(475.2,270.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgLAtQgTgFgKgSQgGgLAAgLIABgLQAFgTARgKQARgJARAFQATAFAKAQQALARgFARIAAABQgGASgRAJQgLAIgMAAIgLgCg");
	this.shape_17.setTransform(475.2,270.6);

	this.instance = new lib.Intro_ok();
	this.instance.setTransform(269.5,151);

	this.text_1 = new cjs.Text(txt['titulo'], "31px Georgia");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 33;
	this.text_1.lineWidth = 789;
	this.text_1.setTransform(473.5,61);

        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.text_1,this.instance,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.btn_laringe,this.text,this.btn_traquea,this.btn_nasales,this.btn_bronquio,this.btn_pulmon);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{laringe:0});

 basicos(this, 0, 0, 0, 0, 0);
     this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));
	// Capa 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhKMAvfMAAAhe9MCUZAAAMAAABe9g");
	mask.setTransform(475,304);

	// popup
	this.mc_laringe = new lib.mc_laringe();
	this.mc_laringe.setTransform(1266.5,344.5,1,1,0,0,0,274.4,145.9);
	this.mc_laringe.alpha = 0;

	this.mc_laringe.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.mc_laringe).wait(1).to({regX:286.4,regY:138.9,x:1231.1,y:337.5,alpha:0.059},0).wait(1).to({x:1183.8,alpha:0.118},0).wait(1).to({x:1136.4,alpha:0.176},0).wait(1).to({x:1089.1,alpha:0.235},0).wait(1).to({x:1041.7,alpha:0.294},0).wait(1).to({x:994.4,alpha:0.353},0).wait(1).to({x:947,alpha:0.412},0).wait(1).to({x:899.7,alpha:0.471},0).wait(1).to({x:852.3,alpha:0.529},0).wait(1).to({x:805,alpha:0.588},0).wait(1).to({x:757.6,alpha:0.647},0).wait(1).to({x:710.3,alpha:0.706},0).wait(1).to({x:662.9,alpha:0.765},0).wait(1).to({x:615.6,alpha:0.824},0).wait(1).to({x:568.2,alpha:0.882},0).wait(1).to({x:520.9,alpha:0.941},0).wait(1).to({x:473.5,alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(918,141,721,393);

   (lib.frame3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{laringe:0});

 basicos(this, 0, 0, 0, 0, 0);
     this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));
	// Capa 3 (mask)
var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhKMAvfMAAAhe9MCUZAAAMAAABe9g");
	mask.setTransform(475,304);

	// popup
	this.mc_traquea = new lib.mc_traquea();
	this.mc_traquea.setTransform(1266.5,344.5,1,1,0,0,0,274.4,145.9);
	this.mc_traquea.alpha = 0;

	this.mc_traquea.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.mc_traquea).wait(1).to({regX:286.4,regY:138.9,x:1231.1,y:337.5,alpha:0.059},0).wait(1).to({x:1183.8,alpha:0.118},0).wait(1).to({x:1136.4,alpha:0.176},0).wait(1).to({x:1089.1,alpha:0.235},0).wait(1).to({x:1041.7,alpha:0.294},0).wait(1).to({x:994.4,alpha:0.353},0).wait(1).to({x:947,alpha:0.412},0).wait(1).to({x:899.7,alpha:0.471},0).wait(1).to({x:852.3,alpha:0.529},0).wait(1).to({x:805,alpha:0.588},0).wait(1).to({x:757.6,alpha:0.647},0).wait(1).to({x:710.3,alpha:0.706},0).wait(1).to({x:662.9,alpha:0.765},0).wait(1).to({x:615.6,alpha:0.824},0).wait(1).to({x:568.2,alpha:0.882},0).wait(1).to({x:520.9,alpha:0.941},0).wait(1).to({x:473.5,alpha:1},0).wait(1));


}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(918,141,721,393);
  (lib.frame4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{laringe:0});

 basicos(this, 0, 0, 0, 0, 0);
     this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));
	// Capa 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhKMAvfMAAAhe9MCUZAAAMAAABe9g");
	mask.setTransform(475,304);

	// popup
	this.mc_bronquio = new lib.mc_bronquio();
	this.mc_bronquio.setTransform(1266.5,344.5,1,1,0,0,0,274.4,145.9);
	this.mc_bronquio.alpha = 0;

	this.mc_bronquio.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.mc_bronquio).wait(1).to({regX:286.4,regY:136.4,x:1231.1,y:335,alpha:0.059},0).wait(1).to({x:1183.8,alpha:0.118},0).wait(1).to({x:1136.4,alpha:0.176},0).wait(1).to({x:1089.1,alpha:0.235},0).wait(1).to({x:1041.7,alpha:0.294},0).wait(1).to({x:994.4,alpha:0.353},0).wait(1).to({x:947,alpha:0.412},0).wait(1).to({x:899.7,alpha:0.471},0).wait(1).to({x:852.3,alpha:0.529},0).wait(1).to({x:805,alpha:0.588},0).wait(1).to({x:757.6,alpha:0.647},0).wait(1).to({x:710.3,alpha:0.706},0).wait(1).to({x:662.9,alpha:0.765},0).wait(1).to({x:615.6,alpha:0.824},0).wait(1).to({x:568.2,alpha:0.882},0).wait(1).to({x:520.9,alpha:0.941},0).wait(1).to({x:473.5,alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(918,141,721,393);
  (lib.frame5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{laringe:0});

 basicos(this, 0, 0, 0, 0, 0);
     this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));
	// Capa 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhKMAvfMAAAhe9MCUZAAAMAAABe9g");
	mask.setTransform(475,304);

	// popup
	this.mc_pulmon = new lib.mc_pulmon();
	this.mc_pulmon.setTransform(1266.5,344.5,1,1,0,0,0,274.4,145.9);
	this.mc_pulmon.alpha = 0;

	this.mc_pulmon.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.mc_pulmon).wait(1).to({regX:286.4,regY:136.4,x:1228.2,y:335,alpha:0.063},0).wait(1).to({x:1177.9,alpha:0.125},0).wait(1).to({x:1127.7,alpha:0.188},0).wait(1).to({x:1077.4,alpha:0.25},0).wait(1).to({x:1027.2,alpha:0.313},0).wait(1).to({x:976.9,alpha:0.375},0).wait(1).to({x:926.7,alpha:0.438},0).wait(1).to({x:876.4,alpha:0.5},0).wait(1).to({x:826.1,alpha:0.563},0).wait(1).to({x:775.9,alpha:0.625},0).wait(1).to({x:725.6,alpha:0.688},0).wait(1).to({x:675.3,alpha:0.75},0).wait(1).to({x:625.1,alpha:0.813},0).wait(1).to({x:574.9,alpha:0.875},0).wait(1).to({x:524.6,alpha:0.938},0).wait(1).to({x:474.3,alpha:1},0).wait(1));


}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(918,141,721,393);
  (lib.frame6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{laringe:0});

 basicos(this, 0, 0, 0, 0, 0);
     this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));
	// Capa 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhKMAvfMAAAhe9MCUZAAAMAAABe9g");
	mask.setTransform(475,304);

	// popup
	this.mc_nasales = new lib.mc_nasales();
	this.mc_nasales.setTransform(1266.5,344.5,1,1,0,0,0,274.4,145.9);
	this.mc_nasales.alpha = 0;

	this.mc_nasales.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.mc_nasales).wait(1).to({regX:286.4,regY:136.4,x:1228.2,y:335,alpha:0.059},0).wait(1).to({x:1177.9,alpha:0.118},0).wait(1).to({x:1127.7,alpha:0.176},0).wait(1).to({x:1077.4,alpha:0.235},0).wait(1).to({x:1027.2,alpha:0.294},0).wait(1).to({x:976.9,alpha:0.353},0).wait(1).to({x:926.7,alpha:0.412},0).wait(1).to({x:876.4,alpha:0.471},0).wait(1).to({x:826.1,alpha:0.529},0).wait(1).to({x:775.9,alpha:0.588},0).wait(1).to({x:725.6,alpha:0.647},0).wait(1).to({x:675.3,alpha:0.706},0).wait(1).to({x:625.1,alpha:0.765},0).wait(1).to({x:574.9,alpha:0.824},0).wait(1).to({x:524.6,alpha:0.882},0).wait(1).to({x:474.3,alpha:0.941},0).wait(1));


}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(918,141,721,393);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
 
   //Simbolillos
   (lib.destacat_nen = function() {
	this.initialize(img.destacat_nen);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,928,909);


(lib.destacat_nena = function() {
	this.initialize(img.destacat_nena);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,948,909);


(lib.Image = function() {
	this.initialize(img.Image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,928,909);


(lib.Image_1 = function() {
	this.initialize(img.Image_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,948,909);


(lib.intro_ok = function() {
	this.initialize(img.intro_ok);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,595,380);


(lib.Intro_ok = function() {
	this.initialize(img.Intro_ok);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,409,380);


(lib.nasales = function() {
	this.initialize(img.nasales);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,411,350);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.pulmon = function() {
	this.initialize(img.pulmon);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,377,350);


(lib.traquea = function() {
	this.initialize(img.traquea);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,451,350);


(lib.traquea_ok = function() {
	this.initialize(img.traquea_ok);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,451,350);


(lib.btn_traquea = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_traquea'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(71.7,2.7+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape.setTransform(75.5,14.6,1.163,1.262);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_1.setTransform(75.5,14.6,1.163,1.262);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_2.setTransform(75.5,14.6,1.163,1.262);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6.5,-0.3,138,30);


(lib.btn_pulmon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_pulmon'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(66,1.9+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape.setTransform(68.6,14.4,1.163,1.262);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_1.setTransform(68.6,14.4,1.163,1.262);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_2.setTransform(68.6,14.4,1.163,1.262);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,-0.5,138,30);


(lib.btn_laringe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_laringe'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(64.4,2.5+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape.setTransform(66.4,14.9,1.163,1.262);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_1.setTransform(66.4,14.9,1.163,1.262);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_2.setTransform(66.4,14.9,1.163,1.262);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,0,138,30);


(lib.btn_fosasnasales = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_fosasnasales'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(67.2,3.3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape.setTransform(69.2,15.7,1.163,1.262);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_1.setTransform(69.2,15.7,1.163,1.262);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_2.setTransform(69.2,15.7,1.163,1.262);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape,p:{x:69.2,y:15.7}},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape,p:{x:68.9,y:15}},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.3,0.7,138,30);


(lib.btn_bronquio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_bronquio'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(69.2,4.7+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape.setTransform(72.2,16.7,1.163,1.262);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_1.setTransform(72.2,16.7,1.163,1.262);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_2.setTransform(72.2,16.7,1.163,1.262);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.2,1.7,138,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-1.9,-17);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ABeidIi6AAQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0.1,1.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg6AAAAg8IAAjDQAAg8A6AAIC6AAQA5AAAAA8IAADDQAAA8g5AAg");
	this.shape_1.setTransform(0.1,1.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("ABnitIjMAAQhAAAAABDIAADWQAABCBAAAIDMAAQA/AAAAhCIAAjWQAAhDg/AAg");
	this.shape_2.setTransform(0.1,1.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhlCuQg/AAAAhDIAAjWQAAhCA/AAIDMAAQA/AAAABCIAADWQAABDg/AAg");
	this.shape_3.setTransform(0.1,1.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{scaleX:1,scaleY:1,x:-1.9,y:-17}}]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:-3.4,y:-18.6}}]},1).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{scaleX:1,scaleY:1,x:-1.9,y:-17}}]},1).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{scaleX:1,scaleY:1,x:-1.9,y:-17}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.4,-17,31,34.2);


(lib.mc_traquea = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// botons
	this.btn_volver = new lib.btn_cerrar();
	this.btn_volver.setTransform(613.6,-24.7,0.968,0.878,0,0,0,0.1,0.2);
	new cjs.ButtonHelper(this.btn_volver, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_volver.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn_volver}]}).wait(95));

	// textes
	this.text = new cjs.Text(txt['mc_traquea_1'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 122;
	this.text.setTransform(373,72+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("Al1AAILrAA");
	this.shape.setTransform(327.5,88.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").ss(2,1,1).p("AAvABQAAAFgBAGQgFATgRAKQgRAJgRgFQgTgFgKgQQgLgRAFgRQAAgBAAAAQAGgSARgJQAQgLASAFQATAFAKASQAGALAAALg");
	this.shape_1.setTransform(285.2,88);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgKAtQgTgFgKgQQgLgRAFgRIAAgBQAGgSARgJQAQgLASAFQATAFAKASQAGALAAALIgBALQgFATgRAKQgLAGgMAAQgEAAgHgCg");
	this.shape_2.setTransform(285.2,88);

	this.text_1 = new cjs.Text(txt['mc_traquea_2'], "20px Verdana");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 80;
	this.text_1.setTransform(453,16+incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("Al1AAILrAA");
	this.shape_3.setTransform(327.5,32.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#999999").ss(2,1,1).p("AAvABQAAAFgBAGQgFATgRAKQgRAJgRgFQgTgFgKgQQgLgRAFgRQAAgBAAAAQAGgSARgJQAQgLASAFQATAFAKASQAGALAAALg");
	this.shape_4.setTransform(285.2,32);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgKAtQgTgFgKgQQgLgRAFgRIAAgBQAGgSARgJQAQgLASAFQATAFAKASQAGALAAALIgBALQgFATgRAKQgLAGgMAAQgEAAgHgCg");
	this.shape_5.setTransform(285.2,32);

	this.text_2 = new cjs.Text(txt['mc_traquea'], "bold 23px Verdana");
	this.text_2.lineHeight = 25;
	this.text_2.lineWidth = 193;
	this.text_2.setTransform(-41.3,-29.5+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.text_1},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text}]}).wait(95));

	// imatge
	this.instance = new lib.traquea_ok();
	this.instance.setTransform(4.5,-17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(95));

	// ficha
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,1,1).p("EA2wgerMhtfAAAQhkAAAABkMAAAA6PQAABkBkAAMBtfAAAQBkAAAAhkMAAAg6PQAAhkhkAAg");
	this.shape_6.setTransform(286.4,138.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Eg2vAesQhkAAAAhkMAAAg6PQAAhkBkAAMBtfAAAQBkAAAABkMAAAA6PQAABkhkAAg");
	this.shape_7.setTransform(286.4,138.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6}]}).wait(95));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-57.5,721,393);


(lib.mc_pulmon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// botons
	this.btn_volver = new lib.btn_cerrar();
	this.btn_volver.setTransform(615.6,-43.6);
	new cjs.ButtonHelper(this.btn_volver, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_volver.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn_volver}]}).wait(95));

	// textes
	this.text = new cjs.Text(txt['mc_pulmon_1'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 106;
	this.text.setTransform(510.1,118.5+incremento);

	this.text_1 = new cjs.Text(txt['mc_traquea_2'], "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 91;
	this.text_1.setTransform(466.1,14.6+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AswAAIZhAA");
	this.shape.setTransform(375.2,30.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").ss(2,1,1).p("AgYglQAQgMATAEQASAGAKARQAIALABALQgBAFgCAGQgFATgPAKQgRAIgRgCQgUgFgKgRQgLgQAEgRQAAAAAAgCQAGgSAQgIg");
	this.shape_1.setTransform(288.4,28.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgJAuQgUgFgKgRQgLgQAEgRIAAgCQAGgSAQgIQAQgMATAEQASAGAKARQAIALABALQgBAFgCAGQgFATgPAKQgNAHgNAAIgIgBg");
	this.shape_2.setTransform(288.4,28.7);

	this.text_2 = new cjs.Text(txt['mc_pulmon_2'], "20px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 91;
	this.text_2.setTransform(56.1,251+incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,0,0,3.9).p("AEdAAIo5AA");
	this.shape_3.setTransform(96.3,265.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#999999").ss(2,1,1).p("AgegkQARgKARAAQAUACAMAQQANAPgCARQAAAAAAACQgDASgPALQgPANgSgBQgTgEgNgPQgJgLgCgMQAAgFACgFQACgTANgMg");
	this.shape_4.setTransform(130.1,266.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgEAvQgTgEgNgPQgJgLgCgMQAAgFACgFQACgTANgMQARgKARAAQAUACAMAQQANAPgCARIAAACQgDASgPALQgNAMgQAAIgEAAg");
	this.shape_5.setTransform(130.1,266.5);

	this.text_3 = new cjs.Text(txt['mc_pulmon_3'], "20px Verdana");
	this.text_3.textAlign = "right";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 91;
	this.text_3.setTransform(56.8,173.1+incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,0,0,3.9).p("AJuAAIzbAA");
	this.shape_6.setTransform(132.1,202);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#999999").ss(2,1,1).p("AAdAjQgPANgSgBQgTgEgNgPQgJgLgCgMQAAgFACgFQACgTANgMQARgKARAAQAUACAMAQQANAPgCARQAAAAAAACQgDASgPALg");
	this.shape_7.setTransform(199.6,202.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgEAvQgTgEgNgPQgJgLgCgMQAAgFACgFQACgTANgMQARgKARAAQAUACAMAQQANAPgCARIAAACQgDASgPALQgNAMgQAAIgEAAg");
	this.shape_8.setTransform(199.6,202.7);

	this.text_4 = new cjs.Text(txt['mc_pulmon_4'], "20px Verdana");
	this.text_4.textAlign = "right";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 91;
	this.text_4.setTransform(56.8,84.4+incremento);

	this.text_5 = new cjs.Text(txt['mc_pulmon_5'], "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 123;
	this.text_5.setTransform(327.3,-51.3+incremento);

	this.text_6 = new cjs.Text(txt['mc_pulmon_6'], "20px Verdana");
	this.text_6.textAlign = "right";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 123;
	this.text_6.setTransform(244.5,-51.3+incremento);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,0,0,3.9).p("AJuAAIzbAA");
	this.shape_9.setTransform(132.1,113.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#999999").ss(2,1,1).p("AAvAGQgDASgPALQgPANgSgBQgTgEgNgPQgJgLgCgMQAAgFACgFQACgTANgMQARgKARAAQAUACAMAQQANAPgCARQAAAAAAACg");
	this.shape_10.setTransform(199.6,114);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgEAvQgTgEgNgPQgJgLgCgMQAAgFACgFQACgTANgMQARgKARAAQAUACAMAQQANAPgCARIAAACQgDASgPALQgNAMgQAAIgEAAg");
	this.shape_11.setTransform(199.6,114);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,0,0,3.9).p("AsjACIZHgC");
	this.shape_12.setTransform(423.5,137.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#999999").ss(2,1,1).p("AAvAFQgBAGgCAGQgHARgRAJQgSAHgRgGQgSgHgJgSQgIgRAHgRQAAAAAAAAQAIgSARgHQARgKARAHQATAIAHASQAGAMgBAKg");
	this.shape_13.setTransform(338.2,136.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgPAsQgSgHgJgSQgIgRAHgRIAAAAQAIgSARgHQARgKARAHQATAIAHASQAGAMgBAKIgDAMQgHARgRAJQgKAEgKAAQgGAAgJgDg");
	this.shape_14.setTransform(338.2,136.9);

	this.text_7 = new cjs.Text(txt['mc_pulmon'], "bold 23px Verdana");
	this.text_7.lineHeight = 25;
	this.text_7.lineWidth = 193;
	this.text_7.setTransform(-51.3,-60.5+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_7},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.text_3},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.text_2},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_1},{t:this.text}]}).wait(95));

	// imatge
	this.instance = new lib.pulmon();
	this.instance.setTransform(98.1,-18.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(95));

	// ficha
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,1,1).p("EA2wghFMhtfAAAQhkAAAABrMAAAA+0QAABsBkAAMBtfAAAQBkAAAAhsMAAAg+0QAAhrhkAAg");
	this.shape_15.setTransform(286.4,136.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("Eg2vAhGQhkAAAAhsMAAAg+0QAAhrBkAAMBtfAAAQBkAAAABrMAAAA+0QAABshkAAg");
	this.shape_16.setTransform(286.4,136.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15}]}).wait(95));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-75.4,721,423.8);


(lib.mc_nasales = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// botons
	this.btn_volver = new lib.btn_cerrar();
	this.btn_volver.setTransform(615.6,-43.6,0.968,0.878,0,0,0,0.1,0.3);
	new cjs.ButtonHelper(this.btn_volver, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_volver.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn_volver}]}).wait(95));

	// textes
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AMjAHI5FgN");
	this.shape.setTransform(182.7,94.7,1,1,-8.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").ss(2,1,1).p("AgugBQAAgGACgGQAGgSARgKQASgIAQAFQATAGAJARQAJARgFARQAAABgBAAQgGASgRAIQgQALgRgGQgUgHgIgRQgHgMABgKg");
	this.shape_1.setTransform(267,82.4,1,1,-8.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgMAtQgUgHgIgRQgHgMABgKIACgMQAGgSARgKQASgIAQAFQATAGAJARQAJARgFARIgBABQgGASgRAIQgKAHgLAAQgFAAgHgCg");
	this.shape_2.setTransform(267,82.4,1,1,-8.9);

	this.text = new cjs.Text(txt['mc_nasales_1'], "20px Verdana");
	this.text.textAlign = "right";
	this.text.lineHeight = 22;
	this.text.lineWidth = 86;
	this.text.setTransform(84.6,93+incremento);

	this.text_1 = new cjs.Text(txt['mc_nasales_2'], "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 86;
	this.text_1.setTransform(462.9,49.3+incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AspgDIZTAH");
	this.shape_3.setTransform(366.6,74.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#999999").ss(2,1,1).p("AglAcQgMgPACgSQABAAAAgBQAEgTAPgKQAPgNATADQATAEAMAQQAJAKABANQAAADgCAHQgDATgOALQgQAJgSAAQgUgDgMgQg");
	this.shape_4.setTransform(280.3,73.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgFAvQgUgDgMgQQgMgPACgSIABgBQAEgTAPgKQAPgNATADQATAEAMAQQAJAKABANQAAADgCAHQgDATgOALQgQAJgQAAIgCAAg");
	this.shape_5.setTransform(280.3,73.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AMjAHI5FgN");
	this.shape_6.setTransform(192.8,96.2,1.15,1,-6.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#999999").ss(2,1,1).p("AgugBQAAgGACgGQAGgSARgKQASgIAQAFQATAGAJARQAJARgFARQAAABgBAAQgGASgRAIQgQALgRgGQgUgHgIgRQgHgMABgKg");
	this.shape_7.setTransform(290.1,85.6,1.15,1,-6.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgMAtQgUgHgIgRQgHgMABgKIACgMQAGgSARgKQASgIAQAFQATAGAJARQAJARgFARIgBABQgGASgRAIQgKAHgLAAQgFAAgHgCg");
	this.shape_8.setTransform(290.1,85.6,1.15,1,-6.7);

	this.text_2 = new cjs.Text(txt['mc_nasales'], "bold 23px Verdana");
	this.text_2.lineHeight = 25;
	this.text_2.lineWidth = 193;
	this.text_2.setTransform(-51.3,-60.5+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.text_1},{t:this.text},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(95));

	// imatge
	this.instance = new lib.nasales();
	this.instance.setTransform(74.1,-7.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(95));

	// ficha
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,1,1).p("EA2wghFMhtfAAAQhkAAAABrMAAAA+0QAABsBkAAMBtfAAAQBkAAAAhsMAAAg+0QAAhrhkAAg");
	this.shape_9.setTransform(286.4,136.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Eg2vAhGQhkAAAAhsMAAAg+0QAAhrBkAAMBtfAAAQBkAAAABrMAAAA+0QAABshkAAg");
	this.shape_10.setTransform(286.4,136.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9}]}).wait(95));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-75.4,721,423.8);


(lib.mc_laringe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textes
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AF2AAIrrAA");
	this.shape.setTransform(234.4,292.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").ss(2,1,1).p("AgtAMQAFATARAKQARAJARgFQATgFAKgQQALgRgFgRQAAgBAAAAQgGgSgRgJQgQgLgSAFQgTAFgKASQgGALAAALQAAAFABAGg");
	this.shape_1.setTransform(276.6,292.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgXApQgRgKgFgTIgBgLQAAgLAGgLQAKgSATgFQASgFAQALQARAJAGASIAAABQAFARgLARQgKAQgTAFQgHACgEAAQgMAAgLgGg");
	this.shape_2.setTransform(276.6,292.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AK3AAI1tAA");
	this.shape_3.setTransform(205.3,189.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#999999").ss(2,1,1).p("AgtAMQAFATARAKQARAJARgFQATgFAKgQQALgRgFgRQAAgBAAAAQgGgSgRgJQgQgLgSAFQgTAFgKASQgGALAAALQAAAFABAGg");
	this.shape_4.setTransform(279.6,189.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgXApQgRgKgFgTIgBgLQAAgLAGgLQAKgSATgFQASgFAQALQARAJAGASIAAABQAFARgLARQgKAQgTAFQgHACgEAAQgMAAgLgGg");
	this.shape_5.setTransform(279.6,189.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("An9AAIP7AA");
	this.shape_6.setTransform(335.8,211.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#999999").ss(2,1,1).p("AAwABQAAAFgBAGQgFATgRAKQgSAJgRgFQgUgFgJgQQgLgRAFgRQAAgBAAAAQAGgSARgJQAQgLASAFQAUAFAKASQAGALAAALg");
	this.shape_7.setTransform(279.8,211.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgKAtQgUgFgJgQQgLgRAFgRIAAgBQAGgSARgJQAQgLASAFQAUAFAKASQAGALAAALIgBALQgFATgRAKQgMAGgMAAQgFAAgGgCg");
	this.shape_8.setTransform(279.8,211.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("An9AAIP7AA");
	this.shape_9.setTransform(336.3,160.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#999999").ss(2,1,1).p("AAvABQAAAFgBAGQgFATgRAKQgRAJgRgFQgTgFgKgQQgLgRAFgRQAAgBAAAAQAGgSARgJQAQgLASAFQATAFAKASQAGALAAALg");
	this.shape_10.setTransform(280.5,160.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgKAtQgTgFgKgQQgLgRAFgRIAAgBQAGgSARgJQAQgLASAFQATAFAKASQAGALAAALIgBALQgFATgRAKQgLAGgMAAQgEAAgHgCg");
	this.shape_11.setTransform(280.5,160.1);

	this.text = new cjs.Text(txt['mc_laringe_1'], "20px Verdana");
	this.text.textAlign = "right";
	this.text.lineHeight = 22;
	this.text.lineWidth = 93;
	this.text.setTransform(129.7,155.4+incremento);

	this.text_1 = new cjs.Text(txt['mc_traquea_2'], "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 93;
	this.text_1.setTransform(97.7,275.5+incremento);

	this.text_2 = new cjs.Text(txt['mc_laringe_2'], "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 93;
	this.text_2.setTransform(390.5,193.6+incremento);

	this.text_3 = new cjs.Text(txt['mc_laringe_3'], "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 93;
	this.text_3.setTransform(390.5,146.4+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(95));

	// imatge
	this.instance = new lib.nasales();
	this.instance.setTransform(74.1,-25.8);

	this.btn_volver = new lib.btn_cerrar();
	this.btn_volver.setTransform(613.6,-24.7,0.968,0.878,0,0,0,0.1,0.2);
	new cjs.ButtonHelper(this.btn_volver, 0, 1, 2, false, new lib.btn_cerrar(), 3);
  this.btn_volver.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.text_4 = new cjs.Text(txt['btn_laringe'], "bold 23px Verdana");
	this.text_4.lineHeight = 25;
	this.text_4.lineWidth = 193;
	this.text_4.setTransform(-29.3,-29.5+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_4},{t:this.btn_volver},{t:this.instance}]}).wait(95));

	// ficha
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,1,1).p("EA2wgerMhtfAAAQhkAAAABkMAAAA6PQAABkBkAAMBtfAAAQBkAAAAhkMAAAg6PQAAhkhkAAg");
	this.shape_12.setTransform(286.4,138.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Eg2vAesQhkAAAAhkMAAAg6PQAAhkBkAAMBtfAAAQBkAAAABkMAAAA6PQAABkhkAAg");
	this.shape_13.setTransform(286.4,138.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12}]}).wait(95));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-57.5,721,393);


(lib.mc_bronquio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// botons
	this.btn_volver = new lib.btn_cerrar();
	this.btn_volver.setTransform(615.6,-43.6,0.968,0.878,0,0,0,0.1,0.3);
	new cjs.ButtonHelper(this.btn_volver, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_volver.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn_volver}]}).wait(95));

	// textes
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AGilLItDKX");
	this.shape.setTransform(97.8,219.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").ss(2,1,1).p("AglAbQgDgEgCgGQgHgQAFgRQAJgRASgJQARgIARAIQATAGAIATQAAAAAAAAQAGARgHAQQgGASgSAJQgTAHgQgHQgNgFgHgKQgBAAAAgBg");
	this.shape_1.setTransform(143.5,183.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgQArQgNgFgHgKIgBgBIgFgKQgHgQAFgRQAJgRASgJQARgIARAIQATAGAIATIAAAAQAGARgHAQQgGASgSAJQgJAEgJAAQgHAAgKgEg");
	this.shape_2.setTransform(143.5,183.8);

	this.text = new cjs.Text(txt['mc_bronquio_1'], "20px Verdana");
	this.text.textAlign = "right";
	this.text.lineHeight = 22;
	this.text.lineWidth = 89;
	this.text.setTransform(45.2,233.4+incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AkGi9IgEgJIgEAZQgHAZgQAEIgbAfQgTAlAlAcIgHAdQABAcAlAEIAHAtQAQAtAwgFIgCAuQAHAtAxgJIACAWQADAaAIAPQAbAzBJhCIAUAdQAaAZArgUIAWAVQAaAXAaAMQBRAmAphYQARgGAKgMQAUgXghgeIAIhNIASgLQAPgPgQgTIAbgCQAWgJgdglQAHgTAAgSQgCgqgngNQAFgegGgfQgMg/gxgDQAKgUABgVQAEgpgpgDQgRAIgWAAQgsgBgWgsQgMgJgSgEQgkgHgWAcQgVgNgUgDQgpgFACA1QgPgFgSAAQgjgBgLAXQgigHgfAEQg8AJAWA1");
	this.shape_3.setTransform(155,159.4);

	this.text_1 = new cjs.Text(txt['mc_bronquio_2'], "20px Verdana");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 78;
	this.text_1.setTransform(33.9,184.6+incremento);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AE/j8Ip9H6");
	this.shape_4.setTransform(70.7,156.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#999999").ss(2,1,1).p("AgkAcQgDgEgDgHQgHgQAFgRQAJgRASgJQARgIARAIQATAGAIATQAAAAAAAAQAGARgHAQQgGASgSAJQgTAHgQgHQgNgFgHgKg");
	this.shape_5.setTransform(106.4,127.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgQArQgNgFgHgKIgGgLQgHgQAFgRQAJgRASgJQARgIARAIQATAGAIATIAAAAQAGARgHAQQgGASgSAJQgJAEgJAAQgHAAgKgEg");
	this.shape_6.setTransform(106.4,127.9);

	this.text_2 = new cjs.Text(txt['mc_bronquio_3'], "20px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 101;
	this.text_2.setTransform(61.5,27.4+incremento);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AFWDeIqrm7");
	this.shape_7.setTransform(104.5,79.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#999999").ss(2,1,1).p("AgmgZQADgEAFgEQAOgNARAAQAUACAOAOQANAPgCASQAAAUgPANQAAAAAAABQgPALgQgBQgUgBgOgOQgNgPACgSQAAgNAHgLg");
	this.shape_8.setTransform(142.6,104);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAAAvQgUgBgOgOQgNgPACgSQAAgNAHgLQADgEAFgEQAOgNARAAQAUACAOAOQANAPgCASQAAAUgPANIAAABQgNAKgQAAIgCAAg");
	this.shape_9.setTransform(142.6,104);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AgkGWIBJsr");
	this.shape_10.setTransform(168.6,50.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#999999").ss(2,1,1).p("AAFguQAGAAAGADQARAHAJAQQAHASgGASQgHASgSAIQgRAJgRgHQAAAAgBAAQgRgHgHgSQgJgRAGgSQAIgSASgIQAMgFAKABg");
	this.shape_11.setTransform(164.3,96.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgPAsIgBAAQgRgHgHgSQgJgRAGgSQAIgSASgIQAMgFAKABQAGAAAGADQARAHAJAQQAHASgGASQgHASgSAIQgKAFgJAAQgHAAgIgDg");
	this.shape_12.setTransform(164.3,96.3);

	this.text_3 = new cjs.Text(txt['mc_bronquio_4'], "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 194;
	this.text_3.setTransform(130.8,-47.9+incremento);

	this.text_4 = new cjs.Text(txt['mc_bronquio_5'], "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 194;
	this.text_4.setTransform(272.7,-49.9+incremento);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AoCGuIQFtb");
	this.shape_13.setTransform(264.9,21.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#999999").ss(2,1,1).p("Ag7AkQgNgYAHgXQADgdAYgRQAZgOAbAFQATAEAOALQAFAGAEAJQAQAXgEAZQgIAbgXARQgYAQgagGQgdgEgQgYQABgBgCgBg");
	this.shape_14.setTransform(206.8,68.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgNBCQgdgEgQgYQAAAAABAAQAAAAgBgBQAAAAAAAAQAAAAgBgBQgNgYAHgXQADgdAYgRQAZgOAbAFQATAEAOALQAFAGAEAJQAQAXgEAZQgIAbgXARQgSAMgTAAQgGAAgHgCg");
	this.shape_15.setTransform(206.8,68.4);

	this.text_5 = new cjs.Text(txt['mc_bronquio_6'], "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 122;
	this.text_5.setTransform(486.7,269.4+incremento);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AkLESIIWoj");
	this.shape_16.setTransform(386.6,110.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#999999").ss(2,1,1).p("AAhggQAEADADAGQAKARgEAQQgGATgQALQgRAKgRgFQgUgEgKgRQAAAAgBgBQgIgQAFgQQAEgUARgLQARgJARAFQAOADAIAJg");
	this.shape_17.setTransform(356.4,141.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgKAtQgUgEgKgRIgBgBQgIgQAFgQQAEgUARgLQARgJARAFQAOADAIAJQAEADADAGQAKARgEAQQgGATgQALQgMAGgMAAQgEAAgGgBg");
	this.shape_18.setTransform(356.4,141.7);

	this.text_6 = new cjs.Text(txt['mc_bronquio_7'], "20px Verdana");
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 122;
	this.text_6.setTransform(421.4,51.3+incremento);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AnHEkIOPpH");
	this.shape_19.setTransform(368.6,111.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#999999").ss(2,1,1).p("AAogYQADAFACAGQAFAQgIASQgKARgSAGQgRAGgRgJQgSgIgGgTQAAAAAAgBQgFgQAJgRQAIgSATgGQARgFARAJQANAGAGAKg");
	this.shape_20.setTransform(318.9,143.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgUApQgSgIgGgTIAAgBQgFgQAJgRQAIgSATgGQARgFARAJQANAGAGAKQADAFACAGQAFAQgIASQgKARgSAGQgIADgGAAQgKAAgKgGg");
	this.shape_21.setTransform(318.9,143.7);

	this.text_7 = new cjs.Text(txt['mc_bronquio'], "bold 23px Verdana");
	this.text_7.lineHeight = 25;
	this.text_7.lineWidth = 193;
	this.text_7.setTransform(-51.3,-60.5+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_7},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.text_6},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.text_5},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.text_4},{t:this.text_3},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.text_2},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.text_1},{t:this.shape_3},{t:this.text},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(95));

	// imatge
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#2D2C2E").ss(1,0,0,3.9).p("AtVAAIarAA");
	this.shape_22.setTransform(389,285.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#999999").ss(2,1,1).p("AAvABQAAAFgBAGQgFATgRAKQgRAJgRgFQgTgFgKgQQgLgRAFgRQAAgBAAAAQAGgSARgJQAQgLASAFQATAFAKASQAGALAAALg");
	this.shape_23.setTransform(298.8,285.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgKAtQgTgFgKgQQgLgRAFgRIAAgBQAGgSARgJQAQgLASAFQATAFAKASQAGALAAALIgBALQgFATgRAKQgLAGgMAAQgEAAgHgCg");
	this.shape_24.setTransform(298.8,285.2);

	this.instance = new lib.traquea();
	this.instance.setTransform(59.5,-5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22}]}).wait(95));

	// ficha
	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(2,1,1).p("EA2wgerMhtfAAAQhkAAAABkMAAAA6PQAABkBkAAMBtfAAAQBkAAAAhkMAAAg6PQAAhkhkAAg");
	this.shape_25.setTransform(286.4,136.4,1,1.078);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("Eg2vAesQhkAAAAhkMAAAg6PQAAhkBkAAMBtfAAAQBkAAAABkMAAAA6PQAABkhkAAg");
	this.shape_26.setTransform(286.4,136.4,1,1.078);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25}]}).wait(95));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74,-75.4,721,423.8);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}