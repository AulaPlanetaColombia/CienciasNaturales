(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
       basicos(this, 0, 0, 1, 0, 0);
        
        this.mc_objetivo = new lib.mc_Objetivo("single",0);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);
this.mc_objetivo.btn_siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
	this.CdP_Introduccion = new lib.CdP_Conclusion("single",2);
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        //new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion();
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);
 this.CdP_Conclusion.on("click", function (evt) {
     putStage(new lib.frame12());
    });

	this.CdP_Proceso = new lib.CdP_Tarea();
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);
 this.CdP_Proceso.on("click", function (evt) {
        putStage(new lib.frame4());
    });

	this.CdP_Tarea = new lib.CdP_Proceso();
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 this.CdP_Tarea.on("click", function (evt) {
       putStage(new lib.frame3());
    });


        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Tarea,this.CdP_Introduccion,this.CdP_Proceso,this.CdP_Conclusionb,this.CdP_Conclusion,this.CdP_Introduccion,this.mc_objetivo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 0);
        this.mc_objetivo = new lib.mc_Objetivo("single",1);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);
this.mc_objetivo.btn_siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
	this.CdP_Introduccion = new lib.CdP_Conclusion("single",2);
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        //new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
         putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion();
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);
 this.CdP_Conclusion.on("click", function (evt) {
          putStage(new lib.frame12());
    });

	this.CdP_Proceso = new lib.CdP_Tarea();
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);
 this.CdP_Proceso.on("click", function (evt) {
       putStage(new lib.frame4());
    });

	this.CdP_Tarea = new lib.CdP_Proceso();
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 this.CdP_Tarea.on("click", function (evt) {
         putStage(new lib.frame3());
    });


        
       this.mc_objetivo.btn_anterior.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Tarea,this.CdP_Introduccion,this.CdP_Proceso,this.CdP_Conclusionb,this.CdP_Conclusion,this.CdP_Introduccion,this.mc_objetivo);
        
        
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
     this.mc_objetivo = new lib.mc_material("single",0);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);

	this.CdP_Introduccion = new lib.CdP_Conclusion();
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion();
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);
 this.CdP_Conclusion.on("click", function (evt) {
     putStage(new lib.frame12());
    });

	this.CdP_Proceso = new lib.CdP_Tarea();
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);

this.CdP_Proceso.on("click", function (evt) {
       putStage(new lib.frame4());
    });

	this.CdP_Tarea = new lib.CdP_Proceso("single",2);
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 

        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Introduccion,this.CdP_Proceso,this.CdP_Conclusionb,this.CdP_Introduccion,this.CdP_Conclusion,this.CdP_Tarea,this.mc_objetivo);

        

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
      this.mc_objetivo = new lib.mc_Procedimiento("single",0);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);
this.mc_objetivo.btn_siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });

	this.CdP_Introduccion = new lib.CdP_Conclusion();
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion();
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);
 this.CdP_Conclusion.on("click", function (evt) {
     putStage(new lib.frame12());
    });

	this.CdP_Proceso = new lib.CdP_Tarea("single",2);
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);


	this.CdP_Tarea = new lib.CdP_Proceso();
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 this.CdP_Tarea.on("click", function (evt) {
       putStage(new lib.frame3());
    });


        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Introduccion,this.CdP_Conclusionb,this.CdP_Introduccion,this.CdP_Conclusion,this.CdP_Tarea,this.CdP_Proceso,this.mc_objetivo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
     (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
      this.mc_objetivo = new lib.mc_Procedimiento("single",1);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);
this.mc_objetivo.btn_siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
this.mc_objetivo.btn_anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
	this.CdP_Introduccion = new lib.CdP_Conclusion();
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion();
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);
 this.CdP_Conclusion.on("click", function (evt) {
     putStage(new lib.frame12());
    });

	this.CdP_Proceso = new lib.CdP_Tarea("single",2);
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);


	this.CdP_Tarea = new lib.CdP_Proceso();
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 this.CdP_Tarea.on("click", function (evt) {
       putStage(new lib.frame3());
    });


        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Introduccion,this.CdP_Conclusionb,this.CdP_Introduccion,this.CdP_Conclusion,this.CdP_Tarea,this.CdP_Proceso,this.mc_objetivo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  
   (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
      this.mc_objetivo = new lib.mc_Procedimiento("single",2);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);
this.mc_objetivo.btn_siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
this.mc_objetivo.btn_anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
	this.CdP_Introduccion = new lib.CdP_Conclusion();
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion();
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);
 this.CdP_Conclusion.on("click", function (evt) {
     putStage(new lib.frame12());
    });

	this.CdP_Proceso = new lib.CdP_Tarea("single",2);
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);


	this.CdP_Tarea = new lib.CdP_Proceso();
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 this.CdP_Tarea.on("click", function (evt) {
       putStage(new lib.frame3());
    });


        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Introduccion,this.CdP_Conclusionb,this.CdP_Introduccion,this.CdP_Conclusion,this.CdP_Tarea,this.CdP_Proceso,this.mc_objetivo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
   (lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
      this.mc_objetivo = new lib.mc_Procedimiento("single",3);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);
this.mc_objetivo.btn_siguiente.on("click", function (evt) {
            putStage(new lib.frame8());
        });
this.mc_objetivo.btn_anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
	this.CdP_Introduccion = new lib.CdP_Conclusion();
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion();
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);
 this.CdP_Conclusion.on("click", function (evt) {
     putStage(new lib.frame12());
    });

	this.CdP_Proceso = new lib.CdP_Tarea("single",2);
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);


	this.CdP_Tarea = new lib.CdP_Proceso();
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 this.CdP_Tarea.on("click", function (evt) {
       putStage(new lib.frame3());
    });


        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Introduccion,this.CdP_Conclusionb,this.CdP_Introduccion,this.CdP_Conclusion,this.CdP_Tarea,this.CdP_Proceso,this.mc_objetivo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
      this.mc_objetivo = new lib.mc_Procedimiento("single",4);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);
this.mc_objetivo.btn_siguiente.on("click", function (evt) {
            putStage(new lib.frame9());
        });
this.mc_objetivo.btn_anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
	this.CdP_Introduccion = new lib.CdP_Conclusion();
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion();
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);
 this.CdP_Conclusion.on("click", function (evt) {
     putStage(new lib.frame12());
    });

	this.CdP_Proceso = new lib.CdP_Tarea("single",2);
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);


	this.CdP_Tarea = new lib.CdP_Proceso();
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 this.CdP_Tarea.on("click", function (evt) {
       putStage(new lib.frame3());
    });


        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Introduccion,this.CdP_Conclusionb,this.CdP_Introduccion,this.CdP_Conclusion,this.CdP_Tarea,this.CdP_Proceso,this.mc_objetivo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
   (lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
      this.mc_objetivo = new lib.mc_Procedimiento("single",5);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);
this.mc_objetivo.btn_siguiente.on("click", function (evt) {
            putStage(new lib.frame10());
        });
this.mc_objetivo.btn_anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });
	this.CdP_Introduccion = new lib.CdP_Conclusion();
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion();
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);
 this.CdP_Conclusion.on("click", function (evt) {
     putStage(new lib.frame12());
    });

	this.CdP_Proceso = new lib.CdP_Tarea("single",2);
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);


	this.CdP_Tarea = new lib.CdP_Proceso();
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 this.CdP_Tarea.on("click", function (evt) {
       putStage(new lib.frame3());
    });


        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Introduccion,this.CdP_Conclusionb,this.CdP_Introduccion,this.CdP_Conclusion,this.CdP_Tarea,this.CdP_Proceso,this.mc_objetivo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame10 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
      this.mc_objetivo = new lib.mc_Procedimiento("single",6);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);
this.mc_objetivo.btn_siguiente.on("click", function (evt) {
            putStage(new lib.frame11());
        });
this.mc_objetivo.btn_anterior.on("click", function (evt) {
            putStage(new lib.frame9());
        });
	this.CdP_Introduccion = new lib.CdP_Conclusion();
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion();
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);
 this.CdP_Conclusion.on("click", function (evt) {
     putStage(new lib.frame12());
    });

	this.CdP_Proceso = new lib.CdP_Tarea("single",2);
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);


	this.CdP_Tarea = new lib.CdP_Proceso();
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 this.CdP_Tarea.on("click", function (evt) {
       putStage(new lib.frame3());
    });


        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Introduccion,this.CdP_Conclusionb,this.CdP_Introduccion,this.CdP_Conclusion,this.CdP_Tarea,this.CdP_Proceso,this.mc_objetivo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame11 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
      this.mc_objetivo = new lib.mc_Procedimiento("single",7);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);
this.mc_objetivo.btn_siguiente.on("click", function (evt) {
            putStage(new lib.frame12());
        });
this.mc_objetivo.btn_anterior.on("click", function (evt) {
            putStage(new lib.frame10());
        });
	this.CdP_Introduccion = new lib.CdP_Conclusion();
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion();
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);
 this.CdP_Conclusion.on("click", function (evt) {
     putStage(new lib.frame12());
    });

	this.CdP_Proceso = new lib.CdP_Tarea("single",2);
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);


	this.CdP_Tarea = new lib.CdP_Proceso();
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 this.CdP_Tarea.on("click", function (evt) {
       putStage(new lib.frame3());
    });


        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Introduccion,this.CdP_Conclusionb,this.CdP_Introduccion,this.CdP_Conclusion,this.CdP_Tarea,this.CdP_Proceso,this.mc_objetivo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame12 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
       basicos(this, 0, 0, 1, 0, 0);
          this.mc_objetivo = new lib.mc_preguntas("single",0);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);
this.mc_objetivo.btn_siguiente.on("click", function (evt) {
            putStage(new lib.frame13());
        });
	this.CdP_Introduccion = new lib.CdP_Conclusion();
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion("single",2);
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);


	this.CdP_Proceso = new lib.CdP_Tarea();
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);
 this.CdP_Proceso.on("click", function (evt) {
        putStage(new lib.frame4());
    });

	this.CdP_Tarea = new lib.CdP_Proceso();
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 this.CdP_Tarea.on("click", function (evt) {
       putStage(new lib.frame3());
    });


        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Tarea,this.CdP_Introduccion,this.CdP_Proceso,this.CdP_Conclusionb,this.CdP_Introduccion,this.CdP_Conclusion,this.mc_objetivo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame13 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 0);
          this.mc_objetivo = new lib.mc_preguntas("single",1);
	this.mc_objetivo.setTransform(475.4,343.5,1,1,0,0,0,419.4,198.5);
this.mc_objetivo.btn_anterior.on("click", function (evt) {
            putStage(new lib.frame12());
        });
	this.CdP_Introduccion = new lib.CdP_Conclusion();
	this.CdP_Introduccion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Introduccion, 0, 1, 2, false, new lib.CdP_Conclusion(), 3);
 this.CdP_Introduccion.on("click", function (evt) {
        putStage(new lib.frame1());
    });
	this.CdP_Conclusionb = new lib.CdP_Introduccionb("single",2);
	this.CdP_Conclusionb.setTransform(473.5,324.5,1,1,0,0,180);
	this.CdP_Conclusionb.shadow = new cjs.Shadow("#000000",11,11,15);
        this.CdP_Conclusion = new lib.CdP_Introduccion("single",2);
	this.CdP_Conclusion.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Conclusion, 0, 1, 2, false, new lib.CdP_Introduccion(), 3);


	this.CdP_Proceso = new lib.CdP_Tarea();
	this.CdP_Proceso.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Proceso, 0, 1, 2, false, new lib.CdP_Tarea(), 3);
 this.CdP_Proceso.on("click", function (evt) {
        putStage(new lib.frame4());
    });

	this.CdP_Tarea = new lib.CdP_Proceso();
	this.CdP_Tarea.setTransform(473.5,324.5,1,1,0,0,180);
        new cjs.ButtonHelper(this.CdP_Tarea, 0, 1, 2, false, new lib.CdP_Proceso(), 3);
 this.CdP_Tarea.on("click", function (evt) {
       putStage(new lib.frame3());
    });


        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.CdP_Tarea,this.CdP_Introduccion,this.CdP_Proceso,this.CdP_Conclusionb,this.CdP_Introduccion,this.CdP_Conclusion,this.mc_objetivo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib._00075F01 = function() {
	this.initialize(img._00075F01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,260,400);


(lib.CN_07_11_16_0 = function() {
	this.initialize(img.CN_07_11_16_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,625,400);


(lib.CN_07_11_16_1 = function() {
	this.initialize(img.CN_07_11_16_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,625,400);


(lib.CN_07_11_16_2 = function() {
	this.initialize(img.CN_07_11_16_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,625,400);


(lib.CN_07_11_16_3 = function() {
	this.initialize(img.CN_07_11_16_3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,625,400);


(lib.CN_07_11_16_4 = function() {
	this.initialize(img.CN_07_11_16_4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,625,400);


(lib.CN_07_11_16_5 = function() {
	this.initialize(img.CN_07_11_16_5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,625,400);


(lib.CN_07_11_16_6 = function() {
	this.initialize(img.CN_07_11_16_6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,625,400);


(lib.CN_07_11_16_7 = function() {
	this.initialize(img.CN_07_11_16_7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,625,400);


(lib.Mosaico = function() {
	this.initialize(img.Mosaico);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,597,400);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.shutterstock_10959565 = function() {
	this.initialize(img.shutterstock_10959565);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,400);


(lib.shutterstock_15013161 = function() {
	this.initialize(img.shutterstock_15013161);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,362,400);


(lib.gris = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
	this.shape.setTransform(30,30);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.btn_zonaInfluencia = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("AukCWQg8AAAAg8IAAizQAAg8A8AAIdJAAQA8AAAAA8IAACzQAAA8g8AAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,255,255,0.6)").s().p("AukCWQg8AAAAg8IAAizQAAg8A8AAIdJAAQA8AAAAA8IAACzQAAA8g8AAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[]},1).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.mc_material = function() {
	this.initialize();

	// Txt
	this.text = new cjs.Text(txt['txt_material'], "bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 361;
	this.text.setTransform(20,15.3);
 var html = createDiv(txt['txt_material'], "Verdana", "20px", '360px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(20, 15-608);
	// Mcs
	this.instance = new lib.Mosaico();
	this.instance.setTransform(294.6,24.9,0.882,0.882);

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-416.5,-198.5,833,397,6);
	this.shape.setTransform(419.5,198.5,1.007,1);

	this.addChild(this.shape,this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,839,397);


(lib.CdP_Tarea = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btntarea'], "bold 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 196;
	this.text.setTransform(-160.1,-259.4+incremento,1,1,0,0,180);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EBHIgj/MhQtAAAIAAjwQAAg8g8AAI9YAAQg8AAAAA8IAADwI+SAAQg+AAAABAMAAABKqQAABBA+AAMCOPAAAQA+AAAAhBMAAAhKqQAAhAg+AAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhHHAosQg+AAAAhBMAAAhKqQAAhAA+AAIeSAAIAAjwQAAg8A8AAIdYAAQA8AAAAA8IAADwMBQtAAAQA+AAAABAMAAABKqQAABBg+AAg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#999999","#FFFFFF"],[0,0.067],0,-261.1,0.1,261.3).s().p("EhHHAosQg+AAAAhBMAAAhKqQAAhAA+AAIeSAAIAAjwQAAg8A8AAIdYAAQA8AAAAA8IAADwMBQtAAAQA+AAAABAMAAABKqQAABBg+AAg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EBHIgj/MhQtAAAIAAjwQAAg8g8AAI9YAAQg8AAAAA8IAADwI+SAAQg+AAAABAMAAABKqQAABBA+AAMCOPAAAQA+AAAAhBMAAAhKqQAAhAg+AAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{color:"#AAAAAA"}}]},1).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-461.4,-260.4,922.9,520.9);


(lib.CdP_Proceso = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btnproceso'], "bold 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 194;
	this.text.setTransform(40,-259.4+incremento,1,1,0,0,180);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EAUtgorI9WAAQg8AAAAA8IAADwMg9iAAAQg+AAAABAMAAABKqQAABBA+AAMCOPAAAQA+AAAAhBMAAAhKqQAAhAg+AAMgxfAAAIAAjwQAAg8g8AAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhHHAosQg+AAAAhBMAAAhKqQAAhAA+AAMA9iAAAIAAjwQAAg8A8AAIdWAAQA8AAAAA8IAADwMAxfAAAQA+AAAABAMAAABKqQAABBg+AAg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#999999","#FFFFFF"],[0,0.067],0.2,-261.2,-0.1,261.4).s().p("EhHHAosQg+AAAAhBMAAAhKqQAAhAA+AAMA9iAAAIAAjwQAAg8A8AAIdWAAQA8AAAAA8IAADwMAxfAAAQA+AAAABAMAAABKqQAABBg+AAg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EAUtgorI9WAAQg8AAAAA8IAADwMg9iAAAQg+AAAABAMAAABKqQAABBA+AAMCOPAAAQA+AAAAhBMAAAhKqQAAhAg+AAMgxfAAAIAAjwQAAg8g8AAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{color:"#AAAAAA"}}]},1).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-461.4,-260.4,922.9,520.9);


(lib.CdP_Introduccion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btnintroduccion'], "bold 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 196;
	this.text.setTransform(-360,-259.4+incremento,1,1,0,0,180);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EBHIgj/Mhv9AAAIAAjwQAAg8g8AAI9YAAQg8AAAAA8MAAABPaQAABBA+AAMCOPAAAQA+AAAAhBMAAAhKqQAAhAg+AAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhHHAosQg+AAAAhBMAAAhPaQAAg8A8AAIdYAAQA8AAAAA8IAADwMBv9AAAQA+AAAABAMAAABKqQAABBg+AAg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#999999","#FFFFFF"],[0,0.067],0.1,-261.2,0,261.3).s().p("EhHHAosQg+AAAAhBMAAAhPaQAAg8A8AAIdYAAQA8AAAAA8IAADwMBv9AAAQA+AAAABAMAAABKqQAABBg+AAg");

	this.shape_3 = new cjs.Shape();
	//this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EBHIgj/Mhv9AAAIAAjwQAAg8g8AAI9YAAQg8AAAAA8MAAABPaQAABBA+AAMCOPAAAQA+AAAAhBMAAAhKqQAAhAg+AAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape},{t:this.shape_1},{t:this.text,p:{color:"#AAAAAA"}}]},1).to({state:[{t:this.shape},{t:this.shape_1},{t:this.shape_2},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-461.4,-260.4,922.9,520.9);

(lib.CdP_Introduccionb = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	
this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EBHIgj/Mhv9AAAIAAjwQAAg8g8AAI9YAAQg8AAAAA8MAAABPaQAABBA+AAMCOPAAAQA+AAAAhBMAAAhKqQAAhAg+AAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhHHAosQg+AAAAhBMAAAhPaQAAg8A8AAIdYAAQA8AAAAA8IAADwMBv9AAAQA+AAAABAMAAABKqQAABBg+AAg");
        
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EBHIgj/Mhv9AAAIAAjwQAAg8g8AAI9YAAQg8AAAAA8MAAABPaQAABBA+AAMCOPAAAQA+AAAAhBMAAAhKqQAAhAg+AAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_3},{t:this.shape_1},{t:this.shape}]},1).wait(1));
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-461.4,-260.4,922.9,520.9);

(lib.CdP_Conclusion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btnconclusion'], "bold 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 196;
	this.text.setTransform(236.3,-260.5+incremento,1,1,0,0,180);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EAVpgnvIAADwMhcwAAAQg+AAAABAMAAABKqQAABBA+AAMCOPAAAQA+AAAAhBMAAAhKqQAAhAg+AAIyPAAIAAjwQAAg8g8AAI9YAAQg8AAAAA8g");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhHHAosQg+AAAAhBMAAAhKqQAAhAA+AAMBcwAAAIAAjwQAAg8A8AAIdYAAQA8AAAAA8IAADwISPAAQA+AAAABAMAAABKqQAABBg+AAg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#999999","#FFFFFF"],[0,0.067],0,-261.2,0.2,261.3).s().p("EhHHAosQg+AAAAhBMAAAhKqQAAhAA+AAMBcwAAAIAAjwQAAg8A8AAIdYAAQA8AAAAA8IAADwISPAAQA+AAAABAMAAABKqQAABBg+AAg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EAVpgnvIAADwMhcwAAAQg+AAAABAMAAABKqQAABBA+AAMCOPAAAQA+AAAAhBMAAAhKqQAAhAg+AAIyPAAIAAjwQAAg8g8AAI9YAAQg8AAAAA8g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{color:"#AAAAAA"}}]},1).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-461.4,-260.5,922.9,521);


(lib.mc_Procedimiento = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text(txt['txt_ptocedimiento_'+(startPosition+1)], "bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 805;
	this.text.setTransform(16,11.3);
 var html = createDiv(txt['txt_ptocedimiento_'+(startPosition+1)], "Verdana", "20px", '770px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(16, 11-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{text:txt['txt_ptocedimiento_1'],lineWidth:805}}]}).to({state:[{t:this.text,p:{text:txt['txt_ptocedimiento_2'],lineWidth:803}}]},1).to({state:[{t:this.text,p:{text:txt['txt_ptocedimiento_3'],lineWidth:801}}]},1).to({state:[{t:this.text,p:{text:txt['txt_ptocedimiento_4'],lineWidth:810}}]},1).to({state:[{t:this.text,p:{text:txt['txt_ptocedimiento_5'],lineWidth:730}}]},1).to({state:[{t:this.text,p:{text:txt['txt_ptocedimiento_6'],lineWidth:811}}]},1).to({state:[{t:this.text,p:{text:txt['txt_ptocedimiento_7'],lineWidth:810}}]},1).to({state:[{t:this.text,p:{text:"txt['txt_ptocedimiento_8",lineWidth:666}}]},1).wait(1));

	// Capa 5
	this.instance = new lib.CN_07_11_16_0();
	this.instance.setTransform(167.7,55,0.803,0.803);

	this.instance_1 = new lib.CN_07_11_16_1();
	this.instance_1.setTransform(167.7,55,0.803,0.803);

	this.instance_2 = new lib.CN_07_11_16_2();
	this.instance_2.setTransform(167.7,55,0.803,0.803);

	this.instance_3 = new lib.CN_07_11_16_3();
	this.instance_3.setTransform(167.7,55,0.803,0.803);

	this.instance_4 = new lib.CN_07_11_16_4();
	this.instance_4.setTransform(167.7,55,0.803,0.803);

	this.instance_5 = new lib.CN_07_11_16_5();
	this.instance_5.setTransform(167.7,55,0.803,0.803);

	this.instance_6 = new lib.CN_07_11_16_6();
	this.instance_6.setTransform(167.7,55,0.803,0.803);

	this.instance_7 = new lib.CN_07_11_16_7();
	this.instance_7.setTransform(167.7,55,0.803,0.803);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).wait(1));

	// Capa 1
	this.btn_siguiente = new lib.btn_siguiente();
	this.btn_siguiente.setTransform(66.4,374.5);
	new cjs.ButtonHelper(this.btn_siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-416.5,-198.5,833,397,6);
	this.shape.setTransform(419.5,198.5,1.007,1);

	this.btn_anterior = new lib.btn_anterior();
	this.btn_anterior.setTransform(22.7,374.4);
	new cjs.ButtonHelper(this.btn_anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.btn_siguiente}]}).to({state:[{t:this.shape},{t:this.btn_anterior},{t:this.btn_siguiente}]},1).to({state:[{t:this.shape},{t:this.btn_anterior},{t:this.btn_siguiente}]},1).to({state:[{t:this.shape},{t:this.btn_anterior},{t:this.btn_siguiente}]},1).to({state:[{t:this.shape},{t:this.btn_anterior},{t:this.btn_siguiente}]},1).to({state:[{t:this.shape},{t:this.btn_anterior},{t:this.btn_siguiente}]},1).to({state:[{t:this.shape},{t:this.btn_anterior},{t:this.btn_siguiente}]},1).to({state:[{t:this.shape},{t:this.btn_anterior}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,839,397);


(lib.mc_preguntas = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 3
	this.text = new cjs.Text(txt['txt_preguntas_1'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 805;
	this.text.setTransform(418.5,11.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{text:txt['txt_preguntas_1']}}]}).to({state:[{t:this.text,p:{text:txt['txt_preguntas_2']}}]},1).wait(1));

	// Capa 2
	this.instance = new lib.shutterstock_10959565();
	this.instance.setTransform(193.5,56.9,0.752,0.752);

	this.instance_1 = new lib.shutterstock_15013161();
	this.instance_1.setTransform(281.9,56.9,0.752,0.752);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	// Capa 1
	this.btn_siguiente = new lib.btn_siguiente();
	this.btn_siguiente.setTransform(66.4,374.5);
	new cjs.ButtonHelper(this.btn_siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-416.5,-198.5,833,397,6);
	this.shape.setTransform(419.5,198.5,1.007,1);

	this.btn_anterior = new lib.btn_anterior();
	this.btn_anterior.setTransform(22.7,374.4);
	new cjs.ButtonHelper(this.btn_anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.btn_siguiente}]}).to({state:[{t:this.shape},{t:this.btn_anterior}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,839,397);


(lib.mc_Objetivo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Txts
        if(startPosition==0){
	this.text = new cjs.Text(txt['titulo_Objetivo'], "31px Georgia");
	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.lineWidth = 802;
	this.text.setTransform(417,11.3);
    }
    else{
 var html = createDiv(txt['txt_objetivo'], "Verdana", "20px", '440px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(17, 11-608);
}
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).to({state:[{t:this.text}]},1).wait(1));

	// Mcs
	this.instance = new lib._00075F01();
	this.instance.setTransform(317.5,70,0.78,0.78);

	this.instance_1 = new lib.shutterstock_10959565();
	this.instance_1.setTransform(817.3,18.3,0.919,0.919,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	// Capa 1
	this.btn_siguiente = new lib.btn_siguiente();
	this.btn_siguiente.setTransform(66.4,374.5);
	new cjs.ButtonHelper(this.btn_siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-416.5,-198.5,833,397,6);
	this.shape.setTransform(419.5,198.5,1.007,1);

	this.btn_anterior = new lib.btn_anterior();
	this.btn_anterior.setTransform(22.7,374.4);
	new cjs.ButtonHelper(this.btn_anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("EBAmge/MiBLAAAQg8AAAAA8MAAAA8HQAAA8A8AAMCBLAAAQA8AAAAg8MAAAg8HQAAg8g8AAg");
	this.shape_1.setTransform(419.5,198.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("EhAlAfAQg8AAAAg8MAAAg8HQAAg8A8AAMCBLAAAQA8AAAAA8MAAAA8HQAAA8g8AAg");
	this.shape_2.setTransform(419.5,198.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.btn_siguiente}]}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.btn_anterior}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,839,397);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}