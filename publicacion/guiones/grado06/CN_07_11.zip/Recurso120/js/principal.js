(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
       this.text = new cjs.Text(txt['titulo'], "31px Georgia");
	this.text.textAlign = "center";
	this.text.lineHeight = 36;
	this.text.lineWidth = 781;
	this.text.setTransform(473.5,67);
this.btn_mezclas = new lib.btn_mezclas();
	this.btn_mezclas.setTransform(274.4,482.3,1,1,0,0,0,192.5,15);
	new cjs.ButtonHelper(this.btn_mezclas, 0, 1, 2, false, new lib.btn_mezclas(), 3);

	this.btn_atomo = new lib.btn_atomo();
	this.btn_atomo.setTransform(199.4,373.9,1,1,0,0,0,117.5,15);
	new cjs.ButtonHelper(this.btn_atomo, 0, 1, 2, false, new lib.btn_atomo(), 3);

	this.btn_estados = new lib.btn_estados();
	this.btn_estados.setTransform(199.4,266,1,1,0,0,0,117.5,15);
	new cjs.ButtonHelper(this.btn_estados, 0, 1, 2, false, new lib.btn_estados(), 3);
this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-394.5,-42.5,789,85,20);
	this.shape.setTransform(475.5,85.5);

	this.instance = new lib._0028O401();

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("EhKNAvgMAAAhe/MCUbAAAMAAABe/g");
	this.shape_1.setTransform(475,304);

    this.btn_estados.on("click", function (evt) {
        putStage(new lib.frame2());
    });
    this.btn_atomo.on("click", function (evt) {
        putStage(new lib.frame4());
    });
    this.btn_mezclas.on("click", function (evt) {
        putStage(new lib.frame5());
    });
    
        this.addChild(this.logo, this.titulo, this.siguiente, this.shape_1,this.instance,this.shape,this.text,this.btn_estados,this.btn_atomo,this.btn_mezclas);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
this.btn_plasma = new lib.btn_plasma();
	this.btn_plasma.setTransform(640.9,401.5,1,1,0,0,0,136.5,95.7);
	new cjs.ButtonHelper(this.btn_plasma, 0, 1, 1);

	this.btn_gas = new lib.btn_gas();
	this.btn_gas.setTransform(308.3,401,1,1,0,0,0,136.5,96.2);
	new cjs.ButtonHelper(this.btn_gas, 0, 1, 1);

	this.btn_liquido = new lib.btn_liquido();
	this.btn_liquido.setTransform(640.9,189.1,1,1,0,0,0,136.5,96);
	new cjs.ButtonHelper(this.btn_liquido, 0, 1, 1);

	this.btn_solido = new lib.btn_solido();
	this.btn_solido.setTransform(308.3,188.6,1,1,0,0,0,136.5,96.5);
	new cjs.ButtonHelper(this.btn_solido, 0, 1, 1);
  this.btn_solido.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
  this.btn_liquido.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
  this.btn_gas.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
  this.btn_plasma.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });

  this.practica = new lib.btn_practica(txt['btnpractica']);
        this.practica.setTransform(827, 547 , 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
    this.practica.on("click", function (evt) {
            putStage(new lib.frame3());
        });
	this.text = new cjs.Text(txt['tit_estados'], "23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 28;
	this.text.lineWidth = 784;
	this.text.setTransform(473.6,27.2);

	this.text_1 = new cjs.Text(txt['btn_select'], "bold 16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 21;
	this.text_1.lineWidth = 235;
	this.text_1.setTransform(472.9,516.9+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("Ay9CbIAAk1MAl7AAAIAAE1g");
	this.shape.setTransform(475.3,529.6,0.988,0.965);
      
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.shape,this.text_1,this.text,this.practica,this.btn_solido,this.btn_liquido,this.btn_gas,this.btn_plasma);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit_solid']);
        this.instance = new lib.popup_solido();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);

      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
 (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit_liquid']);
        this.instance = new lib.popup_liquido();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);

      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
 (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit_gas']);
        this.instance = new lib.popup_gas();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);

      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
 (lib.frame2_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit_plasma']);
        this.instance = new lib.popup_plasma();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);

      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
      this.instance = new lib.popup_practica("single",0);
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);
  this.practica = new lib.btn_practica(txt['btnsolucion']);
        this.practica.setTransform(827, 547 , 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
  

        this.practica.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
       
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });
       

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.cerrar,this.instance,this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
          this.instance = new lib.popup_practica("single",1);
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
       
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        	this.btn_rutherford = new lib.btn_rutherford();
	this.btn_rutherford.setTransform(157.5,380.1,1,1,0,0,0,112.5,15);
	new cjs.ButtonHelper(this.btn_rutherford, 0, 1, 2, false, new lib.btn_rutherford(), 3);

	this.btn_bohr = new lib.btn_bohr();
	this.btn_bohr.setTransform(157.5,461.4,1,1,0,0,0,112.5,15);
	new cjs.ButtonHelper(this.btn_bohr, 0, 1, 2, false, new lib.btn_bohr(), 3);

	this.btn_thomson = new lib.btn_thomson();
	this.btn_thomson.setTransform(157.5,299,1,1,0,0,0,112.5,15);
	new cjs.ButtonHelper(this.btn_thomson, 0, 1, 2, false, new lib.btn_thomson(), 3);

	this.btn_dalton = new lib.btn_dalton();
	this.btn_dalton.setTransform(157.5,217.9,1,1,0,0,0,112.5,15);
	new cjs.ButtonHelper(this.btn_dalton, 0, 1, 2, false, new lib.btn_dalton(), 3);
 this.btn_dalton.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
 this.btn_thomson.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
 this.btn_bohr.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });
 this.btn_rutherford.on("click", function (evt) {
            putStage(new lib.frame4_4());
        });

	this.text = new cjs.Text(txt['tit_modelos'], "23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 28;
	this.text.lineWidth = 784;
	this.text.setTransform(473.6,67.2);

	
   var html = createDiv(txt['txt_modelos'], "Verdana", "20px", '290px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(308, 153-608);
 
	this.instance = new lib._000S7W01_nombres();
	this.instance.setTransform(597.5,237.1);

        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.instance,this.text_1,this.text,this.btn_dalton,this.btn_thomson,this.btn_bohr,this.btn_rutherford);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['txt_dalton']);

         this.instance = new lib.popup_dalton();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
 (lib.frame4_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['btn_thomson']);
    this.instance = new lib.popup_thomson();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);

      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
 (lib.frame4_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['btn_ruther']);

        this.instance = new lib.popup_rutherford();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);
  
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
 (lib.frame4_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['btn_bohr']);

         this.instance = new lib.popup_bohr();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);
 
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit_tecsep']);
this.btn_tecnicas = new lib.btn_tecnicas();
	this.btn_tecnicas.setTransform(792,570.6,1,1,0,0,0,115,15);
	new cjs.ButtonHelper(this.btn_tecnicas, 0, 1, 2, false, new lib.btn_tecnicas(), 3);

	this.text = new cjs.Text("Mezcla:\n\n• Formada por dos o más componentes que\nse pueden separar por procesos físicos.\n\n• Homogéneas si no se distinguen sus\ncomponentes.\n\n• Heterogéneas si sus componentes se\ndistinguen a simple vista.", "bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 463;
	this.text.setTransform(419.8,207.7);
   var html = createDiv(txt['txt_tecsep'], "Verdana", "20px", '470px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(419, 188-608);
 
	this.instance = new lib._001SHO01();
	this.instance.setTransform(82.1,132.1);
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.btn_tecnicas.on("click", function (evt) {
            putStage(new lib.frame6());
        });

        this.addChild(this.logo, this.titulo, this.home, this.instance,this.text,this.btn_tecnicas);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
     this.btn_decantacion = new lib.btn_decantacion();
	this.btn_decantacion.setTransform(173.9,413.9,1,1,0,0,0,136,101.5);
	new cjs.ButtonHelper(this.btn_decantacion, 0, 1, 2, false, new lib.btn_decantacion(), 3);

	this.btn_centrifugacion = new lib.btn_centrifugacion();
	this.btn_centrifugacion.setTransform(475.9,406.4,1,1,0,0,0,136,94);
	new cjs.ButtonHelper(this.btn_centrifugacion, 0, 1, 2, false, new lib.btn_centrifugacion(), 3);

	this.btn_cromatografia = new lib.btn_cromatografia();
	this.btn_cromatografia.setTransform(776.9,413.9,1,1,0,0,0,136,101.5);
	new cjs.ButtonHelper(this.btn_cromatografia, 0, 1, 2, false, new lib.btn_cromatografia(), 3);

	this.btn_destilacion = new lib.btn_destilacion();
	this.btn_destilacion.setTransform(173,195.4,1,1,0,0,0,136,99.9);
	new cjs.ButtonHelper(this.btn_destilacion, 0, 1, 2, false, new lib.btn_destilacion(), 3);

	this.btn_evaporacion = new lib.btn_evaporacion();
	this.btn_evaporacion.setTransform(475.9,194.8,1,1,0,0,0,136,99.3);
	new cjs.ButtonHelper(this.btn_evaporacion, 0, 1, 2, false, new lib.btn_evaporacion(), 3);

	this.btn_filtracion = new lib.btn_filtracion();
	this.btn_filtracion.setTransform(776.9,194.7,1,1,0,0,0,136,99.2);
	new cjs.ButtonHelper(this.btn_filtracion, 0, 1, 2, false, new lib.btn_filtracion(), 3);
 this.btn_destilacion.on("click", function (evt) {
            putStage(new lib.frame6_1());
        });
this.btn_evaporacion.on("click", function (evt) {
            putStage(new lib.frame6_2());
        });
this.btn_filtracion.on("click", function (evt) {
            putStage(new lib.frame6_3());
        });
this.btn_decantacion.on("click", function (evt) {
            putStage(new lib.frame6_4());
        });
this.btn_centrifugacion.on("click", function (evt) {
            putStage(new lib.frame6_5());
        });
this.btn_cromatografia.on("click", function (evt) {
            putStage(new lib.frame6_6());
        });

	this.text = new cjs.Text(txt['tit_tecsep_1'], "23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 25;
	this.text.lineWidth = 783;
	this.text.setTransform(473.7,32.1);

	this.text_1 = new cjs.Text(txt['btn_select'], "bold 16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 21;
	this.text_1.lineWidth = 235;
	this.text_1.setTransform(473.4,545.9+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("Ay9CbIAAk1MAl7AAAIAAE1g");
	this.shape.setTransform(475.8,558.6,0.988,0.965);

        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame5());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.shape,this.text_1,this.text,this.btn_filtracion,this.btn_evaporacion,this.btn_destilacion,this.btn_cromatografia,this.btn_centrifugacion,this.btn_decantacion);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame6_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['txt_dest']);
        this.instance = new lib.popup_destilacion();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);

        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame6_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['txt_evap']);

              this.instance = new lib.popup_evaporacion();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);
  
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame6_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['txt_filt']);
       this.instance = new lib.popup_filtracion();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);
 
        
       this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame6_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['txt_decant']);
         this.instance = new lib.popup_decantacion();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);
  
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame6_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['txt_centr']);
         this.instance = new lib.popup_centrifugacion();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);
  
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame6_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['txt_cromo']);
         this.instance = new lib.popup_cromatografia();
	this.instance.setTransform(475.3,303.4,1,1,0,0,0,475,304);
  
        
         this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    
    
    
    
// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

     function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 548,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 548,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 548,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 548,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 548,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 548,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 530,1.15,1.15);
        else
            escena.informacion.setTransform(217, 530,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 530,1.15,1.15);
        else
            escena.informacion.setTransform(217, 530,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(888, 55, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(888, 55, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 548, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 548, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
    
   //Simbolillos
   
   (lib._000S7W01_nombres = function() {
	this.initialize(img._000S7W01_nombres);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,310,291);


(lib._0014IL01 = function() {
	this.initialize(img._0014IL01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,273,161);


(lib._0014IL01_1 = function() {
	this.initialize(img._0014IL01_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,251,376);


(lib._0017W101 = function() {
	this.initialize(img._0017W101);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,273,161);


(lib._0017W101_1 = function() {
	this.initialize(img._0017W101_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,251,376);


(lib._001SHO01 = function() {
	this.initialize(img._001SHO01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,257,376);


(lib._0028O401 = function() {
	this.initialize(img._0028O401);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib._002AD301 = function() {
	this.initialize(img._002AD301);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,273,163);


(lib._002AD301_1 = function() {
	this.initialize(img._002AD301_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,251,376);


(lib._101198713 = function() {
	this.initialize(img._101198713);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,273,161);


(lib._101198713_1 = function() {
	this.initialize(img._101198713_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,244,376);


(lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,607,297);


(lib.Mapadebits10 = function() {
	this.initialize(img.Mapadebits10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,372,450);


(lib.Mapadebits11 = function() {
	this.initialize(img.Mapadebits11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,241,177);


(lib.Mapadebits12 = function() {
	this.initialize(img.Mapadebits12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,273,143);


(lib.Mapadebits13 = function() {
	this.initialize(img.Mapadebits13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,263,196);


(lib.Mapadebits14 = function() {
	this.initialize(img.Mapadebits14);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,260,159);


(lib.Mapadebits15 = function() {
	this.initialize(img.Mapadebits15);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,85,203);


(lib.Mapadebits16 = function() {
	this.initialize(img.Mapadebits16);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,165,200);


(lib.Mapadebits2 = function() {
	this.initialize(img.Mapadebits2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,469,235);


(lib.Mapadebits3 = function() {
	this.initialize(img.Mapadebits3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,309,244);


(lib.Mapadebits4 = function() {
	this.initialize(img.Mapadebits4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,268,268);


(lib.Mapadebits5 = function() {
	this.initialize(img.Mapadebits5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,337,412);


(lib.Mapadebits6 = function() {
	this.initialize(img.Mapadebits6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,429,377);


(lib.Mapadebits7 = function() {
	this.initialize(img.Mapadebits7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,173,453);


(lib.Mapadebits8 = function() {
	this.initialize(img.Mapadebits8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,497,330);


(lib.Mapadebits9 = function() {
	this.initialize(img.Mapadebits9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,190,456);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.btn_solucion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btnsolucion'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(7.5,-14.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape.setTransform(9.3,-3,1.096,1.262);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_1.setTransform(9.3,-3,1.096,1.262);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_2.setTransform(9.3,-3,1.096,1.262);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.6,-18.1,130,30);


(lib.btn_practica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btnpractica'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(7.5,-15.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-50.85,-14.4,101.7,28.8,6);
	this.shape.setTransform(9.4,-2.9,1.278,1.043,0,0,0,0,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-50.85,-14.4,101.7,28.8,6);
	this.shape_1.setTransform(9.4,-2.9,1.278,1.043,0,0,0,0,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-50.85,-14.4,101.7,28.8,6);
	this.shape_2.setTransform(9.4,-2.9,1.278,1.043,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.5,-18.1,130.1,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-2.7,-12.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_1.setTransform(-0.4,5.1,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]}).to({state:[{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:-4.2,y:-14.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.2,-12.8,31,33.1);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_tecnicas = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btntec_separa'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 225;
	this.text.setTransform(112.8,2.4+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-115,-15,230,30,6);
	this.shape.setTransform(115,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#1D1D1B").rr(-115,-15,230,30,6);
	this.shape_1.setTransform(115,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").rr(-115,-15,230,30,6);
	this.shape_2.setTransform(115,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,230,30);


(lib.btn_filtracion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits16();
	this.instance.setTransform(63.2,-1.9);

	this.text = new cjs.Text(txt['btn_filt'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(133.8,177.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AVQM+MgqfAAAIAA57MAqfAAAg");
	this.shape.setTransform(136,83.5,1,1.006);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AI2h4IAADxIxsAAIAAjxg");
	this.shape_1.setTransform(135.9,189.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("Ao2B5IAAjxIRsAAIAADxg");
	this.shape_2.setTransform(135.9,189.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AVSs/IAAZ/MgqjAAAIAA5/g");
	this.shape_3.setTransform(135.9,83.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("A1RNAIAA5/MAqjAAAIAAZ/g");
	this.shape_4.setTransform(135.9,83.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#A5B9C3").ss(0.2,0,0,3.9).p("ABai7QAIADgQAyQgSA3ghBFQgoBVg0BEQgdAugCgB");
	this.shape_5.setTransform(152.7,37.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#1D1D1C").ss(0.3,0,0,3.9).p("ACOD5IigAAAiCgkIgGjZ");
	this.shape_6.setTransform(145,78.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D1D1C").s().p("AgOAQQgFgHAAgJQAAgJAFgGQAGgHAIAAQAKAAAFAHQAFAGAAAJQAAAJgFAHQgFAHgKAAQgIAAgGgHgAgKgLQgDAFAAAGQAAAGADAGQAEAGAGAAQAHAAAEgGQADgGAAgGQAAgGgDgFQgEgHgHABQgGgBgEAHg");
	this.shape_7.setTransform(191.5,103.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D1D1C").s().p("AgOAZQgEgHAAgKQAAgIAEgGQAFgHAJAAQAIAAAFAIIABgBIAAgZIAEAAIABA9IgFAAIAAgGIgBgBQgGAJgHAAQgJAAgFgHgAgMAIQAAATAMAAQANAAAAgTQAAgRgNABQgMgBAAARg");
	this.shape_8.setTransform(186.6,102.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D1D1C").s().p("AgQAFIAAgaIAFAAIAAAaQAAAMALAAQALAAAAgPIAAgXIAGAAIAAAqIgFAAIgBgHQgFAJgGAAQgQgBAAgRg");
	this.shape_9.setTransform(181.8,103.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1D1D1C").s().p("AgMAXIAAABIgBAGIgFAAIAAg9IAGAAIAAAaQAEgIAJAAQAJAAAFAHQAEAGAAAIQAAAJgEAIQgFAHgJAAQgIAAgFgJgAgMAIQAAATANAAQAMAAAAgTQAAgRgNABQgMgBAAARg");
	this.shape_10.setTransform(176.9,102.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1D1D1C").s().p("AAaAWIAAgaQAAgNgLAAQgMAAAAAQIAAAXIgEAAIAAgaQAAgNgLAAQgOAAAAAQIAAAXIgEAAIgBgqIAFAAIAAAGIABABQAEgIAKAAQALAAABAJQAHgJAIAAQAQAAAAASIAAAZg");
	this.shape_11.setTransform(170.5,103.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1D1D1C").s().p("AgOAQQgFgHABgJQAAgIAEgHQAGgHAIAAQAUAAAAAXIghAAQAAARAOAAQAEAAAEgDQAEgDAAgEIAGAAQgFAPgOAAQgJAAgFgHgAANgDQgBgOgMAAQgLAAgCAOIAaAAIAAAAg");
	this.shape_12.setTransform(164.1,103.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1D1D1C").s().p("AgBAfIAAg9IADAAIAAA9g");
	this.shape_13.setTransform(120.1,44.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1D1D1C").s().p("AgOAQQgFgGAAgKQAAgIAGgHQAFgHAIAAQAUAAAAAWIghAAQABASANAAQAKAAACgKIAGAAQgFAPgOAAQgIAAgGgHgAANgCQAAgPgNAAQgLAAgBAPIAZAAIAAAAg");
	this.shape_14.setTransform(116.7,45.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1D1D1C").s().p("AgSAfIAAg7IAGAAIAAAGQAFgIAIAAQAJAAAFAIQAEAGAAAKQAAAHgEAHQgFAHgJAAQgIAAgFgIIAAAYgAgMgHQAAARAMAAQANAAABgRQAAgSgOAAQgMAAAAASg");
	this.shape_15.setTransform(111.9,46);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#1D1D1C").s().p("AgMATQgEgDAAgHQAAgJAJgBQAEgCAEAAIAKgBIAAgDQAAgKgKAAQgIAAgBAIIgGAAQACgNANAAQAQAAAAAPIAAAcIgGAAIAAgGIgBABQgCAHgJAAQgGAAgFgEgAgCAAQgIACAAAHQAAAJAKAAQAMAAgBgSIgNAAg");
	this.shape_16.setTransform(107,45.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#1D1D1C").s().p("AgSAfIAAg7IAFAAIABAGQAFgIAIAAQAJAAAFAIQAEAGAAAKQAAAHgEAHQgFAHgJAAQgIAAgFgIIAAAYgAgMgHQAAARANAAQAMAAAAgRQAAgSgNAAQgMAAAAASg");
	this.shape_17.setTransform(102.5,46);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1D1D1C").s().p("AgOAQQgFgHAAgJQAAgIAFgHQAGgHAIAAQAJAAAGAHQAFAHAAAIQAAAJgFAHQgGAHgJAAQgIAAgGgHgAgKgLQgDAGAAAFQAAAHADAFQAEAGAGAAQAHAAAEgGQAEgFgBgHQABgGgEgFQgEgGgHAAQgGAAgEAGg");
	this.shape_18.setTransform(127.1,54.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1D1D1C").s().p("AgJAWIAAgqIAFAAIABAHQACgIAGAAIAFAAIAAAFIgDAAQgKAAAAAOIAAAYg");
	this.shape_19.setTransform(123.5,54.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#1D1D1C").s().p("AgBAYIgBgJIAAgaIgJAAIAAgFIAJAAIAAgJIADgCIAAALIAKAAIAAAFIgKAAIAAAcQAAAGAHAAIAEAAIAAAEIgFABQgHAAgBgEg");
	this.shape_20.setTransform(120.3,53.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#1D1D1C").s().p("AgBAfIAAg9IADAAIAAA9g");
	this.shape_21.setTransform(117.9,53.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#1D1D1C").s().p("AgBAfIAAgqIADAAIAAAqgAgCgYIAAgGIAFAAIAAAGg");
	this.shape_22.setTransform(116,53.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#1D1D1C").s().p("AgCAgIAAgmIgJAAIAAgFIAJAAIAAgJQAAgLAJAAIAFABIAAAEIgDAAQgFAAgCACQgBACABAGIAAAFIAKAAIAAAFIgKAAIAAAmg");
	this.shape_23.setTransform(113.5,53.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#1D1D1C").s().p("AgOAQQgFgGAAgKQABgIAEgHQAGgHAIAAQATAAABAWIghAAQABASANAAQAKAAACgLIAGAAQgEAQgPAAQgJAAgFgHgAAOgCQgBgPgNAAQgFAAgDAFQgEAEgBAGIAbAAIAAAAg");
	this.shape_24.setTransform(107.3,54.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#1D1D1C").s().p("AgOAZQgEgHAAgKQAAgIAEgGQAFgHAJAAQAJAAAEAIIAAgaIAGAAIAAA+IgFAAIgBgHIAAAAQgFAIgIAAQgJAAgFgHgAgMAHQAAAUAMAAQANAAAAgUQAAgPgNAAQgMAAAAAPg");
	this.shape_25.setTransform(102.4,53.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#7D9FAB").ss(0.2,0,0,3.9).p("AjagPQAAALBAAHQBBAIBZAAQBbAABAgIQBAgHAAgL");
	this.shape_26.setTransform(142.9,69.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAMAAIgXAA");
	this.shape_27.setTransform(77.9,74.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AgLAAIAXAA");
	this.shape_28.setTransform(77.9,79.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AgSAAIAFABQAMAAAHgBQAJgCAAgD");
	this.shape_29.setTransform(87.3,1.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AgKAFQAGACAGAAAAagEIgTgBQgKAAgJABQgJADAAAB");
	this.shape_30.setTransform(85.1,0.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AADAFQAAgDgJgC");
	this.shape_31.setTransform(88.4,0.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AgcgEQAAAFAcAAQAdAAAAgF");
	this.shape_32.setTransform(85.8,72.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAFjIAArF");
	this.shape_33.setTransform(88.8,36.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAliIAALF");
	this.shape_34.setTransform(82.9,36.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AgoAFIALAAQAcAAASgEQATgDAAgH");
	this.shape_35.setTransform(88.8,73.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AgdAMQARADAMABAA3gLQgTgEgZAAQgZAAgUAFQgUAFAAAF");
	this.shape_36.setTransform(84.6,72);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAKAIQAAgHgWgD");
	this.shape_37.setTransform(91.4,71.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AhCgJQAAAHAUACQAUAFAaAAQAbAAAUgFQAUgCAAgH");
	this.shape_38.setTransform(85.8,81.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAArIAAhV");
	this.shape_39.setTransform(92.5,76.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAgqIAABV");
	this.shape_40.setTransform(79.1,76.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#EAE8E9").ss(0.9,1,0,3.9).p("ACzAAIllAA");
	this.shape_41.setTransform(105,75.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#E5E3E3").ss(0.9,1,0,3.9).p("ACyAAIljAA");
	this.shape_42.setTransform(105,75.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#E0DEDE").ss(1,1,0,3.9).p("ACyAAIlkAA");
	this.shape_43.setTransform(105,75.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#DCD9DA").ss(1,1,0,3.9).p("ACzAAIlkAA");
	this.shape_44.setTransform(104.9,75.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#D7D4D5").ss(1.1,1,0,3.9).p("ACyAAIljAA");
	this.shape_45.setTransform(104.9,75.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#D2D0D0").ss(1.2,1,0,3.9).p("ACyAAIljAA");
	this.shape_46.setTransform(104.8,75.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#CECBCB").ss(1.2,1,0,3.9).p("ACyAAIljAA");
	this.shape_47.setTransform(104.8,75.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#C9C6C7").ss(1.3,1,0,3.9).p("ACyAAIljAA");
	this.shape_48.setTransform(104.8,75.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#C5C2C2").ss(1.3,1,0,3.9).p("ACyAAIljAA");
	this.shape_49.setTransform(104.7,75.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#C0BDBD").ss(1.4,1,0,3.9).p("ACyAAIljAA");
	this.shape_50.setTransform(104.7,75.8);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#BBB8B8").ss(1.5,1,0,3.9).p("ACyAAIljAA");
	this.shape_51.setTransform(104.6,75.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#B6B3B3").ss(1.5,1,0,3.9).p("ACxAAIliAA");
	this.shape_52.setTransform(104.6,75.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#B1AFAF").ss(1.6,1,0,3.9).p("ACyAAIljAA");
	this.shape_53.setTransform(104.6,75.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#ACAAAA").ss(1.7,1,0,3.9).p("ACyAAIljAA");
	this.shape_54.setTransform(104.5,75.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#A8A6A6").ss(1.7,1,0,3.9).p("ACxAAIlhAA");
	this.shape_55.setTransform(104.5,75.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#A3A1A1").ss(1.8,1,0,3.9).p("ACxAAIlhAA");
	this.shape_56.setTransform(104.4,75.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#9E9D9D").ss(1.8,1,0,3.9).p("ACxAAIlhAA");
	this.shape_57.setTransform(104.4,75.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#9A9898").ss(1.9,1,0,3.9).p("ACxAAIlhAA");
	this.shape_58.setTransform(104.4,75.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#959494").ss(2,1,0,3.9).p("ACxAAIlhAA");
	this.shape_59.setTransform(104.3,75.9);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#90908F").ss(2,1,0,3.9).p("ACxAAIlhAA");
	this.shape_60.setTransform(104.3,75.9);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#8B8B8B").ss(2.1,1,0,3.9).p("ACxAAIlhAA");
	this.shape_61.setTransform(104.2,75.9);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#868787").ss(2.1,1,0,3.9).p("ACwAAIlfAA");
	this.shape_62.setTransform(104.2,75.9);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#818383").ss(2.2,1,0,3.9).p("ACxAAIlgAA");
	this.shape_63.setTransform(104.2,75.9);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#7D7F7F").ss(2.3,1,0,3.9).p("ACwAAIlfAA");
	this.shape_64.setTransform(104.1,75.9);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#EAE8E9").ss(0.9,1,0,3.9).p("AjFgMQAAAMA6AFQA6AIBRAAQBSAAA7gIQA6gFAAgM");
	this.shape_65.setTransform(142.9,76.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#E5E3E3").ss(0.9,1,0,3.9).p("AjFgMQAAALA6AGQA7AHBQAAQBSAAA7gHQA6gGAAgL");
	this.shape_66.setTransform(142.9,76.9);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#E0DEDE").ss(0.9,1,0,3.9).p("AjFgMQAAALA6AGQA6AHBRAAQBSAAA7gHQA6gGAAgL");
	this.shape_67.setTransform(142.9,76.9);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#DCD9DA").ss(1,1,0,3.9).p("AjFgMQAAALA6AGQA6AHBRAAQBSAAA7gHQA6gGAAgL");
	this.shape_68.setTransform(142.9,76.9);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#D7D4D5").ss(1,1,0,3.9).p("AjFgLQAAAKA6AGQA7AIBQAAQBSAAA7gIQA6gGAAgK");
	this.shape_69.setTransform(142.9,77);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#D2D0D0").ss(1.1,1,0,3.9).p("AjFgLQAAALA6AFQA6AIBRAAQBSAAA7gIQA6gFAAgL");
	this.shape_70.setTransform(142.9,77);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#CECBCB").ss(1.1,1,0,3.9).p("AjFgMQAAALA6AGQA6AIBRAAQBSAAA7gIQA6gGAAgL");
	this.shape_71.setTransform(142.9,77);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#C9C6C7").ss(1.2,1,0,3.9).p("AjFgMQAAAMA6AFQA6AIBRAAQBSAAA7gIQA6gFAAgM");
	this.shape_72.setTransform(142.9,77);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#C5C2C2").ss(1.2,1,0,3.9).p("AjFgMQAAAMA6AFQA6AIBRAAQBSAAA7gIQA6gFAAgM");
	this.shape_73.setTransform(142.9,77);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#C0BDBD").ss(1.3,1,0,3.9).p("AjFgMQAAALA6AGQA6AIBRAAQBSAAA7gIQA6gGAAgL");
	this.shape_74.setTransform(142.9,77);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#BBB8B8").ss(1.3,1,0,3.9).p("AjFgMQAAAMA6AFQA6AIBRAAQBSAAA7gIQA6gFAAgM");
	this.shape_75.setTransform(142.9,77.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#B6B3B3").ss(1.4,1,0,3.9).p("AjFgMQAAAMA6AFQA6AIBRAAQBSAAA7gIQA6gFAAgM");
	this.shape_76.setTransform(142.9,77.1);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#B1AFAF").ss(1.4,1,0,3.9).p("AjFgMQAAALA6AGQA7AIBQAAQBSAAA7gIQA6gGAAgL");
	this.shape_77.setTransform(142.9,77.1);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#ACAAAA").ss(1.5,1,0,3.9).p("AjFgMQAAAMA6AFQA6AIBRAAQBSAAA7gIQA6gFAAgM");
	this.shape_78.setTransform(142.9,77.1);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#A8A6A6").ss(1.5,1,0,3.9).p("AjFgMQAAAMA6AFQA6AIBRAAQBSAAA7gIQA6gFAAgM");
	this.shape_79.setTransform(142.9,77.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#A3A1A1").ss(1.6,1,0,3.9).p("AjFgMQAAALA6AGQA7AHBQAAQBSAAA7gHQA6gGAAgL");
	this.shape_80.setTransform(142.9,77.2);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#9E9D9D").ss(1.6,1,0,3.9).p("AjFgMQAAALA6AGQA6AHBRAAQBSAAA7gHQA6gGAAgL");
	this.shape_81.setTransform(142.9,77.2);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#9A9898").ss(1.7,1,0,3.9).p("AjFgMQAAALA6AGQA6AHBRAAQBSAAA7gHQA6gGAAgL");
	this.shape_82.setTransform(142.9,77.2);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#959494").ss(1.7,1,0,3.9).p("AjFgLQAAAKA6AGQA7AIBQAAQBSAAA7gIQA6gGAAgK");
	this.shape_83.setTransform(142.9,77.2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#90908F").ss(1.8,1,0,3.9).p("AjFgLQAAALA6AFQA6AIBRAAQBSAAA7gIQA6gFAAgL");
	this.shape_84.setTransform(142.9,77.2);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#8B8B8B").ss(1.8,1,0,3.9).p("AjFgMQAAALA6AGQA6AIBRAAQBSAAA7gIQA6gGAAgL");
	this.shape_85.setTransform(142.9,77.2);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#868787").ss(1.9,1,0,3.9).p("AjFgMQAAAMA6AFQA6AIBRAAQBSAAA7gIQA6gFAAgM");
	this.shape_86.setTransform(142.9,77.3);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#818383").ss(1.9,1,0,3.9).p("AjFgMQAAAMA6AFQA6AIBRAAQBSAAA7gIQA6gFAAgM");
	this.shape_87.setTransform(142.9,77.3);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#7D7F7F").ss(2,1,0,3.9).p("AjFgMQAAALA6AGQA6AIBRAAQBSAAA7gIQA6gGAAgL");
	this.shape_88.setTransform(142.9,77.3);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AgcgEQAAAFAcAAQAdAAAAgF");
	this.shape_89.setTransform(85.8,156.2);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAF/IAAr9");
	this.shape_90.setTransform(88.8,117.3);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAl+IAAL9");
	this.shape_91.setTransform(82.9,117.3);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AgEApIAAgLQAAgcAEgSQADgTAHAA");
	this.shape_92.setTransform(75.3,73.8);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AgLAeQgDgRgBgNAAMg2QAEATAAAZQAAAZgFAUQgFAUgGAA");
	this.shape_93.setTransform(76.3,78);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AgHgJQAHAAADAW");
	this.shape_94.setTransform(77.2,71.2);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AAKBDQgHAAgDgUQgEgUAAgbQAAgbAEgTQADgUAHAA");
	this.shape_95.setTransform(71.3,76.8);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AgTAAIAnAA");
	this.shape_96.setTransform(74.3,70.2);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAUAAIgnAA");
	this.shape_97.setTransform(74.3,83.5);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#666D6E").ss(2.8,1,0,3.9).p("AjFgMQAAALA6AGQA6AIBRAAQBSAAA7gIQA6gGAAgL");
	this.shape_98.setTransform(142.9,77.3);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#7D9FAB").ss(0.2,0,0,3.9).p("AjZgLQAAAIA2AGQA8AJBQAAQBiAABWgQQAFgBAcgDQAYgCAAgB");
	this.shape_99.setTransform(155.3,113.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#508796").ss(0.2,0,0,3.9).p("ADZj5IABAAQgBgCgWgCQgbgDgEgBQgggHgqgFQg6gHg3AAQhPAAg9AJQg2AJAAAJQAAAIA2AIQA8AJBQAAQBiAABWgSQAFgBAcgDQAVgCACgBgAjZj5QAAADAAAFQABAGACAAQAGADABAQQAAAIgBARIAAGgQAAAaARAGQAyATBsABQBwACA5gSQALgDAGgMQAFgKAAgLIABloQAAgzA6g/");
	this.shape_100.setTransform(155.3,137.2);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#666D6E").ss(2.8,1,0,3.9).p("AF/ANQAAgMg5gFQg6gIhSAAQhRAAg6AIQg4AFAAAMAgPAKIlvAA");
	this.shape_101.setTransform(124.3,74.8);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AlNAQIAAAxIKbAAIAAgxIgJhQIppAAg");
	this.shape_102.setTransform(99.3,157.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text},{t:this.instance}]}).to({state:[{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape},{t:this.text},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1.9,272,202.8);


(lib.btn_evaporacion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits15();
	this.instance.setTransform(90.1,-1.9);

	this.text = new cjs.Text(txt['btn_evap'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(133.3,177.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AVQM+MgqfAAAIAA57MAqfAAAg");
	this.shape.setTransform(136,83.5,1,1.006);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AI2h4IAADxIxsAAIAAjxg");
	this.shape_1.setTransform(135.9,189.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("Ao2B5IAAjxIRsAAIAADxg");
	this.shape_2.setTransform(135.9,189.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AVSNAMgqjAAAIAA5/MAqjAAAg");
	this.shape_3.setTransform(135.9,82.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("A1RNAIAA5/MAqjAAAIAAZ/g");
	this.shape_4.setTransform(135.9,82.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#7D9FAB").ss(0.2,0,0,3.9).p("AjdgLQAAAIA3AGQA9AJBRAAQBjAABZgPQAEgBAdgDQAZgDgBgB");
	this.shape_5.setTransform(150.6,32);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#508796").ss(0.2,0,0,3.9).p("AgYkZQhQAAg9AKQg4AIAAAJQAAABAAAAQAEAIA0AIQA8AJBRAAQBjAABZgSQAFgBAdgDQAUgCADgBQABgBAAAAQgBgBgXgDQgbgCgEgBQgggHgrgGQg8gHg4AAgAjdj9QAAADABAFQABAGABAAQAHADAAAQQABAJgBARIAAGnQAAAaARAGQAxATBvACQBxACA8gTQAKgDAHgMQAFgKAAgLIABlvQAAg1A7g+");
	this.shape_6.setTransform(150.6,56.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#525957").ss(0.3,0,0,3.9).p("ADhAAInBAA");
	this.shape_7.setTransform(148.4,78.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#525957").ss(0.2,0,0,3.9).p("AD7AcIn1AAAD6AZInzAAAD4AWInvAAAD3ASIntAAAD1APInqAAAD0AMInnAAADyAJInkAAADxAGIniAAADwACIngAAADuAAIncAAADtgCInaAAADsgFInYAAADqgIInVAAADpgLInTAAADogNInQAAADmgQInNAAADlgTInLAAADkgWInJAAADjgZInHAAADigcInFAA");
	this.shape_8.setTransform(148.5,81.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#525957").ss(0.3,0,0,3.9).p("AECAGIoDAAAEBADIoBAAAD/AAIn+AAAD+gCIn7AAAD8gFIn4AA");
	this.shape_9.setTransform(148.5,85.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#525957").ss(0.2,0,0,3.9).p("ACoArIgBgDIgTAAIABADADOArIgBgDIgTAAIABADACvgqIAeBSIASAAIATAAIASAAAC/gqIAgBSIABADACPgqIAYBSIATAAIgbhSADzArIgBgDIgjhSAgkArIAAgDIgTAAIAAADAgggqIgEBSIATAAIARAAIASAAIASAAIATAAIATAAIgMhSAgQgqIgBBSIAAADAAOgqIAEBSIAAADAAAArIAAgDIAAhSAgwgqIgHBSIgSAAIgTAAIAAADAAlArIgBgDIgGhSAA4ArIgBgDIgJhSABKArIAAgDIATAAIAAADACDArIgBgDIgTAAIABADABOgqIAPBSIASAAIgRhSABugqIAUBSIASAAIgVhSAjyArIABgDIgSAAAjfArIABgDIgTAAIAghSAi6ArIABgDIgTAAIgBADAjBgqIgdBSIASAAIAbhSAiCArIABgDIgTAAIAThSAiUArIAAgDIgSAAIAVhSAinArIABgDIgTAAIAYhSAhhgqIgNBSIASAAIALhSAhJArIAAgDIAIhSAhuAoIgBADAhxgqIgQBSIATAA");
	this.shape_10.setTransform(148.5,82.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#EE851D").ss(0.3,0,0,3.9).p("Ai+AWIFuAAQAJAAABgWQAAgUgHAAIlaAA");
	this.shape_11.setTransform(117.8,146);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#966D2F").ss(0.2,0,0,3.9).p("ABAASIhNAAQgCAEgEAAIgngGIAAgfIAngFQAEAAACAEIBNAA");
	this.shape_12.setTransform(139.1,146);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#966D2F").ss(0.2,0,0,3.9).p("AgWADIAAgDQgMABAAABIAAB2QAAACAMABIAABfIgEAAQg2ABgkAGQglAHgCAIIABARQgBABAAAPQAAAQABABQAIAKA3AGQA4AHBCgDQA6gCAkgHQAigGgDgJIAAgsQABgBgBgBQgBgDgEgCQgYgPhigCIAAhfQALgBAAgCIAAh1QAAgCgLgBIAAk1QgbAGgYgGIAAE1");
	this.shape_13.setTransform(147.5,128.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAMAAIgXAA");
	this.shape_14.setTransform(102.7,80.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AgLAAIAXAA");
	this.shape_15.setTransform(102.7,85.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AgTABIAGAAQAMAAAHgBQAJgCAAgD");
	this.shape_16.setTransform(112.2,1.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AAYgEQgIgCgLAAQgLAAgIADQgJACAAABAgMAFIAMAC");
	this.shape_17.setTransform(110.2,0.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AADAFQAAgEgJgB");
	this.shape_18.setTransform(113.3,0.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AgcgEQAAAFAcAAQAdAAAAgF");
	this.shape_19.setTransform(110.7,78.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAGBIAAsB");
	this.shape_20.setTransform(113.7,39.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAmAIAAMB");
	this.shape_21.setTransform(107.7,39.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AgoAFIALAAQAcAAASgFQATgCAAgH");
	this.shape_22.setTransform(113.7,79.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AA3gLQgTgEgYAAQgaAAgUAFQgUAFAAAFAgdAMQANACAQAB");
	this.shape_23.setTransform(109.5,78.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAKAIQAAgHgXgD");
	this.shape_24.setTransform(116.3,77.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AhCgJQAAAGAUADQATAFAbAAQAbAAAUgFQATgDAAgG");
	this.shape_25.setTransform(110.7,88.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAArIAAhW");
	this.shape_26.setTransform(117.4,82.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAgrIAABW");
	this.shape_27.setTransform(104,82.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#EAE8E9").ss(0.9,1,0,3.9).p("ACFAAIkKAA");
	this.shape_28.setTransform(124.7,82.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#E5E3E3").ss(0.9,1,0,3.9).p("ACGAAIkLAA");
	this.shape_29.setTransform(124.6,82.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#E0DEDE").ss(1,1,0,3.9).p("ACFAAIkJAA");
	this.shape_30.setTransform(124.6,82.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#DCD9DA").ss(1,1,0,3.9).p("ACFAAIkJAA");
	this.shape_31.setTransform(124.5,82.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#D7D4D5").ss(1.1,1,0,3.9).p("ACFAAIkJAA");
	this.shape_32.setTransform(124.5,82.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#D2D0D0").ss(1.2,1,0,3.9).p("ACFAAIkJAA");
	this.shape_33.setTransform(124.5,82.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#CECBCB").ss(1.2,1,0,3.9).p("ACFAAIkJAA");
	this.shape_34.setTransform(124.4,82.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#C9C6C7").ss(1.3,1,0,3.9).p("ACFAAIkJAA");
	this.shape_35.setTransform(124.4,82.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#C5C2C2").ss(1.3,1,0,3.9).p("ACFAAIkJAA");
	this.shape_36.setTransform(124.3,82.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#C0BDBD").ss(1.4,1,0,3.9).p("ACFAAIkIAA");
	this.shape_37.setTransform(124.3,82.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#BBB8B8").ss(1.5,1,0,3.9).p("ACFAAIkIAA");
	this.shape_38.setTransform(124.3,82.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#B6B3B3").ss(1.5,1,0,3.9).p("ACEAAIkHAA");
	this.shape_39.setTransform(124.2,82.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#B1AFAF").ss(1.6,1,0,3.9).p("ACEAAIkHAA");
	this.shape_40.setTransform(124.2,82.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#ACAAAA").ss(1.7,1,0,3.9).p("ACEAAIkHAA");
	this.shape_41.setTransform(124.1,82.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#A8A6A6").ss(1.7,1,0,3.9).p("ACEAAIkHAA");
	this.shape_42.setTransform(124.1,82.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#A3A1A1").ss(1.8,1,0,3.9).p("ACEAAIkHAA");
	this.shape_43.setTransform(124.1,82.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#9E9D9D").ss(1.8,1,0,3.9).p("ACEAAIkHAA");
	this.shape_44.setTransform(124,82.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#9A9898").ss(1.9,1,0,3.9).p("ACEAAIkHAA");
	this.shape_45.setTransform(124,82.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#959494").ss(2,1,0,3.9).p("ACEAAIkHAA");
	this.shape_46.setTransform(123.9,82.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#90908F").ss(2,1,0,3.9).p("ACDAAIkGAA");
	this.shape_47.setTransform(123.9,82.2);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#8B8B8B").ss(2.1,1,0,3.9).p("ACDAAIkFAA");
	this.shape_48.setTransform(123.9,82.2);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#868787").ss(2.1,1,0,3.9).p("ACDAAIkFAA");
	this.shape_49.setTransform(123.8,82.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#818383").ss(2.2,1,0,3.9).p("ACDAAIkFAA");
	this.shape_50.setTransform(123.8,82.2);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#7D7F7F").ss(2.3,1,0,3.9).p("ACDAAIkFAA");
	this.shape_51.setTransform(123.7,82.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AgEApIAAgLQAAgcAEgSQADgTAHAA");
	this.shape_52.setTransform(100.1,80.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AAMg2QADAUAAAYQAAAagFATQgEAUgGAAAgLAeQgDgMAAgS");
	this.shape_53.setTransform(101.2,84.3);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AgHgJQAHAAADAW");
	this.shape_54.setTransform(102.1,77.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AAKBCQgGAAgEgTQgEgTAAgcQAAgbAEgTQAEgTAGAA");
	this.shape_55.setTransform(96.1,83.2);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AgTAAIAnAA");
	this.shape_56.setTransform(99.2,76.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAUAAIgnAA");
	this.shape_57.setTransform(99.2,89.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AgcgFQAAADAJACQAIABALAAQAMAAAJgBQAIgCAAgD");
	this.shape_58.setTransform(110.7,157);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAFkIAArH");
	this.shape_59.setTransform(113.7,120.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAljIAALH");
	this.shape_60.setTransform(107.7,120.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#666D6E").ss(2.8,1,0,3.9).p("AB+AAIj7AA");
	this.shape_61.setTransform(125.7,82.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFCE4").s().p("AgPAZQgLgEgDgUQgBgJgGgMIgGgKQARAUAZAAQAZAAASgUIgGAKQgGAMgCAJQgCAUgLAEQgKAGgGAAQgFAAgKgGg");
	this.shape_62.setTransform(147.7,95.7);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#F8F6E5").s().p("AgRAdQgMgGgEgWQgBgKgHgOIgHgLQAUAXAcAAQAcAAAVgXIgHALQgHAOgCAKQgCAWgNAGQgKAFgIABQgGgBgLgFg");
	this.shape_63.setTransform(147.7,95.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#F0F0E6").s().p("AgTAhQgPgHgDgZQgBgLgIgQIgIgMQAWAaAgAAQAggBAWgZIgHAMQgIAQgCALQgEAZgNAHQgMAFgIABQgHgBgMgFg");
	this.shape_64.setTransform(147.7,94.9);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#E8EBE7").s().p("AgVAkQgPgHgEgbQgCgNgJgRIgIgPQAZAeAigBQAiAAAagdIgIAPQgJARgCANQgDAagQAIQgIAEgIACIgGACQgIgCgNgGg");
	this.shape_65.setTransform(147.6,94.4);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#E0E5E8").s().p("AgXAnQgJgEgFgLQgGgKgBgMQgCgOgKgTIgJgQQAcAhAlgBQAlAAAdggIgJAQQgKATgBAOQgFAdgRAIQgOAHgJACQgJgCgPgHg");
	this.shape_66.setTransform(147.6,94);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#D7DFE9").s().p("AgaArQgJgFgGgMQgGgLgBgNQgDgPgKgVIgKgRQAdAiAqAAQAoAAAggiIgKARQgLAVgCAPQgEAggTAJQgPAHgLACQgKgCgQgHg");
	this.shape_67.setTransform(147.6,93.6);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#CFD9E9").s().p("AgcAuQgJgEgHgOQgGgLgCgPQgCgRgMgWIgLgSQAfAlAuAAQAVAAARgHQAVgJASgVIgKASQgMAWgCARQgFAjgTAJQgLAFgKADIgHACQgLgCgSgIg");
	this.shape_68.setTransform(147.6,93.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#C6D3EA").s().p("AgeAyQgLgFgHgPQgGgMgCgQQgDgSgLgYIgMgTQAhAoAxAAQAWgBASgIQAXgJAUgWIgLATQgMAYgDASQgCAPgHANQgHAOgLAGQgLAFgKADIgIACQgMgCgTgIg");
	this.shape_69.setTransform(147.6,92.8);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#BECEEA").s().p("AggA1QgLgGgIgOQgHgOgCgQQgDgUgNgaIgMgVQAkAsA0gBQAYAAAUgIQAXgKAWgZIgMAVQgNAagDAUQgCAQgHAOQgIAOgLAGQgTAJgNACQgNgCgUgJg");
	this.shape_70.setTransform(147.6,92.4);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#BECEEA").s().p("AggA0QgLgGgIgPQgHgNgCgRQgDgTgNgaIgMgVQAkAsA0gBQAYAAAUgJQAXgKAWgYIgMAVQgNAagDATQgCARgHANQgIAPgLAGQgTAJgNAFQgNgFgUgJg");
	this.shape_71.setTransform(147.6,92.5);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#C1CBE4").s().p("AggA1QgMgGgIgPQgHgOgCgRQgDgUgNgZIgMgWQAkAsA1AAQAZgBATgIQAYgLAWgYIgMAWQgNAZgDAUQgCARgHAOQgIAPgMAGIggAOQgOgFgTgJg");
	this.shape_72.setTransform(147.6,92.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#C3C9DE").s().p("AghA1QgMgFgHgQQgIgOgCgRQgDgUgNgaIgNgWQAlAsA2AAQAZAAAUgJQAYgKAXgZIgNAWQgOAagCAUQgDARgHAOQgIAQgMAFIggAPQgOgFgUgKg");
	this.shape_73.setTransform(147.6,92.3);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#C6C6D7").s().p("AghA2QgMgFgIgQQgHgOgDgSQgDgUgNgaIgNgXQAmAuA2gBQA1AAAogtIgNAXQgNAagDAUQgDASgHAOQgIAQgMAFIghAPQgOgFgUgKg");
	this.shape_74.setTransform(147.6,92.2);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#C8C3D1").s().p("AgiA3QgMgGgIgPQgHgPgDgSQgDgVgNgaIgNgXQAmAvA3gCQAaABAUgKQAZgLAXgZIgNAXQgNAagDAVQgDASgHAPQgIAPgMAGQgVAKgNAFQgOgFgVgKg");
	this.shape_75.setTransform(147.6,92.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#CBC0CA").s().p("AgiA4QgNgGgIgQQgHgOgDgTQgDgVgOgbIgNgWQAnAtA4ABQAagBAVgJQAZgLAYgZIgNAWQgOAbgDAVQgDATgHAOQgIAQgNAGQgUAKgOAFQgPgFgUgKg");
	this.shape_76.setTransform(147.6,92);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#CDBDC4").s().p("AgjA5QgNgGgIgQQgIgQgCgRQgDgWgOgcIgNgWQAmAuA6AAQAagBAWgIQAZgLAYgaIgOAWQgOAcgDAWQgCARgIAQQgIAQgMAGIgjAPQgPgFgVgKg");
	this.shape_77.setTransform(147.6,91.9);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#CFBABE").s().p("AgjA6QgNgGgIgRQgIgPgCgSQgEgWgOgcIgNgXQAnAwA6gBQAbgBAVgJQAbgLAXgaIgNAXQgOAcgDAWQgDASgHAPQgJARgNAGQgVAKgOAEQgPgEgVgKg");
	this.shape_78.setTransform(147.6,91.7);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#D1B7B7").s().p("AgkA7QgMgGgJgRQgIgPgCgTQgEgWgOgdIgOgXQAoAwA7gBQAbAAAWgJQAbgLAYgbIgOAXQgOAdgDAWQgDATgIAPQgJARgMAGQgWALgOADQgPgDgWgLg");
	this.shape_79.setTransform(147.6,91.6);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#D3B4B1").s().p("AgkA7QgNgFgJgSQgIgPgCgTQgEgXgOgdIgOgYQAoAyA8gBQAcAAAWgJQAbgMAYgcIgOAYQgOAdgEAXQgCATgIAPQgJASgNAFQgVALgPAEQgPgEgWgLg");
	this.shape_80.setTransform(147.6,91.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#D5B0AA").s().p("AglA9QgNgHgJgRQgIgQgCgTQgEgXgPgdIgOgYQAYAcAbAMQAXAJAcAAQAcAAAXgKQAbgMAZgbIgOAYQgPAdgEAXQgCATgIAQQgJARgNAHQgOAGgNAFIgKADQgQgEgWgKg");
	this.shape_81.setTransform(147.6,91.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#D7ADA4").s().p("AgmA9QgNgGgJgSQgIgPgCgUQgEgXgPgeIgOgYQAqAyA9AAQAcgBAXgJQAcgMAZgcIgOAYQgQAegDAXQgCAUgJAPQgIASgOAGQgWALgPAEQgQgEgXgLg");
	this.shape_82.setTransform(147.6,91.3);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#D9A99E").s().p("AgmA+QgNgGgJgSQgJgQgCgUQgEgXgPgeIgOgZQAqAzA+gBQAdAAAXgKQAcgMAZgcIgOAZQgPAegEAXQgCAUgIAQQgKASgNAGQgXALgPAEQgQgEgXgLg");
	this.shape_83.setTransform(147.6,91.2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#DBA697").s().p("AgmA/QgOgGgJgTQgIgQgDgUQgEgYgPgeIgPgZQArA0A/gBQAdAAAYgKQAcgMAagdIgPAZQgPAegEAYQgCAUgJAQQgJATgOAGQgOAHgNAFIgLADQgQgEgXgLg");
	this.shape_84.setTransform(147.6,91.1);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#DCA291").s().p("AgnBAQgNgGgKgTQgIgRgDgUQgEgYgPgeIgPgaQArA0BAAAQAegBAXgKQAdgMAagdIgPAaQgPAegEAYQgDAVgIAQQgJATgOAGQgXAMgQADQgQgDgYgMg");
	this.shape_85.setTransform(147.6,91);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#DE9E8A").s().p("AgoBBQgNgHgKgSQgJgRgDgUQgDgZgQgfIgPgaQAZAdAeANQAYALAegBQAeAAAYgKQAdgNAbgdIgQAaQgPAfgEAZQgDAUgIARQgKASgOAHIgcAMIgLADQgRgDgYgMg");
	this.shape_86.setTransform(147.6,90.9);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#DF9A84").s().p("AgoBCQgOgHgKgTQgIgRgDgUQgEgagQgfIgPgaQAtA2BBgBQAeAAAZgLQAdgNAbgdIgPAaQgQAfgEAaQgDAUgIARQgKATgOAHQgYAMgQADQgRgDgYgMg");
	this.shape_87.setTransform(147.6,90.8);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#E1967E").s().p("AgoBDQgPgHgKgTQgIgRgDgVQgEgZgQggIgPgbQAtA3BCgBQAeAAAZgLQAegNAbgeIgPAbQgQAggEAZQgDAVgIARQgKATgOAHIgeAMIgLADQgRgEgYgLg");
	this.shape_88.setTransform(147.6,90.6);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#E29277").s().p("AgpBEQgOgHgKgUQgJgRgDgVQgDgagRggIgQgbQAaAfAfANQAZALAfgBQAfAAAZgLQAegNAcgeIgQAbQgQAggEAaQgDAVgIARQgKAUgPAHIgeAMIgLADQgRgDgZgMg");
	this.shape_89.setTransform(147.6,90.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#E48E71").s().p("AgpBEQgPgGgKgUQgJgSgDgVQgDgagRghIgQgbQAaAfAfANQAaALAfAAQAfAAAagLQAegNAcgfIgPAbQgRAhgEAaQgDAVgJASQgKAUgOAGQgZAMgRAEQgSgEgYgMg");
	this.shape_90.setTransform(147.6,90.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#E58A6B").s().p("AgqBFQgPgHgKgUQgJgRgDgWQgEgbgRghIgPgbQAuA5BFgBQAfAAAagLQAfgOAdgfIgQAbQgRAhgEAbQgEAWgIARQgLAUgOAHQgQAIgPAFIgLADQgSgEgZgMg");
	this.shape_91.setTransform(147.6,90.3);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#E68664").s().p("AgqBGQgPgHgLgUQgJgSgDgWQgEgagRgiIgQgcQAwA6BFgBQAgAAAagMQAfgNAdggIgQAcQgRAigEAaQgDAWgJASQgKAUgPAHQgaANgRADQgSgDgZgNg");
	this.shape_92.setTransform(147.6,90.2);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#E8825E").s().p("AgrBHQgPgHgLgVQgJgSgDgWQgEgbgRgiIgQgcQAwA6BGgBQAgAAAbgLQAfgOAdggIgQAcQgRAigEAbQgDAWgJASQgLAVgPAHQgaANgRADQgSgDgagNg");
	this.shape_93.setTransform(147.6,90.1);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#E97D58").s().p("AgsBIQgPgIgKgUQgKgSgDgXQgEgbgRgiIgRgdQAxA6BHAAQAhAAAbgMQAfgNAeghIgRAdQgRAigEAbQgDAXgJASQgLAVgPAHQgaANgSADQgSgDgbgNg");
	this.shape_94.setTransform(147.6,90);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#EA7952").s().p("AgsBJQgQgIgKgVQgKgSgDgXQgEgbgRgjIgRgdQAbAhAiAOQAaAMAiAAQAhgBAbgLQAggOAeghIgRAdQgRAjgFAbQgCAXgKASQgLAVgPAIQgaANgSADQgTgDgagNg");
	this.shape_95.setTransform(147.6,89.9);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#EB744C").s().p("AgtBKQgPgIgLgVQgJgTgEgWQgEgcgRgjIgRgeQAyA9BIgBQAigBAbgLQAhgPAdghIgRAeQgRAjgEAcQgDAWgKATQgKAVgQAIQgRAIgPAFIgNACQgTgDgbgMg");
	this.shape_96.setTransform(147.6,89.8);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#EB744C").s().p("AgtBKQgPgIgLgVQgJgTgEgWQgEgcgRgjIgRgeQAyA9BIgBQAigBAbgLQAhgPAdghIgRAeQgRAjgEAcQgDAWgKATQgKAVgQAIQgRAIgPAFIgNACQgTgDgbgMg");
	this.shape_97.setTransform(147.6,89.8);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#EC7B52").s().p("AgtBKQgQgHgLgVQgKgTgDgXQgDgdgSgjIgRgdQAyA8BJgBQAiAAAbgMQAhgOAfghIgRAdQgSAjgFAdQgDAXgJATQgLAVgQAHQgbANgSADQgTgDgbgNg");
	this.shape_98.setTransform(147.6,89.7);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#ED8258").s().p("AgtBLQgQgHgLgWQgKgTgDgXQgEgdgSgkIgSgdQAzA9BKgBQAiAAAcgMQAhgPAfghIgSAdQgSAkgEAdQgDAXgKATQgLAWgQAHQgbANgSADQgTgDgbgNg");
	this.shape_99.setTransform(147.6,89.6);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#EE895E").s().p("AguBMQgQgIgLgVQgKgUgDgXQgEgdgSgkIgSgeQAdAiAiAPQAdAMAiAAQAjAAAcgMQAhgPAfgiIgSAeQgSAkgEAdQgDAXgKAUQgLAVgQAIQgRAIgQAFIgNADQgTgDgcgNg");
	this.shape_100.setTransform(147.6,89.5);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#EF9065").s().p("AguBNQgQgIgMgWQgJgTgEgYQgEgdgSglIgSgeQAdAjAjAPQAcAMAjAAQAjgBAcgMQAigOAfgjIgSAeQgSAlgEAdQgEAYgJATQgMAWgQAIQgRAIgQAFIgNADQgUgDgbgNg");
	this.shape_101.setTransform(147.6,89.4);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#F0976B").s().p("AgvBNQgQgIgLgWQgKgTgDgYQgFgdgSglIgSgfQA0A+BMAAQAjAAAcgMQAjgPAfgjIgSAfQgSAlgFAdQgDAYgKATQgLAWgQAIQgcANgTADQgUgDgcgNg");
	this.shape_102.setTransform(147.6,89.4);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#F29D72").s().p("AgvBOQgRgIgLgWQgKgUgDgYQgFgegSglIgSgeQA0A/BNgBQAjAAAdgNQAigOAggjIgSAeQgTAlgEAeQgDAYgKAUQgLAWgRAIQgSAIgQAFIgNADQgUgDgcgNg");
	this.shape_103.setTransform(147.6,89.3);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#F2A479").s().p("AgvBOQgRgIgLgWQgKgUgEgYQgEgegTglIgSgfQAeAkAjAOQAdANAkAAQAkAAAdgNQAigPAggjIgSAfQgTAlgEAeQgEAYgJAUQgMAWgRAIQgcAOgTADQgUgDgcgOg");
	this.shape_104.setTransform(147.6,89.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#F4AA80").s().p("AgvBPQgSgIgLgXQgKgUgEgYQgEgegTgmIgSgfQA1BABOgBQAkAAAdgMQAjgPAggkIgSAfQgTAmgEAeQgDAYgKAUQgMAXgRAIQgcAOgUADQgUgDgcgOg");
	this.shape_105.setTransform(147.6,89.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#F5B187").s().p("AgwBPQgRgHgMgXQgKgUgDgZQgFgegTgmIgSgfQA2BABOgBQAkgBAegMQAjgPAggjIgSAfQgTAmgFAeQgDAZgKAUQgMAXgRAHQgdAOgTADQgVgDgcgOg");
	this.shape_106.setTransform(147.6,89.1);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#F6B78E").s().p("AgxBQQgRgIgMgXQgKgUgDgZQgFgegTgnIgSgfQA2BBBPgBQAlAAAdgNQAkgQAggjIgSAfQgTAngFAeQgDAZgLAUQgLAXgRAIQgdAOgUADQgVgDgdgOg");
	this.shape_107.setTransform(147.6,89);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#F7BD95").s().p("AgxBRQgRgIgMgXQgKgVgEgZQgEgfgUgmIgSggQA2BCBQgBQAlgBAegMQAjgQAhgkIgSAgQgUAmgEAfQgEAZgKAVQgMAXgRAIQgdAOgUADQgVgDgdgOg");
	this.shape_108.setTransform(147.6,88.9);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#F8C39C").s().p("AgyBSQgRgJgMgXQgKgVgEgZQgEgfgUgnIgSggQAeAlAlAQQAeANAmgBQAlAAAegNQAkgPAhglIgSAgQgUAngFAfQgDAZgKAVQgMAXgSAJQgdAOgUADQgVgDgegOg");
	this.shape_109.setTransform(147.6,88.8);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#F9C9A3").s().p("AgyBSQgRgIgMgYQgLgUgDgaQgFgfgTgnIgTghQAeAlAmAQQAfANAlAAQAmAAAegNQAkgQAhglIgTAhQgTAngEAfQgEAagLAUQgLAYgSAIQgeAPgUADQgVgDgegPg");
	this.shape_110.setTransform(147.6,88.7);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FACFAA").s().p("AgyBTQgRgJgNgXQgLgVgDgaQgFgfgTgoIgTggQAfAlAlAQQAgANAlAAQAmAAAfgNQAkgQAiglIgUAgQgTAogFAfQgEAagKAVQgMAXgRAJQgeAOgVADQgVgDgegOg");
	this.shape_111.setTransform(147.6,88.7);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FBD5B1").s().p("AgzBUQgRgJgMgYQgLgVgEgaQgEgggUgnIgTghQAfAlAmAQQAfAOAmgBQAmAAAfgNQAkgQAjglIgTAhQgUAngFAgQgDAagMAVQgLAYgSAJQgeAOgVADQgVgDgfgOg");
	this.shape_112.setTransform(147.6,88.6);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FCDBB9").s().p("AgzBUQgSgIgMgZQgKgUgFgbQgEgggUgoIgUghQAgAmAmAQQAfAOAngBQAnAAAfgNQAkgRAjglIgTAhQgVAogEAgQgEAagLAVQgMAZgSAIQgeAPgVADQgVgDgfgPg");
	this.shape_113.setTransform(147.6,88.5);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FCE0C0").s().p("Ag0BVQgSgJgMgYQgLgWgDgZQgFghgUgoIgUgiQAgAmAnARQAfANAnAAQAmAAAggNQAlgQAjgnIgUAiQgUAogFAhQgDAagLAVQgNAYgSAJQgeAPgVADQgWgDgfgPg");
	this.shape_114.setTransform(147.6,88.4);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FDE6C7").s().p("Ag0BWQgSgJgMgYQgMgWgDgbQgFgggVgpIgTgiQAgAnAnARQAgANAnAAQAngBAggNQAmgRAigmIgTAiQgWApgEAgQgEAbgLAWQgMAYgSAJQgfAPgVADQgWgDgfgPg");
	this.shape_115.setTransform(147.6,88.3);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FEEBCE").s().p("Ag0BWQgTgJgMgYQgMgVgDgcQgFgggVgpIgTgjQAgAnAnARQAhAOAnAAQAngBAggOQAmgQAjgnIgUAjQgVApgEAgQgEAcgKAVQgNAYgTAJQgfAPgVADQgWgDgfgPg");
	this.shape_116.setTransform(147.6,88.3);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFF1D6").s().p("Ag1BXQgSgJgMgZQgMgVgEgcQgEghgVgpIgUgiQAhAnAnARQAhAOAngBQAoAAAfgOQAmgQAkgnIgUAiQgVApgFAhQgDAcgLAVQgNAZgTAJQgeAPgWADQgXgDgfgPg");
	this.shape_117.setTransform(147.6,88.2);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFF7DD").s().p("Ag1BYQgTgKgMgZQgMgWgDgaQgFgigVgqIgUgiQA7BHBWgBQAogBAggNQAngRAjgnIgUAiQgVAqgFAiQgDAagLAWQgNAZgTAKQggAPgVADQgXgDgfgPg");
	this.shape_118.setTransform(147.6,88.1);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFCE4").s().p("Ag2BYQgSgJgNgZQgLgWgEgcQgFghgVgqIgUgjQAhAoAoARQAhAOAoAAQAogBAggOQAngQAkgoIgUAjQgWAqgEAhQgDAcgMAWQgNAZgTAJQgTAKgTAFIgPAEQgXgEgggPg");
	this.shape_119.setTransform(147.6,88);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AFKhAIp4AAIgpBQIAAAxIKvAAIAAgxg");
	this.shape_120.setTransform(133.5,159.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text},{t:this.instance}]}).to({state:[{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape},{t:this.text},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1.9,272,203);


(lib.btn_destilacion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits14();
	this.instance.setTransform(6,3.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AVQM+MgqfAAAIAA57MAqfAAAg");
	this.shape.setTransform(136,83.5,1,1.006);

	this.text = new cjs.Text(txt['btn_dest'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(133.5,177.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AVQM+MgqfAAAIAA57MAqfAAAg");
	this.shape_1.setTransform(136,83.5,1,1.006);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AI2h4IAADxIxsAAIAAjxg");
	this.shape_2.setTransform(135.9,189.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("Ao2B5IAAjxIRsAAIAADxg");
	this.shape_3.setTransform(135.9,189.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AVSNAMgqjAAAIAA5/MAqjAAAg");
	this.shape_4.setTransform(135.9,82.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("A1RNAIAA5/MAqjAAAIAAZ/g");
	this.shape_5.setTransform(135.9,82.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1D1D1C").s().p("AgJAJQgDgDAAgGQAAgFADgEQAEgEAFAAQANAAAAANIgVAAQAAALAIAAQAHAAACgGIAEAAQgDAJgKAAQgFAAgEgFgAAJgBQgBgJgIAAQgHAAgBAJIARAAIAAAAg");
	this.shape_6.setTransform(176.7,50);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D1D1C").s().p("AAAAPIgBgGIAAgPIgGAAIAAgDIAGAAIAAgGIACgBIAAAHIAGAAIAAADIgGAAIAAAQQAAAEAEAAIADAAIAAADIgEAAQgEAAAAgCg");
	this.shape_7.setTransform(174,49.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D1D1C").s().p("AAIANIAAgPQAAgIgIABQgGgBgBAKIAAANIgDAAIAAgZIADAAIAAAFQADgGAFAAQAKABAAAKIAAAPg");
	this.shape_8.setTransform(171.4,50);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D1D1C").s().p("AgKAFQAAgFAGgBQACgBAJAAIAAgCQAAgGgHAAQgFAAAAAFIgEAAQACgIAHAAQALAAAAAJIAAARIgEAAIAAgEIAAAAIAAAAQgEAFgEAAQgJAAAAgJgAgBAAQgFABgBAEQABAGAGAAQAIAAgBgLIgIAAg");
	this.shape_9.setTransform(168.2,50);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1D1D1C").s().p("AgFANIgBgZIAEAAIABAFQABgGADAAIAEAAIAAAEIgDAAQgFgBAAAJIAAAOg");
	this.shape_10.setTransform(166,50);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1D1D1C").s().p("AgIAJQgEgDAAgGQAAgFAEgEQADgEAFAAQANAAAAANIgVAAQAAALAJAAQAGAAACgGIADAAQgCAJgKAAQgFAAgDgFgAAJgBQgBgJgIAAQgHAAgBAJIARAAIAAAAg");
	this.shape_11.setTransform(163.2,50);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1D1D1C").s().p("AgKALIADAAQABAFAGAAQAJAAAAgIIAAgFQgDAFgGAAQgMAAAAgMQAAgOAMAAQAFAAAEAFIAAgEIAEAAIgBAUIAAAIQgBAFgFABIgGACQgKAAAAgIgAgIgEQAAAJAIAAQAJAAAAgJQAAgLgJAAQgIAAAAALg");
	this.shape_12.setTransform(159.9,50.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1D1D1C").s().p("AAAATIAAgZIABAAIAAAZgAAAgOIAAgEIABAAIAAAEg");
	this.shape_13.setTransform(157.7,49.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1D1D1C").s().p("AgFANIgBgZIAEAAIAAAFQACgGADAAIAEAAIAAAEIgDAAQgGgBAAAJIAAAOg");
	this.shape_14.setTransform(156.2,50);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1D1D1C").s().p("AgBATIAAgWIgGAAIAAgDIAGAAIAAgFQAAgIAFABIAEAAIAAADIgDgBQgFABABAGIAAADIAGAAIAAADIgGAAIAAAWg");
	this.shape_15.setTransform(154,49.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#1D1D1C").s().p("AgIAJQgEgDAAgGQAAgFAEgEQADgEAFAAQANAAAAANIgVAAQAAALAJAAQAGAAACgGIADAAQgCAJgKAAQgFAAgDgFgAAJgBQgBgJgIAAQgHAAgBAJIARAAIAAAAg");
	this.shape_16.setTransform(151.4,50);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#1D1D1C").s().p("AgFANIAAgZIADAAIAAAFQACgGADAAIADAAIAAAEIgCAAQgGgBAAAJIAAAOg");
	this.shape_17.setTransform(149,50);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1D1D1C").s().p("AgJAJQgDgDgBgGQABgFADgEQAEgEAFAAQAGAAAEAEQADAEAAAFQABAOgOAAQgFAAgEgFgAgJAAQAAALAJAAQAJAAABgLQgBgKgJAAQgJAAAAAKg");
	this.shape_18.setTransform(186.9,157);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1D1D1C").s().p("AgLAFQgBgNAMAAQAFAAAEAGIAAgQIAEAAIAAAkIgEAAIAAgDQgDAEgGAAQgMAAABgOgAgIAFQABAMAHgBQAJABAAgMQAAgKgJAAQgIAAAAAKg");
	this.shape_19.setTransform(183.5,156.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#1D1D1C").s().p("AgKAGQAAgGAGAAQADgCAIABIAAgDQAAgGgHAAQgFAAAAAFIgEAAQABgIAIAAQALAAAAAJIAAARIgEAAIAAgEIAAAAIAAAAQgDAFgFAAQgJAAAAgIgAgHAGQABAFAGAAQAIAAgBgLQgOAAAAAGg");
	this.shape_20.setTransform(180.4,157);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#1D1D1C").s().p("AAAATIAAglIABAAIAAAlg");
	this.shape_21.setTransform(178.3,156.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#1D1D1C").s().p("AAAATIAAgZIABAAIAAAZgAAAgOIAAgEIABAAIAAAEg");
	this.shape_22.setTransform(177,156.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#1D1D1C").s().p("AAAAPIgBgGIAAgPIgGAAIAAgDIAGAAIAAgGIACgBIAAAHIAHAAIAAADIgHAAIAAAQQAAAEAEAAIADAAIAAADIgEAAQgEAAAAgCg");
	this.shape_23.setTransform(175.4,156.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#1D1D1C").s().p("AgKAGIAEAAQAAAFAGAAQAIAAAAgFQAAgEgIgCQgJAAAAgFQAAgIAJAAQAKAAAAAHIgDAAQgBgEgGAAQgFAAAAAEQAAADAEABIAHACQAFABAAAEQAAAJgLAAQgKAAAAgIg");
	this.shape_24.setTransform(172.9,157);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#1D1D1C").s().p("AgMAAQAAgFAEgEQADgEAFAAQANAAAAANIgVAAQAAALAIAAQAIAAABgGIAEAAQgDAJgKAAQgMAAAAgOgAAJAAQgBgKgIAAQgHAAgBAKIARAAIAAAAg");
	this.shape_25.setTransform(169.8,157);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#1D1D1C").s().p("AgMAFQAAgNAMAAQAFAAAEAGIAAAAIAAgQIADAAIAAAkIgDAAIAAgDIAAAAQgEAEgFAAQgMAAAAgOgAgHAFQgBAMAIgBQAJABAAgMQAAgKgJAAQgHAAAAAKg");
	this.shape_26.setTransform(166.5,156.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#1D1D1C").s().p("AAIAOIAAgQQAAgIgIAAQgHAAAAAKIAAAOIgDAAIAAgUIAAgGIADAAIAAAEQAEgFAEAAQALAAAAALIAAAQg");
	this.shape_27.setTransform(85.3,98.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#1D1D1C").s().p("AgMAAQAAgEAEgEQADgFAFAAQANAAAAANIgVAAQAAALAIAAQAHAAACgGIAEAAQgDAJgKAAQgMAAAAgOgAAJAAQgBgKgIAAQgHAAgBAKIARAAIAAAAg");
	this.shape_28.setTransform(82,98.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#1D1D1C").s().p("AgKAGQAAgGAGAAQADgBAIAAIAAgDQAAgGgHAAQgFAAAAAFIgEAAQACgIAHAAQALAAAAAJIAAASIgEAAIAAgFQgCAFgFAAQgKAAAAgIgAgGAGQAAAFAGAAQAIAAgBgLQgNAAAAAGg");
	this.shape_29.setTransform(77.2,98.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#1D1D1C").s().p("AgBATIAAglIADAAIAAAlg");
	this.shape_30.setTransform(75.2,97.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#1D1D1C").s().p("AgLAAQAAgEAEgEQADgFAFAAQALAAAAAJIgEAAQAAgGgIAAQgHAAAAAKQAAALAHAAQAHAAABgGIAEAAQgCAJgKAAQgLAAAAgOg");
	this.shape_31.setTransform(73,98.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#1D1D1C").s().p("AgJANIAAgDIAPgTIgPAAIAAgDIATAAIAAADIgPATIAPAAIAAADg");
	this.shape_32.setTransform(70.2,98.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#1D1D1C").s().p("AgMAAQAAgNAMAAQANAAAAANIgVAAQABALAHAAQAHAAACgGIADAAQgCAJgKAAQgMAAAAgOgAAJAAQAAgKgJAAQgIAAAAAKIARAAIAAAAg");
	this.shape_33.setTransform(67.3,98.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#1D1D1C").s().p("AASAOIAAgQQAAgIgIAAQgIAAAAAKIAAAOIgCAAIAAgQQAAgIgIAAQgIAAAAAKIAAAOIgEAAIAAgUIAAgGIAEAAIAAAEQADgFAGAAQAHAAABAGQAFgGAFAAQAKAAAAALIAAAQg");
	this.shape_34.setTransform(63,98.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#1D1D1C").s().p("AAIAOIAAgQQAAgHgIAAQgGgBAAAJIAAAPIgEAAIAAgaIADAAIABAEIAAAAQADgEAEAAQAKAAAAALIAAAPg");
	this.shape_35.setTransform(83.3,103.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#1D1D1C").s().p("AgJAPQgDgEAAgGQAAgNAMAAQAGAAAEAFQADADAAAFQAAAGgDAEQgEAEgGAAQgFAAgEgEgAgJAFQAAALAJAAQAJAAAAgLQAAgKgJAAQgJAAAAAKgAgCgKIAEgIIAEAAIgGAIg");
	this.shape_36.setTransform(80.1,103.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#1D1D1C").s().p("AAAATIAAgZIABAAIAAAZgAgBgOIAAgEIADAAIAAAEg");
	this.shape_37.setTransform(77.8,103.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#1D1D1C").s().p("AgLAAQAAgFAEgDQADgFAEAAQALAAABAJIgEAAQAAgGgIAAQgHAAAAAKQAAALAHAAQAIAAAAgHIAEAAQgCAKgKAAQgLAAAAgOg");
	this.shape_38.setTransform(75.7,104);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#1D1D1C").s().p("AAAATIAAgZIABAAIAAAZgAAAgOIAAgEIABAAIAAAEg");
	this.shape_39.setTransform(73.5,103.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#1D1D1C").s().p("AgBATIAAglIADAAIAAAlg");
	this.shape_40.setTransform(72.2,103.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#1D1D1C").s().p("AAAATIAAglIABAAIAAAlg");
	this.shape_41.setTransform(70.9,103.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#1D1D1C").s().p("AgLACIAAgPIAFAAIAAAQQAAAIAGAAQAIAAAAgKIAAgOIADAAIAAAUIAAAGIgDAAIAAgEQgEAFgEAAQgLAAAAgMg");
	this.shape_42.setTransform(68.6,104);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#1D1D1C").s().p("AgIAOIAAABIAAAEIgEAAIABgGIAAggIADAAIAAARQADgFAFAAQANAAAAAMQAAAGgDAEQgDAFgGAAQgFAAgEgGgAgIAFQAAAMAIAAQAJAAAAgMQAAgJgJAAQgIAAAAAJg");
	this.shape_43.setTransform(65.4,103.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#1D1D1C").s().p("AgMAAQAAgFAEgDQADgFAFAAQANAAAAANIgVAAQABALAHAAQAHAAACgHIADAAQgCAKgKAAQgMAAAAgOgAAJgBQAAgJgJAAQgHAAgBAJIARAAIAAAAg");
	this.shape_44.setTransform(62,104);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#1D1D1C").s().p("AgMAAQAAgNAMAAQANAAAAANIgVAAQABALAHAAQAHAAACgGIADAAQgCAJgKAAQgMAAAAgOgAAJgBQAAgJgJAAQgDAAgCADQgDACAAAEIARAAIAAAAg");
	this.shape_45.setTransform(75,64.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#1D1D1C").s().p("AgMAFQAAgMAMAAQAGAAADAFIAAgRIADAAIAAAgIABAGIgEAAIAAgEIAAgBQgEAGgFAAQgMAAAAgPgAgIAFQAAAMAIAAQAJAAAAgNQAAgIgJAAQgIAAAAAJg");
	this.shape_46.setTransform(71.6,64.3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#1D1D1C").s().p("AgJANIAAgDIAPgTIgPAAIAAgDIATAAIAAADIgPATIAPAAIAAADg");
	this.shape_47.setTransform(67.1,64.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#1D1D1C").s().p("AgKAGQAAgGAGgBIAMgBIAAgCQgBgGgGAAQgGAAAAAFIgDAAQAAgIAJAAQAKAAAAAJIAAARIgDAAIAAgEIgBAAQgCAFgFAAQgKAAAAgIgAAAAAQgGABAAAFQAAAFAGAAQAHAAABgLIgIAAg");
	this.shape_48.setTransform(64.2,64.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#1D1D1C").s().p("AgFANIgBgZIAEAAIAAAEQACgEADgBIAEAAIAAAEIgDAAQgGgBAAAJIAAAOg");
	this.shape_49.setTransform(62,64.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#1D1D1C").s().p("AAAAPIgBgGIAAgPIgGAAIAAgDIAGAAIAAgGIACgBIAAAHIAGAAIAAADIgGAAIAAAQQAAAEAEAAIADAAIAAADIgEAAQgEAAAAgCg");
	this.shape_50.setTransform(59.9,64.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#1D1D1C").s().p("AgKAGQAAgGAGgBIALgBIAAgCQAAgGgHAAQgFAAAAAFIgEAAQACgIAHAAQALAAAAAJIAAARIgEAAIAAgEQgDAFgEAAQgKAAAAgIgAAAAAQgGABAAAFQAAAFAGAAQAIAAgBgLIgHAAg");
	this.shape_51.setTransform(57.3,64.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#1D1D1C").s().p("AASANIAAgPQAAgIgIABQgJAAAAAJIAAANIgBAAIAAgPQAAgIgIABQgIAAAAAJIAAANIgEAAIAAgZIADAAIABAEIAAABQADgGAGAAQAHAAABAHQADgHAHAAQAKABAAAKIAAAPg");
	this.shape_52.setTransform(53.3,64.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#1D1D1C").s().p("AAIAOIAAgQQAAgHgIAAQgGAAAAAJIAAAOIgEAAIAAgUIAAgFIADAAIABADQADgEAEgBQAKAAAAAMIAAAPg");
	this.shape_53.setTransform(76.9,70.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#1D1D1C").s().p("AgJAPQgDgEAAgGQAAgFADgDQAEgFAFAAQAGAAAEAFQADADAAAFQAAAGgDAEQgEAEgGAAQgFAAgEgEgAgJAFQAAALAJAAQAJAAAAgLQAAgKgJAAQgJAAAAAKgAgCgKIAEgIIAEAAIgGAIg");
	this.shape_54.setTransform(73.7,69.9);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#1D1D1C").s().p("AAAATIAAgZIABAAIAAAZgAgBgOIAAgEIADAAIAAAEg");
	this.shape_55.setTransform(71.4,69.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#1D1D1C").s().p("AgLAAQAAgEAEgFQADgEAEAAQALAAABAJIgEAAQAAgGgIAAQgCAAgDAEQgCADAAADQAAALAHAAQAIAAAAgHIAEAAQgCAKgKAAQgLAAAAgOg");
	this.shape_56.setTransform(69.3,70.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#1D1D1C").s().p("AgKAFQAAgFAGgBQACgBAJAAIAAgCQAAgGgHAAQgEAAgBAFIgEAAQACgIAHAAQALAAAAAJIAAARIgDAAIgBgEIAAABQgCAEgFAAQgKAAAAgJgAAAAAQgGABAAAEQAAAGAGAAQAIAAgBgLIgHAAg");
	this.shape_57.setTransform(66.2,70.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#1D1D1C").s().p("AAAATIAAglIABAAIAAAlg");
	this.shape_58.setTransform(64.2,69.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#1D1D1C").s().p("AAAATIAAgZIABAAIAAAZgAAAgOIAAgEIABAAIAAAEg");
	this.shape_59.setTransform(62.9,69.9);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#1D1D1C").s().p("AAAAPIgBgGIAAgPIgGAAIAAgDIAGAAIAAgGIACgBIAAAHIAHAAIAAADIgHAAIAAAQQAAAEAEAAIADAAIAAADIgEAAQgEAAAAgCg");
	this.shape_60.setTransform(61.2,70.1);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#1D1D1C").s().p("AgKAFIAEAAQAAAGAGAAQAHAAAAgGQAAgDgHgCQgJAAAAgFQAAgIAJAAQAKAAAAAIIgDAAQgBgFgGAAQgFAAAAAFQAAACAEABIAHACQAFAAAAAFQAAAJgLAAQgKAAAAgJg");
	this.shape_61.setTransform(58.7,70.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#1D1D1C").s().p("AgMAAQAAgEAEgFQADgEAFAAQANAAAAAOIgVAAQABAKAHAAQAHAAACgHIADAAQgCAKgKAAQgMAAAAgOgAAJgBQAAgJgJAAQgHAAgBAJIARAAIAAAAg");
	this.shape_62.setTransform(55.6,70.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#1D1D1C").s().p("AgMAFQABgNALAAQAFABAEAEIAAgQIADAAIAAAmIgDAAIAAgFQgFAFgEABQgLAAgBgPgAgIAEQAAAMAIAAQAJAAAAgMQAAgJgJABQgIgBAAAJg");
	this.shape_63.setTransform(52.3,69.9);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#1D1D1C").s().p("AgKAGQAAgGAGgBQACAAAJAAIAAgDQAAgGgHAAQgEAAgBAEIgEAAQACgHAHAAQALAAAAAJIAAARIgDAAIgBgEIAAAAQgDAFgEAAQgKAAAAgIgAAAAAQgGABAAAFQAAAFAGAAQAIAAgBgLIgHAAg");
	this.shape_64.setTransform(176.8,109.3);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#1D1D1C").s().p("AgKACIAAgPIADAAIAAAQQAAAHAHABQAIAAAAgKIAAgOIADAAIAAAZIgDAAIAAgDIgBAAQgDAEgEAAQgKAAAAgLg");
	this.shape_65.setTransform(173.8,109.4);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#1D1D1C").s().p("AgKALIADAAQABAFAGAAQAJAAAAgIIAAgFQgDAFgGAAQgMAAAAgMQAAgOAMAAQAFAAAEAFIAAgEIAEAAIgBAVQAAALgGADIgGABQgKAAAAgIgAgIgEQAAAJAIAAQAJAAAAgJQAAgLgJAAQgIAAAAALg");
	this.shape_66.setTransform(170.4,109.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#1D1D1C").s().p("AgKAGQAAgGAGgBQADAAAJAAIAAgDQgBgGgGAAQgGAAAAAEIgDAAQAAgHAJAAQAKAAAAAJIAAARIgDAAIAAgEIgBAAQgCAFgFAAQgKAAAAgIgAAAAAQgGABAAAFQAAAFAGAAQAIAAAAgLIgIAAg");
	this.shape_67.setTransform(167.3,109.3);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#1D1D1C").s().p("AgJAJQgDgDAAgGQAAgFADgEQAEgEAFAAQANAAAAANIgVAAQAAALAIAAQAHAAACgGIAEAAQgEAJgJAAQgFAAgEgFgAAJgBQgBgJgIAAQgHAAgBAJIARAAIAAAAg");
	this.shape_68.setTransform(162.6,109.3);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#1D1D1C").s().p("AgJAPQgDgFAAgFQAAgNAMAAQAGAAADAGIAAgQIADAAIAAAfIABAFIgEAAIAAgDQgEAEgFAAQgGAAgDgEgAgIAFQAAAMAIgBQAJABAAgMQAAgKgJAAQgIAAAAAKg");
	this.shape_69.setTransform(159.3,108.8);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#1D1D1C").s().p("AgKAGQAAgGAGgBQADAAAIAAIAAgDQAAgGgGAAQgGAAAAAEIgEAAQABgHAJAAQAKAAAAAJIAAARIgEAAIAAgEIAAAAQgCAFgFAAQgKAAAAgIgAAAAAQgGABAAAFQAAAFAGAAQAIAAgBgLIgHAAg");
	this.shape_70.setTransform(154.5,109.3);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#1D1D1C").s().p("AgMAFQABgNALAAQAFAAAEAGIAAgQIADAAIAAAkIgDAAIAAgDQgFAEgEAAQgLAAgBgOgAgIAFQAAAMAIgBQAIABABgMQAAgKgJAAQgIAAAAAKg");
	this.shape_71.setTransform(151.4,108.8);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#1D1D1C").s().p("AgKAGQAAgGAGgBQACAAAJAAIAAgDQAAgGgHAAQgFAAAAAEIgEAAQACgHAHAAQALAAAAAJIAAARIgEAAIAAgEQgDAFgEAAQgKAAAAgIgAAAAAQgGABAAAFQAAAFAGAAQAIAAgBgLIgHAAg");
	this.shape_72.setTransform(148.2,109.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#1D1D1C").s().p("AgGANIAAgZIAEAAIAAAFIABAAQABgGADAAIAEAAIAAADIgCAAQgGAAgBAJIAAAOg");
	this.shape_73.setTransform(146.1,109.3);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#1D1D1C").s().p("AAAAPIgBgGIAAgPIgGAAIAAgDIAGAAIAAgGIACgBIAAAHIAHAAIAAADIgHAAIAAAQQAAAEAEAAIADAAIAAADIgEAAQgEAAAAgCg");
	this.shape_74.setTransform(143.9,109);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#1D1D1C").s().p("AAIANIAAgPQAAgIgIAAQgHAAAAAKIAAANIgDAAIAAgZIADAAIAAAFIABAAQADgGAEAAQAKABAAAKIAAAPg");
	this.shape_75.setTransform(141.3,109.3);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#1D1D1C").s().p("AgMAAQAAgFAEgEQADgEAFAAQANAAAAANIgVAAQAAALAIAAQAIAAABgGIADAAQgCAJgKAAQgMAAAAgOgAAJgBQgBgJgIAAQgHAAgBAJIARAAIAAAAg");
	this.shape_76.setTransform(138,109.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#1D1D1C").s().p("AgKAGQAAgGAGAAQADgBAJAAIAAgDQgBgGgGAAQgGAAAAAEIgDAAQAAgHAJAAQAKAAAAAJIAAARIgDAAIAAgEIgBAAQgCAFgFAAQgKAAAAgIgAgGAGQAAAFAGAAQAHAAABgLQgOAAAAAGg");
	this.shape_77.setTransform(131.2,84);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#1D1D1C").s().p("AgLADIAAgQIAEAAIAAAQQAAAIAHAAQAHAAAAgKIAAgOIAEAAIAAAUIABAGIgEAAIgBgEQgDAFgEAAQgLAAAAgLg");
	this.shape_78.setTransform(128.2,84);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#1D1D1C").s().p("AgKALIADAAQABAFAGAAQAIAAABgIIAAgFIgBAAQgCAFgGAAQgLAAAAgMQAAgOALAAQAFAAADAFIABAAIAAgEIAEAAIAAAUQAAAMgHACQgDACgDAAQgLAAABgIgAgIgEQAAAJAIAAQAJAAAAgJQAAgLgJAAQgIAAAAALg");
	this.shape_79.setTransform(124.8,84.5);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#1D1D1C").s().p("AgKAGQAAgGAGAAQADgBAIAAIAAgDQAAgGgHAAQgFAAAAAEIgEAAQACgHAHAAQALAAgBAJIABARIgEAAIAAgEIAAAAQgEAFgDAAQgKAAAAgIgAgHAGQAAAFAHAAQAIAAgBgLQgOAAAAAGg");
	this.shape_80.setTransform(121.7,84);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#1D1D1C").s().p("AgMAAQAAgEAEgFQADgEAFAAQANAAAAANIgVAAQABALAHAAQAHAAACgGIAEAAQgDAJgKAAQgMAAAAgOgAAJgBQgBgJgIAAQgHAAgBAJIARAAIAAAAg");
	this.shape_81.setTransform(117,84);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#1D1D1C").s().p("AgLAFQgBgNAMABQAGgBACAGIABAAIAAgQIAEAAIAAAkIgEAAIAAgDIgBAAQgDAEgFAAQgMAAABgOgAgIAFQAAALAIABQAJAAgBgNQAAgJgIAAQgIAAAAAKg");
	this.shape_82.setTransform(113.7,83.5);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#1D1D1C").s().p("AgKAGQAAgGAGAAQACgBAJAAIAAgDQAAgGgHAAQgEAAgBAEIgEAAQACgHAHAAQALAAgBAJIABARIgDAAIgBgEIAAAAQgEAFgDAAQgKAAAAgIgAAAAAQgHABAAAFQAAAFAHAAQAIAAgBgLIgHAAg");
	this.shape_83.setTransform(108.9,84);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#1D1D1C").s().p("AgJAPQgDgFAAgFQAAgNAMABQAGgBADAGIAAgQIADAAIAAAeIABAGIgEAAIAAgDQgEAEgFAAQgGAAgDgEgAgIAFQAAALAIABQAJAAAAgNQAAgJgJAAQgIAAAAAKg");
	this.shape_84.setTransform(105.8,83.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#1D1D1C").s().p("AAAATIAAgZIABAAIAAAZgAgBgOIAAgEIADAAIAAAEg");
	this.shape_85.setTransform(103.5,83.4);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#1D1D1C").s().p("AAAATIAAglIABAAIAAAlg");
	this.shape_86.setTransform(102.2,83.4);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#1D1D1C").s().p("AgKAGQAAgGAGAAQACgBAJAAIAAgDQAAgGgHAAQgEAAgBAEIgEAAQACgHAHAAQALAAAAAJIAAARIgDAAIgBgEIAAAAQgDAFgEAAQgKAAAAgIgAAAAAQgGABAAAFQAAAFAGAAQAIAAgBgLIgHAAg");
	this.shape_87.setTransform(100,84);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#1D1D1C").s().p("AgKAGIADAAQABAFAGAAQAHAAAAgFQAAgEgHgCQgJAAAAgGQAAgHAJAAQAKAAAAAHIgEAAQAAgEgGAAQgGAAAAAEQAAADAEABIAIACQAFAAAAAFQAAAJgLAAQgKAAAAgIg");
	this.shape_88.setTransform(97.1,84);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#1D1D1C").s().p("AgJAJQgEgDAAgGQAAgFAEgEQAEgEAFAAQAGAAAEAEQADAEAAAFQAAAOgNAAQgFAAgEgFgAgIAAQgBALAJAAQAEAAADgEQACgDABgEQAAgKgKAAQgJAAABAKg");
	this.shape_89.setTransform(88.2,9.4);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#1D1D1C").s().p("AgFAOIAAgaIADAAIAAAEIAAAAQACgEADgBIADABIAAADIgCgBQgFAAgBAJIAAAPg");
	this.shape_90.setTransform(85.7,9.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#1D1D1C").s().p("AAAAPIgBgGIAAgPIgGAAIAAgDIAGAAIAAgGIACgBIAAAHIAHAAIAAADIgHAAIAAAQQAAAEAEAAIADAAIAAADIgEAAQgEAAAAgCg");
	this.shape_91.setTransform(83.5,9.1);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#1D1D1C").s().p("AgMAAQAAgEAEgFQADgEAFAAQANAAAAANIgVAAQAAALAIAAQAHAAACgGIAEAAQgDAJgKAAQgMAAAAgOgAAJAAQgBgKgIAAQgHAAgBAKIARAAIAAAAg");
	this.shape_92.setTransform(80.9,9.4);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#1D1D1C").s().p("AASAOIAAgQQAAgIgIAAQgJAAAAAKIAAAOIgBAAIAAgQQAAgIgIAAQgJAAAAAKIAAAOIgDAAIAAgaIADAAIAAAEIABAAQADgFAGAAQAHAAAAAGQAFgGAGAAQAKAAAAAMIAAAPg");
	this.shape_93.setTransform(76.7,9.4);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#1D1D1C").s().p("AgMAEQAAgEADgEQAEgEAFAAQAGAAAEAEQADAEAAAEQAAAPgNAAQgMAAAAgPgAgJAEQAAAMAJAAQAEAAADgEQACgDAAgFQAAgJgJAAQgJAAAAAJgAgCgLIAEgHIAEAAIgGAHg");
	this.shape_94.setTransform(72.4,8.9);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#1D1D1C").s().p("AASAOIAAgQQAAgIgIAAQgJAAAAAKIAAAOIgBAAIAAgQQAAgIgIAAQgIAAAAAKIAAAOIgEAAIAAgUIAAgGIADAAIABAEQADgFAGAAQAHAAABAGQAEgGAGAAQAKAAAAAMIAAAPg");
	this.shape_95.setTransform(68.1,9.4);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#1D1D1C").s().p("AgFAOIAAgaIADAAIAAAEQACgEADgBIADABIAAADIgBgBQgHAAAAAJIAAAPg");
	this.shape_96.setTransform(64.7,9.4);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#1D1D1C").s().p("AgJAJQgDgDAAgGQAAgEADgFQAEgEAFAAQANAAAAANIgVAAQAAALAIAAQAIAAABgGIAEAAQgEAJgJAAQgFAAgEgFgAAJAAQgBgKgIAAQgHAAgBAKIARAAIAAAAg");
	this.shape_97.setTransform(61.9,9.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#1D1D1C").s().p("AgBAJIAAgPIgGAAIAAgDIAGAAIAAgGIACgBIAAAHIAGAAIAAADIgGAAIAAAQQAAAEAEAAIADAAIAAADIgEAAQgFAAAAgIg");
	this.shape_98.setTransform(59.3,9.1);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#1D1D1C").ss(0.3,0,0,3.9).p("Ar2reIi1AAAs3iyIhoAAACIlHIAACNAl5AKIhaAAArUCXIiIAAAHmEGIBSAAAOsLfIlgAA");
	this.shape_99.setTransform(131.6,83.1);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#7D9FAB").ss(0.2,0,0,3.9).p("AAXhYIAAB+IgvAv");
	this.shape_100.setTransform(239.7,112.2);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#357D8C").ss(0.2,0,0,3.9).p("AAABkIAAjH");
	this.shape_101.setTransform(237.1,110.4);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#EEF1F3").s().p("AAYCWIgliWQgFgUgGggQgIgrAAgTIAAglQAAgFADAAQADAAAAAFIgBAlQAAATAHAqQAHAlAEAQIAqCTQACAJgEABIgBAAQgEAAgCgHg");
	this.shape_102.setTransform(242,128.4);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#EAEEF1").s().p("AAWCZIgliZQgThRAAgiIAAgoQABgFADAAQADAAAAAFIgBAoQAAAUAIArQAHAlAFAPIAqCWQADAJgHACIgCAAQgFAAgBgIg");
	this.shape_103.setTransform(242.1,128.5);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#E7EBEE").s().p("AATCcIgjicQgThTAAggIAAgsQAAgFAEAAQAEAAAAAFIgBAsQAAAUAIArQAHAlAFAPIAsCZQACAJgIACIgDABQgGAAgCgJg");
	this.shape_104.setTransform(242.2,128.6);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#E4E8EC").s().p("AARCfIgjieQgThUAAggIABgvQAAgGAEAAQAEAAAAAGIgBAvQAAAUAIArQAIAmAFAOIAtCdQADAJgKACIgDABQgIAAgCgKg");
	this.shape_105.setTransform(242.3,128.6);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#E0E5E9").s().p("AAOCjIgiihQgShRAAglIAAgyQAAgFAFAAQAEAAAAAFIgBAyQAAAVAJArQAHAmAFAPIAvCfQADAKgMACIgEAAQgIAAgDgJg");
	this.shape_106.setTransform(242.4,128.7);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#DCE2E7").s().p("AAMCmIghikQgThTAAgjIABg2QAAgGAFAAQAFAAAAAGIgBA2QAAAVAJArQAHAoAFAOIAxChQADAKgOADIgFABQgKAAgCgLg");
	this.shape_107.setTransform(242.5,128.8);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#D9DFE4").s().p("AAKCpIghimQgShfAAgZIAAg5QAAgFAGAAQAGAAgBAFIAAA5QAAAVAIAtQAIAnAFAPIAzCjQADAKgQAEIgGAAQgLAAgCgLg");
	this.shape_108.setTransform(242.6,128.8);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#D5DCE2").s().p("AAHCsIggipQgShaAAgeIAAg9QAAgFAGAAQAHAAgBAFIAAA9QAAAVAJAtQAHAnAGAPIA0CmQADALgSADIgGABQgMAAgDgMg");
	this.shape_109.setTransform(242.8,128.9);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#D2DADF").s().p("AAFCvIggirQgRhdAAgdIAAhAQAAgFAGAAQAHAAAAAFIgBBAQAAAVAJAuQAIAoAGAPIA1CpQAEAKgUAEIgHABQgOAAgCgNg");
	this.shape_110.setTransform(242.9,129);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#CED7DD").s().p("AADCzIgfiuQgShfAAgcIABhDQAAgGAHAAQAHAAgBAGIAABDQAAAWAJAuQAIAnAGAQIA3CrQAEALgXAEIgHABQgPAAgCgNg");
	this.shape_111.setTransform(243,129);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#CBD4DA").s().p("AAAC2IgeiwQgRhdAAgfIAAhHQAAgFAIgBQAHAAAAAGIgBBHQAAAWAKAuQAIApAGAPIA4CuQAEALgYAEIgJABQgPAAgDgOg");
	this.shape_112.setTransform(243.1,129.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#C7D2D8").s().p("AAAC5IggizQgRhcAAghIAAhKQAAgGAIAAQAIAAAAAGIgBBKQAAAWAKAvQAIApAGAQIA7CwQAEALgbAFIgJABQgRAAAAgPg");
	this.shape_113.setTransform(243.2,129.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#C4CFD6").s().p("AgDC8Igei1IgKg5QgHgwAAgVIAAhOQAAgFAJgBQAIAAAAAGIAABOQAAAWAJAwQAIApAHAQIA7CyQAFAMgcAFIgKABQgRAAgDgQg");
	this.shape_114.setTransform(243.3,129.2);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#C0CCD3").s().p("AgFDAIgei4IgJg6QgHgxAAgVIAAhRQAAgFAJgBQAJABgBAFIAABRQAAAXAKAwQAJApAGAQIA9C1QAEAMgeAFIgLABQgRAAgDgPg");
	this.shape_115.setTransform(243.4,129.3);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#BCC9D1").s().p("AgHDDIgei7IgJg6QgHgxAAgVIAAhUQAAgGAJAAQAKgBgBAHIAABUQAAAWAKAxQAJApAGARIA/C3QAFAMggAGIgMABQgSAAgDgQg");
	this.shape_116.setTransform(243.5,129.4);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#B9C7CF").s().p("AgKDGIgci9IgJg6QgHgyAAgVIAAhYQAAgGAKAAQAJAAAAAGIAABYQAAAXAKAwQAJArAGAQIBBC6QAEAMgiAGIgMABQgUAAgDgRg");
	this.shape_117.setTransform(243.6,129.4);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#357D8C").ss(0.2,0,0,3.9).p("AA+h8QAAAiATAhICyE+QAEAFAAAIQAAAKgHAHQgIAHgLAAQgBABnZgBQgLAAgHgHQgIgHAAgKQAAgHADgFIC0lBQASghAAggIAAiQQAAgLgMgFQgFgCAAgEQAAgHAIAAICPAAQAHAAAAAHQAAAEgEACQgNAFAAANg");
	this.shape_118.setTransform(239.6,130.2);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f().s("#508796").ss(0.2,0,0,3.9).p("AABAPIgCgd");
	this.shape_119.setTransform(31.2,40.3);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("#7D9FAB").ss(0.2,0,0,3.9).p("AA3AAIhtAA");
	this.shape_120.setTransform(37,41.9);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f().s("#DCE2E7").ss(0.2,0,0,3.9).p("AABgMIgBAY");
	this.shape_121.setTransform(42.7,40.6);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f().s("#264546").ss(0.3,0,0,3.9).p("Ag8ASIgFgkICDAAQgFAkABAA");
	this.shape_122.setTransform(37,35.1);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f().s("#7D9FAB").ss(0.2,0,0,3.9).p("AgmgBIBJAAQgDADgGAAIg3AAQgGAAgDgDg");
	this.shape_123.setTransform(37.4,42);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#DCE2E7").s().p("AgbACQgGAAgDgDIBJAAQgDADgGAAg");
	this.shape_124.setTransform(37.2,42);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f().s("#EE851D").ss(0.3,0,0,3.9).p("AhmAPIDAAAQAHAAAAgPQAAgOgFAAIiwAA");
	this.shape_125.setTransform(18.2,150.6);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f().s("#966D2F").ss(0.2,0,0,3.9).p("AgWB1IAAANIg5AAQgDgDgDAAIgeAEIAAAXIAeAEQADAAADgDIA5AAIAAAUQg5AFgsAUIgaAAIAAAiIErAAIAAgiIgZAAQgtgUg5gFIAAg6IAHAAIAAhXIgHAAIAAkHIgtAAIAAEHIgGAAIAABXg");
	this.shape_126.setTransform(36.9,136.3);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#EAD2B2").s().p("AgCAQIAAgfIAFAAIAAAfg");
	this.shape_127.setTransform(50.3,158.1);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#F4E8D9").s().p("AgCAQIAAgfIAFAAIAAAfg");
	this.shape_128.setTransform(49.5,158.1);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgCAQIAAgfIAFAAIAAAfg");
	this.shape_129.setTransform(48.7,158.1);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AgBAQIAAgfIADAAIAAAfg");
	this.shape_130.setTransform(48.4,158.1);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#F4E8D9").s().p("AgBAQIAAgfIADAAIAAAfg");
	this.shape_131.setTransform(47.9,158.1);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#EAD2B2").s().p("AgBAQIAAgfIADAAIAAAfg");
	this.shape_132.setTransform(47.3,158.1);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#DFBC8B").s().p("AgBAQIAAgfIADAAIAAAfg");
	this.shape_133.setTransform(46.7,158.1);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#D4A564").s().p("AgBAQIAAgfIADAAIAAAfg");
	this.shape_134.setTransform(46.1,158.1);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#D4A564").s().p("AgCAQIAAgfIAFAAIAAAfg");
	this.shape_135.setTransform(45.9,158.1);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#C99953").s().p("AgCAQIAAgfIAFAAIAAAfg");
	this.shape_136.setTransform(45.2,158.1);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#BE8E44").s().p("AgCAQIAAgfIAFAAIAAAfg");
	this.shape_137.setTransform(44.6,158.1);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#B38238").s().p("AgCAQIAAgfIAFAAIAAAfg");
	this.shape_138.setTransform(43.9,158.1);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#A8772C").s().p("AgCAQIAAgfIAFAAIAAAfg");
	this.shape_139.setTransform(43.2,158.1);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#A8772C").s().p("AgBAQIAAgfIADAAIAAAfg");
	this.shape_140.setTransform(43.1,158.1);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#B38238").s().p("AgBAQIAAgfIADAAIAAAfg");
	this.shape_141.setTransform(42.6,158.1);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#BE8E44").s().p("AgBAQIAAgfIADAAIAAAfg");
	this.shape_142.setTransform(42.1,158.1);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#C99953").s().p("AgBAQIAAgfIADAAIAAAfg");
	this.shape_143.setTransform(41.6,158.1);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#D4A564").s().p("AgBAQIAAgfIADAAIAAAfg");
	this.shape_144.setTransform(41.1,158.1);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#D4A564").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_145.setTransform(40.8,158.1);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#D8B278").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_146.setTransform(39.8,158.1);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#DDBE8D").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_147.setTransform(38.8,158.1);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#E2CAA2").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_148.setTransform(37.8,158.1);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#E6D6B7").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_149.setTransform(36.8,158.1);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#EAE2CB").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_150.setTransform(35.8,158.1);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#EAE2CB").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_151.setTransform(35.3,158.1);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#E3D4B4").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_152.setTransform(34.3,158.1);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#DCC69C").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_153.setTransform(33.4,158.1);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#D5B984").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_154.setTransform(32.4,158.1);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#CEAB6C").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_155.setTransform(31.4,158.1);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#C79E55").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_156.setTransform(30.4,158.1);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#C09140").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_157.setTransform(29.5,158.1);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#C09140").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_158.setTransform(29,158.1);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#BC8D3D").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_159.setTransform(28,158.1);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#B9893A").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_160.setTransform(27,158.1);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#B58637").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_161.setTransform(26,158.1);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#B28234").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_162.setTransform(25,158.1);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#AF7F32").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_163.setTransform(24.1,158.1);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#AB7B2F").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_164.setTransform(23.1,158.1);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#F4E8D9").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_165.setTransform(38.7,133.7);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_166.setTransform(38.5,133.7);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FFFFFF").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_167.setTransform(38.8,133.7);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#F4E8D9").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_168.setTransform(38.6,133.7);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#EAD2B2").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_169.setTransform(38.5,133.7);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#DFBC8B").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_170.setTransform(38.3,133.7);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#D4A564").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_171.setTransform(38.1,133.7);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#D4A564").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_172.setTransform(38.4,133.7);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#C99953").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_173.setTransform(38.3,133.7);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#BE8E44").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_174.setTransform(38.1,133.7);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#B38238").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_175.setTransform(37.9,133.7);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#A8772C").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_176.setTransform(37.7,133.7);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#A8772C").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_177.setTransform(38,133.7);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#B38238").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_178.setTransform(37.8,133.7);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#BE8E44").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_179.setTransform(37.7,133.7);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#C99953").s().p("AAADQIAAmfIAAAAIAAGfg");
	this.shape_180.setTransform(37.5,133.7);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#D4A564").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_181.setTransform(37.3,133.7);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#D4A564").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_182.setTransform(37.7,133.7);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#DAB57E").s().p("AAADQIAAmfIAAAAIAAGfg");
	this.shape_183.setTransform(37.4,133.7);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#DFC498").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_184.setTransform(37.1,133.7);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#E5D3B2").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_185.setTransform(36.9,133.7);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#EAE2CB").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_186.setTransform(36.6,133.7);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#EAE2CB").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_187.setTransform(36.8,133.7);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#E0CDA8").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_188.setTransform(36.5,133.7);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#D5B984").s().p("AAADQIAAmfIAAAAIAAGfg");
	this.shape_189.setTransform(36.3,133.7);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#CBA561").s().p("AAADQIAAmfIAAAAIAAGfg");
	this.shape_190.setTransform(36,133.7);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#C09140").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_191.setTransform(35.7,133.7);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#C09140").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_192.setTransform(35.9,133.7);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#BA8A3B").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_193.setTransform(35.5,133.7);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#B48436").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_194.setTransform(35.2,133.7);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#AE7E31").s().p("AAADQIAAmfIABAAIAAGfg");
	this.shape_195.setTransform(34.9,133.7);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#515E5F").s().p("AgEAKQAAgPAEgEQACACACAHIAAAKg");
	this.shape_196.setTransform(36.9,112);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#536262").s().p("AgEALQAAgQAEgFQAFAFAAAQg");
	this.shape_197.setTransform(36.9,111.9);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#566664").s().p("AgEAMQAAgSAEgFQAFAFAAASg");
	this.shape_198.setTransform(36.9,111.9);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#596A67").s().p("AgEAMQAAgTAEgEQAFAEAAATg");
	this.shape_199.setTransform(36.9,111.8);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#5B6E6A").s().p("AgEANQAAgUAEgFQACADACAJQABAJAAAEg");
	this.shape_200.setTransform(36.9,111.7);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#5E726D").s().p("AgEANQAAgUAEgFQAGAFgBAUg");
	this.shape_201.setTransform(36.9,111.7);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#617670").s().p("AgEAOQAAgWAEgFQAGAFgBAWg");
	this.shape_202.setTransform(36.9,111.6);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#647A73").s().p("AgEAPQAAgXAEgFQAGAFgBAXg");
	this.shape_203.setTransform(36.9,111.6);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#677F76").s().p("AgFAPQAAgYAFgFQADADABALQACALgBAEg");
	this.shape_204.setTransform(36.9,111.5);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#698379").s().p("AgFAQIACgQQABgMACgDQADADACAMIABAQg");
	this.shape_205.setTransform(36.9,111.4);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#6D877C").s().p("AgFAQQAAgaAFgFQAGAFAAAag");
	this.shape_206.setTransform(36.9,111.4);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#708C7F").s().p("AgFARQAAgbAFgGQAGAGAAAbg");
	this.shape_207.setTransform(36.9,111.3);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#708C7F").s().p("AgFARQAAgbAFgGQAGAGAAAbg");
	this.shape_208.setTransform(36.9,111.3);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#749081").s().p("AgFASIABgSQACgOACgDQADADACAOIABASg");
	this.shape_209.setTransform(36.9,111.2);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#789482").s().p("AgGATIACgTQACgOACgEQAEAEABAOIACATg");
	this.shape_210.setTransform(36.9,111.1);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#7C9984").s().p("AgGAUIABgUQACgPADgEQADAEADAPQABAOAAAGg");
	this.shape_211.setTransform(36.9,111);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#819D85").s().p("AgGAVIABgVQACgQADgEQADAEADAQIABAVg");
	this.shape_212.setTransform(36.9,110.9);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#85A287").s().p("AgHAWIACgWQACgRADgEQAEAEACARIACAWg");
	this.shape_213.setTransform(36.9,110.8);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#89A688").s().p("AgIAXIACgXQACgSAEgEQAFAEACASIABAXg");
	this.shape_214.setTransform(36.9,110.7);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#8EAB8A").s().p("AgIAYIACgYQACgTAEgEQAEAEADATQACARgBAHg");
	this.shape_215.setTransform(36.9,110.6);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#92AF8B").s().p("AgIAZQAAgLACgOQACgUAEgEQAEAEADAUQACASAAAHg");
	this.shape_216.setTransform(36.9,110.5);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#96B48D").s().p("AgJAaQAAgKADgQQADgVADgEQAFAEACAVQACAPABALg");
	this.shape_217.setTransform(36.9,110.4);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#9BB88E").s().p("AgJAbQAAgLACgQQADgWAEgEQAFAEADAWQACAQAAALg");
	this.shape_218.setTransform(36.9,110.3);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#9FBD90").s().p("AgKAdIADgdQADgXAEgFQAGAFACAXQADAQAAANg");
	this.shape_219.setTransform(36.9,110.2);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#A3C191").s().p("AgKAeQAAgNACgRQAEgXAEgGQAFAGADAXQADAVgBAJg");
	this.shape_220.setTransform(36.9,110.1);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#A8C692").s().p("AgKAfQAAgOACgRQADgZAFgFQAFAFAEAZQACAVAAAKg");
	this.shape_221.setTransform(36.9,110);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#ACCB94").s().p("AgLAgQABgOACgSQADgZAFgFQAGAFAEAZQACASAAAOg");
	this.shape_222.setTransform(36.9,109.9);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#B1D095").s().p("AgLAhQAAgOACgTQAEgaAFgFQAGAFAEAaQACATAAAOg");
	this.shape_223.setTransform(36.9,109.8);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#B5D497").s().p("AgLAiQAAgPACgTQAEgbAFgGQAGAHAEAaQACAWAAAMg");
	this.shape_224.setTransform(36.9,109.7);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#B5D497").s().p("AgLAiQAAgPACgTQAEgbAFgGQAGAHAEAaQACAWAAAMg");
	this.shape_225.setTransform(36.9,109.7);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#B5D497").s().p("AgLAiQAAgPACgTQAEgbAFgGQAGAHAEAaQACAWAAAMg");
	this.shape_226.setTransform(36.9,109.7);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#B3D29F").s().p("AgMAjQgBgHABgQQAEgmAIgIQAJAIAEAnQABARgBAFg");
	this.shape_227.setTransform(36.9,109.5);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#B1CFA7").s().p("AgNAlQgBgLABgOQABgOAEgNQAEgQAEgFQAMAKADAnQAAAOgBAKg");
	this.shape_228.setTransform(36.9,109.3);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#AFCDAF").s().p("AgOAnQgCgJABgSQABgNAEgOQAFgRAFgGQANAMADAnQABASgDAIg");
	this.shape_229.setTransform(36.9,109.2);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#ADCAB6").s().p("AgPAoQgCgIABgUQABgNAEgPQAFgRAGgGQAHAGAFARQAEAPABAOQABASgDAJg");
	this.shape_230.setTransform(36.9,109);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#ABC7BD").s().p("AgPAqQgEgKABgTQABgOAFgQQAFgRAHgHQAHAHAGASQAFAPABAOQAAAVgDAIg");
	this.shape_231.setTransform(36.9,108.8);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#AAC5C3").s().p("AgQArQgEgKABgUQAAgPAGgPQAFgRAIgIQAIAIAGARQAFAQABAOQAAAVgDAJg");
	this.shape_232.setTransform(36.9,108.7);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#A8C2CA").s().p("AgRAtQgFgLABgVQABgOAFgRQAHgSAIgIQAJAIAGASQAGAQABAQQAAAUgFALg");
	this.shape_233.setTransform(36.9,108.5);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#A6BFCF").s().p("AgSAvQgFgOABgUQAAgPAHgRQAGgRAJgKQAKAKAGARQAHASAAAOQABAUgFAOg");
	this.shape_234.setTransform(36.9,108.4);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#A5BCD4").s().p("AgSAwQgHgNACgWQgBgPAHgRQAIgSAJgKQAKAKAIASQAGARAAAPQACAWgHANg");
	this.shape_235.setTransform(36.9,108.2);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#A3B9D9").s().p("AgTAyQgGgOAAgXQAAgPAHgSQAHgSALgLQALALAIASQAHASAAAPQABAVgHAQg");
	this.shape_236.setTransform(36.9,108);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#A1B6DD").s().p("AgUA0QgGgQgBgWQAAgQAIgSQAIgTALgMQANAMAHATQAIASAAAQQgBAYgGAOg");
	this.shape_237.setTransform(36.9,107.9);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#A1B6DD").s().p("AgUA0QgGgQgBgWQAAgQAIgSQAIgTALgMQANAMAHATQAIASAAAQQgBAYgGAOg");
	this.shape_238.setTransform(36.9,107.9);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#AEBFE2").s().p("AgUA0QgHgOAAgaQAAgPAIgSQAHgSAMgMQAMAMAIASQAIASAAAPQAAAZgHAPg");
	this.shape_239.setTransform(36.9,107.8);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#BAC8E6").s().p("AgUA0QgHgPAAgaQAAgQAHgRQAIgSAMgLQAMALAJASQAHARAAAQQAAAagHAPg");
	this.shape_240.setTransform(36.9,107.8);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#C6D1EB").s().p("AgUA1QgHgQAAgbQAAgkAbgaQAcAaAAAkQAAAbgHAQg");
	this.shape_241.setTransform(36.9,107.7);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#D1DAEF").s().p("AgUA1QgHgPAAgdQAAgiAbgbQAcAbAAAiQAAAdgHAPg");
	this.shape_242.setTransform(36.9,107.7);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#DDE3F3").s().p("AgUA2QgHgRAAgdQAAghAbgcQAcAcAAAhQAAAdgHARg");
	this.shape_243.setTransform(36.9,107.6);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#E8ECF8").s().p("AgUA2QgDgHgCgQQgCgOAAgLQAAggAbgbQAcAbAAAgQAAAggHAQg");
	this.shape_244.setTransform(36.9,107.6);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#F4F6FC").s().p("AgUA3QgDgIgCgQQgCgPAAgLQAAgfAbgcQAcAcAAAfQAAAhgHARg");
	this.shape_245.setTransform(36.9,107.5);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#FFFFFF").s().p("AgUA3QgDgHgDgSQgCgPAAgLQABgQAHgPQAHgMANgPQAPAPAGAMQAIAPAAAQQAAALgDAPQgCASgDAHg");
	this.shape_246.setTransform(36.9,107.5);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#515E5F").s().p("AgQArIgLhVIA3AAIgLBVg");
	this.shape_247.setTransform(38.9,37.5);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#4F5D5E").s().p("AgQArIgMhVIA5AAIgLBVg");
	this.shape_248.setTransform(38.8,37.5);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#4E5C5D").s().p("AgSArIgLhVIA7AAIgLBVg");
	this.shape_249.setTransform(38.8,37.5);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#4D5B5C").s().p("AgUArIgKhVIA9AAIgLBVg");
	this.shape_250.setTransform(38.7,37.5);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#4C5A5B").s().p("AgVArIgLhVIBBAAIgMBVg");
	this.shape_251.setTransform(38.7,37.5);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#4A595A").s().p("AgWArIgLhVIBDAAIgLBVg");
	this.shape_252.setTransform(38.6,37.5);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#49585A").s().p("AgWArIgMhVIBFAAIgLBVg");
	this.shape_253.setTransform(38.5,37.5);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#485859").s().p("AgYArIgLhVIBHAAIgLBVg");
	this.shape_254.setTransform(38.5,37.5);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#465758").s().p("AgaArIgKhVIBJAAIgLBVg");
	this.shape_255.setTransform(38.4,37.5);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#455657").s().p("AgbArIgLhVIBNAAIgLBVg");
	this.shape_256.setTransform(38.4,37.5);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#445556").s().p("AgcArIgLhVIBPAAIgLBVg");
	this.shape_257.setTransform(38.3,37.5);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#435455").s().p("AgcArIgMhVIBRAAIgLBVg");
	this.shape_258.setTransform(38.2,37.5);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#415355").s().p("AgeArIgLhVIBTAAIgLBVg");
	this.shape_259.setTransform(38.2,37.5);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#405354").s().p("AggArIgKhVIBWAAIgMBVg");
	this.shape_260.setTransform(38.1,37.5);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#3F5253").s().p("AghArIgLhVIBYAAIgKBVg");
	this.shape_261.setTransform(38.1,37.5);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#3D5152").s().p("AgiArIgLhVIBbAAIgLBVg");
	this.shape_262.setTransform(38,37.5);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#3C5051").s().p("AgiArIgMhVIBdAAIgLBVg");
	this.shape_263.setTransform(37.9,37.5);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#3B5051").s().p("AgkArIgLhVIBfAAIgLBVg");
	this.shape_264.setTransform(37.9,37.5);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#3A4F50").s().p("AgmArIgKhVIBhAAIgLBVg");
	this.shape_265.setTransform(37.8,37.5);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#384E4F").s().p("AgnArIgLhVIBlAAIgMBVg");
	this.shape_266.setTransform(37.8,37.5);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#374D4E").s().p("AgoArIgLhVIBnAAIgLBVg");
	this.shape_267.setTransform(37.7,37.5);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#364D4E").s().p("AgoArIgMhVIBpAAIgLBVg");
	this.shape_268.setTransform(37.6,37.5);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#344C4D").s().p("AgqArIgLhVIBrAAIgLBVg");
	this.shape_269.setTransform(37.6,37.5);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#334B4C").s().p("AgsArIgKhVIBtAAIgLBVg");
	this.shape_270.setTransform(37.5,37.5);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#324A4B").s().p("AgtArIgLhVIBxAAIgLBVg");
	this.shape_271.setTransform(37.5,37.5);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#304A4B").s().p("AguArIgLhVIBzAAIgLBVg");
	this.shape_272.setTransform(37.4,37.5);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#2F494A").s().p("AguArIgMhVIB1AAIgLBVg");
	this.shape_273.setTransform(37.3,37.5);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#2E4849").s().p("AgwArIgLhVIB3AAIgLBVg");
	this.shape_274.setTransform(37.3,37.5);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#2C4748").s().p("AgyArIgKhVIB6AAIgMBVg");
	this.shape_275.setTransform(37.2,37.5);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#2B4748").s().p("AgzArIgLhVIB8AAIgLBVg");
	this.shape_276.setTransform(37.2,37.5);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#294647").s().p("Ag0ArIgLhVIB/AAIgLBVg");
	this.shape_277.setTransform(37.1,37.5);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#284546").s().p("Ag0ArIgMhVICBAAIgLBVg");
	this.shape_278.setTransform(37,37.5);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#264546").s().p("Ag2ArIgLhVICDAAIgLBVg");
	this.shape_279.setTransform(37,37.5);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f().s("#C3493A").ss(0.2,0,0,3.9).p("AAIA3IgOAAAAIAzIgIAAAAIAuIgIAAAAIAqIgIAAAAIAlIgIAAAAIAhIgIAAAAIAcIgIAAAAIAZIgIAAAAIAUIgIAAAAIAPIgIAAAAIALIgOAAAAIAGIgIAAAAIACIgIAAAAIgBIgIAAAAIgFIgIAAAAIgKIgIAAAAIgOIgIAAAAIgTIgIAAAAIgXIgIAAAAIgcIgIAAAAIggIgOAAAAIglIgIAAAAIgpIgIAAAAIguIgIAAAAIgyIgIAAAAIg3IgIAA");
	this.shape_280.setTransform(37.4,31.6);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f().s("#C3493A").ss(0.2,0,0,3.9).p("AAIg7IgIAAAAIg/IgIAAAAIhEIgIAAAAIhIIgIAAAAIhNIgIAAAAIhRIgIAAAAIhWIgIAAAAIhaIgIAAAAIhfIgIAAAAIBgIgIAAAAIBbIgIAAAAIBXIgIAAAAIBSIgIAAAAIBOIgOAAAAIBJIgIAAAAIBFIgIAAAAIBAIgIAAAAIA8IgIAAAAIA3IgIAAAAIAzIgIAAAAIAvIgIAAAAIAqIgIAAAAIAmIgIAAAAIAhIgOAAAAIAdIgIAAAAIAYIgIAAAAIAUIgIAAAAIAPIgIAAAAIALIgIAAAAIAGIgIAAAAIACIgIAAAAIgBIgIAAAAIgFIgIAAAAIgKIgOAAAAIgOIgIAAAAIgTIgIAAAAIgXIgIAAAAIgcIgIAAAAIggIgIAAAAIglIgIAAAAIgpIgIAAAAIgtIgIAAAAIgyIgIAAAAIg2IgOAA");
	this.shape_281.setTransform(37.4,16.3);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f().s("#357D8C").ss(0.2,0,0,3.9).p("AA/jmIAADWQAAARASAKIADAAQA0AWAgAtQAgAuAAA4QAABEgvAzQgJAJgOAFQgKAEgKAAIjdAAQgYAAgSgTQgug0AAhCQAAg3AfgtQAfgsA0gXQAXgMAAgQIAAkQQAAgKgMgGQgEgCAAgEQAAgHAIAAICOAAQAIAAAAAHQAAAEgFACQgMAFAAANQAAAaABAA");
	this.shape_282.setTransform(36.9,68.7);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#DCE2E7").s().p("AAHAcQgJgFgKgLQgKgMgDgKQgDgMAFgFQAGgFALAFQAJAFAKAMQAKAKADALQADAMgFAFQgDACgFAAQgEAAgFgCg");
	this.shape_283.setTransform(39.9,80.3);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#DAE0E5").s().p("AAHAeQgJgFgLgNQgLgMgDgLQgEgNAHgFQAGgFAMAFQAJAFALAMQALAMADAMQAEAMgHAGQgDACgEAAQgFAAgGgCg");
	this.shape_284.setTransform(39.9,80.3);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#D8DFE4").s().p("AAIAgQgLgFgLgOQgLgNgEgMQgEgNAHgGQAGgFANAFQALAGALANQAMAMADANQAEANgHAGQgDADgFAAQgFAAgGgDg");
	this.shape_285.setTransform(39.9,80.3);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#D6DDE2").s().p("AAJAiQgMgGgMgOQgMgOgEgMQgEgOAHgHQAHgGANAGQAMAGAMAOQAMANAEANQAEAPgHAGQgDADgFAAQgFAAgHgDg");
	this.shape_286.setTransform(39.9,80.4);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#D3DBE0").s().p("AAJAkQgMgGgNgPQgNgPgEgNQgEgPAHgHQAHgGAPAGQAMAGANAPQANAOAEAOQAEAPgHAHQgEADgGAAQgFAAgHgDg");
	this.shape_287.setTransform(39.9,80.4);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#D1D9DF").s().p("AAJAnQgNgHgNgQQgOgQgEgOQgEgQAHgHQAIgHAPAHQANAHAOAQQANAOAFAQQAEAQgIAGQgEADgGAAQgFAAgIgCg");
	this.shape_288.setTransform(40,80.4);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#CFD8DD").s().p("AAKAoQgOgGgOgRQgPgRgEgPQgEgRAIgHQAIgHAQAHQAOAHAOAQQAOAQAFAQQAEARgIAHQgEAEgGAAQgGAAgIgEg");
	this.shape_289.setTransform(40,80.4);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#CDD6DC").s().p("AALAqQgPgHgPgRQgPgSgFgQQgEgRAIgIQAJgIAQAIQAPAHAPASQAPAQAFARQAFARgJAIQgEAEgHAAQgGAAgIgEg");
	this.shape_290.setTransform(40,80.5);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#CBD4DA").s().p("AALAsQgPgHgQgTQgQgSgFgRQgEgSAJgIQAIgIASAHQAQAIAPASQAQASAFARQAFATgKAIQgEAEgHAAQgGAAgJgEg");
	this.shape_291.setTransform(40,80.5);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#C9D3D9").s().p("AAMAuQgQgHgRgUQgQgTgGgSQgFgTAJgIQAKgIASAIQAQAIARATQAQASAFASQAGAUgKAIQgFAEgHAAQgGAAgJgEg");
	this.shape_292.setTransform(40,80.5);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#C6D1D7").s().p("AANAwQgRgHgSgVQgRgUgFgSQgGgVAKgIQAKgIATAHQARAIARAVQARATAGATQAFAVgKAIQgFAEgHAAQgHAAgJgEg");
	this.shape_293.setTransform(40,80.6);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#C4CFD6").s().p("AANAyQgSgIgSgVQgSgVgGgTQgFgVAKgJQAKgJAUAIQASAJASAVQASAUAGAUQAFAVgKAJQgFAFgIAAQgHAAgKgFg");
	this.shape_294.setTransform(40.1,80.6);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#C2CED5").s().p("AAOA0QgTgIgTgWQgSgWgGgUQgGgWAKgJQALgJAUAIQATAJATAWQATAVAFAVQAGAVgKAKQgGAFgIAAQgHAAgKgFg");
	this.shape_295.setTransform(40.1,80.6);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#C0CCD3").s().p("AAOA2QgTgJgUgWQgTgXgHgVQgFgWALgKQAKgKAWAJQATAKAUAWQATAWAHAWQAFAXgLAJQgFAFgIAAQgIAAgLgFg");
	this.shape_296.setTransform(40.1,80.6);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#BDCAD2").s().p("AAOA5QgUgKgUgXQgUgYgGgVQgGgYALgKQALgKAWAKQAVAJAUAYQAUAWAGAXQAHAXgMAKQgGAFgJAAQgIAAgLgEg");
	this.shape_297.setTransform(40.1,80.6);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#BBC8D0").s().p("AAPA7QgVgKgVgZQgVgYgGgXQgHgYAMgKQAMgLAXAKQAVAKAVAZQAVAXAGAXQAHAZgMAKQgGAGgJAAQgJAAgLgFg");
	this.shape_298.setTransform(40.1,80.7);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#B9C7CF").s().p("AAPA9QgVgKgWgaQgWgZgGgXQgHgZANgLQAMgLAYAKQAVALAWAZQAVAYAHAYQAHAagNAKQgGAGgJAAQgJAAgMgFg");
	this.shape_299.setTransform(40.2,80.7);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f().s("#357D8C").ss(0.2,0,0,3.9).p("ABuAPIAABiQACABgbAYQgXAUgBADIAAiSQgDgsgigOIgTgHQgGgCgLgBQgLgBgDAAIg1ABQgMAAgGAHQgDADgEgBQgHgCACgGIAgh1QACgFAGACQAFABABADQABAGAPAIIAsAYQARAIADABIAeALQAlAQANAbQAOAbgBA3gAgth1QAHACgCAEIgHAYQgBAEgFgBIgCAA");
	this.shape_300.setTransform(231,99.6);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f().s("#508796").ss(0.2,0,0,3.9).p("AAVACIgpgD");
	this.shape_301.setTransform(222.6,93.3);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f().s("#DCE2E7").ss(0.2,0,0,3.9).p("AgKgCIAVAG");
	this.shape_302.setTransform(226,84.9);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#637F86").s().p("AgYAOIAMghIAlAPIgIAYg");
	this.shape_303.setTransform(224,87.2);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#607E85").s().p("AgYAQIAMgkIAlAQIgIAZg");
	this.shape_304.setTransform(224,87.2);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#5E7D85").s().p("AgYAQIAMglIAlAQIgIAbg");
	this.shape_305.setTransform(224,87.3);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#5B7C84").s().p("AgYARIAMgnIAmAQIgJAdg");
	this.shape_306.setTransform(224,87.3);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#587C84").s().p("AgZASIAOgoIAlAPIgKAeg");
	this.shape_307.setTransform(223.9,87.4);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#567B83").s().p("AgZATIAOgrIAlAQIgKAhg");
	this.shape_308.setTransform(223.9,87.4);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#537A83").s().p("AgaAUIAPgsIAlAPIgKAig");
	this.shape_309.setTransform(223.9,87.5);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#507982").s().p("AgaAVIAQguIAkAQIgKAjg");
	this.shape_310.setTransform(223.9,87.5);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#4D7882").s().p("AgaAWIAQgwIAlAPIgMAmg");
	this.shape_311.setTransform(223.9,87.6);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#4A7882").s().p("AgaAXIAQgyIAlAQIgMAng");
	this.shape_312.setTransform(223.9,87.6);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#477781").s().p("AgaAYIAQg0IAmAQIgOApg");
	this.shape_313.setTransform(223.9,87.6);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#447681").s().p("AgbAZIASg2IAlAQIgNArg");
	this.shape_314.setTransform(223.8,87.7);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#417580").s().p("AgbAZIASg3IAlAQIgOAtg");
	this.shape_315.setTransform(223.8,87.7);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#3E7580").s().p("AgbAbIASg6IAlAQIgOAug");
	this.shape_316.setTransform(223.8,87.8);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#3A747F").s().p("AgbAbIASg6IAlAPIgOAwg");
	this.shape_317.setTransform(223.8,87.8);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#37737F").s().p("AgcAcIATg8IAmAPIgQAyg");
	this.shape_318.setTransform(223.8,87.9);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#33737E").s().p("AgcAdIAUg+IAlAPIgQA0g");
	this.shape_319.setTransform(223.8,87.9);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#30727E").s().p("AgcAeIAUhAIAlAQIgQA1g");
	this.shape_320.setTransform(223.7,88);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#2C717E").s().p("AgdAeIAVhBIAmAPIgSA4g");
	this.shape_321.setTransform(223.8,88);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#27707D").s().p("AgdAgIAVhEIAmAQIgSA5g");
	this.shape_322.setTransform(223.7,88);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#23707D").s().p("AgdAhIAWhGIAlAQIgSA7g");
	this.shape_323.setTransform(223.7,88.1);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#1E6F7C").s().p("AgdAhIAWhHIAlAQIgSA9g");
	this.shape_324.setTransform(223.7,88.1);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#186E7C").s().p("AgeAiIAXhJIAmAQIgTA/g");
	this.shape_325.setTransform(223.7,88.2);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#106E7B").s().p("AgeAkIAXhMIAmAQIgUBAg");
	this.shape_326.setTransform(223.7,88.2);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#056D7B").s().p("AgeAkIAYhMIAlAPIgUBCg");
	this.shape_327.setTransform(223.7,88.3);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#006D7A").s().p("AgeAlIAYhOIAlAPIgUBEg");
	this.shape_328.setTransform(223.6,88.3);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#006C7A").s().p("AgfAmIAZhQIAmAPIgVBGg");
	this.shape_329.setTransform(223.6,88.4);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#006B79").s().p("AgfAmIAZhRIAmAQIgWBHg");
	this.shape_330.setTransform(223.6,88.4);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#006B79").s().p("AgfAoIAahUIAlAPIgWBKg");
	this.shape_331.setTransform(223.6,88.5);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#006A79").s().p("AggApIAbhWIAmAQIgXBLg");
	this.shape_332.setTransform(223.6,88.5);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#006978").s().p("AggApIAbhXIAmAQIgXBNg");
	this.shape_333.setTransform(223.6,88.5);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#006978").s().p("AggAqIAchZIAlAQIgYBPg");
	this.shape_334.setTransform(223.6,88.6);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#006877").s().p("AggArIAchaIAlAPIgYBQg");
	this.shape_335.setTransform(223.5,88.6);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f().s("#7D9FAB").ss(0.2,0,0,3.9).p("AALgoIgVBR");
	this.shape_336.setTransform(226,89.4);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#8AA0A8").s().p("AghAqIAbhZIAoAPIgYBQg");
	this.shape_337.setTransform(223.7,88.6);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f().s("#264546").ss(0.3,0,0,3.9).p("AAEA0IgggEIAchhQAfAMAAgB");
	this.shape_338.setTransform(219.6,87.6);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#515E5F").s().p("AgpAPIAMgoIBHAZIgHAag");
	this.shape_339.setTransform(222.2,86.6);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#4F5D5E").s().p("AgqAQIANgpIBIAZIgIAbg");
	this.shape_340.setTransform(222.2,86.7);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#4E5C5D").s().p("AgqARIANgsIBIAbIgIAbg");
	this.shape_341.setTransform(222.2,86.7);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#4D5B5C").s().p("AgqASIANguIBJAbIgJAeg");
	this.shape_342.setTransform(222.2,86.8);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#4C5A5B").s().p("AgqATIANgvIBJAbIgKAeg");
	this.shape_343.setTransform(222.2,86.8);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#4A595A").s().p("AgrAUIAPgxIBIAbIgKAgg");
	this.shape_344.setTransform(222.1,86.8);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#49585A").s().p("AgrAUIAPgyIBIAbIgLAig");
	this.shape_345.setTransform(222.1,86.9);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#485859").s().p("AgsAWIAQg1IBIAcIgKAjg");
	this.shape_346.setTransform(222.1,86.9);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#465758").s().p("AgsAWIARg2IBIAbIgMAmg");
	this.shape_347.setTransform(222.1,87);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#455657").s().p("AgsAXIARg4IBIAbIgMAog");
	this.shape_348.setTransform(222.1,87);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#445556").s().p("AgsAYIARg6IBIAbIgNAqg");
	this.shape_349.setTransform(222.1,87.1);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#435455").s().p("AgsAZIASg7IBIAbIgOArg");
	this.shape_350.setTransform(222.1,87.1);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#415355").s().p("AgtAaIATg9IBIAaIgOAtg");
	this.shape_351.setTransform(222,87.2);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#405354").s().p("AgtAbIATg/IBIAbIgOAug");
	this.shape_352.setTransform(222,87.2);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#3F5253").s().p("AgtAcIAThBIBIAbIgPAwg");
	this.shape_353.setTransform(222,87.2);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#3D5152").s().p("AgtAdIAThDIBIAbIgPAyg");
	this.shape_354.setTransform(222,87.3);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#3C5051").s().p("AguAdIAVhEIBIAbIgQA0g");
	this.shape_355.setTransform(222,87.3);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#3B5051").s().p("AguAfIAWhHIBHAcIgQA1g");
	this.shape_356.setTransform(222,87.4);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#3A4F50").s().p("AguAfIAVhIIBIAbIgRA4g");
	this.shape_357.setTransform(222,87.4);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#384E4F").s().p("AgvAgIAXhJIBIAbIgSA4g");
	this.shape_358.setTransform(222,87.5);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#374D4E").s().p("AgvAhIAXhMIBIAbIgSA8g");
	this.shape_359.setTransform(221.9,87.5);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#364D4E").s().p("AgvAiIAXhNIBIAbIgSA9g");
	this.shape_360.setTransform(221.9,87.6);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#344C4D").s().p("AgvAiIAXhPIBIAcIgTA+g");
	this.shape_361.setTransform(221.9,87.6);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#334B4C").s().p("AgvAkIAXhRIBIAbIgTBAg");
	this.shape_362.setTransform(221.9,87.6);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#324A4B").s().p("AgwAlIAZhTIBIAbIgUBCg");
	this.shape_363.setTransform(221.9,87.7);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#304A4B").s().p("AgwAlIAahUIBHAbIgUBEg");
	this.shape_364.setTransform(221.9,87.7);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#2F494A").s().p("AgwAmIAahWIBHAbIgUBGg");
	this.shape_365.setTransform(221.9,87.8);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#2E4849").s().p("AgwAoIAahZIBHAcIgVBHg");
	this.shape_366.setTransform(221.9,87.8);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#2C4748").s().p("AgxAoIAbhaIBIAbIgWBKg");
	this.shape_367.setTransform(221.8,87.9);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#2B4748").s().p("AgxApIAbhbIBIAbIgWBKg");
	this.shape_368.setTransform(221.8,87.9);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#294647").s().p("AgyAqIAcheIBJAbIgYBOg");
	this.shape_369.setTransform(221.8,88);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#284546").s().p("AgyAqIAcheIBJAbIgYBPg");
	this.shape_370.setTransform(221.8,88);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#264546").s().p("AgyAsIAdhhIBIAbIgYBQg");
	this.shape_371.setTransform(221.8,88);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f().s("#357D8C").ss(0.2,0,0,3.9).p("Ah/gsIDDAvIAAgDQACgCAEABIAuANQAFABgCAFIgHAXQgBAFgFgBIgvgIQgFgBABgFIABgCIi7gt");
	this.shape_372.setTransform(54,46.7);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#B9C7CF").s().p("AARASIgogHQgEgBABgEIAGgUQABgEAFABIAmAOQAEABgBACIgFAPQAAADgDAAIgCAAg");
	this.shape_373.setTransform(63.2,48.6);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#B4C3CB").s().p("AARASIgogHQgFgBACgEIAGgUQABgEAFABIAmANQAEABgBADIgFAPQAAABAAABQAAAAgBABQAAAAgBAAQgBAAAAAAIgCAAg");
	this.shape_374.setTransform(63.2,48.6);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#AEBFC8").s().p("AARASIgogGQgFgCACgDIAGgWQACgEAEABIAmAOQAFABgBADIgGAQQAAABAAAAQAAABgBAAQAAABAAAAQgBAAgBAAIgCgBg");
	this.shape_375.setTransform(63.2,48.6);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#A9BCC5").s().p("AASATIgpgHQgFgBACgEIAGgWQACgDAEAAIAmAOQAFABgBADIgFAQQgBADgDAAIgBAAg");
	this.shape_376.setTransform(63.2,48.6);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#A4B8C2").s().p("AASATIgqgHQgEgBABgEIAHgWQABgEAFABIAnAOQAEABgBADIgFAQQgBADgDAAIgBAAg");
	this.shape_377.setTransform(63.2,48.6);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#9FB5BF").s().p("AASATIgqgHQgEgBABgEIAHgXQABgEAFACIAnANQAFACgCADIgFAQQAAABAAABQgBAAAAABQgBAAAAAAQgBABgBAAIgBgBg");
	this.shape_378.setTransform(63.2,48.6);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#9AB1BC").s().p("AARAUIgqgHQgDgCAAgEIAIgXQABgEAEABIAoAOQAEACgBADIgFARQgBADgDAAIgCAAg");
	this.shape_379.setTransform(63.2,48.6);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#95AEB9").s().p("AASAUIgqgHQgFgBABgFIAIgXQABgEAFABIAoAOQAEABgBAEIgGARQAAABAAAAQgBABAAAAQgBABAAAAQgBAAgBAAIgBAAg");
	this.shape_380.setTransform(63.2,48.7);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#90ABB6").s().p("AASAUIgrgHQgEgBABgEIAIgYQABgEAEABIApAOQAEABgBAEIgGARQgBADgDAAIgBAAg");
	this.shape_381.setTransform(63.2,48.7);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#8BA7B3").s().p("AASAUIgrgHQgEgBABgEIAIgZQABgEAEABIApAPQAEABgBAEIgFARQgCAEgCAAIgCgBg");
	this.shape_382.setTransform(63.2,48.7);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#85A4B0").s().p("AARAVIgrgHQgDgCAAgEIAIgZQABgEAFABIApAPQAFABgCAEIgGASQgBADgDAAIgCAAg");
	this.shape_383.setTransform(63.2,48.7);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#7FA1AD").s().p("AASAVIgrgIQgFgBABgDIAIgaQACgEAEABIApAOQAFABgBAFIgGASQgBADgDAAIgCAAg");
	this.shape_384.setTransform(63.2,48.7);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#7A9DAA").s().p("AASAVIgrgHQgFgBABgFIAIgZQABgFAFACIAqAOQAFABgCAEIgGATQgBABAAABQAAAAgBABQAAAAgBAAQgBABAAAAIgCgBg");
	this.shape_385.setTransform(63.2,48.7);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#749AA7").s().p("AASAWIgsgIQgEgBABgEIAIgbQABgEAFABIAqAPQAEABgBAEIgGAUQAAABgBAAQAAABgBAAQAAABgBAAQAAAAgBAAIgCAAg");
	this.shape_386.setTransform(63.2,48.7);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#6E97A4").s().p("AASAWIgsgHQgFgCACgEIAIgbQABgEAFABIAqAPQAEACgBADIgGAUQgBADgDAAIgCAAg");
	this.shape_387.setTransform(63.2,48.7);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#6894A1").s().p("AASAWIgsgIQgFgBABgEIAJgbQACgFAEACIAqAPQAFABgCAEIgGAUQgBADgDAAIgCAAg");
	this.shape_388.setTransform(63.2,48.8);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#62919E").s().p("AASAWIgsgHQgGgBACgFIAJgbQABgFAFABIAqAPQAFABgBAFIgHAUQgBAEgDAAIgCgBg");
	this.shape_389.setTransform(63.2,48.8);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#5C8E9C").s().p("AASAXIgtgIQgEgBABgEIAJgdQABgEAFABIAqAPQAGABgCAFIgHAVQAAADgEAAIgCAAg");
	this.shape_390.setTransform(63.2,48.8);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#568A99").s().p("AASAXIgtgHQgFgCACgEIAJgdQABgEAFABIArAPQAEABgBAFIgHAVQAAADgEAAIgCAAg");
	this.shape_391.setTransform(63.2,48.8);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#508796").s().p("AASAYIgtgIQgFgBABgFIAJgdQACgEAEAAIAsAQQAFABgCAFIgHAVQAAAEgEAAIgCAAg");
	this.shape_392.setTransform(63.2,48.8);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#DCE2E7").s().p("ABUCEIAAhcQAAgzgRgYQgJgOgZgLIgagJQgXgIgDAAIhJgLIALgsIBCAtQAIAEAoAMQAlAQAMAUQALAVAAA1IAABdIgBABIgIgBg");
	this.shape_393.setTransform(230.8,97.8);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#D8DFE4").s().p("ABTAmQABgvgRgYQgLgOgYgKIgZgJQgXgIgDABIhLgKIAOg0IBCAtQAIADAoANQAmAQALAVQAMAVgBA2IAABdQADABgOAEg");
	this.shape_394.setTransform(230.7,97.9);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#D3DBE0").s().p("ABSAkQABgsgRgWQgLgPgXgKIgZgIQgXgIgDAAIhMgIIAQg7IBDAsQAIAEAoAOQAlAPAMAVQAMAWgBA1IAABfQADABgRAIg");
	this.shape_395.setTransform(230.7,98.1);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#CFD8DD").s().p("ABRAiQAAgogQgWQgMgQgWgJIgYgIQgYgHgDABIhMgHIAShDIBCAsIAxARQAlAQAMAVQAMAXgBA1IAABfQABABgJAHIgIAGg");
	this.shape_396.setTransform(230.7,98.2);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#CBD4DA").s().p("ABQAgQgBg/gxgUIgYgHQgXgGgDAAIhOgFIAUhLIBDArQAIAEApAPQAlAPAMAWQAMAXgBA1IAABgQACABgLAJIgJAIg");
	this.shape_397.setTransform(230.7,98.3);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#C6D1D7").s().p("ABPAdQgBg6gwgTIgYgHQgXgGgDAAIhPgDIAWhTIBEAqQAIAFApAOQAlAQAMAXQAMAWgBA2IAABgQACABgNAMIgKALg");
	this.shape_398.setTransform(230.6,98.4);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#C2CED5").s().p("ABOAbQgBgcgPgUQgNgRgUgJIgYgFQgWgGgDABIhQgDIAYhbIBDArIAyAUQAlAPAMAXQAMAXgBA2IAABhQABABgNAOIgLANg");
	this.shape_399.setTransform(230.6,98.5);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#BDCAD2").s().p("ABNAZQgBgZgPgTQgNgRgTgIIgxgKIhRgBIAahjIBEArQAHAEArAQQAkAPAMAYQAMAXgBA2IAABiQACABgOAQIgNAPg");
	this.shape_400.setTransform(230.6,98.6);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#B9C7CF").s().p("ABMAXQgCgWgOgRQgOgSgSgJIgYgEQgWgEgDAAIhSAAIAdhqIBEAqIAyAUQAkAQAMAYQAMAYgBA2IABBjQABAAgPATIgOARg");
	this.shape_401.setTransform(230.6,98.8);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#B9C7CF").s().p("AA9AVQgDgsgigOIgTgHIgRgDIgOAAIg1AAQgMAAgGAHQgDADgEgBQgHgBACgHIAgh0QACgGAGACQAFACABACQABAHAPAHIAsAZIAUAJIAeALQAlAPANAcQAOAbgBA2IAABjQACAAgbAYQgXAVgBACg");
	this.shape_402.setTransform(231,98.9);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#DCE2E7").s().p("AJ7CmIz5k9QgGgBgDgDQgDgDAAgDQABgDAFgBQAFgCAFACIT5E9QAGABADADQAEADgBADQgCAFgIAAIgGgBg");
	this.shape_403.setTransform(144.4,69.7);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#D8DFE4").s().p("AJ8CoIz8k+QgHgBgDgEQgEgDABgDQABgEAGgCQAFgBAGABIT8E+QAHABADAEQAEADgBAEQgBADgGABIgGABIgFAAg");
	this.shape_404.setTransform(144.5,69.7);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#D3DBE0").s().p("AJ+CqI0Bk/QgHgCgDgDQgEgEABgEQABgEAGgCQAFgCAHABIUBE/QAHACADADQAEAEgBAEQgBAEgGACIgHABIgFAAg");
	this.shape_405.setTransform(144.7,69.6);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#CFD8DD").s().p("AJ/CrI0ElAQgHgBgEgEQgEgEABgFQABgFAHgCQAGgCAHACIUEE/QAHACAEAEQAEAEgBAFQgCAEgGADIgHABIgGgBg");
	this.shape_406.setTransform(144.8,69.6);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#CBD4DA").s().p("AKBCtI0JlAQgHgCgEgFQgFgFACgEQABgFAHgDQAGgDAIACIUIFBQAIABAEAEQAFAGgCAEQgCAGgGACQgEACgFAAIgFgBg");
	this.shape_407.setTransform(145,69.6);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#C6D1D7").s().p("AKCCvI0MlCQgIgBgFgFQgEgGACgFQACgGAHgDQAGgCAJABIUMFCQAIABAEAFQAFAGgCAFQgCAGgHADQgEABgFAAIgGAAg");
	this.shape_408.setTransform(145.1,69.6);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#C2CED5").s().p("AKECwI0QlCQgJgCgEgFQgFgGACgGQACgGAHgDQAHgDAJACIUQFCQAIABAFAGQAFAFgCAHQgCAGgHADQgFACgGAAIgFgBg");
	this.shape_409.setTransform(145.3,69.6);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#BDCAD2").s().p("AKGCyI0VlDQgJgCgEgGQgGgGACgHQADgGAHgDQAJgEAIACIUVFDQAJACAEAGQAGAGgCAGQgDAHgHADQgGADgFAAIgGgBg");
	this.shape_410.setTransform(145.4,69.6);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#B9C7CF").s().p("AKHC0I0YlEQgKgCgFgGQgFgHACgHQACgHAJgEQAIgEAKACIUYFEQAJACAFAHQAGAGgDAHQgCAHgIAEQgFACgGAAIgHAAg");
	this.shape_411.setTransform(145.6,69.5);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f().s("#D5A675").ss(0.3,0,0,3.9).p("ABSBzQgtgqgtg8QgTgXgCgtQgCgpALgdQgXgcgWAQQgSA5AEAqQAEAmAaAjQAhAtAiAlQASASAMAJ");
	this.shape_412.setTransform(192.7,111.3);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#FEF0DF").s().p("AgmAeQgagggCgnQgDgmATg7QAJgEAGAGQgOAlgCAkQgDA0AYAhQAlA4A9A4IgIAGQg8g5gmg1g");
	this.shape_413.setTransform(192.3,110.8);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#FCECDA").s().p("AgoAfQgZghgDgmQgCgnASg7QALgFAHAIQgNAjgCAmQgCAzAXAgQAmA4A7A3IgKAJQg7g3gog3g");
	this.shape_414.setTransform(192.4,110.9);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#F9E9D5").s().p("AgpAfQgZgggDgnQgDgnASg7QAMgGAKAKQgOAjgBAmQgCAyAYAfQAmA5A6A0IgOAMQg5g0gpg6g");
	this.shape_415.setTransform(192.4,110.9);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#F7E5CF").s().p("AgqAgQgaghgDgnQgDgnATg6QANgIALANQgMAigBAmQgCAxAXAeQAoA5A3AzIgQAOQg4gygqg7g");
	this.shape_416.setTransform(192.5,111);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#F4E1CA").s().p("AgrAgQgaghgDgmQgEgoATg6QAPgJANAPQgNAhAAAnQgBAxAWAcQApA6A2AxIgUARQg2gwgrg+g");
	this.shape_417.setTransform(192.5,111);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#F2DDC4").s().p("AgtAhQgZghgEgnQgDgoASg6QAQgKAQARQgNAgAAAnQAAAxAWAbQApA6A0AwIgWATQg1gtgthAg");
	this.shape_418.setTransform(192.6,111.1);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#EFD9BF").s().p("AAUBxQgkgmgegqQgZghgEgnQgEgoASg6QASgMARAUQgMAgABAnQAAAwAVAaQAqA7AzAuIgaAVQgMgKgTgTg");
	this.shape_419.setTransform(192.6,111.1);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#EDD5BA").s().p("AATByQgjglgfgrQgagigEgnQgEgoATg6QATgOATAYQgMAeABAoQABAvAUAZQArA7AxAtIgcAYQgMgKgTgTg");
	this.shape_420.setTransform(192.7,111.2);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#EAD1B4").s().p("AASBzQgigkgggtQgagigEgmQgFgqATg5QAVgPAUAaQgLAeABAoQACAuATAYQAtA8AvArIggAaQgLgJgTgTg");
	this.shape_421.setTransform(192.7,111.2);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#E8CDAF").s().p("AARB1QgiglghgtQgagjgEgmQgEgqASg5QAWgQAXAcQgLAdACApQACAtATAXQAtA8AtAqIgiAdQgMgJgSgSg");
	this.shape_422.setTransform(192.8,111.3);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f().s("#D5A675").ss(0.3,0,0,3.9).p("ABSBzQgtgpgtg9QgTgWgCguQgCgoALgeQgXgbgWAPQgSA6AEApQAEAmAaAjQAiAuAiAkQASASALAJ");
	this.shape_423.setTransform(88.9,85.1);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#FEF0DF").s().p("AgmAeQgZgggDgnQgDgmATg7QAKgDAFAFQgOAkgCAlQgDA0AYAhQAlA4A9A3IgIAHQg8g5gmg1g");
	this.shape_424.setTransform(88.6,84.7);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#FCECDA").s().p("AgoAfQgZghgDgmQgCgnASg7QALgEAHAHQgOAkgBAlQgCAzAYAgQAlA5A7A2IgKAJQg7g3gog3g");
	this.shape_425.setTransform(88.6,84.7);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#F9E9D5").s().p("AgpAfQgZghgDgmQgDgoATg6QAMgGAJAKQgNAjgCAmQgCAyAYAfQAmA5A6A0IgOAMQg5g1gpg5g");
	this.shape_426.setTransform(88.7,84.8);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#F7E5CF").s().p("AgqAgQgaghgDgnQgDgnATg7QANgHAMAMQgNAigBAnQgCAxAXAeQAoA5A3AzIgQAOQg4gygqg7g");
	this.shape_427.setTransform(88.7,84.8);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#F4E1CA").s().p("AgrAhQgaghgDgnQgEgoATg6QAPgJANAPQgMAhgBAnQgBAxAWAcQApA6A2AxIgUARQg2gwgrg9g");
	this.shape_428.setTransform(88.8,84.8);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#F2DDC4").s().p("AAVBwQgkgngegoQgZghgEgnQgDgoASg6QARgKAPARQgNAhAAAnQAAAwAWAbQApA7A0AvIgWATQgNgLgTgTg");
	this.shape_429.setTransform(88.8,84.9);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#EFD9BF").s().p("AAUBxQgjgmgfgqQgZghgEgnQgEgpATg5QARgMARAUQgMAgABAnQAAAwAVAaQAqA7AzAuIgaAVQgMgKgTgTg");
	this.shape_430.setTransform(88.9,85);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#EDD5BA").s().p("AATByQgjglgfgrQgagigEgnQgEgpATg5QATgNATAWQgMAfABAoQABAvAUAZQAsA7AwAtIgcAYQgMgKgTgTg");
	this.shape_431.setTransform(88.9,85);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#EAD1B4").s().p("AASBzQgigkgggsQgagjgEgmQgEgqASg5QAUgOAWAZQgMAeABAoQACAuATAYQAtA8AvArIggAaQgLgJgTgTg");
	this.shape_432.setTransform(89,85);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#E8CDAF").s().p("AASB1QgigkgiguQgagjgEgmQgEgpASg6QAWgPAXAbQgLAeACAoQACAuATAWQAtA9AtApIgiAdQgLgJgSgSg");
	this.shape_433.setTransform(89,85.1);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f().s("#508796").ss(0.2,0,0,3.9).p("AATAHIglgN");
	this.shape_434.setTransform(65.2,44.8);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f().s("#DCE2E7").ss(0.2,0,0,3.9).p("AgKAAIAWAB");
	this.shape_435.setTransform(63.6,53.7);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f().s("#357D8C").ss(0.2,0,0,3.9).p("AqNjuIgbgHQgNgDgHgGIgwgaQgKgGgCgIQAAgEgFgBQgGgCgCAGIgjB3QgCAGAHACQAEABADgDQAGgGAPAAIAzgBQATABAFABIAbAHQAOAEADALQADAPANAMQALAMASAEIA9AQIgXBNQgEAAgCADIgJAuQgBAFAFACIARAEQAFABACgFIASgsQABgEgEgBIAXhNIPvD4IgWBNQgFAAAAAEIgKAwQAAACAAACQACACACAAIAQAEQAGACABgFIASguQACgEgEgBIAWhOIAmAKQASAEARgFQARgEALgMQAJgJAFgDQAKgHAKACIBLATQAAAFAFABIA/ALQAHABACgGIAJgeQACgHgHgBIg9gVQgFgBgCAEIhLgSQgPgEgGgbQgEgPgLgLQgMgMgRgEIyLkgQgRgEgRAEQgRAFgLALQgJAJgPgDg");
	this.shape_436.setTransform(140.9,72.2);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#637F86").s().p("AgXAPIAJgiIAmAQIgHAXg");
	this.shape_437.setTransform(63.3,50.3);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#607E85").s().p("AgYAQIAKgkIAnAQIgIAZg");
	this.shape_438.setTransform(63.3,50.2);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#5E7D85").s().p("AgYARIALgmIAmAQIgIAag");
	this.shape_439.setTransform(63.3,50.2);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#5B7C84").s().p("AgYASIALgoIAmAQIgJAdg");
	this.shape_440.setTransform(63.3,50.2);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#587C84").s().p("AgYATIALgpIAmAPIgJAeg");
	this.shape_441.setTransform(63.3,50.1);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#567B83").s().p("AgZAUIANgrIAmAPIgKAgg");
	this.shape_442.setTransform(63.3,50.1);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#537A83").s().p("AgZAVIANgtIAmAPIgLAig");
	this.shape_443.setTransform(63.4,50);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#507982").s().p("AgZAVIANguIAmAPIgLAkg");
	this.shape_444.setTransform(63.4,50);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#4D7882").s().p("AgZAWIANgwIAmAPIgLAmg");
	this.shape_445.setTransform(63.4,50);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#4A7882").s().p("AgaAXIAPgyIAmAQIgMAng");
	this.shape_446.setTransform(63.4,49.9);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#477781").s().p("AgaAYIAPg0IAmAQIgMApg");
	this.shape_447.setTransform(63.4,49.8);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#447681").s().p("AgaAZIAPg1IAmAOIgNArg");
	this.shape_448.setTransform(63.4,49.8);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#417580").s().p("AgbAaIAQg4IAnAQIgPAsg");
	this.shape_449.setTransform(63.5,49.8);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#3E7580").s().p("AgbAbIARg6IAmAQIgOAvg");
	this.shape_450.setTransform(63.4,49.7);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#3A747F").s().p("AgbAcIARg7IAmAPIgPAwg");
	this.shape_451.setTransform(63.5,49.7);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#37737F").s().p("AgbAcIARg8IAmAPIgPAyg");
	this.shape_452.setTransform(63.5,49.6);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#33737E").s().p("AgcAdIASg+IAnAPIgQA0g");
	this.shape_453.setTransform(63.5,49.6);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#30727E").s().p("AgcAeIAThAIAmAPIgQA2g");
	this.shape_454.setTransform(63.5,49.5);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#2C717E").s().p("AgcAfIAThCIAmAPIgRA4g");
	this.shape_455.setTransform(63.5,49.5);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#27707D").s().p("AgcAgIAThEIAmAQIgRA5g");
	this.shape_456.setTransform(63.5,49.4);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#23707D").s().p("AgdAhIAUhGIAnAQIgSA7g");
	this.shape_457.setTransform(63.5,49.4);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#1E6F7C").s().p("AgdAiIAUhHIAnAOIgSA9g");
	this.shape_458.setTransform(63.6,49.4);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#186E7C").s().p("AgdAiIAVhJIAmAQIgTA/g");
	this.shape_459.setTransform(63.6,49.3);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#106E7B").s().p("AgdAjIAVhLIAmAQIgTBBg");
	this.shape_460.setTransform(63.6,49.3);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#056D7B").s().p("AgeAkIAWhMIAnAPIgUBCg");
	this.shape_461.setTransform(63.6,49.2);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#006D7A").s().p("AgeAlIAWhOIAnAPIgVBEg");
	this.shape_462.setTransform(63.6,49.2);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#006C7A").s().p("AgeAmIAXhQIAmAPIgVBGg");
	this.shape_463.setTransform(63.6,49.1);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#006B79").s().p("AgeAnIAXhSIAnAPIgWBIg");
	this.shape_464.setTransform(63.6,49.1);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#006B79").s().p("AgfAoIAYhUIAnAPIgWBKg");
	this.shape_465.setTransform(63.6,49.1);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#006A79").s().p("AgfApIAZhWIAmAQIgWBLg");
	this.shape_466.setTransform(63.7,49);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#006978").s().p("AgfAqIAZhYIAmAQIgXBNg");
	this.shape_467.setTransform(63.7,48.9);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#006978").s().p("AggArIAahZIAmAPIgXBOg");
	this.shape_468.setTransform(63.7,48.9);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#006877").s().p("AggArIAahbIAnAQIgYBQg");
	this.shape_469.setTransform(63.7,48.9);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f().s("#7D9FAB").ss(0.2,0,0,3.9).p("AgLApIAWhR");
	this.shape_470.setTransform(66,49.7);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#8AA0A8").s().p("AghAqIAbhZIAoAPIgYBQg");
	this.shape_471.setTransform(63.8,49);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f().s("#264546").ss(0.3,0,0,3.9).p("AAhgmIghgMIgbBhIAhAF");
	this.shape_472.setTransform(59.5,47.9);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#515E5F").s().p("AgqAPIANgoIBHAaIgHAZg");
	this.shape_473.setTransform(61.5,49.7);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#4F5D5E").s().p("AgqAQIANgqIBIAaIgIAag");
	this.shape_474.setTransform(61.5,49.7);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#4E5C5D").s().p("AgqARIANgrIBIAaIgIAbg");
	this.shape_475.setTransform(61.5,49.6);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#4D5B5C").s().p("AgqASIAOguIBHAcIgJAdg");
	this.shape_476.setTransform(61.5,49.6);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#4C5A5B").s().p("AgqATIAOgvIBIAbIgKAeg");
	this.shape_477.setTransform(61.5,49.5);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#4A595A").s().p("AgrATIAPgwIBIAbIgKAgg");
	this.shape_478.setTransform(61.5,49.5);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#49585A").s().p("AgrAUIAPgyIBIAbIgKAig");
	this.shape_479.setTransform(61.5,49.4);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#485859").s().p("AgsAVIAQg0IBIAbIgLAkg");
	this.shape_480.setTransform(61.6,49.4);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#465758").s().p("AgsAWIARg2IBHAbIgLAmg");
	this.shape_481.setTransform(61.6,49.4);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#455657").s().p("AgsAXIARg4IBIAcIgMAng");
	this.shape_482.setTransform(61.6,49.3);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#445556").s().p("AgsAYIARg6IBIAbIgMAqg");
	this.shape_483.setTransform(61.6,49.3);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#435455").s().p("AgsAZIASg8IBIAbIgOArg");
	this.shape_484.setTransform(61.6,49.2);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#415355").s().p("AgtAaIATg9IBIAbIgOAsg");
	this.shape_485.setTransform(61.6,49.2);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#405354").s().p("AgtAbIAUg/IBHAbIgOAug");
	this.shape_486.setTransform(61.6,49.1);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#3F5253").s().p("AgtAcIAThBIBIAbIgOAwg");
	this.shape_487.setTransform(61.6,49.1);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#3D5152").s().p("AguAcIAUhCIBJAbIgQAyg");
	this.shape_488.setTransform(61.7,49);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#3C5051").s().p("AguAdIAVhEIBIAbIgQA0g");
	this.shape_489.setTransform(61.7,49);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#3B5051").s().p("AguAeIAWhGIBHAbIgQA2g");
	this.shape_490.setTransform(61.7,49);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#3A4F50").s().p("AguAfIAVhIIBIAbIgRA4g");
	this.shape_491.setTransform(61.7,48.9);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#384E4F").s().p("AguAgIAVhKIBIAcIgRA5g");
	this.shape_492.setTransform(61.7,48.8);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#374D4E").s().p("AgvAhIAXhMIBIAbIgSA8g");
	this.shape_493.setTransform(61.7,48.8);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#364D4E").s().p("AgvAiIAXhOIBIAbIgSA9g");
	this.shape_494.setTransform(61.7,48.8);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#344C4D").s().p("AgvAjIAYhPIBHAbIgTA/g");
	this.shape_495.setTransform(61.7,48.7);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#334B4C").s().p("AgwAkIAZhRIBIAbIgUBAg");
	this.shape_496.setTransform(61.8,48.7);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#324A4B").s().p("AgwAlIAZhTIBIAbIgUBCg");
	this.shape_497.setTransform(61.8,48.6);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#304A4B").s().p("AgwAlIAZhUIBIAbIgUBEg");
	this.shape_498.setTransform(61.8,48.6);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#2F494A").s().p("AgwAmIAahWIBHAbIgVBGg");
	this.shape_499.setTransform(61.8,48.6);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#2E4849").s().p("AgwAnIAahYIBIAbIgWBIg");
	this.shape_500.setTransform(61.8,48.5);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#2C4748").s().p("AgxAoIAbhaIBIAbIgWBKg");
	this.shape_501.setTransform(61.8,48.5);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#2B4748").s().p("AgxApIAbhbIBIAbIgWBKg");
	this.shape_502.setTransform(61.8,48.4);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#294647").s().p("AgyAqIAcheIBIAbIgXBOg");
	this.shape_503.setTransform(61.9,48.4);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#284546").s().p("AgyArIAdhgIBHAcIgXBOg");
	this.shape_504.setTransform(61.9,48.3);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#264546").s().p("AgyAsIAdhhIBIAbIgYBQg");
	this.shape_505.setTransform(61.9,48.3);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#DCE2E7").s().p("AgXAWQgGAAgEgEQgFgEABgFIADgMQAAgHAGgHQAGgIAHACIAqAPQAJAEACAEIAAAGIgCAJQAAAJgOAAg");
	this.shape_506.setTransform(68.4,50.6);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#D8DFE4").s().p("AAXAbIgugCQgHAAgFgEQgEgFAAgFIAEgPQAAgHAGgIQAHgJAIADIArAQQAKAEABAFIAAAJIgBAHQgBALgNAAIgCAAg");
	this.shape_507.setTransform(68.4,50.5);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#D3DBE0").s().p("AgYAbQgIAAgFgEQgFgFAAgGIAFgRQAAgIAIgIQAIgKAIADIAsATQAKAEABAFQABADgBAJIgBAGQgBAMgQAAg");
	this.shape_508.setTransform(68.4,50.3);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#CFD8DD").s().p("AgaAdQgHAAgGgFQgFgEAAgHIAFgUQABgIAIgJQAIgKAJADIAuAVQAKAFACAFIgBAOIgBAFQgBANgRAAg");
	this.shape_509.setTransform(68.4,50.2);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#CBD4DA").s().p("AAaAjIg0gCQgJgBgFgFQgGgFAAgHIAGgXQAAgIAJgKQAKgLAJAEIAvAXQALAEABAIQABAFgBAKIgBAEQgDAOgPAAIgCAAg");
	this.shape_510.setTransform(68.3,50);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#C6D1D7").s().p("AgbAjQgJgBgGgFQgHgFABgIIAHgaQAAgJAJgKQALgLAJAEIAwAYQALAGACAIIgBARIAAADQgCAQgTAAg");
	this.shape_511.setTransform(68.3,49.9);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#C2CED5").s().p("AAcAoIg5gDQgJAAgHgGQgGgGAAgIIAIgcQAAgJALgLQALgLAKAEIAxAaQAMAGABAJQABAHgCAMIAAACQgDAQgRAAIgCAAg");
	this.shape_512.setTransform(68.3,49.8);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#BDCAD2").s().p("AAdArIg6gDQgKgBgHgGQgHgGAAgIIAJgfQAAgKALgLQAMgMALAEIAyAcQAMAHACALQABAHgCAMIAAABQgEASgSAAIgCAAg");
	this.shape_513.setTransform(68.3,49.6);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#B9C7CF").s().p("AgeAqQgLAAgHgHQgHgGAAgJIAJgiQABgKALgMQANgNALAFIA0AeQAMAHACAMQABAIgCAOQgEATgVAAg");
	this.shape_514.setTransform(68.3,49.5);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#B9C7CF").s().p("AAXAZIg4gJQgDgBgBgDIALgjQACgCADABIA2ARQAFABgBAFIgHAXQgBADgEAAIgCAAg");
	this.shape_515.setTransform(217.7,87.5);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#B5C4CC").s().p("AAXAZIg4gJQgBAAgBgBQAAAAgBAAQAAgBAAAAQgBgBAAgBIALgjQACgCADAAIA2ASQABAAAAAAQABABAAAAQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAAAgBABIgHAXQgBAEgEAAIgCgBg");
	this.shape_516.setTransform(217.7,87.5);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#B1C1CA").s().p("AAYAaIg5gKQgDgBgBgDIALgjQADgCADAAIA2ASQAFACgBAEIgHAXQgCAEgEAAIgBAAg");
	this.shape_517.setTransform(217.7,87.5);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#ADBFC8").s().p("AAXAaIg5gKQgDgBAAgDIALgjQACgDADABIA3ASQAFABgBAFIgIAXQgBAEgDAAIgDAAg");
	this.shape_518.setTransform(217.7,87.5);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#AABCC5").s().p("AAYAaIg5gKQgDgBgBgDIALgkQACgCAEABIA2ARQAFACgBAFIgHAXQgCAEgDAAIgCAAg");
	this.shape_519.setTransform(217.7,87.5);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#A6BAC3").s().p("AAYAaIg5gJQgEgBgBgDIAMgkQACgDADABIA3ASQABAAAAAAQABAAAAAAQABABAAAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAgBABIgHAYQgBAEgEAAIgCgBg");
	this.shape_520.setTransform(217.7,87.4);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#A2B7C1").s().p("AAYAaIg6gJQgDgBgBgDIAMglQACgDADABIA3ASQAGACgCAFIgHAYQgBAEgEAAIgCgBg");
	this.shape_521.setTransform(217.7,87.4);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#9FB4BF").s().p("AAYAbIg6gKQgDAAgBgEIALglQADgDADABIA4ATQAFABgBAFIgIAYQgBAEgEAAIgCAAg");
	this.shape_522.setTransform(217.7,87.4);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#9BB2BC").s().p("AAYAbIg6gKQgDgBgBgDIALglQADgDADABIA4ASQAGACgCAFIgIAYQgBAEgEAAIgCAAg");
	this.shape_523.setTransform(217.7,87.4);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#97AFBA").s().p("AAYAbIg6gKQgEAAgBgEIANglQACgDADABIA4ASQAGABgCAGIgIAYQgBAEgEAAIgCAAg");
	this.shape_524.setTransform(217.7,87.4);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#93ADB8").s().p("AAYAcIg6gKQgDgBgCgDIAMgmQADgDADABIA4ASQAGACgCAFIgIAZQgBAEgEAAIgCAAg");
	this.shape_525.setTransform(217.7,87.3);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#90AAB6").s().p("AAYAcIg6gKQgEgBgBgDIAMgnQADgDADABIA4ATQAGABgBAGIgIAZQgCAEgEAAIgCAAg");
	this.shape_526.setTransform(217.6,87.3);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#8CA8B3").s().p("AAYAcIg7gKQgDgBgBgDIAMgnQADgDADABIA5ATQAFACgCAEIgIAaQgBAEgEAAIgCAAg");
	this.shape_527.setTransform(217.7,87.3);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#88A6B1").s().p("AAYAcIg7gKQgDAAgBgEIAMgnQACgDAEABIA5ATQAGABgCAGIgIAaQgCADgDAAIgDAAg");
	this.shape_528.setTransform(217.6,87.3);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#84A3AF").s().p("AAYAcIg7gJQgDgCgBgDIAMgnQACgDAEABIA5ATQAFACgBAFIgIAaQgCAEgDAAIgDgBg");
	this.shape_529.setTransform(217.6,87.3);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#80A1AD").s().p("AAYAdIg7gKQgEgCgBgDIANgoQADgDADABIA5ATQAGACgCAFIgIAbQgBAEgFAAIgCAAg");
	this.shape_530.setTransform(217.6,87.3);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#7C9EAB").s().p("AAYAdIg7gKQgEgBgBgDIANgpQADgDADABIA5AUQAGACgCAFIgIAaQgBAEgFAAIgCAAg");
	this.shape_531.setTransform(217.6,87.2);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#779CA8").s().p("AAZAdIg8gKQgEgCgBgCIANgpQADgDADABIA6ATQAFACgBAFIgIAbQgCAEgEAAIgCAAg");
	this.shape_532.setTransform(217.6,87.2);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#7399A6").s().p("AAYAdIg8gKQgDgBgBgDIAMgpQADgEAEACIA5ATQAGABgBAGIgJAbQgBAFgEAAIgDgBg");
	this.shape_533.setTransform(217.6,87.2);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#6F97A4").s().p("AAZAdIg9gKQgEgCAAgCIANgqQADgCADAAIA6AUQAGACgCAFIgIAbQgCAFgEAAIgCgBg");
	this.shape_534.setTransform(217.6,87.2);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#6A95A2").s().p("AAZAeIg9gKQgDgCgBgDIAMgqQADgDAEABIA6AUQAAAAABAAQAAABABAAQAAAAABABQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAABAAAAIgIAcQgCAEgEAAIgCAAg");
	this.shape_535.setTransform(217.6,87.2);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#6693A0").s().p("AAZAeIg9gKQgEgCgBgDIANgqQADgDAEABIA6AUQAGACgCAFIgIAcQgCAEgDAAIgDAAg");
	this.shape_536.setTransform(217.6,87.2);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#62909E").s().p("AAZAeIg9gKQgEgCgBgDIANgqQADgEAEACIA6AUQABAAAAAAQABABAAAAQABAAAAABQABAAAAAAQAAABABABQAAAAAAABQAAAAAAABQAAAAAAABIgJAcQgCAEgEAAIgCAAg");
	this.shape_537.setTransform(217.6,87.2);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#5D8E9C").s().p("AAZAeIg9gKQgFgBAAgEIANgqQADgEAEACIA6AUQAGACgBAFIgJAcQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAIgDABIgCgBg");
	this.shape_538.setTransform(217.6,87.1);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#598C9A").s().p("AAZAfIg+gLQgEgBAAgEIANgrQADgDAEABIA6AVQABAAAAAAQABAAABABQAAAAAAAAQABABAAAAQABABAAAAQAAABAAAAQAAABAAABQAAAAAAABIgJAcQgBAFgFAAIgCAAg");
	this.shape_539.setTransform(217.6,87.1);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#548A98").s().p("AAZAfIg+gLQgEgBgBgEIAOgrQADgDADABIA7AUQAGACgBAGIgJAcQgBAFgFAAIgCAAg");
	this.shape_540.setTransform(217.6,87.1);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#508796").s().p("AAZAfIg+gKQgEgBgBgEIAOgsQACgDAEABIA7AVQAHABgCAGIgJAdQgBAFgFAAIgCgBg");
	this.shape_541.setTransform(217.6,87.1);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#B9C7CF").s().p("AMYDvIhAgKQgFgCAAgEIhLgTQgLgDgOALQADgGgDgFQgDgEgEgCIzZk1IgJAAQgKAAgDABQgFADgDAGIgCAGIgCgDQgFgGgJgBIgbgHQgMgDgLABIg3ABQgNAAgFAGQgDADgEgBQgHgCACgGIAjh2QABgDACgBIAFgBQAEABABAEQACAIANAHIAsAYIAWAJIAbAHQAHACAIgCIAEgCIgBAGQgBAHADAFQAHAMAaADIS5EsIAVADQALABACgMQAGAOALACIBLATQACgEAFABIA+AVQAGABgCAGIgJAfQgBAFgEAAIgDgBg");
	this.shape_542.setTransform(140.9,66.3);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#DCE2E7").s().p("AAJAPIgZgHQgGgBgDgFQgDgCACgGQABgFAGgCQAFgDAGACIAYAGQAGACAEAEQADADgCAFQgBAGgFACQgEACgDAAIgFgBg");
	this.shape_543.setTransform(209.4,85.3);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#D8DFE4").s().p("AAKAQIgbgHQgHgBgDgFQgDgEABgFQACgGAGgDQAFgCAHABIAbAHQAGACAEAFQADADgBAGQgCAFgGADQgDACgEAAIgFgBg");
	this.shape_544.setTransform(209.4,85.3);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#D3DBE0").s().p("AALASIgdgIQgHgCgEgFQgEgEACgGQACgGAGgDQAGgDAHACIAdAIQAHACAEAFQAEADgCAGQgCAGgGADQgEADgEAAIgFgBg");
	this.shape_545.setTransform(209.4,85.3);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#CFD8DD").s().p("AALATIgfgIQgHgCgEgGQgEgEACgGQACgHAGgDQAHgDAHACIAgAIQAHACAEAGQAEADgCAHQgCAHgGADQgEACgFAAIgGgBg");
	this.shape_546.setTransform(209.4,85.3);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#CBD4DA").s().p("AAMAUIghgIQgIgCgEgHQgFgEACgHQACgHAHgDQAHgEAIACIAiAJQAIACAEAGQAFAFgCAHQgDAHgGADQgFACgEAAIgHgBg");
	this.shape_547.setTransform(209.4,85.3);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#C6D1D7").s().p("AANAWIgkgKQgIgCgFgHQgEgEACgHQACgIAIgDQAHgEAJACIAjAJQAJADAEAGQAFAFgCAHQgCAHgIAEQgEACgGAAIgGAAg");
	this.shape_548.setTransform(209.4,85.3);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#C2CED5").s().p("AAOAXIgmgKQgJgCgFgHQgEgFACgIQACgIAIgEQAIgDAJACIAmAKQAJACAFAHQAFAFgDAIQgCAIgIADQgFADgGAAIgGgBg");
	this.shape_549.setTransform(209.4,85.3);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#BDCAD2").s().p("AAPAYIgogKQgKgCgFgIQgFgFACgJQADgIAIgEQAIgEAKACIAoALQAKACAFAIQAFAFgCAIQgDAIgIAFQgFACgGAAIgHgBg");
	this.shape_550.setTransform(209.4,85.3);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#B9C7CF").s().p("AAQAaIgrgLQgKgDgFgIQgFgGACgIQACgJAJgEQAJgEAKACIArALQAKADAFAHQAFAGgCAJQgDAIgJAFQgFADgGAAIgHgBg");
	this.shape_551.setTransform(209.4,85.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.text},{t:this.shape},{t:this.instance}]}).to({state:[{t:this.shape_551},{t:this.shape_550},{t:this.shape_549},{t:this.shape_548},{t:this.shape_547},{t:this.shape_546},{t:this.shape_545},{t:this.shape_544},{t:this.shape_543},{t:this.shape_542},{t:this.shape_541},{t:this.shape_540},{t:this.shape_539},{t:this.shape_538},{t:this.shape_537},{t:this.shape_536},{t:this.shape_535},{t:this.shape_534},{t:this.shape_533},{t:this.shape_532},{t:this.shape_531},{t:this.shape_530},{t:this.shape_529},{t:this.shape_528},{t:this.shape_527},{t:this.shape_526},{t:this.shape_525},{t:this.shape_524},{t:this.shape_523},{t:this.shape_522},{t:this.shape_521},{t:this.shape_520},{t:this.shape_519},{t:this.shape_518},{t:this.shape_517},{t:this.shape_516},{t:this.shape_515},{t:this.shape_514},{t:this.shape_513},{t:this.shape_512},{t:this.shape_511},{t:this.shape_510},{t:this.shape_509},{t:this.shape_508},{t:this.shape_507},{t:this.shape_506},{t:this.shape_505},{t:this.shape_504},{t:this.shape_503},{t:this.shape_502},{t:this.shape_501},{t:this.shape_500},{t:this.shape_499},{t:this.shape_498},{t:this.shape_497},{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490},{t:this.shape_489},{t:this.shape_488},{t:this.shape_487},{t:this.shape_486},{t:this.shape_485},{t:this.shape_484},{t:this.shape_483},{t:this.shape_482},{t:this.shape_481},{t:this.shape_480},{t:this.shape_479},{t:this.shape_478},{t:this.shape_477},{t:this.shape_476},{t:this.shape_475},{t:this.shape_474},{t:this.shape_473},{t:this.shape_472},{t:this.shape_471},{t:this.shape_470},{t:this.shape_469},{t:this.shape_468},{t:this.shape_467},{t:this.shape_466},{t:this.shape_465},{t:this.shape_464},{t:this.shape_463},{t:this.shape_462},{t:this.shape_461},{t:this.shape_460},{t:this.shape_459},{t:this.shape_458},{t:this.shape_457},{t:this.shape_456},{t:this.shape_455},{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445},{t:this.shape_444},{t:this.shape_443},{t:this.shape_442},{t:this.shape_441},{t:this.shape_440},{t:this.shape_439},{t:this.shape_438},{t:this.shape_437},{t:this.shape_436},{t:this.shape_435},{t:this.shape_434},{t:this.shape_433},{t:this.shape_432},{t:this.shape_431},{t:this.shape_430},{t:this.shape_429},{t:this.shape_428},{t:this.shape_427},{t:this.shape_426},{t:this.shape_425},{t:this.shape_424},{t:this.shape_423},{t:this.shape_422},{t:this.shape_421},{t:this.shape_420},{t:this.shape_419},{t:this.shape_418},{t:this.shape_417},{t:this.shape_416},{t:this.shape_415},{t:this.shape_414},{t:this.shape_413},{t:this.shape_412},{t:this.shape_411},{t:this.shape_410},{t:this.shape_409},{t:this.shape_408},{t:this.shape_407},{t:this.shape_406},{t:this.shape_405},{t:this.shape_404},{t:this.shape_403},{t:this.shape_402},{t:this.shape_401},{t:this.shape_400},{t:this.shape_399},{t:this.shape_398},{t:this.shape_397},{t:this.shape_396},{t:this.shape_395},{t:this.shape_394},{t:this.shape_393},{t:this.shape_392},{t:this.shape_391},{t:this.shape_390},{t:this.shape_389},{t:this.shape_388},{t:this.shape_387},{t:this.shape_386},{t:this.shape_385},{t:this.shape_384},{t:this.shape_383},{t:this.shape_382},{t:this.shape_381},{t:this.shape_380},{t:this.shape_379},{t:this.shape_378},{t:this.shape_377},{t:this.shape_376},{t:this.shape_375},{t:this.shape_374},{t:this.shape_373},{t:this.shape_372},{t:this.shape_371},{t:this.shape_370},{t:this.shape_369},{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_1},{t:this.text},{t:this.shape},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,272,200.8);


(lib.btn_decantacion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits13();
	this.instance.setTransform(5.5,5.6);

	this.text = new cjs.Text(txt['btn_decant'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(132.5,180.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AVQM+MgqfAAAIAA57MAqfAAAg");
	this.shape.setTransform(136,83.5,1,1.006);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AI2h4IAADxIxsAAIAAjxg");
	this.shape_1.setTransform(135.9,189.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("Ao2B5IAAjxIRsAAIAADxg");
	this.shape_2.setTransform(135.9,189.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AVSs/IAAZ/MgqjAAAIAA5/g");
	this.shape_3.setTransform(135.9,83.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("A1RNAIAA5/MAqjAAAIAAZ/g");
	this.shape_4.setTransform(135.9,83.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1D1D1C").s().p("AgJAAQABgNAIAAQAKAAAAANQAAAOgKAAQgIAAgBgOgAgFAAQAAALAFAAQAHAAAAgLQAAgKgHAAQgFAAAAAKg");
	this.shape_5.setTransform(208.8,65.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1D1D1C").s().p("AgIAFQAAgMAIAAQAEAAACAFIAAgRIADAAIAAAgIAAAFIgDAAIAAgDQgDAEgDABQgIAAAAgPgAgFAFQAAAMAFgBQAGABAAgMQAAgJgGAAQgFAAAAAJg");
	this.shape_6.setTransform(206.3,65.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D1D1C").s().p("AgHAFQAAgFAEgBQACgBAGAAIAAgCQAAgGgFAAQgDAAAAAFIgDAAQABgIAFAAQAIAAAAAJIAAARIgDAAIAAgEIAAAAQgCAFgDAAQgHAAAAgJgAAAAAQgEABAAAEQAAAGAEAAQAFAAAAgLIgFAAg");
	this.shape_7.setTransform(204,65.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D1D1C").s().p("AgHAAQgBgNAIAAQAJAAAAAJIgDAAQAAgGgGAAQgEAAgBAKQABALAEAAQAFAAABgHIADAAQgBAKgIAAQgHAAAAgOg");
	this.shape_8.setTransform(202,65.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D1D1C").s().p("AAAATIAAgZIABAAIAAAZgAAAgOIAAgEIABAAIAAAEg");
	this.shape_9.setTransform(200.4,65.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1D1D1C").s().p("AgBATIAAgWIgDAAIAAgDIADAAIAAgFQABgHADAAIACAAIAAADIgBAAQgEAAAAAGIAAADIAFAAIAAADIgFAAIAAAWg");
	this.shape_10.setTransform(199.2,65.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1D1D1C").s().p("AAAATIAAgZIABAAIAAAZgAAAgOIAAgEIABAAIAAAEg");
	this.shape_11.setTransform(198,65.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1D1D1C").s().p("AgDANIAAgZIACAAIAAAEQABgEACAAIADAAIAAADIgCgBQgEAAAAAJIAAAOg");
	this.shape_12.setTransform(197,65.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1D1D1C").s().p("AgHACIAAgPIACAAIAAAQQAAAHAFAAQAFAAAAgJIAAgOIADAAIAAAUIAAAFIgDAAIAAgEQgCAFgDABQgHAAAAgMg");
	this.shape_13.setTransform(194.9,65.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1D1D1C").s().p("AgIASIAAgdIAAgGIADAAIAAAEQACgEAEAAQAIgBAAAOQAAANgIAAQgEAAgCgFIAAAOgAgFgEQAAAKAGAAQAFAAAAgKQAAgLgGAAQgFAAAAALg");
	this.shape_14.setTransform(192.6,66.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1D1D1C").s().p("AgCAVQACgKAAgLQAAgIgCgNIACAAQADAQAAAFQAAAGgDAPg");
	this.shape_15.setTransform(189.5,65.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#1D1D1C").s().p("AgHAFIADAAQAAAGAEAAQAGAAAAgGQAAgDgGgCQgGAAgBgFQABgIAGAAQAHAAAAAHIgCAAQAAgEgFAAQgDAAAAAEQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAIAGACQADAAAAAFQAAAJgIAAQgHAAAAgJg");
	this.shape_16.setTransform(187.9,65.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#1D1D1C").s().p("AABAVQgDgPAAgGQAAgIADgNIACAAQgDANAAAIQAAALADAKg");
	this.shape_17.setTransform(186.3,65.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1D1D1C").s().p("AgFAMIAAgCQAIgKAAgFQAAgEgDAAQgDAAAAAFIgCAAQAAgHAFAAQAFAAAAAGQAAAFgHAKIAIAAIAAACg");
	this.shape_18.setTransform(184.8,67.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1D1D1C").s().p("AAAATIAAglIABAAIAAAlg");
	this.shape_19.setTransform(183.4,65.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#1D1D1C").s().p("AgCAWQACgLAAgLQAAgHgCgNIACAAQADAMAAAIQAAAGgDAQg");
	this.shape_20.setTransform(209.3,79.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#1D1D1C").s().p("AgHALIADAAQAAAFAEAAQAGAAABgIIAAgFQgDAFgEAAQgIAAAAgLQAAgPAIAAQADAAAEAFIAAgEIACAAIAAAVQAAALgEACQgDACgCAAQgHAAAAgIgAgFgEQAAAJAFAAQAHAAAAgJQAAgLgHAAQgFAAAAALg");
	this.shape_21.setTransform(207.6,79.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#1D1D1C").s().p("AABAWQgDgQAAgGQAAgEADgQIACAAQgDALAAAJQAAAKADAMg");
	this.shape_22.setTransform(205.9,79.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#1D1D1C").s().p("AgFAMIAAgCQAJgKAAgFQAAgEgEAAQgCAAAAAFIgCAAQAAgHAEAAQAGAAAAAGQAAAFgIAKIAIAAIAAACg");
	this.shape_23.setTransform(204.4,81.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#1D1D1C").s().p("AAAATIAAglIABAAIAAAlg");
	this.shape_24.setTransform(203.1,78.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#1D1D1C").s().p("AgHAFIACAAQABAGAEAAQAFAAAAgGQAAgDgFgCQgHAAABgFQgBgIAHAAQAHAAABAHIgEAAQABgEgFAAQgDAAgBAEQAAABABAAQAAABAAAAQABABAAAAQABABAAAAIAFACQAEAAAAAFQAAAJgIAAQgHAAAAgJg");
	this.shape_25.setTransform(208.5,92.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#1D1D1C").s().p("AgHAFQAAgFAFgBQABgBAGAAIAAgCQAAgGgFAAQgDAAAAAFIgDAAQAAgIAGAAQAHAAAAAJIABARIgDAAIAAgEQgCAFgDAAQgHAAAAgJgAgEAFQAAAGAEAAQAGAAgBgLQgKAAABAFg");
	this.shape_26.setTransform(206.3,92.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#1D1D1C").s().p("AgGANIAAgDIAKgTIgKAAIAAgDIANAAIAAADIgKATIAKAAIAAADg");
	this.shape_27.setTransform(204.3,92.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#1D1D1C").s().p("AgIAAQAAgEACgEQADgFADAAQAJAAAAANIgOAAQAAALAFAAQAFAAABgHIADAAQgCAKgHAAQgIAAAAgOgAAGgBQAAgJgGAAQgEAAgBAJIALAAIAAAAg");
	this.shape_28.setTransform(202.2,92.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#1D1D1C").s().p("AgEANIAAgZIADAAIAAAEQABgEACAAIACAAIAAADIgBgBQgEAAAAAJIAAAOg");
	this.shape_29.setTransform(200.4,92.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#1D1D1C").s().p("AgHADIAAgPIADAAIAAAPQAAAIAEAAQAFAAAAgKIAAgNIADAAIAAASIAAAHIgDAAIAAgFQgCAGgDAAQgHgBAAgKg");
	this.shape_30.setTransform(198.4,92.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#1D1D1C").s().p("AgIASIAAgdIAAgGIADAAIAAAEQACgEADgBQAJABAAAOQAAAMgJAAQgCAAgDgFIAAAOgAgFgEQAAAKAFAAQAGAAAAgKQAAgLgGAAQgFAAAAALg");
	this.shape_31.setTransform(196,93.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#1D1D1C").s().p("AANANIAAgPQAAgIgGAAQgGAAAAAKIAAANIgBAAIAAgPQAAgIgFAAQgHAAAAAKIAAANIgCAAIAAgZIACAAIAAAEQADgEAEAAQAFAAAAAFQADgFAFAAQAHAAAAAKIAAAPg");
	this.shape_32.setTransform(192.9,92.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#1D1D1C").s().p("AAAATIAAgZIABAAIAAAZgAAAgOIAAgEIABAAIAAAEg");
	this.shape_33.setTransform(190.5,92.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#1D1D1C").s().p("AAAANIAAgMIgJAAIAAgBIAJAAIAAgMIABAAIAAAMIAJAAIAAABIgJAAIAAAMg");
	this.shape_34.setTransform(187.4,92.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#1D1D1C").s().p("AgCAVQACgKAAgLQAAgIgCgMIACAAQADAOAAAGQAAAGgDAPg");
	this.shape_35.setTransform(184.1,92.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#1D1D1C").s().p("AgHAFIADAAQAAAGAEAAQAFAAAAgGQAAgDgFgCQgHAAABgFQgBgIAHAAQAHAAABAHIgEAAQAAgEgEAAQgEAAAAAEQAAABABAAQAAABAAAAQABABAAAAQABABABAAIAEACQAEAAAAAFQAAAJgIAAQgHAAAAgJg");
	this.shape_36.setTransform(182.5,92.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#1D1D1C").s().p("AABAVQgDgPAAgGQAAgGADgOIACAAQgDAMAAAIQAAALADAKg");
	this.shape_37.setTransform(180.9,92.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#1D1D1C").s().p("AgFAMIAAgCQAIgKAAgFQAAgEgDAAQgCAAAAAFIgCAAQAAgHAEAAQAFAAAAAGQAAAFgHAKIAIAAIAAACg");
	this.shape_38.setTransform(179.4,94.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#1D1D1C").s().p("AAAATIAAglIABAAIAAAlg");
	this.shape_39.setTransform(178.1,92.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#1D1D1C").s().p("AgIATIAAgEQAOgQAAgGQAAgIgGAAQgEABAAAHIgDAAQAAgKAHAAQAJAAAAAJQAAAGgGAGIgHAMIANAAIAAADg");
	this.shape_40.setTransform(105.3,74.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#1D1D1C").s().p("AgIAAQAAgNAIAAQAJAAAAANIgOAAQAAALAFAAQAFAAABgHIADAAQgCAKgHAAQgIAAAAgOgAAHAAQgBgKgGAAQgEAAgBAKIAMAAIAAAAg");
	this.shape_41.setTransform(101.7,75.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#1D1D1C").s().p("AgHAGIADAAQAAAFAEAAQAGAAAAgFQgBgEgFgCQgGAAAAgGQAAgHAGAAQAHAAABAHIgDAAQgBgEgEAAQgDAAgBAEQAAABABABQAAAAAAABQABAAAAAAQABABABAAIAFACQADAAAAAFQAAAJgIAAQgHAAAAgIg");
	this.shape_42.setTransform(99.5,75.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#1D1D1C").s().p("AgHAGQAAgGAEAAQACgBAGAAIAAgDQAAgGgFAAQgDAAAAAFIgDAAQABgIAFAAQAIAAAAAJIAAARIgDAAIAAgEIAAAAIAAAAQgCAFgDAAQgHAAAAgIgAgEAGQAAAFAEAAQAGAAgBgLQgJAAAAAGg");
	this.shape_43.setTransform(97.3,75.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#1D1D1C").s().p("AAAATIAAgWIgEAAIAAgDIAEAAIAAgFQAAgHADAAIACAAIAAADIgBAAQgEAAAAAGIAAADIAFAAIAAADIgFAAIAAAWg");
	this.shape_44.setTransform(95.5,74.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#1D1D1C").s().p("AABASIAAgfIgEAGIAAgEQADgDABgDIADAAIAAAjg");
	this.shape_45.setTransform(105.1,57);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#1D1D1C").s().p("AgIAAQAAgNAIAAQAJAAAAANIgOAAQAAALAFAAQAFAAABgHIADAAQgCAKgHAAQgIAAAAgOgAAHgBQgBgJgGAAQgEAAgBAJIAMAAIAAAAg");
	this.shape_46.setTransform(101.7,57.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#1D1D1C").s().p("AgHAGIADAAQAAAFAEAAQAGAAAAgGQgBgDgFgCQgGAAAAgFQAAgIAGAAQAHAAABAIIgDAAQgBgFgEAAQgDAAgBAEQABADADABIAFACQADAAAAAFQAAAJgIAAQgHAAAAgIg");
	this.shape_47.setTransform(99.5,57.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#1D1D1C").s().p("AgHAFQAAgFAEAAQADgCAFAAIAAgCQAAgGgFAAQgDAAAAAFIgDAAQABgIAFAAQAIAAAAAJIAAARIgDAAIAAgEIAAAAIAAAAQgCAFgDAAQgHAAAAgJgAAAAAQgEABAAAEQAAAGAEAAQAGAAgBgLIgFAAg");
	this.shape_48.setTransform(97.3,57.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#1D1D1C").s().p("AAAATIAAgWIgEAAIAAgCIAEAAIAAgHQAAgGADAAIACAAIAAADIgBAAQgEAAAAAGIAAAEIAFAAIAAACIgFAAIAAAWg");
	this.shape_49.setTransform(95.5,56.9);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#1D1D1C").s().p("AgIAAQAAgNAIAAQAJAAAAANIgOAAQAAALAFAAQAFAAABgHIADAAQgCAKgHAAQgIAAAAgOgAAHgBQgBgJgGAAQgEAAgBAJIAMAAIAAAAg");
	this.shape_50.setTransform(63.1,149.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#1D1D1C").s().p("AAAAJIAAgPIgFAAIAAgDIAFAAIAAgFIAAgCIAAAHIAFAAIAAADIgFAAIAAAQQAAABAAABQAAAAABABQAAAAABABQAAAAABAAIADAAIAAACIgEABQgCAAAAgIg");
	this.shape_51.setTransform(61.2,149.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#1D1D1C").s().p("AAGANIAAgPQAAgHgGAAQgEAAAAAJIAAANIgDAAIAAgTIAAgGIADAAIAAAEQACgEADAAQAHAAAAAKIAAAPg");
	this.shape_52.setTransform(59.3,149.7);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#1D1D1C").s().p("AgIAAQAAgNAIAAQAJAAAAANIgOAAQAAALAFAAQAFAAABgHIADAAQgCAKgHAAQgIAAAAgOgAAHgBQgBgJgGAAQgEAAgBAJIAMAAIAAAAg");
	this.shape_53.setTransform(56.9,149.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#1D1D1C").s().p("AAAANIgJgZIADAAIAGAVIAHgVIADAAIgJAZg");
	this.shape_54.setTransform(54.6,149.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#1D1D1C").s().p("AAAATIAAglIABAAIAAAlg");
	this.shape_55.setTransform(53.1,149.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#1D1D1C").s().p("AgJAAQAAgNAJAAQAKAAgBANQABAOgKAAQgJAAAAgOgAgGAAQABALAFAAQAHAAAAgLQAAgKgHAAQgFAAgBAKg");
	this.shape_56.setTransform(51.4,149.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#1D1D1C").s().p("AgHAFIADAAQAAAGAEAAQAFAAAAgGQAAgDgFgCQgGAAAAgFQAAgIAGAAQAHAAAAAIIgCAAQgBgFgEAAQgEAAAAAEQAAABAAAAQABABAAAAQAAABABAAQAAABABAAIAFACQAEAAAAAFQAAAJgIAAQgHAAAAgJg");
	this.shape_57.setTransform(49.1,149.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#1D1D1C").s().p("AAAATIAAgZIAAAAIAAAZgAAAgOIAAgEIABAAIAAAEg");
	this.shape_58.setTransform(47.6,149.1);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#1D1D1C").s().p("AgIAFQAAgMAIAAQAEAAACAEIAAgPIADAAIAAAeIAAAGIgDAAIAAgEQgDAFgDAAQgIAAAAgOgAgFAEQAAAMAFAAQAGAAAAgMQAAgIgGAAQgFAAAAAIg");
	this.shape_59.setTransform(45.9,149.2);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#1D1D1C").s().p("AgJAAQABgNAIAAQAEAAADAFQADAEAAAEQAAAOgKAAQgIAAgBgOgAgGAAQAAALAGAAQAHAAgBgLQABgKgHAAQgGAAAAAKg");
	this.shape_60.setTransform(19.3,101);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#1D1D1C").s().p("AgIAFQAAgMAIAAQAEAAACAFIABgBIAAgPIACAAIAAAkIgCAAIAAgEIgBAAQgDAFgDAAQgIAAAAgOgAgFAFQAAALAFAAQAGAAAAgMQAAgIgGAAQgFAAAAAJg");
	this.shape_61.setTransform(16.9,100.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#1D1D1C").s().p("AAAATIAAgZIABAAIAAAZgAAAgOIAAgEIABAAIAAAEg");
	this.shape_62.setTransform(15.2,100.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#1D1D1C").s().p("AAAATIAAglIABAAIAAAlg");
	this.shape_63.setTransform(14.3,100.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#1D1D1C").s().p("AgIAEQgBgMAJAAQAKAAgBAMQABAPgKAAQgJAAABgPgAgGAEQAAAMAGAAQAHAAAAgMQAAgJgHAAQgGAAAAAJgAAAgKIABgIIAEAAIgFAIg");
	this.shape_64.setTransform(12.6,100.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#1D1D1C").s().p("AgHAGIADAAQAAAFAEAAQAFAAAAgGQABgDgGgCQgGAAAAgFQAAgIAGAAQAHAAAAAIIgCAAQAAgFgFAAQgDAAAAAFQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAIAGACQADAAAAAFQAAAJgIAAQgHAAAAgIg");
	this.shape_65.setTransform(10.3,101);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#1D1D1C").ss(0.3,0,0,3.9).p("AgznMIiEAAAgbkcIicAAAuKgaIiFAAAs9HNIiFAAAQQl6Ii6AAAQQjyIi6AAAQQhuIi6AA");
	this.shape_66.setTransform(126.3,103.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AgGAAIAOAA");
	this.shape_67.setTransform(77.7,91.9);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAIAAIgOAA");
	this.shape_68.setTransform(77.7,95.9);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAOAAIgEAAQgIAAgEAAQgFgBAAgD");
	this.shape_69.setTransform(71.5,32);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AAIAEIgIACAgOgDQAFgBAHAAQARAAAAAE");
	this.shape_70.setTransform(72.9,31.4);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAAEQAAgDAFgB");
	this.shape_71.setTransform(70.7,31);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AATgEQAAADgGABQgFAAgIAAQgHAAgGAAQgFgBAAgD");
	this.shape_72.setTransform(72.5,90.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAEkIAApG");
	this.shape_73.setTransform(70.6,60.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAkiIAAJG");
	this.shape_74.setTransform(74.5,60.7);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAcADIgIABQgSAAgLgEQgNgCAAgG");
	this.shape_75.setTransform(70.4,91);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AAUAKQgMACgIABAgjgIQAOgEAPAAQAQAAANAEQANAEAAAE");
	this.shape_76.setTransform(73.3,90);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AgEAHQAAgHAOgB");
	this.shape_77.setTransform(68.7,89.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AAsgIQAAAGgNACQgNAEgSAAQgRAAgNgEQgNgCAAgG");
	this.shape_78.setTransform(72.5,98.2);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAAkIAAhG");
	this.shape_79.setTransform(68.1,93.7);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAgiIAABG");
	this.shape_80.setTransform(76.9,93.7);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#EAE8E9").ss(0.9,1,0,3.9).p("Ah1AAIDqAA");
	this.shape_81.setTransform(59.9,93.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#E5E3E3").ss(0.9,1,0,3.9).p("Ah0AAIDpAA");
	this.shape_82.setTransform(59.9,93.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#E0DEDE").ss(1,1,0,3.9).p("Ah0AAIDqAA");
	this.shape_83.setTransform(59.9,93.2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#DCD9DA").ss(1,1,0,3.9).p("Ah0AAIDpAA");
	this.shape_84.setTransform(59.9,93.2);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#D7D4D5").ss(1.1,1,0,3.9).p("Ah0AAIDpAA");
	this.shape_85.setTransform(60,93.2);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#D2D0D0").ss(1.2,1,0,3.9).p("Ah0AAIDpAA");
	this.shape_86.setTransform(60,93.2);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#CECBCB").ss(1.2,1,0,3.9).p("Ah0AAIDpAA");
	this.shape_87.setTransform(60,93.2);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#C9C6C7").ss(1.3,1,0,3.9).p("Ah0AAIDpAA");
	this.shape_88.setTransform(60.1,93.2);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#C5C2C2").ss(1.3,1,0,3.9).p("Ah0AAIDpAA");
	this.shape_89.setTransform(60.1,93.2);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#C0BDBD").ss(1.4,1,0,3.9).p("Ah0AAIDpAA");
	this.shape_90.setTransform(60.1,93.2);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#BBB8B8").ss(1.5,1,0,3.9).p("Ah0AAIDpAA");
	this.shape_91.setTransform(60.1,93.2);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#B6B3B3").ss(1.5,1,0,3.9).p("Ah0AAIDpAA");
	this.shape_92.setTransform(60.1,93.2);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("#B1AFAF").ss(1.6,1,0,3.9).p("Ah0AAIDpAA");
	this.shape_93.setTransform(60.2,93.2);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#ACAAAA").ss(1.7,1,0,3.9).p("AhzAAIDoAA");
	this.shape_94.setTransform(60.2,93.2);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#A8A6A6").ss(1.7,1,0,3.9).p("AhzAAIDoAA");
	this.shape_95.setTransform(60.2,93.2);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#A3A1A1").ss(1.8,1,0,3.9).p("AhzAAIDnAA");
	this.shape_96.setTransform(60.3,93.2);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#9E9D9D").ss(1.8,1,0,3.9).p("AhzAAIDnAA");
	this.shape_97.setTransform(60.3,93.2);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#9A9898").ss(1.9,1,0,3.9).p("AhzAAIDnAA");
	this.shape_98.setTransform(60.3,93.2);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#959494").ss(2,1,0,3.9).p("AhzAAIDnAA");
	this.shape_99.setTransform(60.3,93.2);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#90908F").ss(2,1,0,3.9).p("AhzAAIDnAA");
	this.shape_100.setTransform(60.4,93.2);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#8B8B8B").ss(2.1,1,0,3.9).p("AhzAAIDnAA");
	this.shape_101.setTransform(60.4,93.2);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#868787").ss(2.1,1,0,3.9).p("AhzAAIDnAA");
	this.shape_102.setTransform(60.4,93.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f().s("#818383").ss(2.2,1,0,3.9).p("AhzAAIDnAA");
	this.shape_103.setTransform(60.4,93.3);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#7D7F7F").ss(2.3,1,0,3.9).p("AhzAAIDnAA");
	this.shape_104.setTransform(60.5,93.3);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().s("#EAE8E9").ss(0.9,1,0,3.9).p("ACDgJQAAAIgnAFQgnAGg1AAQg0AAgngGQgmgFAAgI");
	this.shape_105.setTransform(35,94.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#E5E3E3").ss(0.9,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_106.setTransform(35,94.1);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("#E0DEDE").ss(0.9,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_107.setTransform(35,94.1);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("#DCD9DA").ss(1,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_108.setTransform(35,94.1);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().s("#D7D4D5").ss(1,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_109.setTransform(35,94.1);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#D2D0D0").ss(1.1,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_110.setTransform(35,94.1);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f().s("#CECBCB").ss(1.1,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_111.setTransform(35,94.1);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("#C9C6C7").ss(1.2,1,0,3.9).p("ACDgJQAAAIgnAFQgnAGg1AAQg0AAgngGQgmgFAAgI");
	this.shape_112.setTransform(35,94.2);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f().s("#C5C2C2").ss(1.2,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_113.setTransform(35,94.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().s("#C0BDBD").ss(1.3,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_114.setTransform(35,94.2);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f().s("#BBB8B8").ss(1.3,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg0AAgngGQgmgEAAgJ");
	this.shape_115.setTransform(35,94.2);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("#B6B3B3").ss(1.4,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_116.setTransform(35,94.2);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().s("#B1AFAF").ss(1.4,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_117.setTransform(35,94.2);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#ACAAAA").ss(1.5,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_118.setTransform(35,94.2);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f().s("#A8A6A6").ss(1.5,1,0,3.9).p("ACDgJQAAAIgnAFQgnAGg1AAQg0AAgngGQgmgFAAgI");
	this.shape_119.setTransform(35,94.3);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("#A3A1A1").ss(1.6,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_120.setTransform(35,94.3);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f().s("#9E9D9D").ss(1.6,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_121.setTransform(35,94.3);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f().s("#9A9898").ss(1.7,1,0,3.9).p("ACDgJQAAAIgnAFQgnAGg1AAQg0AAgngGQgmgFAAgI");
	this.shape_122.setTransform(35,94.3);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f().s("#959494").ss(1.7,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_123.setTransform(35,94.3);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f().s("#90908F").ss(1.8,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_124.setTransform(35,94.3);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f().s("#8B8B8B").ss(1.8,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_125.setTransform(35,94.3);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f().s("#868787").ss(1.9,1,0,3.9).p("ACDgJQAAAIgnAFQgnAGg1AAQg0AAgngGQgmgFAAgI");
	this.shape_126.setTransform(35,94.4);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f().s("#818383").ss(1.9,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_127.setTransform(35,94.4);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f().s("#7D7F7F").ss(2,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_128.setTransform(35,94.4);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AATgEQAAADgGABQgFAAgIAAQgSAAAAgE");
	this.shape_129.setTransform(72.5,159.3);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAE6IAApz");
	this.shape_130.setTransform(70.6,127.3);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAk5IAAJz");
	this.shape_131.setTransform(74.5,127.3);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AACAiIAAgJQAAgXgCgOQgCgQgEAA");
	this.shape_132.setTransform(79.5,91.5);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AAIAYQABgHABgRAgHgsQgCAMAAAYQAAAVADAQQADAQADAA");
	this.shape_133.setTransform(78.8,95);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAGgGQgGAAAAAS");
	this.shape_134.setTransform(78.1,89.3);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AgGA3QAEAAACgRQACgQAAgWQAAgVgCgRQgCgQgEAA");
	this.shape_135.setTransform(82.2,94);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AANAAIgZAA");
	this.shape_136.setTransform(80.1,88.5);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AgMAAIAZAA");
	this.shape_137.setTransform(80.1,99.5);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f().s("#EE851D").ss(0.3,0,0,3.9).p("AhWASICiAAQAGAAAAgSQABgRgFAAIiVAA");
	this.shape_138.setTransform(214.8,149.8);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f().s("#966D2F").ss(0.2,0,0,3.9).p("AArAOIgyAAQgCAEgDAAIgZgFIAAgZIAZgFQADAAACAEIAyAA");
	this.shape_139.setTransform(224.8,149.8);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f().s("#966D2F").ss(0.2,0,0,3.9).p("AAPkUIAAErQAIABAAABIAABhQAAABgIABIAABOIACAAQAkABAYAGQAYAFABAHQABAAgBACIAAALQAAAaAAABQgGAJgkAFQglAFgqgCQgmgBgYgGQgXgGACgHIAAglQAAgCADgDQAQgLBBgDIAAhOQgHgBAAgBIAAhgQAAgCAHgBIAAkrQASAEAPgEg");
	this.shape_140.setTransform(230.9,133.2);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AgHAAIAPAA");
	this.shape_141.setTransform(260.3,23.8);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAIAAIgPAA");
	this.shape_142.setTransform(260.3,27.8);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAOAAIgEAAQgRAAAAgE");
	this.shape_143.setTransform(254.1,8.3);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AAGAEIgHABAgRgDIANgBQARAAAAAE");
	this.shape_144.setTransform(255.7,7.7);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAAEQAAgCAFgC");
	this.shape_145.setTransform(253.3,7.3);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AATgEQAAAEgTAAQgSAAAAgE");
	this.shape_146.setTransform(255.1,22.1);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAABFIAAiI");
	this.shape_147.setTransform(253.2,14.7);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAhDIAACI");
	this.shape_148.setTransform(257.1,14.7);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAcADIgIABQgSAAgLgEQgNgCAAgG");
	this.shape_149.setTransform(253,22.8);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AAUAKQgMACgIABAgjgIQAOgEAPAAQAQAAANAEQANAEAAAE");
	this.shape_150.setTransform(255.9,21.9);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AgFAHQAAgGAOgC");
	this.shape_151.setTransform(251.3,21.2);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AAsgIQAAAGgNACQgNAEgSAAQgRAAgNgEQgNgCAAgG");
	this.shape_152.setTransform(255.1,30);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAAkIAAhH");
	this.shape_153.setTransform(250.7,25.5);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAgjIAABH");
	this.shape_154.setTransform(259.5,25.5);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f().s("#EAE8E9").ss(0.9,1,0,3.9).p("AhWAAICuAA");
	this.shape_155.setTransform(245.9,25);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f().s("#E5E3E3").ss(0.9,1,0,3.9).p("AhXAAICvAA");
	this.shape_156.setTransform(246,25);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f().s("#E0DEDE").ss(1,1,0,3.9).p("AhXAAICvAA");
	this.shape_157.setTransform(246,25);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f().s("#DCD9DA").ss(1,1,0,3.9).p("AhWAAICtAA");
	this.shape_158.setTransform(246,25);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f().s("#D7D4D5").ss(1.1,1,0,3.9).p("AhWAAICtAA");
	this.shape_159.setTransform(246,25);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f().s("#D2D0D0").ss(1.2,1,0,3.9).p("AhWAAICtAA");
	this.shape_160.setTransform(246,25);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f().s("#CECBCB").ss(1.2,1,0,3.9).p("AhWAAICtAA");
	this.shape_161.setTransform(246.1,25);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f().s("#C9C6C7").ss(1.3,1,0,3.9).p("AhWAAICtAA");
	this.shape_162.setTransform(246.1,25);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f().s("#C5C2C2").ss(1.3,1,0,3.9).p("AhWAAICtAA");
	this.shape_163.setTransform(246.1,25);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f().s("#C0BDBD").ss(1.4,1,0,3.9).p("AhWAAICtAA");
	this.shape_164.setTransform(246.2,25);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f().s("#BBB8B8").ss(1.5,1,0,3.9).p("AhWAAICtAA");
	this.shape_165.setTransform(246.2,25);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f().s("#B6B3B3").ss(1.5,1,0,3.9).p("AhWAAICtAA");
	this.shape_166.setTransform(246.2,25);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f().s("#B1AFAF").ss(1.6,1,0,3.9).p("AhWAAICtAA");
	this.shape_167.setTransform(246.2,25.1);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f().s("#ACAAAA").ss(1.7,1,0,3.9).p("AhVAAICrAA");
	this.shape_168.setTransform(246.3,25.1);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f().s("#A8A6A6").ss(1.7,1,0,3.9).p("AhWAAICtAA");
	this.shape_169.setTransform(246.3,25.1);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f().s("#A3A1A1").ss(1.8,1,0,3.9).p("AhVAAICrAA");
	this.shape_170.setTransform(246.3,25.1);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f().s("#9E9D9D").ss(1.8,1,0,3.9).p("AhWAAICsAA");
	this.shape_171.setTransform(246.4,25.1);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f().s("#9A9898").ss(1.9,1,0,3.9).p("AhWAAICsAA");
	this.shape_172.setTransform(246.4,25.1);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f().s("#959494").ss(2,1,0,3.9).p("AhVAAICrAA");
	this.shape_173.setTransform(246.4,25.1);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f().s("#90908F").ss(2,1,0,3.9).p("AhVAAICrAA");
	this.shape_174.setTransform(246.4,25.1);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f().s("#8B8B8B").ss(2.1,1,0,3.9).p("AhVAAICrAA");
	this.shape_175.setTransform(246.4,25.1);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f().s("#868787").ss(2.1,1,0,3.9).p("AhVAAICrAA");
	this.shape_176.setTransform(246.5,25.1);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f().s("#818383").ss(2.2,1,0,3.9).p("AhVAAICrAA");
	this.shape_177.setTransform(246.5,25.1);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f().s("#7D7F7F").ss(2.3,1,0,3.9).p("AhVAAICrAA");
	this.shape_178.setTransform(246.5,25.1);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AACAiIAAgJQAAgXgCgOQgCgQgEAA");
	this.shape_179.setTransform(262.1,23.3);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AAHAZQACgIABgRAgHgsQgCAMAAAYQAAAVADAQQADAQADAA");
	this.shape_180.setTransform(261.4,26.8);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAGgGQgFAAgBAS");
	this.shape_181.setTransform(260.7,21.1);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AgGA3QAEAAACgRQACgQAAgWQAAgVgCgRQgCgQgEAA");
	this.shape_182.setTransform(264.8,25.9);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AANAAIgZAA");
	this.shape_183.setTransform(262.7,20.4);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AgMAAIAZAA");
	this.shape_184.setTransform(262.7,31.4);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f().s("#EAE8E9").ss(0.9,1,0,3.9).p("AAogIQAAAGgXAEQgUAFgkAC");
	this.shape_185.setTransform(232.7,25.8);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f().s("#E5E3E3").ss(0.9,1,0,3.9).p("AAogJQAAAHgYAEQgUAFgjAD");
	this.shape_186.setTransform(232.7,25.9);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f().s("#E0DEDE").ss(0.9,1,0,3.9).p("AAogJQAAAHgYAEQgVAFgiAD");
	this.shape_187.setTransform(232.7,25.9);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f().s("#DCD9DA").ss(1,1,0,3.9).p("AAogIQAAAGgZAEQgWAFggAC");
	this.shape_188.setTransform(232.7,25.9);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f().s("#D7D4D5").ss(1,1,0,3.9).p("AAogIQAAAGgaAEQgWAGgfAB");
	this.shape_189.setTransform(232.7,25.9);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f().s("#D2D0D0").ss(1.1,1,0,3.9).p("AAogJQAAAHgbAEQgXAGgdAC");
	this.shape_190.setTransform(232.7,25.9);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f().s("#CECBCB").ss(1.1,1,0,3.9).p("AAogJQAAAHgcAFQgXAGgcAB");
	this.shape_191.setTransform(232.7,25.9);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f().s("#C9C6C7").ss(1.2,1,0,3.9).p("AAogIQAAAGgcAEQgYAGgbAB");
	this.shape_192.setTransform(232.7,25.9);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f().s("#C5C2C2").ss(1.2,1,0,3.9).p("AAogJQAAAHgdAFQgYAGgaAB");
	this.shape_193.setTransform(232.7,26);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f().s("#C0BDBD").ss(1.3,1,0,3.9).p("AAogJQAAAHgeAFQgZAGgYAB");
	this.shape_194.setTransform(232.7,26);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f().s("#BBB8B8").ss(1.3,1,0,3.9).p("AAogIQAAAGgeAFQgbAGgWAA");
	this.shape_195.setTransform(232.7,26);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f().s("#B6B3B3").ss(1.4,1,0,3.9).p("AAogIQAAAGgfAFQgcAGgUAA");
	this.shape_196.setTransform(232.7,26);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f().s("#B1AFAF").ss(1.4,1,0,3.9).p("AAogJQAAAHggAFQgbAGgUAB");
	this.shape_197.setTransform(232.7,26);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f().s("#ACAAAA").ss(1.5,1,0,3.9).p("AAogJQAAAHghAFQgcAHgSAA");
	this.shape_198.setTransform(232.7,26);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f().s("#A8A6A6").ss(1.5,1,0,3.9).p("AAogIQAAAGghAFQgdAHgRgB");
	this.shape_199.setTransform(232.7,26);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f().s("#A3A1A1").ss(1.6,1,0,3.9).p("AAogJQAAAGgiAGQgeAHgPgB");
	this.shape_200.setTransform(232.7,26.1);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f().s("#9E9D9D").ss(1.6,1,0,3.9).p("AAogJQAAAGgjAGQgfAHgNgB");
	this.shape_201.setTransform(232.7,26.1);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f().s("#9A9898").ss(1.7,1,0,3.9).p("AAogIQAAAGgkAFQggAHgLgB");
	this.shape_202.setTransform(232.7,26.1);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f().s("#959494").ss(1.7,1,0,3.9).p("AAogJQAAAGgkAGQghAHgKgB");
	this.shape_203.setTransform(232.7,26.1);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f().s("#90908F").ss(1.8,1,0,3.9).p("AAogJQAAAGglAGQgiAIgIgC");
	this.shape_204.setTransform(232.7,26.1);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f().s("#8B8B8B").ss(1.8,1,0,3.9).p("AAogIQAAAFgmAGQgkAIgFgC");
	this.shape_205.setTransform(232.7,26.1);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f().s("#868787").ss(1.9,1,0,3.9).p("AAogJQAAAGgnAGQgkAIgEgC");
	this.shape_206.setTransform(232.7,26.2);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f().s("#818383").ss(1.9,1,0,3.9).p("AAogJQAAAGgoAGQglAIgCgC");
	this.shape_207.setTransform(232.7,26.2);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f().s("#7D7F7F").ss(2,1,0,3.9).p("AAogJQAAAGgoAHQgnAIAAgD");
	this.shape_208.setTransform(232.6,26.2);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f().s("#666D6E").ss(2.8,1,0,3.9).p("AAogJQAAAHgXAEQgUAFgkAD");
	this.shape_209.setTransform(232.7,26.2);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AATgEQAAAEgTAAQgSAAAAgE");
	this.shape_210.setTransform(255.1,158.9);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAKOIAA0a");
	this.shape_211.setTransform(253.2,92.9);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAqMIAAUa");
	this.shape_212.setTransform(257.1,92.9);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f().s("#666D6E").ss(2.8,1,0,3.9).p("AhSAAIClAA");
	this.shape_213.setTransform(245.2,25.1);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f().s("#EAE8E9").ss(0.9,1,0,3.9).p("ACDgJQAAAIgnAFQgnAGg1AAQg0AAgngGQgmgFAAgI");
	this.shape_214.setTransform(130.5,62.1);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f().s("#E5E3E3").ss(0.9,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_215.setTransform(130.5,62.1);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f().s("#E0DEDE").ss(0.9,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_216.setTransform(130.5,62.1);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f().s("#DCD9DA").ss(1,1,0,3.9).p("ACDgJQAAAIgnAFQgmAGg2AAQg0AAgngGQgmgFAAgI");
	this.shape_217.setTransform(130.5,62.1);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f().s("#D7D4D5").ss(1,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_218.setTransform(130.5,62.1);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f().s("#D2D0D0").ss(1.1,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_219.setTransform(130.5,62.1);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f().s("#CECBCB").ss(1.1,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_220.setTransform(130.5,62.1);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f().s("#C9C6C7").ss(1.2,1,0,3.9).p("ACDgJQAAAIgnAFQgnAGg1AAQg0AAgngGQgmgFAAgI");
	this.shape_221.setTransform(130.5,62.2);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f().s("#C5C2C2").ss(1.2,1,0,3.9).p("ACCgJQAAAJgmAEQgnAGg1AAQg1AAgmgGQgngEAAgJ");
	this.shape_222.setTransform(130.5,62.2);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f().s("#C0BDBD").ss(1.3,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_223.setTransform(130.5,62.2);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f().s("#BBB8B8").ss(1.3,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg0AAgngGQgmgEAAgJ");
	this.shape_224.setTransform(130.5,62.2);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f().s("#B6B3B3").ss(1.4,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_225.setTransform(130.5,62.2);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f().s("#B1AFAF").ss(1.4,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_226.setTransform(130.5,62.2);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f().s("#ACAAAA").ss(1.5,1,0,3.9).p("ACCgJQAAAJgmAEQgnAGg1AAQg1AAgmgGQgngEAAgJ");
	this.shape_227.setTransform(130.5,62.2);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f().s("#A8A6A6").ss(1.5,1,0,3.9).p("ACDgJQAAAIgnAFQgnAGg1AAQg0AAgngGQgmgFAAgI");
	this.shape_228.setTransform(130.5,62.3);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f().s("#A3A1A1").ss(1.6,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_229.setTransform(130.5,62.3);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f().s("#9E9D9D").ss(1.6,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_230.setTransform(130.5,62.3);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f().s("#9A9898").ss(1.7,1,0,3.9).p("ACDgJQAAAIgnAFQgnAGg1AAQg0AAgngGQgmgFAAgI");
	this.shape_231.setTransform(130.5,62.3);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f().s("#959494").ss(1.7,1,0,3.9).p("ACCgJQAAAJgmAEQgnAGg1AAQg1AAgmgGQgngEAAgJ");
	this.shape_232.setTransform(130.5,62.3);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f().s("#90908F").ss(1.8,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_233.setTransform(130.5,62.3);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f().s("#8B8B8B").ss(1.8,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_234.setTransform(130.5,62.3);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f().s("#868787").ss(1.9,1,0,3.9).p("ACDgJQAAAIgnAFQgnAGg1AAQg0AAgngGQgmgFAAgI");
	this.shape_235.setTransform(130.5,62.4);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f().s("#818383").ss(1.9,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_236.setTransform(130.5,62.4);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f().s("#7D7F7F").ss(2,1,0,3.9).p("ACCgJQAAAJgmAEQgnAGg1AAQg1AAgmgGQgngEAAgJ");
	this.shape_237.setTransform(130.5,62.4);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f().s("#666D6E").ss(2.8,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_238.setTransform(130.5,62.4);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f().s("#508796").ss(0.2,0,0,3.9).p("Ag2gGQAAAEAQACQARACAVAAQAWAAARgCQAQgCAAgE");
	this.shape_239.setTransform(129.9,106.8);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f().s("#508796").ss(0.2,0,0,3.9).p("AATGNIAAgmQAAgoAXgQQAmgbAHg0IAujKQAEgWAAgVQAAg8gXgtQgYgugrgPQgLgEgFgPIgDgOIAAigQACgIAEAAQACAAAAgDQAAgFgDAAIhCgBQgDAAAAADQAAAFACAAQAEAAACAHIAAChIgDANQgEAOgMAGQgqAPgYAvQgXAsAAA9QAAAVAEAWIAuDKQAEAaALAUQAMAVARAMQAXANAAAsQAAAmAAAA");
	this.shape_240.setTransform(130.2,50.4);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f().s("#508796").ss(0.2,0,0,3.9).p("AgzkAQAAgEAQgEQARgDAUAAQAXAAAQADQARAEAAAEQAAAEgRADQgQADgXAAQgVAAgQgDQgQgDAAgEgACEEMQgsgRhXAAQhZAAgqAR");
	this.shape_241.setTransform(129.6,131.8);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AgHAAIAPAA");
	this.shape_242.setTransform(160.1,59.9);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAIAAIgPAA");
	this.shape_243.setTransform(160.1,63.9);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAOAAIgEAAQgRAAAAgE");
	this.shape_244.setTransform(153.8,10.1);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AAGAEQgEACgDAAAgRgDQALgCACAAQAGAAAFADQAGABAAAB");
	this.shape_245.setTransform(155.4,9.5);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAAEQAAgDAFgB");
	this.shape_246.setTransform(153.1,9.1);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AATgEQAAADgGABQgGAAgHAAQgHAAgGAAQgFgBAAgD");
	this.shape_247.setTransform(154.9,58.4);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAADxIAAnh");
	this.shape_248.setTransform(152.9,33.7);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAjwIAAHh");
	this.shape_249.setTransform(156.8,33.7);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAcADIgIABQgSAAgLgEQgNgCAAgG");
	this.shape_250.setTransform(152.8,59);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AgjgIQAOgEAPAAQAQAAANAEQANAEAAAEAAUAKQgMACgIAB");
	this.shape_251.setTransform(155.6,58);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AgEAHQAAgHAOgB");
	this.shape_252.setTransform(151,57.3);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AAsgIQAAAGgNACQgNAEgSAAQgRAAgNgEQgNgCAAgG");
	this.shape_253.setTransform(154.9,66.2);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAAkIAAhG");
	this.shape_254.setTransform(150.5,61.7);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAgiIAABG");
	this.shape_255.setTransform(159.3,61.7);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f().s("#EAE8E9").ss(0.9,1,0,3.9).p("AgyAAIBlAA");
	this.shape_256.setTransform(149.1,61.1);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f().s("#E5E3E3").ss(0.9,1,0,3.9).p("AgyAAIBlAA");
	this.shape_257.setTransform(149.1,61.1);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f().s("#E0DEDE").ss(1,1,0,3.9).p("AgzAAIBmAA");
	this.shape_258.setTransform(149.1,61.2);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f().s("#DCD9DA").ss(1,1,0,3.9).p("AgyAAIBlAA");
	this.shape_259.setTransform(149.1,61.2);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f().s("#D7D4D5").ss(1.1,1,0,3.9).p("AgyAAIBlAA");
	this.shape_260.setTransform(149.1,61.2);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f().s("#D2D0D0").ss(1.2,1,0,3.9).p("AgyAAIBlAA");
	this.shape_261.setTransform(149.2,61.2);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f().s("#CECBCB").ss(1.2,1,0,3.9).p("AgyAAIBlAA");
	this.shape_262.setTransform(149.2,61.2);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f().s("#C9C6C7").ss(1.3,1,0,3.9).p("AgyAAIBlAA");
	this.shape_263.setTransform(149.2,61.2);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f().s("#C5C2C2").ss(1.3,1,0,3.9).p("AgyAAIBlAA");
	this.shape_264.setTransform(149.3,61.2);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f().s("#C0BDBD").ss(1.4,1,0,3.9).p("AgyAAIBlAA");
	this.shape_265.setTransform(149.3,61.2);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f().s("#BBB8B8").ss(1.5,1,0,3.9).p("AgyAAIBlAA");
	this.shape_266.setTransform(149.3,61.2);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f().s("#B6B3B3").ss(1.5,1,0,3.9).p("AgyAAIBlAA");
	this.shape_267.setTransform(149.3,61.2);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f().s("#B1AFAF").ss(1.6,1,0,3.9).p("AgyAAIBkAA");
	this.shape_268.setTransform(149.4,61.2);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f().s("#ACAAAA").ss(1.7,1,0,3.9).p("AgyAAIBlAA");
	this.shape_269.setTransform(149.4,61.2);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f().s("#A8A6A6").ss(1.7,1,0,3.9).p("AgxAAIBkAA");
	this.shape_270.setTransform(149.4,61.2);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f().s("#A3A1A1").ss(1.8,1,0,3.9).p("AgyAAIBkAA");
	this.shape_271.setTransform(149.5,61.2);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f().s("#9E9D9D").ss(1.8,1,0,3.9).p("AgyAAIBkAA");
	this.shape_272.setTransform(149.5,61.2);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f().s("#9A9898").ss(1.9,1,0,3.9).p("AgxAAIBjAA");
	this.shape_273.setTransform(149.5,61.2);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f().s("#959494").ss(2,1,0,3.9).p("AgxAAIBjAA");
	this.shape_274.setTransform(149.5,61.2);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f().s("#90908F").ss(2,1,0,3.9).p("AgxAAIBjAA");
	this.shape_275.setTransform(149.5,61.2);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f().s("#8B8B8B").ss(2.1,1,0,3.9).p("AgxAAIBjAA");
	this.shape_276.setTransform(149.6,61.2);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f().s("#868787").ss(2.1,1,0,3.9).p("AgxAAIBjAA");
	this.shape_277.setTransform(149.6,61.2);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f().s("#818383").ss(2.2,1,0,3.9).p("AgxAAIBjAA");
	this.shape_278.setTransform(149.6,61.3);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f().s("#7D7F7F").ss(2.3,1,0,3.9).p("AgxAAIBjAA");
	this.shape_279.setTransform(149.7,61.3);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AATgEQAAAEgTAAQgSAAAAgE");
	this.shape_280.setTransform(154.9,160.7);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAAHhIAAvB");
	this.shape_281.setTransform(152.9,112);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAAngIAAPB");
	this.shape_282.setTransform(156.8,112);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AACAiIAAgJQAAgXgCgOQgCgQgEAA");
	this.shape_283.setTransform(161.9,59.5);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AgHgsQgCAMAAAYQAAAVADAQQADAQADAAAAHAYQACgHABgR");
	this.shape_284.setTransform(161.1,63);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAGgGQgGAAAAAS");
	this.shape_285.setTransform(160.5,57.3);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AgGA3QAEAAACgRQACgQAAgWQAAgVgCgRQgCgQgEAA");
	this.shape_286.setTransform(164.5,62);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AANAAIgZAA");
	this.shape_287.setTransform(162.4,56.5);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AgMAAIAZAA");
	this.shape_288.setTransform(162.4,67.5);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f().s("#666D6E").ss(2.8,1,0,3.9).p("Ag2AAIBtAA");
	this.shape_289.setTransform(149.3,61.3);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f().s("#7D9FAB").ss(0.2,0,0,3.9).p("ACQgNQAAAKgqAFQgrAHg7AAQg6AAgqgHQgrgFAAgK");
	this.shape_290.setTransform(35,88.3);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f().s("#666D6E").ss(2.8,1,0,3.9).p("ACDgJQAAAJgnAEQgmAGg2AAQg1AAgmgGQgmgEAAgJ");
	this.shape_291.setTransform(35,94.4);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f().s("#7D9FAB").ss(0.2,0,0,3.9).p("ACmgLQAAAIgpAGQgtAIg+AAQhJAAhDgOQgrgFAAgD");
	this.shape_292.setTransform(22.3,117.9);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f().s("#508796").ss(0.2,0,0,3.9).p("ACfi2IAAGMQAAAYgNAHQgkARhUACQhUACgtgSQgIgDgFgLQgEgJAAgLIAAlXQAAgzgtg5QAAAAAAgBQAAgBASgCQAUgDADgBQBDgSBLAAQA9AAAtAJQAqAIAAAIQAAADAAAFQgBAGgBAAQgFADgBAPQAAAIABAQgAiljtQADACAoAFQBDAQBJAAQA9AAAtgIQAqgIAAgI");
	this.shape_293.setTransform(22.3,140.6);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f().s("#666D6E").ss(2.8,1,0,3.9).p("Aj7AKQAAgJAmgEQAmgGA2AAQA2AAAmAGQAkAEAAAJAAKAIIDyAA");
	this.shape_294.setTransform(47.2,92.4);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("ADBg0IAbBBIAAAoIm2AAIAGhpg");
	this.shape_295.setTransform(63.6,160.7);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f().s("#666D6E").ss(2.8,1,0,3.9).p("AiAAKQAAgJAmgEQAmgGA0AAQA1AAAmAGQAmAEAAAJ");
	this.shape_296.setTransform(130.4,60.4);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AkAANIAJhBIHdAAIAaBBIAAAoIoAAAg");
	this.shape_297.setTransform(136.8,162.7);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AABAZIAAgHQAAgQgBgKQgBgLgEAA");
	this.shape_298.setTransform(135.2,91.1);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f().s("#939292").ss(0.2,0,0,3.9).p("AAFARIACgRAgEgfQgCAJAAAQQAAAPACAMQACALACAA");
	this.shape_299.setTransform(134.5,93.7);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AAFgEQgEAAgBAN");
	this.shape_300.setTransform(134,89.6);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f().s("#515E5F").ss(0.2,0,0,3.9).p("AgFAnQAEAAABgLQABgMAAgQQAAgPgBgMQgBgLgEAA");
	this.shape_301.setTransform(137.1,93);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AAJAAIgRAA");
	this.shape_302.setTransform(135.5,89.1);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f().s("#7D7F7F").ss(0.2,0,0,3.9).p("AgIAAIARAA");
	this.shape_303.setTransform(135.5,97);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f().s("#508796").ss(0.2,0,0,3.9).p("AB9CWQAAADgEADQgFAqgXAhIgBACQgSAZgXAOQgZAOgaAAQgZAAgYgNQgXgNgRgWIgGgIQgWgigFgpQgBgCAAgDQgBgJAAgKQAAguAUgmQATglAggRQAPgLAAgPIAAjkQAAgJgIgEQgDgBAAgEQAAgGAFAAIBXAAQAFAAAAAGQAAADgDACQgHAEAAALIAADiQAAAQALAIIABAAQAhARAUAmQAUAmAAAvQAAAMgCANQgIAFgZAFQglAGgzAAQg0AAgkgGQgbgFgHgG");
	this.shape_304.setTransform(230.4,37);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f().s("#666D6E").ss(2.8,1,0,3.9).p("AgmgJQAjADAUAGQAWADAAAH");
	this.shape_305.setTransform(232.6,24.3);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f().s("#525957").ss(0.3,0,0,3.9).p("AiTAAIEnAA");
	this.shape_306.setTransform(230.3,89.5);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f().s("#525957").ss(0.2,0,0,3.9).p("AiTgWIEpAAAiVgSIEsAAAiWgNIEvAAAiYgLIExAAAiYgIIEyAAAiagEIE2AAAibgBIE3AAAibAAIE4AAAidACIE7AAAidAEIE8AAAifAHIE/AAAigAKIFBAAAigAMIFBAAAihAPIFDAAAiiASIFFAAAijAUIFHAAAikAXIFJAA");
	this.shape_307.setTransform(230.3,92.1);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f().s("#525957").ss(0.3,0,0,3.9).p("AilgEIFLAAAimgBIFNAAAinAAIFPAAAioADIFRAAAipAFIFTAA");
	this.shape_308.setTransform(230.2,95.3);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f().s("#525957").ss(0.2,0,0,3.9).p("AB7AjIgBgDIgMAAIAAADABiAjIgBgDIgMAAIABADABVgjIAMBDIANAAIgOhDACTAjIgBgDIgMAAIABADACrAgIgMAAIABADAB/gjIATBDIANAAIgVhDABqgjIAQBDIAMAAIgRhDAh6AjIABgDIgNAAIAAADAiTAjIABgDIgMAAIgBADAh9gjIgVBDIAMAAIAUhDAiqAgIAMAAIAXhDAAYAjIAAgDIgMAAIAAADAAAAjIAAgDIgLAAIAAADAAAgjIAABDIAMAAIgBhDABJAjIAAgDIgNAAIABADAArgjIAFBDIAMAAIgHhDAAxAjIgBgDIgMAAIAAADAAWgjIACBDIAMAAIgEhDAgIgjIgDBDIgMAAIAAADABJAgIgJhDAhJAjIABgDIgMAAIgBADAhhAjIAAgDIgMAAIAQhDAhSgjIgPBDIANAAIAMhDAhngjIgSBDIAMAAIgBADAgXAgIgNAAIAAADAgogjIgIBDIAMAAIAHhDAgwAjIAAgDIgMAAIAAADAg9gjIgLBDIAMAAIAJhDAgXAgIAEhDABKgjIALBDIgMAA");
	this.shape_309.setTransform(230.2,92.9);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f().s("#666D6E").ss(0.2,0,0,3.9).p("AD/g0IAaBBIAAAoIoxAAIAAgoIAIhBg");
	this.shape_310.setTransform(234.6,160.9);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#FFFCE4").s().p("AgJAVQgHgEgCgQQgCgHgEgKIgDgJQAMARAPABQAQAAAMgSIgDAJQgFAKgBAHQgCAQgHAEQgGAEgEABIgJgFg");
	this.shape_311.setTransform(230.8,103.7);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#F8F6E5").s().p("AgKAYQgJgFgCgTQgBgHgEgMIgFgJQAOATARAAQASABAOgUIgFAJQgEAMgBAHQgCATgJAFQgGAEgFABQgEgBgGgEg");
	this.shape_312.setTransform(230.8,103.4);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#F0F0E6").s().p("AgMAaQgJgEgDgVQgBgJgFgNIgFgKQAQAVATAAQAVAAAPgVIgFAKQgFANgCAJQgCATgJAGQgIAGgFABQgEgBgIgGg");
	this.shape_313.setTransform(230.8,103.1);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#E8EBE7").s().p("AgNAeQgKgHgDgWQgBgKgGgOIgGgMQASAYAVAAQAYAAAPgYIgFAMQgFAOgCAKQgCAWgKAHQgJAEgGACQgFgCgIgEg");
	this.shape_314.setTransform(230.8,102.7);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#E0E5E8").s().p("AgPAgQgLgHgDgYQgBgLgGgQIgGgMQATAaAXAAQAaAAARgaIgGAMQgGAQgBALQgDAYgLAHQgKAGgGABQgFgBgKgGg");
	this.shape_315.setTransform(230.8,102.4);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#D7DFE9").s().p("AgRAjQgLgHgDgbQgCgMgGgRIgHgOQAUAcAaABQAcAAATgdIgHAOQgHARgBAMQgDAbgMAHQgKAGgHACQgGgCgLgGg");
	this.shape_316.setTransform(230.8,102);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#CFD9E9").s().p("AgRAmQgNgHgEgdQgBgOgIgSIgHgPQAXAeAbAAQAeABAVgfIgHAPQgHASgCAOQgDAcgNAIQgLAHgIABQgGgBgLgHg");
	this.shape_317.setTransform(230.8,101.7);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#C6D3EA").s().p("AgTApQgNgIgFgfQgBgPgIgTIgIgQQAYAgAeAAQAhABAWghIgIAQQgIATgCAPQgDAegOAJQgMAHgIABQgHgBgMgHg");
	this.shape_318.setTransform(230.8,101.3);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#BECEEA").s().p("AgUAsQgPgJgEghQgCgQgIgUIgIgSQAZAjAgAAQAkAAAWgjIgIASQgIAUgCAQQgEAhgOAJQgNAHgJACQgHgCgNgHg");
	this.shape_319.setTransform(230.8,101);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#BECEEA").s().p("AgUAqQgPgIgEghQgCgQgIgUIgIgSQAZAjAgAAQAkAAAWgjIgIASQgIAUgCAQQgEAhgOAIQgNAIgJAEg");
	this.shape_320.setTransform(230.8,101.1);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#C1CBE4").s().p("AgUArQgQgJgDghQgCgQgJgVIgIgSQAaAjAgABQAkAAAXgkIgIASQgJAVgCAQQgDAhgPAJQgNAIgJAEIgUgMg");
	this.shape_321.setTransform(230.8,101);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#C3C9DE").s().p("AgVAsQgPgJgEgiQgCgQgJgWIgIgSQAaAlAhgBQAkABAYglIgIASQgJAWgCAQQgDAigQAJQgNAIgJAEQgIgEgNgIg");
	this.shape_322.setTransform(230.8,100.9);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#C6C6D7").s().p("AgVAtQgIgFgGgNQgEgMgBgOQgDgQgIgWIgJgSQAbAkAhAAQAkABAZglIgJASQgIAWgCAQQgEAigPAKQgOAIgJADQgIgDgNgIg");
	this.shape_323.setTransform(230.8,100.8);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#C8C3D1").s().p("AgVAtQgQgJgEgjQgCgQgKgXIgIgSQAbAkAiABQAlAAAZglIgJASQgIAXgDAQQgEAjgPAJQgOAIgJAEQgIgEgNgIg");
	this.shape_324.setTransform(230.8,100.8);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#CBC0CA").s().p("AgWAuQgQgKgEgjQgCgRgJgXIgJgSQAbAlAjABQAlAAAagmIgJASQgJAXgCARQgEAjgQAKQgOAIgJAEIgWgMg");
	this.shape_325.setTransform(230.8,100.7);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#CDBDC4").s().p("AgWAvQgQgKgEgjQgDgSgJgXIgJgTQAcAnAjgBQAmABAagnIgJATQgKAXgCASQgEAjgQAKQgOAIgJADQgIgDgOgIg");
	this.shape_326.setTransform(230.8,100.6);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#CFBABE").s().p("AgWAwQgRgKgEgkQgCgSgKgXIgJgTQAdAnAjgBQAmABAbgnIgJATQgJAXgDASQgDAjgRALQgOAIgKADQgIgDgOgIg");
	this.shape_327.setTransform(230.8,100.5);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#D1B7B7").s().p("AgXAwQgRgKgEglQgCgSgKgXIgJgTQAQAWASAJQAOAIARAAQAnAAAbgnIgJATQgKAXgCASQgEAlgRAKQgOAJgKADQgJgDgOgJg");
	this.shape_328.setTransform(230.8,100.4);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#D3B4B1").s().p("AgXAxQgSgKgEglQgBgTgLgYIgIgTQAdAnAkAAQAnABAcgoIgJATQgLAYgBATQgFAlgRAKQgOAIgKAEQgJgEgOgIg");
	this.shape_329.setTransform(230.8,100.3);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#D5B0AA").s().p("AgXAxQgSgKgEglQgCgTgKgYIgJgUQAdAoAlAAQAoABAcgpIgKAUQgKAYgCATQgEAlgRAKQgPAKgKADQgJgDgOgKg");
	this.shape_330.setTransform(230.8,100.2);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#D7ADA4").s().p("AgYAyQgRgKgFgmQgCgTgJgYIgKgUQAdAoAmAAQApABAbgpIgJAUQgKAYgCATQgFAmgRAKQgOAJgLAEQgJgEgPgJg");
	this.shape_331.setTransform(230.8,100.1);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#D9A99E").s().p("AgYAzQgSgLgFgmQgBgTgKgZIgKgUQARAXASAKQAPAIASAAQAqAAAbgpIgKAUQgKAZgBATQgCAQgGANQgFAPgKAFQgPAJgKADQgJgDgPgJg");
	this.shape_332.setTransform(230.8,100);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#DBA697").s().p("AgYA0QgJgGgHgPQgFgNgCgQQgCgTgKgZIgKgVQARAXATAKQAPAJASAAQAqABAcgrIgKAVQgJAZgDATQgCAQgFANQgGAPgJAGQgPAJgLADQgJgDgPgJg");
	this.shape_333.setTransform(230.8,99.9);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#DCA291").s().p("AgZA1QgJgGgGgQQgGgNgCgRQgCgTgKgZIgKgVQARAYAUAKQAPAIASAAQAqABAdgrIgKAVQgKAZgCATQgEAogTAMQgPAIgLAEQgJgEgQgIg");
	this.shape_334.setTransform(230.8,99.9);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#DE9E8A").s().p("AgaA2QgSgLgEgpQgCgUgLgZIgKgWQARAYATALQARAIASABQArAAAdgsIgKAWQgLAZgCAUQgEApgTALQgPAJgLADQgKgDgQgJg");
	this.shape_335.setTransform(230.8,99.7);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#DF9A84").s().p("AgaA2QgSgLgFgpQgCgUgLgaIgKgWQASAZATAKQAQAJATABQAsgBAdgsIgKAWQgLAagCAUQgFApgSALQgQAKgLADQgKgDgQgKg");
	this.shape_336.setTransform(230.8,99.7);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#E1967E").s().p("AgaA3QgTgLgEgqQgDgUgLgaIgKgWQAhAsAoAAQAsABAegtIgKAWQgLAagDAUQgBARgGAOQgHAQgJAGQgQAJgLADQgKgDgQgJg");
	this.shape_337.setTransform(230.8,99.6);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#E29277").s().p("AgbA4QgJgGgGgQQgHgPgBgRQgCgVgLgaIgLgWQASAZAUALQAQAIAUABQAtAAAegtIgKAWQgLAagDAVQgBARgHAPQgGAQgJAGQgRAJgLADQgKgDgRgJg");
	this.shape_338.setTransform(230.8,99.5);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#E48E71").s().p("AgbA4QgKgFgGgRQgGgOgCgSQgDgVgKgaIgLgXQATAZAUALQARAJATABQAtAAAfguIgKAXQgMAagCAVQgFArgTALQgRAKgLADQgKgDgRgKg");
	this.shape_339.setTransform(230.8,99.4);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#E58A6B").s().p("AgbA5QgUgMgEgqQgDgWgLgbIgKgWQASAZAUALQARAJAUAAQAuABAeguIgKAWQgLAbgDAWQgEAqgUAMQgRAKgLACQgKgCgRgKg");
	this.shape_340.setTransform(230.8,99.3);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#E68664").s().p("AgcA5QgKgFgGgQQgGgPgCgSQgCgWgLgcIgLgWQASAaAVALQARAJAUAAQAuABAfgvIgKAWQgLAcgDAWQgFArgTALQgSALgLACQgKgCgSgLg");
	this.shape_341.setTransform(230.8,99.2);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#E8825E").s().p("AgcA6QgKgGgHgQQgGgQgCgSQgDgVgLgcIgKgXQATAaAUALQARAJAVABQAvAAAfgvIgLAXQgLAcgDAVQgBASgGAQQgHAQgKAGQgRALgMACQgLgCgRgLg");
	this.shape_342.setTransform(230.8,99.1);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#E97D58").s().p("AgcA7QgKgGgHgRQgHgPgCgSQgCgWgLgdIgLgXQAUAaAUAMQASAJAUABQAvAAAggwIgLAXQgLAdgCAWQgGArgUANQgRALgMACQgLgCgRgLg");
	this.shape_343.setTransform(230.8,99);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#EA7952").s().p("AgdA8QgKgGgHgRQgGgQgCgSQgCgXgMgcIgLgYQATAbAWAMQASAJAUAAQAvABAhgxIgLAYQgMAcgCAXQgCASgGAQQgHARgKAGQgSAKgMADQgLgDgSgKg");
	this.shape_344.setTransform(230.8,98.9);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#EB744C").s().p("AgdA8QgKgGgHgRQgHgQgCgTQgCgWgMgdIgLgYQATAbAWAMQASAJAVABQAwABAhgyIgLAYQgLAdgDAWQgCATgGAQQgIARgKAGQgSALgMADQgMgDgRgLg");
	this.shape_345.setTransform(230.8,98.9);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#EB744C").s().p("AgdA8QgKgGgHgRQgHgQgCgTQgCgWgMgdIgLgYQATAbAWAMQASAJAVABQAwABAhgyIgLAYQgLAdgDAWQgCATgGAQQgIARgKAGQgSALgMADQgMgDgRgLg");
	this.shape_346.setTransform(230.8,98.9);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#EC7B52").s().p("AgdA9QgKgGgIgSQgGgPgCgTQgDgXgLgdIgMgYQAUAbAWAMQASAKAVAAQAwABAigyIgMAYQgLAdgDAXQgFAugVAMQgSALgMACQgMgCgRgLg");
	this.shape_347.setTransform(230.8,98.8);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#ED8258").s().p("AgeA+QgKgHgHgRQgHgQgCgTQgCgXgMgdIgMgZQAVAcAWALQASAKAVABQAXAAASgKQAXgMATgcIgMAZQgMAdgCAXQgCATgHAQQgHARgKAHQgSAKgNADQgMgDgSgKg");
	this.shape_348.setTransform(230.8,98.7);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#EE895E").s().p("AgeA+QgKgHgIgRQgGgPgCgUQgDgYgMgdIgLgZQAUAdAXALQASAKAVABQAzAAAggzIgMAZQgLAdgDAYQgCAUgGAPQgIARgKAHQgSALgNADQgMgDgSgLg");
	this.shape_349.setTransform(230.8,98.7);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#EF9065").s().p("AgeA/QgKgHgIgSQgGgPgDgUQgCgXgNgeIgLgZQAVAcAWAMQATAKAVAAQAyABAigzIgLAZQgMAegDAXQgCAUgHAPQgHASgLAHQgSALgNACQgMgCgSgLg");
	this.shape_350.setTransform(230.8,98.6);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#F0976B").s().p("AgeA/QgLgGgHgTQgHgQgCgTQgDgYgMgeIgMgZQAVAdAXAMQATAKAVAAQAyABAjg0IgMAZQgMAegDAYQgCATgHAQQgHATgLAGQgSALgNADQgMgDgSgLg");
	this.shape_351.setTransform(230.8,98.5);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#F29D72").s().p("AgfBAQgLgHgHgSQgHgQgCgUQgDgYgMgfIgLgYQAUAcAXAMQATALAWAAQAYAAATgKQAXgMATgdIgMAYQgMAfgDAYQgCAUgGAQQgIASgLAHQgSALgNADQgMgDgTgLg");
	this.shape_352.setTransform(230.8,98.5);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#F2A479").s().p("AgeBBQgLgHgIgTQgGgQgDgUQgDgYgMgeIgMgaQAVAdAXAMQATAKAWABQA0AAAig0IgMAaQgMAegDAYQgCAUgHAQQgHATgLAHQgTALgNACQgMgCgSgLg");
	this.shape_353.setTransform(230.8,98.4);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#F4AA80").s().p("AgfBBQgLgHgHgSQgHgQgCgVQgDgYgNgfIgLgaQAUAdAYANQATAKAWAAQA0ABAig1IgLAaQgNAfgDAYQgCAUgGARQgIASgLAHQgTALgNADQgMgDgTgLg");
	this.shape_354.setTransform(230.8,98.3);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#F5B187").s().p("AgfBBQgWgNgGgxQgDgZgNgfIgLgZQAVAdAXAMQAUALAWAAQA1ABAig1IgLAZQgNAfgDAZQgCAUgHARQgIATgLAGQgTAMgNACQgMgCgTgMg");
	this.shape_355.setTransform(230.8,98.3);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#F6B78E").s().p("AgfBCQgXgNgFgyQgEgZgMgfIgMgaQAWAdAXANQAUAKAWABQA1AAAjg1IgMAaQgMAfgEAZQgBAVgIAQQgHATgMAHQgTAMgNACQgNgCgSgMg");
	this.shape_356.setTransform(230.8,98.2);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#F7BD95").s().p("AggBDQgLgHgIgTQgHgRgCgVQgDgZgNggIgMgaQAWAeAXANQAUAKAXABQA1ABAkg3IgNAaQgMAggDAZQgCAVgHARQgIATgLAHQgUALgNADQgNgDgTgLg");
	this.shape_357.setTransform(230.8,98.1);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#F8C39C").s().p("AggBDQgLgHgIgTQgHgRgCgVQgEgZgMggIgNgaQAWAeAYAMQAUALAXAAQAZABAUgLQAYgNAUgeIgMAaQgMAggEAZQgBAVgIARQgIATgLAHQgTAMgOACQgMgCgUgMg");
	this.shape_358.setTransform(230.8,98.1);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#F9C9A3").s().p("AggBEQgMgIgIgSQgHgSgCgVQgDgZgNghIgMgaQAWAfAYANQATAKAYAAQA1ABAlg3IgMAaQgNAhgDAZQgCAVgHASQgIASgMAIQgTAMgOACQgNgCgTgMg");
	this.shape_359.setTransform(230.8,98);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#FACFAA").s().p("AggBEQgMgHgIgUQgHgRgCgVQgDgZgNghIgNgbQAWAfAYANQAVALAXAAQAaAAAUgLQAZgNAUgfIgNAbQgMAhgEAZQgCAVgHARQgIAUgMAHQgTAMgOADQgNgDgTgMg");
	this.shape_360.setTransform(230.8,98);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#FBD5B1").s().p("AghBFQgLgHgIgUQgIgSgCgVQgDgagNggIgNgbQAXAfAYANQAUAKAYABQA2ABAmg4IgNAbQgNAggDAaQgDAWgHARQgIAUgLAHQgUAMgOACQgNgCgUgMg");
	this.shape_361.setTransform(230.8,97.9);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#FCDBB9").s().p("AghBFQgMgHgIgTQgHgTgCgVQgDgagOggIgMgcQAWAfAZAOQAUAKAYABQAaAAAUgLQAZgOAVgfIgMAcQgOAggDAaQgCAWgHASQgIATgMAHQgUANgOACQgNgCgUgNg");
	this.shape_362.setTransform(230.8,97.8);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#FCE0C0").s().p("AghBFQgMgGgIgVQgIgRgCgVQgDgbgNghIgNgcQAXAfAYAOQAVALAYAAQAaABAVgMQAZgNAVggIgNAcQgNAhgDAbQgDAWgGAQQgJAVgMAGQgTANgPADQgNgDgUgNg");
	this.shape_363.setTransform(230.8,97.8);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#FDE6C7").s().p("AgiBGQgMgHgIgUQgHgSgCgWQgDgagOgiIgNgbQAXAfAZAOQAUALAZAAQAaAAAVgLQAZgNAWggIgNAbQgOAigDAaQgCAWgHASQgIAUgMAHQgVANgOACQgNgCgVgNg");
	this.shape_364.setTransform(230.8,97.7);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#FEEBCE").s().p("AghBHQgNgIgIgUQgHgRgDgXQgDgagOgiIgMgcQAXAgAZANQAVALAYABQAaAAAWgLQAZgOAVggIgMAcQgOAigDAaQgDAWgGASQgJAUgMAIQgUAMgPADQgNgDgUgMg");
	this.shape_365.setTransform(230.8,97.6);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#FFF1D6").s().p("AgiBHQgMgHgIgVQgIgRgCgWQgDgbgOgiIgNgcQAXAfAZAOQAVAMAZAAQAaAAAWgLQAagOAVggIgNAcQgOAigDAbQgCAWgHARQgJAVgMAHQgVANgOADQgOgDgUgNg");
	this.shape_366.setTransform(230.8,97.6);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#FFF7DD").s().p("AgiBIQgNgIgIgUQgHgSgDgXQgDgbgOgiIgNgcQAXAgAaANQAVAMAZAAQAbAAAVgLQAagNAWghIgNAcQgOAigDAbQgDAXgHASQgIAUgNAIQgUAMgPADQgOgDgUgMg");
	this.shape_367.setTransform(230.8,97.5);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#FFFCE4").s().p("AgjBIQgMgHgIgVQgIgSgCgXQgDgbgOgiIgOgdQAYAgAZAOQAWAMAZAAQAbABAWgMQAagOAWghIgOAdQgOAigDAbQgCAXgIASQgIAVgMAHQgVANgPADQgOgDgVgNg");
	this.shape_368.setTransform(230.8,97.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text},{t:this.instance}]}).to({state:[{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape},{t:this.text},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,272,203.9);


(lib.btn_cromatografia = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits12();
	this.instance.setTransform(-0.4,18.6);

	this.text = new cjs.Text(txt['btn_cromo'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(133.1,180.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AVQM+MgqfAAAIAA57MAqfAAAg");
	this.shape.setTransform(136,83.5,1,1.006);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AI2h4IAADxIxsAAIAAjxg");
	this.shape_1.setTransform(134,189.2,1.161,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("Ao2B5IAAjxIRsAAIAADxg");
	this.shape_2.setTransform(134,189.2,1.161,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AVSNAMgqjAAAIAA5/MAqjAAAg");
	this.shape_3.setTransform(135.9,82.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("A1RNAIAA5/MAqjAAAIAAZ/g");
	this.shape_4.setTransform(135.9,82.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1D1D1C").s().p("AgKgMIAVAAIgLAZg");
	this.shape_5.setTransform(50.6,146.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1D1D1C").s().p("AgKANIAKgZIALAZg");
	this.shape_6.setTransform(50.6,21.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#1D1D1C").ss(0.3,0,0,3.9).p("AAApwIAATh");
	this.shape_7.setTransform(50.6,84);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D1D1C").s().p("AgOAcIAAgFQAYgYgBgLQABgKgKAAQgJAAABALIgGAAQABgHAEgFQAEgEAFAAQAGAAAEADQAFAEAAAHQAAAJgKAKIgNARIAXAAIAAAFg");
	this.shape_8.setTransform(202.8,158.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D1D1C").s().p("AADAbIAAgwQgEAGgFADIAAgGQAFgCAEgHIAFAAIAAA2g");
	this.shape_9.setTransform(137.4,158.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1D1D1C").s().p("AgKAUIAAgmIADAAIABAEQACgFAEAAQALAAAAAPQAAANgKABQgEAAgDgGIAAAQgAgGgEQAAALAGgBQAIABAAgLQAAgMgIAAQgGAAAAAMg");
	this.shape_10.setTransform(222,82.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1D1D1C").s().p("AgJAGIADAAQABAGAFAAQAGAAAAgGQAAgEgGgCQgIgBAAgFQAAgIAIAAQAIAAABAIIgEAAQAAgFgFAAQgFAAAAAFQAAABAAAAQABABAAAAQABABAAAAQABAAABABIAGACQAFABAAAEQAAAKgKAAQgJAAAAgJg");
	this.shape_11.setTransform(219.3,81.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1D1D1C").s().p("AgQAdIAAg5IARAAQAGAAAEAEQAEAEAAAHQAAALgKACQAMAAAAANQAAAQgPAAgAgLAYIALAAQAMAAAAgMQAAgLgPAAIgIAAgAgLgCIALAAQAKAAAAgLQAAgKgKAAIgLAAg");
	this.shape_12.setTransform(215.7,78.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1D1D1C").s().p("AgQAdIAAg5IARABQAGAAAEADQAEAEAAAHQAAALgKACIAAAAQAMAAAAANQAAAQgPAAgAgMAYIAMAAQAMAAAAgLQAAgMgPAAIgJAAgAgMgCIAMAAQAKAAAAgKQAAgLgKAAIgMAAg");
	this.shape_13.setTransform(154.1,77.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1D1D1C").s().p("AARAdIgFgQIgXAAIgGAQIgFAAIAVg5IADAAIAVA5gAAKAIIgKgfIgKAfIAUAAg");
	this.shape_14.setTransform(146.9,110.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1D1D1C").s().p("AgJAUIAAggIgBgGIADAAIABAEQACgFAFAAQAKAAAAAPQAAAOgKAAQgFAAgCgGIAAAQgAgGgEQAAALAGAAQAIAAAAgLQgBgMgHAAQgHAAABAMg");
	this.shape_15.setTransform(187,116.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#1D1D1C").s().p("AgJAGIADAAQABAGAFAAQAGAAAAgGQAAgBAAAAQAAgBAAgBQgBAAAAAAQgBgBAAAAIgEgCQgIAAAAgGQAAgIAIAAQAIAAABAIIgEAAQAAgFgFAAQgFAAAAAFQAAADAEABIAGACQAFABAAAEQAAAKgKAAQgJAAAAgJg");
	this.shape_16.setTransform(184.2,115.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#1D1D1C").s().p("AgLAUIAAgnIALAAQAEAAADADQAEADAAAEQgBAIgGABQAIAAAAAJQAAALgLAAgAgIARIAIAAQAIABAAgJQAAgIgKAAIgGAAgAgIgBIAIAAQAHAAAAgHQAAgIgHAAIgIAAg");
	this.shape_17.setTransform(181.3,115.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1D1D1C").s().p("AgKAWIAAAAIAAAGIgEAAIAAg4IAEAAIAAAXIAAABQAEgIAGAAQAQAAgBAUQAAAIgDAGQgDAHgIAAQgGAAgFgHgAgKAHQAAASAKAAQALAAAAgSQAAgOgLAAQgKAAAAAOg");
	this.shape_18.setTransform(177.6,112.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1D1D1C").s().p("AgNAJQAAgJAIgBQADgBADgBIAIAAIAAgDQAAgKgJABQgGgBAAAIIgFAAQACgMAJAAQANAAAAAOIABAaIgFAAIAAgGIAAAAIAAAAQgDAHgHAAQgMAAAAgMgAgBABQgHABAAAHQAAAHAIABQAKAAgBgRIgKABg");
	this.shape_19.setTransform(95.6,127.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#1D1D1C").s().p("AgKAWIAAAAIAAAGIgEAAIAAg4IAEAAIAAAYQAFgIAGAAQAOAAAAAUQABAIgEAGQgDAHgIAAQgGAAgFgHgAgKAHQABASAKAAQAKAAAAgSQAAgOgLAAQgKAAAAAOg");
	this.shape_20.setTransform(74.2,112.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#1D1D1C").s().p("AAKAUIgKgSIgKASIgFAAIAOgUIgOgTIAGAAIAJARIAKgRIAFAAIgNATIAOAUg");
	this.shape_21.setTransform(46.2,86.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#1D1D1C").s().p("AgPANIAFAAQAAAFADADQAEADADAAQALAAAAgMQAAgGgFgEQgEgCgDABIAAgDQADAAAEgCQAEgDAAgFQAAgLgKAAQgIAAgCALIgFAAQAAgHAFgFQAEgDAGAAQAPgBAAAQQAAAKgKACIAAAAQALABAAAMQAAAHgFAFQgFADgGAAQgPAAAAgPg");
	this.shape_22.setTransform(10.1,155.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#1D1D1C").s().p("AAEAbIAAgNIgUAAIAAgEIATglIAGAAIAAAkIAJAAIAAAFIgJAAIAAANgAgLAJIAPAAIAAgdg");
	this.shape_23.setTransform(10.2,25.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#515E5F").ss(1,0,0,3.9).p("AFGggIAABBAlFggIAABB");
	this.shape_24.setTransform(170.1,148.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#EAA969").s().p("AgbAAQABgIAFgEQAIgEANAAIALABIAFgBQALAAAAAHIgCAEQgBADAAACIAAAJQAAAIgHAAQgDAAgEgEQgEgDgEAAIgCAAQgDAAgEADQgEAEgEAAQgLAAgBgRg");
	this.shape_25.setTransform(202.7,81.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#E9A867").s().p("AgcAAQAAgJAGgDQAIgFAOAAIALABQACAAAEgCQAMAAAAAHIgCAGQgDAEAAABIAAALQAAAIgGAAQgEAAgEgEQgFgDgDAAIgDAAQgDAAgEAEQgEADgDAAQgNAAAAgTg");
	this.shape_26.setTransform(202.7,81.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#E9A766").s().p("AAKARQgFgEgDAAIgDAAQgDAAgEAEQgEAEgEAAQgNAAAAgVQAAgJAGgEQAIgFAPAAIALABQACAAAFgDQAMAAAAAHIgCAIQgDAEAAABIAAAMQAAAJgHAAQgEAAgEgEg");
	this.shape_27.setTransform(202.7,81.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#E9A664").s().p("AAKATQgFgFgEAAIgCAAQgDAAgFAFQgEAEgEAAQgNAAAAgXQAAgJAGgFQAJgGAPAAIALACQACAAAGgFQAMAAAAAJQAAADgCAFIgDAGIAAANQAAAKgHAAQgEABgFgFg");
	this.shape_28.setTransform(202.7,81.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#E9A562").s().p("AAKAVQgFgFgEAAIgDAAQgDAAgEAFQgFAEgDAAQgOAAgBgZQABgKAGgFQAIgGARAAIALACQADAAAGgGQAMAAAAAJIgCAJQgDAGAAABIAAAPQAAAEgCADQgCAEgEAAQgEAAgFgFg");
	this.shape_29.setTransform(202.7,81.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#E8A360").s().p("AAKAXQgFgGgEAAIgDAAQgEAAgEAFQgFAFgEAAQgOAAAAgbQAAgLAHgFQAIgGARAAQAEAAAIACQABAAAEgEIAFgDQAFAAAEACQAEADAAAEQAAADgDAIQgDAHAAABIAAAQQAAAEgCADQgDAEgEAAQgEAAgFgFg");
	this.shape_30.setTransform(202.7,81.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#E8A25F").s().p("AAKAZQgFgGgFAAIgCAAQgEAAgFAFQgFAGgEAAQgOAAAAgeQAAgLAGgFQAJgHASAAIAMABIAFgDQAEgEACAAQAFAAAEACQAEADAAAFQAAADgDAIQgDAIAAABIAAARQAAAFgDADQgCAEgEAAQgFAAgFgFg");
	this.shape_31.setTransform(202.8,81.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#E8A15D").s().p("AALAaQgGgGgFAAIgCAAQgEAAgFAGQgFAGgEAAQgPAAAAggQAAgLAGgGQAKgHASgBIAMACQABAAAFgEQAEgFACAAQAFAAAEADQAEADAAAFQAAADgDAKQgEAIABABIAAATQAAAEgDAEQgDAFgEAAQgEgBgFgGg");
	this.shape_32.setTransform(202.8,81.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#E7A05B").s().p("AALAcQgHgHgEAAIgDAAQgEAAgFAGQgEAGgFAAQgQAAAAghQABgMAHgGQAJgIATAAIANACIAFgFQAFgFABAAQAPAAAAALQAAAEgEAKQgEAJABACIAAATQAAAFgEAEQgDAFgDAAQgFAAgFgHg");
	this.shape_33.setTransform(202.8,81);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#E79F59").s().p("AAKAeQgGgHgEAAIgDAAQgEAAgFAGQgFAHgFAAQgQAAAAgkQAAgMAIgHQAGgFAHgCIAPgBIANACQACAAAFgGQAFgFABAAQAGAAAEADQAFADAAAGQAAAEgEAKQgEAKAAACIAAAVQAAAFgDAFQgDAEgEAAQgFAAgGgHg");
	this.shape_34.setTransform(202.8,81);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#E79E58").s().p("AAKAgQgGgIgEABIgEAAQgEgBgGAHQgEAGgFAAQgQABAAgmQAAgNAHgGQAHgGAHgCQAGgBAJAAQAFAAAJACQACAAAFgHQAGgFABgBQAGAAAEAEQAFAEAAAFQAAAEgEAMQgEAKAAACIAAAXQAAAEgDAGQgEAEgEAAQgFABgGgIg");
	this.shape_35.setTransform(202.8,81);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#E69D56").s().p("AAKAiQgGgIgEAAIgEAAQgFAAgFAHQgFAHgFAAQgQAAAAgnQAAgPAHgHQAHgGAHgBQAFgCALAAQAEAAAKACQACAAAGgGQAFgHACAAQAGAAAEAEQAFADAAAGQAAAFgEAMQgEALAAADIAAAXQAAAFgEAFQgDAGgFAAQgEAAgHgIg");
	this.shape_36.setTransform(202.8,80.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#E69C54").s().p("AALAjQgHgIgEAAIgFAAQgEAAgGAHQgFAIgEAAQgRAAgBgpQAAgPAIgHQAHgHAIgBQAFgCALAAQAEAAAKACQACAAAGgHQAHgHABAAQAGAAAEAEQAFADABAGQAAAFgFANQgEAMAAADIAAAYQAAAGgEAGQgEAFgEAAQgEAAgHgJg");
	this.shape_37.setTransform(202.8,80.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#E69B52").s().p("AALAlQgHgJgEAAIgFAAQgEAAgGAIQgFAIgFAAQgSAAAAgrQAAgQAIgHQAHgHAIgCQAFgBAMAAIAGABIAJABQABAAAHgIQAGgHACAAQAGAAAFADQAFAEAAAGQAAAFgFAOQgEANAAAEIAAAZQAAAGgEAFQgEAGgFAAQgFAAgGgJg");
	this.shape_38.setTransform(202.8,80.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#E69A51").s().p("AALAnQgHgJgEAAIgFAAQgFAAgGAIQgFAIgGAAQgRAAAAgtQAAgQAIgIQAHgHAIgCQAGgCALAAIAHACIAJABQABAAAHgIQAHgJACAAQAGAAAFAEQAFAEAAAHQAAAFgEAPQgFANgBAEIAAAaQAAAGgEAHQgEAGgFAAQgEAAgHgKg");
	this.shape_39.setTransform(202.9,80.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#E5994F").s().p("AALApQgHgKgEAAIgGAAQgFAAgFAJQgGAHgFABQgSAAAAgvQAAgRAIgIQAHgHAIgCQAGgCAMAAIAHABIAIABQACABAHgJQAIgJABAAQAHAAAFAEQAFAEAAAHQAAAFgFAQQgFAOAAAFIAAAbQAAAGgEAGQgEAHgFAAQgFAAgHgKg");
	this.shape_40.setTransform(202.9,80.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#E5984D").s().p("AALArQgHgLgEAAIgGAAQgFAAgGAJQgGAJgFAAQgTAAAAgwQAAgTAJgIQAIgHAIgCQAGgCALAAQAGAAALACQABAAAIgJQAIgJABAAQAHAAAFAEQAGAEAAAHQAAAGgFAQQgGAPAAAFIAAAcQAAAHgEAGQgFAHgFAAQgFAAgHgKg");
	this.shape_41.setTransform(202.9,80.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#E5974C").s().p("AAKAtQgHgMgDAAIgHAAQgFABgFAIQgGAJgGAAQgTAAAAgxQAAgTAJgJQAIgHAIgDQAGgCAMAAQAGAAAKADQACAAAIgJQAJgLABAAQAHABAFAEQAGAEAAAHQAAAGgFASQgGAPAAAFIAAAeQAAAHgEAGQgGAIgEAAQgGgBgIgKg");
	this.shape_42.setTransform(202.9,80.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#E5954A").s().p("AALAuQgHgLgEAAIgHAAQgFAAgGAJQgGAKgFAAQgUAAAAg0QAAgUAJgJQAIgIAIgCQAHgCAMAAQAFAAAMADQABAAAJgKQAIgLACAAQAIAAAEAEQAGAFAAAIQAAAGgGASQgFAQAAAFIAAAfQAAAHgFAHQgFAIgFAAQgGAAgHgMg");
	this.shape_43.setTransform(202.9,80.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#E49448").s().p("AALAwQgIgLgEAAIgGAAQgGAAgGAKQgGAJgGAAQgTAAAAg1QAAgVAJgKQAIgHAJgDQAGgCAMAAIAIABIAKACQACAAAIgLQAJgLACAAQAHAAAFAEQAGAGAAAIQAAAFgFAUQgGAQAAAGIAAAgQAAAHgFAHQgGAIgFAAQgFAAgIgMg");
	this.shape_44.setTransform(202.9,80.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#E49347").s().p("AALAyQgIgMgEAAIgGAAQgGAAgGAKQgHAKgFAAQgVAAAAg3QAAgVAKgKQAIgIAJgDQAHgCAMAAIAIABIAKACQACAAAJgMQAJgLACAAQAHAAAGAEQAGAFAAAJQAAAGgGAUQgGARAAAGIAAAiQAAAHgFAIQgGAHgFAAQgGAAgIgMg");
	this.shape_45.setTransform(202.9,80.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#E49245").s().p("AALA0QgIgNgEAAIgHAAQgFAAgHALQgGAKgGAAQgVAAAAg5QAAgWAKgKQAIgIAJgEQAHgCANAAIAIACIAKABQACAAAJgMQAKgMABABQAIAAAGAEQAGAGAAAIQAAAHgGAUQgGASgBAHIAAAiQABAIgGAHQgGAJgFgBQgGAAgIgMg");
	this.shape_46.setTransform(203,80.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#1D1D1C").ss(0.3,0,0,3.9).p("AkIAAIIRAA");
	this.shape_47.setTransform(99.7,78.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#1D1D1C").s().p("AgKgMIAVAAIgLAZg");
	this.shape_48.setTransform(173.3,146.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#1D1D1C").s().p("AgKANIAKgZIALAZg");
	this.shape_49.setTransform(173.3,80.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#1D1D1C").ss(0.3,0,0,3.9).p("AAAlKIAAKV");
	this.shape_50.setTransform(173.3,113.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#1D1D1C").s().p("AgKgMIAVAAIgLAZg");
	this.shape_51.setTransform(99.5,146.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#1D1D1C").s().p("AgKANIAKgZIALAZg");
	this.shape_52.setTransform(99.6,109.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#1D1D1C").ss(0.3,0,0,3.9).p("AAAi4IAAFx");
	this.shape_53.setTransform(99.6,128);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#1D1D1C").s().p("AgKgMIAVAAIgLAZg");
	this.shape_54.setTransform(78.5,146.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#1D1D1C").s().p("AgKANIAKgZIALAZg");
	this.shape_55.setTransform(78.5,80);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#1D1D1C").ss(0.3,0,0,3.9).p("AE2lQIEHAAAmfguIGKAAAo3lBIAAKW");
	this.shape_56.setTransform(135.4,112.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#515E5F").ss(1,0,0,3.9).p("A1OqGMAqeAAAA1OKHMAqeAAA");
	this.shape_57.setTransform(136,83.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#F0AE98").s().p("AgRAvIgDgIQgFgEAAgFQAAgDAEgLIADgMQAAgDgDgCQgEgEAAgDQABgLAJgGQAGgCAEgDQAFgFAAgEQgDgFABgDQgBgBAEAAIAGABIAGgCQADgCACAAQADAAADADQABADAAADQABAFgJAJQgIAJAAAGQAAADACAEQACAEAAACQAAADgGADIgHADQgDACgEAFQgDAGAAADQAAAFADARQAAAFgEAAQgDAAgDgFg");
	this.shape_58.setTransform(138.3,109.7);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#F0AD97").s().p("AgRAvIgEgIQgEgFAAgEQAAgEAEgJQADgKAAgDQAAgDgDgCQgDgEAAgDQAAgMAKgFQAOgGAAgIQgCgFAAgDQAAgBADAAIAGAAIAGgBIAFgCQAIAAAAAJQAAAFgIAJQgJAJAAAGQAAADADAEQACAEAAACQAAADgGADIgIAEQgDABgDAFQgDAGAAAEIADAVQAAAFgFAAQgDAAgDgFg");
	this.shape_59.setTransform(138.3,109.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#F0AC96").s().p("AgRAvIgEgHQgEgFAAgFQAAgDAEgKQACgJAAgEQAAgDgCgBQgEgEAAgDQAAgMAKgFQAPgHAAgIIgBgEIgCgDQAAgDADAAIAHABIAGgBQADgCACAAQAIAAAAAJQAAAGgJAJQgIAIAAAGQAAADADAFQACAEAAABQgBAEgFADIgIADQgDACgDAFQgDAGAAADQAAAFADAQQAAAFgFAAQgDAAgDgFg");
	this.shape_60.setTransform(138.3,109.7);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#F0AB95").s().p("AgRAwIgEgIQgEgFAAgEQAAgEAEgJQADgKAAgEQAAgDgEgBQgDgEAAgDQAAgMAKgFQAPgHAAgIIgBgEIgCgEQAAgCAEAAIAGABQACAAAEgCIAFgCQAEAAACADQACADAAAEQAAAGgIAJQgIAJAAAFQAAADACAFQACAEAAABQAAAEgFADIgJAEQgCABgDAFQgEAGAAADIADAVQAAAGgFAAQgDAAgDgFg");
	this.shape_61.setTransform(138.3,109.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#EFAB94").s().p("AgRAwIgEgIQgEgFAAgEQAAgEADgJQADgJAAgEQAAgDgDgCQgDgEAAgDQAAgMAKgGQAPgFAAgJIgBgEIgCgEQAAgCAEAAIAGABIAGgCIAFgCQAEAAACADQACADAAAEQAAAGgIAJQgIAIAAAGQAAADACAFQACAEAAABQAAAFgFACIgJAEQgCABgDAGQgEAFAAADQAAAGAEAPQAAAGgGAAQgDAAgDgFg");
	this.shape_62.setTransform(138.3,109.7);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#EFAA93").s().p("AgRAwIgEgIQgEgEAAgFQAAgEADgJQADgJAAgEQAAgDgDgCQgEgEAAgDQAAgNALgFQAPgGAAgIIgCgEIgBgEQAAgCADAAIAHABQACAAAEgCIAFgCQAJAAAAAKQAAAGgJAJQgIAIAAAGQAAADACAFQADAEAAABQAAAFgGACIgJAEQgCABgDAGQgDAFAAAEIADAUQAAAGgGAAQgDAAgDgFg");
	this.shape_63.setTransform(138.3,109.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#EFA992").s().p("AgRAwIgEgHQgEgFAAgFQAAgDADgKQADgJAAgEQAAgDgDgCQgEgEAAgDQAAgNALgFQAPgGAAgJIgCgDIgBgEQAAgCADAAIAHAAIAGgBQADgCADAAQADAAACADQADACAAAEQAAAHgIAIQgJAJAAAGQAAAEADAEQACAFAAABQAAAEgGADIgJADQgCACgDAFQgDAFAAAEQAAAFADAPQAAAGgGAAQgDAAgDgFg");
	this.shape_64.setTransform(138.3,109.7);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#EFA891").s().p("AgRAxIgEgIQgFgGAAgEQAAgDAEgJQADgJAAgEQAAgDgEgDQgDgDAAgDQAAgOALgEQAOgHAAgJQgCgEAAgDQAAgCADgBIAHABQACAAAEgCQADgBADAAQADAAADACQACAEAAAEQAAAGgIAJQgJAIAAAGQAAAEADAEQACAFAAABQAAAFgGACIgJADQgCACgDAFQgDAFAAAEQAAAFADAPQAAAGgGABQgDgBgDgEg");
	this.shape_65.setTransform(138.3,109.7);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#EFA790").s().p("AgRAxIgEgIQgFgFAAgFQAAgDAEgJQADgJAAgEQAAgDgEgDQgDgDAAgEQAAgNALgFQAOgIAAgHIgBgDIgCgEQAAgDAEAAIAHABQACAAAEgCIAGgCQAIAAAAAKQAAAHgIAIQgJAJAAAGQAAAEADAEQACAFAAABQAAAFgFACIgKAEQgCABgDAFQgDAFAAAEQAAAGADAOQAAAHgGAAQgDAAgDgFg");
	this.shape_66.setTransform(138.3,109.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#EEA68F").s().p("AgQAxIgFgHQgFgFABgFQAAgEADgJQACgJAAgDQABgDgEgEQgDgDAAgDQgBgNAMgGQAOgGAAgJIgBgDIgCgEQAAgCAFgBIAGABQACAAAEgCIAGgCQAEAAACADQACAEABAEQgBAGgHAJQgJAIAAAGQAAAEACAEQADAFAAACQAAAEgGADIgKADQgCACgDAFQgCAFAAAEQAAAFACAOQABAHgHAAQgDAAgCgFg");
	this.shape_67.setTransform(138.3,109.7);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#EEA58E").s().p("AgQAxIgFgHQgFgFAAgFQAAgEAEgJQACgJAAgDQABgDgEgEQgEgDAAgDQAAgNAMgGQAOgGAAgJIgBgDQAAgBgBAAQAAgBAAgBQgBAAAAgBQAAAAAAgBQAAgCAEAAIAHABQACAAAEgCIAGgCQAEAAADADQACADAAAEQAAAHgIAJQgJAIAAAGQAAAEACAFQADAEAAACQAAAEgFADIgLADQgBACgDAFQgDAFAAAEQAAAFADAOQAAAHgHAAQgDAAgCgFg");
	this.shape_68.setTransform(138.3,109.7);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#EEA58D").s().p("AgQAyIgFgHQgFgHAAgEQAAgEADgJQADgIAAgEQAAgDgDgEQgEgDAAgDQAAgNAMgGQAOgGAAgJIgCgDIgBgFQAAgCAEAAIAHABQACAAAEgCQAEgCACAAQADAAAEACQACAEAAAEQAAAHgIAJQgJAIAAAHQAAADADAFQADAEAAACQgBAEgFADIgLADQgBACgDAFQgDAFAAAEQAAAGADANQAAAHgHABQgDgBgCgEg");
	this.shape_69.setTransform(138.3,109.7);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#EEA48C").s().p("AgQAyIgFgHQgFgGAAgFQAAgEADgIQADgJAAgDQAAgEgDgEQgEgCgBgEQAAgNANgGQAOgHAAgIIgCgDIgBgFQAAgCAEAAIAHAAIAGgBQAEgCADAAQADAAADACQACADABAFQAAAHgJAJQgIAIAAAHQAAADACAFQADAEAAACQgBAFgFADIgLADQgBACgDAEQgDAFABAEIACATQAAAHgHABQgDgBgCgEg");
	this.shape_70.setTransform(138.3,109.7);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#EEA38B").s().p("AgQAzIgFgIQgGgGABgEQAAgEADgJQADgIAAgEQAAgDgDgFQgEgCgBgEQAAgOAMgFQAPgHAAgIIgCgEQAAAAAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBQABgCAEAAIAHABIAGgCQAEgDADAAQADAAADAEQACADABAEQAAAHgJAJQgIAJAAAGQgBADADAFQADAEAAADQAAAEgGADIgLADQgBACgDAEQgDAFABAEQAAAGACANQABAIgIAAQgDAAgCgEg");
	this.shape_71.setTransform(138.3,109.6);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#EEA28A").s().p("AgQAzIgFgHQgFgHAAgFQAAgDADgJQADgIAAgEQAAgEgEgDQgEgDAAgEQAAgOAMgFQAPgHAAgIIgCgEIgBgEQAAgCAEgBIAHABIAHgBQADgDADAAQADAAADADQADADAAAFQAAAGgIAKQgJAIAAAHQAAAEADAEQACAEAAACQAAAFgGADIgKADQgCACgCAEQgDAFAAAEQAAAGADANQAAAIgHAAQgDAAgDgEg");
	this.shape_72.setTransform(138.2,109.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#EEA189").s().p("AgQAzIgFgHQgFgGAAgFQAAgEADgIQADgIAAgEQAAgEgEgEQgEgDAAgDQAAgPAMgFQAPgGAAgJIgCgEIgBgEQAAgDAEAAIAHABIAHgCQADgCADAAQAEAAADADQACADAAAFQAAAHgIAJQgJAJAAAGQAAAEADAFQADADAAADQAAAFgGACIgLAEQgCABgCAFQgDAEAAAFQAAAGADAMQAAAIgHAAQgDAAgDgEg");
	this.shape_73.setTransform(138.2,109.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#EDA089").s().p("AgQAzIgFgHQgGgGAAgFQAAgEADgHQADgJAAgEQAAgDgDgFQgEgCAAgEQAAgPAMgFQAPgHAAgHIgCgFQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAgBAAAAQAAgDAFAAIAHACQADAAAEgDQADgCADgBQAEABADADQACADAAAFQAAAHgIAJQgJAJAAAHQAAADADAFQADADAAAEQAAAEgGACIgLAFQgCABgCAFQgDAEAAAEQAAAGADANQAAAHgHAAQgEAAgCgEg");
	this.shape_74.setTransform(138.2,109.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#ED9F88").s().p("AgQA0IgFgIQgFgGgBgFQAAgEADgIQAEgHAAgFQAAgDgFgFQgDgCAAgEQAAgPAMgFQAPgHAAgIIgBgEQgBAAAAgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAgDAFAAIAHABIAHgCQADgDADAAQAEAAADAEQACADAAAEQAAAHgHAJQgJAKAAAGQAAAEADAFQADADgBAEQAAAFgFACIgMADQgBACgCAEQgDAFAAAEQAAAGADAMQAAAJgIAAQgDAAgDgEg");
	this.shape_75.setTransform(138.2,109.6);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#ED9F87").s().p("AgQA0IgFgHQgGgGAAgFQAAgEADgIQADgIAAgFQAAgDgEgFQgEgCAAgDQAAgQANgFQAOgHAAgHIgBgFIgCgEQAAgDAFAAIAHABQADAAAEgDQADgCADAAQAEAAADADQADAEAAAEQAAAIgJAIQgIAJAAAIQAAADADAGQACACAAAEQAAAFgGADIgLADQgGAEAAALQAAAGADAMQAAAIgIAAQgEAAgCgEg");
	this.shape_76.setTransform(138.2,109.6);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#ED9E86").s().p("AgQA0IgFgHQgGgGAAgFQAAgEADgIQADgHAAgFQAAgEgEgEQgEgCAAgEQAAgPAMgHQAPgFABgIIgCgFQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgDAFAAIAHABQADAAAEgDQADgCADAAQAFAAACADQADAEAAAEQAAAIgIAIQgJAJAAAIQAAADADAGQADADAAAEQAAAEgGADIgMADQgFADgBAMQAAAGADAMQAAAIgIAAQgDAAgDgEg");
	this.shape_77.setTransform(138.2,109.6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#ED9D85").s().p("AgRA0IgEgHQgGgGAAgFQAAgEADgHQADgIAAgFQAAgDgEgFQgFgCABgEQAAgPAMgHIAKgEQAGgEAAgGIgCgEQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgEAFAAIAHABQADAAAEgCQADgDADABQAFAAACADQADAEABAEQAAAIgJAIQgJAJABAIQAAADACAGQADADAAAEQAAAFgGACIgMADQgFAFgBAKQAAAGADAMQAAAIgIABQgEgBgDgEg");
	this.shape_78.setTransform(138.2,109.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#ED9C84").s().p("AgRA1IgEgHQgGgIAAgEQAAgEADgHQADgIAAgFQgBgDgEgFQgDgCAAgEQAAgQAMgGIAKgEQAFgEAAgGIgBgEIgCgEQAAgEAFAAIAHABQADAAAEgCQAEgDACABQAFAAACADQADADABAFQAAAHgJAJQgJAKABAHQAAAEACAFQADADAAAEQABAFgHACIgLADQgGAEAAALQAAAGADAMQgBADgCADQgCADgEAAQgEAAgDgEg");
	this.shape_79.setTransform(138.2,109.6);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#EC9B83").s().p("AgQA1IgFgHQgGgHAAgEQAAgFADgHQADgHAAgFQAAgDgEgFQgFgDAAgEQAAgQANgFIAKgFQAFgEAAgGIgBgEQgBgBAAAAQgBgBAAgBQAAAAAAgBQAAAAAAgBQAAgCAFAAIAIABQADAAADgDQAEgDADAAQAEAAADAEQADADAAAFQAAAIgJAJQgIAJAAAHQAAAEADAFQADAEAAADQAAAGgGACIgMADQgGAEAAAKQAAAGADAMQAAAJgJAAQgDAAgDgEg");
	this.shape_80.setTransform(138.2,109.6);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#EC9A82").s().p("AgRA1IgEgHQgHgGABgFQAAgFACgHQADgHAAgFQAAgDgEgFQgEgDAAgEQAAgQANgGIAKgFQAFgDAAgGIgBgFQgBAAAAgBQgBAAAAgBQAAAAAAgBQgBgBAAAAQABgDAFAAIAHABQADAAAEgDQAEgCACAAQAFAAADADQADAEAAAFQAAAHgIAJQgJAKAAAHQAAAEADAGQADADAAAEQAAAFgGACIgMADQgGAEAAAKQAAAHADALQgBAEgCACQgCADgEAAQgEAAgDgEg");
	this.shape_81.setTransform(138.2,109.6);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#EC9981").s().p("AgQA2IgFgHQgGgGAAgGQAAgEADgHQACgIAAgEQAAgEgEgFQgEgDAAgEQAAgPANgHIAKgFQAFgDAAgGQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAgBgBAAIgCgFQAAgDAGAAIAHABQADAAAEgCQAEgDADAAQAEAAADADQADAEAAAFQAAAHgIAKQgJAJAAAHQAAAEADAGQADADAAAEQAAAFgGACIgMADQgFAEAAAKQAAAHACALQAAAJgJAAQgDAAgDgDg");
	this.shape_82.setTransform(138.2,109.6);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#EC9980").s().p("AgQA2IgFgHQgHgHAAgFQAAgEADgHQADgHAAgFQAAgEgEgFQgFgDAAgEQAAgPAOgHIAKgFQAFgDAAgGIgCgEIgCgFQAAgDAGAAIAHABQADAAAEgDQAEgCADAAQAEAAAEADQADAEAAAFQAAAHgJAKQgJAJAAAHQAAAEADAGQADADAAAEQAAAFgGACIgLAEQgGAEAAAKIABAIIABAJQAAAJgJAAQgDAAgDgDg");
	this.shape_83.setTransform(138.2,109.6);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#EC987F").s().p("AgQA2IgGgGQgGgIAAgEQAAgFADgHQADgHAAgFQAAgEgEgFQgFgDAAgDQAAgQAOgHIAKgFQAFgDAAgGIgCgEIgCgFQAAgDAGAAIAHABQADAAAEgDQAEgDADAAQAFAAADAEQADAEAAAFQAAAHgJAKQgIAJAAAHQAAAEADAGQADADAAAEQAAAGgGACIgMADQgGAEAAAKQAAAGACALQAAAEgCADQgDADgEAAQgDAAgDgEg");
	this.shape_84.setTransform(138.2,109.6);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#E6715E").s().p("AgoA4QgDgFAAgHQAAgHAHgJQAGgKAAgHQAAgDgDgEQgDgEAAgBQAAgJALgGQAPgJACgDQACgCAAgEQAAgFABgCIADgCQABAAAAgBQABAAAAAAQAAgBAAAAQAAAAAAgBIACgJQABgFAEAAQAFAAAFAFQAGAGAEABQARAFAAAKQAAAHgFAJQgFAJAAAHQAAAFAFALQAFALAAAIQAAAHgCAGQgEAGgFAAQgHAAgJgHQgJgHgGAAQgGAAgKALQgKALgHAAQgGAAgDgFg");
	this.shape_85.setTransform(137.3,80.1);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#E77562").s().p("AgvBAQgDgGAAgHQAAgIAIgLQAHgLAAgIQAAgEgDgEQgEgFAAgBQAAgLAMgHQASgKADgDQACgDAAgFQgBgFABgDIAEgCQADgBAAgCIACgLQACgGAEAAQAFAAAGAGQAIAGAEACQAKADAEADQAGAEAAAHQAAAIgGALQgGAKAAAIQAAAHAGAMQAGANAAAJQAAAJgDAGQgEAHgGAAQgIAAgKgIQgLgIgHAAQgHAAgLANQgMANgJAAQgGAAgEgHg");
	this.shape_86.setTransform(137.3,80.1);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#E77966").s().p("Ag1BJQgEgGAAgJQAAgJAJgNQAJgMAAgJQAAgEgEgFQgEgFAAgCQAAgNANgHQATgLAEgFQADgCAAgGIABgJQAAgCAEgBQADgBAAgDIADgMQACgGAEAAQAHAAAGAGQAJAIAEABQALAEAFADQAHAFAAAIQAAAJgHAMQgHAMAAAJQAAAIAHAOQAHAPAAAKQAAAKgDAHQgEAIgIAAQgIAAgMgJQgMgKgJAAQgIAAgNAPQgMAOgLAAQgHAAgEgHg");
	this.shape_87.setTransform(137.2,80.1);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#E87D6A").s().p("Ag8BSQgFgHABgKQgBgKALgOQAKgOAAgKQAAgEgFgGQgEgGAAgCQAAgPAOgIQAXgMAEgFQADgDAAgGQgBgIACgCQABgDADgBQAEgBAAgDIADgNQADgIAEAAQAIAAAHAIQAJAIAFACQANAEAFADQAIAGAAAJQAAAJgHAOQgIAOAAAJQAAAJAIAQQAHARAAALQAAALgDAJQgGAIgIABQgJAAgNgLQgOgLgKAAQgJAAgOARQgOAQgMAAQgIAAgFgIg");
	this.shape_88.setTransform(137.1,80.1);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#EC987F").s().p("AgiA1QgHgSAAgdQAAgZAGgSQAHgUAQgQIAYAAIAGgCQAYAMAAAWQAAANgFAQQgFASgBAJQgHA9gfAAQgSAAgJgXg");
	this.shape_89.setTransform(138,109.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#EC9D84").s().p("AgiA1QgIgSAAgcQAAgaAHgSQAGgVARgPIAYAAIAGgCQAZAKAAAYQAAANgFAQQgGATgBAIQgGA9ggAAQgSAAgJgXg");
	this.shape_90.setTransform(138,109.5);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#ECA18A").s().p("AgjA2QgHgSAAgdQAAgaAHgTQAGgVARgPIAZAAIAFgCQAZALAAAXQAAAOgFAQQgFATgBAJQgJA9geAAQgTAAgJgXg");
	this.shape_91.setTransform(138,109.5);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#EDA68F").s().p("AgjA2QgHgSAAgdQAAgaAGgTQAHgVARgQIAZAAIAFgCQAZALAAAYQAAANgEARQgGASgBAKQgHA+ggAAQgTAAgJgYg");
	this.shape_92.setTransform(138,109.5);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#EDAB95").s().p("AgjA3QgIgSABgeQAAgaAGgTQAHgWARgQIAZAAIAFgBQAaAKAAAZQgBANgEARQgGASAAAKQgIA/gggBQgUAAgIgXg");
	this.shape_93.setTransform(138,109.5);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#EEB09A").s().p("AgkA3QgHgSAAgeQAAgbAHgTQAHgVARgQIAZAAIAFgCQAaALAAAYQAAAOgFARQgFATgBAJQgIA/ggAAQgTAAgKgYg");
	this.shape_94.setTransform(138,109.5);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#EEB5A0").s().p("AgkA4QgHgTAAgeQAAgaAGgUQAIgWARgPIAZAAIAGgDQAZALABAZQgBAOgEARQgGAUgBAIQgHBAghAAQgTAAgKgYg");
	this.shape_95.setTransform(138,109.5);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#EEB9A5").s().p("AglA4QgHgTAAgeQAAgcAHgTQAHgVASgRIAZAAIAGgCQAaAMAAAYQAAAOgFARQgGAUgBAJQgIBBggAAQgUAAgKgZg");
	this.shape_96.setTransform(138,109.5);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#EEBEAB").s().p("AglA5QgHgTAAgfQAAgcAGgSQAIgXASgQIAaAAIAFgDQAaAMAAAZQAAAOgEARQgGAUgBAJQgIBCghAAQgVAAgJgZg");
	this.shape_97.setTransform(138,109.5);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#EFC2B0").s().p("AglA6QgIgUAAgfQAAgbAHgUQAIgWASgRIAaAAIAFgCQAbALAAAaQAAAOgFARQgGAUgBAJQgJBCggAAQgVAAgJgYg");
	this.shape_98.setTransform(138,109.5);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#EFC7B6").s().p("AgmA6QgHgUAAgfQAAgcAGgTQAIgXASgQIAbAAIAFgDQAbAMAAAZQAAAOgEASIgIAeQgIBCghAAQgVAAgKgZg");
	this.shape_99.setTransform(138,109.5);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#EFCBBC").s().p("AgmA6QgIgUAAgfQABgcAGgUQAIgWASgSIAbAAIAGgCQAbAMAAAaQgBAOgFASQgFATgCALQgHBDgjAAQgUgBgKgZg");
	this.shape_100.setTransform(138.1,109.5);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#EFCFC1").s().p("AgnA7QgHgUAAggQAAgcAHgUQAIgXASgRIAbAAIAGgDQAbAMAAAaQAAAOgFATQgGATgBALQgKBDghAAQgUABgLgag");
	this.shape_101.setTransform(138.1,109.5);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#F0D4C7").s().p("AgmA7QgIgUAAggQAAgdAHgTQAHgYATgRIAbAAIAGgCQAbAMAAAaQAAAPgEASIgIAeQgIBEgiAAQgVAAgKgag");
	this.shape_102.setTransform(138,109.5);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#F0D8CD").s().p("AgnA8QgIgUAAggQAAgdAHgVQAIgXATgRIAcAAIAFgDQAcAMAAAbQAAAOgFATQgGAUgBALQgIBEgkAAQgVAAgKgag");
	this.shape_103.setTransform(138,109.4);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#F0DCD2").s().p("AgnA8QgIgUAAghQAAgdAHgUQAIgYATgSIAbAAIAGgBQAcAMAAAaQAAAOgFAUQgGAUgBALQgJBFgjgBQgVAAgKgag");
	this.shape_104.setTransform(138.1,109.5);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#F0E0D8").s().p("AgnA9QgJgVAAggQAAgeAIgVQAHgXAUgSIAbAAIAHgCQAcAMAAAbQAAAPgGATQgFAVgCAKQgIBFgkAAQgVAAgKgag");
	this.shape_105.setTransform(138.1,109.4);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#F0E4DD").s().p("AgoA9QgIgUAAgiQAAgdAHgVQAIgYAUgSIAcAAIAGgCQAcAMAAAbQAAAPgFATIgHAgQgKBGgjAAQgWAAgKgbg");
	this.shape_106.setTransform(138.1,109.5);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#F0E8E3").s().p("AgoA+QgIgVAAghQAAgeAHgVQAIgYATgSIAdAAIAGgDQAcANAAAbQAAAPgFATQgGAVgBALQgKBHgjAAQgWAAgKgbg");
	this.shape_107.setTransform(138.1,109.4);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#F0ECE8").s().p("AgpA+QgIgVAAghQAAgeAHgWQAJgYATgSIAdAAIAGgCQAdAMAAAcQAAAPgFATQgHAVgBALQgIBHglAAQgWAAgLgbg");
	this.shape_108.setTransform(138.1,109.4);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#E87D6A").s().p("AhBCEQgEgHgEgRQgKgZAAgQIAAgYQAAgqAIgbQAIgfAUggIAXgkQAOgRARAAQAEAAAGACQAHADAEABIgGgFQAWAFAKAaQAEAIAKAsIAKAmQAGAUAAARQAAAWgFAUIgLAqIgEAQQgCAIgFAFQgEAEgGgBIgMgBQgGAAgKAEQgJAEgHAAQgDAAgIgDQgIgDgFAAQgGAAgIAFQgIAEgGAAQgKAAgGgLg");
	this.shape_109.setTransform(137.7,77.2);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#E8816E").s().p("AhCCFQgEgHgEgRIgGgVQgEgLAAgKIAAgXQAAgsAIgaQAIggAVggIAXglQAOgRARAAQAEAAAHACQAGAEAEAAIgGgFQAWAFALAaQADAJALArIAKAnQAGAVAAAQQAAAYgFAUIgLAqIgEAQQgCAJgFAFQgEAEgGgBIgNgCQgGAAgKAFQgJADgHAAQgDAAgIgCQgIgEgGAAQgFABgJAFQgIAEgGAAQgKAAgGgMg");
	this.shape_110.setTransform(137.7,77.2);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#E98572").s().p("AhDCHQgEgHgEgRIgGgVQgEgMAAgKIAAgXQAAgsAIgbQAIghAVghIAYgkQAOgSARAAQAEAAAHADQAHADAEAAIgHgFQAXAFALAbQAEAJAKAsIAKAnQAGAVAAARQAAAXgFAUQgCALgJAgIgEAQQgCAKgFAFQgEADgHAAIgMgCQgHAAgJAEQgKAEgGAAQgEAAgIgDQgJgDgFAAQgGAAgIAFQgJAEgFABQgLgBgGgLg");
	this.shape_111.setTransform(137.7,77.2);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#E98976").s().p("AhECIQgEgIgEgRIgGgVQgEgLAAgKIAAgYQAAgsAIgcQAIggAVgiIAYglQAPgRARAAQAEAAAHACQAHADAEAAIgGgEQAXAFALAaQADAIALAuIAKAnQAGAVAAASQAAAXgFAVQgCALgJAgIgEARQgCAJgFAFQgEAEgHgBIgNgCQgGAAgKAEQgKAEgGAAQgEAAgIgDQgJgDgFAAQgGAAgIAFQgJAFgGAAQgKAAgHgMg");
	this.shape_112.setTransform(137.7,77.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#E98D79").s().p("AhNBxIgGgWQgEgLAAgLIAAgYQAAgtAHgbQAJghAVgiQAWgiADgDQAPgSARAAQAFAAAGADQAHADAEAAIgGgFQAXAFALAbQADAIALAvQAEAPAHAYQAGAWAAARQAAAXgFAWIgMArIgDARQgDAJgFAFQgEAEgGgBQgIgCgGAAQgFABgLAEQgKAEgGAAQgEAAgJgDQgIgDgGAAQgFAAgJAFQgJAFgGAAQgSAAgHglg");
	this.shape_113.setTransform(137.8,77.1);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#EA917D").s().p("AhGCMQgEgIgEgSIgGgWQgEgLAAgKIAAgZQAAguAHgbQAJgiAWgiIAYgmQAPgRASgBQAFAAAGADQAHAEAEAAIgGgFQAYAFALAbQADAJALAuIALAoQAGAWAAARQAAAZgEAVIgNAsIgDARQgDAIgFAGQgEAEgHgBQgIgCgFAAQgGAAgLAFQgJAEgHAAQgEAAgJgDQgJgEgFABQgGAAgIAEQgJAGgHAAQgLgBgGgLg");
	this.shape_114.setTransform(137.8,77);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#EA9581").s().p("AhHCNQgEgIgEgSQgKgaAAgSIAAgZQAAgtAIgdQAIghAWgjIAagmQAPgSARAAQAFAAAHADQAHADAEAAIgGgFQAYAFALAcQADAIALAvIAMApQAFAWAAASQAAAYgEAVQgDAOgKAfIgDARQgDAJgFAFQgEAEgHgBIgNgBQgHAAgKAEQgKAEgHAAQgEAAgIgDQgJgDgGAAQgGAAgJAFQgJAFgGAAQgLAAgHgMg");
	this.shape_115.setTransform(137.7,77);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#EA9985").s().p("AhHCOQgFgIgEgSQgKgaAAgSIAAgZQgBguAJgdQAIgiAWgjIAagnQAPgSASAAQAFAAAHADQAHADAFAAIgHgEQAYAFAMAbQADAKALAvIAMApQAFAWAAASQAAAYgEAWQgDANgKAgIgEARQgCAJgGAGQgDAEgIgBIgNgCQgHABgKAEQgKAEgHAAQgEAAgJgDQgJgDgGAAQgGAAgIAFQgKAFgGAAQgLAAgGgNg");
	this.shape_116.setTransform(137.8,76.9);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#EB9D89").s().p("AhICQQgFgJgEgSIgHgWQgDgMAAgLIAAgZQgBgvAJgcQAIgjAXgjIAagnQAPgSASgBQAFABAHADQAHACAFAAIgHgEQAYAFAMAcQAEAIALAxIAMApQAFAWAAATQAAAYgEAWQgDAMgKAiIgEARQgDAKgFAFQgDAEgIgBIgOgBQgGAAgKAEQgLAEgHABQgEAAgJgDQgJgEgGAAQgGAAgJAGQgJAEgGAAQgMAAgGgMg");
	this.shape_117.setTransform(137.8,76.9);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#EBA08D").s().p("AhJCSQgFgJgEgSIgHgXQgDgMAAgLIAAgZQAAgvAIgeQAIgjAXgjIAbgnQAPgTASAAQAFAAAHADQAIADAFAAIgHgFQAYAFAMAdQAEAIALAxIAMAqQAFAWABATQgBAZgFAXQgCAMgKAhIgEASQgDAJgFAFQgEAFgIgBIgNgCQgHABgKAEQgLAEgHAAQgEAAgJgDQgJgEgGABQgGgBgJAGQgJAFgHAAQgMAAgGgMg");
	this.shape_118.setTransform(137.8,76.9);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#EBA491").s().p("AhKCTQgFgJgEgSIgHgWQgDgNAAgLIAAgaQAAgwAHgdQAKgjAXgkIAagoQAQgTASAAQAFAAAHADQAIAEAFAAIgHgFQAZAFAMAdQADAJAMAxIALAqQAGAXABASQgBAagFAWQgCANgKAhIgEASQgDAKgFAFQgEAFgIgBIgNgCQgIAAgKAEQgKAFgIAAQgEAAgJgDQgJgEgHAAQgFAAgKAGQgJAFgGAAQgMAAgHgNg");
	this.shape_119.setTransform(137.8,76.8);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#ECA895").s().p("AhLCVQgFgJgEgSIgHgYQgEgMAAgLIAAgaQAAgwAIgeQAJgkAYgkIAagpQAQgSATgBQAFAAAIAEQAHADAFAAIgHgFQAZAFAMAdQAEAJAMAyIAMAqQAGAYAAASQAAAZgFAYIgNAvIgEASQgDAJgFAGQgFAEgHgBIgOgCQgHAAgLAFQgLAEgHABQgEgBgJgDQgKgDgGAAQgGAAgJAFQgKAGgGgBQgMABgHgNg");
	this.shape_120.setTransform(137.8,76.8);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#ECAC99").s().p("AhMCWQgFgIgEgUIgHgWQgEgNAAgMIAAgaQAAgwAIgfQAKgjAYglIAbgpQAPgTAUAAQAFAAAHADQAIAEAFgBIgHgEQAZAFAMAdQAEAJAMAyIAMAsQAGAXAAATQAAAZgFAXIgNAvIgFATQgCAJgFAGQgFAFgHgBIgOgDQgIABgKAFQgLAEgIAAQgEAAgJgDQgKgEgGABQgGgBgKAGQgJAFgHAAQgMAAgHgNg");
	this.shape_121.setTransform(137.8,76.7);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#ECAF9E").s().p("AhNCYQgEgJgFgTIgHgYQgEgNAAgKIAAgbQAAgxAIgfQAKgkAYgkIAbgqQARgTATAAQAGAAAGACIANAEIgHgFQAZAGANAdQAEALALAwQAEASAJAaQAGAYAAATQAAAagFAYQgDAOgLAhIgDASQgDAKgFAGQgFAFgIgCQgIgCgGAAQgHAAgLAFQgLAEgHABQgFgBgJgCQgKgEgGAAQgGAAgKAGQgKAEgGAAQgNAAgHgMg");
	this.shape_122.setTransform(137.8,76.7);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#EDB3A2").s().p("AhOCZQgFgJgEgTIgHgYQgEgNAAgLIAAgbQAAgxAIgfQAKgkAYgmIAcgqQAQgTAUAAQAFAAAIADIAMADIgHgFQAaAGAMAdQAEAJAMA0QAEARAJAbQAGAXAAAUQAAAagFAYQgDAOgLAiIgEASQgCAKgGAGQgFAFgHgBQgJgDgGAAQgHABgLAFQgLAEgIAAQgEAAgKgDQgJgEgHAAQgGAAgKAGQgJAFgHAAQgNAAgHgNg");
	this.shape_123.setTransform(137.8,76.6);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#EDB7A6").s().p("AhPCbQgFgKgEgTIgHgYQgEgNAAgLIAAgbQAAgyAJgfQAJglAZgmIAbgqQARgUAUAAQAFAAAIADIAMAEIgHgGQAbAGAMAeQAEAKAMAzQAEASAJAbQAGAXAAAUQAAAbgFAXQgDAOgLAjIgEATQgCAKgGAGQgFAEgIgBIgOgCQgIABgLAEQgLAFgIAAQgEAAgKgEQgJgDgHAAQgGAAgKAFQgKAGgHAAQgMAAgIgNg");
	this.shape_124.setTransform(137.8,76.6);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#EDBAAA").s().p("AhPCcQgFgJgFgTIgHgZQgEgNAAgLIAAgcQAAgyAJggQAJglAZgmIAcgrQARgUAUAAQAGAAAHADQAIAEAFAAIgHgFQAaAGANAeQAEAKAMAzIANAtQAGAYAAAUQAAAbgFAYQgDAOgLAjIgEATQgCAKgGAGQgFAFgIgBIgPgCQgHAAgMAFQgLAEgIAAQgEAAgKgDQgKgEgGAAQgHAAgKAGQgKAGgHAAQgMAAgHgOg");
	this.shape_125.setTransform(137.8,76.5);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#EEBEAE").s().p("AhQCeQgFgJgFgUIgHgZQgEgNAAgMIAAgbQAAgzAJggQAJglAZgnIAdgrQARgUAUAAQAGAAAHADQAIADAFABIgHgGQAbAGANAfQADAJANA1IANAtQAGAYAAAVQAAAbgFAYQgDAOgLAjIgEAUQgDAKgGAGQgEAEgIgBIgPgCQgIABgLAEQgMAFgIAAQgEAAgKgDQgKgEgGAAQgHAAgKAGQgKAFgHAAQgNAAgHgNg");
	this.shape_126.setTransform(137.8,76.5);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#EEC1B2").s().p("AhSCfQgFgJgEgUIgHgZQgFgNAAgMIAAgcQAAgzAJggQAKgmAZgnIAdgrQARgVAVAAQAGAAAHADQAIAEAGAAIgIgFQAbAGANAeQAFAKAMA1IANAuQAGAYAAAVQAAAbgFAZQgDAMgLAmIgEATQgDAKgGAGQgFAFgIgBIgPgCQgIAAgMAFQgLAFgIAAQgFAAgKgEQgJgDgHAAQgHAAgKAFQgKAGgHAAQgNAAgIgOg");
	this.shape_127.setTransform(137.8,76.4);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#EEC5B6").s().p("AhSCgQgFgJgFgUIgHgZQgFgNAAgMIAAgdQAAgzAJghQAKgmAagnIAdgsQARgVAVABQAGAAAIACQAJAEAEABIgHgGQAbAGANAfQAFAKAMA1IANAuQAHAZAAAVQAAAbgGAZQgCAMgMAmIgEAUQgDAKgGAGQgFAFgIgBIgPgCQgIABgMAEQgLAFgIAAQgFAAgKgDQgKgEgHAAQgHAAgKAGQgKAFgHABQgNgBgIgOg");
	this.shape_128.setTransform(137.8,76.4);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#EEC8BB").s().p("AhTCiQgFgJgFgUIgHgZQgFgOAAgMIAAgdQAAg0AKghQAKgmAagoIAdgtQARgUAWAAQAFAAAIADQAIADAGABIgIgGQAbAHAOAeQAEALANA2QAEASAJAdQAHAYAAAVQAAAcgGAZQgDAOgLAlIgEAUQgDAKgGAGQgFAFgIgCIgQgBQgHAAgMAFQgMAEgIABQgFgBgKgDQgKgDgHgBQgHAAgLAHQgKAFgHAAQgNAAgIgOg");
	this.shape_129.setTransform(137.8,76.4);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#EECCBF").s().p("AhUCjQgFgIgFgVIgIgaQgEgOAAgMIAAgcQAAg1AKgiQAKgmAagoIAdgtQASgVAWAAQAFAAAIAEQAIADAGAAIgIgFQAcAFANAhQAFAKAMA2QAFATAJAcQAHAZAAAWQAAAcgGAYIgPA0IgEAUQgCALgHAFQgEAGgJgCIgPgCQgIABgNAEQgLAFgJABQgEAAgLgEQgKgEgHAAQgHAAgLAGQgJAGgIAAQgOAAgHgPg");
	this.shape_130.setTransform(137.8,76.3);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#EFCFC3").s().p("AhVClQgFgJgFgVIgIgZQgEgPAAgMIAAgcQAAg2AKghQAJgnAbgpIAeguQASgVAWABQAFgBAIAEQAJADAFAAIgHgFQAcAGANAgQAFAMAMA1IAOAwQAHAZAAAWQAAAcgGAZQgDAQgMAkIgEAUQgDALgGAGQgFAFgIgBQgKgCgGAAQgHAAgNAFQgMAFgJAAQgEAAgLgDQgKgFgHAAQgHABgLAFQgKAGgIABQgNAAgIgPg");
	this.shape_131.setTransform(137.8,76.3);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#EFD2C7").s().p("AhWCnQgFgJgFgWIgIgaQgEgOAAgMIAAgdQAAg2AKgiQAJgnAcgpIAeguQASgVAWAAQAGAAAHADQAJAEAGAAIgIgGQAcAHAOAgQAEAKAOA4IANAwQAHAZAAAWQAAAcgGAaQgDAQgLAkIgFAVQgDAKgGAGQgFAGgIgBQgLgDgFAAQgIABgNAEQgMAGgJAAQgEgBgLgDQgKgEgIAAQgGAAgMAGQgKAGgIAAQgNAAgIgOg");
	this.shape_132.setTransform(137.8,76.2);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#EFD6CB").s().p("AhWCoQgGgKgEgVIgIgaQgFgOAAgMIAAgeQAAg2AJgjQALgnAbgpIAeguQASgWAXAAQAGAAAIAEQAIADAGAAIgIgFQAdAGAOAhQAFALANA3QAEATAJAdQAHAaAAAWQAAAdgGAZQgDAQgLAlIgFAVQgDAKgHAHQgEAFgJgBIgQgCQgIAAgMAFQgNAFgJAAQgEAAgLgDQgKgEgIAAQgHAAgLAGQgLAGgHAAQgOAAgHgPg");
	this.shape_133.setTransform(137.8,76.2);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#EFD9D0").s().p("AhXCqQgGgLgEgUIgJgbQgEgOgBgNIAAgdQABg3AJgjQALgoAcgpIAegvQASgVAXAAQAGAAAIADQAJAEAGAAIgJgGQAeAHAOAgQAEAKAOA5QAEATAJAeQAIAagBAWQABAdgHAaQgCAOgMAoIgFAUQgDALgHAHQgEAFgJgCIgQgCQgJABgMAFQgNAFgIAAQgFAAgLgEQgLgEgHAAQgHAAgLAGQgLAGgIAAQgNAAgIgOg");
	this.shape_134.setTransform(137.8,76.1);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#EFDCD4").s().p("AhYCrQgFgKgFgVIgJgbQgEgOgBgNIAAgeQAAg3AKgjQALgoAbgqIAggvQATgWAWAAQAGAAAIAEQAJADAGAAIgJgFQAeAGAPAhQADAKAPA6QAEATAJAeQAIAagBAWQAAAdgFAbQgEAOgLAoIgGAVQgCAKgHAHQgFAFgIgBIgRgCQgIAAgNAFQgNAFgIAAQgFAAgLgDQgLgEgHAAQgIAAgLAGQgLAGgHAAQgOAAgIgPg");
	this.shape_135.setTransform(137.8,76.1);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#EFDFD8").s().p("AhZCtQgFgKgGgWIgIgbQgEgOgBgNIAAgeQAAg4AKgjQALgpAcgqIAggwQASgWAYAAQAFAAAIAEQAKAEAFAAIgIgGQAdAHAPAhQAFALANA5QAFATAKAfQAGAaAAAXQAAAdgFAbQgEAPgMAnIgFAVQgDALgGAHQgFAFgJgBIgQgDQgIABgNAFQgOAFgIAAQgFAAgLgEQgLgEgIAAQgHAAgLAHQgLAGgIAAQgOAAgIgPg");
	this.shape_136.setTransform(137.8,76);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#F0E3DC").s().p("AhaCuQgGgKgFgVIgIgcQgFgOAAgNIAAgfQAAg4AKgkQALgpAcgqIAggwQATgWAXAAQAGAAAJADQAJAEAFAAIgIgGQAeAHAOAiQAFAKAOA6IAOAyQAIAbAAAXQAAAdgGAbQgDAOgNApIgFAVQgDAMgGAGQgGAFgJgBIgQgCQgIAAgOAGQgMAFgJAAQgFAAgLgEQgLgEgIAAQgHAAgMAGQgLAGgIAAQgOAAgIgPg");
	this.shape_137.setTransform(137.8,76);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#F0E6E0").s().p("AhbCwQgGgLgFgWIgIgbQgFgPAAgNIAAgeQAAg5AKgkQALgqAdgqIAggwQATgXAXAAQAGAAAJADQAJAEAGABIgJgHQAfAHAOAjQAFALAOA5IAOAzQAIAbAAAXQAAAegGAbQgDAOgNApIgFAWQgDAKgHAIQgFAEgJgBIgQgCQgJABgNAFQgNAFgJAAQgFAAgMgEQgLgEgHAAQgIAAgLAHQgLAGgIAAQgPAAgIgPg");
	this.shape_138.setTransform(137.8,76);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#F0E9E4").s().p("AhcCxQgGgKgFgWIgIgbQgFgPAAgOIAAgfQAAg5AKgkQALgqAdgsIAggwQAUgWAXgBQAHAAAIAEQAKADAFABIgIgGQAeAHAPAiQAFAMAOA6IAOAzQAIAbAAAXQAAAfgGAbQgEAQgMAoIgFAVQgDALgHAHQgFAFgJgBIgRgDQgIABgOAFQgNAFgJABQgFAAgMgEQgLgEgHAAQgIAAgMAHQgLAFgIAAQgOAAgJgPg");
	this.shape_139.setTransform(137.8,75.9);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#F0ECE8").s().p("AhdCyQgFgKgGgWIgIgcQgFgPAAgNIAAgfQAAg6AKglQALgqAdgrIAhgyQAUgWAYAAQAGAAAJADQAJAEAGAAIgJgFQAfAGAPAjQAEAKAPA8IAOA0QAIAbAAAYQAAAegGAbQgEARgMAnIgFAWQgDAMgHAHQgFAFgJgCQgLgCgGAAQgJABgOAFQgNAGgJgBQgFAAgMgDQgLgEgIgBQgIAAgLAHQgMAGgIAAQgOAAgJgQg");
	this.shape_140.setTransform(137.8,75.9);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#E2893B").s().p("AgpAqQgBgBgBgHQABgKAEgLQAGgNABgGIAAgMQAAgIACgDQADgIAFgCQAEgCAJAAQAGAAAHAGQAIAFAGAAIAOgBQAHgBADAGIAAAFIgFABIgMgDQgFAAgFgEQgHgFgEAAQgJAAgKAIQgJAIgEALQgCAFgFAZQgCARgEAAIgBAAg");
	this.shape_141.setTransform(201.2,73.6);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#E28B3D").s().p("AgrAsQgBgBgBgGQAAgLAFgMIAGgUIABgMQgBgIADgEQAFgOARAAQAGAAAIAGQAIAGAGAAIAPgBQAHABAEAGQAAAFgCABIgFAAIgLgCQgFAAgHgEQgGgEgFAAQgJAAgKAIQgJAHgEAMIgHAfQgDARgEAAIgBgBg");
	this.shape_142.setTransform(201.3,73.6);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#E38D3F").s().p("AgtAvQgBgBAAgHQAAgLAEgNQAFgPABgHIABgMQAAgHACgEQAHgQARAAQAGAAAHAGQAKAGAGAAIAPAAQAIABAEAHQAAAEgCACQgCABgFAAIgKgCQgFAAgHgEQgHgEgFAAQgJAAgKAIQgJAIgFAMIgHAfQgEARgEAAIgBAAg");
	this.shape_143.setTransform(201.4,73.7);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#E38F41").s().p("AguAxQgCgBAAgGQAAgMAEgOIAGgXQAAgQADgIQAIgRARAAQAHAAAHAGQAKAHAGAAIAQAAQAIABAFAHQgBAJgJAAIgJgBQgFAAgIgEQgHgFgGAAQgWAAgLAcIgIAhQgEAQgEAAIgBAAg");
	this.shape_144.setTransform(201.4,73.7);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#E39043").s().p("AgwA0QgCgCAAgFQAAgNADgOIAHgaQAAgPADgIQAJgUARAAQAIAAAHAHQAKAHAHAAQAMAAAFABQAIACAFAHQgBAKgLAAIgIgBQgGAAgIgEQgHgEgGAAQgWAAgMAbIgIAiQgEARgFAAIgBAAg");
	this.shape_145.setTransform(201.5,73.8);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#E49245").s().p("AgyA2QgCgCAAgFQAAgOADgPIAGgbQACgPADgIQAKgVARAAQAIAAAHAHQAKAGAHAAQANAAAFACQAJACAFAIQgCALgMAAIgHAAQgFAAgJgEQgIgFgFAAQgXAAgMAdQgEAKgFAYQgEARgFAAIgCAAg");
	this.shape_146.setTransform(201.6,73.9);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#E49245").s().p("AgIBoQgTgCgRgJQgPgJgGgTQgEgOgBgaQABgaAEgXQADgQAKgiQAFgPAHgHQAIgIANAAQAEAAAOAHQALAGAFAAQAhAAANAaQAKAVAAAsQAAAugHAXQgJAkgbAAIgkgBg");
	this.shape_147.setTransform(202.1,77.2);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#E4954A").s().p("AgHBpQgTgCgSgJQgQgJgGgTQgEgPAAgZQAAgaAEgYQAEgRAKgiQAIgeAYAAQAFAAAOAGQALAGAFAAQAhAAANAbQAKAWAAAsQAAAvgGAXQgJAkgbAAQgdAAgHgBg");
	this.shape_148.setTransform(202.1,77.2);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#E5984F").s().p("AgIBrQgTgCgRgKQgQgIgGgUQgFgPAAgaQAAgaAFgYQADgRAKgjQAJgfAYAAQAFAAANAHQAMAGAEAAQAiAAANAcQALAWAAAsQAAAwgGAXQgKAlgbAAQgdAAgIgBg");
	this.shape_149.setTransform(202.1,77.1);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#E59B54").s().p("AgHBsQgTgCgTgJQgPgJgHgUQgFgPAAgaQABgbAEgZQADgPALglQAJgfAYAAQAFAAANAGQAMAFAEAAQAiAAANAdQAMAXAAAtQgBAxgGAXQgKAlgaAAQgeAAgHgBg");
	this.shape_150.setTransform(202.1,77.1);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#E69E59").s().p("AgHBtQgUgCgSgJQgQgJgGgUQgFgPgBgbQABgbAFgZQADgQAKglQAJgfAYAAQAFgBAOAGQAMAFAEABQAjAAAOAdQAKAYABAtQgBAxgGAYQgKAmgbgBQgeAAgHgBg");
	this.shape_151.setTransform(202.1,77.1);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#E6A15F").s().p("AgIBvQgTgCgTgKQgQgJgGgUQgFgPAAgbQAAgcAFgZQADgQAKglQAKghAYAAQAEAAAOAFQAMAGAEAAQAjAAAPAeQALAYAAAvQAAAxgGAYQgKAmgcAAQgeAAgIgBg");
	this.shape_152.setTransform(202.1,77.1);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#E7A564").s().p("AgIBwQgUgCgSgJQgRgJgGgVQgFgPAAgbQAAgdAFgZQAEgRAKglQAKghAYAAQAEAAAOAFQAMAFAEAAQAjAAAPAfQAMAZAAAvQAAAygGAYQgKAngcgBQgfAAgIgBg");
	this.shape_153.setTransform(202,77.1);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#E7A869").s().p("AgIByQgUgCgSgKQgRgJgGgVQgFgQAAgbQAAgdAFgZQADgRALglQAKgjAYAAQAEAAAOAFQAMAFAEAAQAjAAAPAgQAMAaAAAvQAAAzgGAYQgKAngcAAIgngBg");
	this.shape_154.setTransform(202,77);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#E8AB6F").s().p("AgIB0QgUgCgTgLQgRgJgGgVQgFgQAAgcQAAgdAFgZQADgTALgkQAKgjAZAAQADgBAPAGQAMAEADAAQBAAAAABrQAAA0gGAZQgLAngcgBQgfAAgIAAg");
	this.shape_155.setTransform(202,77);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#E8AE74").s().p("AgIB1QgVgCgSgLQgRgJgHgVQgFgQAAgcQAAgeAFgZQADgQAMgoQAKgkAYAAQAEAAAOAFQAMAFAEAAQBBAAAABtQAAAzgGAZQgLAogcAAIgogBg");
	this.shape_156.setTransform(202,77);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#E9B179").s().p("AgIB2QgUgCgTgKQgSgKgGgVQgFgQgBgdQABgeAFgaQADgSALgmQAKgkAZAAQAEAAAOAEIAPAEQBDAAAABwQAAA0gHAZQgKAogdAAQggAAgIgBg");
	this.shape_157.setTransform(202,77);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#E9B47F").s().p("AgIB4QgVgCgTgLQgSgJgGgWQgGgRAAgcQABgfAFgZQAEgSAKgnQALgmAZAAQADAAAOAFIAQAEQBEAAAABxQgBA1gGAZQgLApgdAAIgogBg");
	this.shape_158.setTransform(202,76.9);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#E9B784").s().p("AgIB5QgVgCgUgLQgRgJgHgWQgFgRAAgdQAAgfAFgaQAEgSALgnQALgmAZAAIASAEIAPAEQBEAAAABzQAAA1gHAaQgKApgeAAQggAAgIgBg");
	this.shape_159.setTransform(202,76.9);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#EAB989").s().p("AgJB7QgVgDgTgLQgSgKgHgVQgFgRAAgeQAAgfAGgaQADgSALgoQAMgmAZgBIARAFIAQADQAlAAARAkQAPAfAAAyQAAA2gHAaQgLAqgdAAQgiAAgIgBg");
	this.shape_160.setTransform(202,76.9);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#EABC8F").s().p("AgJB8QgVgCgTgLQgTgKgGgWQgGgRAAgeQAAggAGgaQADgTAMgnQALgoAaAAIARAEIAQADQAlAAASAmQAOAfAAAzQABA2gHAbQgLApgeAAQghAAgJgBg");
	this.shape_161.setTransform(202,76.9);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#EBBF94").s().p("AgJB9QgVgCgUgLQgSgKgHgXQgFgQAAgeQAAghAFgaQAEgTALgoQAMgpAZAAQAFAAAcAIQAmgBASAmQAPAhAAAzQAAA3gHAbQgLApgeAAQgiAAgIgBg");
	this.shape_162.setTransform(202,76.9);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#EBC299").s().p("AgJB/QgVgCgUgLQgTgLgGgWQgGgSAAgeQAAghAGgaQADgUAMgoQAKgpAbAAQAFAAAcAGQAmAAATAnQAPAhAAA0QAAA3gHAbQgLArgfAAQgiAAgIgBg");
	this.shape_163.setTransform(202,76.8);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#ECC59F").s().p("AgJCAQgWgCgUgLQgSgLgHgWQgGgSAAgeQAAghAGgbQADgSAMgrQAMgqAaAAIAgAGQAnAAATAoQAQAiAAA0QAAA4gHAbQgLAsgfgBQgjAAgIgBg");
	this.shape_164.setTransform(201.9,76.8);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#ECC8A4").s().p("AgJCCQgWgDgUgLQgTgKgHgXQgFgSAAgfQAAghAFgbQAEgUAMgpQAMgrAaAAIAgAGQAnAAATAoQAQAiAAA1QAAA5gHAbQgLAsgfAAQgjAAgIgBg");
	this.shape_165.setTransform(201.9,76.8);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#ECCBA9").s().p("AgJCDQgWgCgVgMQgTgKgHgXQgFgSAAgfQAAgiAFgcQAEgSAMgrQAMgrAaAAIAgAFQAoAAAUApQAQAjAAA1QAAA6gHAbQgLAsggAAQgjAAgIgBg");
	this.shape_166.setTransform(201.9,76.8);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#EDCEAF").s().p("AgJCFQgXgDgUgLQgTgLgHgXQgGgSAAggQAAgiAGgbQAEgVAMgpQAMgtAaAAIAgAFQAoAAAUAqQARAkAAA2QAAA6gHAcQgMAsggAAQgjAAgIgBg");
	this.shape_167.setTransform(201.9,76.7);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#EDD0B4").s().p("AgJCGQgWgCgVgMQgUgLgHgYQgGgRAAggQAAgjAGgcQAEgTAMgrQAGgVAIgLQAKgNAPAAIAgAEQAoAAAVArQAQAkAAA3QAAA6gGAdQgMAsggAAQgjAAgJgBg");
	this.shape_168.setTransform(201.9,76.7);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#EDD3B9").s().p("AgJCIQgXgDgVgMQgTgLgHgYQgGgSAAggQAAgjAGgcQADgUANgrQAGgWAIgKQAKgOAPAAIAgAEQAoAAAVAsQARAkAAA4QAAA7gHAdQgMAsggABQgjAAgJgBg");
	this.shape_169.setTransform(201.9,76.7);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#EED6BF").s().p("AgJCJQgYgCgUgMQgUgLgHgZQgGgSAAggQAAgkAGgcQAEgUAMgsQAMguAbAAIAgADQApAAAVAtQASAlAAA4QAAA8gHAcQgMAuggAAIgtgBg");
	this.shape_170.setTransform(201.9,76.7);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#EED9C4").s().p("AgKCLQgXgDgVgMQgTgLgIgZQgGgSAAghQAAgjAGgdQAEgVANgrQAMgwAbABIAgADQApAAAVAtQATAmAAA5QAAA7gIAeQgLAughAAQglAAgJgBg");
	this.shape_171.setTransform(201.9,76.7);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#EEDCC9").s().p("AgKCMQgXgDgWgMQgTgLgIgZQgFgSAAghQAAgkAGgdQADgVANgsQANgwAbAAIAfADQAqAAAWAuQASAnAAA5QAAA8gHAeQgMAughAAQgmAAgIgBg");
	this.shape_172.setTransform(201.9,76.6);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#EFDECE").s().p("AgKCNQgXgDgWgMQgUgLgHgZQgGgTAAghQAAgkAGgdQAEgUAMguQAOgwAbAAIAfACQAqAAAWAvQATAnAAA6QAAA8gHAeQgNAvghAAQglAAgJgBg");
	this.shape_173.setTransform(201.9,76.6);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#EFE1D4").s().p("AgKCPQgXgDgXgMQgTgMgIgZQgGgTAAghQAAglAGgdQAEgVANgtQANgyAcAAIAfACQAqAAAWAwQAUAoAAA6QAAA9gIAfQgMAvgiAAQgmAAgIgBg");
	this.shape_174.setTransform(201.9,76.6);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#EFE4D9").s().p("AgKCQQgYgDgWgMQgUgMgIgZQgFgTgBgiQAAglAHgeQADgVAOgtQANgyAbAAIAgABQAqAAAXAwQATAqAAA6QABA/gIAeQgMAvgiAAQglAAgKgBg");
	this.shape_175.setTransform(201.9,76.6);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#EFE6DE").s().p("AgKCRQgYgCgWgMQgUgMgIgaQgGgUAAgiQAAgkAGgfQAEgVANguQAHgXAIgMQAKgPAQAAIAfAAQArAAAXAxQAUAqAAA8QAAA+gHAeQgNAxgigBQgnAAgIgBg");
	this.shape_176.setTransform(201.8,76.6);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#F0E9E3").s().p("AgKCTQgYgDgXgMQgUgMgIgaQgGgTAAgjQAAglAGgfQAEgUANgwQAOgzAcAAIAfAAQArAAAYAyQAUArAAA8QAAA/gIAfQgMAwgiAAQgmAAgKgBg");
	this.shape_177.setTransform(201.8,76.5);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#F0ECE8").s().p("AgKCUQgZgCgWgNQgVgMgIgaQgGgTAAgjQAAgnAGgeQAFgXANgtQAOg0AcAAIAeAAQAsAAAYAyQAVAsAAA8QAAA/gIAgQgNAwgiAAQgoAAgIgBg");
	this.shape_178.setTransform(201.8,76.5);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#F0ECE8").s().p("A1ONDIAA6FMAqeAAAIAAaFg");
	this.shape_179.setTransform(136,83.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text},{t:this.instance}]}).to({state:[{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape},{t:this.text},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,0,273,203.9);


(lib.btn_centrifugacion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mapadebits11();
	this.instance.setTransform(11.3,-14.5);

	this.text = new cjs.Text(txt['btn_centr'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(133.5,179.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AVQM+MgqfAAAIAA57MAqfAAAg");
	this.shape.setTransform(136,83.5,1,1.006);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AI2h4IAADxIxsAAIAAjxg");
	this.shape_1.setTransform(136.2,189.9,1.186,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("Ao2B5IAAjxIRsAAIAADxg");
	this.shape_2.setTransform(136.2,189.9,1.186,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AVSs/IAAZ/MgqjAAAIAA5/g");
	this.shape_3.setTransform(135.9,83.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("A1RNAIAA5/MAqjAAAIAAZ/g");
	this.shape_4.setTransform(135.9,83.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1D1D1C").s().p("AgRAAQAAgIARAAQASAAAAAIQAAAJgSAAQgRAAAAgJgAgNAAQAAAGANAAQAOAAAAgGQAAgGgOABQgNgBAAAGg");
	this.shape_5.setTransform(166.5,20.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1D1D1C").s().p("AgMAFIAAgEIgHAAIgCgBIAJAAIAAgEIAEAAIAAAEIAVAAQAFAAAAgCIAAgCIADAAIABACQAAACgEABIgHAAIgTAAIAAAEg");
	this.shape_6.setTransform(166.1,22.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D1D1C").s().p("AgQAIIAAgDIAUAAQAJAAAAgFQAAgEgLAAIgSAAIAAgCIAYAAIAIgBIAAADIgFAAIAAAAQAGACAAADQAAAHgOAAg");
	this.shape_7.setTransform(166.6,24.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D1D1C").s().p("AgYABIAAgBIAxAAIAAABg");
	this.shape_8.setTransform(165.8,25.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D1D1C").s().p("AgLAHQgGgDAAgEQAAgIARAAQASAAAAAIQAAAEgGADQgFACgHAAQgGAAgFgCgAgNAAQAAAGANAAQAOAAAAgGQAAgGgOAAQgNAAAAAGg");
	this.shape_9.setTransform(166.5,27.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1D1D1C").s().p("AAHAFQAHAAAAgFQAAgEgHAAQgFAAgCAEQgBAHgGAAQgKAAAAgHQAAgGAKAAIAAACQgGABAAADQAAAEAFAAQAEAAABgCIADgFQAAgEAGAAQAMAAAAAHQAAAHgLABg");
	this.shape_10.setTransform(166.5,29.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1D1D1C").s().p("AgRAAQAAgIARAAIAAAOQAOAAAAgGQAAgDgIgCIAAgDQAMADAAAFQAAAJgSAAQgRAAAAgJgAgNAAQAAAFAMABIAAgLQgMABAAAEg");
	this.shape_11.setTransform(166.5,32.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1D1D1C").s().p("AgKAAQABgCAGgDIgVAAIAAgCIAwAAIAAACIgFAAQAGADAAACQAAAJgTAAQgQAAAAgJgAgGAAQAAAGAMAAQAPAAAAgGQAAgFgPAAQgMAAAAAFg");
	this.shape_12.setTransform(165.8,35.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1D1D1C").s().p("AgKAAQABgCAGgDIgVAAIAAgCIAwgBIAAADIgFAAIAAAAQAGADAAACQAAAJgTAAQgQAAAAgJgAgGAAQAAAGAMAAQAPAAAAgGQAAgFgPAAQgMAAAAAFg");
	this.shape_13.setTransform(165.8,38.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1D1D1C").s().p("AgBADIgCgHIgDAAQgHABAAADQAAADAGABIAAACQgKAAAAgGQAAgGAMAAIAWAAIAAACIgFAAQAGACAAADQAAAGgLABQgHgBgBgEgAAAABQABAEAGAAQAHAAAAgFQAAgEgOAAIAAAFg");
	this.shape_14.setTransform(166.5,40.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1D1D1C").s().p("AgKAAQABgCAGgDIgVAAIAAgCIAoAAIAIgBIAAADIgFAAQAGADAAACQAAAJgTAAQgQAAAAgJgAgGAAQAAAGAMAAQAPAAAAgGQAAgFgPAAQgMAAAAAFg");
	this.shape_15.setTransform(165.8,43);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#1D1D1C").s().p("AgIABIAAgBIAhAAIAAABgAgYABIAAgBIAGAAIAAABg");
	this.shape_16.setTransform(165.8,44.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#1D1D1C").s().p("AgMAFIAAgEIgHAAIgCgBIAJAAIAAgEIAEAAIAAAEIAVAAQAFAAAAgCIAAgCIADAAIABACQAAADgLAAIgTAAIAAAEg");
	this.shape_17.setTransform(166.1,45.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1D1D1C").s().p("AgPAIIAAgDIAFAAQgGgCAAgDQAAgHAOAAIATAAIAAADIgUAAQgKAAAAAEQAAAFAMAAIASAAIAAADg");
	this.shape_18.setTransform(166.5,47.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1D1D1C").s().p("AgBADIgCgHIgDAAQgHAAAAAEQAAAEAGAAIAAADQgKgBAAgGQAAgGAMAAIAOAAIAIgBIAAADIgFAAQAGACAAADQAAAHgLAAQgHAAgBgFgAAAgEIAAAFQABAEAGAAQAHAAAAgFQAAgEgLAAIgDAAg");
	this.shape_19.setTransform(166.5,49.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#1D1D1C").s().p("AgRAAQAAgHAMAAIAAACQgIABAAAEQAAAFANAAQAOAAAAgFQAAgEgIgBIAAgCQAMABAAAGQAAAIgSAAQgRAAAAgIg");
	this.shape_20.setTransform(166.5,51.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#1D1D1C").s().p("AgOAAQAAgJAOAAQAPAAAAAJIgYAAQAAAIAKAAQAIAAABgFIAFAAQgEAHgLAAQgOABAAgLgAAKAAQAAgIgKABQgJgBAAAIIATAAIAAAAg");
	this.shape_21.setTransform(240.4,59.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#1D1D1C").s().p("AAAALQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAgBAAAAIAAgMIgHAAIAAgCIAHAAIAAgEIACgBIAAAFIAIAAIAAACIgIAAIAAAMQAAADAFAAIADAAIAAADIgEAAQgFAAAAgCg");
	this.shape_22.setTransform(237.3,58.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#1D1D1C").s().p("AAJAKIAAgLQAAgGgJAAQgIAAAAAHIAAAKIgEAAIAAgOIAAgFIAEAAIAAAEQAEgEAFAAQAMAAAAAIIAAALg");
	this.shape_23.setTransform(234.2,59.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#1D1D1C").s().p("AgOAAQAAgJAOAAQAPAAAAAJIgZAAQABAIAJAAQAJAAACgFIADAAQgCAHgMAAQgOABAAgLgAALAAQgCgIgJABQgIgBgCAIIAVAAIAAAAg");
	this.shape_24.setTransform(230.4,59.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#1D1D1C").s().p("AgGAOIAGgIIgPgTIAFAAIAKAQIALgQIAFAAIgSAbg");
	this.shape_25.setTransform(226.8,59.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#1D1D1C").s().p("AgNACIAAgLIAFAAIAAALQAAAGAIAAQAJAAAAgHIAAgKIAEAAIAAAOIAAAEIgEAAIAAgDIAAAAQgDAEgGAAQgNAAAAgIg");
	this.shape_26.setTransform(223.2,59.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#1D1D1C").s().p("AAAAOIAAgbIABAAIAAAbg");
	this.shape_27.setTransform(220.5,58.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#1D1D1C").s().p("AgKAHQgEgDAAgEQAAgJAOAAQAPAAAAAJIgZAAQAAAIAKAAQAJAAABgFIAFAAQgEAHgLAAQgGAAgEgDgAALAAQgBgIgKABQgJgBgBAIIAVAAIAAAAg");
	this.shape_28.setTransform(217.8,59.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#1D1D1C").s().p("AgOAAQAAgJAOAAQAPAAAAAJIgZAAQAAAIAKAAQAJAAABgFIAFAAQgDAHgMAAQgOABAAgLgAALAAQgBgIgKABQgIgBgCAIIAVAAIAAAAg");
	this.shape_29.setTransform(212,59.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#1D1D1C").s().p("AgOADQAAgIAOAAQAHAAADADIAAgMIAFAAIAAAcIgEAAIgBgDQgEAEgGAAQgOAAAAgMgAgJADQAAAJAJAAQAKAAAAgJQAAgGgKAAQgJAAAAAGg");
	this.shape_30.setTransform(208.1,58.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#1D1D1C").s().p("AAJAKIAAgLQAAgGgJAAQgIAAAAAHIAAAKIgEAAIAAgOIgBgFIAFAAIAAAEQADgEAGAAQAMAAAAAIIAAALg");
	this.shape_31.setTransform(202.5,59.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#1D1D1C").s().p("AgKAHQgEgDAAgEQAAgJAOAAQAPAAAAAJIgZAAQAAAIAKAAQAJAAABgFIAFAAQgDAHgMAAQgGAAgEgDgAALAAQgBgIgKABQgIgBgCAIIAVAAIAAAAg");
	this.shape_32.setTransform(198.6,59.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#1D1D1C").s().p("AAUAKIAAgLQAAgGgJAAQgJAAgBAHIAAAKIgBAAIAAgLQgBgGgIAAQgKAAAAAHIAAAKIgFAAIAAgOIAAgFIAFAAIAAAEQADgEAIAAQAIAAAAAFQAFgFAHAAQANAAAAAIIAAALg");
	this.shape_33.setTransform(193.7,59.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#1D1D1C").s().p("AgNACIAAgLIAFAAIAAALQAAAGAIAAQAJAAAAgHIAAgKIAEAAIAAAOIABAEIgFAAIAAgDIgBAAQgDAEgFAAQgNAAAAgIg");
	this.shape_34.setTransform(188.7,59.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#1D1D1C").s().p("AAAAOIAAgbIABAAIAAAbg");
	this.shape_35.setTransform(186,58.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#1D1D1C").s().p("AgPAAQAAgJAPAAQAHgBAFAEQAEADAAADQAAAEgEADQgFADgHAAQgPABAAgLgAgKAAQAAADADACQADADAEAAQAFAAADgDQADgCAAgDQAAgIgLABQgKgBAAAIg");
	this.shape_36.setTransform(183.3,59.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#1D1D1C").s().p("AgBAKIgOgTIAFAAIAKAQIALgQIAFAAIgOATg");
	this.shape_37.setTransform(179.7,59.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#1D1D1C").s().p("AgMAEIAEAAQABAEAHAAQAJAAAAgEQAAgCgJgCQgLAAAAgEQAAgGALABQAMgBAAAGIgEAAQAAgEgIABQgGgBAAAEQAAACAEAAIAKACQAFAAAAADQAAAIgNgBQgMAAAAgGg");
	this.shape_38.setTransform(204.6,108.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#1D1D1C").s().p("AgKAHQgEgDAAgEQAAgJAOAAQAPgBAAAKIgZAAQABAIAJAAQAJAAABgFIAFAAQgDAHgMAAQgGAAgEgDgAALAAQgBgIgKABQgIgBgBAIIAUAAIAAAAg");
	this.shape_39.setTransform(201,108.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#1D1D1C").s().p("AgOADQAAgIAOAAQAHAAADADIABAAIAAgMIADAAIAAAXIABAFIgEAAIAAgDIgBAAQgEAEgGAAQgOAAAAgMgAgKADQAAAJAKAAQAKAAAAgJQAAgGgKAAQgKAAAAAGg");
	this.shape_40.setTransform(197.1,108.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#1D1D1C").s().p("AAJAKIAAgLQAAgGgJAAQgIAAAAAHIAAAKIgEAAIAAgTIAEAAIAAADQAEgDAFAAQAMAAAAAIIAAALg");
	this.shape_41.setTransform(193.3,108.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#1D1D1C").s().p("AgMAEQAAgEAHAAQADgBAKAAIAAgCQAAgFgHABQgHgBAAAEIgFAAQACgGAKABQAMgBAAAHIAAANIgEAAIAAgDIgBAAIAAAAQgDADgGAAQgLAAAAgGgAgBAAQgGABgBADQABAEAHAAQAKAAgCgIIgJAAg");
	this.shape_42.setTransform(189.6,108.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#1D1D1C").s().p("AgHAKIAAgTIAEAAIABADQACgDAEAAIAEAAIAAACIgDAAQgHAAAAAGIAAALg");
	this.shape_43.setTransform(187,108.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#1D1D1C").s().p("AgMAJIAEAAQAAADAIAAQAKAAABgGIAAgEIgBAAQgDAEgHAAQgOAAAAgJQAAgKAOAAQAFAAAFADIABAAIAAgDIAEAAIgBAFIAAAKIAAAHQgCADgFABIgHABQgNAAABgFgAgKgDQABADACABQADADAEAAQALAAAAgHQAAgDgEgCQgDgDgEAAQgKAAAAAIg");
	this.shape_44.setTransform(183.7,108.9);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#1D1D1C").s().p("AgMAEIAEAAQABAEAHAAQAJAAAAgEQAAgCgJgCQgLAAAAgEQAAgGALABQAMgBAAAGIgEAAQgBgEgHABQgHgBAAAEQAAACAFAAIAJACQAGAAAAADQAAAIgNgBQgMAAAAgGg");
	this.shape_45.setTransform(178.2,108.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#1D1D1C").s().p("AgMAEQAAgEAHAAQADgBALAAIAAgCQgBgFgIABQgGgBAAAEIgEAAQABgGAJABQANgBgBAHIAAAIIABAFIgEAAIAAgDIgBAAQgEADgEAAQgMAAAAgGgAAAAAQgIABABADQAAAEAHAAQAJAAAAgIIgJAAg");
	this.shape_46.setTransform(174.7,108.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#1D1D1C").s().p("AgBAOIAAgbIADAAIAAAbg");
	this.shape_47.setTransform(172.3,108);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#1D1D1C").s().p("AgMACIAAgLIAEAAIAAALQAAAGAIAAQAJAAAAgHIAAgKIAEAAIAAAOIAAAEIgEAAIAAgDQgEAEgFAAQgMAAAAgIg");
	this.shape_48.setTransform(169.6,108.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#1D1D1C").s().p("AgJAHQgEgDAAgEQAAgJAOAAQANAAAAAGIgFAAQAAgEgJAAQgIAAAAAHQAAAIAIAAQAJAAAAgFIAFAAQgCAHgMAAQgFAAgEgDg");
	this.shape_49.setTransform(166,108.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#1D1D1C").s().p("AgKALQgEgDAAgEQAAgJAOAAQAPgBAAAKIgZAAQAAAIALAAQAIAAACgFIAEAAQgDAHgMAAQgGAAgEgDgAALACQgBgGgKABQgIgBgCAGIAVAAIAAAAgAgCgIIAEgFIAGAAIgIAFg");
	this.shape_50.setTransform(162.3,108.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#1D1D1C").s().p("AAAAOIAAgbIABAAIAAAbg");
	this.shape_51.setTransform(159.7,108);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#1D1D1C").s().p("AgLAHQgEgDAAgEQAAgJAPAAQAHAAAFADQAEADAAADQAAAEgEADQgFADgHAAQgGAAgFgDgAgKAAQAAADADACQADADAEAAQALAAAAgIQAAgIgLABQgKgBAAAIg");
	this.shape_52.setTransform(157,108.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#1D1D1C").s().p("AAVAKIAAgLQAAgGgJAAQgKAAAAAHIAAAKIgCAAIAAgLQAAgGgJAAQgKAAAAAHIAAAKIgFAAIAAgTIAEAAIABADQADgDAIAAQAIAAABAFQAEgFAIAAQAMAAAAAIIAAALg");
	this.shape_53.setTransform(152,108.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#1D1D1C").s().p("AgMAEIAEAAQAAAEAIAAQAJAAAAgEQAAgCgJgCQgLAAAAgEQAAgFALAAQAMAAAAAFIgEAAQgBgDgHAAQgHAAAAADQAAACAFABIAJABQAGAAAAAEQAAAGgNAAQgMAAAAgGg");
	this.shape_54.setTransform(210,80.9);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#1D1D1C").s().p("AgMAEQAAgEAHAAQADgBALAAIAAgCQgBgEgIAAQgGAAAAADIgFAAQACgFAJAAQANAAAAAGIAAAIIAAAFIgEAAIAAgDIgBAAIAAAAQgDADgGAAQgLAAAAgGgAgBAAQgHABAAADQAAAEAIAAQAJAAAAgIIgKAAg");
	this.shape_55.setTransform(206.4,80.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#1D1D1C").s().p("AAJAOIAAgNQAAgEgJAAQgIAAAAAFIAAAMIgEAAIAAgOIAAgFIAEAAIAAADQAEgDAFAAQAMAAAAAGIAAANgAgIgJQACgEAGABIADABQABAAABAAQAAAAABgBQAAAAAAAAQABAAAAgBIACAAQgBAEgFAAIgFgBQAAAAgBAAQgBAAAAAAQAAAAgBABQAAAAAAAAg");
	this.shape_56.setTransform(202.9,80.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#1D1D1C").s().p("AgOAAQAAgJAOAAQAPAAAAAJIgZAAQAAAIAKAAQAJAAABgFIAFAAQgDAHgMAAQgOAAAAgKgAALAAQgBgHgKAAQgJAAgBAHIAVAAIAAAAg");
	this.shape_57.setTransform(199.1,80.9);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#1D1D1C").s().p("AgMACIAAgLIAEAAIAAALQAAAGAIAAQAJAAAAgHIAAgKIAEAAIAAAOIAAAEIgEAAIAAgCQgEADgFAAQgMAAAAgIg");
	this.shape_58.setTransform(195.3,80.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#1D1D1C").s().p("AALAOIAAgLQgFADgGABQgOgBAAgIQAAgLAOAAQAHAAAEAEIAAgEIAEAAIgBAFIAAAWgAgKgCQABAGAJABQALgBAAgGQAAgJgLAAQgKAAAAAJg");
	this.shape_59.setTransform(191.4,81.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#1D1D1C").s().p("AgOAAQAAgJAOAAQAPAAAAAJIgZAAQABAIAJAAQAJAAABgFIAFAAQgDAHgMAAQgOAAAAgKgAALAAQgBgHgKAAQgIAAgBAHIAUAAIAAAAg");
	this.shape_60.setTransform(187.6,80.9);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#1D1D1C").s().p("AgNAOIAAgWIgBgFIAEAAIABAEQADgEAHAAQAOAAAAALQAAAIgOABQgGgBgEgDIAAALgAgJgCQAAAGAJABQAKgBAAgGQAAgJgKAAQgJAAAAAJg");
	this.shape_61.setTransform(183.8,81.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#1D1D1C").s().p("AgMAEIAEAAQABAEAHAAQAJAAAAgEQAAgCgJgCQgLAAAAgEQAAgFALAAQAMAAAAAFIgEAAQgBgDgHAAQgHAAAAADQAAACAFABIAJABQAGAAAAAEQAAAGgNAAQgMAAAAgGg");
	this.shape_62.setTransform(178.2,80.9);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#1D1D1C").s().p("AgMAEQAAgEAHAAQADgBALAAIAAgCQgBgEgIAAQgGAAAAADIgEAAQABgFAJAAQANAAgBAGIAAAIIABAFIgEAAIAAgDIgBAAQgDADgFAAQgMAAAAgGgAAAAAQgIABABADQAAAEAHAAQAJAAAAgIIgJAAg");
	this.shape_63.setTransform(174.7,80.9);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#1D1D1C").s().p("AgBAOIAAgbIADAAIAAAbg");
	this.shape_64.setTransform(172.3,80.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#1D1D1C").s().p("AgMACIAAgLIAEAAIAAALQAAAGAIAAQAJAAAAgHIAAgKIAEAAIAAAOIAAAEIgEAAIAAgCQgEADgFAAQgMAAAAgIg");
	this.shape_65.setTransform(169.6,80.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#1D1D1C").s().p("AgNAAQAAgJAOAAQANAAAAAHIgFAAQAAgFgJAAQgIAAAAAHQAAAIAIAAQAJAAAAgFIAFAAQgCAHgMAAQgNAAAAgKg");
	this.shape_66.setTransform(166,80.9);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#1D1D1C").s().p("AgOAEQAAgJAOAAQAPAAAAAJIgZAAQAAAIALAAQAIAAACgFIAEAAQgDAHgMAAQgOAAAAgKgAALACQgBgFgKAAQgIAAgCAFIAVAAIAAAAgAgCgHIAEgGIAGAAIgIAGg");
	this.shape_67.setTransform(162.3,80.5);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#1D1D1C").s().p("AAAAOIAAgbIABAAIAAAbg");
	this.shape_68.setTransform(159.7,80.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#1D1D1C").s().p("AgLAHQgEgDAAgEQAAgJAPAAQAHAAAFADQAEADAAADQAAAEgEADQgFADgHAAQgGAAgFgDgAgKAAQAAADADACQADADAEAAQALAAAAgIQAAgHgLAAQgKAAAAAHg");
	this.shape_69.setTransform(157,80.9);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#1D1D1C").s().p("AAVAKIAAgLQAAgGgJAAQgKAAAAAHIAAAKIgCAAIAAgLQAAgGgJAAQgKAAAAAHIAAAKIgFAAIAAgTIAEAAIABAEQADgEAIAAQAIAAABAFQAEgFAIAAQAMAAAAAIIAAALg");
	this.shape_70.setTransform(152,80.9);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#1D1D1C").s().p("AAAAOIAAgbIABAAIAAAbg");
	this.shape_71.setTransform(197.9,67.6);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#1D1D1C").s().p("AgOAAQAAgDAEgDQAEgDAGgBQAPAAAAAKIgZAAQABAJAJgBQAJAAABgEIAFAAQgDAGgMABQgOAAAAgLgAALAAQgBgHgKAAQgIAAgBAHIAUAAIAAAAg");
	this.shape_72.setTransform(195.2,68.1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#1D1D1C").s().p("AgMAJIAEAAQAAADAIAAQAKAAABgGIAAgEIgBAAQgDAEgHAAQgOAAAAgIQAAgLAOAAQAGAAAEAEIABAAIAAgDIAEAAIgBAEIAAALIAAAGQgCADgFABIgHABQgNAAABgFgAgKgCQABAGAJAAQALAAAAgHQAAgDgEgCQgDgDgEAAQgKAAAAAJg");
	this.shape_73.setTransform(191.4,68.4);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#1D1D1C").s().p("AgOAAQAAgJAOgBQAPAAAAAKIgYAAQgBAJAKgBQAJAAABgEIAFAAQgEAGgLABQgOAAAAgLgAAKAAQAAgHgKAAQgJAAAAAHIATAAIAAAAg");
	this.shape_74.setTransform(185.7,68.1);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#1D1D1C").s().p("AgOAEQAAgJAOAAQAGAAAEAEIAAgNIAEAAIAAAYIABAEIgEAAIgBgDQgEAEgGAAQgOAAAAgLgAgJAEQAAAJAJAAQAKAAAAgKQAAgGgKAAQgJAAAAAHg");
	this.shape_75.setTransform(181.8,67.6);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#1D1D1C").s().p("AgMAFIAEAAQAAADAIAAQAJABAAgFQAAgCgJgCQgLAAAAgDQAAgHALAAQALAAABAHIgEAAQgBgEgHAAQgHAAAAAEQAAACAFAAIAJABQAGABAAADQAAAHgNAAQgMgBAAgFg");
	this.shape_76.setTransform(176.3,68.1);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#1D1D1C").s().p("AgMAEQAAgEAHAAQADgBALAAIAAgBQAAgFgJAAQgFAAgBAEIgEAAQABgHAJAAQANAAAAAIIAAAMIgEAAIAAgDIgBAAIAAAAQgCADgHABQgLAAAAgHgAgIAEQABAFAHgBQAJAAAAgIQgRAAAAAEg");
	this.shape_77.setTransform(172.7,68.1);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#1D1D1C").s().p("AAAAOIAAgbIABAAIAAAbg");
	this.shape_78.setTransform(170.4,67.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#1D1D1C").s().p("AgMACIAAgLIAEAAIAAALQAAAGAIAAQAJAAAAgHIAAgKIAEAAIAAASIgEAAIAAgCIAAAAQgEADgFAAQgMAAAAgIg");
	this.shape_79.setTransform(167.7,68.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#1D1D1C").s().p("AgNAAQAAgDAEgDQAEgDAFgBQANAAABAIIgFAAQAAgFgJAAQgIAAAAAHQAAAIAIAAQAIAAABgEIAFAAQgCAGgMABQgNAAAAgLg");
	this.shape_80.setTransform(164.1,68.1);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#1D1D1C").s().p("AgDAOIAAgTIADAAIAAATgAgEgHIAEgGIAFAAIgGAGg");
	this.shape_81.setTransform(161.8,67.7);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#1D1D1C").s().p("AAFANQgFAAAAgCIgBgEIAAgLIgHAAIAAgCIAHAAIAAgFIACgBIAAAGIAIAAIAAACIgIAAIAAAMQAAADAFAAIADgBIAAADg");
	this.shape_82.setTransform(159.6,67.8);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#1D1D1C").s().p("AgGAKIAAgOIgBgEIAFAAIAAADIAAAAQACgDAEgBIAEAAIAAACIgDAAQgGAAgBAHIAAAKg");
	this.shape_83.setTransform(157.5,68);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#1D1D1C").s().p("AgMAEQAAgEAHAAQADgBAKAAIAAgBQAAgFgIAAQgFAAgBAEIgFAAQACgHAJAAQANAAAAAIIAAAMIgEAAIgBgDIAAAAQgCADgHABQgLAAAAgHgAgIAEQABAFAHgBQAJAAgBgIQgQAAAAAEg");
	this.shape_84.setTransform(154.4,68.1);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#1D1D1C").s().p("AgOAOIAAgWIAAgEIAFAAIAAADIAAAAQAEgEAFAAQAPAAAAALQAAAJgOAAQgGAAgEgEIAAAAIAAALgAgJgDQgBAIAKAAQALAAgBgHQAAgJgKAAQgJAAAAAIg");
	this.shape_85.setTransform(150.9,68.4);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#1D1D1C").s().p("AgKAHQgEgDAAgEQAAgDAEgDQAEgDAGgBQAPAAAAAKIgZAAQABAIAJAAQAJAAABgFIAFAAQgDAIgMgBQgGAAgEgDgAALgBQgBgHgKAAQgIAAgBAHIAUAAIAAAAg");
	this.shape_86.setTransform(56.4,7.2);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#1D1D1C").s().p("AAAALQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAgBAAgBIAAgKIgHAAIAAgCIAHAAIAAgFIACgBIAAAGIAIAAIAAACIgIAAIAAALQAAAEAEAAIAEAAIAAACIgEAAQgFAAAAgCg");
	this.shape_87.setTransform(53.3,7);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#1D1D1C").s().p("AAJAKIAAgLQAAgGgJAAQgIAAAAAHIAAAKIgEAAIAAgOIgBgEIAFAAIAAADIABAAQADgEAFAAQAMAAAAAIIAAALg");
	this.shape_88.setTransform(50.3,7.2);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#1D1D1C").s().p("AgKAHQgEgDAAgEQAAgDAEgDQAEgDAGgBQAPAAAAAKIgZAAQABAIAJAAQAJAAABgFIAFAAQgDAIgMgBQgGAAgEgDgAALgBQgBgHgKAAQgIAAgBAHIAUAAIAAAAg");
	this.shape_89.setTransform(46.4,7.2);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#1D1D1C").s().p("AgGAOIAFgIIgOgTIAFAAIAKAQIALgQIAFAAIgRAbg");
	this.shape_90.setTransform(42.8,7.6);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#1D1D1C").s().p("AgMACIAAgLIAEAAIAAALQAAAGAIAAQAJAAAAgHIAAgKIAEAAIAAASIgEAAIAAgDQgEAEgFAAQgMAAAAgIg");
	this.shape_91.setTransform(39.2,7.2);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#1D1D1C").s().p("AAAAOIAAgbIABAAIAAAbg");
	this.shape_92.setTransform(36.5,6.7);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#1D1D1C").s().p("AgOAAQAAgKAOAAQAPAAAAAKIgYAAQAAAIAJAAQAJAAABgFIAFAAQgEAIgLgBQgOAAAAgKgAAKgBQAAgHgKAAQgJAAAAAHIATAAIAAAAg");
	this.shape_93.setTransform(33.8,7.2);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#1D1D1C").ss(0.3,0,0,3.9).p("AJNBgIiTAAAJNH0IjDAAAJNDgIiTAAApHn4IAACd");
	this.shape_94.setTransform(87.8,58.1);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#515E5F").s().p("AgIgEIARAEIgSAFg");
	this.shape_95.setTransform(249.7,55.8);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#515E5F").s().p("AgIAFIAIgJIAJAJg");
	this.shape_96.setTransform(171.8,14.5);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#515E5F").ss(0.5,0,0,3.9).p("AmBjPIAAGaIMIAA");
	this.shape_97.setTransform(210.4,35.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#357D8C").ss(0.2,0,0,3.9).p("AgLgRIgjABQgIABAAAEIAAAXQAAAEAIAAIAkACAAdAUIAaABIAAgoIgZAB");
	this.shape_98.setTransform(126.1,98.8);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#D9D7D7").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_99.setTransform(122.6,98.3);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#EAE8E9").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_100.setTransform(122.6,98.5);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#EAE8E9").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_101.setTransform(122.6,98.3);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#C4C1C1").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_102.setTransform(122.6,98.4);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#9E9C9C").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_103.setTransform(122.6,98.5);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#777A7B").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_104.setTransform(122.6,98.6);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#515E5F").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_105.setTransform(122.6,98.7);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#515E5F").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_106.setTransform(122.6,98.5);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#777A7B").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_107.setTransform(122.6,98.7);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#9E9C9C").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_108.setTransform(122.6,98.8);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#C4C1C1").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_109.setTransform(122.6,98.9);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#EAE8E9").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_110.setTransform(122.6,99);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#EAE8E9").s().p("AgZACIAAgDIAzAAIAAADg");
	this.shape_111.setTransform(122.6,99.1);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#EAE8E9").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_112.setTransform(122.6,99.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#CFCCCC").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_113.setTransform(122.6,99.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#B4B1B1").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_114.setTransform(122.6,99.3);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#989797").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_115.setTransform(122.6,99.5);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#7D7F7F").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_116.setTransform(122.6,99.4);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#717677").s().p("AgZAAIAAAAIAzAAIAAAAg");
	this.shape_117.setTransform(122.6,99.5);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#357D8C").ss(0.2,0,0,3.9).p("AAdAUIAaABIAAgoIgZABAgLgRIgjABQgIABAAAEIAAAXQAAAEAIAAIAkAC");
	this.shape_118.setTransform(77.9,98.8);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#CAC7C7").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_119.setTransform(74.3,98.2);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#D9D7D7").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_120.setTransform(74.3,98.3);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#EAE8E9").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_121.setTransform(74.3,98.5);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#EAE8E9").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_122.setTransform(74.3,98.3);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#C4C1C1").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_123.setTransform(74.3,98.4);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#9E9C9C").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_124.setTransform(74.3,98.5);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#777A7B").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_125.setTransform(74.3,98.6);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#515E5F").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_126.setTransform(74.3,98.7);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#515E5F").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_127.setTransform(74.3,98.5);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#777A7B").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_128.setTransform(74.3,98.7);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#9E9C9C").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_129.setTransform(74.3,98.8);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#C4C1C1").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_130.setTransform(74.3,98.9);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#EAE8E9").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_131.setTransform(74.3,99);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#EAE8E9").s().p("AgYACIAAgDIAyAAIAAADg");
	this.shape_132.setTransform(74.3,99.1);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#EAE8E9").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_133.setTransform(74.3,99.1);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#CFCCCC").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_134.setTransform(74.3,99.2);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#B4B1B1").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_135.setTransform(74.3,99.3);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#989797").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_136.setTransform(74.3,99.5);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#7D7F7F").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_137.setTransform(74.3,99.4);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#717677").s().p("AgYAAIAAAAIAyAAIAAAAg");
	this.shape_138.setTransform(74.3,99.5);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f().s("#357D8C").ss(0.2,0,0,3.9).p("AAdAUIAaABIAAgoIgZABAgLgRIgjABQgIABAAAEIAAAXQAAAEAIAAIAkAC");
	this.shape_139.setTransform(29.6,98.8);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#D9D7D7").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_140.setTransform(26.1,98.3);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#EAE8E9").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_141.setTransform(26.1,98.5);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#EAE8E9").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_142.setTransform(26.1,98.3);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#C4C1C1").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_143.setTransform(26.1,98.4);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#9E9C9C").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_144.setTransform(26.1,98.5);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#777A7B").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_145.setTransform(26.1,98.6);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#515E5F").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_146.setTransform(26.1,98.7);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#515E5F").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_147.setTransform(26.1,98.5);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#777A7B").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_148.setTransform(26.1,98.7);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#9E9C9C").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_149.setTransform(26.1,98.8);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#C4C1C1").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_150.setTransform(26.1,98.9);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#EAE8E9").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_151.setTransform(26.1,99);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#EAE8E9").s().p("AgZACIAAgDIAyAAIAAADg");
	this.shape_152.setTransform(26.1,99.1);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#EAE8E9").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_153.setTransform(26.1,99.1);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#CFCCCC").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_154.setTransform(26.1,99.2);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#B4B1B1").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_155.setTransform(26.1,99.3);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#989797").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_156.setTransform(26.1,99.5);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#717677").s().p("AgZAAIAAAAIAyAAIAAAAg");
	this.shape_157.setTransform(26.1,99.5);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#E33E20").s().p("Ah4BWQATgBANgVQAKgQATgwQASguALgRQAOgVAQgBQASABAPAVQALARASAuQATAyAIAOQANAVATABg");
	this.shape_158.setTransform(192.3,47.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text},{t:this.instance}]}).to({state:[{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape},{t:this.text},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-14.5,272,217.7);


(lib.btn_thomson = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_thomson'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 217;
	this.text.setTransform(110.5,3.5+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-112.5,-15,225,30,6);
	this.shape.setTransform(112.5,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#1D1D1B").rr(-112.5,-15,225,30,6);
	this.shape_1.setTransform(112.5,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").rr(-112.5,-15,225,30,6);
	this.shape_2.setTransform(112.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,225,30);


(lib.btn_rutherford = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_ruther'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 220;
	this.text.setTransform(110.2,3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-112.5,-15,225,30,6);
	this.shape.setTransform(112.5,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#1D1D1B").rr(-112.5,-15,225,30,6);
	this.shape_1.setTransform(112.5,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").rr(-112.5,-15,225,30,6);
	this.shape_2.setTransform(112.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,225,30);


(lib.btn_dalton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_dalton'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 219;
	this.text.setTransform(110.2,3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-112.5,-15,225,30,6);
	this.shape.setTransform(112.5,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#1D1D1B").rr(-112.5,-15,225,30,6);
	this.shape_1.setTransform(112.5,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").rr(-112.5,-15,225,30,6);
	this.shape_2.setTransform(112.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,225,30);


(lib.btn_bohr = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_bohr'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 219;
	this.text.setTransform(110.2,3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-112.5,-15,225,30,6);
	this.shape.setTransform(112.5,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#1D1D1B").rr(-112.5,-15,225,30,6);
	this.shape_1.setTransform(112.5,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").rr(-112.5,-15,225,30,6);
	this.shape_2.setTransform(112.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,225,30);


(lib.btn_solido = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['btn_solid'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 21;
	this.text.lineWidth = 268;
	this.text.setTransform(134.3,170+incremento);

	this.instance = new lib._101198713();

	this.addChild(this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,273,193.4);


(lib.btn_plasma = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['btn_plasma'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 21;
	this.text.lineWidth = 267;
	this.text.setTransform(133.9,168.4+incremento);

	this.instance = new lib._0014IL01();

	this.addChild(this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,273,191.9);


(lib.btn_liquido = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['btn_liquid'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 21;
	this.text.lineWidth = 268;
	this.text.setTransform(134.4,169+incremento);

	this.instance = new lib._0017W101();

	this.addChild(this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,273,192.5);


(lib.btn_gas = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['btn_gas'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 21;
	this.text.lineWidth = 268;
	this.text.setTransform(134.3,169.4+incremento);

	this.instance = new lib._002AD301();

	this.addChild(this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,273,192.9);


(lib.btn_mezclas = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_mexclas'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 21;
	this.text.lineWidth = 257;
	this.text.setTransform(129.8,5.5+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-131.3,-29.7,262.6,59.4,6);
	this.shape.setTransform(131.7,29.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-131.3,-29.7,262.6,59.4,6);
	this.shape_1.setTransform(131.7,29.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-131.3,-29.7,262.6,59.4,6);
	this.shape_2.setTransform(131.7,29.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s("#666666").ss(1,1,1).rr(-131.3,-29.7,262.6,59.4,6);
	this.shape_3.setTransform(131.7,29.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape_3},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.4,-0.1,262.6,59.4);


(lib.btn_estados = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_estados'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 21;
	this.text.lineWidth = 146;
	this.text.setTransform(74.1,3.7+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-75.45,-28.75,150.9,57.5,6);
	this.shape.setTransform(76.3,28.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-75.45,-28.75,150.9,57.5,6);
	this.shape_1.setTransform(76.3,28.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-75.45,-28.75,150.9,57.5,6);
	this.shape_2.setTransform(76.3,28.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.9,-0.4,150.9,57.5);


(lib.btn_atomo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_atomo'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 21;
	this.text.lineWidth = 144;
	this.text.setTransform(74.2,4+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-75.45,-28.75,150.9,57.5,6);
	this.shape.setTransform(76.3,28.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-75.45,-28.75,150.9,57.5,6);
	this.shape_1.setTransform(76.3,28.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-75.45,-28.75,150.9,57.5,6);
	this.shape_2.setTransform(76.3,28.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.9,-0.4,150.9,57.5);


(lib.popup_filtracion = function() {
	this.initialize();

	// FlashAICB
	this.instance = new lib.Mapadebits10();
	this.instance.setTransform(76.7,149.8);

	this.text = new cjs.Text(txt['txt_filt_1'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 426;
	this.text.setTransform(454,297);
   var html = createDiv(txt['txt_filt_1'], "Verdana", "20px", '430px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(454,297 -608);



	this.addChild(this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_evaporacion = function() {
	this.initialize();

	// FlashAICB
	this.instance = new lib.Mapadebits9();
	this.instance.setTransform(71.4,147.6);

	this.text = new cjs.Text(txt['txt_evap_1'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 459;
	this.text.setTransform(367,309);
   var html = createDiv(txt['txt_evap_1'], "Verdana", "20px", '460px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(367,309 -608);


	this.addChild(this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_destilacion = function() {
	this.initialize();

	// FlashAICB
	this.instance = new lib.Mapadebits8();
	this.instance.setTransform(80,175.1);

	this.text = new cjs.Text(txt['txt_dest_1'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 267;
	this.text.setTransform(621,246);
   var html = createDiv(txt['txt_dest_1'], "Verdana", "20px", '270px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(621,246 -608);
 
	
	this.addChild(this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_decantacion = function() {
	this.initialize();

	// FlashAICB
	this.instance = new lib.Mapadebits7();
	this.instance.setTransform(122.6,148.2);

	this.text = new cjs.Text(txt['txt_decant_1'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 387;
	this.text.setTransform(399,271);
   var html = createDiv(txt['txt_decant_1'], "Verdana", "20px", '390px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(399,271 -608);

	this.addChild(this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_cromatografia = function() {
	this.initialize();

	// FlashAICB
	this.instance = new lib.Mapadebits6();
	this.instance.setTransform(82,152.3);

	this.text = new cjs.Text(txt['txt_cromo_1'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 379;
	this.text.setTransform(539,271);
   var html = createDiv(txt['txt_cromo_1'], "Verdana", "20px", '380px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(539,271 -608);


	this.addChild(this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_centrifugacion = function() {
	this.initialize();

	// FlashAICB
	this.instance = new lib.Mapadebits5();
	this.instance.setTransform(81.8,110);

	this.text = new cjs.Text(txt['txt_centr_1'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 392;
	this.text.setTransform(490,285);
   var html = createDiv(txt['txt_centr_1'], "Verdana", "20px", '390px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(490,285 -608);

	this.addChild(this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_thomson = function() {
	this.initialize();

	// Txt
	this.text = new cjs.Text(txt['txt_thomson_3'], "20px Verdana");
	this.text.lineHeight = 25;
	this.text.lineWidth = 350;
	this.text.setTransform(462,281.2);

	// FlashAICB
	this.instance = new lib.Mapadebits4();
	this.instance.setTransform(202.1,210);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AAAJXIAAyt");
	this.shape.setTransform(214.5,485.9,1,0.425,90);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,0,0,4).p("AAAJXIAAyt");
	this.shape_1.setTransform(239,450.9,1,0.59);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,0,0,4).p("AAAJXIAAyt");
	this.shape_2.setTransform(331,300);

	this.text_1 = new cjs.Text(txt['txt_thomson_2'], "20px Verdana", "#1D1D1C");
	this.text_1.lineHeight = 25;
	this.text_1.setTransform(102.8,469.6);

	this.text_2 = new cjs.Text(txt['txt_thomson_1'], "20px Verdana", "#1D1D1C");
	this.text_2.lineHeight = 25;
	this.text_2.setTransform(246.9,180.1);

	
	this.addChild(this.text_2,this.text_1,this.shape_2,this.shape_1,this.shape,this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_rutherford = function() {
	this.initialize();

	// Txt
	this.text = new cjs.Text(txt['txt_ruther_5'], "20px Verdana");
	this.text.lineHeight = 25;
	this.text.lineWidth = 385;
	this.text.setTransform(462,281.2);

	// FlashAICB
	this.instance = new lib.Mapadebits3();
	this.instance.setTransform(82.2,217.1);

	this.text_1 = new cjs.Text(txt['txt_ruther_4'], "20px Verdana", "#1D1D1C");
	this.text_1.lineHeight = 25;
	this.text_1.setTransform(371.9,493.8);

	this.text_2 = new cjs.Text(txt['txt_ruther_3'], "20px Verdana", "#1D1D1C");
	this.text_2.lineHeight = 25;
	this.text_2.setTransform(328.5,410.2);

	this.text_3 = new cjs.Text(txt['txt_ruther_2'], "20px Verdana", "#1D1D1C");
	this.text_3.lineHeight = 25;
	this.text_3.setTransform(218.3,157.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AmZj9IMzH7");
	this.shape.setTransform(328.4,483.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,0,0,4).p("AAAJXIAAyt");
	this.shape_1.setTransform(337.6,374,1,0.649,0,0,0,0,-0.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,0,0,4).p("AAAJXIAAyt");
	this.shape_2.setTransform(302.7,336,1,0.59,-89.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,0,0,4).p("AAAJXIAAyt");
	this.shape_3.setTransform(130,492.7,1,0.425,0,-89.9,90,0,-0.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,0,0,4).p("AAAJXIAAyt");
	this.shape_4.setTransform(105.6,457.8,1,0.59,0,0,180);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,0,0,4).p("AAAJXIAAyt");
	this.shape_5.setTransform(252.7,246.7);

	this.text_4 = new cjs.Text(txt['txt_ruther_1'], "20px Verdana", "#1D1D1C");
	this.text_4.lineHeight = 25;
	this.text_4.setTransform(160.6,475.7);

	
	this.addChild(this.text_4,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_3,this.text_2,this.text_1,this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_dalton = function() {
	this.initialize();

	// Txt
	this.text = new cjs.Text(txt['txt_dalton_4'], "20px Verdana");
	this.text.lineHeight = 23;
	this.text.lineWidth = 283;
	this.text.setTransform(572.4,298);

	// FlashAICB
	this.instance = new lib.Mapadebits2();
	this.instance.setTransform(69.8,260);

	this.text_1 = new cjs.Text(txt['txt_dalton_3'], "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 23;
	this.text_1.lineWidth = 117;
	this.text_1.setTransform(449.6,192.3);

	this.text_2 = new cjs.Text(txt['txt_dalton_2'], "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 23;
	this.text_2.lineWidth = 112;
	this.text_2.setTransform(301,192.3);

	this.text_3 = new cjs.Text(txt['txt_dalton_1'], "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 23;
	this.text_3.lineWidth = 122;
	this.text_3.setTransform(155.2,192.3);

	
	this.text_4 = new cjs.Text(txt['txt_dalton'], "30px Verdana");
	this.text_4.lineHeight = 32;
	this.text_4.lineWidth = 783;
	this.text_4.setTransform(77.6,65.1);

	
	this.addChild(this.text_3,this.text_2,this.text_1,this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_bohr = function() {
	this.initialize();

	// Txt
	this.text = new cjs.Text(txt['txt_bohr_3'], "bold 16px Verdana");
	this.text.lineHeight = 21;
	this.text.lineWidth = 422;
	this.text.setTransform(153,316.7);

	this.text_1 = new cjs.Text(txt['txt_bohr_2'], "bold 16px Verdana");
	this.text_1.lineHeight = 21;
	this.text_1.lineWidth = 328;
	this.text_1.setTransform(153.1,147.1);

	this.text_2 = new cjs.Text(txt['txt_bohr_1'], "20px Verdana");
	this.text_2.lineHeight = 25;
	this.text_2.lineWidth = 740;
	this.text_2.setTransform(82.7,498.5);

	// FlashAICB
	this.instance = new lib.Mapadebits1();
	this.instance.setTransform(189,183.7);


	this.addChild(this.instance,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_solido = function() {
	this.initialize();

	// Imatge
	this.instance = new lib._101198713_1();
	this.instance.setTransform(82,151);

	// PastillaColor
	this.text = new cjs.Text(txt['txt_solid'], "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 479;
	this.text.setTransform(407.7,301.6);
    var html = createDiv(txt['txt_solid'], "Verdana", "20px", '480px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(407, 301-608);


	this.text_1 = new cjs.Text(txt['tit_solid'], "30px Verdana");
	this.text_1.lineHeight = 32;
	this.text_1.lineWidth = 783;
	this.text_1.setTransform(81.6,65.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(31,138,178,0.298)").s().p("EhKNAdYMAAAg6uMCUbAAAMAAAA6ug");
	this.shape.setTransform(475,339);


	this.addChild(this.shape,this.btn_salir,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_practica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Botons
	
	// Txt
	this.text = new cjs.Text(txt['tit_completa'], "23px Verdana");
	this.text.lineHeight = 25;
	this.text.lineWidth = 783;
	this.text.setTransform(81.6,68.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{text:"Completa la tabla"}}]}).to({state:[{t:this.text,p:{text:"Estados de la materia"}}]},1).wait(1));

	// Tabla
	this.text_1 = new cjs.Text(txt['txt_tabla_4'], "bold 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(725.4,198);

	this.text_2 = new cjs.Text(txt['txt_tabla_3'], "bold 20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(567.9,198);

	this.text_3 = new cjs.Text(txt['txt_tabla_2'], "bold 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(273.8,198);

	this.text_4 = new cjs.Text(txt['txt_tabla_1'], "bold 20px Verdana");
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(133.9,198);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").p("AAADdIAAm5");
	this.shape.setTransform(690.5,396.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").p("AtgAAIbBAA");
	this.shape_1.setTransform(777,373.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").p("AAADdIAAm5");
	this.shape_2.setTransform(520.5,396.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").p("AtRAAIajAA");
	this.shape_3.setTransform(605.5,373.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").p("AAADdIAAm5");
	this.shape_4.setTransform(259.5,396.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").p("A0YAAMAoxAAA");
	this.shape_5.setTransform(390,373.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").p("AtbAAIa3AA");
	this.shape_6.setTransform(173.5,373.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").p("AAADdIAAm5");
	this.shape_7.setTransform(690.5,351.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").p("AtgAAIbBAA");
	this.shape_8.setTransform(777,328.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").p("AAADdIAAm5");
	this.shape_9.setTransform(520.5,351.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").p("AtRAAIajAA");
	this.shape_10.setTransform(605.5,328.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").p("AAADdIAAm5");
	this.shape_11.setTransform(259.5,351.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").p("A0YAAMAoxAAA");
	this.shape_12.setTransform(390,328.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").p("AtbAAIa3AA");
	this.shape_13.setTransform(173.5,328.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").p("AAADdIAAm5");
	this.shape_14.setTransform(690.5,305.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").p("AtgAAIbBAA");
	this.shape_15.setTransform(777,283.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").p("AAADdIAAm5");
	this.shape_16.setTransform(520.5,305.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").p("AtRAAIajAA");
	this.shape_17.setTransform(605.5,283.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").p("AAADdIAAm5");
	this.shape_18.setTransform(259.5,305.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").p("A0YAAMAoxAAA");
	this.shape_19.setTransform(390,283.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").p("AtbAAIa3AA");
	this.shape_20.setTransform(173.5,283.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").p("AAADdIAAm5");
	this.shape_21.setTransform(690.5,260.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").p("AAADdIAAm5");
	this.shape_22.setTransform(520.5,260.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").p("AAADdIAAm5");
	this.shape_23.setTransform(259.5,260.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s("#1D1D1B").rr(-388.2,-90.25,776.4,180.5,10);
	this.shape_24.setTransform(475.4,328.2);

	this.text_5 = new cjs.Text(txt['txt_tabla_5'], "20px Verdana");
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(734.5,336.9+incremento);

	this.text_6 = new cjs.Text(txt['txt_tabla_5'], "20px Verdana");
	this.text_6.lineHeight = 20;
	this.text_6.setTransform(563.2,336.9+incremento);

	this.text_7 = new cjs.Text(txt['txt_tabla_6'], "20px Verdana");
	this.text_7.lineHeight = 20;
	this.text_7.setTransform(346.6,336.9+incremento);

	this.text_8 = new cjs.Text(txt['txt_tabla_7'], "20px Verdana");
	this.text_8.lineHeight = 20;
	this.text_8.setTransform(152.8,336.9+incremento);

	this.text_9 = new cjs.Text(txt['txt_tabla_8'], "20px Verdana");
	this.text_9.lineHeight = 20;
	this.text_9.setTransform(724,291.6+incremento);

	this.text_10 = new cjs.Text(txt['txt_tabla_5'], "20px Verdana");
	this.text_10.lineHeight = 20;
	this.text_10.setTransform(563.2,291.6+incremento);

	this.text_11 = new cjs.Text(txt['txt_tabla_9'], "20px Verdana");
	this.text_11.lineHeight = 20;
	this.text_11.setTransform(362.6,291.6+incremento);

	this.text_12 = new cjs.Text(txt['txt_tabla_10'], "20px Verdana");
	this.text_12.lineHeight = 20;
	this.text_12.setTransform(135.8,291.6+incremento);

	this.text_13 = new cjs.Text(txt['txt_tabla_8'], "20px Verdana");
	this.text_13.lineHeight = 20;
	this.text_13.setTransform(724,246.3+incremento);

	this.text_14 = new cjs.Text(txt['txt_tabla_8'], "20px Verdana");
	this.text_14.lineHeight = 20;
	this.text_14.setTransform(552.7,246.3+incremento);

	this.text_15 = new cjs.Text(txt['txt_tabla_11'], "20px Verdana");
	this.text_15.lineHeight = 20;
	this.text_15.setTransform(355.8,246.3+incremento);

	this.text_16 = new cjs.Text(txt['txt_tabla_12'], "20px Verdana");
	this.text_16.lineHeight = 20;
	this.text_16.setTransform(141.1,246.3+incremento);

	this.text_17 = new cjs.Text(txt['txt_tabla_4'], "bold 20px Verdana");
	this.text_17.lineHeight = 20;
	this.text_17.setTransform(725.4,198);

	this.text_18 = new cjs.Text(txt['txt_tabla_3'], "bold 20px Verdana");
	this.text_18.lineHeight = 20;
	this.text_18.setTransform(567.9,198);

	this.text_19 = new cjs.Text(txt['txt_tabla_2'], "bold 20px Verdana");
	this.text_19.lineHeight = 20;
	this.text_19.setTransform(273.8,198);

	this.text_20 = new cjs.Text(txt['txt_tabla_1'], "bold 20px Verdana");
	this.text_20.lineHeight = 20;
	this.text_20.setTransform(133.9,198);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1}]}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4,p:{x:136,y:382.2,text:"Plasma",font:"20px Verdana",lineWidth:72}},{t:this.text_3,p:{x:346.6,y:382.2,text:"Ninguna",font:"20px Verdana",lineWidth:83}},{t:this.text_2,p:{x:563.2,y:382.2,text:"Variable",font:"20px Verdana",lineWidth:81}},{t:this.text_1,p:{x:734.5,y:382.2,text:"Variable",font:"20px Verdana",lineWidth:81}}]},1).wait(1));

	// PastillaBlanca
	this.shape_25 = new cjs.Shape();
	
	this.shape_25.setTransform(475,304,0.998,0.999);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25}]}).to({state:[{t:this.shape_25}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_plasma = function() {
	this.initialize();

	// Imatge
	this.instance = new lib._0014IL01_1();
	this.instance.setTransform(82,151);

	// PastillaColor
	this.text = new cjs.Text(txt['txt_plasma'], "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 479;
	this.text.setTransform(414,289.6);
 var html = createDiv(txt['txt_plasma'], "Verdana", "20px", '480px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(414, 289-608);

	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.7,54.4);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.text_1 = new cjs.Text(txt['tit_plasma'], "30px Verdana");
	this.text_1.lineHeight = 32;
	this.text_1.lineWidth = 783;
	this.text_1.setTransform(81.6,65.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(182,1,15,0.298)").s().p("EhKNAdYMAAAg6uMCUbAAAMAAAA6ug");
	this.shape.setTransform(475,339);

	// PastillaBlanca
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhKYAvkMAAAhfHMCUxAAAMAAABfHg");
	this.shape_1.setTransform(475,304,0.998,0.999);

	this.addChild(this.shape,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_liquido = function() {
	this.initialize();

	// Imatge
	this.instance = new lib._0017W101_1();
	this.instance.setTransform(82,151);

	// PastillaColor
	this.text = new cjs.Text(txt['txt_liquid'], "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 479;
	this.text.setTransform(414,301.6);
  var html = createDiv(txt['txt_liquid'], "Verdana", "20px", '480px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(414, 301-608);

	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.7,54.4);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.text_1 = new cjs.Text(txt['tit_liquid'], "30px Verdana");
	this.text_1.lineHeight = 32;
	this.text_1.lineWidth = 783;
	this.text_1.setTransform(81.6,65.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(15,127,17,0.298)").s().p("EhKNAdYMAAAg6uMCUbAAAMAAAA6ug");
	this.shape.setTransform(475,339);

	// PastillaBlanca
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhKYAvkMAAAhfHMCUxAAAMAAABfHg");
	this.shape_1.setTransform(475,304,0.998,0.999);

	this.addChild(this.shape,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_gas = function() {
	this.initialize();

	// Imatge
	this.instance = new lib._002AD301_1();
	this.instance.setTransform(82,151);

	// PastillaColor
	this.text = new cjs.Text(txt['txt_gas'], "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 401;
	this.text.setTransform(414.7,289.6);
  var html = createDiv(txt['txt_gas'], "Verdana", "20px", '480px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(414, 289-608);

	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.7,54.4);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.text_1 = new cjs.Text(txt['tit_gas'], "30px Verdana");
	this.text_1.lineHeight = 32;
	this.text_1.lineWidth = 783;
	this.text_1.setTransform(81.6,65.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(127,9,126,0.298)").s().p("EhKNAdYMAAAg6uMCUbAAAMAAAA6ug");
	this.shape.setTransform(475,339);

	// PastillaBlanca
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhKYAvkMAAAhfHMCUxAAAMAAABfHg");
	this.shape_1.setTransform(475,304,0.998,0.999);

	this.addChild(this.shape,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);

 

    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}