(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0, 0);
        titulo1(this, txt['titulo']);
        this.linia = new lib.pisos("single", tipo);
        this.linia.setTransform(607.8, 330.5, 0.904, 0.904);
        this.linia.alpha = 0.949;
        this.linia2 = new lib.carretera3("single", tipo);

        this.linia2.setTransform(910+940, 0);
        this.cot = new lib.cotxecau("single", 0);
        this.cot.setTransform(345, 390, 1.034, 1.034);

        this.shape0 = new cjs.Shape();
        this.shape0.graphics.f("#CCCCCC").s().p("EgySAZ6MAAAgzyMBklAAAMAAAAzyg");
        this.shape0.setTransform(468.5, 273);
        this.linia.mask = this.linia2.mask = this.shape0;

        var html = createHTML('Pavimento: <input type="radio" id="seco" onclick="pavimento(0)" name="pavimento" value="seco" ' + (tipo == 0 ? "checked" : "") + '><label for="seco"><b>Seco</b></label><input id="mojado" type="radio" onclick="pavimento(2)" name="pavimento" value="mojado"' + (tipo == 2 ? "checked" : "") + '><label for="mojado"><b>Mojado</b></label><input onclick="pavimento(1)" id="helado" type="radio" name="pavimento" value="helado"' + (tipo == 1 ? "checked" : "") + '><label for="helado"><b>Helado</b></label>', "400px", '40px', "radio");
        this.radios = new cjs.DOMElement(html);
        this.radios.setTransform(155, 440 - 608);

        var html = createHTML('Velocidad inicial: <input type="text" id="velocidad" value="0" size="4" > Km/h', "400px", '40px', "radio");
        this.velocidad = new cjs.DOMElement(html);
        this.velocidad.setTransform(525, 440 - 608);

        var html = createHTML('<center><span style="display:none" class="naranja" id="limites"><b>La velocidad debe estar comprendida entre 1 y 131 km/h.</b></span></center>', "500px", '40px', "radio");
        this.limites = new cjs.DOMElement(html);
        this.limites.setTransform(225, 474 - 608);

        this.instance = new lib.Mapadebits2();
        this.instance.setTransform(149.8, 497.5);

        this.instance_1 = new lib.Mapadebits1();
        this.instance_1.setTransform(149.8, 473.5);
        this.punt = new lib.puntmapa("single", 0);
        this.punt.setTransform(170.7, 522.8);

        this.text = new cjs.Text("200m", "14px Verdana");
        this.text.lineHeight = 16;
        this.text.setTransform(199.6, 526.9);
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AHjAGIAAhNIArAAIAACQIgrAAIAAhDIvwAA");
        this.shape.setTransform(224.3, 523.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#666666").ss(1, 1, 1, 3, true).p("Aj8AAIkEAAIAgALAoEAAIAEAAIAggOADvAAIESAAIgggKAIFAAIgEAAIggAP");
        this.shape_1.setTransform(222.5, 538.4);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FF0000").s().p("AgUBKIAAgDIApAAIAAADgAAVBHgAgUBHIAAhDIAAhNIApAAIAACQg");
        this.shape_2.setTransform(274.8, 524);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("rgba(7,137,180,0.4)").s().p("A6GDUQgjAAgbgPQgMgGgKgJQgNgLgJgOQgEgGgCgHQgGgPAAgRIAAgtIABAAIgBgPIAAgtIABAAIgBgNIAAgtIAAgFIAAhBIAAAAQACgMAEgKQACgHAEgGQAEgIAIgHIAKgKQAjgeAxAAMA0NAAAQAxAAAiAeIAMAKQAGAHAFAIQAKAQACATIAAAAIAABBIAAAFIAAAtIgBANIABAAIAAAtIgBAPIABAAIAAAtQAAAYgMAVQgHAKgJAKIgHAFQgKAJgKAGQgcAPgjAAg");
        this.shape_3.setTransform(329.2, 530.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("rgba(7,137,180,0.4)").s().p("Aw+DUQgoAAghgPQgNgGgLgJQgQgLgKgOQgFgGgCgHQgHgPAAgRIAAgtIABAAIgBgPIAAgtIABAAIgBgNIAAgtIAAgFIAAhBIAAAAQACgMAFgKQACgHAFgGQAFgIAIgHIANgKQAogeA5AAMAh8AAAQA6AAAoAeIANAKQAHAHAGAIQALAQACATIABAAIAABBIAAAFIAAAtQAAAGgBAHIABAAIAAAtQAAAHgBAIIABAAIAAAtQAAAYgOAVQgIAKgLAKIgHAFQgMAJgNAGQggAPgpAAg");
        this.shape_4.setTransform(655.7, 530.7);
        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("rgba(7,137,180,0.4)").ss(1, 1, 1).p("EAyPgBlIAADLEgyOgBlIAADLABfhlIAADL");
        this.shape_5.setTransform(468.8, 452.2);

 var html = createHTML('Distancia recorrida: <b><span id="metros">&nbsp;&nbsp;&nbsp;&nbsp;</span></b> m', "400px", '40px', "distancia");
        this.distancia = new cjs.DOMElement(html);
        this.distancia.setTransform(300, 520 - 608);

        var html = createHTML('Tiempo de frenada: <b><span id="segundos">&nbsp;&nbsp;&nbsp;&nbsp;</span></b> s', "400px", '40px', "tiempo");
        this.tiempo = new cjs.DOMElement(html);
        this.tiempo.setTransform(560, 520 - 608);
        
        if (tipo == 2) {
            this.pluja = new lib.pluja();
            this.pluja.setTransform(514.9, 332.3, 0.73, 0.73);
            this.pluja.mask = this.shape0;

        }
        this.instance3 = new lib.cuadrobotcA();
        this.instance3.setTransform(476.8, 570.2);
        new cjs.ButtonHelper(this.instance3, 0, 1, 2, false, new lib.cuadrobotcA(), 3);
        this.instance3.on("click", function (evt) {
            var vel = document.getElementById("velocidad").value;
            if (vel < 1 || vel > 130) {
                document.getElementById("limites").style.display = "";
                return;
            }
            else {
                document.getElementById("limites").style.display = "none";
                putStage(new lib.frame2(vel))
            }
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior, this.home, this.informacion, this.cerrar, this.linia, this.linia2, this.cot, this.radios, this.instance, this.instance_1, this.text, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape, this.punt, this.shape_7, this.shape_6, this.shape_5, this.velocidad, this.pluja, this.instance3, this.limites,this.distancia, this.tiempo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function (vel) {
        this.initialize();
        clearTexts();
        var clock = new Date();
        var parar = false;
        var tiempo = vel / 12;
        if (tipo == 2)
            tiempo = vel / 7.27;
        if (tipo == 1)
            tiempo = vel / 1.8;
        tiempo = Math.round(tiempo * 100) / 100;
        var distancia = vel * vel / 85;
        if (tipo == 2)
            distancia = vel * vel / 51;
        if (tipo == 1)
            distancia = vel * vel / 12.9;
        distancia = Math.round(distancia);
//        console.log(tiempo + "|" + distancia);
        // Capa 1
        basicos(this, 0, 0, 0, 0, 0, 0);
        titulo1(this, txt['titulo']);
        this.linia = new lib.pisos("single", tipo);
        this.linia.setTransform(607.8, 330.5, 0.904, 0.904);
            this.linia = new lib.moveElement3(this.linia, distancia, tiempo);
        
        this.linia.alpha = 0.949;
        this.linia2 = new lib.carretera3("single", tipo);

        this.linia2.setTransform(910+940, 0);
        this.linia2 = new lib.moveElement2(this.linia2, distancia, tiempo);

        this.cot = new lib.cotxecau("single", 0);
        this.cot.setTransform(345, 390, 1.034, 1.034);

        this.shape0 = new cjs.Shape();
        this.shape0.graphics.f("#CCCCCC").s().p("EgySAZ6MAAAgzyMBklAAAMAAAAzyg");
        this.shape0.setTransform(468.5, 273);
        this.linia.mask = this.linia2.mask = this.shape0;

        var html = createHTML('Pavimento: <input disabled type="radio" onclick="pavimento(0)" name="pavimento" value="seco" ' + (tipo == 0 ? "checked" : "") + '><label for="seco"><b>Seco</b></label><input disabled type="radio" onclick="pavimento(2)" name="pavimento" value="mojado"' + (tipo == 2 ? "checked" : "") + '><b>Mojado</b><input disabled onclick="pavimento(1)" type="radio" name="pavimento" value="helado"' + (tipo == 1 ? "checked" : "") + '><b>Helado</b>', "400px", '40px', "radio");
        this.radios = new cjs.DOMElement(html);
        this.radios.setTransform(155, 440 - 608);

        var html = createHTML('Velocidad inicial: <input disabled type="text" id="velocidad" value="' + vel + '" size="4" > Km/h', "400px", '40px', "radio");
        this.velocidad = new cjs.DOMElement(html);
        this.velocidad.setTransform(525, 440 - 608);

        var html = createHTML('<center><span style="display:none" class="naranja" id="limites"><b>La velocidad debe estar comprendida entre 1 y 130</b></span></center>', "500px", '40px', "radio");
        this.limites = new cjs.DOMElement(html);
        this.limites.setTransform(225, 474 - 608);

        var html = createHTML('Distancia recorrida: <b><span id="metros"></span></b> m', "400px", '40px', "distancia");
        this.distancia = new cjs.DOMElement(html);
        this.distancia.setTransform(300, 520 - 608);

        var html = createHTML('Tiempo de frenada: <b><span id="segundos"></span></b> s', "400px", '40px', "tiempo");
        this.tiempo = new cjs.DOMElement(html);
        this.tiempo.setTransform(560, 520 - 608);


        this.instance = new lib.Mapadebits2();
        this.instance.setTransform(149.8, 497.5);

        this.instance_1 = new lib.Mapadebits1();
        this.instance_1.setTransform(149.8, 473.5);

        this.punt = new lib.puntmapa("single", 0);
        this.punt.setTransform(170.7, 522.8);
        this.punt = new lib.moveElement(this.punt, distancia, tiempo);

        this.text = new cjs.Text("200m", "14px Verdana");
        this.text.lineHeight = 16;
        this.text.setTransform(199.6, 526.9);
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AHjAGIAAhNIArAAIAACQIgrAAIAAhDIvwAA");
        this.shape.setTransform(224.3, 523.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#666666").ss(1, 1, 1, 3, true).p("Aj8AAIkEAAIAgALAoEAAIAEAAIAggOADvAAIESAAIgggKAIFAAIgEAAIggAP");
        this.shape_1.setTransform(222.5, 538.4);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FF0000").s().p("AgUBKIAAgDIApAAIAAADgAAVBHgAgUBHIAAhDIAAhNIApAAIAACQg");
        this.shape_2.setTransform(274.8, 524);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("rgba(7,137,180,0.4)").s().p("A6GDUQgjAAgbgPQgMgGgKgJQgNgLgJgOQgEgGgCgHQgGgPAAgRIAAgtIABAAIgBgPIAAgtIABAAIgBgNIAAgtIAAgFIAAhBIAAAAQACgMAEgKQACgHAEgGQAEgIAIgHIAKgKQAjgeAxAAMA0NAAAQAxAAAiAeIAMAKQAGAHAFAIQAKAQACATIAAAAIAABBIAAAFIAAAtIgBANIABAAIAAAtIgBAPIABAAIAAAtQAAAYgMAVQgHAKgJAKIgHAFQgKAJgKAGQgcAPgjAAg");
        this.shape_3.setTransform(329.2, 530.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("rgba(7,137,180,0.4)").s().p("Aw+DUQgoAAghgPQgNgGgLgJQgQgLgKgOQgFgGgCgHQgHgPAAgRIAAgtIABAAIgBgPIAAgtIABAAIgBgNIAAgtIAAgFIAAhBIAAAAQACgMAFgKQACgHAFgGQAFgIAIgHIANgKQAogeA5AAMAh8AAAQA6AAAoAeIANAKQAHAHAGAIQALAQACATIABAAIAABBIAAAFIAAAtQAAAGgBAHIABAAIAAAtQAAAHgBAIIABAAIAAAtQAAAYgOAVQgIAKgLAKIgHAFQgMAJgNAGQggAPgpAAg");
        this.shape_4.setTransform(655.7, 530.7);
        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("rgba(7,137,180,0.4)").ss(1, 1, 1).p("EAyPgBlIAADLEgyOgBlIAADLABfhlIAADL");
        this.shape_5.setTransform(468.8, 452.2);

        if (tipo == 2) {
            this.pluja = new lib.pluja();
            this.pluja.setTransform(514.9, 332.3, 0.73, 0.73);
            this.pluja.mask = this.shape0;

        }
        this.instance3 = new lib.cuadrobotcB();
        this.instance3.setTransform(476.8, 570.2);
        new cjs.ButtonHelper(this.instance3, 0, 1, 2, false, new lib.cuadrobotcA(), 3);
        this.instance3.on("click", function (evt) {

            putStage(new lib.frame1())

        });

        var ti = this.on("tick", function (evt) {
          
            if (parar)
                return;
              this.cot.cotxe.d.rotation+=30;
            this.cot.cotxe.r.rotation+=30;
            var cluck = new Date();
            var mili = Math.round((cluck.getTime() - clock.getTime()) / 10) / 100;
            var dis = Math.round(distancia * mili / tiempo);
            if (mili > tiempo) {
                parar = true;
                mili = tiempo;
                dis = distancia
            }
            
            if (dis >= 200) {
                parar = true;
                //console.log("##->"+dis+"|"+mili);
                document.getElementById("distancia").style.display = "none";
                document.getElementById("tiempo").style.display = "none";
                this.parent.punt2 = new lib.puntmapa();
                this.parent.punt2.setTransform(273, 522.8);
                this.parent.addChild(this.parent.punt2);
                this.linia2.children[0].c3.balla.visible=false;
               this.parent.balla2 = new lib.ballaAlAire();
                this.parent.balla2.setTransform(0, 0);
                  this.parent.balla2.mask =  this.shape0;

                this.parent.addChild(this.parent.balla2);
//                for (var i=0;i<3000;i++){
//                    for(var j=0;j<100000;j++){var a=0;}
//                this.linia2.children[0].c3.balla.x+=.1;
//                this.linia2.children[0].c3.balla.y-=.1;
//            }
            }
            ;
            document.getElementById("segundos").innerHTML = mili;
            document.getElementById("metros").innerHTML = dis;
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior, this.home, this.informacion, this.cerrar, this.linia, this.linia2, this.cot, this.radios, this.instance, this.instance_1, this.text, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape, this.punt, this.shape_7, this.shape_6, this.shape_5, this.velocidad, this.pluja, this.instance3, this.limites, this.distancia, this.tiempo, this.balla);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titulo']);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titulo']);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        titulo2(this, txt['titulo']);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho, top) {
        width = 730 - ancho;
        top = top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568, 1.15, 1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568, 1.15, 1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568, 1.15, 1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568, 1.15, 1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568, 1.15, 1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568, 1.15, 1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }

        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio == 1)
                escena.informacion.setTransform(280, 550, 1.15, 1.15);
            else
                escena.informacion.setTransform(217, 550, 1.15, 1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio == 1)
                escena.informacion.setTransform(280, 550, 1.15, 1.15);
            else
                escena.informacion.setTransform(217, 550, 1.15, 1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }

    //Simbolillos

    (lib.Mapadebits1 = function () {
        this.initialize(img.Mapadebits1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 629, 2);


    (lib.Mapadebits2 = function () {
        this.initialize(img.Mapadebits2);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 629, 2);


    (lib.ballatrans = function () {
        this.initialize(img.ballatrans);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 32, 101);


    (lib.bassals = function () {
        this.initialize(img.bassals);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1444, 82);


    (lib.cursorHelp = function () {
        this.initialize(img.cursorHelp);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 24, 23);


    (lib.fondo_ayuda = function () {
        this.initialize(img.fondo_ayuda);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 226, 126);


    (lib.fotofons = function () {
        this.initialize(img.fotofons);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2143, 403);


    (lib.fotofonsfinal = function () {
        this.initialize(img.fotofonsfinal);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2400, 135);


    (lib.fotofons2 = function () {
        this.initialize(img.fotofons2);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 718, 136);


    (lib.fotofonsarbrescarretera = function () {
        this.initialize(img.fotofonsarbrescarretera);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 693, 257);


    (lib.linia = function () {
        this.initialize(img.linia);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1567, 392);


    (lib.linianevat = function () {
        this.initialize(img.linianevat);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1716, 470);


    (lib.liniapluja = function () {
        this.initialize(img.liniapluja);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1564, 271);


    (lib.NEU = function () {
        this.initialize(img.NEU);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1515, 268);


    (lib.neuarbrescarreterapng = function () {
        this.initialize(img.neuarbrescarreterapng);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 330, 122);


    (lib.neucarreterapng = function () {
        this.initialize(img.neucarreterapng);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1217, 51);


    (lib.raincel = function () {
        this.initialize(img.raincel);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 2143, 307);


    (lib.transparent = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000000").s().p("AlJBZQgIAAgFgHQgHgIAAgKIAAh/QAAgKAHgIQAFgHAIgBIKTAAQAHABAGAHQAHAIAAAKIAAB/QAAAKgHAIQgGAHgHAAg");
        this.shape.setTransform(1, 1);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 3).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);


    (lib.titulo = function () {
        this.initialize();

        // Capa 1
        this.text = new cjs.Text("El movimiento y la velocidad", "31px Georgia");
        this.text.textAlign = "center";
        this.text.lineHeight = 33;
        this.text.lineWidth = 749;
        this.text.setTransform(-1.9, -19.6);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-376.5, -19.6, 753.1, 39.3);


    (lib.texto = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {arriba: 0, abajo: 1});

        // Capa 1
        this.text = new cjs.Text(" ", "14px Verdana");
        this.text.lineHeight = 13;
        this.text.lineWidth = 224;
        this.text.setTransform(-73.3, -9.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text, p: {text: " ", font: "14px Verdana", color: "#000000", lineHeight: 13.4, lineWidth: 224}}]}).to({state: [{t: this.text, p: {text: "", font: "10px Verdana", color: "#7B9A9C", lineHeight: 9.4, lineWidth: 140}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-73.3, -9.7, 228.4, 79.8);


    (lib.Símbolo519 = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#39585C").s().p("AgqBPIArgaIAqAZQgUAMgXAAQgVAAgVgLgAhXAUIArgYIAAAEQAAANAHALQAIALALAFIgqAaQgVgTgGgbgAAUAoQALgGAHgLQAHgKAAgNIgBgFIAsAZQgGAbgVASgAhMgsQALgUAUgMIAAAyIgsAZQABgXAMgUgAAugcIAAgwQAUAMAMAUQAMAUAAAWgAAAgrQgNgBgMAJIAAgyQANgEAMAAQANAAANAEIAAAyQgMgJgOABg");
        this.shape.setTransform(166.3, 507.3);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(157.2, 498.3, 18.1, 18.1);


    (lib.Símbolo518 = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#9CACAE", "#39585C", "#39585C"], [0, 0.647, 1], 389.5, -3.9, 389.5, 4.1).s().p("AhZgRQArgWAwAAQAvAAArAVQApASAdAjQhRg7hOAAQgqAAgtATQgnAPgmAeQAdgmArgTg");
        this.shape.setTransform(165.9, 492.4);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(149.7, 488.4, 32.5, 8.1);


    (lib.Símbolo517 = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#6B8285").s().p("ABRAdQABgWgKgTQgIgUgQgPQgPgQgUgIQgTgKgWABQgngBgfAZQAPgTAXgMQAXgLAbAAQAUAAAVAJQAUAJAPAPQAPAPAJAVQAJAUAAAVQAAAagLAXQgMAWgTAQQAZgfgBgng");
        this.shape.setTransform(167.3, 506.3);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(157.4, 496.3, 19.9, 19.9);


    (lib.Símbolo516 = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#6B8285", "#CED6D7"], [0, 1], 333.2, 255.5, 319.1, 272.8).s().p("AgqBmQgUgIgPgQQgQgPgIgUQgJgVAAgWQAAgVAJgVQAIgUAQgPQAPgQAUgIQAVgJAVAAQAWAAAVAJQAUAIAQAQQAPAPAIAUQAJAVAAAVQAAAWgJAVQgIAUgPAPQgQAQgUAIQgVAJgWAAQgVAAgVgJg");
        this.shape.setTransform(166.1, 507.5);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(154.9, 496.3, 22.4, 22.4);


    (lib.Símbolo515 = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#9CACAE", "#E7EBEB", "#9CACAE"], [0, 0.267, 1], 329.5, 260.3, 313.6, 279.3).s().p("AgvByQgWgKgRgRQgRgRgKgWQgKgXAAgZQAAgYAKgXQAKgWARgRQARgRAWgKQAXgKAYAAQAZAAAXAKQAWAKARARQARARAKAWQAKAXAAAYQAAAZgKAXQgKAWgRARQgRARgWAKQgXAKgZAAQgYAAgXgKg");
        this.shape.setTransform(166.1, 507.5);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(153.7, 495.1, 24.9, 24.9);


    (lib.Símbolo514 = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.rf(["#072E33", "#39585C"], [0, 1], 0, 0, 0, 0, 0, 23.6).s().p("AhPC+QglgQgdgcQgcgdgQglQgQgmAAgqQAAgpAQgmQAQglAcgdQAdgcAlgQQAmgQApAAQAqAAAmAQQAlAQAdAcQAcAdAQAlQAQAmAAApQAAAqgQAmQgQAlgcAdQgdAcglAQQgmAQgqAAQgpAAgmgQg");
        this.shape.setTransform(166.1, 507.5);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(145.4, 486.8, 41.4, 41.4);


    (lib.Símbolo513 = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#39585C", "#39585C", "#9CACAE"], [0, 0.525, 1], -159.6, 298.9, -168.7, 293.8).s().p("AgyANIAAgaIBlAAIAAAag");
        this.shape.setTransform(226.7, 467);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(221.5, 465.6, 10.4, 2.8);


    (lib.Símbolo511 = function () {
        this.initialize();

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("ARJGRQgGgugVgpQgVgogigfQgigegqgRQgsgRgvAAQgvAAgsARQgqARgiAeQgiAfgVAoQgVApgFAuIyzAAQgFgugWgpQgVgogigfQghgegrgRQgrgRgwAAQgvAAgsARQgqARgiAeQghAfgVAoQgWApgFAuIi6AAIgSkzQgBgWANgvQALgqALgUICtlRQAGgLAKgHQAMgIANAAIRpAEQA8ADAsAYQFDBzEpC1IG4CxQAoARARAkQAOAegFAjIgZCzg");
        mask.setTransform(251.6, 464.3);

        // Capa 2
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#FE821A", "#FFA65D"], [0, 1], 368.9, -4.5, 368.9, 4.6).s().p("AhMAuIgYhaICxAAIAYBag");
        this.shape.setTransform(379.5, 482.1);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.lf(["#FE821A", "#FFA65D"], [0, 1], 356.3, -4.4, 356.3, 4.6).s().p("Ag5AtIAAhaIBzAAIAABag");
        this.shape_1.setTransform(121.1, 475.8);

        this.shape.mask = this.shape_1.mask = mask;

        this.addChild(this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(115.2, 471.2, 274.5, 15.6);


    (lib.Símbolo3252 = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").ss(0.4, 1, 1).p("ABEAAIiHAA");
        this.shape.setTransform(147.3, 309);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);


    (lib.Símbolo2982 = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#999A9D").s().p("AgQAfIAAg9IAhAAIAAA9g");
        this.shape.setTransform(153.6, 341.8);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(151.8, 338.7, 3.5, 6.3);


    (lib.Símbolo147 = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AuDBzIAAjlIcHAAIAADlg");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-90, -11.4, 180.1, 23);


    (lib.radio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {"arriba": 0, "abajo": 1});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1.5, 1, 1).p("ABKAAQABAfgXAVQgVAXgfgBQgeABgWgXQgWgVAAgfQAAgeAWgWQAWgWAeAAQAfAAAVAWQAXAWgBAeg");

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("AgeAfQgOgNAAgSQAAgRAOgNQANgOARAAQASAAANAOQANANAAARQAAASgNANQgNANgSAAQgRAAgNgNg");

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}, {t: this.shape}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-7.4, -7.4, 15, 15);


    (lib.puntmapa = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AAfgeQAOANAAARQAAASgOANQgNAOgSAAQgRAAgNgOQgOgNABgSQgBgRAOgNQANgOARABQASgBANAOg");
        this.shape.setTransform(0.5, 1.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AAAAtQgRAAgNgOQgOgNABgSQgBgRAOgOQANgNARABQASgBANANQAOAOAAARQAAASgOANQgNAOgSAAIAAAAg");
        this.shape_1.setTransform(0.5, 1.5);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#990000").s().p("AAAAtQgRAAgNgOQgOgNABgSQgBgRAOgOQANgNARABQASgBANANQAOAOAAARQAAASgOANQgNAOgSAAIAAAAg");
        this.shape_2.setTransform(0.5, 1.5);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}]}).to({state: [{t: this.shape_1}, {t: this.shape}]}, 1).to({state: [{t: this.shape_2}, {t: this.shape}]}, 1).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-3.9, -2.9, 9, 9);


    (lib.plujaterra = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.bassals();
        this.instance.setTransform(-527, -55.6, 0.73, 1.358);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-527, -55.6, 1054.1, 111.4);


    (lib.pluja = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#0099FF").ss(1, 1, 1).p("Af22iIkBEBAVY9GIjGDGAfFrwInLHLAZhwNInlHlEAiPAGKIl3F3ARUXFIj5D5AVkiPImgGeEArmgDLInCHAEgpbgKKIiKCKAtUqxIk4E3EgTAgglIn4H4AE088IlJFMEgjLgQaIj6D6AIxAiIgEADAGVC+Ik/E/AnSQnIiKCJA6DB8IkvEuALJdPIjXDXAj6jxIkwEuAMrGoIiFCEAQL35InlHm");
        this.shape.setTransform(-32.2, -78.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#0099FF").ss(1, 1, 1).p("Af22iIkBEBAVY9GIjGDGAZhwNInlHlAfFrwInLHLEAiPAGKIl3F3ARUXFIj5D5EArmgDLInCHAAVkiPImgGeEgpbgKKIiKCKAtUqxIk4E3EgTAgglIn4H4AE088IlJFMEgjLgQaIj6D6AIxAiIgEADAGVC+Ik/E/AnSQnIiKCJA6DB8IkvEuALJdPIjXDXAj6jxIkwEuAQL35InlHmAMrGoIiFCE");
        this.shape_1.setTransform(107.5, -125.4);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#0099FF").ss(1, 1, 1).p("EAqygaLIkCEBEAgUggvIjHDGEAkdgT2InmHlEAqAgPZInLHLEAtKAChIl3F3EAgrAAcInCHCAcPTcIj5D5EA2hgG0InCHAEAgfgF4ImgGeEguFgMxIj7D6A+gtzIiKCKA9688In5H4AiZuaIk3E3EgIEgkOIn5H4AmF5TIlLFMAKe5dIjHDGAU8y5IkCEBEAPwgglIlMFMAFQ0QInjHmA4Q0DIj6D6ATsjFIgDADARQgqIk/E+ADnM+IiJCJABwKQIiDCFAKpBYImgGgAiIELIgDADAvIhrIkvEsAu1gIIkwEuAyNUQIiJCJAkkGmIk/FAAWFZmIjXDXAGZauIj5D5EAAPAg4IjWDXEgk+AFlIkvEuAG/naIkwEwAUKoHInLHLAOnskInmHlEg0WgGhIiKCKA4PnIIk3E3AbG7iInlHmAXmC+IiECFAXUJzIl3F3");
        this.shape_2.setTransform(-148.7, 37.6);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#0099FF").ss(1, 1, 1).p("AMWE2Ih4B4AELhfInjHjAJYmtIjGDHAnKmjIlLFM");
        this.shape_3.setTransform(-69.8, -270.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#0099FF").ss(1, 1, 1).p("AWevqIiJCJAIxAiIgEADASCrNInmHlAfFrwInLHLEArmgDLInCHAAMrGoIiFCEARUXFIj5D5ALJdPIjXDXEAiPAGKIl4F3AVkiPImgGeEgjLgQaIj6D6EgpbgKKIiKCKA6DqiIkvEuAtU3RIk4E3Aj6jxIkwEuEgTAgglIn4H4AnSdHIiKCJAGVPeIk/E/");
        this.shape_4.setTransform(-178.6, -95.5);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#0099FF").ss(1, 1, 1).p("EAaYghWIjGDHAdW1yIh4B4AWeu6IiJCKAIxBSIgEAEASCqdInmHmAfFrAInLHLEArmgCbInCHAAVL8IInlHlAMrHYIiFCFARUX1Ij5D5ALJeAIjXDXEAiPAG6Il4F4AVkhfImgGeEgjLgPqIj6D6EgpbgJaIiKCKA6DpyIkvEuAtU2hIk4E3Aj6jBIkwEuAzA/1In4H5AnSd3IiKCKAGVQOIk/E/EAJ0ghMIlLFM");
        this.shape_5.setTransform(-38.8, -146.9);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f().s("#0099FF").ss(1, 1, 1).p("EAlUgk/IjHDHEAoSgZbIh4B4EAhagSjIiKCKATsiVIgDAEAc9uGInmHmEAqAgOpInLHLEA2hgGEInCHAEAgGgfxInlHlAXUKjIl3F4AXmDvIiECFAcPUMIj5D5AWFaXIjXDXEAgrABMInCHCEAtKADRIl3F4EAgfgFIImgGeEg0WgFxIiKCLEgk+gGJIkvEvEguFgMBIj7D6A4QzTIj6D6A+gtDIiKCKAvItbIkvEuA4Py4Ik3E3APe9tIjHDHAiZ6KIk4E4AhF9jIlLFMALkrRIiKCKAKQ4fInlHlAHHmzInkHjEgIFgjeIn4H5A968MIn5H5AiIE7IgEAEABwLBIiDCFADnaOIiKCKAGZbeIj5D5AKpCIImgGgEgSNAhgIiJCKEAAPAhpIjWDXAkkT3Ik/E/Au1AmIkwEwARQMlIk/E/EAUwgk1IlMFMAUKnXInLHMAScyJIh4B4");
        this.shape_6.setTransform(-108.7, -7.1);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#0099FF").ss(1, 1, 1).p("AxYtNIgDAEARcw8InCHCAtdnHIiFCFAo1JUIj5D5Au/PfIheBeAIFnlIl4F4AmUuQIkxEw");
        this.shape_7.setTransform(231.8, -171.1);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f().s("#0099FF").ss(1, 1, 1).p("EApBgaFIjGDHEAj0gU3IkBEAEAYTAmvIh4B5EAKPgmRIh4B4ADX/ZIiJCKAL97fInLHLA0ioZIj6D6A6ziIIiKCIArbihIkuEtABSvQIg5A5ACcx+IhvBvAKsEOIkwEwEgB7gonIjlDlAhE68InlHmEAHUAlIIiJCKA8VQ3Ij+D/EghHAGqIn5H5AU+XfIlAE/AYd57IlMFM");
        this.shape_8.setTransform(-109.1, -190.5);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f().s("#0099FF").ss(1, 1, 1).p("AaK6FIjGDHAVCqLIgDADAY9kFIiFCEEA34gN6InCHCEAuhgEjIl4F1AU903IkBEAEAgGgLPIkxExAdlMWIj5D5AXbShIheBeEAJdAmvIh5B5EgEmgmRIh4B4Are/ZIiJCKAi47fInLHLEgjZgIZIj6D6EgppgCIIiKCIA6SihIkuEtAtjvQIg4A5AsYx+IhwBvAkJEOIkwEwAv768InlHmEgQygonIjkDlEgHgAlIIiKCKEgrLAQ3Ij/D/Egv+AGqIn5H5AJm57IlLFMAGHXfIlAE/");
        this.shape_9.setTransform(125.6, -240);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f().s("#0099FF").ss(1, 1, 1).p("EAlFgd8IjGDGAf9uCIgDADEAjmgAsIl4F2EAj4gH9IiFCFEBCzgRyInCHCEA5cgIbIl4F4Af44vIkBEBEArBgPGIkxExEAs9gKDInCHCEAogAIfIj5D5EAiWAOpIheBfEAUYAi4Ih5B4Eg0kABtIiKCKEglNABVIkuEuEguUgEhIj6D6EAGTgqIIh4B4EgAjgjQIiJCJAIB/WInLHLEgbtgkvIjkDkA2Z7hIiJCJEgPhgiZIh4B4A4erYIg4A4A3TuHIhwBwA4esRIj6D7A+umAIiKCKAvXmYIkuEuAPP2NIjGDGAKCxAIkBEBAiozHIg4A4AhT2DIlLFLAKHmTIgDADAOCgOIiFCDAGwAXIkwEwAlA+zInlHlEgF3gseIjkDkAtz3nInLHLA623EInlHlEADZAhRIiKCJAMgWYIheBfEgSbApAIiKCJEgBcAqnIh5B4AkybWIlAFAEg2GAUvIj/D+Eg65AKiIn5H4EggQANAIj/D+EglDACzIn5H4AvEIGIkwEwAUh9yIlLFLARCTnIlAFAASqQOIj5D5AVLnXIkxEx");
        this.shape_10.setTransform(-107.3, -52.2);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f().s("#0099FF").ss(1, 1, 1).p("EAo9gaLIkBEBEAefggvIjGDGEAiogT2InlHlEAoLgPZInLHLEArWAChIl4F3AaaTcIj5D5EAigAAcInDHCEA0sgG0InCHAAeql4ImgGeEgsRgMxIj6D6EggVgNzIiKCKAkOuaIk3E3EgJ5gkOIn5H4AkQ5TIlMFMAMS5dIjGDGAHF0QInkHmEAN7gglIlMFMA6E0DIj6D6A8G88In5H4AR3jFIgDADAPcgqIlAE+AgUELIgDADAByM+IiHCJADlKQIiFCFAMdBYImgGgAw9hrIkuEsAwZUQIiJCJAtBgIIkwEuAUQZmIjXDXAINauIj5D5EACDAg4IjVDXAivGmIlAFAEgjKAFlIkuEuAFKnaIkwEwAQbskInlHlEgyigGhIiKCKA2bnIIk3E3AZS7iInmHmAVyC+IiFCFAWwy5IkBEBAV+oHInLHLAZIJzIl3F3");
        this.shape_11.setTransform(-137.1, 37.6);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f().s("#0099FF").ss(1, 1, 1).p("EAjfgooIjGDHEAmdgdEIh4B4Afl2MIiJCKAUQufIh4B4AR3l+IgDAEAbIxvInlHmEAoLgSSInLHMEA0tgJtInCHCEAeSgjaInmHlAVyAGIiFCFAaaQjIj5D5AUQWuIjXDXAZIOMIl3F4EAigAE1InCHCEArWgAWIl4F2AeroxImhGgEgsRgIYIj6D6A6E28Ij6D6EggVgQsIiKCKAw9xEIkuEuA2bvPIk3E3AkO9zIk3E3AAu56IlKFMANYnnIiJCJAFKqTIkwEwAMF02InlHlEgJ5gnHIn5H5A8G4jIn5H5AMdFxImgGgAgUIkIgDAEAByWlIiHCKADlOqIiFCFAtBEPIkwEwEgQZAlJIiJCKAINfHIj5D5EACDAlSIjVDXAivXgIlAE/EgyigCHIiKCIAI7jKInlHjEgjKgCgIkuEtAPcI8IlAE/EAS7goeIlMFMAV+juInLHKARS6EIjGDH");
        this.shape_12.setTransform(-97.1, 16.1);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f().s("#0099FF").ss(1, 1, 1).p("EApBgaFIjGDHEAj0gU3IkBEAEAYTAmvIh4B5EAKPgmRIh4B4ADX/ZIiJCKAL97fInLHLA0ioZIj6D6A6ziIIiKCIArbihIkuEtABSvQIg5A5ACcx+IhvBvAKsEOIkwEwAhE68InlHmEgB7gonIjlDlEAHUAlIIiJCKA8VQ3Ij+D/EghHAGqIn5H5AYd57IlMFMAU+XfIlAE/");
        this.shape_13.setTransform(-225.6, -219.6);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f().s("#0099FF").ss(1, 1, 1).p("AaK6FIjGDHAVCqLIgDADAY9kFIiFCEEA34gN6InCHCEAuhgEjIl4F1AU903IkBEAEAgGgLPIkxExAdlMWIj5D5AXbShIheBeEAJdAmvIh5B5EgEmgmRIh4B4Are/ZIiJCKAi47fInLHLEgjZgIZIj6D6EgppgCIIiKCIA6SihIkuEtAtjvQIg4A5AsYx+IhwBvAkJEOIkwEwEgQygonIjkDlAv768InlHmEgHgAlIIiKCKEgrLAQ3Ij/D/Egv+AGqIn5H5AGHXfIlAE/AJm57IlLFM");
        this.shape_14.setTransform(9.1, -289.5);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f().s("#0099FF").ss(1, 1, 1).p("EAlFgfiIjGDGAf9voIgDADEAj4gJjIiFCFEBCzgTYInCHCEA5cgKBIl4F4Af46VIkBEBEArBgQsIkxExEAs9gIdInCHCEAogAG5Ij5D5EAiWANDIheBfEAUYAhSIh5B4EAjmAA4Il4F4Eg0kADTIiKCKEguUgC8Ij6D5EAGTgruIh4B4EgAjgk2IiJCJEAIBgg8InLHLEgbtgjJIjkDkEgPhggzIh4B4Atz2BInLHLA4epyIg4A4A3TshIhwBwA4et3Ij6D7A+unmIiKCKAvXn+IkuEuAPP0nIjGDGAKCvaIkBEBAio0tIg4A4Ahd3cIhwBwAhT0dIlLFMAKHktIgDADAOCBWIiFCFAGwhNIkwEuEgF3guEIjkDlEgFAggZInlHlA2Z57IiJCJA621eInlHlADZfrIiKCJAMgX+IheBeAvEJsIkwEwEgSbAqmIiKCJEgBcAsNIh5B4Akyc8IlAFAEg2GAWUIj/D/Eg65AMIIn5H4EggQALaIj/D+EglDABMIn5H5EglNAC7IkuEuARCSBIlAFAAUh/YIlLFLASqR0Ij5D5AVLlxIkxEx");
        this.shape_15.setTransform(-107.3, -42);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2}, {t: this.shape_1, p: {x: 107.5, y: -125.4}}, {t: this.shape, p: {x: -32.2, y: -78.8}}]}).to({state: []}, 1).to({state: [{t: this.shape_6}, {t: this.shape_5, p: {x: -38.8, y: -146.9}}, {t: this.shape_4, p: {x: -178.6, y: -95.5}}, {t: this.shape_3, p: {x: -69.8, y: -270.8}}]}, 1).to({state: []}, 1).to({state: [{t: this.shape_10}, {t: this.shape_9}, {t: this.shape_8}, {t: this.shape_7, p: {x: 231.8, y: -171.1}}]}, 1).to({state: []}, 1).to({state: [{t: this.shape_11}, {t: this.shape_1, p: {x: 37.6, y: -195.3}}, {t: this.shape, p: {x: -78.8, y: -148.7}}]}, 1).to({state: []}, 1).to({state: [{t: this.shape_12}, {t: this.shape_5, p: {x: 31, y: -216.8}}, {t: this.shape_4, p: {x: -85.4, y: -118.8}}, {t: this.shape_3, p: {x: 23.3, y: -294.1}}]}, 1).to({state: []}, 1).to({state: [{t: this.shape_15}, {t: this.shape_14}, {t: this.shape_13}, {t: this.shape_7, p: {x: 115.3, y: -200.2}}]}, 1).to({state: []}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-497.7, -334.1, 884.3, 603.8);


    (lib.pisos = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 13
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#9C9E9C").s().p("Eh57ABtIAAjZMDz3AAAIAADZg");
        this.shape.setTransform(217.2, 57.3);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 2).wait(1));

        // Capa 11
        this.instance = new lib.fotofons();
        this.instance.setTransform(-563, -378, 0.736, 0.973);

        this.instance_1 = new lib.NEU();
        this.instance_1.setTransform(-562.7, -377.6, 1.289, 1.696);

        this.instance_2 = new lib.raincel();
        this.instance_2.setTransform(-563, -284.9, 0.735, 0.972);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}]}).to({state: [{t: this.instance_1}]}, 1).to({state: [{t: this.instance_2}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-563, -378, 1576.3, 392);


    (lib.neuterra = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.neucarreterapng();
        this.instance.setTransform(-525.9, -54.2, 0.864, 2.128);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-525.9, -54.2, 1052, 108.6);


    (lib.mc_loader_barra = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 3
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#000000", "#FFFFFF"], [0.894, 1], 21.4, 17.1, -2.9, -25.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape.setTransform(9, 27.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.lf(["#000000", "#FFFFFF"], [0.885, 0.996], 21.5, 16.9, -3.1, -24.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_1.setTransform(9, 27.4);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.lf(["#000000", "#FFFFFF"], [0.876, 0.992], 21.5, 16.7, -3.3, -24.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_2.setTransform(9, 27.4);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.lf(["#000000", "#FFFFFF"], [0.867, 0.988], 21.6, 16.4, -3.4, -24.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_3.setTransform(9, 27.4);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.lf(["#000000", "#FFFFFF"], [0.858, 0.984], 21.7, 16.2, -3.6, -24.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_4.setTransform(9, 27.4);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.lf(["#000000", "#FFFFFF"], [0.849, 0.98], 21.8, 15.9, -3.7, -24.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_5.setTransform(9, 27.4);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.lf(["#000000", "#FFFFFF"], [0.84, 0.976], 21.9, 15.7, -3.9, -24).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_6.setTransform(9, 27.4);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.lf(["#000000", "#FFFFFF"], [0.832, 0.971], 21.9, 15.4, -4.1, -23.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_7.setTransform(9, 27.4);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.lf(["#000000", "#FFFFFF"], [0.823, 0.967], 22.1, 15.2, -4.2, -23.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_8.setTransform(9, 27.4);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.lf(["#000000", "#FFFFFF"], [0.814, 0.963], 22.1, 14.9, -4.4, -23.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_9.setTransform(9, 27.4);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.lf(["#000000", "#FFFFFF"], [0.805, 0.959], 22.2, 14.7, -4.5, -23.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_10.setTransform(9, 27.4);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.lf(["#000000", "#FFFFFF"], [0.796, 0.955], 22.3, 14.5, -4.7, -23.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_11.setTransform(9, 27.4);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.lf(["#000000", "#FFFFFF"], [0.787, 0.951], 22.4, 14.2, -4.8, -22.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_12.setTransform(9, 27.4);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.lf(["#000000", "#FFFFFF"], [0.778, 0.947], 22.5, 13.9, -5, -22.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_13.setTransform(9, 27.4);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.lf(["#000000", "#FFFFFF"], [0.769, 0.943], 22.5, 13.7, -5.2, -22.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_14.setTransform(9, 27.4);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.lf(["#000000", "#FFFFFF"], [0.76, 0.939], 22.6, 13.5, -5.4, -22.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_15.setTransform(9, 27.4);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.lf(["#000000", "#FFFFFF"], [0.751, 0.935], 22.7, 13.2, -5.5, -22.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_16.setTransform(9, 27.4);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.lf(["#000000", "#FFFFFF"], [0.742, 0.931], 22.8, 12.9, -5.7, -22.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_17.setTransform(9, 27.4);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.lf(["#000000", "#FFFFFF"], [0.733, 0.927], 22.9, 12.7, -5.8, -21.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_18.setTransform(9, 27.4);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.lf(["#000000", "#FFFFFF"], [0.724, 0.923], 23, 12.5, -6, -21.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_19.setTransform(9, 27.4);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.lf(["#000000", "#FFFFFF"], [0.715, 0.918], 23.1, 12.2, -6.1, -21.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_20.setTransform(9, 27.4);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.lf(["#000000", "#FFFFFF"], [0.706, 0.914], 23.2, 11.9, -6.3, -21.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_21.setTransform(9, 27.4);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.lf(["#000000", "#FFFFFF"], [0.697, 0.91], 23.2, 11.7, -6.5, -21.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_22.setTransform(9, 27.4);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.lf(["#000000", "#FFFFFF"], [0.688, 0.906], 23.3, 11.5, -6.6, -21).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_23.setTransform(9, 27.4);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.lf(["#000000", "#FFFFFF"], [0.68, 0.902], 23.4, 11.2, -6.8, -20.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_24.setTransform(9, 27.4);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.lf(["#000000", "#FFFFFF"], [0.671, 0.898], 23.5, 10.9, -6.9, -20.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_25.setTransform(9, 27.4);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.lf(["#000000", "#FFFFFF"], [0.662, 0.894], 23.6, 10.7, -7.1, -20.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_26.setTransform(9, 27.4);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.lf(["#000000", "#FFFFFF"], [0.653, 0.89], 23.6, 10.5, -7.3, -20.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_27.setTransform(9, 27.4);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.lf(["#000000", "#FFFFFF"], [0.644, 0.886], 23.8, 10.2, -7.4, -20.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_28.setTransform(9, 27.4);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.lf(["#000000", "#FFFFFF"], [0.635, 0.882], 23.8, 10, -7.6, -19.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_29.setTransform(9, 27.4);

        this.shape_30 = new cjs.Shape();
        this.shape_30.graphics.lf(["#000000", "#FFFFFF"], [0.626, 0.878], 23.9, 9.7, -7.7, -19.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_30.setTransform(9, 27.4);

        this.shape_31 = new cjs.Shape();
        this.shape_31.graphics.lf(["#000000", "#FFFFFF"], [0.617, 0.874], 24, 9.5, -7.9, -19.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_31.setTransform(9, 27.4);

        this.shape_32 = new cjs.Shape();
        this.shape_32.graphics.lf(["#000000", "#FFFFFF"], [0.608, 0.869], 24.1, 9.2, -8, -19.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_32.setTransform(9, 27.4);

        this.shape_33 = new cjs.Shape();
        this.shape_33.graphics.lf(["#000000", "#FFFFFF"], [0.599, 0.865], 24.2, 9, -8.2, -19.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_33.setTransform(9, 27.4);

        this.shape_34 = new cjs.Shape();
        this.shape_34.graphics.lf(["#000000", "#FFFFFF"], [0.59, 0.861], 24.2, 8.7, -8.4, -19.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_34.setTransform(9, 27.4);

        this.shape_35 = new cjs.Shape();
        this.shape_35.graphics.lf(["#000000", "#FFFFFF"], [0.581, 0.857], 24.3, 8.5, -8.5, -18.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_35.setTransform(9, 27.4);

        this.shape_36 = new cjs.Shape();
        this.shape_36.graphics.lf(["#000000", "#FFFFFF"], [0.572, 0.853], 24.4, 8.3, -8.7, -18.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_36.setTransform(9, 27.4);

        this.shape_37 = new cjs.Shape();
        this.shape_37.graphics.lf(["#000000", "#FFFFFF"], [0.563, 0.849], 24.5, 8, -8.8, -18.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_37.setTransform(9, 27.4);

        this.shape_38 = new cjs.Shape();
        this.shape_38.graphics.lf(["#000000", "#FFFFFF"], [0.554, 0.845], 24.6, 7.7, -9, -18.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_38.setTransform(9, 27.4);

        this.shape_39 = new cjs.Shape();
        this.shape_39.graphics.lf(["#000000", "#FFFFFF"], [0.545, 0.841], 24.7, 7.5, -9.2, -18.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_39.setTransform(9, 27.4);

        this.shape_40 = new cjs.Shape();
        this.shape_40.graphics.lf(["#000000", "#FFFFFF"], [0.536, 0.837], 24.8, 7.3, -9.3, -18).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_40.setTransform(9, 27.4);

        this.shape_41 = new cjs.Shape();
        this.shape_41.graphics.lf(["#000000", "#FFFFFF"], [0.528, 0.833], 24.8, 7, -9.5, -17.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_41.setTransform(9, 27.4);

        this.shape_42 = new cjs.Shape();
        this.shape_42.graphics.lf(["#000000", "#FFFFFF"], [0.519, 0.829], 24.9, 6.7, -9.7, -17.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_42.setTransform(9, 27.4);

        this.shape_43 = new cjs.Shape();
        this.shape_43.graphics.lf(["#000000", "#FFFFFF"], [0.51, 0.825], 25, 6.5, -9.8, -17.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_43.setTransform(9, 27.4);

        this.shape_44 = new cjs.Shape();
        this.shape_44.graphics.lf(["#000000", "#FFFFFF"], [0.501, 0.821], 25.1, 6.3, -9.9, -17.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_44.setTransform(9, 27.4);

        this.shape_45 = new cjs.Shape();
        this.shape_45.graphics.lf(["#000000", "#FFFFFF"], [0.492, 0.816], 25.2, 6, -10.1, -17.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_45.setTransform(9, 27.4);

        this.shape_46 = new cjs.Shape();
        this.shape_46.graphics.lf(["#000000", "#FFFFFF"], [0.483, 0.812], 25.3, 5.8, -10.3, -17).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_46.setTransform(9, 27.4);

        this.shape_47 = new cjs.Shape();
        this.shape_47.graphics.lf(["#000000", "#FFFFFF"], [0.474, 0.808], 25.3, 5.5, -10.5, -16.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_47.setTransform(9, 27.4);

        this.shape_48 = new cjs.Shape();
        this.shape_48.graphics.lf(["#000000", "#FFFFFF"], [0.465, 0.804], 25.4, 5.3, -10.6, -16.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_48.setTransform(9, 27.4);

        this.shape_49 = new cjs.Shape();
        this.shape_49.graphics.lf(["#000000", "#FFFFFF"], [0.456, 0.8], 25.5, 5, -10.8, -16.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_49.setTransform(9, 27.4);

        this.shape_50 = new cjs.Shape();
        this.shape_50.graphics.lf(["#000000", "#FFFFFF"], [0.447, 0.796], 25.6, 4.8, -10.9, -16.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_50.setTransform(9, 27.4);

        this.shape_51 = new cjs.Shape();
        this.shape_51.graphics.lf(["#000000", "#FFFFFF"], [0.438, 0.792], 25.7, 4.5, -11.1, -16.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_51.setTransform(9, 27.4);

        this.shape_52 = new cjs.Shape();
        this.shape_52.graphics.lf(["#000000", "#FFFFFF"], [0.429, 0.788], 25.8, 4.3, -11.2, -15.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_52.setTransform(9, 27.4);

        this.shape_53 = new cjs.Shape();
        this.shape_53.graphics.lf(["#000000", "#FFFFFF"], [0.42, 0.784], 25.9, 4, -11.4, -15.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_53.setTransform(9, 27.4);

        this.shape_54 = new cjs.Shape();
        this.shape_54.graphics.lf(["#000000", "#FFFFFF"], [0.411, 0.78], 25.9, 3.8, -11.6, -15.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_54.setTransform(9, 27.4);

        this.shape_55 = new cjs.Shape();
        this.shape_55.graphics.lf(["#000000", "#FFFFFF"], [0.402, 0.776], 26, 3.5, -11.7, -15.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_55.setTransform(9, 27.4);

        this.shape_56 = new cjs.Shape();
        this.shape_56.graphics.lf(["#000000", "#FFFFFF"], [0.393, 0.772], 26.1, 3.3, -11.9, -15.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_56.setTransform(9, 27.4);

        this.shape_57 = new cjs.Shape();
        this.shape_57.graphics.lf(["#000000", "#FFFFFF"], [0.384, 0.768], 26.2, 3, -12, -15.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_57.setTransform(9, 27.4);

        this.shape_58 = new cjs.Shape();
        this.shape_58.graphics.lf(["#000000", "#FFFFFF"], [0.376, 0.763], 26.3, 2.8, -12.2, -14.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_58.setTransform(9, 27.4);

        this.shape_59 = new cjs.Shape();
        this.shape_59.graphics.lf(["#000000", "#FFFFFF"], [0.367, 0.759], 26.3, 2.6, -12.4, -14.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_59.setTransform(9, 27.4);

        this.shape_60 = new cjs.Shape();
        this.shape_60.graphics.lf(["#000000", "#FFFFFF"], [0.358, 0.755], 26.5, 2.3, -12.5, -14.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_60.setTransform(9, 27.4);

        this.shape_61 = new cjs.Shape();
        this.shape_61.graphics.lf(["#000000", "#FFFFFF"], [0.349, 0.751], 26.5, 2.1, -12.7, -14.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_61.setTransform(9, 27.4);

        this.shape_62 = new cjs.Shape();
        this.shape_62.graphics.lf(["#000000", "#FFFFFF"], [0.34, 0.747], 26.6, 1.8, -12.8, -14.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_62.setTransform(9, 27.4);

        this.shape_63 = new cjs.Shape();
        this.shape_63.graphics.lf(["#000000", "#FFFFFF"], [0.331, 0.743], 26.7, 1.6, -13, -14).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_63.setTransform(9, 27.4);

        this.shape_64 = new cjs.Shape();
        this.shape_64.graphics.lf(["#000000", "#FFFFFF"], [0.322, 0.739], 26.8, 1.3, -13.1, -13.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_64.setTransform(9, 27.4);

        this.shape_65 = new cjs.Shape();
        this.shape_65.graphics.lf(["#000000", "#FFFFFF"], [0.313, 0.735], 26.9, 1.1, -13.3, -13.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_65.setTransform(9, 27.4);

        this.shape_66 = new cjs.Shape();
        this.shape_66.graphics.lf(["#000000", "#FFFFFF"], [0.304, 0.731], 26.9, 0.8, -13.5, -13.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_66.setTransform(9, 27.4);

        this.shape_67 = new cjs.Shape();
        this.shape_67.graphics.lf(["#000000", "#FFFFFF"], [0.295, 0.727], 27, 0.6, -13.7, -13.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_67.setTransform(9, 27.4);

        this.shape_68 = new cjs.Shape();
        this.shape_68.graphics.lf(["#000000", "#FFFFFF"], [0.286, 0.723], 27.1, 0.3, -13.8, -13.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_68.setTransform(9, 27.4);

        this.shape_69 = new cjs.Shape();
        this.shape_69.graphics.lf(["#000000", "#FFFFFF"], [0.277, 0.719], 27.2, 0.1, -14, -12.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_69.setTransform(9, 27.4);

        this.shape_70 = new cjs.Shape();
        this.shape_70.graphics.lf(["#000000", "#FFFFFF"], [0.268, 0.715], 27.3, -0.1, -14.1, -12.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_70.setTransform(9, 27.4);

        this.shape_71 = new cjs.Shape();
        this.shape_71.graphics.lf(["#000000", "#FFFFFF"], [0.259, 0.71], 27.4, -0.3, -14.3, -12.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_71.setTransform(9, 27.4);

        this.shape_72 = new cjs.Shape();
        this.shape_72.graphics.lf(["#000000", "#FFFFFF"], [0.25, 0.706], 27.5, -0.5, -14.4, -12.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_72.setTransform(9, 27.4);

        this.shape_73 = new cjs.Shape();
        this.shape_73.graphics.lf(["#000000", "#FFFFFF"], [0.241, 0.702], 27.6, -0.8, -14.6, -12.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_73.setTransform(9, 27.4);

        this.shape_74 = new cjs.Shape();
        this.shape_74.graphics.lf(["#000000", "#FFFFFF"], [0.232, 0.698], 27.6, -1.1, -14.8, -12.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_74.setTransform(9, 27.4);

        this.shape_75 = new cjs.Shape();
        this.shape_75.graphics.lf(["#000000", "#FFFFFF"], [0.224, 0.694], 27.7, -1.3, -14.9, -11.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_75.setTransform(9, 27.4);

        this.shape_76 = new cjs.Shape();
        this.shape_76.graphics.lf(["#000000", "#FFFFFF"], [0.215, 0.69], 27.8, -1.5, -15.1, -11.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_76.setTransform(9, 27.4);

        this.shape_77 = new cjs.Shape();
        this.shape_77.graphics.lf(["#000000", "#FFFFFF"], [0.206, 0.686], 27.9, -1.8, -15.2, -11.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_77.setTransform(9, 27.4);

        this.shape_78 = new cjs.Shape();
        this.shape_78.graphics.lf(["#000000", "#FFFFFF"], [0.197, 0.682], 28, -2.1, -15.4, -11.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_78.setTransform(9, 27.4);

        this.shape_79 = new cjs.Shape();
        this.shape_79.graphics.lf(["#000000", "#FFFFFF"], [0.188, 0.678], 28, -2.3, -15.6, -11.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_79.setTransform(9, 27.4);

        this.shape_80 = new cjs.Shape();
        this.shape_80.graphics.lf(["#000000", "#FFFFFF"], [0.179, 0.674], 28.2, -2.5, -15.7, -11).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_80.setTransform(9, 27.4);

        this.shape_81 = new cjs.Shape();
        this.shape_81.graphics.lf(["#000000", "#FFFFFF"], [0.17, 0.67], 28.2, -2.8, -15.9, -10.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_81.setTransform(9, 27.4);

        this.shape_82 = new cjs.Shape();
        this.shape_82.graphics.lf(["#000000", "#FFFFFF"], [0.161, 0.666], 28.3, -3.1, -16, -10.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_82.setTransform(9, 27.4);

        this.shape_83 = new cjs.Shape();
        this.shape_83.graphics.lf(["#000000", "#FFFFFF"], [0.152, 0.661], 28.4, -3.3, -16.2, -10.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_83.setTransform(9, 27.4);

        this.shape_84 = new cjs.Shape();
        this.shape_84.graphics.lf(["#000000", "#FFFFFF"], [0.143, 0.657], 28.5, -3.5, -16.3, -10.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_84.setTransform(9, 27.4);

        this.shape_85 = new cjs.Shape();
        this.shape_85.graphics.lf(["#000000", "#FFFFFF"], [0.134, 0.653], 28.6, -3.8, -16.5, -10.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_85.setTransform(9, 27.4);

        this.shape_86 = new cjs.Shape();
        this.shape_86.graphics.lf(["#000000", "#FFFFFF"], [0.125, 0.649], 28.6, -4, -16.7, -9.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_86.setTransform(9, 27.4);

        this.shape_87 = new cjs.Shape();
        this.shape_87.graphics.lf(["#000000", "#FFFFFF"], [0.116, 0.645], 28.7, -4.3, -16.8, -9.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_87.setTransform(9, 27.4);

        this.shape_88 = new cjs.Shape();
        this.shape_88.graphics.lf(["#000000", "#FFFFFF"], [0.107, 0.641], 28.8, -4.5, -17, -9.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_88.setTransform(9, 27.4);

        this.shape_89 = new cjs.Shape();
        this.shape_89.graphics.lf(["#000000", "#FFFFFF"], [0.098, 0.637], 28.9, -4.8, -17.1, -9.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_89.setTransform(9, 27.4);

        this.shape_90 = new cjs.Shape();
        this.shape_90.graphics.lf(["#000000", "#FFFFFF"], [0.089, 0.633], 29, -5, -17.3, -9.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_90.setTransform(9, 27.4);

        this.shape_91 = new cjs.Shape();
        this.shape_91.graphics.lf(["#000000", "#FFFFFF"], [0.08, 0.629], 29.1, -5.3, -17.5, -9.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_91.setTransform(9, 27.4);

        this.shape_92 = new cjs.Shape();
        this.shape_92.graphics.lf(["#000000", "#FFFFFF"], [0.072, 0.625], 29.2, -5.5, -17.6, -8.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_92.setTransform(9, 27.4);

        this.shape_93 = new cjs.Shape();
        this.shape_93.graphics.lf(["#000000", "#FFFFFF"], [0.063, 0.621], 29.2, -5.7, -17.8, -8.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_93.setTransform(9, 27.4);

        this.shape_94 = new cjs.Shape();
        this.shape_94.graphics.lf(["#000000", "#FFFFFF"], [0.054, 0.617], 29.3, -6, -18, -8.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_94.setTransform(9, 27.4);

        this.shape_95 = new cjs.Shape();
        this.shape_95.graphics.lf(["#000000", "#FFFFFF"], [0.045, 0.613], 29.4, -6.3, -18.1, -8.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_95.setTransform(9, 27.4);

        this.shape_96 = new cjs.Shape();
        this.shape_96.graphics.lf(["#000000", "#FFFFFF"], [0.036, 0.608], 29.5, -6.5, -18.2, -8.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_96.setTransform(9, 27.4);

        this.shape_97 = new cjs.Shape();
        this.shape_97.graphics.lf(["#000000", "#FFFFFF"], [0.027, 0.604], 29.6, -6.7, -18.4, -8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_97.setTransform(9, 27.4);

        this.shape_98 = new cjs.Shape();
        this.shape_98.graphics.lf(["#000000", "#FFFFFF"], [0.018, 0.6], 29.7, -7, -18.6, -7.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_98.setTransform(9, 27.4);

        this.shape_99 = new cjs.Shape();
        this.shape_99.graphics.lf(["#000000", "#FFFFFF"], [0.009, 0.596], 29.7, -7.3, -18.8, -7.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_99.setTransform(9, 27.4);

        this.shape_100 = new cjs.Shape();
        this.shape_100.graphics.lf(["#000000", "#FFFFFF"], [0, 0.592], 29.8, -7.5, -18.9, -7.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
        this.shape_100.setTransform(9, 27.4);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).to({state: [{t: this.shape_3}]}, 1).to({state: [{t: this.shape_4}]}, 1).to({state: [{t: this.shape_5}]}, 1).to({state: [{t: this.shape_6}]}, 1).to({state: [{t: this.shape_7}]}, 1).to({state: [{t: this.shape_8}]}, 1).to({state: [{t: this.shape_9}]}, 1).to({state: [{t: this.shape_10}]}, 1).to({state: [{t: this.shape_11}]}, 1).to({state: [{t: this.shape_12}]}, 1).to({state: [{t: this.shape_13}]}, 1).to({state: [{t: this.shape_14}]}, 1).to({state: [{t: this.shape_15}]}, 1).to({state: [{t: this.shape_16}]}, 1).to({state: [{t: this.shape_17}]}, 1).to({state: [{t: this.shape_18}]}, 1).to({state: [{t: this.shape_19}]}, 1).to({state: [{t: this.shape_20}]}, 1).to({state: [{t: this.shape_21}]}, 1).to({state: [{t: this.shape_22}]}, 1).to({state: [{t: this.shape_23}]}, 1).to({state: [{t: this.shape_24}]}, 1).to({state: [{t: this.shape_25}]}, 1).to({state: [{t: this.shape_26}]}, 1).to({state: [{t: this.shape_27}]}, 1).to({state: [{t: this.shape_28}]}, 1).to({state: [{t: this.shape_29}]}, 1).to({state: [{t: this.shape_30}]}, 1).to({state: [{t: this.shape_31}]}, 1).to({state: [{t: this.shape_32}]}, 1).to({state: [{t: this.shape_33}]}, 1).to({state: [{t: this.shape_34}]}, 1).to({state: [{t: this.shape_35}]}, 1).to({state: [{t: this.shape_36}]}, 1).to({state: [{t: this.shape_37}]}, 1).to({state: [{t: this.shape_38}]}, 1).to({state: [{t: this.shape_39}]}, 1).to({state: [{t: this.shape_40}]}, 1).to({state: [{t: this.shape_41}]}, 1).to({state: [{t: this.shape_42}]}, 1).to({state: [{t: this.shape_43}]}, 1).to({state: [{t: this.shape_44}]}, 1).to({state: [{t: this.shape_45}]}, 1).to({state: [{t: this.shape_46}]}, 1).to({state: [{t: this.shape_47}]}, 1).to({state: [{t: this.shape_48}]}, 1).to({state: [{t: this.shape_49}]}, 1).to({state: [{t: this.shape_50}]}, 1).to({state: [{t: this.shape_51}]}, 1).to({state: [{t: this.shape_52}]}, 1).to({state: [{t: this.shape_53}]}, 1).to({state: [{t: this.shape_54}]}, 1).to({state: [{t: this.shape_55}]}, 1).to({state: [{t: this.shape_56}]}, 1).to({state: [{t: this.shape_57}]}, 1).to({state: [{t: this.shape_58}]}, 1).to({state: [{t: this.shape_59}]}, 1).to({state: [{t: this.shape_60}]}, 1).to({state: [{t: this.shape_61}]}, 1).to({state: [{t: this.shape_62}]}, 1).to({state: [{t: this.shape_63}]}, 1).to({state: [{t: this.shape_64}]}, 1).to({state: [{t: this.shape_65}]}, 1).to({state: [{t: this.shape_66}]}, 1).to({state: [{t: this.shape_67}]}, 1).to({state: [{t: this.shape_68}]}, 1).to({state: [{t: this.shape_69}]}, 1).to({state: [{t: this.shape_70}]}, 1).to({state: [{t: this.shape_71}]}, 1).to({state: [{t: this.shape_72}]}, 1).to({state: [{t: this.shape_73}]}, 1).to({state: [{t: this.shape_74}]}, 1).to({state: [{t: this.shape_75}]}, 1).to({state: [{t: this.shape_76}]}, 1).to({state: [{t: this.shape_77}]}, 1).to({state: [{t: this.shape_78}]}, 1).to({state: [{t: this.shape_79}]}, 1).to({state: [{t: this.shape_80}]}, 1).to({state: [{t: this.shape_81}]}, 1).to({state: [{t: this.shape_82}]}, 1).to({state: [{t: this.shape_83}]}, 1).to({state: [{t: this.shape_84}]}, 1).to({state: [{t: this.shape_85}]}, 1).to({state: [{t: this.shape_86}]}, 1).to({state: [{t: this.shape_87}]}, 1).to({state: [{t: this.shape_88}]}, 1).to({state: [{t: this.shape_89}]}, 1).to({state: [{t: this.shape_90}]}, 1).to({state: [{t: this.shape_91}]}, 1).to({state: [{t: this.shape_92}]}, 1).to({state: [{t: this.shape_93}]}, 1).to({state: [{t: this.shape_94}]}, 1).to({state: [{t: this.shape_95}]}, 1).to({state: [{t: this.shape_96}]}, 1).to({state: [{t: this.shape_97}]}, 1).to({state: [{t: this.shape_98}]}, 1).to({state: [{t: this.shape_99}]}, 1).to({state: [{t: this.shape_100}]}, 1).wait(101));

        // Capa 2
        this.shape_101 = new cjs.Shape();
        this.shape_101.graphics.lf(["#000000", "#FFFFFF"], [0.894, 1], -21.2, -17, 3.1, 25.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_101.setTransform(18.2, 18.2);

        this.shape_102 = new cjs.Shape();
        this.shape_102.graphics.lf(["#000000", "#FFFFFF"], [0.885, 0.996], -21.3, -16.8, 3.3, 25).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_102.setTransform(18.2, 18.2);

        this.shape_103 = new cjs.Shape();
        this.shape_103.graphics.lf(["#000000", "#FFFFFF"], [0.876, 0.992], -21.4, -16.5, 3.4, 24.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_103.setTransform(18.2, 18.2);

        this.shape_104 = new cjs.Shape();
        this.shape_104.graphics.lf(["#000000", "#FFFFFF"], [0.867, 0.988], -21.4, -16.2, 3.6, 24.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_104.setTransform(18.2, 18.2);

        this.shape_105 = new cjs.Shape();
        this.shape_105.graphics.lf(["#000000", "#FFFFFF"], [0.858, 0.984], -21.6, -16, 3.7, 24.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_105.setTransform(18.2, 18.2);

        this.shape_106 = new cjs.Shape();
        this.shape_106.graphics.lf(["#000000", "#FFFFFF"], [0.849, 0.98], -21.6, -15.8, 3.9, 24.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_106.setTransform(18.2, 18.2);

        this.shape_107 = new cjs.Shape();
        this.shape_107.graphics.lf(["#000000", "#FFFFFF"], [0.84, 0.976], -21.7, -15.5, 4.1, 24.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_107.setTransform(18.2, 18.2);

        this.shape_108 = new cjs.Shape();
        this.shape_108.graphics.lf(["#000000", "#FFFFFF"], [0.832, 0.971], -21.8, -15.2, 4.2, 24).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_108.setTransform(18.2, 18.2);

        this.shape_109 = new cjs.Shape();
        this.shape_109.graphics.lf(["#000000", "#FFFFFF"], [0.823, 0.967], -21.9, -15, 4.4, 23.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_109.setTransform(18.2, 18.2);

        this.shape_110 = new cjs.Shape();
        this.shape_110.graphics.lf(["#000000", "#FFFFFF"], [0.814, 0.963], -22, -14.8, 4.5, 23.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_110.setTransform(18.2, 18.2);

        this.shape_111 = new cjs.Shape();
        this.shape_111.graphics.lf(["#000000", "#FFFFFF"], [0.805, 0.959], -22, -14.5, 4.7, 23.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_111.setTransform(18.2, 18.2);

        this.shape_112 = new cjs.Shape();
        this.shape_112.graphics.lf(["#000000", "#FFFFFF"], [0.796, 0.955], -22.1, -14.3, 4.9, 23.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_112.setTransform(18.2, 18.2);

        this.shape_113 = new cjs.Shape();
        this.shape_113.graphics.lf(["#000000", "#FFFFFF"], [0.787, 0.951], -22.2, -14, 5, 23.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_113.setTransform(18.2, 18.2);

        this.shape_114 = new cjs.Shape();
        this.shape_114.graphics.lf(["#000000", "#FFFFFF"], [0.778, 0.947], -22.3, -13.8, 5.2, 22.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_114.setTransform(18.2, 18.2);

        this.shape_115 = new cjs.Shape();
        this.shape_115.graphics.lf(["#000000", "#FFFFFF"], [0.769, 0.943], -22.4, -13.5, 5.3, 22.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_115.setTransform(18.2, 18.2);

        this.shape_116 = new cjs.Shape();
        this.shape_116.graphics.lf(["#000000", "#FFFFFF"], [0.76, 0.939], -22.5, -13.3, 5.5, 22.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_116.setTransform(18.2, 18.2);

        this.shape_117 = new cjs.Shape();
        this.shape_117.graphics.lf(["#000000", "#FFFFFF"], [0.751, 0.935], -22.6, -13, 5.6, 22.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_117.setTransform(18.2, 18.2);

        this.shape_118 = new cjs.Shape();
        this.shape_118.graphics.lf(["#000000", "#FFFFFF"], [0.742, 0.931], -22.7, -12.8, 5.8, 22.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_118.setTransform(18.2, 18.2);

        this.shape_119 = new cjs.Shape();
        this.shape_119.graphics.lf(["#000000", "#FFFFFF"], [0.733, 0.927], -22.7, -12.6, 6, 22).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_119.setTransform(18.2, 18.2);

        this.shape_120 = new cjs.Shape();
        this.shape_120.graphics.lf(["#000000", "#FFFFFF"], [0.724, 0.923], -22.8, -12.3, 6.2, 21.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_120.setTransform(18.2, 18.2);

        this.shape_121 = new cjs.Shape();
        this.shape_121.graphics.lf(["#000000", "#FFFFFF"], [0.715, 0.918], -22.9, -12, 6.3, 21.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_121.setTransform(18.2, 18.2);

        this.shape_122 = new cjs.Shape();
        this.shape_122.graphics.lf(["#000000", "#FFFFFF"], [0.706, 0.914], -23, -11.8, 6.5, 21.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_122.setTransform(18.2, 18.2);

        this.shape_123 = new cjs.Shape();
        this.shape_123.graphics.lf(["#000000", "#FFFFFF"], [0.697, 0.91], -23.1, -11.6, 6.6, 21.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_123.setTransform(18.2, 18.2);

        this.shape_124 = new cjs.Shape();
        this.shape_124.graphics.lf(["#000000", "#FFFFFF"], [0.688, 0.906], -23.1, -11.3, 6.8, 21.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_124.setTransform(18.2, 18.2);

        this.shape_125 = new cjs.Shape();
        this.shape_125.graphics.lf(["#000000", "#FFFFFF"], [0.68, 0.902], -23.3, -11, 6.9, 21).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_125.setTransform(18.2, 18.2);

        this.shape_126 = new cjs.Shape();
        this.shape_126.graphics.lf(["#000000", "#FFFFFF"], [0.671, 0.898], -23.3, -10.8, 7.1, 20.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_126.setTransform(18.2, 18.2);

        this.shape_127 = new cjs.Shape();
        this.shape_127.graphics.lf(["#000000", "#FFFFFF"], [0.662, 0.894], -23.4, -10.6, 7.3, 20.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_127.setTransform(18.2, 18.2);

        this.shape_128 = new cjs.Shape();
        this.shape_128.graphics.lf(["#000000", "#FFFFFF"], [0.653, 0.89], -23.5, -10.3, 7.4, 20.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_128.setTransform(18.2, 18.2);

        this.shape_129 = new cjs.Shape();
        this.shape_129.graphics.lf(["#000000", "#FFFFFF"], [0.644, 0.886], -23.6, -10, 7.6, 20.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_129.setTransform(18.2, 18.2);

        this.shape_130 = new cjs.Shape();
        this.shape_130.graphics.lf(["#000000", "#FFFFFF"], [0.635, 0.882], -23.7, -9.8, 7.7, 20.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_130.setTransform(18.2, 18.2);

        this.shape_131 = new cjs.Shape();
        this.shape_131.graphics.lf(["#000000", "#FFFFFF"], [0.626, 0.878], -23.7, -9.6, 7.9, 19.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_131.setTransform(18.2, 18.2);

        this.shape_132 = new cjs.Shape();
        this.shape_132.graphics.lf(["#000000", "#FFFFFF"], [0.617, 0.874], -23.8, -9.3, 8.1, 19.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_132.setTransform(18.2, 18.2);

        this.shape_133 = new cjs.Shape();
        this.shape_133.graphics.lf(["#000000", "#FFFFFF"], [0.608, 0.869], -23.9, -9.1, 8.2, 19.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_133.setTransform(18.2, 18.2);

        this.shape_134 = new cjs.Shape();
        this.shape_134.graphics.lf(["#000000", "#FFFFFF"], [0.599, 0.865], -24, -8.8, 8.4, 19.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_134.setTransform(18.2, 18.2);

        this.shape_135 = new cjs.Shape();
        this.shape_135.graphics.lf(["#000000", "#FFFFFF"], [0.59, 0.861], -24.1, -8.6, 8.5, 19.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_135.setTransform(18.2, 18.2);

        this.shape_136 = new cjs.Shape();
        this.shape_136.graphics.lf(["#000000", "#FFFFFF"], [0.581, 0.857], -24.1, -8.3, 8.7, 19.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_136.setTransform(18.2, 18.2);

        this.shape_137 = new cjs.Shape();
        this.shape_137.graphics.lf(["#000000", "#FFFFFF"], [0.572, 0.853], -24.3, -8.1, 8.8, 18.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_137.setTransform(18.2, 18.2);

        this.shape_138 = new cjs.Shape();
        this.shape_138.graphics.lf(["#000000", "#FFFFFF"], [0.563, 0.849], -24.3, -7.8, 9, 18.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_138.setTransform(18.2, 18.2);

        this.shape_139 = new cjs.Shape();
        this.shape_139.graphics.lf(["#000000", "#FFFFFF"], [0.554, 0.845], -24.4, -7.6, 9.2, 18.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_139.setTransform(18.2, 18.2);

        this.shape_140 = new cjs.Shape();
        this.shape_140.graphics.lf(["#000000", "#FFFFFF"], [0.545, 0.841], -24.5, -7.3, 9.4, 18.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_140.setTransform(18.2, 18.2);

        this.shape_141 = new cjs.Shape();
        this.shape_141.graphics.lf(["#000000", "#FFFFFF"], [0.536, 0.837], -24.6, -7.1, 9.5, 18.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_141.setTransform(18.2, 18.2);

        this.shape_142 = new cjs.Shape();
        this.shape_142.graphics.lf(["#000000", "#FFFFFF"], [0.528, 0.833], -24.7, -6.8, 9.6, 18).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_142.setTransform(18.2, 18.2);

        this.shape_143 = new cjs.Shape();
        this.shape_143.graphics.lf(["#000000", "#FFFFFF"], [0.519, 0.829], -24.8, -6.6, 9.8, 17.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_143.setTransform(18.2, 18.2);

        this.shape_144 = new cjs.Shape();
        this.shape_144.graphics.lf(["#000000", "#FFFFFF"], [0.51, 0.825], -24.8, -6.4, 10, 17.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_144.setTransform(18.2, 18.2);

        this.shape_145 = new cjs.Shape();
        this.shape_145.graphics.lf(["#000000", "#FFFFFF"], [0.501, 0.821], -24.9, -6.1, 10.1, 17.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_145.setTransform(18.2, 18.2);

        this.shape_146 = new cjs.Shape();
        this.shape_146.graphics.lf(["#000000", "#FFFFFF"], [0.492, 0.816], -25, -5.9, 10.3, 17.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_146.setTransform(18.2, 18.2);

        this.shape_147 = new cjs.Shape();
        this.shape_147.graphics.lf(["#000000", "#FFFFFF"], [0.483, 0.812], -25.1, -5.6, 10.5, 17.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_147.setTransform(18.2, 18.2);

        this.shape_148 = new cjs.Shape();
        this.shape_148.graphics.lf(["#000000", "#FFFFFF"], [0.474, 0.808], -25.2, -5.4, 10.6, 16.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_148.setTransform(18.2, 18.2);

        this.shape_149 = new cjs.Shape();
        this.shape_149.graphics.lf(["#000000", "#FFFFFF"], [0.465, 0.804], -25.3, -5.1, 10.7, 16.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_149.setTransform(18.2, 18.2);

        this.shape_150 = new cjs.Shape();
        this.shape_150.graphics.lf(["#000000", "#FFFFFF"], [0.456, 0.8], -25.4, -4.9, 10.9, 16.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_150.setTransform(18.2, 18.2);

        this.shape_151 = new cjs.Shape();
        this.shape_151.graphics.lf(["#000000", "#FFFFFF"], [0.447, 0.796], -25.4, -4.6, 11.1, 16.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_151.setTransform(18.2, 18.2);

        this.shape_152 = new cjs.Shape();
        this.shape_152.graphics.lf(["#000000", "#FFFFFF"], [0.438, 0.792], -25.5, -4.4, 11.3, 16.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_152.setTransform(18.2, 18.2);

        this.shape_153 = new cjs.Shape();
        this.shape_153.graphics.lf(["#000000", "#FFFFFF"], [0.429, 0.788], -25.6, -4.1, 11.4, 16.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_153.setTransform(18.2, 18.2);

        this.shape_154 = new cjs.Shape();
        this.shape_154.graphics.lf(["#000000", "#FFFFFF"], [0.42, 0.784], -25.7, -3.9, 11.6, 15.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_154.setTransform(18.2, 18.2);

        this.shape_155 = new cjs.Shape();
        this.shape_155.graphics.lf(["#000000", "#FFFFFF"], [0.411, 0.78], -25.8, -3.6, 11.7, 15.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_155.setTransform(18.2, 18.2);

        this.shape_156 = new cjs.Shape();
        this.shape_156.graphics.lf(["#000000", "#FFFFFF"], [0.402, 0.776], -25.8, -3.4, 11.9, 15.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_156.setTransform(18.2, 18.2);

        this.shape_157 = new cjs.Shape();
        this.shape_157.graphics.lf(["#000000", "#FFFFFF"], [0.393, 0.772], -26, -3.1, 12, 15.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_157.setTransform(18.2, 18.2);

        this.shape_158 = new cjs.Shape();
        this.shape_158.graphics.lf(["#000000", "#FFFFFF"], [0.384, 0.768], -26, -2.9, 12.2, 15.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_158.setTransform(18.2, 18.2);

        this.shape_159 = new cjs.Shape();
        this.shape_159.graphics.lf(["#000000", "#FFFFFF"], [0.376, 0.763], -26.1, -2.7, 12.4, 15).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_159.setTransform(18.2, 18.2);

        this.shape_160 = new cjs.Shape();
        this.shape_160.graphics.lf(["#000000", "#FFFFFF"], [0.367, 0.759], -26.2, -2.4, 12.5, 14.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_160.setTransform(18.2, 18.2);

        this.shape_161 = new cjs.Shape();
        this.shape_161.graphics.lf(["#000000", "#FFFFFF"], [0.358, 0.755], -26.3, -2.1, 12.7, 14.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_161.setTransform(18.2, 18.2);

        this.shape_162 = new cjs.Shape();
        this.shape_162.graphics.lf(["#000000", "#FFFFFF"], [0.349, 0.751], -26.4, -1.9, 12.8, 14.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_162.setTransform(18.2, 18.2);

        this.shape_163 = new cjs.Shape();
        this.shape_163.graphics.lf(["#000000", "#FFFFFF"], [0.34, 0.747], -26.4, -1.7, 13, 14.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_163.setTransform(18.2, 18.2);

        this.shape_164 = new cjs.Shape();
        this.shape_164.graphics.lf(["#000000", "#FFFFFF"], [0.331, 0.743], -26.5, -1.4, 13.2, 14.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_164.setTransform(18.2, 18.2);

        this.shape_165 = new cjs.Shape();
        this.shape_165.graphics.lf(["#000000", "#FFFFFF"], [0.322, 0.739], -26.6, -1.1, 13.3, 14).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_165.setTransform(18.2, 18.2);

        this.shape_166 = new cjs.Shape();
        this.shape_166.graphics.lf(["#000000", "#FFFFFF"], [0.313, 0.735], -26.7, -0.9, 13.5, 13.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_166.setTransform(18.2, 18.2);

        this.shape_167 = new cjs.Shape();
        this.shape_167.graphics.lf(["#000000", "#FFFFFF"], [0.304, 0.731], -26.8, -0.7, 13.6, 13.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_167.setTransform(18.2, 18.2);

        this.shape_168 = new cjs.Shape();
        this.shape_168.graphics.lf(["#000000", "#FFFFFF"], [0.295, 0.727], -26.9, -0.4, 13.8, 13.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_168.setTransform(18.2, 18.2);

        this.shape_169 = new cjs.Shape();
        this.shape_169.graphics.lf(["#000000", "#FFFFFF"], [0.286, 0.723], -27, -0.2, 13.9, 13.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_169.setTransform(18.2, 18.2);

        this.shape_170 = new cjs.Shape();
        this.shape_170.graphics.lf(["#000000", "#FFFFFF"], [0.277, 0.719], -27.1, 0, 14.1, 13.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_170.setTransform(18.2, 18.2);

        this.shape_171 = new cjs.Shape();
        this.shape_171.graphics.lf(["#000000", "#FFFFFF"], [0.268, 0.715], -27.1, 0.2, 14.3, 12.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_171.setTransform(18.2, 18.2);

        this.shape_172 = new cjs.Shape();
        this.shape_172.graphics.lf(["#000000", "#FFFFFF"], [0.259, 0.71], -27.2, 0.5, 14.5, 12.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_172.setTransform(18.2, 18.2);

        this.shape_173 = new cjs.Shape();
        this.shape_173.graphics.lf(["#000000", "#FFFFFF"], [0.25, 0.706], -27.3, 0.7, 14.6, 12.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_173.setTransform(18.2, 18.2);

        this.shape_174 = new cjs.Shape();
        this.shape_174.graphics.lf(["#000000", "#FFFFFF"], [0.241, 0.702], -27.4, 1, 14.8, 12.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_174.setTransform(18.2, 18.2);

        this.shape_175 = new cjs.Shape();
        this.shape_175.graphics.lf(["#000000", "#FFFFFF"], [0.232, 0.698], -27.5, 1.2, 14.9, 12.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_175.setTransform(18.2, 18.2);

        this.shape_176 = new cjs.Shape();
        this.shape_176.graphics.lf(["#000000", "#FFFFFF"], [0.224, 0.694], -27.5, 1.5, 15.1, 12.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_176.setTransform(18.2, 18.2);

        this.shape_177 = new cjs.Shape();
        this.shape_177.graphics.lf(["#000000", "#FFFFFF"], [0.215, 0.69], -27.7, 1.7, 15.2, 11.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_177.setTransform(18.2, 18.2);

        this.shape_178 = new cjs.Shape();
        this.shape_178.graphics.lf(["#000000", "#FFFFFF"], [0.206, 0.686], -27.7, 2, 15.4, 11.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_178.setTransform(18.2, 18.2);

        this.shape_179 = new cjs.Shape();
        this.shape_179.graphics.lf(["#000000", "#FFFFFF"], [0.197, 0.682], -27.8, 2.2, 15.6, 11.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_179.setTransform(18.2, 18.2);

        this.shape_180 = new cjs.Shape();
        this.shape_180.graphics.lf(["#000000", "#FFFFFF"], [0.188, 0.678], -27.9, 2.4, 15.7, 11.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_180.setTransform(18.2, 18.2);

        this.shape_181 = new cjs.Shape();
        this.shape_181.graphics.lf(["#000000", "#FFFFFF"], [0.179, 0.674], -28, 2.7, 15.9, 11.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_181.setTransform(18.2, 18.2);

        this.shape_182 = new cjs.Shape();
        this.shape_182.graphics.lf(["#000000", "#FFFFFF"], [0.17, 0.67], -28.1, 3, 16, 11).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_182.setTransform(18.2, 18.2);

        this.shape_183 = new cjs.Shape();
        this.shape_183.graphics.lf(["#000000", "#FFFFFF"], [0.161, 0.666], -28.1, 3.2, 16.2, 10.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_183.setTransform(18.2, 18.2);

        this.shape_184 = new cjs.Shape();
        this.shape_184.graphics.lf(["#000000", "#FFFFFF"], [0.152, 0.661], -28.2, 3.4, 16.4, 10.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_184.setTransform(18.2, 18.2);

        this.shape_185 = new cjs.Shape();
        this.shape_185.graphics.lf(["#000000", "#FFFFFF"], [0.143, 0.657], -28.3, 3.7, 16.5, 10.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_185.setTransform(18.2, 18.2);

        this.shape_186 = new cjs.Shape();
        this.shape_186.graphics.lf(["#000000", "#FFFFFF"], [0.134, 0.653], -28.4, 4, 16.7, 10.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_186.setTransform(18.2, 18.2);

        this.shape_187 = new cjs.Shape();
        this.shape_187.graphics.lf(["#000000", "#FFFFFF"], [0.125, 0.649], -28.5, 4.2, 16.8, 10.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_187.setTransform(18.2, 18.2);

        this.shape_188 = new cjs.Shape();
        this.shape_188.graphics.lf(["#000000", "#FFFFFF"], [0.116, 0.645], -28.5, 4.4, 17, 9.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_188.setTransform(18.2, 18.2);

        this.shape_189 = new cjs.Shape();
        this.shape_189.graphics.lf(["#000000", "#FFFFFF"], [0.107, 0.641], -28.7, 4.7, 17.1, 9.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_189.setTransform(18.2, 18.2);

        this.shape_190 = new cjs.Shape();
        this.shape_190.graphics.lf(["#000000", "#FFFFFF"], [0.098, 0.637], -28.7, 5, 17.3, 9.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_190.setTransform(18.2, 18.2);

        this.shape_191 = new cjs.Shape();
        this.shape_191.graphics.lf(["#000000", "#FFFFFF"], [0.089, 0.633], -28.8, 5.2, 17.5, 9.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_191.setTransform(18.2, 18.2);

        this.shape_192 = new cjs.Shape();
        this.shape_192.graphics.lf(["#000000", "#FFFFFF"], [0.08, 0.629], -28.9, 5.4, 17.7, 9.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_192.setTransform(18.2, 18.2);

        this.shape_193 = new cjs.Shape();
        this.shape_193.graphics.lf(["#000000", "#FFFFFF"], [0.072, 0.625], -29, 5.7, 17.8, 9.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_193.setTransform(18.2, 18.2);

        this.shape_194 = new cjs.Shape();
        this.shape_194.graphics.lf(["#000000", "#FFFFFF"], [0.063, 0.621], -29.1, 5.9, 17.9, 8.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_194.setTransform(18.2, 18.2);

        this.shape_195 = new cjs.Shape();
        this.shape_195.graphics.lf(["#000000", "#FFFFFF"], [0.054, 0.617], -29.2, 6.2, 18.1, 8.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_195.setTransform(18.2, 18.2);

        this.shape_196 = new cjs.Shape();
        this.shape_196.graphics.lf(["#000000", "#FFFFFF"], [0.045, 0.613], -29.2, 6.4, 18.3, 8.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_196.setTransform(18.2, 18.2);

        this.shape_197 = new cjs.Shape();
        this.shape_197.graphics.lf(["#000000", "#FFFFFF"], [0.036, 0.608], -29.3, 6.7, 18.4, 8.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_197.setTransform(18.2, 18.2);

        this.shape_198 = new cjs.Shape();
        this.shape_198.graphics.lf(["#000000", "#FFFFFF"], [0.027, 0.604], -29.4, 6.9, 18.6, 8.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_198.setTransform(18.2, 18.2);

        this.shape_199 = new cjs.Shape();
        this.shape_199.graphics.lf(["#000000", "#FFFFFF"], [0.018, 0.6], -29.5, 7.2, 18.8, 8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_199.setTransform(18.2, 18.2);

        this.shape_200 = new cjs.Shape();
        this.shape_200.graphics.lf(["#000000", "#FFFFFF"], [0.009, 0.596], -29.6, 7.4, 18.9, 7.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_200.setTransform(18.2, 18.2);

        this.shape_201 = new cjs.Shape();
        this.shape_201.graphics.lf(["#000000", "#FFFFFF"], [0, 0.592], -29.7, 7.7, 19, 7.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
        this.shape_201.setTransform(18.2, 18.2);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_101}]}).to({state: [{t: this.shape_102}]}, 1).to({state: [{t: this.shape_103}]}, 1).to({state: [{t: this.shape_104}]}, 1).to({state: [{t: this.shape_105}]}, 1).to({state: [{t: this.shape_106}]}, 1).to({state: [{t: this.shape_107}]}, 1).to({state: [{t: this.shape_108}]}, 1).to({state: [{t: this.shape_109}]}, 1).to({state: [{t: this.shape_110}]}, 1).to({state: [{t: this.shape_111}]}, 1).to({state: [{t: this.shape_112}]}, 1).to({state: [{t: this.shape_113}]}, 1).to({state: [{t: this.shape_114}]}, 1).to({state: [{t: this.shape_115}]}, 1).to({state: [{t: this.shape_116}]}, 1).to({state: [{t: this.shape_117}]}, 1).to({state: [{t: this.shape_118}]}, 1).to({state: [{t: this.shape_119}]}, 1).to({state: [{t: this.shape_120}]}, 1).to({state: [{t: this.shape_121}]}, 1).to({state: [{t: this.shape_122}]}, 1).to({state: [{t: this.shape_123}]}, 1).to({state: [{t: this.shape_124}]}, 1).to({state: [{t: this.shape_125}]}, 1).to({state: [{t: this.shape_126}]}, 1).to({state: [{t: this.shape_127}]}, 1).to({state: [{t: this.shape_128}]}, 1).to({state: [{t: this.shape_129}]}, 1).to({state: [{t: this.shape_130}]}, 1).to({state: [{t: this.shape_131}]}, 1).to({state: [{t: this.shape_132}]}, 1).to({state: [{t: this.shape_133}]}, 1).to({state: [{t: this.shape_134}]}, 1).to({state: [{t: this.shape_135}]}, 1).to({state: [{t: this.shape_136}]}, 1).to({state: [{t: this.shape_137}]}, 1).to({state: [{t: this.shape_138}]}, 1).to({state: [{t: this.shape_139}]}, 1).to({state: [{t: this.shape_140}]}, 1).to({state: [{t: this.shape_141}]}, 1).to({state: [{t: this.shape_142}]}, 1).to({state: [{t: this.shape_143}]}, 1).to({state: [{t: this.shape_144}]}, 1).to({state: [{t: this.shape_145}]}, 1).to({state: [{t: this.shape_146}]}, 1).to({state: [{t: this.shape_147}]}, 1).to({state: [{t: this.shape_148}]}, 1).to({state: [{t: this.shape_149}]}, 1).to({state: [{t: this.shape_150}]}, 1).to({state: [{t: this.shape_151}]}, 1).to({state: [{t: this.shape_152}]}, 1).to({state: [{t: this.shape_153}]}, 1).to({state: [{t: this.shape_154}]}, 1).to({state: [{t: this.shape_155}]}, 1).to({state: [{t: this.shape_156}]}, 1).to({state: [{t: this.shape_157}]}, 1).to({state: [{t: this.shape_158}]}, 1).to({state: [{t: this.shape_159}]}, 1).to({state: [{t: this.shape_160}]}, 1).to({state: [{t: this.shape_161}]}, 1).to({state: [{t: this.shape_162}]}, 1).to({state: [{t: this.shape_163}]}, 1).to({state: [{t: this.shape_164}]}, 1).to({state: [{t: this.shape_165}]}, 1).to({state: [{t: this.shape_166}]}, 1).to({state: [{t: this.shape_167}]}, 1).to({state: [{t: this.shape_168}]}, 1).to({state: [{t: this.shape_169}]}, 1).to({state: [{t: this.shape_170}]}, 1).to({state: [{t: this.shape_171}]}, 1).to({state: [{t: this.shape_172}]}, 1).to({state: [{t: this.shape_173}]}, 1).to({state: [{t: this.shape_174}]}, 1).to({state: [{t: this.shape_175}]}, 1).to({state: [{t: this.shape_176}]}, 1).to({state: [{t: this.shape_177}]}, 1).to({state: [{t: this.shape_178}]}, 1).to({state: [{t: this.shape_179}]}, 1).to({state: [{t: this.shape_180}]}, 1).to({state: [{t: this.shape_181}]}, 1).to({state: [{t: this.shape_182}]}, 1).to({state: [{t: this.shape_183}]}, 1).to({state: [{t: this.shape_184}]}, 1).to({state: [{t: this.shape_185}]}, 1).to({state: [{t: this.shape_186}]}, 1).to({state: [{t: this.shape_187}]}, 1).to({state: [{t: this.shape_188}]}, 1).to({state: [{t: this.shape_189}]}, 1).to({state: [{t: this.shape_190}]}, 1).to({state: [{t: this.shape_191}]}, 1).to({state: [{t: this.shape_192}]}, 1).to({state: [{t: this.shape_193}]}, 1).to({state: [{t: this.shape_194}]}, 1).to({state: [{t: this.shape_195}]}, 1).to({state: [{t: this.shape_196}]}, 1).to({state: [{t: this.shape_197}]}, 1).to({state: [{t: this.shape_198}]}, 1).to({state: [{t: this.shape_199}]}, 1).to({state: [{t: this.shape_200}]}, 1).to({state: [{t: this.shape_201}]}, 1).to({state: []}, 1).wait(100));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-9.2, 0, 45.7, 45.6);


    (lib.fnd_loader = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000000").s().p("EhKNAu4MAAAhdvMCUbAAAMAAABdvg");
        this.shape.setTransform(475, 304.1, 1, 1.014);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608.1);


    (lib.cuadrobotcA = function () {
        this.initialize();

        this.text = new cjs.Text("Iniciar", "bold 14px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 16;

        this.text.setTransform(0, -4.3);

        // Capa 1
        this.instance = new lib.Símbolo147();
        this.instance.setTransform(0, 2.6, .5, 0.865);
        this.instance.alpha = 0.16;

        this.addChild(this.instance, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-90, -7.3, 180.1, 19.9);
    (lib.cuadrobotcB = function () {
        this.initialize();

        this.text = new cjs.Text("Reiniciar", "bold 14px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 16;

        this.text.setTransform(0, -4.3);

        // Capa 1
        this.instance = new lib.Símbolo147();
        this.instance.setTransform(0, 2.6, .5, 0.865);
        this.instance.alpha = 0.16;

        this.addChild(this.instance, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-90, -7.3, 180.1, 19.9);


    (lib.balla = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.ballatrans();
        this.instance.setTransform(-15.9, -50.4);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-15.9, -50.4, 32, 101);


    (lib.Símbolo512 = function () {
        this.initialize();

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("AsYigIRSAAQBVABBKAhQEbB+DKCTI97AOg");
        mask.setTransform(220.2, 444.6);

        // Capa 2
        this.instance = new lib.Símbolo2982("synched", 0);
        this.instance.setTransform(-191.4, -1366.9, 11.727, 1.057, 0, -87.7, 87.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#39585C").s().p("AAEi3ICAgHQhiDuglCHIiAAIQAniHBgjvg");
        this.shape.setTransform(177.8, 444.9);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#39585C").s().p("AiAhzIEBCnIjvBAg");
        this.shape_1.setTransform(305.7, 454.2);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#39585C").s().p("AAYi8ICCgUQgVA1geBBIg1BuIguBiQgTAwgLAeIh/ANg");
        this.shape_2.setTransform(132.7, 444.1);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.lf(["#9CACAE", "#FFFFFF", "#9CACAE"], [0, 0.384, 1], -201.2, -244.9, -35.9, -311.7).s().p("AsXigIRRAAQBVAABKAjQEbB9DKCUI97ANg");
        this.shape_3.setTransform(223.7, 447.7);

        this.instance.mask = this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = mask;

        this.addChild(this.shape_3, this.shape_2, this.shape_1, this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(117.3, 423.2, 202.4, 43.7);


    (lib.mc_loader = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.mc_barras = new lib.mc_loader_barra();
        this.mc_barras.setTransform(22.9, 30.1, 1, 1, 0, 0, 0, 13.6, 22.8);

        this.timeline.addTween(cjs.Tween.get(this.mc_barras).wait(1).to({rotation: 4.6}, 0).wait(1).to({rotation: 9.1, y: 30}, 0).wait(1).to({rotation: 13.7}, 0).wait(1).to({rotation: 18.2}, 0).wait(1).to({rotation: 22.8}, 0).wait(1).to({rotation: 27.3, y: 30.1}, 0).wait(1).to({rotation: 31.9}, 0).wait(1).to({rotation: 36.5}, 0).wait(1).to({rotation: 41, y: 30}, 0).wait(1).to({rotation: 45.6}, 0).wait(1).to({rotation: 50.1}, 0).wait(1).to({rotation: 54.7, y: 30.1}, 0).wait(1).to({rotation: 59.2}, 0).wait(1).to({rotation: 63.8, y: 30}, 0).wait(1).to({rotation: 68.4}, 0).wait(1).to({rotation: 72.9, y: 30.1}, 0).wait(1).to({rotation: 77.5}, 0).wait(1).to({rotation: 82, y: 30}, 0).wait(1).to({rotation: 86.6, y: 30.1}, 0).wait(1).to({rotation: 91.1}, 0).wait(1).to({rotation: 95.7}, 0).wait(1).to({rotation: 100.3}, 0).wait(1).to({rotation: 104.8, y: 30}, 0).wait(1).to({rotation: 109.4, y: 30.1}, 0).wait(1).to({rotation: 113.9}, 0).wait(1).to({rotation: 118.5}, 0).wait(1).to({rotation: 123, y: 30}, 0).wait(1).to({rotation: 127.6, y: 30.1}, 0).wait(1).to({rotation: 132.2}, 0).wait(1).to({rotation: 136.7}, 0).wait(1).to({rotation: 141.3, y: 30}, 0).wait(1).to({rotation: 145.8, y: 30.1}, 0).wait(1).to({rotation: 150.4, y: 30}, 0).wait(1).to({rotation: 154.9}, 0).wait(1).to({rotation: 159.5}, 0).wait(1).to({rotation: 164.1, y: 30.1}, 0).wait(1).to({rotation: 168.6}, 0).wait(1).to({rotation: 173.2, y: 30}, 0).wait(1).to({rotation: 177.7}, 0).wait(1).to({rotation: 182.4}, 0).wait(1).to({rotation: 186.9, y: 30.1}, 0).wait(1).to({rotation: 191.5, y: 30}, 0).wait(1).to({rotation: 196, y: 30.1}, 0).wait(1).to({rotation: 200.6}, 0).wait(1).to({rotation: 205.2}, 0).wait(1).to({rotation: 209.7}, 0).wait(1).to({rotation: 214.3}, 0).wait(1).to({rotation: 218.8, y: 30}, 0).wait(1).to({rotation: 223.4}, 0).wait(1).to({rotation: 227.9}, 0).wait(1).to({rotation: 232.5}, 0).wait(1).to({rotation: 237.1}, 0).wait(1).to({rotation: 241.6, y: 30.1}, 0).wait(1).to({rotation: 246.2, y: 30}, 0).wait(1).to({rotation: 250.7}, 0).wait(1).to({rotation: 255.3}, 0).wait(1).to({rotation: 259.8}, 0).wait(1).to({rotation: 264.4}, 0).wait(1).to({rotation: 269, y: 30.1}, 0).wait(1).to({rotation: 273.5, y: 30}, 0).wait(1).to({rotation: 278.1, x: 23, y: 30.1}, 0).wait(1).to({rotation: 282.6, x: 22.9, y: 30}, 0).wait(1).to({rotation: 287.2, x: 23}, 0).wait(1).to({rotation: 291.7, x: 22.9}, 0).wait(1).to({rotation: 296.3}, 0).wait(1).to({rotation: 300.9, x: 23}, 0).wait(1).to({rotation: 305.4, x: 22.9, y: 30.1}, 0).wait(1).to({rotation: 310, y: 30}, 0).wait(1).to({rotation: 314.5, y: 30.1}, 0).wait(1).to({rotation: 319.1}, 0).wait(1).to({rotation: 323.6, x: 23, y: 30}, 0).wait(1).to({rotation: 328.2}, 0).wait(1).to({rotation: 332.8, x: 22.9}, 0).wait(1).to({rotation: 337.3}, 0).wait(1).to({rotation: 341.9}, 0).wait(1).to({rotation: 346.4, y: 30.1}, 0).wait(1).to({rotation: 351, y: 30}, 0).wait(1).to({rotation: 355.5, y: 30.1}, 0).wait(1).to({rotation: 360}, 0).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-1.9, 5.1, 49.8, 49.8);


    (lib.gir = function () {
        this.initialize();

        // Capa 5
        this.instance = new lib.Símbolo519("synched", 0);
        this.instance.setTransform(-114, -349.4, 0.688, 0.689);

        this.instance_1 = new lib.Símbolo515("synched", 0);
        this.instance_1.setTransform(-27, -83.4, 0.164, 0.164);

        this.instance_2 = new lib.Símbolo518("synched", 0);
        this.instance_2.setTransform(-114, -349.4, 0.688, 0.689);

        this.instance_3 = new lib.Símbolo517("synched", 0);
        this.instance_3.setTransform(-114, -349.4, 0.688, 0.689);

        this.instance_4 = new lib.Símbolo516("synched", 0);
        this.instance_4.setTransform(-114, -349.4, 0.688, 0.689);

        this.instance_5 = new lib.Símbolo515("synched", 0);
        this.instance_5.setTransform(-114, -349.4, 0.688, 0.689);

        this.instance_6 = new lib.Símbolo514("synched", 0);
        this.instance_6.setTransform(-114, -349.4, 0.688, 0.689);

        this.addChild(this.instance_6, this.instance_5, this.instance_4, this.instance_3, this.instance_2, this.instance_1, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-14, -14.2, 28.5, 28.5);


    (lib.area_botocA = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.instance = new lib.cuadrobotcA();
        this.instance.setTransform(0.3, 0.3);
        this.instance._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({_off: false}, 0).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);


    (lib.cuadrobotcA_1 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.Símbolo147();
        this.instance.setTransform(0, 2.6, 1, 0.865);
        this.instance.alpha = 0.16;

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-90, -7.3, 180.1, 19.9);


    (lib.cotxe = function () {
        this.initialize();

        // Capa 1
        this.d = new lib.gir();
        this.d.setTransform(64.8, 10.7);

        this.r = new lib.gir();
        this.r.setTransform(-51, 9.8);

        // Capa 11
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#39585C", "#39585C", "#9CACAE"], [0, 0.525, 1], -147.8, 284, -162.3, 276).s().p("Ag7AvIgIhdICHAdIAABAg");
        this.shape.setTransform(36.1, -27.1, 0.688, 0.768);

        this.instance = new lib.Símbolo513("synched", 0);
        this.instance.setTransform(-149.8, -379.2, 0.688, 0.768);

        this.instance_1 = new lib.Símbolo513("synched", 0);
        this.instance_1.setTransform(-165.3, -379.2, 0.688, 0.768);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#39585C").ss(0.2, 1, 1).p("AHZh+QEbB+DKCTI97ANICllAIRSAAQBVAABKAig");
        this.shape_1.setTransform(-13.8, -37.5, 0.688, 0.768);

        this.instance_2 = new lib.Símbolo512("synched", 0);
        this.instance_2.setTransform(-165.3, -379.2, 0.688, 0.768);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#39585C").ss(0.2, 1, 1).p("AHZh+QEbB+DKCTI97ANICllAIRSAAQBVAABKAig");
        this.shape_2.setTransform(-13.8, -37.5, 0.688, 0.768);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#39585C").s().p("AsYigIRSAAQBVABBKAhQEbB+DKCTI97AOg");
        this.shape_3.setTransform(-13.8, -37.5, 0.688, 0.768);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#39585C").ss(0.2, 1, 1).p("AhCirIAACfQAdAKAZASQAWAUASAbQASAZALAdQAKAcAAAb");
        this.shape_4.setTransform(-38.7, -9);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#39585C").ss(0.2, 1, 1).p("AANDjQAMk/goiG");
        this.shape_5.setTransform(44, -9.1, 0.688, 0.768);

        this.instance_3 = new lib.Símbolo3252("synched", 0);
        this.instance_3.setTransform(48.6, 220.4, 0, 0);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#39585C").s().p("Ag3BMQgBgygRgiQgQgigjghIDeAAQAOAAAHAJQAGAIAAANIAAAtQgEAPgJAPQgJANgLALQgLAKgNAGQgNAGgMAAg");
        this.shape_6.setTransform(88.6, 2.1);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f("#39585C").s().p("Ag/A+QgRAAgIgDQgMgFgCgNIgQhPQgDgOAKgJQAKgHARAAIDMACQg0AqgJBdg");
        this.shape_7.setTransform(-74, 2.8);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f().s("#39585C").ss(0.2, 1, 1).p("AB7ApQBXAuBUAzIhRAHQkfi2jbhrg");
        this.shape_8.setTransform(42.1, -38.9, 0.688, 0.768);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.lf(["#9CACAE", "#FFFFFF", "#9CACAE"], [0, 0.384, 1], -128.8, -260.6, -88, -277.1).s().p("AkliQIGgC5QBXAuBUAzIhRAHQkfi2jbhrg");
        this.shape_9.setTransform(42.1, -38.9, 0.688, 0.768);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f().s("#39585C").ss(0.1, 1, 1).p("AB6kbQDeBYDMCMIEvCHQAbANAMAbQAKAYgEAaIgRCKIh9AAQgDgjgPggQgPgfgXgXQgXgYgdgMQgegNghAAQggAAgeANQgdAMgXAYQgYAXgOAfQgPAggDAjIs7AAQgEgjgOggQgPgfgXgXQgXgYgegMQgegNggAAQghAAgeANQgdAMgXAYQgXAXgPAfQgOAggEAjIiAAAIgMjsQgBgRAJgkQAIggAHgPIB3kDQAEgJAHgFQAIgGAKAAIMHADQApADAfASg");
        this.shape_10.setTransform(7.7, -22.4);

        this.instance_4 = new lib.Símbolo511("synched", 0);
        this.instance_4.setTransform(-165.3, -379.2, 0.688, 0.768);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f().s("#39585C").ss(0.1, 1, 1).p("ACxlxQFDBzEpC1IG4CxQAoARARAkQAOAegFAjIgZCzIi1AAQgGgugVgpQgVgogigfQgigegqgRQgsgRgvAAQgvAAgsARQgqARgiAeQgiAfgVAoQgVApgFAuIyzAAQgFgugWgpQgVgogigfQghgegrgRQgrgRgwAAQgvAAgsARQgqARgiAeQghAfgVAoQgWApgFAuIi6AAIgSkzQgBgWANgvQALgqALgUICtlRQAGgLAKgHQAMgIANAAIRpAEQA8ADAsAYg");
        this.shape_11.setTransform(7.7, -22.4, 0.688, 0.768);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.lf(["#6B8285", "#6B8285", "#E7EBEB", "#9CACAE", "#E7EBEB"], [0, 0.122, 0.345, 0.584, 1], -333.2, 40.1, -333.2, -40).s().p("ARJGRQgGgugVgpQgVgogigfQgigegqgRQgsgRgvAAQgvAAgsARQgqARgiAeQgiAfgVAoQgVApgFAuIyzAAQgFgugWgpQgVgogigfQghgegrgRQgrgRgwAAQgvAAgsARQgqARgiAeQghAfgVAoQgWApgFAuIi6AAIgSkzQgBgWANgvQALgqALgUICtlRQAGgLAKgHQAMgIANAAIRpAEQA8ADAsAYQFDBzEpC1IG4CxQAoARARAkQAOAegFAjIgZCzg");
        this.shape_12.setTransform(7.7, -22.4, 0.688, 0.768);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f("#072E33").s().p("AmbCDIgmgpIlBAAIgDjcIVfAAICsC9IkzAAIhABIg");
        this.shape_13.setTransform(9.2, -0.7);

        this.addChild(this.shape_13, this.shape_12, this.shape_11, this.instance_4, this.shape_10, this.shape_9, this.shape_8, this.shape_7, this.shape_6, this.instance_3, this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.instance_2, this.shape_1, this.instance_1, this.instance, this.shape, this.r, this.d);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-86, -53.3, 187.1, 357.7);


(lib.Mapadebits1b = function() {
	this.initialize(img.Mapadebits1b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,580,243);


(lib.Mapadebits2b = function() {
	this.initialize(img.Mapadebits2b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,580,243);


(lib.Mapadebits3b = function() {
	this.initialize(img.Mapadebits3b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,580,243);

   (lib.carretera3 = function () {
       this.initialize();
        this.c0= new lib.carretera("single", tipo);
        this.c0.setTransform(570-940*2, 317, 0.73, 0.73);
        this.c1= new lib.carretera("single", tipo);
        this.c1.setTransform(570-940, 317, 0.73, 0.73);
        this.c2= new lib.carretera("single", tipo);
        this.c2.setTransform(570, 317, 0.73, 0.73);
        this.c2b= new lib.carretera("single", tipo);
        this.c2b.setTransform(570+940, 317, 0.73, 0.73);
        this.c3= new lib.carretera("single", tipo);
        this.c3.setTransform(570+940*2, 317, 0.73, 0.73);
           this.addChild(this.c0,this.c1,this.c2,this.c2b,this.c3);
        }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-606.7, -151.9, 3476.6, 343.9);
    (lib.carretera = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 15
        this.instance = new lib.neuterra("synched", 0);
        this.instance.setTransform(273.9, 134, 1.01, 1);
        this.instance.alpha = 0.75;

        this.instance_1 = new lib.plujaterra("synched", 0);
        this.instance_1.setTransform(272.9, 134.7, 1.01, 1);
        this.instance_1.alpha = 0.75;

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.instance}]}, 1).to({state: [{t: this.instance_1}]}, 1).wait(1));

// bala
        this.balla = new lib.balla();
        this.balla.setTransform(1094.3, 104.6);

        //this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.balla}]}).wait(3));
 this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.balla}]}).to({state: [{t: this.balla}]}, 1).to({state: [{t: this.balla}]}, 1).wait(1));

        // arbres
        this.instance_2 = new lib.fotofonsarbrescarretera();
        this.instance_2.setTransform(589.9, -151.9, 0.843, 0.962);

        this.instance_3 = new lib.fotofonsarbrescarretera();
        this.instance_3.setTransform(-0.6, -151.9, 0.843, 0.962);

        this.instance_4 = new lib.fotofonsarbrescarretera();
        this.instance_4.setTransform(-591, -151.9, 0.843, 0.962);

     this.instance_5 = new lib.Mapadebits3b();
	this.instance_5.setTransform(591.4,-149.3);

	this.instance_6 = new lib.Mapadebits2b();
	this.instance_6.setTransform(0.6,-149.2);

	this.instance_7 = new lib.Mapadebits1b();
	this.instance_7.setTransform(-588.8,-149.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.neuarbrescarreterapng).s().p("AgwgnQASA4AzAXIABgUQAKhBAYg3IAJABQAEBKgNBBQgJAAgDAEQgXAagSAfQhnhOA0g+g");
	this.shape.setTransform(-46.3,-76.4);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance_4}, {t: this.instance_3}, {t: this.instance_2}]}).to({state: [{t: this.instance_5}, {t: this.instance_6}, {t: this.instance_7}]}, 1).to({state: [{t: this.instance_4}, {t: this.instance_3}, {t: this.instance_2}]}, 1).wait(1));

        // finasl
        this.instance_5 = new lib.fotofonsfinal();
        this.instance_5.setTransform(795.6, 32.4, 0.614, 1.182);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance_5}]}).wait(3));

        // Capa 22
        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f("#666666").s().p("AsMATIAAglIYZAAIAAAlg");
        this.shape_7.setTransform(-240.2, 32.5);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#666666").s().p("Ejs2AATIAAglMHZZAAAIAAACIAUAAIAAAQIgFAGIgPAAIAAANg");
        this.shape_8.setTransform(1353.8, 32.5);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8}, {t: this.shape_7}]}).wait(3));

        // gotes terra
        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f().s("#666666").ss(1, 1, 1).p("EAkLAAAIAdAAEggMAAAIgLAAEgknAAAIAdAAEggXAAAIgnAA");
        this.shape_9.setTransform(1911.7, 21.3);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f("#666666").s().p("EjQgAATIAAglMGhBAAAIAAAlg");
        this.shape_10.setTransform(1016.1, 32.5);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f("rgba(102,153,204,0.6)").s().p("AgEAAIAJAAIgJAAg");
        this.shape_11.setTransform(1705, 21.2);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape_11}, {t: this.shape_10}, {t: this.shape_9}]}, 2).wait(1));

        // herba terra
        this.instance_6 = new lib.fotofons2();
        this.instance_6.setTransform(-606.7, 30.3, 0.525, 1.178);

        this.instance_7 = new lib.fotofons2();
        this.instance_7.setTransform(-233.7, 30.3, 0.525, 1.178);

        this.instance_8 = new lib.fotofons2();
        this.instance_8.setTransform(139.5, 30.3, 0.525, 1.178);

        this.instance_9 = new lib.fotofons2();
        this.instance_9.setTransform(509.6, 30.3, 0.525, 1.178);

        this.instance_10 = new lib.fotofons2();
        this.instance_10.setTransform(882.8, 30.3, 0.525, 1.178);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance_10}, {t: this.instance_9}, {t: this.instance_8}, {t: this.instance_7}, {t: this.instance_6}]}).wait(3));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-606.7, -151.9, 3476.6, 343.9);


    (lib.cotxecau = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.cotxe = new lib.cotxe();
        this.cotxe.setTransform(0.2, 0.1);

        this.timeline.addTween(cjs.Tween.get(this.cotxe).to({x: 249.7, y: 1.7, mode: "synched", startPosition: 0}, 9, cjs.Ease.get(1)).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-85.8, -53.2, 187.2, 357.7);

    (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
    (lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
    (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
    (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
    (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
    (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
    (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.ballaAlAire = function ( mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});
        this.balla = new lib.balla();
        this.balla.setTransform(480, 380);
  
          //this.timeline.addTween(cjs.Tween.get(this.balla).wait(1).to({}, 40).wait(1));
                this.timeline.addTween(cjs.Tween.get(this.balla).wait(1).to({x: 800,y:0}, 20).wait(1));

    
    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
   (lib.moveElement = function (element, distancia, tiempo, mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});
        var d = distancia * 100 / 200;
if (distancia>200){
            tiempo=200*tiempo/distancia;
        }
        var x1 = d / 2 + 170;
        var x2 = d * 7 / 8 + 170;
        var x3 = d + 170;
           if (x1 > 273){
                       x1 = 273;
         this.timeline.addTween(cjs.Tween.get(element).wait(1).to({x: x1}, tiempo * 24).wait(1));
        }
        else
        if (x2  > 273){
            x2 = 273;
            this.timeline.addTween(cjs.Tween.get(element).wait(1).to({x: x1}, tiempo * 16).wait(1).to({x: x2}, tiempo * 8).wait(1));
        }
    else{
        if (x3  > 273)
            x3 =  273;
          this.timeline.addTween(cjs.Tween.get(element).wait(1).to({x: x1}, tiempo * 8).wait(1).to({x: x2}, tiempo * 8).wait(1).to({x: x3}, tiempo * 8).wait(1));
        
    }
    
//        if (x1 > 273)
//            x1 = 273;
//        if (x2 > 273)
//            x2 = 273;
//        if (x3 > 273)
//            x3 = 273;
//        this.timeline.addTween(cjs.Tween.get(element).wait(1).to({x: x1}, tiempo * 8).wait(1).to({x: x2}, tiempo * 8).wait(1).to({x: x3}, tiempo * 8).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.moveElement2 = function (element, distancia, tiempo, mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});
        var d = distancia * 4640 / 200;
        if (distancia>200){
            tiempo=200*tiempo/distancia;
        }
        var x1 = 1850 - d / 2;
        var x2 = 1850 - d * 7 / 8;
        var x3 = 1850 - d;
       
        if (x1 < -2790){
            x1 = -2790;
             this.timeline.addTween(cjs.Tween.get(element).wait(1).to({x: x1}, tiempo * 24).wait(1));
        }
        else
        if (x2 < -2790){
            x2 = -2790;
            this.timeline.addTween(cjs.Tween.get(element).wait(1).to({x: x1}, tiempo * 16).wait(1).to({x: x2}, tiempo * 8).wait(1));
        }
    else{
        if (x3 < -2790)
            x3 = -2790;
          this.timeline.addTween(cjs.Tween.get(element).wait(1).to({x: x1}, tiempo * 8).wait(1).to({x: x2}, tiempo * 8).wait(1).to({x: x3}, tiempo * 8).wait(1));
        
    }

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
 (lib.moveElement3= function (element, distancia, tiempo, mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});
        var d = distancia * 700 / 200;
 if (distancia>200){
            tiempo=200*tiempo/distancia;
        }
        var x1 = 607 - d / 2;
        var x2 = 607 - d * 7 / 8;
        var x3 = 607 - d;
        
        
        if (x1 < -100){
            x1 = -100;
             this.timeline.addTween(cjs.Tween.get(element).wait(1).to({x: x1}, tiempo * 24).wait(1));
        }
        else
        if (x2 < -100){
            x2 = -100;
            this.timeline.addTween(cjs.Tween.get(element).wait(1).to({x: x1}, tiempo * 16).wait(1).to({x: x2}, tiempo * 8).wait(1));
        }
    else{
        if (x3 < -100)
            x3 = -100;
          this.timeline.addTween(cjs.Tween.get(element).wait(1).to({x: x1}, tiempo * 8).wait(1).to({x: x2}, tiempo * 8).wait(1).to({x: x3}, tiempo * 8).wait(1));
        
    }
    
      

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.crossFadeElement = function (elemento1, elemento2, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, false, {});
        elemento1.alpha = 1;
        elemento2.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento1).wait(espera).to({alpha: 0}, delay).wait(1));
        this.timeline.addTween(cjs.Tween.get(elemento2).wait(espera).to({alpha: 1}, delay).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')) {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}
function createHTML(texto, width, height, id) {

    var html = document.createElement('div', width, height);
    html.id = id;
    html.innerHTML = texto;

    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

