window.onresize = resize;
var scale 	= 1;

/* BEGIN CONST */

var element_order;

/* END CONST */


var canvas;

var rotationInterval;
var vibrateInterval;
var INITIAL_DEGREES = 0;

var currentDegrees = INITIAL_DEGREES;

var currentModalidad = 1;

var currentProtons 		= 0;
var currentNeutrons 	= 0;
var currentElectrons 	= 0;


$(document).ready(function(){

	var originx = 280;
	var originy = 309;

	$("#electrons").css("transform-origin",originx+"px "+originy+"px");
	$("img#aguja").css("transform-origin","50% 90%");

	addTouchListener();
	resize();
	initialize();
});

/*
		INITIALIZE
	 -------------------
*/
function initialize() {

	currentProtons 		= 0;
	currentNeutrons 	= 0;
	currentElectrons 	= 0;

	currentDegrees		= 0;
	element_order 		= 0;

	updateValues();

	$("span.label_carga").html("");

	$('td').removeClass("selected");
	$("#electrons").css('transform','rotate(' + currentDegrees + 'deg)');

	$("#electrons img").hide();

	$("#elemento #element_name").html("");
	$("span.label_element").html("");
	$("#num_masico #num_masico_label").html("");
	$("span#element_electrons").html("");
	$("span#element_short").html("");

	if (currentModalidad == 1)
		setModalidad1();
	else
		setModalidad2();
}

/*
 		TOUCH LISTENERS
 	------------------------
 */
function addTouchListener() {

	$('td').on("touchend mouseup",function(ev){

		if (currentModalidad == 1)
			return;

		if ($(this).html() == "")
			return;

		$('td').removeClass("selected");
		$(this).addClass("selected");
		element_order = elements_codi.indexOf($(this).html())
		selectElement($(this).html());
	});
}


function protonsInc() {
	currentProtons++;

	if (currentProtons > 36) {
		currentProtons = 36;
	}else{
		updateValues();
	}
}
function protonsDec() {
	currentProtons--;

	if (currentProtons < 0)	{
		currentProtons = 0;
	}else {
		updateValues();
	}
}

function neutronsInc() {
	currentNeutrons++;

	if (currentNeutrons > 50) {
		currentNeutrons = 50;
	}else{
		updateValues();
	}
}
function neutronsDec() {
	currentNeutrons--;

	if (currentNeutrons < 0) {
		currentNeutrons = 0;
	}else{
		updateValues();
	}
}

function electronsInc() {
	currentElectrons++;

	if (currentElectrons > 60) {
		currentElectrons = 60;
	}else {
		updateValues();
	}
}
function electronsDec() {
	currentElectrons--;

	if (currentElectrons < 0) {
		currentElectrons = 0;
	}else{
		updateValues();
	}
}

/*
			UPDATE
	----------------------
 */
function updateValues() {

	$("#protons_counter").html(currentProtons);
	$("#neutrons_counter").html(currentNeutrons);
	$("#electrons_counter").html(currentElectrons);

	$("span#minus").html(currentElectrons);
	$("span#plus").html(currentProtons);

	if (element_order != currentProtons) {
		element_order = currentProtons;
		selectElement();
	}

	showElectronsN(currentElectrons);
	$("span#element_protones").html(currentProtons);
	$("span#element_p_n").html(currentNeutrons+currentProtons);

	var value = currentProtons-currentElectrons;
	value = value > 0 ? "+"+value : value;

	$("#aguja_value").html(value);

	$("span#element_carga").html(value);

	setCarga();
	setEstable();

	addOrbitalElements();
}

function addOrbitalElements() {

	$("#orbital_elements").html("");

	for (var i=0; i<currentProtons; i++) {
		$("#orbital_elements").append("<img src='images/proton.png'/>")

	}
	for (var i=0; i<currentNeutrons; i++) {
		$("#orbital_elements").append("<img src='images/neutron.png'/>")
	}

	shuffle($("#orbital_elements img"));
	addVibration();
}

function addVibration() {

	stopVibration();

	if ($("#orbital_elements img").length > 0 && !checkStable())
		vibrateInterval = setInterval(vibrateElements,100);
}

function stopVibration() {
	clearInterval(vibrateInterval);
}

function vibrateElements() {
	$("#orbital_elements img").each(function() {

		var left 	= parseInt($(this).css("left"));
		var top 	= parseInt($(this).css("top"));

		var diff1 = Math.floor((Math.random() * 3) -1);
		var diff2 = Math.floor((Math.random() * 3) -1);

		/*
		if (diff1 + left > 40) {
			left = 40;
		}
		if (diff2 + top > 40) {
			top = 40;
		}
		if (diff1 + left < 15) {
			left = 15;
		}
		if (diff2 + top < 15) {
			top = 15;
		}
		*/

		$(this).css( "top"  , (top+diff2 ) + "px" );
		$(this).css( "left" , (left+diff1) + "px" );

	});
}

function setCarga() {

	if (currentElectrons == currentProtons) {
		// carga neutra
		$("span.label_carga").html(getText("atomoNeutro"));
		$("img#aguja").css('transform','rotate(0deg)');
	}else if (currentElectrons > currentProtons) {
		// carga positiva
		$("span.label_carga").html(getText("anion"));
		$("img#aguja").css('transform','rotate(-90deg)');
	}else{
		// carga negativa
		$("span.label_carga").html(getText("cation"));
		$("img#aguja").css('transform','rotate(90deg)');
	}

}

function setEstable() {
	var result = checkStable();

	if (result) {
		$("span.label_stable").html(getText("estable"));
		stopVibration();
	}else{
		$("span.label_stable").html(getText("inestable"));
		addVibration();
	}

	if (currentProtons  == 0 && currentNeutrons == 0) {
		$("span.label_stable").html("");
	}

}

function checkStable() {
	if (currentProtons > 0) {
		var stableValues = elements_estable[currentProtons];

		console.log("CHECK STABLE");
		console.log(stableValues);

		var ok = false;

		stableValues.forEach(function(value) {

			console.log(value);
			console.log(currentNeutrons);

			if (currentNeutrons == value) {
				ok = true;
			}
		});

		return ok;
	}

	return false;
}

/*
 		SELECT ELEMENT
 	----------------------
 */
function selectElement() {

	// SET ELEMENT
	var element_name = elements_nom[element_order];
	$("#elemento #element_name").html(element_name);
	$("span.label_element").html(element_name);

	$("span#element_short").html(elements_codi[element_order]);

	// SET NUMERO MASICO
	var num_masico = (elements_masico[element_order]+"").replace(".",",");
	$("#num_masico #num_masico_label").html(num_masico);

	// APPLY CHANGES FOR FIRST MODE
	if (currentModalidad == 1) {

		$('td').removeClass("selected");

		if (element_order > 0) {
			$('td').each(function() {
				if ($(this).html() == elements_codi[element_order]){
					$(this).addClass("selected");
				}
			});
		}

	}else {
		showElectrons(element_order);
	}

}

function showElectrons(order) {
	var totalElectrons = elements_estructura[order].reduce(function(a,b){
		return a+b;
	});

	$("span#element_electrons").html(totalElectrons);

	// SHOW ELECTRONS
	var electrons = elements_estructura[order];

	var k = 1;

	$("#electrons img.electron").hide();

	electrons.forEach(function(entry) {
		for (var j=0;j<entry; j++) {
			$("#fixe_"+k+"_"+(j+1)).show();
		}
		k++;
	});
}

function showElectronsN(n) {
	$("span#element_electrons").html(n);

	$("#electrons img.electron").hide();

	if (n>0)
		startRotation();

	var k=0;

	$("#electrons img").each(function(entry) {

		if (k<n)
			$(this).show();

		k++;
	});
}


/*
			MODALIDAD
	-------------------------
 */

function setModalidad1() {

	$("#carga_values").show();

	$("#footer-buttons div").show();
	$("#orbital_labels span").show();

	$("#orbitas").removeClass("modalidad2");
	$("#orbitas").addClass("modalidad1")
	$("#tabla").removeClass("modalidad2");
	$("#tabla").addClass("modalidad1");

	$("#elemento div.box_content span").show();
	$("#elemento div.box_content span#element_electrons").hide();
}

function setModalidad2() {

	$("#carga_values").hide();

	$("#footer-buttons div").hide();

	$("#orbital_labels span").hide();
	$("#orbital_labels span.label_element").show();

	$("#orbitas").removeClass("modalidad1");
	$("#orbitas").addClass("modalidad2");
	$("#tabla").removeClass("modalidad1");
	$("#tabla").addClass("modalidad2");

	$("#elemento div.box_content span").hide();
	$("#elemento div.box_content span#element_electrons").show();
	$("#elemento div.box_content span#element_short").show();

	$(".orbita").show();
}

function changeModalidad(modalidad) {

	reiniciar();

	currentModalidad = modalidad;

	$(".buttonsSwitch").addClass("off");
	$("#switch"+modalidad).removeClass("off");

	var pieText = getText("desc"+modalidad);
	$("#pie").html(pieText);



	switch (modalidad) {
		case 1:
			setModalidad1();
			break;
		case 2:
			setModalidad2();
			break;
		default :
			break;
	}
}

/*
 		ROTATION
 	-----------------
 */

function startRotation() {

	clearInterval(rotationInterval);
	rotationInterval = setInterval(rotation,33);
}

function rotation() {
	currentDegrees ++;
	currentDegrees %= 360;
	$("#electrons").css('transform','rotate(' + currentDegrees + 'deg)');
}

function stopRotation() {
	clearInterval(rotationInterval);
}



/*
 		GLOBAL FUNCTIONS
 	-----------------------
 */
function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		//apply margin left
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
		console.log("aki");
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
		//apply margin top
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}

function reiniciar() {

	console.log("RESET");

	stopRotation();
	stopVibration();
	currentDegrees = 0;
	initialize();
}

function shuffle(array) {
	var currentIndex = array.length, temporaryValue, randomIndex ;

	// While there remain elements to shuffle...
	while (0 !== currentIndex) {

		// Pick a remaining element...
		randomIndex = Math.floor(Math.random() * currentIndex);
		currentIndex -= 1;

		// And swap it with the current element.
		temporaryValue = array[currentIndex];
		array[currentIndex] = array[randomIndex];
		array[randomIndex] = temporaryValue;
	}


	array.each(function() {

		console.log(this);

		var top 	= Math.floor((Math.random() * 35) + 15);
		var left 	= Math.floor((Math.random() * 35) + 15);

		$(this).css( "top"  , top  + "px" );
		$(this).css( "left" , left + "px" );
	});

	return array;
}
