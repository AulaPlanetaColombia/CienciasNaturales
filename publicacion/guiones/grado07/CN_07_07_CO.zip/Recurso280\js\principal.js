(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0,0, 1, 0);
        titulo1(this, txt['titulo']);

this.btn_fases = new lib.btn_fases();
	this.btn_fases.setTransform(251.3,412.9,1,1,0,0,0,-84.8,-34.8);
	new cjs.ButtonHelper(this.btn_fases, 0, 1, 2, false, new lib.btn_fases(), 3);

	this.btn_localizacion = new lib.btn_localizacion();
	this.btn_localizacion.setTransform(252.3,265.4,1,1,0,0,0,-84.8,-34.8);
	new cjs.ButtonHelper(this.btn_localizacion, 0, 1, 2, false, new lib.btn_localizacion(), 3);


	this.instance = new lib.fotosIntro();
	this.instance.setTransform(417.4,358.1,1.95,1.95);

        this.informacion.on("click", function (evt) {
            putStage(new lib.frame4());
        });

     this.btn_localizacion.on("click", function (evt) {
            putStage(new lib.frame2(0));
        });
     this.btn_fases.on("click", function (evt) {
            putStage(new lib.frame3(0));
        });

        this.addChild(this.logo, this.titulo, this.informacion, this.instance,this.btn_localizacion,this.btn_fases);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function (frame) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['titulolocal']);
        texto(this,txt['textolocal'],0,400);
        
        this.text_1 = new cjs.Text(txt['texloesq_3'], "bold 16px Verdana");
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(775.7,370.6);

	this.text_2 = new cjs.Text(txt['texloesq_2'], "bold 16px Verdana");
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(504.2,370.6);

	this.text_3 = new cjs.Text(txt['texloesq_1'], "bold 16px Verdana");
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(632.2,160.2);

	this.text_4 = new cjs.Text(txt['texloesq_4'], "bold 16px Verdana");
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(570,437.7);

	this.text_5 = new cjs.Text(txt['texloesq_5'], "bold 16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(750,437.7);

	this.text_6 = new cjs.Text(txt['texloesq_6'], "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(689.8,292.5);
        
        this.btn_hidrosfera = new lib.btn_hidrosfera();
	this.btn_hidrosfera.setTransform(390,460,1,1,0,0,0,-57.4,-14.9);
	new cjs.ButtonHelper(this.btn_hidrosfera, 0, 1, 2, false, new lib.btn_hidrosfera(), 3);

	this.btn_litosfera = new lib.btn_litosfera();
	this.btn_litosfera.setTransform(250,460,1,1,0,0,0,-57.4,-14.9);
	new cjs.ButtonHelper(this.btn_litosfera, 0, 1, 2, false, new lib.btn_litosfera(), 3);

	this.btn_atmosfera = new lib.btn_atmosfera();
	this.btn_atmosfera.setTransform(110,460,1,1,0,0,0,-57.4,-14.9);
	new cjs.ButtonHelper(this.btn_atmosfera, 0, 1, 2, false, new lib.btn_atmosfera(), 3);
        this.btn_atmosfera.on("click", function (evt) {
            putStage(new lib.frame2(1));
        });
          this.btn_litosfera.on("click", function (evt) {
            putStage(new lib.frame2(2));
        });
          this.btn_hidrosfera.on("click", function (evt) {
            putStage(new lib.frame2(3));
        });
        if (frame==0){
            this.instance=new lib.p1("single");
            
        }
          if (frame==1){
              
            this.instance=new lib.p1();
            
        }
          if (frame==2){
              
            this.instance=new lib.p1a();
            
        }
          if (frame==3){
              
            this.instance=new lib.p1b();
            
        }
        this.instance.setTransform(694.9,353,1.363,1.363);
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.texto,this.btn_hidrosfera,this.btn_litosfera,this.btn_atmosfera,this.instance,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function (frame) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['titfases']);
 texto(this,txt['textofases'],0,400);
  if (frame==4)
	this.btn_combustion = new lib.btn_combustion("single",1);
    else
	this.btn_combustion = new lib.btn_combustion();
       
 
	this.btn_combustion.setTransform(200,131.6+350,0.92,0.92,0,0,0,-74.9,-14.9);
	new cjs.ButtonHelper(this.btn_combustion, 0, 1, 2, false, new lib.btn_combustion(), 3);
 if (frame==3)
	this.btn_mineralizacion = new lib.btn_mineralizacion("single",1);
    else
	this.btn_mineralizacion = new lib.btn_mineralizacion();
       
	this.btn_mineralizacion.setTransform(200,87.6+350,0.92,0.92,0,0,0,-74.9,-14.9);
	new cjs.ButtonHelper(this.btn_mineralizacion, 0, 1, 2, false, new lib.btn_mineralizacion(), 3);
 if (frame==5)
	this.btn_nutricion = new lib.btn_nutricion("single",1);
    else
	this.btn_nutricion = new lib.btn_nutricion();
       
	this.btn_nutricion.setTransform(200,44.3+350,0.92,0.92,0,0,0,-74.9,-14.9);
	new cjs.ButtonHelper(this.btn_nutricion, 0, 1, 2, false, new lib.btn_nutricion(), 3);
 if (frame==2)
	this.btn_fotosintesis = new lib.btn_fotosintesis("single",1);
    else
	this.btn_fotosintesis = new lib.btn_fotosintesis();
       
	this.btn_fotosintesis.setTransform(200,-0.4+350,0.92,0.92,0,0,0,-74.9,-14.9);
	new cjs.ButtonHelper(this.btn_fotosintesis, 0, 1, 2, false, new lib.btn_fotosintesis(), 3);
        if (frame==1)
	this.btn_respiracion = new lib.btn_respiracion("single",1);
    else
	this.btn_respiracion = new lib.btn_respiracion();
        
	this.btn_respiracion.setTransform(200,-43.9+350,0.92,0.92,0,0,0,-74.9,-14.9);
	new cjs.ButtonHelper(this.btn_respiracion, 0, 1, 2, false, new lib.btn_respiracion(), 3);
        
         if (frame==0){
            this.instance=new lib.p3a("single");
            
        }
        else{
            this.instance=new lib.p3a(frame);
        }
          
        
        this.instance.setTransform(709.6,345,1.259,1.259);
        this.btn_respiracion.on("click", function (evt) {
            putStage(new lib.frame3(1));
        });
         this.btn_fotosintesis.on("click", function (evt) {
            putStage(new lib.frame3(2));
        });
           this.btn_mineralizacion.on("click", function (evt) {
            putStage(new lib.frame3(3));
        });
          this.btn_combustion.on("click", function (evt) {
            putStage(new lib.frame3(4));
        });
          this.btn_nutricion.on("click", function (evt) {
            putStage(new lib.frame3(5));
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.texto,this.btn_respiracion,this.btn_fotosintesis,this.btn_nutricion,this.btn_mineralizacion,this.btn_combustion,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1,0,0, 0, 0);
        titulo2(this, txt['titulo']);
        texto(this,txt['texcicl'],0,400);
this.instance = new lib.fotosIntro();
	this.instance.setTransform(418.9,358.1,1.95,1.95);
        
       
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.texto, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '100px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130 + ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

 /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }

   
   //Simbolillos
   (lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,196,196);


(lib.Mapadebits10 = function() {
	this.initialize(img.Mapadebits10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,50,16);


(lib.Mapadebits11 = function() {
	this.initialize(img.Mapadebits11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,34,41);

(lib.Mapadebits22 = function() {
	this.initialize(img.Mapadebits22);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,32,43);


(lib.Mapadebits23 = function() {
	this.initialize(img.Mapadebits23);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,27,46);

(lib.Mapadebits22b = function() {
	this.initialize(img.Mapadebits22b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,78,33);


(lib.Mapadebits23b = function() {
	this.initialize(img.Mapadebits23b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,33,30);


(lib.Mapadebits24b = function() {
	this.initialize(img.Mapadebits24b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,90,30);


(lib.Mapadebits12 = function() {
	this.initialize(img.Mapadebits12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,34,41);


(lib.Mapadebits13 = function() {
	this.initialize(img.Mapadebits13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,78,33);


(lib.Mapadebits14 = function() {
	this.initialize(img.Mapadebits14);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,102,252);


(lib.Mapadebits15 = function() {
	this.initialize(img.Mapadebits15);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,102,284);


(lib.Mapadebits16 = function() {
	this.initialize(img.Mapadebits16);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,40,40);


(lib.Mapadebits17 = function() {
	this.initialize(img.Mapadebits17);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,40,40);


(lib.Mapadebits18 = function() {
	this.initialize(img.Mapadebits18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,102,10);


(lib.Mapadebits19 = function() {
	this.initialize(img.Mapadebits19);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,43,38);


(lib.Mapadebits2 = function() {
	this.initialize(img.Mapadebits2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,196,192);


(lib.Mapadebits20 = function() {
	this.initialize(img.Mapadebits20);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,10,207);


(lib.Mapadebits21 = function() {
	this.initialize(img.Mapadebits21);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,189,73);


(lib.Mapadebits3 = function() {
	this.initialize(img.Mapadebits3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,196,194);


(lib.Mapadebits4 = function() {
	this.initialize(img.Mapadebits4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,16,50);


(lib.Mapadebits5 = function() {
	this.initialize(img.Mapadebits5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,10,44);


(lib.Mapadebits6 = function() {
	this.initialize(img.Mapadebits6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,34,41);


(lib.Mapadebits7 = function() {
	this.initialize(img.Mapadebits7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,34,41);


(lib.Mapadebits8 = function() {
	this.initialize(img.Mapadebits8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,28,46);


(lib.Mapadebits9 = function() {
	this.initialize(img.Mapadebits9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,50,16);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.introduccio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AofBkIAAjHIF7AAIAADHg");
	var mask_graphics_1 = new cjs.Graphics().p("AoiBPIAWjFIF5AoIgVDFg");
	var mask_graphics_2 = new cjs.Graphics().p("AoeAgIArjCIFzBQIgqDCg");
	var mask_graphics_3 = new cjs.Graphics().p("AoUgaIA/i+IFpB3Ig/C8g");
	var mask_graphics_4 = new cjs.Graphics().p("AoDhWIBSi2IFaCdIhSC0g");
	var mask_graphics_5 = new cjs.Graphics().p("AntiRIBlisIFIDBIhmCqg");
	var mask_graphics_6 = new cjs.Graphics().p("AnSjKIB4igIExDiIh4Cfg");
	var mask_graphics_7 = new cjs.Graphics().p("AmxkAICIiTIEXECIiICRg");
	var mask_graphics_8 = new cjs.Graphics().p("AmLk0ICXiEID4EeIiVCEg");
	var mask_graphics_9 = new cjs.Graphics().p("AlhlkICkhzIDZE3IiiBzg");
	var mask_graphics_10 = new cjs.Graphics().p("AkymQICvhhIC2FMIitBhg");
	var mask_graphics_11 = new cjs.Graphics().p("AkAm4IC4hNICSFeIi2BNg");
	var mask_graphics_12 = new cjs.Graphics().p("AjLnaIC/g6IBsFsIi+A6g");
	var mask_graphics_13 = new cjs.Graphics().p("AiUn3IDCglIBHF1IjDAlg");
	var mask_graphics_14 = new cjs.Graphics().p("AhxoOIDFgQIAeF6IjFAQg");
	var mask_graphics_15 = new cjs.Graphics().p("AhoihIALl8IDGAFIgLF8g");
	var mask_graphics_16 = new cjs.Graphics().p("Ah7ilIAzl4IDEAaIgzF5g");
	var mask_graphics_17 = new cjs.Graphics().p("AhpimIBblyIDAAwIhaFxg");
	var mask_graphics_18 = new cjs.Graphics().p("AhTimIB/lmIC8BEIiBFmg");
	var mask_graphics_19 = new cjs.Graphics().p("Ag9ikICllWICzBYIimFVg");
	var mask_graphics_20 = new cjs.Graphics().p("AgmigIDIlCICqBqIjKFCg");
	var mask_graphics_21 = new cjs.Graphics().p("AgOiaIDpkrICdB8IjrErg");
	var mask_graphics_22 = new cjs.Graphics().p("AAIiSIEJkQICPCLIkJEQg");
	var mask_graphics_23 = new cjs.Graphics().p("AAgiIIEkjzICACaIklDwg");
	var mask_graphics_24 = new cjs.Graphics().p("AA3h9IE8jSIBvCmIk9DQg");
	var mask_graphics_25 = new cjs.Graphics().p("ABOhxIFRivIBcCyIlRCtg");
	var mask_graphics_26 = new cjs.Graphics().p("ABjhiIFiiLIBJC6IliCJg");
	var mask_graphics_27 = new cjs.Graphics().p("AB4hTIFvhkIA0C/IluBkg");
	var mask_graphics_28 = new cjs.Graphics().p("ACLhDIF4g8IAfDDIl3A8g");
	var mask_graphics_29 = new cjs.Graphics().p("ACdhYIF8gUIAKDFIl7AUg");
	var mask_graphics_30 = new cjs.Graphics().p("ACdBZIALjFIF7AUIgKDFg");
	var mask_graphics_31 = new cjs.Graphics().p("ACLBTIAgjDIF3A8IgfDEg");
	var mask_graphics_32 = new cjs.Graphics().p("AB4BkIA1i/IFuBiIg0DBg");
	var mask_graphics_33 = new cjs.Graphics().p("ABjBzIBJi4IFiCIIhJC6g");
	var mask_graphics_34 = new cjs.Graphics().p("ABOCBIBcivIFRCtIhcCxg");
	var mask_graphics_35 = new cjs.Graphics().p("AA3COIBuilIE9DQIhvCng");
	var mask_graphics_36 = new cjs.Graphics().p("AAgCZIB/iZIElDyIiACag");
	var mask_graphics_37 = new cjs.Graphics().p("AAICjICPiMIEJEQIiPCMg");
	var mask_graphics_38 = new cjs.Graphics().p("AgOCqICbh7IDrErIidB7g");
	var mask_graphics_39 = new cjs.Graphics().p("AgmCwICohqIDKFCIiqBrg");
	var mask_graphics_40 = new cjs.Graphics().p("Ag9C1ICyhYICmFWIizBXg");
	var mask_graphics_41 = new cjs.Graphics().p("AhTC3IC6hEICBFlIi8BEg");
	var mask_graphics_42 = new cjs.Graphics().p("AhpC3IDBgvIBaFxIjAAvg");
	var mask_graphics_43 = new cjs.Graphics().p("Ah7C1IDEgaIAzF4IjEAbg");
	var mask_graphics_44 = new cjs.Graphics().p("AhoCyIDGgGIALF8IjGAFg");
	var mask_graphics_45 = new cjs.Graphics().p("AhxIfIAel7IDFAQIgeF7g");
	var mask_graphics_46 = new cjs.Graphics().p("AiUIIIBGl2IDDAlIhHF2g");
	var mask_graphics_47 = new cjs.Graphics().p("AjLHrIBtlsIC+A6IhsFrg");
	var mask_graphics_48 = new cjs.Graphics().p("AkAHIICUleIC2BOIiSFeg");
	var mask_graphics_49 = new cjs.Graphics().p("AkyGhIC4lNICtBhIi2FNg");
	var mask_graphics_50 = new cjs.Graphics().p("AlhF1IDbk3ICiBzIjZE3g");
	var mask_graphics_51 = new cjs.Graphics().p("AmLFEID6keICVCEIj4Eeg");
	var mask_graphics_52 = new cjs.Graphics().p("AmxERIEXkCICICTIkXECg");
	var mask_graphics_53 = new cjs.Graphics().p("AnSDaIExjhIB4CfIkxDjg");
	var mask_graphics_54 = new cjs.Graphics().p("AntChIFHi/IBmCrIlIDAg");
	var mask_graphics_55 = new cjs.Graphics().p("AoDBnIFaicIBSC1IlaCdg");
	var mask_graphics_56 = new cjs.Graphics().p("AoUArIFph1IA/C7IlpB4g");
	var mask_graphics_57 = new cjs.Graphics().p("AoegPIF0hQIAqDBIlzBQg");
	var mask_graphics_58 = new cjs.Graphics().p("AoihLIF6goIAVDFIl5Aog");
	var mask_graphics_59 = new cjs.Graphics().p("AofBkIAAjGIF7AAIAADGg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-54.4,y:0.1}).wait(1).to({graphics:mask_graphics_1,x:-54.6,y:-9.4}).wait(1).to({graphics:mask_graphics_2,x:-54.2,y:-16.2}).wait(1).to({graphics:mask_graphics_3,x:-53.2,y:-21.7}).wait(1).to({graphics:mask_graphics_4,x:-51.6,y:-26.9}).wait(1).to({graphics:mask_graphics_5,x:-49.4,y:-31.7}).wait(1).to({graphics:mask_graphics_6,x:-46.6,y:-36.3}).wait(1).to({graphics:mask_graphics_7,x:-43.3,y:-40.4}).wait(1).to({graphics:mask_graphics_8,x:-39.5,y:-44}).wait(1).to({graphics:mask_graphics_9,x:-35.3,y:-47.2}).wait(1).to({graphics:mask_graphics_10,x:-30.7,y:-49.8}).wait(1).to({graphics:mask_graphics_11,x:-25.7,y:-51.8}).wait(1).to({graphics:mask_graphics_12,x:-20.4,y:-53.2}).wait(1).to({graphics:mask_graphics_13,x:-14.9,y:-54.1}).wait(1).to({graphics:mask_graphics_14,x:-7,y:-54.3}).wait(1).to({graphics:mask_graphics_15,x:2.5,y:-54.1}).wait(1).to({graphics:mask_graphics_16,x:12,y:-54.2}).wait(1).to({graphics:mask_graphics_17,x:17.8,y:-53.6}).wait(1).to({graphics:mask_graphics_18,x:23.2,y:-52.4}).wait(1).to({graphics:mask_graphics_19,x:28.4,y:-50.6}).wait(1).to({graphics:mask_graphics_20,x:33.2,y:-48.3}).wait(1).to({graphics:mask_graphics_21,x:37.7,y:-45.3}).wait(1).to({graphics:mask_graphics_22,x:41.7,y:-41.9}).wait(1).to({graphics:mask_graphics_23,x:45.2,y:-37.9}).wait(1).to({graphics:mask_graphics_24,x:48.3,y:-33.6}).wait(1).to({graphics:mask_graphics_25,x:50.7,y:-28.8}).wait(1).to({graphics:mask_graphics_26,x:52.7,y:-23.7}).wait(1).to({graphics:mask_graphics_27,x:54,y:-18.4}).wait(1).to({graphics:mask_graphics_28,x:54.7,y:-12.8}).wait(1).to({graphics:mask_graphics_29,x:54.8,y:-3.2}).wait(1).to({graphics:mask_graphics_30,x:54.8,y:6.4}).wait(1).to({graphics:mask_graphics_31,x:54.7,y:14.4}).wait(1).to({graphics:mask_graphics_32,x:54,y:20}).wait(1).to({graphics:mask_graphics_33,x:52.7,y:25.4}).wait(1).to({graphics:mask_graphics_34,x:50.7,y:30.5}).wait(1).to({graphics:mask_graphics_35,x:48.3,y:35.2}).wait(1).to({graphics:mask_graphics_36,x:45.2,y:39.6}).wait(1).to({graphics:mask_graphics_37,x:41.7,y:43.5}).wait(1).to({graphics:mask_graphics_38,x:37.7,y:47}).wait(1).to({graphics:mask_graphics_39,x:33.2,y:49.9}).wait(1).to({graphics:mask_graphics_40,x:28.4,y:52.3}).wait(1).to({graphics:mask_graphics_41,x:23.2,y:54.1}).wait(1).to({graphics:mask_graphics_42,x:17.8,y:55.3}).wait(1).to({graphics:mask_graphics_43,x:12,y:55.8}).wait(1).to({graphics:mask_graphics_44,x:2.5,y:55.8}).wait(1).to({graphics:mask_graphics_45,x:-7,y:55.9}).wait(1).to({graphics:mask_graphics_46,x:-14.9,y:55.7}).wait(1).to({graphics:mask_graphics_47,x:-20.4,y:54.9}).wait(1).to({graphics:mask_graphics_48,x:-25.7,y:53.4}).wait(1).to({graphics:mask_graphics_49,x:-30.7,y:51.4}).wait(1).to({graphics:mask_graphics_50,x:-35.3,y:48.8}).wait(1).to({graphics:mask_graphics_51,x:-39.5,y:45.7}).wait(1).to({graphics:mask_graphics_52,x:-43.3,y:42}).wait(1).to({graphics:mask_graphics_53,x:-46.6,y:37.9}).wait(1).to({graphics:mask_graphics_54,x:-49.4,y:33.4}).wait(1).to({graphics:mask_graphics_55,x:-51.6,y:28.5}).wait(1).to({graphics:mask_graphics_56,x:-53.2,y:23.3}).wait(1).to({graphics:mask_graphics_57,x:-54.2,y:17.9}).wait(1).to({graphics:mask_graphics_58,x:-54.6,y:12.3}).wait(1).to({graphics:mask_graphics_59,x:-54.4,y:3.1}).wait(1));

	// cercle vermell
	this.instance = new lib.Mapadebits1();
	this.instance.setTransform(-94.2,-97.7);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(60));

	// Layer 7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AofEOIAAoaIF7AAIAAIag");
	var mask_1_graphics_1 = new cjs.Graphics().p("AorD4IA6oXIF5AoIg5IXg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AowDfIByoOIF0BRIhyIOg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AouDEICpn/IFpB4IiqH/g");
	var mask_1_graphics_4 = new cjs.Graphics().p("AonCQIDgnqIFYCdIjeHqg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AoZBJIETnPIFFDBIkQHPg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AoEABIFCmvIEvDiIlAGwg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AnqhFIFumNIEVECIlsGLg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AnLiMIGXlkID4EeImVFig");
	var mask_1_graphics_9 = new cjs.Graphics().p("AmmjRIG4k3IDaE3Im4E0g");
	var mask_1_graphics_10 = new cjs.Graphics().p("Al8kVIHWkFIC4FMInWEEg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AlPlUIHwjSICUFeInwDQg");
	var mask_1_graphics_12 = new cjs.Graphics().p("Ak4mQIIDicIBuFrIoDCcg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AkrnIIIRhkIBGF1IoRBlg");
	var mask_1_graphics_14 = new cjs.Graphics().p("Akbn6IIYgrIAfF7IoYArg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AkRijIAKl8IIZAOIgKF8g");
	var mask_1_graphics_16 = new cjs.Graphics().p("AkjiwIAyl5IIVBIIgyF5g");
	var mask_1_graphics_17 = new cjs.Graphics().p("Akyi7IBalxIILCAIhaFyg");
	var mask_1_graphics_18 = new cjs.Graphics().p("Ak9jDICBlmIH6C4IiBFlg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AkijJICmlWIHkDsIimFUg");
	var mask_1_graphics_20 = new cjs.Graphics().p("Aj+jNIDKlCIHIEeIjKFAg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AjWjOIDokrIGpFNIjrEpg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AitjNIEHkRIGDF5IkJEOg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AiBjKIEijyIFZGfIklDxg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AhUjEIE7jSIEqHAIk9DSg");
	var mask_1_graphics_25 = new cjs.Graphics().p("Agmi8IFPivID5HdIlRCvg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AAGi1IFiiKIDFH1IliCKg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AA1jRIFvhkICOIHIlvBkg");
	var mask_1_graphics_28 = new cjs.Graphics().p("ABjjrIF3g8IBWITIl3A8g");
	var mask_1_graphics_29 = new cjs.Graphics().p("ACQkCIF7gUIAdIZIl8AUg");
	var mask_1_graphics_30 = new cjs.Graphics().p("ACQEDIAcoZIF8AUIgdIZg");
	var mask_1_graphics_31 = new cjs.Graphics().p("ABjDsIBWoTIF3A8IhWITg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AA1DSICOoHIFvBkIiOIHg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AAGDCIDFn1IFiCLIjFH0g");
	var mask_1_graphics_34 = new cjs.Graphics().p("AgmDMID3ndIFRCvIj5Heg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AhUDVIEonAIE9DSIkqHAg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AiBDaIFWmdIElDwIlZGgg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AitDeIGBl3IEJEOImDF5g");
	var mask_1_graphics_38 = new cjs.Graphics().p("AjWDfIGmlMIDrEpImpFOg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Aj+DdIHIkcIDKFAInIEfg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AkiDaIHkjqICmFTInkDsg");
	var mask_1_graphics_41 = new cjs.Graphics().p("Ak9DUIH6i4ICBFmIn6C3g");
	var mask_1_graphics_42 = new cjs.Graphics().p("AkyDLIILiAIBaFxIoLCAg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AkjDBIIVhIIAyF5IoVBHg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AkRC0IIZgOIAKF7IoZAPg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AkbILIAfl7IIYArIgfF7g");
	var mask_1_graphics_46 = new cjs.Graphics().p("AkrHYIBGl1IIRBkIhGF1g");
	var mask_1_graphics_47 = new cjs.Graphics().p("Ak4GhIBulsIIDCcIhuFsg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AlPFlICUleIHwDSIiUFeg");
	var mask_1_graphics_49 = new cjs.Graphics().p("Al8ElIC4lKIHWEDIi4FNg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AmmDiIDak1IG4E0IjaE3g");
	var mask_1_graphics_51 = new cjs.Graphics().p("AnLCcID6kbIGVFhIj4Eeg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AnqBVIEXj/IFsGKIkVECg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AoEANIExjgIFAGvIkvDjg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AoZg5IFIjAIEQHPIlFDBg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AoniAIFaidIDeHqIlYCdg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AoujDIFoh4ICqH/IlpB4g");
	var mask_1_graphics_57 = new cjs.Graphics().p("AowjeIF0hRIByIOIl0BRg");
	var mask_1_graphics_58 = new cjs.Graphics().p("Aorj3IF6goIA5IXIl5Aog");
	var mask_1_graphics_59 = new cjs.Graphics().p("AofEOIAAoaIF7AAIAAIag");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-54.4,y:0.1}).wait(1).to({graphics:mask_1_graphics_1,x:-55.5,y:-9.4}).wait(1).to({graphics:mask_1_graphics_2,x:-56,y:-18.8}).wait(1).to({graphics:mask_1_graphics_3,x:-55.9,y:-28}).wait(1).to({graphics:mask_1_graphics_4,x:-55.1,y:-34.6}).wait(1).to({graphics:mask_1_graphics_5,x:-53.7,y:-39.1}).wait(1).to({graphics:mask_1_graphics_6,x:-51.7,y:-43.1}).wait(1).to({graphics:mask_1_graphics_7,x:-49.1,y:-46.6}).wait(1).to({graphics:mask_1_graphics_8,x:-45.9,y:-49.6}).wait(1).to({graphics:mask_1_graphics_9,x:-42.3,y:-52}).wait(1).to({graphics:mask_1_graphics_10,x:-38.1,y:-53.9}).wait(1).to({graphics:mask_1_graphics_11,x:-33.5,y:-55.1}).wait(1).to({graphics:mask_1_graphics_12,x:-25.8,y:-55.7}).wait(1).to({graphics:mask_1_graphics_13,x:-16.5,y:-55.6}).wait(1).to({graphics:mask_1_graphics_14,x:-7,y:-55}).wait(1).to({graphics:mask_1_graphics_15,x:2.5,y:-54.4}).wait(1).to({graphics:mask_1_graphics_16,x:12,y:-55.3}).wait(1).to({graphics:mask_1_graphics_17,x:21.5,y:-55.6}).wait(1).to({graphics:mask_1_graphics_18,x:30.6,y:-55.3}).wait(1).to({graphics:mask_1_graphics_19,x:36,y:-54.3}).wait(1).to({graphics:mask_1_graphics_20,x:40.4,y:-52.8}).wait(1).to({graphics:mask_1_graphics_21,x:44.3,y:-50.6}).wait(1).to({graphics:mask_1_graphics_22,x:47.8,y:-47.8}).wait(1).to({graphics:mask_1_graphics_23,x:50.6,y:-44.5}).wait(1).to({graphics:mask_1_graphics_24,x:53,y:-40.7}).wait(1).to({graphics:mask_1_graphics_25,x:54.7,y:-36.4}).wait(1).to({graphics:mask_1_graphics_26,x:55.8,y:-31.3}).wait(1).to({graphics:mask_1_graphics_27,x:56.2,y:-22.2}).wait(1).to({graphics:mask_1_graphics_28,x:56,y:-12.8}).wait(1).to({graphics:mask_1_graphics_29,x:55.2,y:-3.2}).wait(1).to({graphics:mask_1_graphics_30,x:55.2,y:6.4}).wait(1).to({graphics:mask_1_graphics_31,x:56,y:16}).wait(1).to({graphics:mask_1_graphics_32,x:56.2,y:25.4}).wait(1).to({graphics:mask_1_graphics_33,x:55.8,y:33.3}).wait(1).to({graphics:mask_1_graphics_34,x:54.7,y:38}).wait(1).to({graphics:mask_1_graphics_35,x:53,y:42.3}).wait(1).to({graphics:mask_1_graphics_36,x:50.6,y:46.1}).wait(1).to({graphics:mask_1_graphics_37,x:47.8,y:49.5}).wait(1).to({graphics:mask_1_graphics_38,x:44.3,y:52.2}).wait(1).to({graphics:mask_1_graphics_39,x:40.4,y:54.4}).wait(1).to({graphics:mask_1_graphics_40,x:36,y:56}).wait(1).to({graphics:mask_1_graphics_41,x:30.6,y:57}).wait(1).to({graphics:mask_1_graphics_42,x:21.5,y:57.3}).wait(1).to({graphics:mask_1_graphics_43,x:12,y:57}).wait(1).to({graphics:mask_1_graphics_44,x:2.5,y:56}).wait(1).to({graphics:mask_1_graphics_45,x:-7,y:56.6}).wait(1).to({graphics:mask_1_graphics_46,x:-16.5,y:57.3}).wait(1).to({graphics:mask_1_graphics_47,x:-25.8,y:57.3}).wait(1).to({graphics:mask_1_graphics_48,x:-33.5,y:56.7}).wait(1).to({graphics:mask_1_graphics_49,x:-38.1,y:55.5}).wait(1).to({graphics:mask_1_graphics_50,x:-42.3,y:53.7}).wait(1).to({graphics:mask_1_graphics_51,x:-45.9,y:51.3}).wait(1).to({graphics:mask_1_graphics_52,x:-49.1,y:48.3}).wait(1).to({graphics:mask_1_graphics_53,x:-51.7,y:44.7}).wait(1).to({graphics:mask_1_graphics_54,x:-53.7,y:40.7}).wait(1).to({graphics:mask_1_graphics_55,x:-55.1,y:36.3}).wait(1).to({graphics:mask_1_graphics_56,x:-55.9,y:31.2}).wait(1).to({graphics:mask_1_graphics_57,x:-56,y:22}).wait(1).to({graphics:mask_1_graphics_58,x:-55.5,y:12.6}).wait(1).to({graphics:mask_1_graphics_59,x:-54.4,y:3.1}).wait(1));

	// cercle verd
	this.instance_1 = new lib.Mapadebits2();
	this.instance_1.setTransform(-94.2,-97.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#609F94").ss(10,1,1).p("AttkzQBDjBCbibQEQkQF/AAQGAAAEQEQQEQEQAAF/QAAGAkQEQQkQEQmAAAQl/AAkQkQQkQkQAAmAQAAgLABgN");
	this.shape.setTransform(3.5,0);

	this.instance_1.mask = this.shape.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.shape}]},59).wait(1));

	// cercle
	this.instance_2 = new lib.Mapadebits3();
	this.instance_2.setTransform(-94.2,-97.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#323431").s().p("AhMAmIBMhMIBNBNg");
	this.shape_1.setTransform(-88.4,-9.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.instance_2}]}).wait(60));

	// lletra
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#F5F5ED","#003333"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_2.setTransform(-2.7,-0.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#F5F5ED","#013535"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_3.setTransform(-2.7,-0.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#F5F5ED","#033838"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_4.setTransform(-2.7,-0.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#F5F5ED","#043A3A"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_5.setTransform(-2.7,-0.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["#F5F5ED","#053D3D"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_6.setTransform(-2.7,-0.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["#F5F5ED","#073F3F"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_7.setTransform(-2.7,-0.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["#F5F5ED","#084242"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_8.setTransform(-2.7,-0.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["#F5F5ED","#094444"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_9.setTransform(-2.7,-0.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["#F5F5ED","#0B4747"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_10.setTransform(-2.7,-0.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.rf(["#F5F5ED","#0C4949"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_11.setTransform(-2.7,-0.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.rf(["#F5F5ED","#0D4C4C"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_12.setTransform(-2.7,-0.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.rf(["#F5F5ED","#0F4E4E"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_13.setTransform(-2.7,-0.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.rf(["#F5F5ED","#105151"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_14.setTransform(-2.7,-0.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["#F5F5ED","#115353"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_15.setTransform(-2.7,-0.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.rf(["#F5F5ED","#135656"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_16.setTransform(-2.7,-0.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.rf(["#F5F5ED","#145858"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_17.setTransform(-2.7,-0.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.rf(["#F5F5ED","#165B5B"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_18.setTransform(-2.7,-0.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["#F5F5ED","#175D5D"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_19.setTransform(-2.7,-0.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.rf(["#F5F5ED","#186060"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_20.setTransform(-2.7,-0.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.rf(["#F5F5ED","#1A6262"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_21.setTransform(-2.7,-0.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.rf(["#F5F5ED","#1B6565"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_22.setTransform(-2.7,-0.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.rf(["#F5F5ED","#1C6767"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_23.setTransform(-2.7,-0.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.rf(["#F5F5ED","#1E6A6A"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_24.setTransform(-2.7,-0.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.rf(["#F5F5ED","#1F6C6C"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_25.setTransform(-2.7,-0.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.rf(["#F5F5ED","#206F6F"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_26.setTransform(-2.7,-0.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.rf(["#F5F5ED","#227171"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_27.setTransform(-2.7,-0.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.rf(["#F5F5ED","#237474"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_28.setTransform(-2.7,-0.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.rf(["#F5F5ED","#247676"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_29.setTransform(-2.7,-0.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.rf(["#F5F5ED","#267979"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_30.setTransform(-2.7,-0.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.rf(["#F5F5ED","#277B7B"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_31.setTransform(-2.7,-0.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.rf(["#F5F5ED","#216F6F"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_32.setTransform(-2.7,-0.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.rf(["#F5F5ED","#1F6D6D"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_33.setTransform(-2.7,-0.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.rf(["#F5F5ED","#1D6868"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_34.setTransform(-2.7,-0.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.rf(["#F5F5ED","#1A6363"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_35.setTransform(-2.7,-0.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.rf(["#F5F5ED","#196161"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_36.setTransform(-2.7,-0.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.rf(["#F5F5ED","#175E5E"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_37.setTransform(-2.7,-0.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.rf(["#F5F5ED","#165C5C"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_38.setTransform(-2.7,-0.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.rf(["#F5F5ED","#155959"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_39.setTransform(-2.7,-0.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.rf(["#F5F5ED","#145757"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_40.setTransform(-2.7,-0.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.rf(["#F5F5ED","#125555"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_41.setTransform(-2.7,-0.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.rf(["#F5F5ED","#115252"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_42.setTransform(-2.7,-0.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.rf(["#F5F5ED","#105050"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_43.setTransform(-2.7,-0.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.rf(["#F5F5ED","#0E4D4D"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_44.setTransform(-2.7,-0.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.rf(["#F5F5ED","#0D4B4B"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_45.setTransform(-2.7,-0.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.rf(["#F5F5ED","#0A4646"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_46.setTransform(-2.7,-0.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.rf(["#F5F5ED","#084141"],[0,1],-8.8,-12.8,0,-8.8,-12.8,25.4).s().p("AgtCwQgigMgZgXQgZgYgNgjQgOgkAAguQAAgpANgkQANgjAZgZQAYgYAjgNQAjgNAnAAQAXAAATACQASADAQAEIAdAKIAYALIAABYIgLAAIgRgOQgLgIgNgHQgNgIgQgGQgQgFgRAAQgUAAgSAGQgQAGgPAPQgOAOgJAWQgJAXAAAfQAAAiAKAXQAJAXAPANQAPAOAQAFQASAGASAAQARAAARgFQARgFAOgJQAMgHAKgIIARgOIAKAAIAABXIgbAMQgMAFgOAEQgRAFgQADQgQACgbAAQgnAAgigMg");
	this.shape_47.setTransform(-2.7,-0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	// esfera
	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.rf(["#F5F5ED","#277B7B"],[0,1],-12,-17.7,0,-12,-17.7,64.8).s().p("AAAHKQi9AAiGiGQiGiGAAi+QAAi9CGiGQCGiGC9AAQC+AACGCGQCGCGAAC9QAAC+iGCGQiGCGi+AAIAAAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48}]}).wait(60));

	// ombra esfera
	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.rf(["#110000","rgba(206,206,168,0)"],[0,1],0,0,0,0,0,58).s().p("AmXGXQioipAAjuQAAjtCoiqIABAAQCoioDuAAQDuAACpCoQCpCpAADuQAADuipCpIgBAAQioCpjuAAQjuAAipipg");
	this.shape_49.setTransform(8.4,8.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_49}]}).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-96.2,-97.7,198,196);


(lib.btn_respiracion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Respiración", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 145;
	this.text.setTransform(-77,-27.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape.setTransform(-74.9,-14.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape_1.setTransform(-74.9,-14.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape_2.setTransform(-74.9,-14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.9,-29.9,150,30);


(lib.btn_nutricion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btnut'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 145;
	this.text.setTransform(-77,-27.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape.setTransform(-74.9,-14.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape_1.setTransform(-74.9,-14.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape_2.setTransform(-74.9,-14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.9,-29.9,150,30);


(lib.btn_mineralizacion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btmin'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 145;
	this.text.setTransform(-77,-27.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape.setTransform(-74.9,-14.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape_1.setTransform(-74.9,-14.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape_2.setTransform(-74.9,-14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.9,-29.9,150,30);


(lib.btn_localizacion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btnlocal'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 165;
	this.text.setTransform(-87.3,-63.2+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-84.85,-34.9,169.7,69.8,6);
	this.shape.setTransform(-84.7,-34.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-84.85,-34.9,169.7,69.8,6);
	this.shape_1.setTransform(-84.7,-34.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-84.85,-34.9,169.7,69.8,6);
	this.shape_2.setTransform(-84.7,-34.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-169.7,-69.7,169.8,69.8);


(lib.btn_litosfera = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btnlit'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 110;
	this.text.setTransform(-59.7,-26.7+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape.setTransform(-57.4,-14.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_1.setTransform(-57.4,-14.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_2.setTransform(-57.4,-14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114.9,-29.9,115,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_info = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("i", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.setTransform(13.1,-0.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ABeidIi6AAQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(15.1,15.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_1.setTransform(15.1,15.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AhmitQg/AAAABDIAADWQAABCA/AAIDNAAQA+AAAAhCIAAjWQAAhDg+AAg");
	this.shape_2.setTransform(15.1,15.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhmCuQg+AAgBhDIAAjWQABhCA+AAIDNAAQA+AAAABCIAADWQAABDg+AAg");
	this.shape_3.setTransform(15.1,15.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("ACQCFQAHgOAAgVIAAjDQAAg8g5AAIi6AAQg6AAAAA8IAADDQAAA8A6AAIC6AAQAkAAANgY");
	this.shape_4.setTransform(15.1,15.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBAVgGAOIAAABIgBAAQgNAYglAAg");
	this.shape_5.setTransform(15.1,15.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:-0.1}}]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:12.5,y:-1.6}}]},1).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:-0.1}}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.1,30.2,31.9);


(lib.btn_hidrosfera = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['bthid'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 109;
	this.text.setTransform(-59.8,-27.3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape.setTransform(-57.4,-14.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_1.setTransform(-57.4,-14.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_2.setTransform(-57.4,-14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114.9,-29.9,115,30);


(lib.btn_fotosintesis = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btnfot'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 145;
	this.text.setTransform(-77,-27.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape.setTransform(-74.9,-14.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape_1.setTransform(-74.9,-14.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape_2.setTransform(-74.9,-14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.9,-29.9,150,30);


(lib.btn_fases = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['titfases'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 163;
	this.text.setTransform(-86.8,-46.9+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-84.85,-34.9,169.7,69.8,6);
	this.shape.setTransform(-84.7,-34.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-84.85,-34.9,169.7,69.8,6);
	this.shape_1.setTransform(-84.7,-34.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-84.85,-34.9,169.7,69.8,6);
	this.shape_2.setTransform(-84.7,-34.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-169.6,-69.7,169.7,69.8);


(lib.btn_combustion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btcom'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 145;
	this.text.setTransform(-77,-27.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape.setTransform(-74.9,-14.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape_1.setTransform(-74.9,-14.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-75,-15,150,30,6);
	this.shape_2.setTransform(-74.9,-14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.9,-29.9,150,30);


(lib.btn_atmosfera = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btnatm'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 111;
	this.text.setTransform(-59.5,-27.4+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape.setTransform(-57.4,-14.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_1.setTransform(-57.4,-14.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_2.setTransform(-57.4,-14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114.9,-29.9,115,30);



(lib.p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{fotosintesis:4,respiracion:34,mineralizacion:69,combustion:99,nutricion:140});

	// Txt
	this.text = new cjs.Text(txt['btcom9'], "bold 11px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 12;
	this.text.lineWidth = 91;
	this.text.setTransform(-18.6,26.6);

	this.text_1 = new cjs.Text("fotosíntesis", "bold 11px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 12;
	this.text_1.lineWidth = 91;
	this.text_1.setTransform(-18.1,-65.1);

	this.text_2 = new cjs.Text("nutrición", "bold 11px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 12;
	this.text_2.lineWidth = 91;
	this.text_2.setTransform(-18.6,-32.6);

	this.text_3 = new cjs.Text("combustión", "bold 11px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 12;
	this.text_3.lineWidth = 75;
	this.text_3.setTransform(-109.4,62.6);

	this.text_4 = new cjs.Text("combustión", "bold 11px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 12;
	this.text_4.lineWidth = 75;
	this.text_4.setTransform(73,96.6);

	this.text_5 = new cjs.Text("respiración", "bold 11px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 12;
	this.text_5.lineWidth = 75;
	this.text_5.setTransform(-109.5,-117.8);

	this.text_6 = new cjs.Text("respiración", "bold 11px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 12;
	this.text_6.lineWidth = 75;
	this.text_6.setTransform(73.5,-118);

	this.text_7 = new cjs.Text("rocas\ncarbonatadas", "12px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 9;
	this.text_7.lineWidth = 100;
	this.text_7.setTransform(-18,112.4);

	this.text_8 = new cjs.Text("carbón\npetróleo\ngas", "12px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 9;
	this.text_8.lineWidth = 100;
	this.text_8.setTransform(-18.2,70.5);

	this.text_9 = new cjs.Text("animales", "12px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 13;
	this.text_9.lineWidth = 61;
	this.text_9.setTransform(58.1,12.9);

	this.text_10 = new cjs.Text("vegetales", "12px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 13;
	this.text_10.lineWidth = 61;
	this.text_10.setTransform(-95.2,12.9);

	this.text_11 = new cjs.Text("ATMÓSFERA\nHIDROSFERA", "12px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 12;
	this.text_11.lineWidth = 100;
	this.text_11.setTransform(-18,-114.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(172));

	// botons
	


	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_140 = new cjs.Graphics().p("AgwCNIAAkZIBgAAIAAEZg");
	var mask_graphics_141 = new cjs.Graphics().p("AhICNIAAkZICRAAIAAEZg");
	var mask_graphics_142 = new cjs.Graphics().p("AhhCNIAAkZIDDAAIAAEZg");
	var mask_graphics_143 = new cjs.Graphics().p("Ah6CNIAAkZID1AAIAAEZg");
	var mask_graphics_144 = new cjs.Graphics().p("AiTCNIAAkZIEnAAIAAEZg");
	var mask_graphics_145 = new cjs.Graphics().p("AisCNIAAkZIFZAAIAAEZg");
	var mask_graphics_146 = new cjs.Graphics().p("AjFCNIAAkZIGLAAIAAEZg");
	var mask_graphics_147 = new cjs.Graphics().p("AjeCNIAAkZIG9AAIAAEZg");
	var mask_graphics_148 = new cjs.Graphics().p("Aj3CNIAAkZIHvAAIAAEZg");
	var mask_graphics_149 = new cjs.Graphics().p("AkQCNIAAkZIIhAAIAAEZg");
	var mask_graphics_150 = new cjs.Graphics().p("AkpCNIAAkZIJTAAIAAEZg");
	var mask_graphics_151 = new cjs.Graphics().p("AlCCNIAAkZIKFAAIAAEZg");
	var mask_graphics_152 = new cjs.Graphics().p("AlbCNIAAkZIK3AAIAAEZg");
	var mask_graphics_153 = new cjs.Graphics().p("Al0CNIAAkZILpAAIAAEZg");
	var mask_graphics_154 = new cjs.Graphics().p("AmNCNIAAkZIMbAAIAAEZg");
	var mask_graphics_155 = new cjs.Graphics().p("AmmCNIAAkZINNAAIAAEZg");
	var mask_graphics_156 = new cjs.Graphics().p("Am/CNIAAkZIN/AAIAAEZg");
	var mask_graphics_157 = new cjs.Graphics().p("AnYCNIAAkZIOxAAIAAEZg");
	var mask_graphics_158 = new cjs.Graphics().p("AnxCNIAAkZIPjAAIAAEZg");
	var mask_graphics_159 = new cjs.Graphics().p("AoKCNIAAkZIQVAAIAAEZg");
	var mask_graphics_160 = new cjs.Graphics().p("AojCNIAAkZIRHAAIAAEZg");
	var mask_graphics_161 = new cjs.Graphics().p("Ao8CNIAAkZIR5AAIAAEZg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(140).to({graphics:mask_graphics_140,x:-73.6,y:-8.2}).wait(1).to({graphics:mask_graphics_141,x:-71.1,y:-8.2}).wait(1).to({graphics:mask_graphics_142,x:-68.6,y:-8.2}).wait(1).to({graphics:mask_graphics_143,x:-66.1,y:-8.2}).wait(1).to({graphics:mask_graphics_144,x:-63.6,y:-8.2}).wait(1).to({graphics:mask_graphics_145,x:-61.1,y:-8.2}).wait(1).to({graphics:mask_graphics_146,x:-58.6,y:-8.2}).wait(1).to({graphics:mask_graphics_147,x:-56.1,y:-8.2}).wait(1).to({graphics:mask_graphics_148,x:-53.6,y:-8.2}).wait(1).to({graphics:mask_graphics_149,x:-51.1,y:-8.2}).wait(1).to({graphics:mask_graphics_150,x:-48.6,y:-8.2}).wait(1).to({graphics:mask_graphics_151,x:-46.1,y:-8.2}).wait(1).to({graphics:mask_graphics_152,x:-43.6,y:-8.2}).wait(1).to({graphics:mask_graphics_153,x:-41.1,y:-8.2}).wait(1).to({graphics:mask_graphics_154,x:-38.6,y:-8.2}).wait(1).to({graphics:mask_graphics_155,x:-36.1,y:-8.2}).wait(1).to({graphics:mask_graphics_156,x:-33.6,y:-8.2}).wait(1).to({graphics:mask_graphics_157,x:-31.1,y:-8.2}).wait(1).to({graphics:mask_graphics_158,x:-28.6,y:-8.2}).wait(1).to({graphics:mask_graphics_159,x:-26.1,y:-8.2}).wait(1).to({graphics:mask_graphics_160,x:-23.6,y:-8.2}).wait(1).to({graphics:mask_graphics_161,x:-21.1,y:-8.2}).wait(11));

	// fl nutricion
	this.instance = new lib.Mapadebits18();
	this.instance.setTransform(-72.1,-13.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#203936").s().p("AglhNIBMBNIhNBOg");
	this.shape_1.setTransform(32.3,-8.2);

	this.instance.mask = this.shape_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.instance}]}).wait(172));

	// Layer 43 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_99 = new cjs.Graphics().p("AgsDhIAAnAIBYAAIAAHAg");
	var mask_1_graphics_100 = new cjs.Graphics().p("AhlDYIAAmvIDLAAIAAGvg");
	var mask_1_graphics_101 = new cjs.Graphics().p("AifDQIAAmfIE/AAIAAGfg");
	var mask_1_graphics_102 = new cjs.Graphics().p("AjYDIIAAmPIGxAAIAAGPg");
	var mask_1_graphics_103 = new cjs.Graphics().p("AkSDAIAAl/IIkAAIAAF/g");
	var mask_1_graphics_104 = new cjs.Graphics().p("AlLC4IAAlvIKXAAIAAFvg");
	var mask_1_graphics_105 = new cjs.Graphics().p("AmFCwIAAlfIMLAAIAAFfg");
	var mask_1_graphics_106 = new cjs.Graphics().p("Am+CoIAAlPIN9AAIAAFPg");
	var mask_1_graphics_107 = new cjs.Graphics().p("AltLYIAAlAIPwAAIAAFAg");
	var mask_1_graphics_108 = new cjs.Graphics().p("An1DoIAAnPIPrAAIAAHPg");
	var mask_1_graphics_109 = new cjs.Graphics().p("AnyEwIAApfIPlAAIAAJfg");
	var mask_1_graphics_110 = new cjs.Graphics().p("AnwF5IAArxIPhAAIAALxg");
	var mask_1_graphics_111 = new cjs.Graphics().p("AntHBIAAuBIPbAAIAAOBg");
	var mask_1_graphics_112 = new cjs.Graphics().p("AnqIJIAAwRIPVAAIAAQRg");
	var mask_1_graphics_113 = new cjs.Graphics().p("AnoJSIAAyjIPRAAIAASjg");
	var mask_1_graphics_114 = new cjs.Graphics().p("AnlKaIAA0zIPLAAIAAUzg");
	var mask_1_graphics_115 = new cjs.Graphics().p("AniLiIAA3DIPFAAIAAXDg");
	var mask_1_graphics_116 = new cjs.Graphics().p("AngMrIAA5VIPBAAIAAZVg");
	var mask_1_graphics_117 = new cjs.Graphics().p("AndNzIAA7lIO7AAIAAblg");
	var mask_1_graphics_118 = new cjs.Graphics().p("AnaO8IAA93IO1AAIAAd3g");
	var mask_1_graphics_119 = new cjs.Graphics().p("AnYQEMAAAggHIOxAAMAAAAgHg");
	var mask_1_graphics_120 = new cjs.Graphics().p("AnVRMMAAAgiXIOrAAMAAAAiXg");
	var mask_1_graphics_121 = new cjs.Graphics().p("AnSSVMAAAgkpIOlAAMAAAAkpg");
	var mask_1_graphics_122 = new cjs.Graphics().p("AnQTdMAAAgm5IOhAAMAAAAm5g");
	var mask_1_graphics_123 = new cjs.Graphics().p("AnNUlMAAAgpJIObAAMAAAApJg");
	var mask_1_graphics_124 = new cjs.Graphics().p("AkSVuMAAAgrbIOWAAMAAAArbg");
	var mask_1_graphics_125 = new cjs.Graphics().p("AnLWWMAAAgsrIOXAAMAAAAsrg");
	var mask_1_graphics_126 = new cjs.Graphics().p("AnLW+MAAAgt7IOXAAMAAAAt7g");
	var mask_1_graphics_127 = new cjs.Graphics().p("AkSXmMAAAgvLIOWAAMAAAAvLg");
	var mask_1_graphics_128 = new cjs.Graphics().p("An/XmMAAAgvLIP/AAMAAAAvLg");
	var mask_1_graphics_129 = new cjs.Graphics().p("AnkXmMAAAgvLIRoAAMAAAAvLg");
	var mask_1_graphics_130 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_131 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_132 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_133 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_134 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_135 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_136 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_137 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_138 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_139 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(99).to({graphics:mask_1_graphics_99,x:32.3,y:123.2}).wait(1).to({graphics:mask_1_graphics_100,x:38,y:124}).wait(1).to({graphics:mask_1_graphics_101,x:43.8,y:124.8}).wait(1).to({graphics:mask_1_graphics_102,x:49.5,y:125.6}).wait(1).to({graphics:mask_1_graphics_103,x:55.3,y:126.5}).wait(1).to({graphics:mask_1_graphics_104,x:61,y:127.3}).wait(1).to({graphics:mask_1_graphics_105,x:66.8,y:128.1}).wait(1).to({graphics:mask_1_graphics_106,x:72.5,y:128.9}).wait(1).to({graphics:mask_1_graphics_107,x:64.4,y:72.9}).wait(1).to({graphics:mask_1_graphics_108,x:78.5,y:122.5}).wait(1).to({graphics:mask_1_graphics_109,x:78.8,y:115.2}).wait(1).to({graphics:mask_1_graphics_110,x:79.1,y:108}).wait(1).to({graphics:mask_1_graphics_111,x:79.3,y:100.8}).wait(1).to({graphics:mask_1_graphics_112,x:79.6,y:93.5}).wait(1).to({graphics:mask_1_graphics_113,x:79.9,y:86.3}).wait(1).to({graphics:mask_1_graphics_114,x:80.1,y:79}).wait(1).to({graphics:mask_1_graphics_115,x:80.4,y:71.8}).wait(1).to({graphics:mask_1_graphics_116,x:80.7,y:64.6}).wait(1).to({graphics:mask_1_graphics_117,x:81,y:57.3}).wait(1).to({graphics:mask_1_graphics_118,x:81.2,y:50.1}).wait(1).to({graphics:mask_1_graphics_119,x:81.5,y:42.9}).wait(1).to({graphics:mask_1_graphics_120,x:81.8,y:35.6}).wait(1).to({graphics:mask_1_graphics_121,x:82,y:28.4}).wait(1).to({graphics:mask_1_graphics_122,x:82.3,y:21.1}).wait(1).to({graphics:mask_1_graphics_123,x:82.6,y:13.9}).wait(1).to({graphics:mask_1_graphics_124,x:64.4,y:6.7}).wait(1).to({graphics:mask_1_graphics_125,x:82.9,y:2.7}).wait(1).to({graphics:mask_1_graphics_126,x:82.9,y:-1.2}).wait(1).to({graphics:mask_1_graphics_127,x:64.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_128,x:77.6,y:-5.2}).wait(1).to({graphics:mask_1_graphics_129,x:64.4,y:-5.3}).wait(1).to({graphics:mask_1_graphics_130,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_131,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_132,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_133,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_134,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_135,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_136,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_137,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_138,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_139,x:72.4,y:-5.3}).wait(33));

	// fl combustion2
	this.instance_1 = new lib.Mapadebits15();
	this.instance_1.setTransform(23.8,-152);

	this.instance_2 = new lib.Mapadebits14();
	this.instance_2.setTransform(-156.9,-151.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#313934").s().p("AoIgmICeABIhPBMgAFrgmICeABIhPBMg");
	this.shape_2.setTransform(-15.5,-119.6);

	this.instance_1.mask = this.instance_2.mask = this.shape_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.instance_2},{t:this.instance_1}]}).wait(172));

	// Layer 42 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_99 = new cjs.Graphics().p("AltJWIAAowIAoAAIAAIwg");
	var mask_2_graphics_100 = new cjs.Graphics().p("AhOEQIAAofICdAAIAAIfg");
	var mask_2_graphics_101 = new cjs.Graphics().p("AiKEIIAAoPIEVAAIAAIPg");
	var mask_2_graphics_102 = new cjs.Graphics().p("AjFEBIAAoBIGLAAIAAIBg");
	var mask_2_graphics_103 = new cjs.Graphics().p("AkBD5IAAnxIIDAAIAAHxg");
	var mask_2_graphics_104 = new cjs.Graphics().p("Ak8DyIAAnjIJ5AAIAAHjg");
	var mask_2_graphics_105 = new cjs.Graphics().p("Al4DqIAAnTILxAAIAAHTg");
	var mask_2_graphics_106 = new cjs.Graphics().p("Am0DiIAAnDINpAAIAAHDg");
	var mask_2_graphics_107 = new cjs.Graphics().p("AtKJWIAAm3IPgAAIAAG3g");
	var mask_2_graphics_108 = new cjs.Graphics().p("AnuEZIAAoxIPdAAIAAIxg");
	var mask_2_graphics_109 = new cjs.Graphics().p("AntFYIAAqvIPbAAIAAKvg");
	var mask_2_graphics_110 = new cjs.Graphics().p("AnsGWIAAsrIPZAAIAAMrg");
	var mask_2_graphics_111 = new cjs.Graphics().p("AnrHUIAAunIPXAAIAAOng");
	var mask_2_graphics_112 = new cjs.Graphics().p("AnqITIAAwlIPVAAIAAQlg");
	var mask_2_graphics_113 = new cjs.Graphics().p("AnpJRIAAyhIPTAAIAAShg");
	var mask_2_graphics_114 = new cjs.Graphics().p("AnoKQIAA0fIPRAAIAAUfg");
	var mask_2_graphics_115 = new cjs.Graphics().p("AnnLOIAA2bIPPAAIAAWbg");
	var mask_2_graphics_116 = new cjs.Graphics().p("AnmMMIAA4XIPNAAIAAYXg");
	var mask_2_graphics_117 = new cjs.Graphics().p("AnlNLIAA6VIPLAAIAAaVg");
	var mask_2_graphics_118 = new cjs.Graphics().p("AnkOJIAA8RIPJAAIAAcRg");
	var mask_2_graphics_119 = new cjs.Graphics().p("AnjPIIAA+PIPHAAIAAePg");
	var mask_2_graphics_120 = new cjs.Graphics().p("AniQGMAAAggLIPFAAMAAAAgLg");
	var mask_2_graphics_121 = new cjs.Graphics().p("AnhRFMAAAgiJIPDAAMAAAAiJg");
	var mask_2_graphics_122 = new cjs.Graphics().p("AngSDMAAAgkFIPBAAMAAAAkFg");
	var mask_2_graphics_123 = new cjs.Graphics().p("AnfTBMAAAgmBIO/AAMAAAAmBg");
	var mask_2_graphics_124 = new cjs.Graphics().p("AneUAMAAAgn/IO9AAMAAAAn/g");
	var mask_2_graphics_125 = new cjs.Graphics().p("AneUhMAAAgpBIO9AAMAAAApBg");
	var mask_2_graphics_126 = new cjs.Graphics().p("AneVCMAAAgqDIO9AAMAAAAqDg");
	var mask_2_graphics_127 = new cjs.Graphics().p("AtDVkMAAAgrHIO+AAMAAAArHg");
	var mask_2_graphics_128 = new cjs.Graphics().p("AoYVkMAAAgrHIQxAAMAAAArHg");
	var mask_2_graphics_129 = new cjs.Graphics().p("AtCVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_130 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_131 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_132 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_133 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_134 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_135 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_136 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_137 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_138 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_139 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_140 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(99).to({graphics:mask_2_graphics_99,x:-36.5,y:59.9}).wait(1).to({graphics:mask_2_graphics_100,x:-77.1,y:92.5}).wait(1).to({graphics:mask_2_graphics_101,x:-83.1,y:93.2}).wait(1).to({graphics:mask_2_graphics_102,x:-89,y:94}).wait(1).to({graphics:mask_2_graphics_103,x:-95,y:94.7}).wait(1).to({graphics:mask_2_graphics_104,x:-100.9,y:95.5}).wait(1).to({graphics:mask_2_graphics_105,x:-106.9,y:96.3}).wait(1).to({graphics:mask_2_graphics_106,x:-112.9,y:97}).wait(1).to({graphics:mask_2_graphics_107,x:-84.2,y:59.8}).wait(1).to({graphics:mask_2_graphics_108,x:-118.8,y:91.5}).wait(1).to({graphics:mask_2_graphics_109,x:-118.9,y:85.3}).wait(1).to({graphics:mask_2_graphics_110,x:-118.9,y:79.1}).wait(1).to({graphics:mask_2_graphics_111,x:-118.9,y:72.8}).wait(1).to({graphics:mask_2_graphics_112,x:-118.9,y:66.6}).wait(1).to({graphics:mask_2_graphics_113,x:-118.9,y:60.3}).wait(1).to({graphics:mask_2_graphics_114,x:-118.9,y:54.1}).wait(1).to({graphics:mask_2_graphics_115,x:-119,y:47.8}).wait(1).to({graphics:mask_2_graphics_116,x:-119,y:41.6}).wait(1).to({graphics:mask_2_graphics_117,x:-119,y:35.4}).wait(1).to({graphics:mask_2_graphics_118,x:-119,y:29.1}).wait(1).to({graphics:mask_2_graphics_119,x:-119,y:22.9}).wait(1).to({graphics:mask_2_graphics_120,x:-119.1,y:16.6}).wait(1).to({graphics:mask_2_graphics_121,x:-119.1,y:10.4}).wait(1).to({graphics:mask_2_graphics_122,x:-119.1,y:4.2}).wait(1).to({graphics:mask_2_graphics_123,x:-119.1,y:-2}).wait(1).to({graphics:mask_2_graphics_124,x:-119.1,y:-8.2}).wait(1).to({graphics:mask_2_graphics_125,x:-119.1,y:-11.6}).wait(1).to({graphics:mask_2_graphics_126,x:-119.1,y:-14.9}).wait(1).to({graphics:mask_2_graphics_127,x:-83.5,y:-18.2}).wait(1).to({graphics:mask_2_graphics_128,x:-113.4,y:-18.2}).wait(1).to({graphics:mask_2_graphics_129,x:-83.5,y:-18.2}).wait(1).to({graphics:mask_2_graphics_130,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_131,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_132,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_133,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_134,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_135,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_136,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_137,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_138,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_139,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_140,x:-107.6,y:-18.2}).wait(32));

	// fl combustion1
	this.instance_3 = new lib.Mapadebits24b();
	this.instance_3.setTransform(-156.4,70.2);

	this.instance_4 = new lib.Mapadebits23b();
	this.instance_4.setTransform(-88.5,-151.9);

	this.instance_5 = new lib.Mapadebits22b();
	this.instance_5.setTransform(-156.8,-152);

	this.instance_6 = new lib.Mapadebits20();
	this.instance_6.setTransform(-157,-129.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#313934").s().p("AoIgmICeABIhPBMgAFrgmICeABIhPBMg");
	this.shape_3.setTransform(-15.5,-119.6);

	this.instance_3.mask = this.instance_4.mask = this.instance_5.mask = this.instance_6.mask = this.shape_3.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).wait(172));

	// Layer 40 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_69 = new cjs.Graphics().p("ArTAsIAAhYIWoAAIAABYg");
	var mask_3_graphics_70 = new cjs.Graphics().p("ArTA/IAAh+IWoAAIAAB+g");
	var mask_3_graphics_71 = new cjs.Graphics().p("ArTBTIAAilIWoAAIAAClg");
	var mask_3_graphics_72 = new cjs.Graphics().p("ArTBmIAAjLIWoAAIAADLg");
	var mask_3_graphics_73 = new cjs.Graphics().p("ArTB4IAAjwIWoAAIAADwg");
	var mask_3_graphics_74 = new cjs.Graphics().p("ArTCLIAAkWIWoAAIAAEWg");
	var mask_3_graphics_75 = new cjs.Graphics().p("ArTCfIAAk9IWoAAIAAE9g");
	var mask_3_graphics_76 = new cjs.Graphics().p("ArTCyIAAljIWoAAIAAFjg");
	var mask_3_graphics_77 = new cjs.Graphics().p("ArTDEIAAmIIWoAAIAAGIg");
	var mask_3_graphics_78 = new cjs.Graphics().p("ArTDXIAAmuIWoAAIAAGug");
	var mask_3_graphics_79 = new cjs.Graphics().p("ArTDqIAAnUIWoAAIAAHUg");
	var mask_3_graphics_80 = new cjs.Graphics().p("ArTD+IAAn7IWoAAIAAH7g");
	var mask_3_graphics_81 = new cjs.Graphics().p("ArTERIAAohIWoAAIAAIhg");
	var mask_3_graphics_82 = new cjs.Graphics().p("ArTEjIAApGIWoAAIAAJGg");
	var mask_3_graphics_83 = new cjs.Graphics().p("ArTE2IAApsIWoAAIAAJsg");
	var mask_3_graphics_84 = new cjs.Graphics().p("ArTGOIAAqSIWoAAIAAKSg");
	var mask_3_graphics_85 = new cjs.Graphics().p("ArTFJIAAqRIWoAAIAAKRg");
	var mask_3_graphics_86 = new cjs.Graphics().p("ArTFKIAAqTIWoAAIAAKTg");
	var mask_3_graphics_87 = new cjs.Graphics().p("ArTFJIAAqRIWoAAIAAKRg");
	var mask_3_graphics_88 = new cjs.Graphics().p("ArTFKIAAqTIWoAAIAAKTg");
	var mask_3_graphics_89 = new cjs.Graphics().p("ArTFJIAAqSIWoAAIAAKSg");
	var mask_3_graphics_90 = new cjs.Graphics().p("ArTFKIAAqSIWoAAIAAKSg");
	var mask_3_graphics_91 = new cjs.Graphics().p("ArTFJIAAqSIWoAAIAAKSg");
	var mask_3_graphics_92 = new cjs.Graphics().p("ArTFJIAAqRIWoAAIAAKRg");
	var mask_3_graphics_93 = new cjs.Graphics().p("ArTFKIAAqTIWoAAIAAKTg");
	var mask_3_graphics_94 = new cjs.Graphics().p("ArTFJIAAqSIWoAAIAAKSg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(69).to({graphics:mask_3_graphics_69,x:-14.7,y:18.2}).wait(1).to({graphics:mask_3_graphics_70,x:-14.7,y:20.1}).wait(1).to({graphics:mask_3_graphics_71,x:-14.7,y:22}).wait(1).to({graphics:mask_3_graphics_72,x:-14.7,y:23.9}).wait(1).to({graphics:mask_3_graphics_73,x:-14.7,y:25.8}).wait(1).to({graphics:mask_3_graphics_74,x:-14.7,y:27.7}).wait(1).to({graphics:mask_3_graphics_75,x:-14.7,y:29.6}).wait(1).to({graphics:mask_3_graphics_76,x:-14.7,y:31.5}).wait(1).to({graphics:mask_3_graphics_77,x:-14.7,y:33.4}).wait(1).to({graphics:mask_3_graphics_78,x:-14.7,y:35.3}).wait(1).to({graphics:mask_3_graphics_79,x:-14.7,y:37.2}).wait(1).to({graphics:mask_3_graphics_80,x:-14.7,y:39.1}).wait(1).to({graphics:mask_3_graphics_81,x:-14.7,y:41}).wait(1).to({graphics:mask_3_graphics_82,x:-14.7,y:42.9}).wait(1).to({graphics:mask_3_graphics_83,x:-14.7,y:44.8}).wait(1).to({graphics:mask_3_graphics_84,x:-14.7,y:39.9}).wait(1).to({graphics:mask_3_graphics_85,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_86,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_87,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_88,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_89,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_90,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_91,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_92,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_93,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_94,x:-14.7,y:46.7}).wait(78));

	// fl mineralizacion
	this.instance_7 = new lib.Mapadebits17();
	this.instance_7.setTransform(-84.3,26.7);

	this.instance_8 = new lib.Mapadebits16();
	this.instance_8.setTransform(12.6,26.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00004D").s().p("AEBg2IBvBtIhvAAgAlwA3IBxhtIgBBtg");
	this.shape_4.setTransform(-16,63.7);

	this.instance_7.mask = this.instance_8.mask = this.shape_4.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.instance_8},{t:this.instance_7}]}).wait(172));

	// Layer 39 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_34 = new cjs.Graphics().p("AxKATIAAglMAiVAAAIAAAlg");
	var mask_4_graphics_35 = new cjs.Graphics().p("AxKAnIAAhNMAiVAAAIAABNg");
	var mask_4_graphics_36 = new cjs.Graphics().p("AxKA6IAAhzMAiVAAAIAABzg");
	var mask_4_graphics_37 = new cjs.Graphics().p("AxKBNIAAiZMAiVAAAIAACZg");
	var mask_4_graphics_38 = new cjs.Graphics().p("AxKBhIAAjBMAiVAAAIAADBg");
	var mask_4_graphics_39 = new cjs.Graphics().p("AxKB0IAAjnMAiVAAAIAADng");
	var mask_4_graphics_40 = new cjs.Graphics().p("AxKCHIAAkNMAiVAAAIAAENg");
	var mask_4_graphics_41 = new cjs.Graphics().p("AxKCaIAAkzMAiVAAAIAAEzg");
	var mask_4_graphics_42 = new cjs.Graphics().p("AxKCuIAAlbMAiVAAAIAAFbg");
	var mask_4_graphics_43 = new cjs.Graphics().p("AxKDBIAAmBMAiVAAAIAAGBg");
	var mask_4_graphics_44 = new cjs.Graphics().p("AxKDUIAAmnMAiVAAAIAAGng");
	var mask_4_graphics_45 = new cjs.Graphics().p("AxKDnIAAnNMAiVAAAIAAHNg");
	var mask_4_graphics_46 = new cjs.Graphics().p("AxKD7IAAn1MAiVAAAIAAH1g");
	var mask_4_graphics_47 = new cjs.Graphics().p("AxKEOIAAobMAiVAAAIAAIbg");
	var mask_4_graphics_48 = new cjs.Graphics().p("AxKEhIAApBMAiVAAAIAAJBg");
	var mask_4_graphics_49 = new cjs.Graphics().p("AxKE0IAApnMAiVAAAIAAJng");
	var mask_4_graphics_50 = new cjs.Graphics().p("AxKFIIAAqPMAiVAAAIAAKPg");
	var mask_4_graphics_51 = new cjs.Graphics().p("AxKFbIAAq1MAiVAAAIAAK1g");
	var mask_4_graphics_52 = new cjs.Graphics().p("AxKFuIAArbMAiVAAAIAALbg");
	var mask_4_graphics_53 = new cjs.Graphics().p("AxKGBIAAsBMAiVAAAIAAMBg");
	var mask_4_graphics_54 = new cjs.Graphics().p("AxKEgIAAsoMAiVAAAIAAMog");
	var mask_4_graphics_55 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_56 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_57 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_58 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_59 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_60 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_61 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_62 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_63 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_64 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(34).to({graphics:mask_4_graphics_34,x:-16.1,y:-25.2}).wait(1).to({graphics:mask_4_graphics_35,x:-16.1,y:-27.1}).wait(1).to({graphics:mask_4_graphics_36,x:-16.1,y:-29.1}).wait(1).to({graphics:mask_4_graphics_37,x:-16.1,y:-31}).wait(1).to({graphics:mask_4_graphics_38,x:-16.1,y:-32.9}).wait(1).to({graphics:mask_4_graphics_39,x:-16.1,y:-34.8}).wait(1).to({graphics:mask_4_graphics_40,x:-16.1,y:-36.8}).wait(1).to({graphics:mask_4_graphics_41,x:-16.1,y:-38.7}).wait(1).to({graphics:mask_4_graphics_42,x:-16.1,y:-40.6}).wait(1).to({graphics:mask_4_graphics_43,x:-16.1,y:-42.5}).wait(1).to({graphics:mask_4_graphics_44,x:-16.1,y:-44.5}).wait(1).to({graphics:mask_4_graphics_45,x:-16.1,y:-46.4}).wait(1).to({graphics:mask_4_graphics_46,x:-16.1,y:-48.3}).wait(1).to({graphics:mask_4_graphics_47,x:-16.1,y:-50.2}).wait(1).to({graphics:mask_4_graphics_48,x:-16.1,y:-52.2}).wait(1).to({graphics:mask_4_graphics_49,x:-16.1,y:-54.1}).wait(1).to({graphics:mask_4_graphics_50,x:-16.1,y:-56}).wait(1).to({graphics:mask_4_graphics_51,x:-16.1,y:-57.9}).wait(1).to({graphics:mask_4_graphics_52,x:-16.1,y:-59.9}).wait(1).to({graphics:mask_4_graphics_53,x:-16.1,y:-61.8}).wait(1).to({graphics:mask_4_graphics_54,x:-16.1,y:-52.1}).wait(1).to({graphics:mask_4_graphics_55,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_56,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_57,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_58,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_59,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_60,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_61,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_62,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_63,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_64,x:-16.1,y:-63.8}).wait(108));

	// fl respiracion
	this.instance_9 = new lib.Mapadebits21();
	this.instance_9.setTransform(-110,-101.3);

	this.instance_9.mask = mask_4;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9}]}).wait(172));

	// Layer 38 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_4 = new cjs.Graphics().p("AkSBPIAAieIIlAAIAACeg");
	var mask_5_graphics_5 = new cjs.Graphics().p("AkWBdIAAi6IItAAIAAC6g");
	var mask_5_graphics_6 = new cjs.Graphics().p("AkaBrIAAjWII1AAIAADWg");
	var mask_5_graphics_7 = new cjs.Graphics().p("AkfB5IAAjyII+AAIAADyg");
	var mask_5_graphics_8 = new cjs.Graphics().p("AkjCHIAAkOIJHAAIAAEOg");
	var mask_5_graphics_9 = new cjs.Graphics().p("AknCWIAAkrIJPAAIAAErg");
	var mask_5_graphics_10 = new cjs.Graphics().p("AkrCkIAAlHIJYAAIAAFHg");
	var mask_5_graphics_11 = new cjs.Graphics().p("AkwCyIAAljIJhAAIAAFjg");
	var mask_5_graphics_12 = new cjs.Graphics().p("Ak0DAIAAl/IJpAAIAAF/g");
	var mask_5_graphics_13 = new cjs.Graphics().p("Ak5DNIAAmaIJyAAIAAGag");
	var mask_5_graphics_14 = new cjs.Graphics().p("Ak9DbIAAm2IJ7AAIAAG2g");
	var mask_5_graphics_15 = new cjs.Graphics().p("AlBDpIAAnSIKDAAIAAHSg");
	var mask_5_graphics_16 = new cjs.Graphics().p("AlGD3IAAnuIKNAAIAAHug");
	var mask_5_graphics_17 = new cjs.Graphics().p("AlKEFIAAoKIKVAAIAAIKg");
	var mask_5_graphics_18 = new cjs.Graphics().p("AlOEUIAAonIKdAAIAAIng");
	var mask_5_graphics_19 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_20 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_21 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_22 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_23 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_24 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_25 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_26 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_27 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_28 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_29 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_5_graphics_4,x:-51.7,y:-81.3}).wait(1).to({graphics:mask_5_graphics_5,x:-52.5,y:-79.9}).wait(1).to({graphics:mask_5_graphics_6,x:-53.4,y:-78.5}).wait(1).to({graphics:mask_5_graphics_7,x:-54.3,y:-77.1}).wait(1).to({graphics:mask_5_graphics_8,x:-55.1,y:-75.7}).wait(1).to({graphics:mask_5_graphics_9,x:-56,y:-74.3}).wait(1).to({graphics:mask_5_graphics_10,x:-56.9,y:-72.9}).wait(1).to({graphics:mask_5_graphics_11,x:-57.7,y:-71.5}).wait(1).to({graphics:mask_5_graphics_12,x:-58.6,y:-70.1}).wait(1).to({graphics:mask_5_graphics_13,x:-59.5,y:-68.7}).wait(1).to({graphics:mask_5_graphics_14,x:-60.3,y:-67.3}).wait(1).to({graphics:mask_5_graphics_15,x:-61.2,y:-65.9}).wait(1).to({graphics:mask_5_graphics_16,x:-62.1,y:-64.5}).wait(1).to({graphics:mask_5_graphics_17,x:-62.9,y:-63.1}).wait(1).to({graphics:mask_5_graphics_18,x:-63.8,y:-61.7}).wait(1).to({graphics:mask_5_graphics_19,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_20,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_21,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_22,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_23,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_24,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_25,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_26,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_27,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_28,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_29,x:-64.7,y:-60.3}).wait(143));

	// fl fotosintesis
	this.instance_10 = new lib.Mapadebits19();
	this.instance_10.setTransform(-94.9,-73.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#65642E").s().p("AhNgmICbABIhOBMg");
	this.shape_5.setTransform(-89.8,-36.6);

	this.instance_10.mask = this.shape_5.mask = mask_5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.instance_10}]}).wait(172));

	// co2
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#277B7B").s().p("ABBAxIAAgKIAKgIIAIgGIAHgIIABgGQAAgFgCgBQgCgCgFAAIgHABIgHADIgCAAIAAgKIAIgCIALgBQAKAAAGAEQAFACAAAJQAAAFgCAFIgIAKIgHAFIgFAEIAZAAIAAALgAgRAXQgLgMAAgRQAAgTALgLQALgMARAAQAUAAALAMQAKALAAATQAAARgKAMQgLALgUAAQgRAAgLgLgAAEgfQgEABgBAEQgCADgCAFQgCAFAAAHQAAAGACAEQACAFACAEQABADAEABIAHACQAEAAAEgCQADgBADgEIAFgIIABgKQAAgHgCgFQgBgFgDgDIgGgFIgIgBIgHABgAhTAfQgIgCgFgGQgGgFgDgIQgDgHAAgJQAAgJADgIQADgIAGgFQAEgFAJgDQAHgDAKAAIAIAAIAIACIAGACIAGADIAAATIgDAAIgEgDIgFgEQgCgCgEgBIgIgBQgEAAgEACIgHAEQgDADgCAFQgCAFAAAHQAAAGACAFQACAFADADQAEADAEABIAHABIAIgBIAHgDIAFgDIADgDIADAAIAAATIgGACIgGACIgHACIgJABQgKAAgHgDg");
	this.shape_6.setTransform(-16.2,-77.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6}]}).wait(172));

	// pastilles
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#CECEA8").ss(1,1,1,3,true).p("AIIFmIwPAAIAAkpIAAmiIQPAAIAAGigAoHA9IQPAA");
	this.shape_7.setTransform(-16,107.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#CECEA8").ss(1,1,1,3,true).p("AIHDaIwNAAIAAmzIQNAAg");
	this.shape_8.setTransform(-15.7,-92.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7}]}).wait(172));

	// peix-planta
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#277B7B").s().p("AhKBDQgWgVgMgaIgEgKIhNBNIgDACIgEgBIgCgDIAAgEIAIgTQAFgTADgTIABgNIAAgLQAAgggKghIgHgUIAAgDIACgEQABAAAAAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAAAIBNBOIAEgKIAAABQAMgYAVgWQAxgwBDABQAhAAAdALQAeAMAZAYQAeAfALAlIAAAEQgMAjgcAcQgXAXgaAMIgBABQgfAOgkAAQhDAAgxgygAg/g4QgTATgLAWIAAABIgGANIAGAOQALAXAUAUQAsAsA8AAQAeAAAagKQgegpAAg0QAAgxAZgmQgZgJgbAAQg9AAgrArgABKgDQgBAyAeAoIAAAAQAYgKAUgVQAZgYALgfQgLgegagbQgWgVgagLQgZAkABAxgAizA+IA/g+IAAgCIhAhAQAGAUACASIANAAIABAAIAAACIgBAAIgMAAIABAMIAOAAIAAABIAAABIgOAAIAAALIAYAAIAAABIAAAAIgYAAIAAALIAOAAIAAAAIAAABIAAABIgOgBIgBANIAIABIABAAIAAABIAAAAIgBAAIgIAAQgDARgFASgAB1gXQgEgEABgFQgBgEAEgEQADgDAFAAQAFAAADADQAEAEAAAEQAAAFgEAEQgDADgFAAQgFAAgDgDg");
	this.shape_9.setTransform(60.4,-7.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#277B7B").s().p("AAAC8QgBgDAAgDIAAhNIgCgBIgvguQgMAFgPAAQgdAAgUgVQgVgVAAgbQAAgOAFgMIACgDIADgCQALgEAPAAQAdgBAVAVQAUAVAAAbQAAAOgEAMIgBABIAtAsIAAhyIgCgBIguguIgBAAQgMAFgPAAQgdAAgUgUQgVgVAAgdQAAgOAFgNIACgCIADgCQALgFAPAAQAdAAAVAVQAUAUAAAdQAAAOgEAMIgBABIAtAtIAAifQAAgEABgCQACgCADAAQAEAAACACQACACABAEIAAC9IAggfIgBgCQgEgLABgNQgBgdAVgVQAVgVAdABIAAAAQAOAAAMAEIADACIACADQAFAMAAAOQAAAdgVAVQgUAVgdAAQgPAAgMgFIgBgBIgkAiIAAB0IAhghIgBAAQgFgMABgOIAAgBQgBgdAVgUQAVgVAdAAIAAAAQAOAAAMAFIADACIACADQAFALAAAPQAAAdgVAVQgUAUgdAAQgPAAgMgEIgBgBIgkAlIAAArQgBADgCADQgCACgEAAQgDAAgCgCgABABZQAGACAIAAQAVAAARgQQAPgQAAgWQAAgJgCgIQgIgCgJAAQgPAAgMAHIACABIABACIAAARIAIgIIAAgLIABgCIACgBIACABIABACIAAAGIAHgHIACAAIACAAIABACIgBACIgGAGIAGAAIACABIAAACIAAACIgCABIgMgBIgIAIIASAAIACABIABACIgBACIgCABIgXAAIgCABIAAAEIgDADIACAAIAaAAIACABIABACIgBACIgCABIgZgBIgIAIIARAAIACABIABACIgBACIgCABIgXgBIAAABIAAAAgABKAiQgQAPABAWIAAABQgBAGACAHIAHgHIAAgXIABgCIACgBIACABIABACIAAARIAIgHIgBgaIABgCIACgBIAAgIIAAgCIgJAIgAhvgZQgJAAgIADQgCAHAAAJQgBAVARAQQAPAPAWAAQAIAAAGgCIgIgIIgXAAIgCgBIgBgCIABgCIACAAIARgBIgHgHIAAAAIgaAAIgCgBIgBgCIABgCIACgBIAUAAIgIgIIgXAAIgCAAIgBgCIABgCIACgBIARAAIgHgGIgLAAIgCgBQgBAAAAAAQAAAAgBAAQAAgBAAAAQAAAAAAgBIACgCIABgBIAGAAIgFgGIgBgBIABgCIACgBIABABIAHAGIAAgGIABgCIACAAIACABIABACIAAALIAHAGIABgQIAAgCIADgBIACABIAAACIAAAVIAIAIIAAgSIABgCIACgBIACABIABACIAAAYIAHAIIAAgSIABgCIACgBIACABIABACIAAAXIAHAHQACgGAAgHQAAgWgQgOQgQgQgVAAIgBAAgABIgoIgCABIgHAHIAPACQAVAAARgQQAPgPAAgWIAAgBQAAgJgCgHQgIgDgJAAQgWAAgQAQIAAAAQgQAQABAWQgBAGACAGIAHgHIAAgWIABgCIACgBIACABIABACIAAARIAIgHIgBgaIABgCIACgBIACABIABACIAAAUIAIgIIAAgXIAAgCIACgBIACABIABACIAAASIAIgIIAAgMIABgCIACAAIACAAIABACIAAAHIAHgIIACAAIACAAIABACIgBACIgGAGIAGAAIACABIAAACIAAACIgCABIgMAAIgHAIIARAAIACABIABABIgBACIgCABIgXAAIgIAIIAUABIACAAIABACIgBACIgCABIgZAAIgEADIAAABIgBAAIgDADIARAAIACABIABACIgBACIgCABIgXAAgAiAiRQgCAIAAAJQgBAWARAQQAPAPAWAAQAIAAAGgBIgIgJIgXABIgCgBIgBgCIABgCIACgBIARAAIgHgIIgaAAIgCgBIgBgBIABgCIACgBIAUAAIgIgIIgXAAIgCgBIgBgCIABgCIACgBIARAAIgHgIIgLAAIgCAAIgCgCQAAgBAAAAQAAAAAAgBQABAAAAAAQAAAAABAAIABgBIAGAAIgFgGIgBgCIABgCIACgBIABABIAHAHIAAgGIABgCIACgBIACABIABACIAAALIAHAIIABgRIAAgCIADgBIACABIAAACIAAAXIAIAIIAAgVIABgCIACAAIACAAIABACIAAAaIAHAIIAAgRIABgCIACgBIACABIABACIAAAXIAHAHQACgHAAgHQAAgWgQgQQgQgPgWAAQgJAAgIACg");
	this.shape_10.setTransform(-93.1,-7.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9}]}).wait(172));

	// peix-planta suport
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(39,123,123,0.2)").s().p("AjqDsIAAnXIHVAAIAAHXg");
	this.shape_11.setTransform(60.4,-7.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(39,123,123,0.2)").s().p("AjrDsIAAnXIHXAAIAAHXg");
	this.shape_12.setTransform(-93.1,-7.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11}]}).wait(172));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-429.2,-152,555.1,295.4);

(lib.p3a = function(tipo,mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{fotosintesis:4,respiracion:34,mineralizacion:69,combustion:99,nutricion:140});

	// Txt
	this.text = new cjs.Text(txt['btcom9'], "bold 11px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 12;
	this.text.lineWidth = 91;
	this.text.setTransform(-18.6,26.6);

	this.text_1 = new cjs.Text(txt['btcom8'], "bold 11px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 12;
	this.text_1.lineWidth = 91;
	this.text_1.setTransform(-18.1,-65.1);

	this.text_2 = new cjs.Text(txt['btcom7'], "bold 11px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 12;
	this.text_2.lineWidth = 91;
	this.text_2.setTransform(-18.6,-32.6);

	this.text_3 = new cjs.Text(txt['btcom6'], "bold 11px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 12;
	this.text_3.lineWidth = 75;
	this.text_3.setTransform(-109.4,62.6);

	this.text_4 = new cjs.Text(txt['btcom6'], "bold 11px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 12;
	this.text_4.lineWidth = 75;
	this.text_4.setTransform(73,96.6);

	this.text_5 = new cjs.Text(txt['btcom5'], "bold 11px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 12;
	this.text_5.lineWidth = 75;
	this.text_5.setTransform(-109.5,-117.8);

	this.text_6 = new cjs.Text(txt['btcom5'], "bold 11px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 12;
	this.text_6.lineWidth = 75;
	this.text_6.setTransform(73.5,-118);

	this.text_7 = new cjs.Text(txt['btcom4'], "12px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 9;
	this.text_7.lineWidth = 100;
	this.text_7.setTransform(-18,112.4);

	this.text_8 = new cjs.Text(txt['btcom3'], "12px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 9;
	this.text_8.lineWidth = 100;
	this.text_8.setTransform(-18.2,70.5);

	this.text_9 = new cjs.Text(txt['btcom2'], "12px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 13;
	this.text_9.lineWidth = 61;
	this.text_9.setTransform(58.1,12.9);

	this.text_10 = new cjs.Text(txt['btcom1'], "12px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 13;
	this.text_10.lineWidth = 61;
	this.text_10.setTransform(-95.2,12.9);

	this.text_11 = new cjs.Text(txt['texloesq_1']+"\n"+txt['texloesq_3'], "12px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 12;
	this.text_11.lineWidth = 100;
	this.text_11.setTransform(-18,-114.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(1));

	// botons
	


	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_140 = new cjs.Graphics().p("AgwCNIAAkZIBgAAIAAEZg");
	var mask_graphics_141 = new cjs.Graphics().p("AhICNIAAkZICRAAIAAEZg");
	var mask_graphics_142 = new cjs.Graphics().p("AhhCNIAAkZIDDAAIAAEZg");
	var mask_graphics_143 = new cjs.Graphics().p("Ah6CNIAAkZID1AAIAAEZg");
	var mask_graphics_144 = new cjs.Graphics().p("AiTCNIAAkZIEnAAIAAEZg");
	var mask_graphics_145 = new cjs.Graphics().p("AisCNIAAkZIFZAAIAAEZg");
	var mask_graphics_146 = new cjs.Graphics().p("AjFCNIAAkZIGLAAIAAEZg");
	var mask_graphics_147 = new cjs.Graphics().p("AjeCNIAAkZIG9AAIAAEZg");
	var mask_graphics_148 = new cjs.Graphics().p("Aj3CNIAAkZIHvAAIAAEZg");
	var mask_graphics_149 = new cjs.Graphics().p("AkQCNIAAkZIIhAAIAAEZg");
	var mask_graphics_150 = new cjs.Graphics().p("AkpCNIAAkZIJTAAIAAEZg");
	var mask_graphics_151 = new cjs.Graphics().p("AlCCNIAAkZIKFAAIAAEZg");
	var mask_graphics_152 = new cjs.Graphics().p("AlbCNIAAkZIK3AAIAAEZg");
	var mask_graphics_153 = new cjs.Graphics().p("Al0CNIAAkZILpAAIAAEZg");
	var mask_graphics_154 = new cjs.Graphics().p("AmNCNIAAkZIMbAAIAAEZg");
	var mask_graphics_155 = new cjs.Graphics().p("AmmCNIAAkZINNAAIAAEZg");
	var mask_graphics_156 = new cjs.Graphics().p("Am/CNIAAkZIN/AAIAAEZg");
	var mask_graphics_157 = new cjs.Graphics().p("AnYCNIAAkZIOxAAIAAEZg");
	var mask_graphics_158 = new cjs.Graphics().p("AnxCNIAAkZIPjAAIAAEZg");
	var mask_graphics_159 = new cjs.Graphics().p("AoKCNIAAkZIQVAAIAAEZg");
	var mask_graphics_160 = new cjs.Graphics().p("AojCNIAAkZIRHAAIAAEZg");
	var mask_graphics_161 = new cjs.Graphics().p("Ao8CNIAAkZIR5AAIAAEZg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_140,x:-73.6,y:-8.2}).wait(1).to({graphics:mask_graphics_141,x:-71.1,y:-8.2}).wait(1).to({graphics:mask_graphics_142,x:-68.6,y:-8.2}).wait(1).to({graphics:mask_graphics_143,x:-66.1,y:-8.2}).wait(1).to({graphics:mask_graphics_144,x:-63.6,y:-8.2}).wait(1).to({graphics:mask_graphics_145,x:-61.1,y:-8.2}).wait(1).to({graphics:mask_graphics_146,x:-58.6,y:-8.2}).wait(1).to({graphics:mask_graphics_147,x:-56.1,y:-8.2}).wait(1).to({graphics:mask_graphics_148,x:-53.6,y:-8.2}).wait(1).to({graphics:mask_graphics_149,x:-51.1,y:-8.2}).wait(1).to({graphics:mask_graphics_150,x:-48.6,y:-8.2}).wait(1).to({graphics:mask_graphics_151,x:-46.1,y:-8.2}).wait(1).to({graphics:mask_graphics_152,x:-43.6,y:-8.2}).wait(1).to({graphics:mask_graphics_153,x:-41.1,y:-8.2}).wait(1).to({graphics:mask_graphics_154,x:-38.6,y:-8.2}).wait(1).to({graphics:mask_graphics_155,x:-36.1,y:-8.2}).wait(1).to({graphics:mask_graphics_156,x:-33.6,y:-8.2}).wait(1).to({graphics:mask_graphics_157,x:-31.1,y:-8.2}).wait(1).to({graphics:mask_graphics_158,x:-28.6,y:-8.2}).wait(1).to({graphics:mask_graphics_159,x:-26.1,y:-8.2}).wait(1).to({graphics:mask_graphics_160,x:-23.6,y:-8.2}).wait(1).to({graphics:mask_graphics_161,x:-21.1,y:-8.2}).wait(11));

	// fl nutricion
	this.instance = new lib.Mapadebits18();
	this.instance.setTransform(-72.1,-13.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#203936").s().p("AglhNIBMBNIhNBOg");
	this.shape_1.setTransform(32.3,-8.2);
if (tipo==5)
	this.instance.mask = this.shape_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.instance}]}).wait(1));

	// Layer 43 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_99 = new cjs.Graphics().p("AgsDhIAAnAIBYAAIAAHAg");
	var mask_1_graphics_100 = new cjs.Graphics().p("AhlDYIAAmvIDLAAIAAGvg");
	var mask_1_graphics_101 = new cjs.Graphics().p("AifDQIAAmfIE/AAIAAGfg");
	var mask_1_graphics_102 = new cjs.Graphics().p("AjYDIIAAmPIGxAAIAAGPg");
	var mask_1_graphics_103 = new cjs.Graphics().p("AkSDAIAAl/IIkAAIAAF/g");
	var mask_1_graphics_104 = new cjs.Graphics().p("AlLC4IAAlvIKXAAIAAFvg");
	var mask_1_graphics_105 = new cjs.Graphics().p("AmFCwIAAlfIMLAAIAAFfg");
	var mask_1_graphics_106 = new cjs.Graphics().p("Am+CoIAAlPIN9AAIAAFPg");
	var mask_1_graphics_107 = new cjs.Graphics().p("AltLYIAAlAIPwAAIAAFAg");
	var mask_1_graphics_108 = new cjs.Graphics().p("An1DoIAAnPIPrAAIAAHPg");
	var mask_1_graphics_109 = new cjs.Graphics().p("AnyEwIAApfIPlAAIAAJfg");
	var mask_1_graphics_110 = new cjs.Graphics().p("AnwF5IAArxIPhAAIAALxg");
	var mask_1_graphics_111 = new cjs.Graphics().p("AntHBIAAuBIPbAAIAAOBg");
	var mask_1_graphics_112 = new cjs.Graphics().p("AnqIJIAAwRIPVAAIAAQRg");
	var mask_1_graphics_113 = new cjs.Graphics().p("AnoJSIAAyjIPRAAIAASjg");
	var mask_1_graphics_114 = new cjs.Graphics().p("AnlKaIAA0zIPLAAIAAUzg");
	var mask_1_graphics_115 = new cjs.Graphics().p("AniLiIAA3DIPFAAIAAXDg");
	var mask_1_graphics_116 = new cjs.Graphics().p("AngMrIAA5VIPBAAIAAZVg");
	var mask_1_graphics_117 = new cjs.Graphics().p("AndNzIAA7lIO7AAIAAblg");
	var mask_1_graphics_118 = new cjs.Graphics().p("AnaO8IAA93IO1AAIAAd3g");
	var mask_1_graphics_119 = new cjs.Graphics().p("AnYQEMAAAggHIOxAAMAAAAgHg");
	var mask_1_graphics_120 = new cjs.Graphics().p("AnVRMMAAAgiXIOrAAMAAAAiXg");
	var mask_1_graphics_121 = new cjs.Graphics().p("AnSSVMAAAgkpIOlAAMAAAAkpg");
	var mask_1_graphics_122 = new cjs.Graphics().p("AnQTdMAAAgm5IOhAAMAAAAm5g");
	var mask_1_graphics_123 = new cjs.Graphics().p("AnNUlMAAAgpJIObAAMAAAApJg");
	var mask_1_graphics_124 = new cjs.Graphics().p("AkSVuMAAAgrbIOWAAMAAAArbg");
	var mask_1_graphics_125 = new cjs.Graphics().p("AnLWWMAAAgsrIOXAAMAAAAsrg");
	var mask_1_graphics_126 = new cjs.Graphics().p("AnLW+MAAAgt7IOXAAMAAAAt7g");
	var mask_1_graphics_127 = new cjs.Graphics().p("AkSXmMAAAgvLIOWAAMAAAAvLg");
	var mask_1_graphics_128 = new cjs.Graphics().p("An/XmMAAAgvLIP/AAMAAAAvLg");
	var mask_1_graphics_129 = new cjs.Graphics().p("AnkXmMAAAgvLIRoAAMAAAAvLg");
	var mask_1_graphics_130 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_131 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_132 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_133 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_134 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_135 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_136 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_137 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_138 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");
	var mask_1_graphics_139 = new cjs.Graphics().p("Ao0XmMAAAgvLIRpAAMAAAAvLg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_1_graphics_99,x:32.3,y:123.2}).wait(1).to({graphics:mask_1_graphics_100,x:38,y:124}).wait(1).to({graphics:mask_1_graphics_101,x:43.8,y:124.8}).wait(1).to({graphics:mask_1_graphics_102,x:49.5,y:125.6}).wait(1).to({graphics:mask_1_graphics_103,x:55.3,y:126.5}).wait(1).to({graphics:mask_1_graphics_104,x:61,y:127.3}).wait(1).to({graphics:mask_1_graphics_105,x:66.8,y:128.1}).wait(1).to({graphics:mask_1_graphics_106,x:72.5,y:128.9}).wait(1).to({graphics:mask_1_graphics_107,x:64.4,y:72.9}).wait(1).to({graphics:mask_1_graphics_108,x:78.5,y:122.5}).wait(1).to({graphics:mask_1_graphics_109,x:78.8,y:115.2}).wait(1).to({graphics:mask_1_graphics_110,x:79.1,y:108}).wait(1).to({graphics:mask_1_graphics_111,x:79.3,y:100.8}).wait(1).to({graphics:mask_1_graphics_112,x:79.6,y:93.5}).wait(1).to({graphics:mask_1_graphics_113,x:79.9,y:86.3}).wait(1).to({graphics:mask_1_graphics_114,x:80.1,y:79}).wait(1).to({graphics:mask_1_graphics_115,x:80.4,y:71.8}).wait(1).to({graphics:mask_1_graphics_116,x:80.7,y:64.6}).wait(1).to({graphics:mask_1_graphics_117,x:81,y:57.3}).wait(1).to({graphics:mask_1_graphics_118,x:81.2,y:50.1}).wait(1).to({graphics:mask_1_graphics_119,x:81.5,y:42.9}).wait(1).to({graphics:mask_1_graphics_120,x:81.8,y:35.6}).wait(1).to({graphics:mask_1_graphics_121,x:82,y:28.4}).wait(1).to({graphics:mask_1_graphics_122,x:82.3,y:21.1}).wait(1).to({graphics:mask_1_graphics_123,x:82.6,y:13.9}).wait(1).to({graphics:mask_1_graphics_124,x:64.4,y:6.7}).wait(1).to({graphics:mask_1_graphics_125,x:82.9,y:2.7}).wait(1).to({graphics:mask_1_graphics_126,x:82.9,y:-1.2}).wait(1).to({graphics:mask_1_graphics_127,x:64.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_128,x:77.6,y:-5.2}).wait(1).to({graphics:mask_1_graphics_129,x:64.4,y:-5.3}).wait(1).to({graphics:mask_1_graphics_130,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_131,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_132,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_133,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_134,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_135,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_136,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_137,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_138,x:72.4,y:-5.2}).wait(1).to({graphics:mask_1_graphics_139,x:72.4,y:-5.3}).wait(1));

	// fl combustion2
	this.instance_1 = new lib.Mapadebits15();
	this.instance_1.setTransform(23.8,-152);

	this.instance_2 = new lib.Mapadebits14();
	this.instance_2.setTransform(-156.9,-151.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#313934").s().p("AoIgmICeABIhPBMgAFrgmICeABIhPBMg");
	this.shape_2.setTransform(-15.5,-119.6);
if (tipo==4)
	this.instance_1.mask = this.instance_2.mask = this.shape_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	// Layer 42 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_99 = new cjs.Graphics().p("AltJWIAAowIAoAAIAAIwg");
	var mask_2_graphics_100 = new cjs.Graphics().p("AhOEQIAAofICdAAIAAIfg");
	var mask_2_graphics_101 = new cjs.Graphics().p("AiKEIIAAoPIEVAAIAAIPg");
	var mask_2_graphics_102 = new cjs.Graphics().p("AjFEBIAAoBIGLAAIAAIBg");
	var mask_2_graphics_103 = new cjs.Graphics().p("AkBD5IAAnxIIDAAIAAHxg");
	var mask_2_graphics_104 = new cjs.Graphics().p("Ak8DyIAAnjIJ5AAIAAHjg");
	var mask_2_graphics_105 = new cjs.Graphics().p("Al4DqIAAnTILxAAIAAHTg");
	var mask_2_graphics_106 = new cjs.Graphics().p("Am0DiIAAnDINpAAIAAHDg");
	var mask_2_graphics_107 = new cjs.Graphics().p("AtKJWIAAm3IPgAAIAAG3g");
	var mask_2_graphics_108 = new cjs.Graphics().p("AnuEZIAAoxIPdAAIAAIxg");
	var mask_2_graphics_109 = new cjs.Graphics().p("AntFYIAAqvIPbAAIAAKvg");
	var mask_2_graphics_110 = new cjs.Graphics().p("AnsGWIAAsrIPZAAIAAMrg");
	var mask_2_graphics_111 = new cjs.Graphics().p("AnrHUIAAunIPXAAIAAOng");
	var mask_2_graphics_112 = new cjs.Graphics().p("AnqITIAAwlIPVAAIAAQlg");
	var mask_2_graphics_113 = new cjs.Graphics().p("AnpJRIAAyhIPTAAIAAShg");
	var mask_2_graphics_114 = new cjs.Graphics().p("AnoKQIAA0fIPRAAIAAUfg");
	var mask_2_graphics_115 = new cjs.Graphics().p("AnnLOIAA2bIPPAAIAAWbg");
	var mask_2_graphics_116 = new cjs.Graphics().p("AnmMMIAA4XIPNAAIAAYXg");
	var mask_2_graphics_117 = new cjs.Graphics().p("AnlNLIAA6VIPLAAIAAaVg");
	var mask_2_graphics_118 = new cjs.Graphics().p("AnkOJIAA8RIPJAAIAAcRg");
	var mask_2_graphics_119 = new cjs.Graphics().p("AnjPIIAA+PIPHAAIAAePg");
	var mask_2_graphics_120 = new cjs.Graphics().p("AniQGMAAAggLIPFAAMAAAAgLg");
	var mask_2_graphics_121 = new cjs.Graphics().p("AnhRFMAAAgiJIPDAAMAAAAiJg");
	var mask_2_graphics_122 = new cjs.Graphics().p("AngSDMAAAgkFIPBAAMAAAAkFg");
	var mask_2_graphics_123 = new cjs.Graphics().p("AnfTBMAAAgmBIO/AAMAAAAmBg");
	var mask_2_graphics_124 = new cjs.Graphics().p("AneUAMAAAgn/IO9AAMAAAAn/g");
	var mask_2_graphics_125 = new cjs.Graphics().p("AneUhMAAAgpBIO9AAMAAAApBg");
	var mask_2_graphics_126 = new cjs.Graphics().p("AneVCMAAAgqDIO9AAMAAAAqDg");
	var mask_2_graphics_127 = new cjs.Graphics().p("AtDVkMAAAgrHIO+AAMAAAArHg");
	var mask_2_graphics_128 = new cjs.Graphics().p("AoYVkMAAAgrHIQxAAMAAAArHg");
	var mask_2_graphics_129 = new cjs.Graphics().p("AtCVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_130 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_131 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_132 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_133 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_134 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_135 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_136 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_137 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_138 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_139 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");
	var mask_2_graphics_140 = new cjs.Graphics().p("ApRVkMAAAgrHISjAAMAAAArHg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_2_graphics_99,x:-36.5,y:59.9}).wait(1).to({graphics:mask_2_graphics_100,x:-77.1,y:92.5}).wait(1).to({graphics:mask_2_graphics_101,x:-83.1,y:93.2}).wait(1).to({graphics:mask_2_graphics_102,x:-89,y:94}).wait(1).to({graphics:mask_2_graphics_103,x:-95,y:94.7}).wait(1).to({graphics:mask_2_graphics_104,x:-100.9,y:95.5}).wait(1).to({graphics:mask_2_graphics_105,x:-106.9,y:96.3}).wait(1).to({graphics:mask_2_graphics_106,x:-112.9,y:97}).wait(1).to({graphics:mask_2_graphics_107,x:-84.2,y:59.8}).wait(1).to({graphics:mask_2_graphics_108,x:-118.8,y:91.5}).wait(1).to({graphics:mask_2_graphics_109,x:-118.9,y:85.3}).wait(1).to({graphics:mask_2_graphics_110,x:-118.9,y:79.1}).wait(1).to({graphics:mask_2_graphics_111,x:-118.9,y:72.8}).wait(1).to({graphics:mask_2_graphics_112,x:-118.9,y:66.6}).wait(1).to({graphics:mask_2_graphics_113,x:-118.9,y:60.3}).wait(1).to({graphics:mask_2_graphics_114,x:-118.9,y:54.1}).wait(1).to({graphics:mask_2_graphics_115,x:-119,y:47.8}).wait(1).to({graphics:mask_2_graphics_116,x:-119,y:41.6}).wait(1).to({graphics:mask_2_graphics_117,x:-119,y:35.4}).wait(1).to({graphics:mask_2_graphics_118,x:-119,y:29.1}).wait(1).to({graphics:mask_2_graphics_119,x:-119,y:22.9}).wait(1).to({graphics:mask_2_graphics_120,x:-119.1,y:16.6}).wait(1).to({graphics:mask_2_graphics_121,x:-119.1,y:10.4}).wait(1).to({graphics:mask_2_graphics_122,x:-119.1,y:4.2}).wait(1).to({graphics:mask_2_graphics_123,x:-119.1,y:-2}).wait(1).to({graphics:mask_2_graphics_124,x:-119.1,y:-8.2}).wait(1).to({graphics:mask_2_graphics_125,x:-119.1,y:-11.6}).wait(1).to({graphics:mask_2_graphics_126,x:-119.1,y:-14.9}).wait(1).to({graphics:mask_2_graphics_127,x:-83.5,y:-18.2}).wait(1).to({graphics:mask_2_graphics_128,x:-113.4,y:-18.2}).wait(1).to({graphics:mask_2_graphics_129,x:-83.5,y:-18.2}).wait(1).to({graphics:mask_2_graphics_130,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_131,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_132,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_133,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_134,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_135,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_136,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_137,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_138,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_139,x:-107.6,y:-18.2}).wait(1).to({graphics:mask_2_graphics_140,x:-107.6,y:-18.2}).wait(1));

	// fl combustion1
	this.instance_3 = new lib.Mapadebits24b();
	this.instance_3.setTransform(-156.4,70.2);

	this.instance_4 = new lib.Mapadebits23b();
	this.instance_4.setTransform(-88.5,-151.9);

	this.instance_5 = new lib.Mapadebits22b();
	this.instance_5.setTransform(-156.8,-152);

	this.instance_6 = new lib.Mapadebits20();
	this.instance_6.setTransform(-157,-129.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#313934").s().p("AoIgmICeABIhPBMgAFrgmICeABIhPBMg");
	this.shape_3.setTransform(-15.5,-119.6);
if (tipo==4)
	this.instance_3.mask = this.instance_4.mask = this.instance_5.mask = this.instance_6.mask = this.shape_3.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).wait(1));

	// Layer 40 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_69 = new cjs.Graphics().p("ArTAsIAAhYIWoAAIAABYg");
	var mask_3_graphics_70 = new cjs.Graphics().p("ArTA/IAAh+IWoAAIAAB+g");
	var mask_3_graphics_71 = new cjs.Graphics().p("ArTBTIAAilIWoAAIAAClg");
	var mask_3_graphics_72 = new cjs.Graphics().p("ArTBmIAAjLIWoAAIAADLg");
	var mask_3_graphics_73 = new cjs.Graphics().p("ArTB4IAAjwIWoAAIAADwg");
	var mask_3_graphics_74 = new cjs.Graphics().p("ArTCLIAAkWIWoAAIAAEWg");
	var mask_3_graphics_75 = new cjs.Graphics().p("ArTCfIAAk9IWoAAIAAE9g");
	var mask_3_graphics_76 = new cjs.Graphics().p("ArTCyIAAljIWoAAIAAFjg");
	var mask_3_graphics_77 = new cjs.Graphics().p("ArTDEIAAmIIWoAAIAAGIg");
	var mask_3_graphics_78 = new cjs.Graphics().p("ArTDXIAAmuIWoAAIAAGug");
	var mask_3_graphics_79 = new cjs.Graphics().p("ArTDqIAAnUIWoAAIAAHUg");
	var mask_3_graphics_80 = new cjs.Graphics().p("ArTD+IAAn7IWoAAIAAH7g");
	var mask_3_graphics_81 = new cjs.Graphics().p("ArTERIAAohIWoAAIAAIhg");
	var mask_3_graphics_82 = new cjs.Graphics().p("ArTEjIAApGIWoAAIAAJGg");
	var mask_3_graphics_83 = new cjs.Graphics().p("ArTE2IAApsIWoAAIAAJsg");
	var mask_3_graphics_84 = new cjs.Graphics().p("ArTGOIAAqSIWoAAIAAKSg");
	var mask_3_graphics_85 = new cjs.Graphics().p("ArTFJIAAqRIWoAAIAAKRg");
	var mask_3_graphics_86 = new cjs.Graphics().p("ArTFKIAAqTIWoAAIAAKTg");
	var mask_3_graphics_87 = new cjs.Graphics().p("ArTFJIAAqRIWoAAIAAKRg");
	var mask_3_graphics_88 = new cjs.Graphics().p("ArTFKIAAqTIWoAAIAAKTg");
	var mask_3_graphics_89 = new cjs.Graphics().p("ArTFJIAAqSIWoAAIAAKSg");
	var mask_3_graphics_90 = new cjs.Graphics().p("ArTFKIAAqSIWoAAIAAKSg");
	var mask_3_graphics_91 = new cjs.Graphics().p("ArTFJIAAqSIWoAAIAAKSg");
	var mask_3_graphics_92 = new cjs.Graphics().p("ArTFJIAAqRIWoAAIAAKRg");
	var mask_3_graphics_93 = new cjs.Graphics().p("ArTFKIAAqTIWoAAIAAKTg");
	var mask_3_graphics_94 = new cjs.Graphics().p("ArTFJIAAqSIWoAAIAAKSg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_3_graphics_69,x:-14.7,y:18.2}).wait(1).to({graphics:mask_3_graphics_70,x:-14.7,y:20.1}).wait(1).to({graphics:mask_3_graphics_71,x:-14.7,y:22}).wait(1).to({graphics:mask_3_graphics_72,x:-14.7,y:23.9}).wait(1).to({graphics:mask_3_graphics_73,x:-14.7,y:25.8}).wait(1).to({graphics:mask_3_graphics_74,x:-14.7,y:27.7}).wait(1).to({graphics:mask_3_graphics_75,x:-14.7,y:29.6}).wait(1).to({graphics:mask_3_graphics_76,x:-14.7,y:31.5}).wait(1).to({graphics:mask_3_graphics_77,x:-14.7,y:33.4}).wait(1).to({graphics:mask_3_graphics_78,x:-14.7,y:35.3}).wait(1).to({graphics:mask_3_graphics_79,x:-14.7,y:37.2}).wait(1).to({graphics:mask_3_graphics_80,x:-14.7,y:39.1}).wait(1).to({graphics:mask_3_graphics_81,x:-14.7,y:41}).wait(1).to({graphics:mask_3_graphics_82,x:-14.7,y:42.9}).wait(1).to({graphics:mask_3_graphics_83,x:-14.7,y:44.8}).wait(1).to({graphics:mask_3_graphics_84,x:-14.7,y:39.9}).wait(1).to({graphics:mask_3_graphics_85,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_86,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_87,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_88,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_89,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_90,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_91,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_92,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_93,x:-14.7,y:46.7}).wait(1).to({graphics:mask_3_graphics_94,x:-14.7,y:46.7}).wait(1));

	// fl mineralizacion
	this.instance_7 = new lib.Mapadebits17();
	this.instance_7.setTransform(-84.3,26.7);

	this.instance_8 = new lib.Mapadebits16();
	this.instance_8.setTransform(12.6,26.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00004D").s().p("AEBg2IBvBtIhvAAgAlwA3IBxhtIgBBtg");
	this.shape_4.setTransform(-16,63.7);
if (tipo==3)
	this.instance_7.mask = this.instance_8.mask = this.shape_4.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.instance_8},{t:this.instance_7}]}).wait(1));

	// Layer 39 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_34 = new cjs.Graphics().p("AxKATIAAglMAiVAAAIAAAlg");
	var mask_4_graphics_35 = new cjs.Graphics().p("AxKAnIAAhNMAiVAAAIAABNg");
	var mask_4_graphics_36 = new cjs.Graphics().p("AxKA6IAAhzMAiVAAAIAABzg");
	var mask_4_graphics_37 = new cjs.Graphics().p("AxKBNIAAiZMAiVAAAIAACZg");
	var mask_4_graphics_38 = new cjs.Graphics().p("AxKBhIAAjBMAiVAAAIAADBg");
	var mask_4_graphics_39 = new cjs.Graphics().p("AxKB0IAAjnMAiVAAAIAADng");
	var mask_4_graphics_40 = new cjs.Graphics().p("AxKCHIAAkNMAiVAAAIAAENg");
	var mask_4_graphics_41 = new cjs.Graphics().p("AxKCaIAAkzMAiVAAAIAAEzg");
	var mask_4_graphics_42 = new cjs.Graphics().p("AxKCuIAAlbMAiVAAAIAAFbg");
	var mask_4_graphics_43 = new cjs.Graphics().p("AxKDBIAAmBMAiVAAAIAAGBg");
	var mask_4_graphics_44 = new cjs.Graphics().p("AxKDUIAAmnMAiVAAAIAAGng");
	var mask_4_graphics_45 = new cjs.Graphics().p("AxKDnIAAnNMAiVAAAIAAHNg");
	var mask_4_graphics_46 = new cjs.Graphics().p("AxKD7IAAn1MAiVAAAIAAH1g");
	var mask_4_graphics_47 = new cjs.Graphics().p("AxKEOIAAobMAiVAAAIAAIbg");
	var mask_4_graphics_48 = new cjs.Graphics().p("AxKEhIAApBMAiVAAAIAAJBg");
	var mask_4_graphics_49 = new cjs.Graphics().p("AxKE0IAApnMAiVAAAIAAJng");
	var mask_4_graphics_50 = new cjs.Graphics().p("AxKFIIAAqPMAiVAAAIAAKPg");
	var mask_4_graphics_51 = new cjs.Graphics().p("AxKFbIAAq1MAiVAAAIAAK1g");
	var mask_4_graphics_52 = new cjs.Graphics().p("AxKFuIAArbMAiVAAAIAALbg");
	var mask_4_graphics_53 = new cjs.Graphics().p("AxKGBIAAsBMAiVAAAIAAMBg");
	var mask_4_graphics_54 = new cjs.Graphics().p("AxKEgIAAsoMAiVAAAIAAMog");
	var mask_4_graphics_55 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_56 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_57 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_58 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_59 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_60 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_61 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_62 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_63 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");
	var mask_4_graphics_64 = new cjs.Graphics().p("AxKGVIAAspMAiVAAAIAAMpg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_4_graphics_34,x:-16.1,y:-25.2}).wait(1).to({graphics:mask_4_graphics_35,x:-16.1,y:-27.1}).wait(1).to({graphics:mask_4_graphics_36,x:-16.1,y:-29.1}).wait(1).to({graphics:mask_4_graphics_37,x:-16.1,y:-31}).wait(1).to({graphics:mask_4_graphics_38,x:-16.1,y:-32.9}).wait(1).to({graphics:mask_4_graphics_39,x:-16.1,y:-34.8}).wait(1).to({graphics:mask_4_graphics_40,x:-16.1,y:-36.8}).wait(1).to({graphics:mask_4_graphics_41,x:-16.1,y:-38.7}).wait(1).to({graphics:mask_4_graphics_42,x:-16.1,y:-40.6}).wait(1).to({graphics:mask_4_graphics_43,x:-16.1,y:-42.5}).wait(1).to({graphics:mask_4_graphics_44,x:-16.1,y:-44.5}).wait(1).to({graphics:mask_4_graphics_45,x:-16.1,y:-46.4}).wait(1).to({graphics:mask_4_graphics_46,x:-16.1,y:-48.3}).wait(1).to({graphics:mask_4_graphics_47,x:-16.1,y:-50.2}).wait(1).to({graphics:mask_4_graphics_48,x:-16.1,y:-52.2}).wait(1).to({graphics:mask_4_graphics_49,x:-16.1,y:-54.1}).wait(1).to({graphics:mask_4_graphics_50,x:-16.1,y:-56}).wait(1).to({graphics:mask_4_graphics_51,x:-16.1,y:-57.9}).wait(1).to({graphics:mask_4_graphics_52,x:-16.1,y:-59.9}).wait(1).to({graphics:mask_4_graphics_53,x:-16.1,y:-61.8}).wait(1).to({graphics:mask_4_graphics_54,x:-16.1,y:-52.1}).wait(1).to({graphics:mask_4_graphics_55,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_56,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_57,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_58,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_59,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_60,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_61,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_62,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_63,x:-16.1,y:-63.7}).wait(1).to({graphics:mask_4_graphics_64,x:-16.1,y:-63.8}).wait(1));

	// fl respiracion
	this.instance_9 = new lib.Mapadebits21();
	this.instance_9.setTransform(-110,-101.3);
if (tipo==1)
	this.instance_9.mask = mask_4;
        
            this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9}]}).wait(1));

	// Layer 38 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_4 = new cjs.Graphics().p("AkSBPIAAieIIlAAIAACeg");
	var mask_5_graphics_5 = new cjs.Graphics().p("AkWBdIAAi6IItAAIAAC6g");
	var mask_5_graphics_6 = new cjs.Graphics().p("AkaBrIAAjWII1AAIAADWg");
	var mask_5_graphics_7 = new cjs.Graphics().p("AkfB5IAAjyII+AAIAADyg");
	var mask_5_graphics_8 = new cjs.Graphics().p("AkjCHIAAkOIJHAAIAAEOg");
	var mask_5_graphics_9 = new cjs.Graphics().p("AknCWIAAkrIJPAAIAAErg");
	var mask_5_graphics_10 = new cjs.Graphics().p("AkrCkIAAlHIJYAAIAAFHg");
	var mask_5_graphics_11 = new cjs.Graphics().p("AkwCyIAAljIJhAAIAAFjg");
	var mask_5_graphics_12 = new cjs.Graphics().p("Ak0DAIAAl/IJpAAIAAF/g");
	var mask_5_graphics_13 = new cjs.Graphics().p("Ak5DNIAAmaIJyAAIAAGag");
	var mask_5_graphics_14 = new cjs.Graphics().p("Ak9DbIAAm2IJ7AAIAAG2g");
	var mask_5_graphics_15 = new cjs.Graphics().p("AlBDpIAAnSIKDAAIAAHSg");
	var mask_5_graphics_16 = new cjs.Graphics().p("AlGD3IAAnuIKNAAIAAHug");
	var mask_5_graphics_17 = new cjs.Graphics().p("AlKEFIAAoKIKVAAIAAIKg");
	var mask_5_graphics_18 = new cjs.Graphics().p("AlOEUIAAonIKdAAIAAIng");
	var mask_5_graphics_19 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_20 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_21 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_22 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_23 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_24 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_25 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_26 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_27 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_28 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");
	var mask_5_graphics_29 = new cjs.Graphics().p("AlSEiIAApDIKlAAIAAJDg");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_5_graphics_4,x:-51.7,y:-81.3}).wait(1).to({graphics:mask_5_graphics_5,x:-52.5,y:-79.9}).wait(1).to({graphics:mask_5_graphics_6,x:-53.4,y:-78.5}).wait(1).to({graphics:mask_5_graphics_7,x:-54.3,y:-77.1}).wait(1).to({graphics:mask_5_graphics_8,x:-55.1,y:-75.7}).wait(1).to({graphics:mask_5_graphics_9,x:-56,y:-74.3}).wait(1).to({graphics:mask_5_graphics_10,x:-56.9,y:-72.9}).wait(1).to({graphics:mask_5_graphics_11,x:-57.7,y:-71.5}).wait(1).to({graphics:mask_5_graphics_12,x:-58.6,y:-70.1}).wait(1).to({graphics:mask_5_graphics_13,x:-59.5,y:-68.7}).wait(1).to({graphics:mask_5_graphics_14,x:-60.3,y:-67.3}).wait(1).to({graphics:mask_5_graphics_15,x:-61.2,y:-65.9}).wait(1).to({graphics:mask_5_graphics_16,x:-62.1,y:-64.5}).wait(1).to({graphics:mask_5_graphics_17,x:-62.9,y:-63.1}).wait(1).to({graphics:mask_5_graphics_18,x:-63.8,y:-61.7}).wait(1).to({graphics:mask_5_graphics_19,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_20,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_21,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_22,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_23,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_24,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_25,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_26,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_27,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_28,x:-64.7,y:-60.3}).wait(1).to({graphics:mask_5_graphics_29,x:-64.7,y:-60.3}).wait(1));

	// fl fotosintesis
	this.instance_10 = new lib.Mapadebits19();
	this.instance_10.setTransform(-94.9,-73.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#65642E").s().p("AhNgmICbABIhOBMg");
	this.shape_5.setTransform(-89.8,-36.6);
        if (tipo==2)
            this.instance_10.mask = this.shape_5.mask = mask_5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.instance_10}]}).wait(1));

	// co2
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#277B7B").s().p("ABBAxIAAgKIAKgIIAIgGIAHgIIABgGQAAgFgCgBQgCgCgFAAIgHABIgHADIgCAAIAAgKIAIgCIALgBQAKAAAGAEQAFACAAAJQAAAFgCAFIgIAKIgHAFIgFAEIAZAAIAAALgAgRAXQgLgMAAgRQAAgTALgLQALgMARAAQAUAAALAMQAKALAAATQAAARgKAMQgLALgUAAQgRAAgLgLgAAEgfQgEABgBAEQgCADgCAFQgCAFAAAHQAAAGACAEQACAFACAEQABADAEABIAHACQAEAAAEgCQADgBADgEIAFgIIABgKQAAgHgCgFQgBgFgDgDIgGgFIgIgBIgHABgAhTAfQgIgCgFgGQgGgFgDgIQgDgHAAgJQAAgJADgIQADgIAGgFQAEgFAJgDQAHgDAKAAIAIAAIAIACIAGACIAGADIAAATIgDAAIgEgDIgFgEQgCgCgEgBIgIgBQgEAAgEACIgHAEQgDADgCAFQgCAFAAAHQAAAGACAFQACAFADADQAEADAEABIAHABIAIgBIAHgDIAFgDIADgDIADAAIAAATIgGACIgGACIgHACIgJABQgKAAgHgDg");
	this.shape_6.setTransform(-16.2,-77.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6}]}).wait(1));

	// pastilles
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#CECEA8").ss(1,1,1,3,true).p("AIIFmIwPAAIAAkpIAAmiIQPAAIAAGigAoHA9IQPAA");
	this.shape_7.setTransform(-16,107.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#CECEA8").ss(1,1,1,3,true).p("AIHDaIwNAAIAAmzIQNAAg");
	this.shape_8.setTransform(-15.7,-92.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7}]}).wait(1));

	// peix-planta
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#277B7B").s().p("AhKBDQgWgVgMgaIgEgKIhNBNIgDACIgEgBIgCgDIAAgEIAIgTQAFgTADgTIABgNIAAgLQAAgggKghIgHgUIAAgDIACgEQABAAAAAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAAAIBNBOIAEgKIAAABQAMgYAVgWQAxgwBDABQAhAAAdALQAeAMAZAYQAeAfALAlIAAAEQgMAjgcAcQgXAXgaAMIgBABQgfAOgkAAQhDAAgxgygAg/g4QgTATgLAWIAAABIgGANIAGAOQALAXAUAUQAsAsA8AAQAeAAAagKQgegpAAg0QAAgxAZgmQgZgJgbAAQg9AAgrArgABKgDQgBAyAeAoIAAAAQAYgKAUgVQAZgYALgfQgLgegagbQgWgVgagLQgZAkABAxgAizA+IA/g+IAAgCIhAhAQAGAUACASIANAAIABAAIAAACIgBAAIgMAAIABAMIAOAAIAAABIAAABIgOAAIAAALIAYAAIAAABIAAAAIgYAAIAAALIAOAAIAAAAIAAABIAAABIgOgBIgBANIAIABIABAAIAAABIAAAAIgBAAIgIAAQgDARgFASgAB1gXQgEgEABgFQgBgEAEgEQADgDAFAAQAFAAADADQAEAEAAAEQAAAFgEAEQgDADgFAAQgFAAgDgDg");
	this.shape_9.setTransform(60.4,-7.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#277B7B").s().p("AAAC8QgBgDAAgDIAAhNIgCgBIgvguQgMAFgPAAQgdAAgUgVQgVgVAAgbQAAgOAFgMIACgDIADgCQALgEAPAAQAdgBAVAVQAUAVAAAbQAAAOgEAMIgBABIAtAsIAAhyIgCgBIguguIgBAAQgMAFgPAAQgdAAgUgUQgVgVAAgdQAAgOAFgNIACgCIADgCQALgFAPAAQAdAAAVAVQAUAUAAAdQAAAOgEAMIgBABIAtAtIAAifQAAgEABgCQACgCADAAQAEAAACACQACACABAEIAAC9IAggfIgBgCQgEgLABgNQgBgdAVgVQAVgVAdABIAAAAQAOAAAMAEIADACIACADQAFAMAAAOQAAAdgVAVQgUAVgdAAQgPAAgMgFIgBgBIgkAiIAAB0IAhghIgBAAQgFgMABgOIAAgBQgBgdAVgUQAVgVAdAAIAAAAQAOAAAMAFIADACIACADQAFALAAAPQAAAdgVAVQgUAUgdAAQgPAAgMgEIgBgBIgkAlIAAArQgBADgCADQgCACgEAAQgDAAgCgCgABABZQAGACAIAAQAVAAARgQQAPgQAAgWQAAgJgCgIQgIgCgJAAQgPAAgMAHIACABIABACIAAARIAIgIIAAgLIABgCIACgBIACABIABACIAAAGIAHgHIACAAIACAAIABACIgBACIgGAGIAGAAIACABIAAACIAAACIgCABIgMgBIgIAIIASAAIACABIABACIgBACIgCABIgXAAIgCABIAAAEIgDADIACAAIAaAAIACABIABACIgBACIgCABIgZgBIgIAIIARAAIACABIABACIgBACIgCABIgXgBIAAABIAAAAgABKAiQgQAPABAWIAAABQgBAGACAHIAHgHIAAgXIABgCIACgBIACABIABACIAAARIAIgHIgBgaIABgCIACgBIAAgIIAAgCIgJAIgAhvgZQgJAAgIADQgCAHAAAJQgBAVARAQQAPAPAWAAQAIAAAGgCIgIgIIgXAAIgCgBIgBgCIABgCIACAAIARgBIgHgHIAAAAIgaAAIgCgBIgBgCIABgCIACgBIAUAAIgIgIIgXAAIgCAAIgBgCIABgCIACgBIARAAIgHgGIgLAAIgCgBQgBAAAAAAQAAAAgBAAQAAgBAAAAQAAAAAAgBIACgCIABgBIAGAAIgFgGIgBgBIABgCIACgBIABABIAHAGIAAgGIABgCIACAAIACABIABACIAAALIAHAGIABgQIAAgCIADgBIACABIAAACIAAAVIAIAIIAAgSIABgCIACgBIACABIABACIAAAYIAHAIIAAgSIABgCIACgBIACABIABACIAAAXIAHAHQACgGAAgHQAAgWgQgOQgQgQgVAAIgBAAgABIgoIgCABIgHAHIAPACQAVAAARgQQAPgPAAgWIAAgBQAAgJgCgHQgIgDgJAAQgWAAgQAQIAAAAQgQAQABAWQgBAGACAGIAHgHIAAgWIABgCIACgBIACABIABACIAAARIAIgHIgBgaIABgCIACgBIACABIABACIAAAUIAIgIIAAgXIAAgCIACgBIACABIABACIAAASIAIgIIAAgMIABgCIACAAIACAAIABACIAAAHIAHgIIACAAIACAAIABACIgBACIgGAGIAGAAIACABIAAACIAAACIgCABIgMAAIgHAIIARAAIACABIABABIgBACIgCABIgXAAIgIAIIAUABIACAAIABACIgBACIgCABIgZAAIgEADIAAABIgBAAIgDADIARAAIACABIABACIgBACIgCABIgXAAgAiAiRQgCAIAAAJQgBAWARAQQAPAPAWAAQAIAAAGgBIgIgJIgXABIgCgBIgBgCIABgCIACgBIARAAIgHgIIgaAAIgCgBIgBgBIABgCIACgBIAUAAIgIgIIgXAAIgCgBIgBgCIABgCIACgBIARAAIgHgIIgLAAIgCAAIgCgCQAAgBAAAAQAAAAAAgBQABAAAAAAQAAAAABAAIABgBIAGAAIgFgGIgBgCIABgCIACgBIABABIAHAHIAAgGIABgCIACgBIACABIABACIAAALIAHAIIABgRIAAgCIADgBIACABIAAACIAAAXIAIAIIAAgVIABgCIACAAIACAAIABACIAAAaIAHAIIAAgRIABgCIACgBIACABIABACIAAAXIAHAHQACgHAAgHQAAgWgQgQQgQgPgWAAQgJAAgIACg");
	this.shape_10.setTransform(-93.1,-7.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	// peix-planta suport
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(39,123,123,0.2)").s().p("AjqDsIAAnXIHVAAIAAHXg");
	this.shape_11.setTransform(60.4,-7.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(39,123,123,0.2)").s().p("AjrDsIAAnXIHXAAIAAHXg");
	this.shape_12.setTransform(-93.1,-7.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-429.2,-152,555.1,295.4);

(lib.p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	
	// Layer 50 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_4 = new cjs.Graphics().p("Ah2BDIDMisIAhAnIjMCrg");
	var mask_5_graphics_5 = new cjs.Graphics().p("AiGAvIDMirIBBBSIjNCog");
	var mask_5_graphics_6 = new cjs.Graphics().p("AiXAbIDMisIBjB/IjOCkg");
	var mask_5_graphics_7 = new cjs.Graphics().p("AinAHIDMisICDCpIjPChg");
	var mask_5_graphics_8 = new cjs.Graphics().p("Ai4gLIDMitIClDUIjQCdg");
	var mask_5_graphics_9 = new cjs.Graphics().p("AjIgfIDMiuIDFEBIjRCag");
	var mask_5_graphics_10 = new cjs.Graphics().p("AjZgzIDOiuIDlEtIjUCWg");
	var mask_5_graphics_11 = new cjs.Graphics().p("AjphHIDOitIEFFYIjVCRg");
	var mask_5_graphics_12 = new cjs.Graphics().p("Aj6hbIDOiuIEnGFIjWCNg");
	var mask_5_graphics_13 = new cjs.Graphics().p("AkKhvIDOiuIFHGxIjXCJg");
	var mask_5_graphics_14 = new cjs.Graphics().p("Ag9koIDNiuIFqHdIjYCFg");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_5_graphics_4,x:84.3,y:-41.6}).wait(1).to({graphics:mask_5_graphics_5,x:83.2,y:-43.8}).wait(1).to({graphics:mask_5_graphics_6,x:82,y:-46}).wait(1).to({graphics:mask_5_graphics_7,x:80.9,y:-48.2}).wait(1).to({graphics:mask_5_graphics_8,x:79.7,y:-50.4}).wait(1).to({graphics:mask_5_graphics_9,x:78.6,y:-52.6}).wait(1).to({graphics:mask_5_graphics_10,x:77.4,y:-54.8}).wait(1).to({graphics:mask_5_graphics_11,x:76.3,y:-57}).wait(1).to({graphics:mask_5_graphics_12,x:75.1,y:-59.2}).wait(1).to({graphics:mask_5_graphics_13,x:74,y:-61.4}).wait(1).to({graphics:mask_5_graphics_14,x:50.6,y:-47}).wait(1).to({graphics:null,x:0,y:0}).wait(9));

	// fletxa4
	this.instance = new lib.Mapadebits6();
	this.instance.setTransform(53.9,-81.8);

	this.instance.mask = mask_5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},4).wait(20));

	// mf3 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	var mask_6_graphics_4 = new cjs.Graphics().p("Ah2BDIDMirIAhAmIjMCrg");
	var mask_6_graphics_5 = new cjs.Graphics().p("AiGAvIDMirIBBBSIjNCog");
	var mask_6_graphics_6 = new cjs.Graphics().p("AiXAbIDMirIBjB+IjOCjg");
	var mask_6_graphics_7 = new cjs.Graphics().p("AinAHIDMirICDCoIjPCig");
	var mask_6_graphics_8 = new cjs.Graphics().p("Ai4gLIDMitIClDUIjQCdg");
	var mask_6_graphics_9 = new cjs.Graphics().p("AjIgfIDMitIDFEAIjRCZg");
	var mask_6_graphics_10 = new cjs.Graphics().p("AjZgzIDOitIDlEsIjUCWg");
	var mask_6_graphics_11 = new cjs.Graphics().p("AjphHIDOitIEFFYIjVCRg");
	var mask_6_graphics_12 = new cjs.Graphics().p("Aj6hbIDOitIEnGEIjWCOg");
	var mask_6_graphics_13 = new cjs.Graphics().p("AkKhvIDOitIFHGwIjXCJg");
	var mask_6_graphics_14 = new cjs.Graphics().p("AkbiDIDPitIFoHcIjYCGg");

	this.timeline.addTween(cjs.Tween.get(mask_6).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_6_graphics_4,x:69.3,y:-93.6}).wait(1).to({graphics:mask_6_graphics_5,x:71,y:-91.6}).wait(1).to({graphics:mask_6_graphics_6,x:72.6,y:-89.6}).wait(1).to({graphics:mask_6_graphics_7,x:74.3,y:-87.6}).wait(1).to({graphics:mask_6_graphics_8,x:75.9,y:-85.6}).wait(1).to({graphics:mask_6_graphics_9,x:77.6,y:-83.6}).wait(1).to({graphics:mask_6_graphics_10,x:79.2,y:-81.6}).wait(1).to({graphics:mask_6_graphics_11,x:80.9,y:-79.6}).wait(1).to({graphics:mask_6_graphics_12,x:82.5,y:-77.6}).wait(1).to({graphics:mask_6_graphics_13,x:84.2,y:-75.6}).wait(1).to({graphics:mask_6_graphics_14,x:85.8,y:-73.6}).wait(1).to({graphics:null,x:0,y:0}).wait(9));

	// fletxa3
	this.instance_1 = new lib.Mapadebits7();
	this.instance_1.setTransform(69.1,-95.5);

	this.instance_1.mask = mask_6;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},4).wait(20));

	// mf2 (mask)
	var mask_7 = new cjs.Shape();
	mask_7._off = true;
	var mask_7_graphics_4 = new cjs.Graphics().p("AiGAtIAAhYIENAAIAABYg");
	var mask_7_graphics_5 = new cjs.Graphics().p("AiGBGIAAiLIENAAIAACLg");
	var mask_7_graphics_6 = new cjs.Graphics().p("AiGBfIAAi+IENAAIAAC+g");
	var mask_7_graphics_7 = new cjs.Graphics().p("AiGB5IAAjxIENAAIAADxg");
	var mask_7_graphics_8 = new cjs.Graphics().p("AiGCTIAAklIENAAIAAElg");
	var mask_7_graphics_9 = new cjs.Graphics().p("AiGCsIAAlXIENAAIAAFXg");
	var mask_7_graphics_10 = new cjs.Graphics().p("AiGDFIAAmKIENAAIAAGKg");
	var mask_7_graphics_11 = new cjs.Graphics().p("AiGDfIAAm9IENAAIAAG9g");
	var mask_7_graphics_12 = new cjs.Graphics().p("AiGD4IAAnvIENAAIAAHvg");
	var mask_7_graphics_13 = new cjs.Graphics().p("AiGESIAAojIENAAIAAIjg");
	var mask_7_graphics_14 = new cjs.Graphics().p("AiGAnIAApWIENAAIAAJWg");

	this.timeline.addTween(cjs.Tween.get(mask_7).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_7_graphics_4,x:10.4,y:-108.6}).wait(1).to({graphics:mask_7_graphics_5,x:10.4,y:-105.9}).wait(1).to({graphics:mask_7_graphics_6,x:10.4,y:-103.3}).wait(1).to({graphics:mask_7_graphics_7,x:10.4,y:-100.6}).wait(1).to({graphics:mask_7_graphics_8,x:10.4,y:-98}).wait(1).to({graphics:mask_7_graphics_9,x:10.4,y:-95.3}).wait(1).to({graphics:mask_7_graphics_10,x:10.4,y:-92.7}).wait(1).to({graphics:mask_7_graphics_11,x:10.4,y:-90}).wait(1).to({graphics:mask_7_graphics_12,x:10.4,y:-87.4}).wait(1).to({graphics:mask_7_graphics_13,x:10.4,y:-84.7}).wait(1).to({graphics:mask_7_graphics_14,x:10.4,y:-56}).wait(10));

	// fletxa2
	this.instance_2 = new lib.Mapadebits5();
	this.instance_2.setTransform(6.5,-107.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#323435").s().p("AhNgmICbABIhOBMg");
	this.shape.setTransform(11.5,-61);

	this.instance_2.mask = this.shape.mask = mask_7;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.instance_2}]},4).wait(20));

	// mf1 (mask)
	var mask_8 = new cjs.Shape();
	mask_8._off = true;
	var mask_8_graphics_4 = new cjs.Graphics().p("AiGAsIAAhYIEMAAIAABYg");
	var mask_8_graphics_5 = new cjs.Graphics().p("AiGBGIAAiLIEMAAIAACLg");
	var mask_8_graphics_6 = new cjs.Graphics().p("AiGBfIAAi9IEMAAIAAC9g");
	var mask_8_graphics_7 = new cjs.Graphics().p("AiGB5IAAjxIEMAAIAADxg");
	var mask_8_graphics_8 = new cjs.Graphics().p("AiGCSIAAkjIEMAAIAAEjg");
	var mask_8_graphics_9 = new cjs.Graphics().p("AiGCsIAAlXIEMAAIAAFXg");
	var mask_8_graphics_10 = new cjs.Graphics().p("AiGDFIAAmKIEMAAIAAGKg");
	var mask_8_graphics_11 = new cjs.Graphics().p("AiGDfIAAm9IEMAAIAAG9g");
	var mask_8_graphics_12 = new cjs.Graphics().p("AiGD4IAAnvIEMAAIAAHvg");
	var mask_8_graphics_13 = new cjs.Graphics().p("AiGESIAAojIEMAAIAAIjg");
	var mask_8_graphics_14 = new cjs.Graphics().p("AiVBFIAApWIEMAAIAAJWg");

	this.timeline.addTween(cjs.Tween.get(mask_8).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_8_graphics_4,x:-16.6,y:-50.6}).wait(1).to({graphics:mask_8_graphics_5,x:-16.6,y:-53.1}).wait(1).to({graphics:mask_8_graphics_6,x:-16.6,y:-55.7}).wait(1).to({graphics:mask_8_graphics_7,x:-16.6,y:-58.2}).wait(1).to({graphics:mask_8_graphics_8,x:-16.6,y:-60.8}).wait(1).to({graphics:mask_8_graphics_9,x:-16.6,y:-63.3}).wait(1).to({graphics:mask_8_graphics_10,x:-16.6,y:-65.9}).wait(1).to({graphics:mask_8_graphics_11,x:-16.6,y:-68.4}).wait(1).to({graphics:mask_8_graphics_12,x:-16.6,y:-71}).wait(1).to({graphics:mask_8_graphics_13,x:-16.6,y:-73.5}).wait(1).to({graphics:mask_8_graphics_14,x:-15,y:-53}).wait(10));

	// fletxa1
	this.instance_3 = new lib.Mapadebits4();
	this.instance_3.setTransform(-22.3,-102.4);

	this.instance_3.mask = mask_8;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},4).wait(20));

	// co2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#277B7B").s().p("ABbBFIAAgOIAPgKIALgKQAHgGACgFQADgEAAgFQAAgFgDgDQgEgDgGgBQgGABgEACIgLAEIgCAAIAAgPIAMgDQAHgCAHAAQAPAAAIAGQAIAFAAALQAAAHgEAHQgEAHgHAHIgKAIIgHAFIAjAAIAAAQgAgYAgQgQgQAAgYQAAgcAQgQQAPgQAZAAQAbAAAPAQQAQAQAAAcQAAAYgQAQQgPAPgbAAQgZAAgPgPgAAGgsQgFABgCAGQgFAEgBAHQgDAHAAALQAAAIADAHQABAGAFAFQABAEAGADQAFABAFAAQAGAAAFgBQAFgDAEgFQADgEADgHQACgGAAgJQAAgKgCgHQgDgHgDgEQgEgFgFgCQgFgCgGAAQgFAAgFACgAh1AsQgLgDgHgIQgIgIgFgKQgEgLAAgMQAAgOAEgLQAFgLAHgIQAHgHALgEQALgEANAAIANAAIAKADIAKACIAHAEIAAAbIgEAAIgFgEIgHgFQgEgCgFgCQgFgCgGABQgGAAgGABQgFACgFAFQgEAEgDAHQgCAHgBALQAAAIAEAHQACAHAFAEQAFAEAFACQAFABAHABIAKgCIAJgEIAHgFIAFgEIAEAAIAAAbIgIAEIgIACIgLADIgNAAQgNABgKgEg");
	this.shape_1.setTransform(102.5,-4.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#277B7B").s().p("ABcBFIAAgOIANgKIAMgKQAHgHACgEQADgFAAgEQAAgFgDgDQgEgEgHAAQgEAAgGADIgKAEIgCAAIAAgPIALgDQAIgCAHAAQAPAAAIAGQAHAFAAALQABAHgEAIQgEAGgHAHIgKAIIgHAGIAjAAIAAAPgAgYAgQgQgQAAgYQAAgcAQgQQAPgPAZgBQAbABAPAPQAQAQAAAcQAAAYgQAQQgPAPgbAAQgZAAgPgPgAAFgsQgEABgDAGQgDAEgCAHQgDAHAAALQAAAIADAHQACAGADAFQACAEAFADQAFACAGAAQAFAAAGgCQAFgDAEgEQAEgFACgHQACgGAAgJQAAgKgDgHQgCgHgDgEQgFgFgEgCQgGgCgFAAQgGAAgFACgAh2AsQgKgDgIgIQgHgIgFgKQgEgLAAgMQAAgOAEgLQAFgLAHgIQAHgHALgEQALgEANAAIAMAAIALADIAKADIAGADIAAAbIgDAAIgGgEIgGgFQgFgDgEgBQgFgBgGAAQgGAAgGACQgFABgFAFQgEAEgDAIQgDAGABALQAAAIACAHQADAHAFAEQAEAEAGACQAFABAGABIALgCIAJgEIAHgFIAFgEIADAAIAAAbIgIAEIgHACIgLADIgNAAQgNABgLgEg");
	this.shape_2.setTransform(0.5,-113.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#277B7B").s().p("ABbBEIAAgMIAPgLIALgKQAHgGACgFQADgFAAgEQAAgFgDgEQgEgDgGAAQgGAAgEACIgLAGIgCAAIAAgQIALgDQAIgCAHAAQAPAAAIAGQAIAFgBALQAAAHgDAIQgEAGgHAHIgKAIIgHAGIAjAAIAAAOgAgYAgQgQgQAAgZQAAgbAQgPQAPgRAZABQAbgBAPARQAQAPAAAbQAAAZgQAQQgPAQgbAAQgZAAgPgQgAAFgtQgEADgDAEQgEAFgBAHQgDAHAAAKQAAAJADAGQABAIAEAEQACAEAFACQAGACAFABQAGgBAFgCQAFgCAEgEQAEgGACgHQACgFAAgJQAAgKgDgHQgCgHgDgFQgFgEgEgDQgFgBgGAAQgFAAgGABgAh1AsQgLgEgHgHQgIgIgFgLQgEgLAAgMQAAgNAEgLQAEgLAIgHQAHgIALgEQALgEANAAIANAAIAKACIAKAEIAHADIAAAbIgEAAIgFgEIgHgFQgFgCgEgCQgFgCgGAAQgGAAgGADQgFACgFADQgEAFgDAIQgCAGgBAKQAAAJADAHQADAHAFAEQAEAEAGACQAFABAHAAIAKgBIAJgEIAHgFIAFgEIAEAAIAAAbIgIADIgIADIgLADIgNABQgNgBgKgDg");
	this.shape_3.setTransform(-101.4,-35.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(24));

	// suport
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#F5F5ED","#277B7B"],[0,1],-11.7,-17.3,0,-11.7,-17.3,63.2).s().p("Ak8E8QiDiDAAi5QAAi4CDiEQCEiDC4AAQC5AACDCDQCDCEABC4QgBC5iDCDQiDCEi5AAQi4AAiEiEg");
	this.shape_4.setTransform(-2.1,-15.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#110000","rgba(206,206,168,0)"],[0,1],0.1,0,0,0.1,0,56.7).s().p("AmNGNQikikgBjpQABjoCkilIAAAAQCmilDnAAQDpAAClClQCkClAADoQAADpikCkIgBAAQilCljoAAQjnAAimilg");
	this.shape_5.setTransform(5.9,-8.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4}]}).wait(24));

	// fons suport
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(102,97,19,0.098)").s().p("Aj7JoQl9l9AAoYQAAmGDIkzIHJEQQh1C3AADoQAAE9DfDiQDKDJEsAXIgBIfQoUgelflhg");
	this.shape_6.setTransform(-67.7,19.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(27,145,205,0.098)").s().p("ApxHJQBwgKBcggQCdg4B/h/QDgjigBk9QABjoh2i2IHJkRQDIEzAAGGQAAIYl9F9QkfEhl7BGQhVAPhtAJg");
	this.shape_7.setTransform(64.2,19.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(39,123,123,0.098)").s().p("AIMFJQjajakygHQkxAHjaDaQgqAqgiAtInBkhQA+hVBOhMQF6l5ISgEQITAEF5F5QBPBMA+BVInBEhQgigtgqgqg");
	this.shape_8.setTransform(-2.1,-99.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(24));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-452.5,-141.1,579.4,260.3);


(lib.p1a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// botons
	
	// Layer 55 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_54 = new cjs.Graphics().p("AjFAEIBXinIE0CgIhXCng");
	var mask_graphics_55 = new cjs.Graphics().p("AjSAbIB4jVIEtCfIhxDWg");
	var mask_graphics_56 = new cjs.Graphics().p("AjfAyICZkDIEmCeIiLEFg");
	var mask_graphics_57 = new cjs.Graphics().p("AjsBJIC6kxIEfCdIilE0g");
	var mask_graphics_58 = new cjs.Graphics().p("Aj5BgIDblfIEYCcIi/Fjg");
	var mask_graphics_59 = new cjs.Graphics().p("AkGB3ID8mNIERCbIjZGSg");
	var mask_graphics_60 = new cjs.Graphics().p("AkTCOIEbm7IEMCaIjzHBg");
	var mask_graphics_61 = new cjs.Graphics().p("AkgClIE8npIEFCZIkNHwg");
	var mask_graphics_62 = new cjs.Graphics().p("AktC8IFdoXID+CYIknIfg");
	var mask_graphics_63 = new cjs.Graphics().p("Ak6DTIF+pFID3CXIk/JOg");
	var mask_graphics_64 = new cjs.Graphics().p("AlHDqIGfpzIDwCWIlZJ9g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_54,x:-105.5,y:-40.6}).wait(1).to({graphics:mask_graphics_55,x:-104.2,y:-42.8}).wait(1).to({graphics:mask_graphics_56,x:-102.9,y:-45.1}).wait(1).to({graphics:mask_graphics_57,x:-101.6,y:-47.4}).wait(1).to({graphics:mask_graphics_58,x:-100.3,y:-49.7}).wait(1).to({graphics:mask_graphics_59,x:-99,y:-52}).wait(1).to({graphics:mask_graphics_60,x:-97.7,y:-54.3}).wait(1).to({graphics:mask_graphics_61,x:-96.4,y:-56.6}).wait(1).to({graphics:mask_graphics_62,x:-95.1,y:-58.9}).wait(1).to({graphics:mask_graphics_63,x:-93.8,y:-61.2}).wait(1).to({graphics:mask_graphics_64,x:-92.5,y:-63.5}).wait(11));

	// fletxa9
	this.instance = new lib.Mapadebits22();
	this.instance.setTransform(-103.7,-88);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).wait(1));

	// Layer 54 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_54 = new cjs.Graphics().p("AikAQIBSieID3B/IhSCeg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AiuAvIBmjaID3CAIhmDXg");
	var mask_1_graphics_56 = new cjs.Graphics().p("Ai5BNIB8kUID3B/Ih8EQg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AjDBsICQlQID3CAIiQFJg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AjOCKICmmKID3B/IimGCg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AjYCpIC6nGID3CAIi6G7g");
	var mask_1_graphics_60 = new cjs.Graphics().p("AjjDHIDQoAID3B/IjQH0g");
	var mask_1_graphics_61 = new cjs.Graphics().p("AjtDmIDko8ID3CAIjkItg");
	var mask_1_graphics_62 = new cjs.Graphics().p("Aj4EEID4p2ID5B/Ij5Jmg");
	var mask_1_graphics_63 = new cjs.Graphics().p("AkCEjIEMqyID5CAIkMKfg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AkNFBIEirsID5B/IkiLYg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_1_graphics_54,x:-18.1,y:9.9}).wait(1).to({graphics:mask_1_graphics_55,x:-19.1,y:12.7}).wait(1).to({graphics:mask_1_graphics_56,x:-20.2,y:15.6}).wait(1).to({graphics:mask_1_graphics_57,x:-21.2,y:18.4}).wait(1).to({graphics:mask_1_graphics_58,x:-22.3,y:21.3}).wait(1).to({graphics:mask_1_graphics_59,x:-23.3,y:24.1}).wait(1).to({graphics:mask_1_graphics_60,x:-24.4,y:27}).wait(1).to({graphics:mask_1_graphics_61,x:-25.4,y:29.8}).wait(1).to({graphics:mask_1_graphics_62,x:-26.5,y:32.7}).wait(1).to({graphics:mask_1_graphics_63,x:-27.5,y:35.5}).wait(1).to({graphics:mask_1_graphics_64,x:-28.6,y:38.4}).wait(11));

	// fletxa8
	this.instance_1 = new lib.Mapadebits23();
	this.instance_1.setTransform(-45.1,17.3);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},1).wait(1));

	
	

	// co2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#277B7B").s().p("ABbBFIAAgOIAPgKIALgKQAHgGACgFQADgEAAgFQAAgFgDgDQgEgDgGgBQgGABgEACIgLAEIgCAAIAAgPIAMgDQAHgCAHAAQAPAAAIAGQAIAFAAALQAAAHgEAHQgEAHgHAHIgKAIIgHAFIAjAAIAAAQgAgYAgQgQgQAAgYQAAgcAQgQQAPgQAZAAQAbAAAPAQQAQAQAAAcQAAAYgQAQQgPAPgbAAQgZAAgPgPgAAGgsQgFABgCAGQgFAEgBAHQgDAHAAALQAAAIADAHQABAGAFAFQABAEAGADQAFABAFAAQAGAAAFgBQAFgDAEgFQADgEADgHQACgGAAgJQAAgKgCgHQgDgHgDgEQgEgFgFgCQgFgCgGAAQgFAAgFACgAh1AsQgLgDgHgIQgIgIgFgKQgEgLAAgMQAAgOAEgLQAFgLAHgIQAHgHALgEQALgEANAAIANAAIAKADIAKACIAHAEIAAAbIgEAAIgFgEIgHgFQgEgCgFgCQgFgCgGABQgGAAgGABQgFACgFAFQgEAEgDAHQgCAHgBALQAAAIAEAHQACAHAFAEQAFAEAFACQAFABAHABIAKgCIAJgEIAHgFIAFgEIAEAAIAAAbIgIAEIgIACIgLADIgNAAQgNABgKgEg");
	this.shape_1.setTransform(102.5,-4.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#277B7B").s().p("ABcBFIAAgOIANgKIAMgKQAHgHACgEQADgFAAgEQAAgFgDgDQgEgEgHAAQgEAAgGADIgKAEIgCAAIAAgPIALgDQAIgCAHAAQAPAAAIAGQAHAFAAALQABAHgEAIQgEAGgHAHIgKAIIgHAGIAjAAIAAAPgAgYAgQgQgQAAgYQAAgcAQgQQAPgPAZgBQAbABAPAPQAQAQAAAcQAAAYgQAQQgPAPgbAAQgZAAgPgPgAAFgsQgEABgDAGQgDAEgCAHQgDAHAAALQAAAIADAHQACAGADAFQACAEAFADQAFACAGAAQAFAAAGgCQAFgDAEgEQAEgFACgHQACgGAAgJQAAgKgDgHQgCgHgDgEQgFgFgEgCQgGgCgFAAQgGAAgFACgAh2AsQgKgDgIgIQgHgIgFgKQgEgLAAgMQAAgOAEgLQAFgLAHgIQAHgHALgEQALgEANAAIAMAAIALADIAKADIAGADIAAAbIgDAAIgGgEIgGgFQgFgDgEgBQgFgBgGAAQgGAAgGACQgFABgFAFQgEAEgDAIQgDAGABALQAAAIACAHQADAHAFAEQAEAEAGACQAFABAGABIALgCIAJgEIAHgFIAFgEIADAAIAAAbIgIAEIgHACIgLADIgNAAQgNABgLgEg");
	this.shape_2.setTransform(0.5,-113.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#277B7B").s().p("ABbBEIAAgMIAPgLIALgKQAHgGACgFQADgFAAgEQAAgFgDgEQgEgDgGAAQgGAAgEACIgLAGIgCAAIAAgQIALgDQAIgCAHAAQAPAAAIAGQAIAFgBALQAAAHgDAIQgEAGgHAHIgKAIIgHAGIAjAAIAAAOgAgYAgQgQgQAAgZQAAgbAQgPQAPgRAZABQAbgBAPARQAQAPAAAbQAAAZgQAQQgPAQgbAAQgZAAgPgQgAAFgtQgEADgDAEQgEAFgBAHQgDAHAAAKQAAAJADAGQABAIAEAEQACAEAFACQAGACAFABQAGgBAFgCQAFgCAEgEQAEgGACgHQACgFAAgJQAAgKgDgHQgCgHgDgFQgFgEgEgDQgFgBgGAAQgFAAgGABgAh1AsQgLgEgHgHQgIgIgFgLQgEgLAAgMQAAgNAEgLQAEgLAIgHQAHgIALgEQALgEANAAIANAAIAKACIAKAEIAHADIAAAbIgEAAIgFgEIgHgFQgFgCgEgCQgFgCgGAAQgGAAgGADQgFACgFADQgEAFgDAIQgCAGgBAKQAAAJADAHQADAHAFAEQAEAEAGACQAFABAHAAIAKgBIAJgEIAHgFIAFgEIAEAAIAAAbIgIADIgIADIgLADIgNABQgNgBgKgDg");
	this.shape_3.setTransform(-101.4,-35.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// suport
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#F5F5ED","#277B7B"],[0,1],-11.7,-17.3,0,-11.7,-17.3,63.2).s().p("Ak8E8QiDiDAAi5QAAi4CDiEQCEiDC4AAQC5AACDCDQCDCEABC4QgBC5iDCDQiDCEi5AAQi4AAiEiEg");
	this.shape_4.setTransform(-2.1,-15.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#110000","rgba(206,206,168,0)"],[0,1],0.1,0,0,0.1,0,56.7).s().p("AmNGNQikikgBjpQABjoCkilIAAAAQCmilDnAAQDpAAClClQCkClAADoQAADpikCkIgBAAQilCljoAAQjnAAimilg");
	this.shape_5.setTransform(5.9,-8.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	// fons suport
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(102,97,19,0.098)").s().p("Aj7JoQl9l9AAoYQAAmGDIkzIHJEQQh1C3AADoQAAE9DfDiQDKDJEsAXIgBIfQoUgelflhg");
	this.shape_6.setTransform(-67.7,19.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(27,145,205,0.098)").s().p("ApxHJQBwgKBcggQCdg4B/h/QDgjigBk9QABjoh2i2IHJkRQDIEzAAGGQAAIYl9F9QkfEhl7BGQhVAPhtAJg");
	this.shape_7.setTransform(64.2,19.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(39,123,123,0.098)").s().p("AIMFJQjajakygHQkxAHjaDaQgqAqgiAtInBkhQA+hVBOhMQF6l5ISgEQITAEF5F5QBPBMA+BVInBEhQgigtgqgqg");
	this.shape_8.setTransform(-2.1,-99.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-452.5,-141.1,579.4,260.3);
(lib.p1b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// botons

	// Layer 53 (mask) Flecha abajo
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_29 = new cjs.Graphics().p("AijBBIEuisIAZArIkuCsg");
	var mask_2_graphics_30 = new cjs.Graphics().p("AitAqIEtirIAuBZIktCrg");
	var mask_2_graphics_31 = new cjs.Graphics().p("Ai4AUIEuisIBCCHIktCqg");
	var mask_2_graphics_32 = new cjs.Graphics().p("AjCgBIEtitIBYCyIkuCsg");
	var mask_2_graphics_33 = new cjs.Graphics().p("AjNgXIEuiuIBtDhIkuCqg");
	var mask_2_graphics_34 = new cjs.Graphics().p("AjXguIEtitICCEOIktCqg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AjihEIEuiuICWE9IktCog");
	var mask_2_graphics_36 = new cjs.Graphics().p("AjshbIEtitICsFqIktCog");
	var mask_2_graphics_37 = new cjs.Graphics().p("Aj3hxIEuiuIDAGZIktCmg");
	var mask_2_graphics_38 = new cjs.Graphics().p("AkBiIIEtitIDWHHIkuClg");
	var mask_2_graphics_39 = new cjs.Graphics().p("AkMieIEuiuIDqH1IktCkg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_2_graphics_29,x:12.3,y:18.4}).wait(1).to({graphics:mask_2_graphics_30,x:13.4,y:20.7}).wait(1).to({graphics:mask_2_graphics_31,x:14.5,y:22.9}).wait(1).to({graphics:mask_2_graphics_32,x:15.5,y:25.2}).wait(1).to({graphics:mask_2_graphics_33,x:16.6,y:27.4}).wait(1).to({graphics:mask_2_graphics_34,x:17.6,y:29.7}).wait(1).to({graphics:mask_2_graphics_35,x:18.7,y:31.9}).wait(1).to({graphics:mask_2_graphics_36,x:19.7,y:34.2}).wait(1).to({graphics:mask_2_graphics_37,x:20.8,y:36.4}).wait(1).to({graphics:mask_2_graphics_38,x:21.8,y:38.7}).wait(1).to({graphics:mask_2_graphics_39,x:22.8,y:40.9}).wait(1));

	// fletxa7
	this.instance_2 = new lib.Mapadebits8();
	this.instance_2.setTransform(10,16.8);

	this.instance_2.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},29).to({state:[]},21).wait(1));

	// Layer 52 (mask) Flechas hdr
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_29 = new cjs.Graphics().p("AgnC9IAAl6IBOAAIAAF6g");
	var mask_3_graphics_30 = new cjs.Graphics().p("Ag/C+IAAl6IB/AAIAAF6g");
	var mask_3_graphics_31 = new cjs.Graphics().p("AhXC+IAAl7ICwAAIAAF7g");
	var mask_3_graphics_32 = new cjs.Graphics().p("AhwC9IAAl6IDhAAIAAF6g");
	var mask_3_graphics_33 = new cjs.Graphics().p("AiJC+IAAl6IETAAIAAF6g");
	var mask_3_graphics_34 = new cjs.Graphics().p("AihC+IAAl7IFDAAIAAF7g");
	var mask_3_graphics_35 = new cjs.Graphics().p("Ai5C9IAAl6IFzAAIAAF6g");
	var mask_3_graphics_36 = new cjs.Graphics().p("AjSC+IAAl6IGlAAIAAF6g");
	var mask_3_graphics_37 = new cjs.Graphics().p("AjrC+IAAl7IHXAAIAAF7g");
	var mask_3_graphics_38 = new cjs.Graphics().p("AkDC9IAAl6IIHAAIAAF6g");
	var mask_3_graphics_39 = new cjs.Graphics().p("AiGC+IAAl6II4AAIAAF6g");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_3_graphics_29,x:85.9,y:6.9}).wait(1).to({graphics:mask_3_graphics_30,x:83.1,y:6.6}).wait(1).to({graphics:mask_3_graphics_31,x:80.4,y:6.3}).wait(1).to({graphics:mask_3_graphics_32,x:77.6,y:6}).wait(1).to({graphics:mask_3_graphics_33,x:74.9,y:5.7}).wait(1).to({graphics:mask_3_graphics_34,x:72.1,y:5.4}).wait(1).to({graphics:mask_3_graphics_35,x:69.4,y:5.1}).wait(1).to({graphics:mask_3_graphics_36,x:66.6,y:4.8}).wait(1).to({graphics:mask_3_graphics_37,x:63.9,y:4.5}).wait(1).to({graphics:mask_3_graphics_38,x:61.1,y:4.2}).wait(1).to({graphics:mask_3_graphics_39,x:43.4,y:3.9}).wait(1));

	// fletxa6
	this.instance_3 = new lib.Mapadebits9();
	this.instance_3.setTransform(35.9,-0.6);

	this.instance_3.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},29).to({state:[]},21).wait(1));

	// mf5 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_29 = new cjs.Graphics().p("AgmC9IAAl6IBOAAIAAF6g");
	var mask_4_graphics_30 = new cjs.Graphics().p("Ag/C9IAAl6IB/AAIAAF6g");
	var mask_4_graphics_31 = new cjs.Graphics().p("AhXC9IAAl6ICwAAIAAF6g");
	var mask_4_graphics_32 = new cjs.Graphics().p("AhwC9IAAl6IDhAAIAAF6g");
	var mask_4_graphics_33 = new cjs.Graphics().p("AiIC9IAAl6IERAAIAAF6g");
	var mask_4_graphics_34 = new cjs.Graphics().p("AihC9IAAl6IFDAAIAAF6g");
	var mask_4_graphics_35 = new cjs.Graphics().p("Ai5C9IAAl6IFzAAIAAF6g");
	var mask_4_graphics_36 = new cjs.Graphics().p("AjSC9IAAl6IGlAAIAAF6g");
	var mask_4_graphics_37 = new cjs.Graphics().p("AjqC9IAAl6IHVAAIAAF6g");
	var mask_4_graphics_38 = new cjs.Graphics().p("AkDC9IAAl6IIHAAIAAF6g");
	var mask_4_graphics_39 = new cjs.Graphics().p("AiBC9IAAl6II4AAIAAF6g");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_4_graphics_29,x:34.9,y:-19.1}).wait(1).to({graphics:mask_4_graphics_30,x:37.3,y:-19.1}).wait(1).to({graphics:mask_4_graphics_31,x:39.8,y:-19.1}).wait(1).to({graphics:mask_4_graphics_32,x:42.2,y:-19.1}).wait(1).to({graphics:mask_4_graphics_33,x:44.7,y:-19.1}).wait(1).to({graphics:mask_4_graphics_34,x:47.1,y:-19.1}).wait(1).to({graphics:mask_4_graphics_35,x:49.6,y:-19.1}).wait(1).to({graphics:mask_4_graphics_36,x:52,y:-19.1}).wait(1).to({graphics:mask_4_graphics_37,x:54.5,y:-19.1}).wait(1).to({graphics:mask_4_graphics_38,x:56.9,y:-19.1}).wait(1).to({graphics:mask_4_graphics_39,x:43.9,y:-19}).wait(1));

	// fletxa5
	this.instance_4 = new lib.Mapadebits10();
	this.instance_4.setTransform(35.9,-26.6);

	this.instance_4.mask = mask_4;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},29).to({state:[]},21).wait(1));

	// Layer 50 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_4 = new cjs.Graphics().p("Ah2BDIDMisIAhAnIjMCrg");
	var mask_5_graphics_5 = new cjs.Graphics().p("AiGAvIDMirIBBBSIjNCog");
	var mask_5_graphics_6 = new cjs.Graphics().p("AiXAbIDMisIBjB/IjOCkg");
	var mask_5_graphics_7 = new cjs.Graphics().p("AinAHIDMisICDCpIjPChg");
	var mask_5_graphics_8 = new cjs.Graphics().p("Ai4gLIDMitIClDUIjQCdg");
	var mask_5_graphics_9 = new cjs.Graphics().p("AjIgfIDMiuIDFEBIjRCag");
	var mask_5_graphics_10 = new cjs.Graphics().p("AjZgzIDOiuIDlEtIjUCWg");
	var mask_5_graphics_11 = new cjs.Graphics().p("AjphHIDOitIEFFYIjVCRg");
	var mask_5_graphics_12 = new cjs.Graphics().p("Aj6hbIDOiuIEnGFIjWCNg");
	var mask_5_graphics_13 = new cjs.Graphics().p("AkKhvIDOiuIFHGxIjXCJg");
	var mask_5_graphics_14 = new cjs.Graphics().p("Ag9koIDNiuIFqHdIjYCFg");
	var mask_5_graphics_29 = new cjs.Graphics().p("Ah2BDIDMisIAhAnIjMCrg");
	var mask_5_graphics_30 = new cjs.Graphics().p("AiGAvIDMirIBBBSIjNCog");
	var mask_5_graphics_31 = new cjs.Graphics().p("AiXAbIDMisIBjB/IjOCkg");
	var mask_5_graphics_32 = new cjs.Graphics().p("AinAHIDMisICDCpIjPChg");
	var mask_5_graphics_33 = new cjs.Graphics().p("Ai4gLIDMitIClDUIjQCdg");
	var mask_5_graphics_34 = new cjs.Graphics().p("AjIgfIDMiuIDFEBIjRCag");
	var mask_5_graphics_35 = new cjs.Graphics().p("AjZgzIDOiuIDlEtIjUCWg");
	var mask_5_graphics_36 = new cjs.Graphics().p("AjphHIDOitIEFFYIjVCRg");
	var mask_5_graphics_37 = new cjs.Graphics().p("Aj6hbIDOiuIEnGFIjWCNg");
	var mask_5_graphics_38 = new cjs.Graphics().p("AkKhvIDOiuIFHGxIjXCJg");
	var mask_5_graphics_39 = new cjs.Graphics().p("Ag9koIDNiuIFqHdIjYCFg");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_5_graphics_4,x:84.3,y:-41.6}).wait(1).to({graphics:mask_5_graphics_5,x:83.2,y:-43.8}).wait(1).to({graphics:mask_5_graphics_6,x:82,y:-46}).wait(1).to({graphics:mask_5_graphics_7,x:80.9,y:-48.2}).wait(1).to({graphics:mask_5_graphics_8,x:79.7,y:-50.4}).wait(1).to({graphics:mask_5_graphics_9,x:78.6,y:-52.6}).wait(1).to({graphics:mask_5_graphics_10,x:77.4,y:-54.8}).wait(1).to({graphics:mask_5_graphics_11,x:76.3,y:-57}).wait(1).to({graphics:mask_5_graphics_12,x:75.1,y:-59.2}).wait(1).to({graphics:mask_5_graphics_13,x:74,y:-61.4}).wait(1).to({graphics:mask_5_graphics_14,x:50.6,y:-47}).wait(1).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_5_graphics_29,x:84.3,y:-41.6}).wait(1).to({graphics:mask_5_graphics_30,x:83.2,y:-43.8}).wait(1).to({graphics:mask_5_graphics_31,x:82,y:-46}).wait(1).to({graphics:mask_5_graphics_32,x:80.9,y:-48.2}).wait(1).to({graphics:mask_5_graphics_33,x:79.7,y:-50.4}).wait(1).to({graphics:mask_5_graphics_34,x:78.6,y:-52.6}).wait(1).to({graphics:mask_5_graphics_35,x:77.4,y:-54.8}).wait(1).to({graphics:mask_5_graphics_36,x:76.3,y:-57}).wait(1).to({graphics:mask_5_graphics_37,x:75.1,y:-59.2}).wait(1).to({graphics:mask_5_graphics_38,x:74,y:-61.4}).wait(1).to({graphics:mask_5_graphics_39,x:50.6,y:-47}).wait(1));

	// fletxa4
	this.instance_5 = new lib.Mapadebits6();
	this.instance_5.setTransform(53.9,-81.8);

	this.instance_6 = new lib.Mapadebits11();
	this.instance_6.setTransform(53.9,-81.8);

	this.instance_5.mask = this.instance_6.mask = mask_5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},29).to({state:[]},21).wait(1));

	// mf3 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	var mask_6_graphics_4 = new cjs.Graphics().p("Ah2BDIDMirIAhAmIjMCrg");
	var mask_6_graphics_5 = new cjs.Graphics().p("AiGAvIDMirIBBBSIjNCog");
	var mask_6_graphics_6 = new cjs.Graphics().p("AiXAbIDMirIBjB+IjOCjg");
	var mask_6_graphics_7 = new cjs.Graphics().p("AinAHIDMirICDCoIjPCig");
	var mask_6_graphics_8 = new cjs.Graphics().p("Ai4gLIDMitIClDUIjQCdg");
	var mask_6_graphics_9 = new cjs.Graphics().p("AjIgfIDMitIDFEAIjRCZg");
	var mask_6_graphics_10 = new cjs.Graphics().p("AjZgzIDOitIDlEsIjUCWg");
	var mask_6_graphics_11 = new cjs.Graphics().p("AjphHIDOitIEFFYIjVCRg");
	var mask_6_graphics_12 = new cjs.Graphics().p("Aj6hbIDOitIEnGEIjWCOg");
	var mask_6_graphics_13 = new cjs.Graphics().p("AkKhvIDOitIFHGwIjXCJg");
	var mask_6_graphics_14 = new cjs.Graphics().p("AkbiDIDPitIFoHcIjYCGg");
	var mask_6_graphics_29 = new cjs.Graphics().p("Ah2BDIDMirIAhAmIjMCrg");
	var mask_6_graphics_30 = new cjs.Graphics().p("AiGAvIDMirIBBBSIjNCog");
	var mask_6_graphics_31 = new cjs.Graphics().p("AiXAbIDMirIBjB+IjOCjg");
	var mask_6_graphics_32 = new cjs.Graphics().p("AinAHIDMirICDCoIjPCig");
	var mask_6_graphics_33 = new cjs.Graphics().p("Ai4gLIDMitIClDUIjQCdg");
	var mask_6_graphics_34 = new cjs.Graphics().p("AjIgfIDMitIDFEAIjRCZg");
	var mask_6_graphics_35 = new cjs.Graphics().p("AjZgzIDOitIDlEsIjUCWg");
	var mask_6_graphics_36 = new cjs.Graphics().p("AjphHIDOitIEFFYIjVCRg");
	var mask_6_graphics_37 = new cjs.Graphics().p("Aj6hbIDOitIEnGEIjWCOg");
	var mask_6_graphics_38 = new cjs.Graphics().p("AkKhvIDOitIFHGwIjXCJg");
	var mask_6_graphics_39 = new cjs.Graphics().p("AkbiDIDPitIFoHcIjYCGg");

	this.timeline.addTween(cjs.Tween.get(mask_6).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_6_graphics_4,x:69.3,y:-93.6}).wait(1).to({graphics:mask_6_graphics_5,x:71,y:-91.6}).wait(1).to({graphics:mask_6_graphics_6,x:72.6,y:-89.6}).wait(1).to({graphics:mask_6_graphics_7,x:74.3,y:-87.6}).wait(1).to({graphics:mask_6_graphics_8,x:75.9,y:-85.6}).wait(1).to({graphics:mask_6_graphics_9,x:77.6,y:-83.6}).wait(1).to({graphics:mask_6_graphics_10,x:79.2,y:-81.6}).wait(1).to({graphics:mask_6_graphics_11,x:80.9,y:-79.6}).wait(1).to({graphics:mask_6_graphics_12,x:82.5,y:-77.6}).wait(1).to({graphics:mask_6_graphics_13,x:84.2,y:-75.6}).wait(1).to({graphics:mask_6_graphics_14,x:85.8,y:-73.6}).wait(1).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_6_graphics_29,x:69.3,y:-93.6}).wait(1).to({graphics:mask_6_graphics_30,x:71,y:-91.6}).wait(1).to({graphics:mask_6_graphics_31,x:72.6,y:-89.6}).wait(1).to({graphics:mask_6_graphics_32,x:74.3,y:-87.6}).wait(1).to({graphics:mask_6_graphics_33,x:75.9,y:-85.6}).wait(1).to({graphics:mask_6_graphics_34,x:77.6,y:-83.6}).wait(1).to({graphics:mask_6_graphics_35,x:79.2,y:-81.6}).wait(1).to({graphics:mask_6_graphics_36,x:80.9,y:-79.6}).wait(1).to({graphics:mask_6_graphics_37,x:82.5,y:-77.6}).wait(1).to({graphics:mask_6_graphics_38,x:84.2,y:-75.6}).wait(1).to({graphics:mask_6_graphics_39,x:85.8,y:-73.6}).wait(1));

	// fletxa3
	this.instance_7 = new lib.Mapadebits7();
	this.instance_7.setTransform(69.1,-95.5);

	this.instance_8 = new lib.Mapadebits12();
	this.instance_8.setTransform(69.1,-95.5);

	this.instance_7.mask = this.instance_8.mask = mask_6;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7}]},29).to({state:[]},20).wait(1));

	

	// co2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#277B7B").s().p("ABbBFIAAgOIAPgKIALgKQAHgGACgFQADgEAAgFQAAgFgDgDQgEgDgGgBQgGABgEACIgLAEIgCAAIAAgPIAMgDQAHgCAHAAQAPAAAIAGQAIAFAAALQAAAHgEAHQgEAHgHAHIgKAIIgHAFIAjAAIAAAQgAgYAgQgQgQAAgYQAAgcAQgQQAPgQAZAAQAbAAAPAQQAQAQAAAcQAAAYgQAQQgPAPgbAAQgZAAgPgPgAAGgsQgFABgCAGQgFAEgBAHQgDAHAAALQAAAIADAHQABAGAFAFQABAEAGADQAFABAFAAQAGAAAFgBQAFgDAEgFQADgEADgHQACgGAAgJQAAgKgCgHQgDgHgDgEQgEgFgFgCQgFgCgGAAQgFAAgFACgAh1AsQgLgDgHgIQgIgIgFgKQgEgLAAgMQAAgOAEgLQAFgLAHgIQAHgHALgEQALgEANAAIANAAIAKADIAKACIAHAEIAAAbIgEAAIgFgEIgHgFQgEgCgFgCQgFgCgGABQgGAAgGABQgFACgFAFQgEAEgDAHQgCAHgBALQAAAIAEAHQACAHAFAEQAFAEAFACQAFABAHABIAKgCIAJgEIAHgFIAFgEIAEAAIAAAbIgIAEIgIACIgLADIgNAAQgNABgKgEg");
	this.shape_1.setTransform(102.5,-4.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#277B7B").s().p("ABcBFIAAgOIANgKIAMgKQAHgHACgEQADgFAAgEQAAgFgDgDQgEgEgHAAQgEAAgGADIgKAEIgCAAIAAgPIALgDQAIgCAHAAQAPAAAIAGQAHAFAAALQABAHgEAIQgEAGgHAHIgKAIIgHAGIAjAAIAAAPgAgYAgQgQgQAAgYQAAgcAQgQQAPgPAZgBQAbABAPAPQAQAQAAAcQAAAYgQAQQgPAPgbAAQgZAAgPgPgAAFgsQgEABgDAGQgDAEgCAHQgDAHAAALQAAAIADAHQACAGADAFQACAEAFADQAFACAGAAQAFAAAGgCQAFgDAEgEQAEgFACgHQACgGAAgJQAAgKgDgHQgCgHgDgEQgFgFgEgCQgGgCgFAAQgGAAgFACgAh2AsQgKgDgIgIQgHgIgFgKQgEgLAAgMQAAgOAEgLQAFgLAHgIQAHgHALgEQALgEANAAIAMAAIALADIAKADIAGADIAAAbIgDAAIgGgEIgGgFQgFgDgEgBQgFgBgGAAQgGAAgGACQgFABgFAFQgEAEgDAIQgDAGABALQAAAIACAHQADAHAFAEQAEAEAGACQAFABAGABIALgCIAJgEIAHgFIAFgEIADAAIAAAbIgIAEIgHACIgLADIgNAAQgNABgLgEg");
	this.shape_2.setTransform(0.5,-113.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#277B7B").s().p("ABbBEIAAgMIAPgLIALgKQAHgGACgFQADgFAAgEQAAgFgDgEQgEgDgGAAQgGAAgEACIgLAGIgCAAIAAgQIALgDQAIgCAHAAQAPAAAIAGQAIAFgBALQAAAHgDAIQgEAGgHAHIgKAIIgHAGIAjAAIAAAOgAgYAgQgQgQAAgZQAAgbAQgPQAPgRAZABQAbgBAPARQAQAPAAAbQAAAZgQAQQgPAQgbAAQgZAAgPgQgAAFgtQgEADgDAEQgEAFgBAHQgDAHAAAKQAAAJADAGQABAIAEAEQACAEAFACQAGACAFABQAGgBAFgCQAFgCAEgEQAEgGACgHQACgFAAgJQAAgKgDgHQgCgHgDgFQgFgEgEgDQgFgBgGAAQgFAAgGABgAh1AsQgLgEgHgHQgIgIgFgLQgEgLAAgMQAAgNAEgLQAEgLAIgHQAHgIALgEQALgEANAAIANAAIAKACIAKAEIAHADIAAAbIgEAAIgFgEIgHgFQgFgCgEgCQgFgCgGAAQgGAAgGADQgFACgFADQgEAFgDAIQgCAGgBAKQAAAJADAHQADAHAFAEQAEAEAGACQAFABAHAAIAKgBIAJgEIAHgFIAFgEIAEAAIAAAbIgIADIgIADIgLADIgNABQgNgBgKgDg");
	this.shape_3.setTransform(-101.4,-35.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// suport
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#F5F5ED","#277B7B"],[0,1],-11.7,-17.3,0,-11.7,-17.3,63.2).s().p("Ak8E8QiDiDAAi5QAAi4CDiEQCEiDC4AAQC5AACDCDQCDCEABC4QgBC5iDCDQiDCEi5AAQi4AAiEiEg");
	this.shape_4.setTransform(-2.1,-15.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#110000","rgba(206,206,168,0)"],[0,1],0.1,0,0,0.1,0,56.7).s().p("AmNGNQikikgBjpQABjoCkilIAAAAQCmilDnAAQDpAAClClQCkClAADoQAADpikCkIgBAAQilCljoAAQjnAAimilg");
	this.shape_5.setTransform(5.9,-8.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	// fons suport
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(102,97,19,0.098)").s().p("Aj7JoQl9l9AAoYQAAmGDIkzIHJEQQh1C3AADoQAAE9DfDiQDKDJEsAXIgBIfQoUgelflhg");
	this.shape_6.setTransform(-67.7,19.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(27,145,205,0.098)").s().p("ApxHJQBwgKBcggQCdg4B/h/QDgjigBk9QABjoh2i2IHJkRQDIEzAAGGQAAIYl9F9QkfEhl7BGQhVAPhtAJg");
	this.shape_7.setTransform(64.2,19.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(39,123,123,0.098)").s().p("AIMFJQjajakygHQkxAHjaDaQgqAqgiAtInBkhQA+hVBOhMQF6l5ISgEQITAEF5F5QBPBMA+BVInBEhQgigtgqgqg");
	this.shape_8.setTransform(-2.1,-99.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-452.5,-141.1,579.4,260.3);

(lib.fotosIntro = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.introduccio();
	this.instance.setTransform(128,-8.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(31.7,-106.7,198,196);

    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '400px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}