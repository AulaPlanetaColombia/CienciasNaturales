(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
        titulo1(this, txt['titulo']);
        this.txt_boto_03 = new cjs.Text('Bloques o\nregiones', "bold 16px Verdana");
        this.txt_boto_03.textAlign = "center";
        this.txt_boto_03.lineHeight = 18;
        this.txt_boto_03.lineWidth = 140;
        this.txt_boto_03.setTransform(137.3, 381);
        

        this.txt_boto_02 = new cjs.Text(txt['txt_boto_02'], "bold 16px Verdana");
        this.txt_boto_02.textAlign = "center";
        this.txt_boto_02.lineHeight = 18;
        this.txt_boto_02.lineWidth = 141;
        this.txt_boto_02.setTransform(136.8, 323.2);

        this.txt_boto_01 = new cjs.Text(txt['txt_boto_01'], "bold 16px Verdana");
        this.txt_boto_01.textAlign = "center";
        this.txt_boto_01.lineHeight = 18;
        this.txt_boto_01.lineWidth = 139;
        this.txt_boto_01.setTransform(136.5, 263.2);

        this.mc_03 = new lib.CdP_Practica();
        this.mc_03.setTransform(68, 375, 1.1, 1.6);
        new cjs.ButtonHelper(this.mc_03, 0, 1, 2, false, new lib.CdP_Practica(), 3);

        this.mc_02 = new lib.CdP_Practica();
        this.mc_02.setTransform(68, 315, 1.1, 1.1);
        new cjs.ButtonHelper(this.mc_02, 0, 1, 2, false, new lib.CdP_Practica(), 3);

        this.mc_01 = new lib.CdP_Practica();
        this.mc_01.setTransform(68, 254, 1.1, 1.1, 0, 0, 0, 0, -0.9);
        new cjs.ButtonHelper(this.mc_01, 0, 1, 2, false, new lib.CdP_Practica(), 3);

        this.mc_01.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.mc_02.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.mc_03.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });

        this.instance_1 = new lib.CdP_Ampliacio_01();
        this.instance_1.setTransform(603.6, 339.5, 0.811, 0.811, 0, 0, 0, 475.1, 303.9);

        this.addChild(this.logo, this.titulo, this.instance_1, this.mc_01, this.mc_02, this.mc_03, this.txt_boto_01, this.txt_boto_02, this.txt_boto_03);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
        texto(this, txt['txt_01_01'], 1, 320);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(376.7, 178);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_1b());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AZF9RMAAAA6jMgyJAAAMAAAg6jg");
        this.shape.setTransform(240.8, 347.1);
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFCCFF").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
        this.shape_1.setTransform(474.4, 347, 1, 0.992);

        this.instance_1 = new lib.IMG_01();
        this.instance_1.setTransform(240.9, 347.1, 1, 1, 0, 0, 0, 160.6, 187.5);

        this.addChild(this.shape_1, this.shape, this.instance_1, this.texto, this.siguiente, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_1b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_01();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame1_2 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 1, 1, 0, 1);
        texto(this, txt['txt_01_02'], 1, 320,-380);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(376.7, 178);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_2b());
        });
           this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
		/*
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
		*/
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

       	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AZF9RMAAAA6jMgyJAAAMAAAg6jg");
	this.shape.setTransform(239.8,347.1);

	this.instance_1 = new lib.IMG_02();
	this.instance_1.setTransform(239.9,347.1,1,1,0,0,0,160.6,187.5);

	

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFCCFF").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
	this.shape_1.setTransform(473.4,347,1,0.992);

        this.addChild(this.shape_1, this.shape, this.instance_1, this.texto, /*this.siguiente,*/this.anterior, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_2b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_02();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    /*
     (lib.frame1_3 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
        texto(this, txt['txt_01_03'], 1, 320,-380);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(376.7, 178);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_3b());
        });
           this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

      this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AZF9RMAAAA6jMgyJAAAMAAAg6jg");
	this.shape.setTransform(240.8,347.1);

	this.instance_1 = new lib.IMG_03();
	this.instance_1.setTransform(240.9,347.1,1,1,0,0,0,160.6,187.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFCCFF").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
	this.shape_1.setTransform(474.4,347,1,0.992);

        this.addChild(this.shape_1, this.shape, this.instance_1, this.texto, this.anterior, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_3b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_03();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
*/
 (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
        texto(this, txt['txt_02_01'], 1, 320,-452);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(377.3,167);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame2_1b());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

       this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AZF9RMAAAA6jMgyJAAAMAAAg6jg");
	this.shape.setTransform(241.4,336.1);

	this.instance_1 = new lib.IMG_04();
	this.instance_1.setTransform(241.4,336.1,1,1,0,0,0,160.6,187.5);


	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCFF").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
	this.shape_1.setTransform(475,336,1,0.992);

        this.addChild(this.shape_1, this.shape, this.instance_1, this.texto, this.siguiente, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_1b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_04();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 1, 1, 0, 1);
        texto(this, txt['txt_02_02'], 1, 320,-380);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(377.3,167);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame2_2b());
        });
           this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
		/*
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
		*/
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });


       this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AZF9RMAAAA6jMgyJAAAMAAAg6jg");
	this.shape.setTransform(241.4,336.1);

	this.instance_1 = new lib.IMG_05();
	this.instance_1.setTransform(241.4,336.1,1,1,0,0,0,160.6,187.5);


	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCFF").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
	this.shape_1.setTransform(475,336,1,0.992);
        
      


        this.addChild(this.shape_1, this.shape, this.instance_1, this.texto, /*this.siguiente,*/this.anterior, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_2b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_05();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
/*    
     (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
        texto(this, txt['txt_02_03'], 1, 320,-380);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(377.3,167);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame2_3b());
        });
           this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

       this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AZF9RMAAAA6jMgyJAAAMAAAg6jg");
	this.shape.setTransform(241.4,336.1);

	this.instance_1 = new lib.IMG_06();
	this.instance_1.setTransform(241.9,336.1,1,1,0,0,0,160.6,187.5);

	
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCFF").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
	this.shape_1.setTransform(475,336,1,0.992);
        

        this.addChild(this.shape_1, this.instance_1, this.shape, this.texto, this.anterior, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_3b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_03();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
*/    
    
    (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
        texto(this, txt['txt_03_01'], 1, 320);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(376.7,178);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame3_1b());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

     	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AZF9RMAAAA6jMgyJAAAMAAAg6jg");
	this.shape.setTransform(240.8,347.1);

	this.instance_1 = new lib.IMG_07();
	this.instance_1.setTransform(240.9,347.1,1,1,0,0,0,160.6,187.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#99CCFF").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
	this.shape_1.setTransform(474.4,347,1,0.992);


        this.addChild(this.shape_1, this.shape, this.instance_1, this.texto, this.siguiente, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_1b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_07();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
      (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
        texto(this, txt['txt_03_02'], 1, 320,-380);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(376.7,178);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame3_2b());
        });
           this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

    this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AZF9RMAAAA6jMgyJAAAMAAAg6jg");
	this.shape.setTransform(240.8,347.1);

	this.instance_1 = new lib.IMG_08();
	this.instance_1.setTransform(240.9,347.1,1,1,0,0,0,160.6,187.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#99CCFF").s().p("EhKLAdiMAAAg7CMCUXAAAMAAAA7Cg");
	this.shape_1.setTransform(474.4,347,1,0.992);
        

        this.addChild(this.shape_1, this.instance_1, this.shape, this.texto, this.anterior, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_2b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_08();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    
// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho, top,w) {
        top = top || -432;
        w = w || 730;
        width = w - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left", "texto");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
    (lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.FQ_10_11_021 = function () {
        this.initialize(img.FQ_10_11_021);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 500, 500);


    (lib.FQ_10_11_022 = function () {
        this.initialize(img.FQ_10_11_022);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 500, 500);


    (lib.FQ_10_11_023 = function () {
        this.initialize(img.FQ_10_11_023);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 500, 500);


    (lib.mc_pastillaBlanca = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Egj/AIbIAAw1MBIAAAAIAAQ1g");
        this.shape.setTransform(230.5, 54);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 461, 108);


    (lib.IMG_07 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        mask.setTransform(160.6, 187.5);

        // Capa 5
        this.instance = new lib.FQ_10_11_023();
        this.instance.setTransform(-11.9, 26.4, 0.664, 0.664);

        this.instance.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}]}).wait(25));

        // Capa 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        this.shape.setTransform(160.6, 187.5);

        this.shape.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).wait(25000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-11.9, 0, 333.2, 374.9);


    (lib.IMG_05 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        mask.setTransform(160.6, 187.5);

        // Capa 2
        this.instance = new lib.FQ_10_11_022();
        this.instance.setTransform(4.6, 34.6, 0.619, 0.619);

        this.instance.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}]}).wait(25));

        // Capa 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        this.shape.setTransform(160.6, 187.5);

        this.shape.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).wait(25));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 321.2, 374.9);


    (lib.CdP_Ampliacio_08 = function () {
        this.initialize();

        // FLECHAS
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000000").s().p("Ag+gkQAlAPAYAHQAnAMAZACQgZADgnAMQgoAMgVAKg");
        this.shape.setTransform(875.7, 138.1, 0.855, 0.855);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AgXAAIAvAA");
        this.shape_1.setTransform(870.4, 138, 0.855, 0.855);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#000000").s().p("AACAPQgmgMgagDQAagCAmgMQAogMAVgKIAABJQgigNgbgJg");
        this.shape_2.setTransform(841.3, 138.1, 0.855, 0.855);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AgdAAIA7AA");
        this.shape_3.setTransform(847.2, 138.1, 0.855, 0.855);

        this.text = new cjs.Text("6d", "20px Verdana");
        this.text.lineHeight = 24;
        this.text.setTransform(374.9, 400.8, 0.855, 0.855);

        this.text_1 = new cjs.Text("5d", "20px Verdana");
        this.text_1.lineHeight = 24;
        this.text_1.setTransform(374.9, 353.8, 0.855, 0.855);

        this.text_2 = new cjs.Text("4d", "20px Verdana");
        this.text_2.lineHeight = 24;
        this.text_2.setTransform(374.9, 311, 0.855, 0.855);

        this.text_3 = new cjs.Text("3d", "20px Verdana");
        this.text_3.lineHeight = 24;
        this.text_3.setTransform(374.9, 264.9, 0.855, 0.855);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#000000").s().p("Ag+gkQAqAQATAGQAnAMAZACQgZADgnAMQgkALgZALg");
        this.shape_4.setTransform(877, 513.7, 0.855, 0.855);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#000000").ss(2, 0, 0, 4).p("A6nAAMA1PAAA");
        this.shape_5.setTransform(728, 513.7, 0.855, 0.855);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#000000").s().p("AACAPQgngMgZgDQAZgCAngMQAggKAdgMIAABJQgqgRgTgFg");
        this.shape_6.setTransform(255.6, 513.8, 0.855, 0.855);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#000000").ss(2, 0, 0, 4).p("A6lAAMA1LAAA");
        this.shape_7.setTransform(404.5, 513.7, 0.855, 0.855);

        this.text_4 = new cjs.Text("5f", "20px Verdana");
        this.text_4.lineHeight = 24;
        this.text_4.setTransform(556, 506, 0.855, 0.855);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#000000").s().p("Ag+glQAqASATAFQAmAMAaACQgaADgmAMQgkALgZAMg");
        this.shape_8.setTransform(875.3, 470.1, 0.855, 0.855);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f().s("#000000").ss(2, 0, 0, 4).p("A6nAAMA1PAAA");
        this.shape_9.setTransform(726.3, 470.1, 0.855, 0.855);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f("#000000").s().p("AACAPQgmgMgagDQAagCAmgMQAggKAdgMIAABJQgqgRgTgFg");
        this.shape_10.setTransform(253.9, 470.1, 0.855, 0.855);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f().s("#000000").ss(2, 0, 0, 4).p("A6lAAMA1LAAA");
        this.shape_11.setTransform(402.7, 470.1, 0.855, 0.855);

        this.text_5 = new cjs.Text("4f", "20px Verdana");
        this.text_5.lineHeight = 24;
        this.text_5.setTransform(554.3, 462.4, 0.855, 0.855);

        this.text_6 = new cjs.Text("7p", "20px Verdana");
        this.text_6.lineHeight = 24;
        this.text_6.setTransform(735.4, 400.8, 0.855, 0.855);

        this.text_7 = new cjs.Text("6p", "20px Verdana");
        this.text_7.lineHeight = 24;
        this.text_7.setTransform(735.4, 355.6, 0.855, 0.855);

        this.text_8 = new cjs.Text("5p", "20px Verdana");
        this.text_8.lineHeight = 24;
        this.text_8.setTransform(735.6, 311.8, 0.855, 0.855);

        this.text_9 = new cjs.Text("4p", "20px Verdana");
        this.text_9.lineHeight = 24;
        this.text_9.setTransform(735.5, 266.5, 0.855, 0.855);

        this.text_10 = new cjs.Text("3p", "20px Verdana");
        this.text_10.lineHeight = 24;
        this.text_10.setTransform(735.6, 220.1, 0.855, 0.855);

        this.text_11 = new cjs.Text("2p", "20px Verdana");
        this.text_11.lineHeight = 24;
        this.text_11.setTransform(735.1, 176.8, 0.855, 0.855);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f("#000000").s().p("Ag+gkQAqARATAFQAmAMAaACQgaADgmAMQgYAHglAPg");
        this.shape_12.setTransform(875.9, 228.5, 0.855, 0.855);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AJ5AAIzxAA");
        this.shape_13.setTransform(818.5, 228.5, 0.855, 0.855);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f("#000000").s().p("Ag+glQAqASATAFQAnAMAZACQgZADgnAMQgoAMgVALg");
        this.shape_14.setTransform(876.5, 273.3, 0.855, 0.855);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AJ5AAIzxAA");
        this.shape_15.setTransform(819.1, 273.3, 0.855, 0.855);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f("#000000").s().p("Ag+gkQArARASAFQAnANAZABQgZADgnAMQggAKgdAMg");
        this.shape_16.setTransform(876.1, 318.4, 0.855, 0.855);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AJ5AAIzxAA");
        this.shape_17.setTransform(818.7, 318.5, 0.855, 0.855);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f("#000000").s().p("Ag+glQArARARAGQAmAMAbACQgbADgmAMQgoANgUAKg");
        this.shape_18.setTransform(877.1, 363.2, 0.855, 0.855);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AJ5AAIzxAA");
        this.shape_19.setTransform(819.6, 363.2, 0.855, 0.855);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f("#000000").s().p("Ag+gkQAqARATAFQAmAMAaACQgaADgmAMQggAKgdAMg");
        this.shape_20.setTransform(876.4, 409.7, 0.855, 0.855);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AJ5AAIzxAA");
        this.shape_21.setTransform(819, 409.7, 0.855, 0.855);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f("#000000").s().p("AADAPQgngNgagCQAagCAngMQAogMAUgKIAABJQgmgPgWgHg");
        this.shape_22.setTransform(616.9, 408.1, 0.855, 0.855);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.f().s("#000000").ss(2, 0, 0, 4).p("ApyAAITlAA");
        this.shape_23.setTransform(673.9, 408.1, 0.855, 0.855);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f("#000000").s().p("AACAPQgmgMgagDQAagCAmgMQAogMAVgKIAABJQglgPgYgHg");
        this.shape_24.setTransform(616.3, 362.5, 0.855, 0.855);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.f().s("#000000").ss(2, 0, 0, 4).p("ApyAAITlAA");
        this.shape_25.setTransform(673.2, 362.5, 0.855, 0.855);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f("#000000").s().p("AACAPQgmgMgagDQAagCAmgMQAogMAVgKIAABJQgqgQgTgGg");
        this.shape_26.setTransform(616.7, 319.1, 0.855, 0.855);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.f().s("#000000").ss(2, 0, 0, 4).p("ApyAAITlAA");
        this.shape_27.setTransform(673.6, 319.1, 0.855, 0.855);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f("#000000").s().p("AADAPQgmgMgbgDQAbgCAmgMQAogMAUgKIAABJQglgPgXgHg");
        this.shape_28.setTransform(615.8, 273.4, 0.855, 0.855);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.f().s("#000000").ss(2, 0, 0, 4).p("ApyAAITlAA");
        this.shape_29.setTransform(672.7, 273.5, 0.855, 0.855);

        this.shape_30 = new cjs.Shape();
        this.shape_30.graphics.f("#000000").s().p("AACAPQgmgMgagDQAagCAmgMQAYgHAlgPIAABJQgqgRgTgFg");
        this.shape_30.setTransform(616.4, 226.9, 0.855, 0.855);

        this.shape_31 = new cjs.Shape();
        this.shape_31.graphics.f().s("#000000").ss(2, 0, 0, 4).p("ApyAAITlAA");
        this.shape_31.setTransform(673.3, 226.9, 0.855, 0.855);

        this.shape_32 = new cjs.Shape();
        this.shape_32.graphics.f("#000000").s().p("Ag+glQAqASATAFQAmAMAaACQgaADgmAMQgoAMgVALg");
        this.shape_32.setTransform(874.9, 185.3, 0.855, 0.855);

        this.shape_33 = new cjs.Shape();
        this.shape_33.graphics.f().s("#000000").ss(2, 0, 0, 4).p("ApyAAITlAA");
        this.shape_33.setTransform(818, 185.3, 0.855, 0.855);

        this.shape_34 = new cjs.Shape();
        this.shape_34.graphics.f("#000000").s().p("AACAPQgngMgZgDQAZgCAngMQAYgHAlgPIAABJQgqgRgTgFg");
        this.shape_34.setTransform(617.3, 184.5, 0.855, 0.855);

        this.shape_35 = new cjs.Shape();
        this.shape_35.graphics.f().s("#000000").ss(2, 0, 0, 4).p("ApyAAITlAA");
        this.shape_35.setTransform(674.2, 184.5, 0.855, 0.855);

        this.shape_36 = new cjs.Shape();
        this.shape_36.graphics.f("#000000").s().p("Ag+glQAqASATAFQAmAMAaACQgaADgmAMQgoAMgVALg");
        this.shape_36.setTransform(604.2, 408.5, 0.855, 0.855);

        this.shape_37 = new cjs.Shape();
        this.shape_37.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AyIAAMAkRAAA");
        this.shape_37.setTransform(501.6, 408.5, 0.855, 0.855);

        this.shape_38 = new cjs.Shape();
        this.shape_38.graphics.f("#000000").s().p("AACAPQgmgMgagDQAagCAmgMQAggKAdgMIAABJQgqgRgTgFg");
        this.shape_38.setTransform(165.8, 408.6, 0.855, 0.855);

        this.shape_39 = new cjs.Shape();
        this.shape_39.graphics.f().s("#000000").ss(2, 0, 0, 4).p("Ax+AAMAj9AAA");
        this.shape_39.setTransform(267.5, 408.6, 0.855, 0.855);

        this.shape_40 = new cjs.Shape();
        this.shape_40.graphics.f("#000000").s().p("Ag+glQAqASATAFQAmAMAaACQgaADgmAMQgkALgZAMg");
        this.shape_40.setTransform(605.2, 362.3, 0.855, 0.855);

        this.shape_41 = new cjs.Shape();
        this.shape_41.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AyIAAMAkRAAA");
        this.shape_41.setTransform(502.6, 362.3, 0.855, 0.855);

        this.shape_42 = new cjs.Shape();
        this.shape_42.graphics.f("#000000").s().p("AACAPQgmgMgagDQAagCAmgMQAggKAdgMIAABJQgqgRgTgFg");
        this.shape_42.setTransform(166.8, 362.4, 0.855, 0.855);

        this.shape_43 = new cjs.Shape();
        this.shape_43.graphics.f().s("#000000").ss(2, 0, 0, 4).p("Ax+AAMAj9AAA");
        this.shape_43.setTransform(268.5, 362.4, 0.855, 0.855);

        this.shape_44 = new cjs.Shape();
        this.shape_44.graphics.f("#000000").s().p("Ag+glQAqASATAFQAmAMAaACQgaADgmAMQgoAMgVALg");
        this.shape_44.setTransform(604.2, 318.7, 0.855, 0.855);

        this.shape_45 = new cjs.Shape();
        this.shape_45.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AyIAAMAkRAAA");
        this.shape_45.setTransform(501.6, 318.7, 0.855, 0.855);

        this.shape_46 = new cjs.Shape();
        this.shape_46.graphics.f("#000000").s().p("AACAPQgmgMgagDQAagCAmgMQAggKAdgMIAABJQgqgRgTgFg");
        this.shape_46.setTransform(165.8, 318.8, 0.855, 0.855);

        this.shape_47 = new cjs.Shape();
        this.shape_47.graphics.f().s("#000000").ss(2, 0, 0, 4).p("Ax+AAMAj9AAA");
        this.shape_47.setTransform(267.5, 318.8, 0.855, 0.855);

        this.shape_48 = new cjs.Shape();
        this.shape_48.graphics.f("#000000").s().p("Ag+glQAqASATAFQAmAMAaACQgaADgmAMQgkALgZAMg");
        this.shape_48.setTransform(153.7, 408.4, 0.855, 0.855);

        this.shape_49 = new cjs.Shape();
        this.shape_49.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AiaAAIE1AA");
        this.shape_49.setTransform(137.2, 408.4, 0.855, 0.855);

        this.shape_50 = new cjs.Shape();
        this.shape_50.graphics.f("#000000").s().p("AACAPQgogNgYgCQAagCAmgMQAogMAVgKIAABJQgqgRgTgFg");
        this.shape_50.setTransform(76.1, 408.4, 0.855, 0.855);

        this.shape_51 = new cjs.Shape();
        this.shape_51.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AiKAAIEVAA");
        this.shape_51.setTransform(91.2, 408.4, 0.855, 0.855);

        this.shape_52 = new cjs.Shape();
        this.shape_52.graphics.f("#000000").s().p("Ag+gkQAhANAcAJQAmAMAaACQgaADgmAMQgpAMgUAKg");
        this.shape_52.setTransform(154.1, 362.7, 0.855, 0.855);

        this.shape_53 = new cjs.Shape();
        this.shape_53.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AiaAAIE1AA");
        this.shape_53.setTransform(137.5, 362.7, 0.855, 0.855);

        this.shape_54 = new cjs.Shape();
        this.shape_54.graphics.f("#000000").s().p("AACAPQgngMgZgDQAZgCAngMQAkgKAZgMIAABJQglgPgYgHg");
        this.shape_54.setTransform(76.2, 362.7, 0.855, 0.855);

        this.shape_55 = new cjs.Shape();
        this.shape_55.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AiGAAIENAA");
        this.shape_55.setTransform(91.1, 362.7, 0.855, 0.855);

        this.shape_56 = new cjs.Shape();
        this.shape_56.graphics.f("#000000").s().p("Ag+gkQAhANAcAJQAmAMAaACQgaADgmAMQgpAMgUAKg");
        this.shape_56.setTransform(154.7, 319, 0.855, 0.855);

        this.shape_57 = new cjs.Shape();
        this.shape_57.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AieAAIE9AA");
        this.shape_57.setTransform(137.8, 319, 0.855, 0.855);

        this.shape_58 = new cjs.Shape();
        this.shape_58.graphics.f("#000000").s().p("AACAPQgmgMgagDQAagCAmgMQAkgKAZgMIAABJQgpgQgUgGg");
        this.shape_58.setTransform(77.5, 318.8, 0.855, 0.855);

        this.shape_59 = new cjs.Shape();
        this.shape_59.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AiAAAIEBAA");
        this.shape_59.setTransform(91.8, 318.8, 0.855, 0.855);

        this.shape_60 = new cjs.Shape();
        this.shape_60.graphics.f("#000000").s().p("Ag+glQAqARATAGQAmAMAaACQgaADgmAMQgkALgZAMg");
        this.shape_60.setTransform(154.1, 273.9, 0.855, 0.855);

        this.shape_61 = new cjs.Shape();
        this.shape_61.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AibAAIE3AA");
        this.shape_61.setTransform(137.5, 273.9, 0.855, 0.855);

        this.shape_62 = new cjs.Shape();
        this.shape_62.graphics.f("#000000").s().p("AACAPQgmgMgagDQAagCAmgMQAhgKAcgMIAABJQgmgPgXgHg");
        this.shape_62.setTransform(76.8, 273.7, 0.855, 0.855);

        this.shape_63 = new cjs.Shape();
        this.shape_63.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AiDAAIEHAA");
        this.shape_63.setTransform(91.5, 273.8, 0.855, 0.855);

        this.shape_64 = new cjs.Shape();
        this.shape_64.graphics.f("#000000").s().p("Ag+gkQAqAQATAGQAnAMAZACQgZADgnAMQgoAMgVAKg");
        this.shape_64.setTransform(153.8, 227.5, 0.855, 0.855);

        this.shape_65 = new cjs.Shape();
        this.shape_65.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AiaAAIE1AA");
        this.shape_65.setTransform(137.3, 227.5, 0.855, 0.855);

        this.shape_66 = new cjs.Shape();
        this.shape_66.graphics.f("#000000").s().p("AACAPQgngMgZgDQAZgCAngMQAggKAdgMIAABJQgqgRgTgFg");
        this.shape_66.setTransform(76.5, 227.3, 0.855, 0.855);

        this.shape_67 = new cjs.Shape();
        this.shape_67.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AiFAAIELAA");
        this.shape_67.setTransform(91.3, 227.3, 0.855, 0.855);

        this.shape_68 = new cjs.Shape();
        this.shape_68.graphics.f("#000000").s().p("Ag+gkQAqARATAFQAnAMAZACQgZADgnAMQggAKgdAMg");
        this.shape_68.setTransform(154.2, 184.1, 0.855, 0.855);

        this.shape_69 = new cjs.Shape();
        this.shape_69.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AicAAIE5AA");
        this.shape_69.setTransform(137.4, 184.1, 0.855, 0.855);

        this.shape_70 = new cjs.Shape();
        this.shape_70.graphics.f("#000000").s().p("AACAPQgngMgZgDQAZgCAngMQAogMAVgLIAABLQgrgRgSgGg");
        this.shape_70.setTransform(76.9, 183.9, 0.855, 0.855);

        this.shape_71 = new cjs.Shape();
        this.shape_71.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AiBAAIEDAA");
        this.shape_71.setTransform(91.3, 183.9, 0.855, 0.855);

        this.text_12 = new cjs.Text("7s", "20px Verdana");
        this.text_12.lineHeight = 24;
        this.text_12.setTransform(103.4, 399.9, 0.855, 0.855);

        this.text_13 = new cjs.Text("6s", "20px Verdana");
        this.text_13.lineHeight = 24;
        this.text_13.setTransform(103.4, 354.7, 0.855, 0.855);

        this.text_14 = new cjs.Text("5s", "20px Verdana");
        this.text_14.lineHeight = 24;
        this.text_14.setTransform(103.6, 311, 0.855, 0.855);

        this.text_15 = new cjs.Text("4s", "20px Verdana");
        this.text_15.lineHeight = 24;
        this.text_15.setTransform(103.5, 265.7, 0.855, 0.855);

        this.text_16 = new cjs.Text("3s", "20px Verdana");
        this.text_16.lineHeight = 24;
        this.text_16.setTransform(103.6, 219.2, 0.855, 0.855);

        this.text_17 = new cjs.Text("2s", "20px Verdana");
        this.text_17.lineHeight = 24;
        this.text_17.setTransform(103.1, 176, 0.855, 0.855);

        this.text_18 = new cjs.Text("1s", "20px Verdana");
        this.text_18.lineHeight = 24;
        this.text_18.setTransform(848.5, 129.5, 0.855, 0.855);

        this.text_19 = new cjs.Text("1s", "20px Verdana");
        this.text_19.lineHeight = 24;
        this.text_19.setTransform(82.9, 129.6, 0.855, 0.855);

        this.shape_72 = new cjs.Shape();
        this.shape_72.graphics.f("#000000").s().p("Ag+gkQArARARAFQAoANAZABQgZADgoAMQgfAKgdAMg");
        this.shape_72.setTransform(109.3, 138.1, 0.855, 0.855);

        this.shape_73 = new cjs.Shape();
        this.shape_73.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AgXAAIAvAA");
        this.shape_73.setTransform(103.9, 138.1, 0.855, 0.855);

        this.shape_74 = new cjs.Shape();
        this.shape_74.graphics.f("#000000").s().p("AACAPQgmgMgagDQAagCAmgMQAggKAdgMIAABJQgqgRgTgFg");
        this.shape_74.setTransform(74.9, 138.2, 0.855, 0.855);

        this.shape_75 = new cjs.Shape();
        this.shape_75.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AgdAAIA8AA");
        this.shape_75.setTransform(80.8, 138.1, 0.855, 0.855);

        this.shape_76 = new cjs.Shape();
        this.shape_76.graphics.f("#000000").s().p("Ag+gkQAqAQATAGQAmAMAaACQgaADgmAMQgkALgZAMg");
        this.shape_76.setTransform(605.2, 273.4, 0.855, 0.855);

        this.shape_77 = new cjs.Shape();
        this.shape_77.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AyIAAMAkRAAA");
        this.shape_77.setTransform(502.6, 273.4, 0.855, 0.855);

        this.shape_78 = new cjs.Shape();
        this.shape_78.graphics.f("#000000").s().p("AACAPQgmgMgagDQAagCAmgMQAggKAdgMIAABJQgqgRgTgFg");
        this.shape_78.setTransform(166.8, 273.4, 0.855, 0.855);

        this.shape_79 = new cjs.Shape();
        this.shape_79.graphics.f().s("#000000").ss(2, 0, 0, 4).p("Ax+AAMAj9AAA");
        this.shape_79.setTransform(268.5, 273.4, 0.855, 0.855);

        // TEXTOS
        this.shape_80 = new cjs.Shape();
        this.shape_80.graphics.f("#FF0000").s().p("AhshlIDZBlIjZBmg");
        this.shape_80.setTransform(227.8, 490.4, 0.855, 0.855);

        this.text_20 = new cjs.Text("Bloque f", "23px Verdana");
        this.text_20.lineHeight = 29;
        this.text_20.setTransform(128.3, 481.3, 0.855, 0.855);

        this.text_21 = new cjs.Text("Bloque p", "23px Verdana");
        this.text_21.lineHeight = 29;
        this.text_21.setTransform(703.9, 114.5, 0.855, 0.855);

        this.text_22 = new cjs.Text("Bloque d", "23px Verdana");
        this.text_22.lineHeight = 29;
        this.text_22.setTransform(339.7, 206.5, 0.855, 0.855);

        this.text_23 = new cjs.Text("Bloque s", "23px Verdana");
        this.text_23.lineHeight = 29;
        this.text_23.setTransform(67.6, 67.4, 0.855, 0.855);

        // TABLA
        this.shape_81 = new cjs.Shape();
        this.shape_81.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("EBKKAAAMiUTAAA");
        this.shape_81.setTransform(475.4, 384.9, 0.855, 0.855);

        this.shape_82 = new cjs.Shape();
        this.shape_82.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("EhJ7AAAMCT3AAA");
        this.shape_82.setTransform(476.2, 340.5, 0.855, 0.855);

        this.shape_83 = new cjs.Shape();
        this.shape_83.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AkBAAIICAA");
        this.shape_83.setTransform(858.6, 160.3, 0.855, 0.855);

        this.shape_84 = new cjs.Shape();
        this.shape_84.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("A4oAAMAxRAAA");
        this.shape_84.setTransform(746.2, 205.7, 0.855, 0.855);

        this.shape_85 = new cjs.Shape();
        this.shape_85.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("A4gAAMAxBAAA");
        this.shape_85.setTransform(746, 250.2, 0.855, 0.855);

        this.shape_86 = new cjs.Shape();
        this.shape_86.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("EhKCAAAMCUFAAA");
        this.shape_86.setTransform(475.7, 295.2, 0.855, 0.855);

        this.shape_87 = new cjs.Shape();
        this.shape_87.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AISAAIwjAA");
        this.shape_87.setTransform(115.8, 250.7, 0.855, 0.855);

        this.shape_88 = new cjs.Shape();
        this.shape_88.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AINAAIwZAA");
        this.shape_88.setTransform(115.8, 205.7, 0.855, 0.855);

        this.shape_89 = new cjs.Shape();
        this.shape_89.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AEBAAIoBAA");
        this.shape_89.setTransform(92, 160.8, 0.855, 0.855);

        this.shape_90 = new cjs.Shape();
        this.shape_90.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAoWIAAQt");
        this.shape_90.setTransform(296.3, 492.6, 0.855, 0.855);

        this.shape_91 = new cjs.Shape();
        this.shape_91.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAoVIAAQr");
        this.shape_91.setTransform(341.3, 492.1, 0.855, 0.855);

        this.shape_92 = new cjs.Shape();
        this.shape_92.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAobIAAQ3");
        this.shape_92.setTransform(386.3, 492.6, 0.855, 0.855);

        this.shape_93 = new cjs.Shape();
        this.shape_93.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAoYIAAQx");
        this.shape_93.setTransform(431.3, 491.9, 0.855, 0.855);

        this.shape_94 = new cjs.Shape();
        this.shape_94.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAoVIAAQr");
        this.shape_94.setTransform(475.3, 492.1, 0.855, 0.855);

        this.shape_95 = new cjs.Shape();
        this.shape_95.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAoYIAAQx");
        this.shape_95.setTransform(521.3, 492.4, 0.855, 0.855);

        this.shape_96 = new cjs.Shape();
        this.shape_96.graphics.f().s("rgba(0,0,0,0.102)").ss(2, 0, 0, 4).p("AAAobIAAQ3");
        this.shape_96.setTransform(565.8, 492.1, 0.855, 0.855);

        this.shape_97 = new cjs.Shape();
        this.shape_97.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAobIAAQ3");
        this.shape_97.setTransform(611.3, 492.1, 0.855, 0.855);

        this.shape_98 = new cjs.Shape();
        this.shape_98.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAoeIAAQ9");
        this.shape_98.setTransform(656.3, 491.9, 0.855, 0.855);

        this.shape_99 = new cjs.Shape();
        this.shape_99.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAoYIAAQx");
        this.shape_99.setTransform(701.4, 491.9, 0.855, 0.855);

        this.shape_100 = new cjs.Shape();
        this.shape_100.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAoeIAAQ9");
        this.shape_100.setTransform(745.9, 492.4, 0.855, 0.855);

        this.shape_101 = new cjs.Shape();
        this.shape_101.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAobIAAQ3");
        this.shape_101.setTransform(790.9, 492.1, 0.855, 0.855);

        this.shape_102 = new cjs.Shape();
        this.shape_102.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAohIAARD");
        this.shape_102.setTransform(836.9, 492.6, 0.855, 0.855);

        this.shape_103 = new cjs.Shape();
        this.shape_103.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAA4yMAAAAxl");
        this.shape_103.setTransform(837.2, 295.5, 0.855, 0.855);

        this.shape_104 = new cjs.Shape();
        this.shape_104.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAA41MAAAAxr");
        this.shape_104.setTransform(791.4, 296.2, 0.855, 0.855);

        this.shape_105 = new cjs.Shape();
        this.shape_105.graphics.f().s("rgba(0,0,0,0.102)").ss(2, 0, 0, 4).p("AAA4yMAAAAxl");
        this.shape_105.setTransform(746.3, 295.5, 0.855, 0.855);

        this.shape_106 = new cjs.Shape();
        this.shape_106.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAA4sMAAAAxZ");
        this.shape_106.setTransform(701.8, 296, 0.855, 0.855);

        this.shape_107 = new cjs.Shape();
        this.shape_107.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAA4vMAAAAxf");
        this.shape_107.setTransform(655.4, 295.2, 0.855, 0.855);

        this.shape_108 = new cjs.Shape();
        this.shape_108.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAwYMAAAAgx");
        this.shape_108.setTransform(610.5, 340.9, 0.855, 0.855);

        this.shape_109 = new cjs.Shape();
        this.shape_109.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAwhMAAAAhD");
        this.shape_109.setTransform(565.3, 340.7, 0.855, 0.855);

        this.shape_110 = new cjs.Shape();
        this.shape_110.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAweMAAAAg9");
        this.shape_110.setTransform(521.3, 341.5, 0.855, 0.855);

        this.shape_111 = new cjs.Shape();
        this.shape_111.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAwkMAAAAhJ");
        this.shape_111.setTransform(475.3, 340.5, 0.855, 0.855);

        this.shape_112 = new cjs.Shape();
        this.shape_112.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAwbMAAAAg3");
        this.shape_112.setTransform(430.8, 340.2, 0.855, 0.855);

        this.shape_113 = new cjs.Shape();
        this.shape_113.graphics.f().s("rgba(0,0,0,0.102)").ss(2, 0, 0, 4).p("AAAweMAAAAg9");
        this.shape_113.setTransform(385.8, 340.5, 0.855, 0.855);

        this.shape_114 = new cjs.Shape();
        this.shape_114.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAwbMAAAAg3");
        this.shape_114.setTransform(341.3, 341.2, 0.855, 0.855);

        this.shape_115 = new cjs.Shape();
        this.shape_115.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAwbMAAAAg3");
        this.shape_115.setTransform(295.8, 340.2, 0.855, 0.855);

        this.shape_116 = new cjs.Shape();
        this.shape_116.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAwVMAAAAgr");
        this.shape_116.setTransform(250.8, 340.7, 0.855, 0.855);

        this.shape_117 = new cjs.Shape();
        this.shape_117.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("AAAwbMAAAAg3");
        this.shape_117.setTransform(205.8, 340.7, 0.855, 0.855);

        this.shape_118 = new cjs.Shape();
        this.shape_118.graphics.f().s("rgba(0,0,0,0.098)").ss(2, 0, 0, 4).p("AAA4vMAAAAxf");
        this.shape_118.setTransform(114.1, 295.7, 0.855, 0.855);

        this.shape_119 = new cjs.Shape();
        this.shape_119.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAwcMAAAAg5");
        this.shape_119.setTransform(160.3, 340.6, 0.855, 0.855);

        this.shape_120 = new cjs.Shape();
        this.shape_120.graphics.f().s("#000000").ss(4, 0, 0, 4).p("EBKFgciMAAAA5lMiUJAAAMgABg6FIINAAIAAImIIcAAIAAQkMBSNAAAIAAwkMApOAAAIAAoGg");
        this.shape_120.setTransform(475.6, 271.9, 0.855, 0.855);

        this.shape_121 = new cjs.Shape();
        this.shape_121.graphics.f().s("rgba(0,0,0,0.2)").ss(2, 0, 0, 4).p("Eg50AAAMBzpAAA");
        this.shape_121.setTransform(566.5, 491.4, 0.855, 0.855);

        this.shape_122 = new cjs.Shape();
        this.shape_122.graphics.f().s("#000000").ss(4, 0, 0, 4).p("EA5rAIcMhzVAAAIAAw3MBzVAAAg");
        this.shape_122.setTransform(566.4, 492.3, 0.855, 0.855);

        // COLORES
        this.shape_123 = new cjs.Shape();
        this.shape_123.graphics.f("#FFE4C2").s().p("AkBEEIAAoHIIDAAIAAIHg");
        this.shape_123.setTransform(859.4, 138.1, 0.855, 0.855);

        this.shape_124 = new cjs.Shape();
        this.shape_124.graphics.f("#96B3BD").s().p("EgpEAQjMAAAghGMBSJAAAMAAAAhGg");
        this.shape_124.setTransform(385.1, 341.1, 0.855, 0.855);

        this.shape_125 = new cjs.Shape();
        this.shape_125.graphics.f("#E7A479").s().p("A4wYzMAAAgxlMAxhAAAMAAAAxlg");
        this.shape_125.setTransform(746.1, 295.7, 0.855, 0.855);

        this.shape_126 = new cjs.Shape();
        this.shape_126.graphics.f("#FFE4C2").s().p("AoRdAMgAEg6EIIUAFIgEIiIIbAJMgAOAxZg");
        this.shape_126.setTransform(115.3, 271.7, 0.855, 0.855);

        this.shape_127 = new cjs.Shape();
        this.shape_127.graphics.f("#FFDE8D").s().p("Eg5xAIZIAAwxMBzjAAAIAAQxg");
        this.shape_127.setTransform(567, 492.3, 0.855, 0.855);

        // Capa 1
        this.shape_128 = new cjs.Shape();
        this.shape_128.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape_128.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape_128, this.shape_127, this.shape_126, this.shape_125, this.shape_124, this.shape_123, this.shape_122, this.shape_121, this.shape_120, this.shape_119, this.shape_118, this.shape_117, this.shape_116, this.shape_115, this.shape_114, this.shape_113, this.shape_112, this.shape_111, this.shape_110, this.shape_109, this.shape_108, this.shape_107, this.shape_106, this.shape_105, this.shape_104, this.shape_103, this.shape_102, this.shape_101, this.shape_100, this.shape_99, this.shape_98, this.shape_97, this.shape_96, this.shape_95, this.shape_94, this.shape_93, this.shape_92, this.shape_91, this.shape_90, this.shape_89, this.shape_88, this.shape_87, this.shape_86, this.shape_85, this.shape_84, this.shape_83, this.shape_82, this.shape_81, this.text_23, this.text_22, this.text_21, this.text_20, this.shape_80, this.shape_79, this.shape_78, this.shape_77, this.shape_76, this.shape_75, this.shape_74, this.shape_73, this.shape_72, this.text_19, this.text_18, this.text_17, this.text_16, this.text_15, this.text_14, this.text_13, this.text_12, this.shape_71, this.shape_70, this.shape_69, this.shape_68, this.shape_67, this.shape_66, this.shape_65, this.shape_64, this.shape_63, this.shape_62, this.shape_61, this.shape_60, this.shape_59, this.shape_58, this.shape_57, this.shape_56, this.shape_55, this.shape_54, this.shape_53, this.shape_52, this.shape_51, this.shape_50, this.shape_49, this.shape_48, this.shape_47, this.shape_46, this.shape_45, this.shape_44, this.shape_43, this.shape_42, this.shape_41, this.shape_40, this.shape_39, this.shape_38, this.shape_37, this.shape_36, this.shape_35, this.shape_34, this.shape_33, this.shape_32, this.shape_31, this.shape_30, this.shape_29, this.shape_28, this.shape_27, this.shape_26, this.shape_25, this.shape_24, this.shape_23, this.shape_22, this.shape_21, this.shape_20, this.shape_19, this.shape_18, this.shape_17, this.shape_16, this.shape_15, this.shape_14, this.shape_13, this.shape_12, this.text_11, this.text_10, this.text_9, this.text_8, this.text_7, this.text_6, this.text_5, this.shape_11, this.shape_10, this.shape_9, this.shape_8, this.text_4, this.shape_7, this.shape_6, this.shape_5, this.shape_4, this.text_3, this.text_2, this.text_1, this.text, this.shape_3, this.shape_2, this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_07 = function () {
        this.initialize();

        // Capa 3
        this.text = new cjs.Text("Subniveles de Schrödinger", "20px Verdana");
        this.text.lineHeight = 21;
        this.text.lineWidth = 320;
        this.text.setTransform(368, 506.9);

        this.text_1 = new cjs.Text("Niveles de energía de Böhr", "20px Verdana");
        this.text_1.lineHeight = 21;
        this.text_1.lineWidth = 320;
        this.text_1.setTransform(348, 54.9);

        // Capa 4
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("A4cC5IAAlwMAw4AAAIAAFwg");
        this.shape.setTransform(507.5, 525.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("A2uDNIAAmZMAtcAAAIAAGZg");
        this.shape_1.setTransform(484.5, 68.5);

        // Capa 2
        this.instance = new lib.FQ_10_11_023();
        this.instance.setTransform(225.3, 53.4);

        // Capa 1
        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape_2.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape_2, this.instance, this.shape_1, this.shape, this.text_1, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_05 = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib.FQ_10_11_022();
        this.instance.setTransform(224.3, 54.4);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_04 = function () {
        this.initialize();

        // Capa 2
        this.text = new cjs.Text("137,3", "10px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 11;
        this.text.lineWidth = 30;
        this.text.setTransform(511.9, 482.8);

        this.text_1 = new cjs.Text("132,9", "10px Verdana");
        this.text_1.textAlign = "center";
        this.text_1.lineHeight = 11;
        this.text_1.lineWidth = 30;
        this.text_1.setTransform(458.7, 482.8);

        this.text_2 = new cjs.Text("87,62", "10px Verdana");
        this.text_2.textAlign = "center";
        this.text_2.lineHeight = 11;
        this.text_2.lineWidth = 30;
        this.text_2.setTransform(511.9, 410.1);

        this.text_3 = new cjs.Text("85,47", "10px Verdana");
        this.text_3.textAlign = "center";
        this.text_3.lineHeight = 11;
        this.text_3.lineWidth = 30;
        this.text_3.setTransform(458.7, 410.1);

        this.text_4 = new cjs.Text("40,08", "10px Verdana");
        this.text_4.textAlign = "center";
        this.text_4.lineHeight = 11;
        this.text_4.lineWidth = 30;
        this.text_4.setTransform(511.9, 337.5);

        this.text_5 = new cjs.Text("39,10", "10px Verdana");
        this.text_5.textAlign = "center";
        this.text_5.lineHeight = 11;
        this.text_5.lineWidth = 30;
        this.text_5.setTransform(458.7, 337.5);

        this.text_6 = new cjs.Text("24,31", "10px Verdana");
        this.text_6.textAlign = "center";
        this.text_6.lineHeight = 11;
        this.text_6.lineWidth = 30;
        this.text_6.setTransform(511.9, 255.1);

        this.text_7 = new cjs.Text("22,99", "10px Verdana");
        this.text_7.textAlign = "center";
        this.text_7.lineHeight = 11;
        this.text_7.lineWidth = 30;
        this.text_7.setTransform(458.7, 255.1);

        this.text_8 = new cjs.Text("9,012", "10px Verdana");
        this.text_8.textAlign = "center";
        this.text_8.lineHeight = 11;
        this.text_8.lineWidth = 30;
        this.text_8.setTransform(511.9, 192.8);

        this.text_9 = new cjs.Text("6,941", "10px Verdana");
        this.text_9.textAlign = "center";
        this.text_9.lineHeight = 11;
        this.text_9.lineWidth = 30;
        this.text_9.setTransform(458.7, 192.8);

        this.text_10 = new cjs.Text("1,008", "10px Verdana");
        this.text_10.textAlign = "center";
        this.text_10.lineHeight = 11;
        this.text_10.lineWidth = 30;
        this.text_10.setTransform(458.7, 120.1);

        // Layer 1
        this.text_11 = new cjs.Text("II", "bold 20px Verdana");
        this.text_11.lineHeight = 21;
        this.text_11.lineWidth = 100;
        this.text_11.setTransform(499, 113.9);

        this.text_12 = new cjs.Text("I", "bold 20px Verdana");
        this.text_12.lineHeight = 21;
        this.text_12.lineWidth = 100;
        this.text_12.setTransform(452, 41.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000000").s().p("Ag9D/QBNhtAAiSQAAiShNhtIArAAQBQBqAACVQAACShQBtg");
        this.shape.setTransform(524.2, 562.7, 0.185, 0.185);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("AhjCjQgngvAAhQQAAg4ATgxQASgtAfggQA0gyBNgKQAUgDAUAAIAAAtQgUgBgVADQg8ALgmAqQgjAmgHA3IACAAQAQgVAXgNQAbgOAeAAQA3AAAiAkQAiAjAAA7QAAA7gkApQgmAsg9AAQhAAAgngvgAgtgIQgVAMgMAWQgGALAAAOQABA0AXAfQAYAhAoAAIAAAAQAkAAAVgbQAWgbAAgrQAAgsgXgZQgWgXgmAAQgXAAgWAOg");
        this.shape_1.setTransform(519.8, 562.3, 0.185, 0.185);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBVhRAcgoQAkgvABgrQAAgkgSgUQgVgZgpABQgrAAgrAiIgSgnQAygpBCAAQA7AAAiAlQAdAhAAAwQABA1gmA1QgeAphHBHIggAeIAAABIC0AAIAAAug");
        this.shape_2.setTransform(513.9, 562.2, 0.185, 0.185);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBUhRAcgoQAlgvABgrQgBgkgRgUQgVgZgoABQgtAAgqAiIgSgnQAxgpBCAAQA8AAAiAlQAdAhABAwQgBA1glA1QgeAphHBHIggAeIAAABIC0AAIAAAug");
        this.shape_3.setTransform(507.9, 562.2, 0.185, 0.185);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#000000").s().p("AATD/QhQhsAAiSQABiSBPhuIArAAQhNBsAACUQAACOBNBwg");
        this.shape_4.setTransform(503.6, 562.7, 0.185, 0.185);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#000000").s().p("AiFDtQgxgpAAg+QAAgzAdglQAcgkAzgUIgBgDQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgWAkgvAWIAAADQA0ASAcAkQAdAkAAAxQAABGg2AtQg0ArhNAAQhSAAgzgsgAhSA3QgZAdAAAoQgCArAeAdQAfAgAwAAQAxAAAegcQAegbAAgrQAAgvgggdQgdgag5gRQgvAOgaAegAhDjJQgYAYAAAlQAABJBlAbQAlgMAWgYQAYgbAAgkQAAgkgVgYQgZgcguAAQgqAAgaAag");
        this.shape_5.setTransform(505.9, 514.7, 0.185, 0.185);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#000000").s().p("AiFDtQgxgpAAg+QAAgzAdglQAbgkA0gUIgBgDQgrgUgXgiQgUgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkgvAWIAAADQA0ATAcAjQAeAkAAAxQAABGg2AtQg0ArhNAAQhSAAgzgsgAhSA3QgZAdAAAoQgCArAeAdQAfAgAwAAQAxAAAegcQAdgbAAgrQAAgvgggdQgcgag5gRQgvAOgaAegAhDjJQgZAYAAAlQAABJBmAbQAlgMAWgYQAYgbAAgkQAAgkgVgYQgZgcguAAQgqAAgaAag");
        this.shape_6.setTransform(498, 514.7, 0.185, 0.185);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f("#000000").s().p("AjBEHQgvgxAAhHQAAhvBeg4QBfg6CtAAIAAgNQAAg3gWghQgig0hPAAQgqAAgrAMQgpAMghAVIgZhIQAngaAzgOQA1gOA3gBQB/AAA5BPQAuA+AABsIAADiQAABaAKA3IhkAAIgJhMIgDAAQgcAngtAYQg0Acg7AAQhXgBgzg2gAgvAQQhTAiAABQQAAAzAfAdQAcAaAtAAQA1AAApgfQAkgcAPgrQAGgWAAgOIAAhnIgTAAQhhAAg4AVg");
        this.shape_7.setTransform(519.8, 540.6, 0.185, 0.185);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#000000").s().p("ACiGqQgSgggniqQgShYgmglQgnglhIgDIhmAAIAAFvIhtAAIAAtCQBTgRB+AAQBVAAA7AQQA7ARAnAkQAgAcARAqQARAqAAAxQAABQguA7QgqA1hHAWIAAAEQBdAgAfCLQAYBnANAtQAQA+AMAWgAiklLIAAE1IBvAAQBVAAA0gsQAzgsAAhJQAAhPg2goQgxgmhZgBQhIAAgjAKg");
        this.shape_8.setTransform(508.6, 538.3, 0.185, 0.185);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_9.setTransform(513.6, 538, 0.185, 0.185);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f("#000000").s().p("AiEDaQg1g/AAhqQAAhMAahBQAYg9AqgqQBFhEBngMQAbgFAaAAIAAA9QgXgCggAFQhQAOgzA4QguAzgKBJIADAAQAVgcAggRQAjgSApAAQBIAAAuAwQAuAvAABPQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAPAAASQABBGAeAqQAgAsA2AAIABAAQAvAAAdgkQAdglAAg6QAAg6geghQgegggzAAQgfAAgdATg");
        this.shape_10.setTransform(505.9, 442.2, 0.185, 0.185);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAVAMAbAIQAiAKAjAAQAzAAAlggQAmghAAg1QgBg3glggQgpgghMAAQgaAAgxAGIAjkFIEDAAIAAA9IjOAAIgUCMQAVgDAWAAQBEAAAvAeQAjATAUAgQAXAmAAAxQAABQg4A0Qg6A1hWAAQgqAAgmgKg");
        this.shape_11.setTransform(497.8, 442.2, 0.185, 0.185);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f("#000000").s().p("AjCEHQgugxAAhHQAAhuBfg5QBeg6CtABIAAgNQAAg3gWgiQgig0hQAAQgqAAgpAMQgqAMggAVIgZhJQAmgZA0gOQA1gPA2AAQB+AAA7BPQAtA+AABsIAADiQAABaAKA4IhkAAIgJhNIgEAAQgcAngtAYQgzAcg7AAQhXAAg0g3gAguARQhUAhAABQQAAAzAfAdQAcAaAtAAQA1AAAqggQAjgbAOgrQAHgVAAgOIAAhoIgTAAQhhAAg3AWg");
        this.shape_12.setTransform(519.7, 468.1, 0.185, 0.185);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f("#000000").s().p("AkJGkIAAtAQBTgRB0AAQBQAAA4AOQA3APAnAgQBGA1AABhQABA+gmAxQgnAyhDAZIAAACQBHASAuAvQA5A8AABWQAABlhGBFQhXBPjMAAQhgAAhJgKgAicFTQAbAFBBABQBcgBA4gjQBDgrAAhWQAAhThBgqQg5gnhfAAIhaAAgAiclRIAAEQIBjAAQBTAAAygoQAwgnAAg/QAAhHgzgjQgvgghVAAQg7AAgmAIg");
        this.shape_13.setTransform(508.6, 465.9, 0.185, 0.185);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_14.setTransform(513.6, 465.5, 0.185, 0.185);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f("#000000").s().p("AiFDtQgxgpAAg+QAAgzAdglQAbgkA0gUIgBgDQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkgvAWIAAADQA0ATAcAiQAeAlAAAxQAABGg2AsQg0AshNAAQhSAAgzgsgAhSA3QgZAdAAAoQgCArAeAdQAfAgAwAAQAxAAAegcQAdgbAAgrQAAgvgggdQgcgag5gRQgvAOgaAegAhDjJQgZAYAAAlQAABJBmAbQAlgMAWgZQAYgaAAgkQAAgkgVgYQgZgcguAAQgqAAgaAag");
        this.shape_15.setTransform(505.9, 369.7, 0.185, 0.185);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f("#000000").s().p("AhvENQgjgKgWgPIAUg5QAUANAdAKQAkAMAjAAQA+AAAhgkQAbgdgBgpQAAg2gsgdQgmgag5AAIgoAAIAAg1IAoAAQAuAAAhgWQApgaAAgtQAAgjgXgWQgZgZguAAQgeAAgfAMQgaAKgVAOIgTg1QAXgRAlgMQApgNApAAQBJAAArAoQAlAkAAA2QAAArgZAhQgaAigxASIAAACQA1AKAgAiQAkAnAAA3QAABFgyAtQg2AxhcAAQgqAAgqgMg");
        this.shape_16.setTransform(497.8, 369.7, 0.185, 0.185);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f("#000000").s().p("AiSE3IAAmhQAAh1gFhJIBhAAIADB3IAFAAQAVg9AsgkQAugkA4AAQAQAAAOAEIAABoQgRgEgUAAQg5AAgoAoQglAngMBAQgFAeAAAVIAAFDg");
        this.shape_17.setTransform(519.9, 395.5, 0.185, 0.185);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f("#000000").s().p("AigGlQg7gQgjgXIAchcQAnAZAxAOQA2AQA1AAQBQAAAwgoQAugnAAhBQAAg7gkgnQglglhTgiQhtgkg2g4Qg9g8ABhWQAAhkBKhBQBNhBB3AAQBzAABIAqIgeBZQhIgphYAAQhOABgrAqQgkAjAAAxQAAA6AoAlQAkAhBaAkQBuArAzA1QA2A9AABaQAABohJBDQhQBKiMAAQg8AAg+gQg");
        this.shape_18.setTransform(509.8, 393.5, 0.185, 0.185);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_19.setTransform(513.6, 393.1, 0.185, 0.185, 0, 0, 0, 0, 0.2);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f("#000000").s().p("AiEDRQgyhLgBiFQAAiEA1hMQAzhJBTAAQBVAAAwBJQAvBIAACDQAACIgyBLQgxBKhYAAQhRAAgwhIgAhOilQgfA9AABqQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhogag5Qgdg9g3AAQgwAAgeA6g");
        this.shape_20.setTransform(505.8, 297.2, 0.185, 0.185);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.f("#000000").s().p("AisEVIAAgtIA6g5QBwhrAmg2QAxg/ABg7QAAgugYgcQgbggg3AAQg8AAg3AuIgYg1QBCg3BYAAQBQAAAtAzQAnArAABBQAABFgyBHQgnA4hgBeIgrApIAAACIDyAAIAAA9g");
        this.shape_21.setTransform(497.8, 297.1, 0.185, 0.185);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f("#000000").s().p("AjBEHQgvgxAAhHQAAhuBeg5QBfg6CtABIAAgNQAAg3gWgjQgigzhPAAQgqAAgqAMQgqAMggAWIgZhJQAmgaA0gOQA1gOA2AAQB/AAA6BOQAtA+AABsIAADiQAABbAKA3IhkAAIgJhNIgDAAQgcAngtAYQg0Abg7AAQhXAAgzg2gAiCCDQAAAyAfAdQAcAaAtAAQA2AAApgfQAjgdAPgqQAGgTAAgQIAAhoIgTAAQjsAAAACIg");
        this.shape_22.setTransform(520.5, 323.2, 0.185, 0.185);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.f("#000000").s().p("AjHFGQh4h0AAjLQAAjFB7h7QB5h7DDAAQBGAAA7ANQAsAKAbAPIgaBZQhIgjhiAAQiVAAhZBbQhaBeAACjQAACcBVBbQBXBdCWAAQAyAAAwgKQAwgJAhgQIAWBWQgiARg2AMQg/ANhIAAQi2AAhxhvg");
        this.shape_23.setTransform(508.7, 321, 0.185, 0.185);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_24.setTransform(513.6, 320.6, 0.185, 0.185, 0, 0, 0, 0, 0.2);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.f("#000000").s().p("AisEUIAAgtIA6g4QBxhsAlg1QAxg/ABg7QAAgvgYgbQgbghg3AAQg7AAg4AuIgYgzQBCg3BYAAQBQgBAtAyQAnAsAABBQAABGgyBGQgnA4hgBfIgrAoIAAABIDyAAIAAA9g");
        this.shape_25.setTransform(504.8, 224.6, 0.185, 0.185);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_26.setTransform(496.3, 224.7, 0.185, 0.185);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.f("#000000").s().p("AiJGtQg4gOgkgXIAchUQAhAUAqANQAyAOA1AAQBYABAxgxQA4g3AAhtIAAhEIgDAAQgbAuguAaQg0AehBAAQhxAAhJhVQhIhVgBh9QABiTBUhbQBOhVBuAAQBHAAA0AiQApAbAYAsIADAAIAEhbIBgAAQgEBYgBBPIAAFgQABBogWBDQgUBCgsApQhPBIiMAAQg4AAg2gNgAh4kkQgyA/AABpQAABeAtA6QAxBABTABQA0gBApgdQAqgfASgzQAJgaAAggIAAhuQAAgegGgVQgRgzgmgeQgqgjg5AAQhOAAgzA+g");
        this.shape_27.setTransform(523, 250.5, 0.185, 0.185);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f("#000000").s().p("AFEGnIgVl0QgOj+ABhuIgEAAQguCeg8CiIiVGbIhRAAIiImUQhDjFgfiCIgDAAQgECtgMDIIgWFrIhoAAIA7tNICLAAICQGaQA6CsAbBvIACAAQAbhvA9isICXmaICLAAIA0NNg");
        this.shape_28.setTransform(507.6, 246, 0.185, 0.185);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_29.setTransform(513.6, 248, 0.185, 0.185);

        this.shape_30 = new cjs.Shape();
        this.shape_30.graphics.f("#000000").s().p("AA1EQIAAiUIj6AAIAAgxIDwlaIBPAAIAAFQIBMAAIAAA7IhMAAIAACUgAAIh4IiDC4IAAABICwAAIAAizQAAgnACgvIgCAAQgUAngZApg");
        this.shape_30.setTransform(498, 151.6, 0.185, 0.185);

        this.shape_31 = new cjs.Shape();
        this.shape_31.graphics.f("#000000").s().p("Ai7DpQhPhUAAiMQAAiLBMhbQBPhgCAAAQCEAABDBmQAzBOAABrQAAAVgEAdImoAAQACBqA+A3QA3AyBXAAQA3AAArgJQAjgIAjgPIATBQQhXAnhzAAQiJAAhQhVgAhyiwQgmAxgHBFIFAAAQAAhEgegwQgpg/hSAAQhKAAgwA9g");
        this.shape_31.setTransform(519.8, 178.1, 0.185, 0.185);

        this.shape_32 = new cjs.Shape();
        this.shape_32.graphics.f("#000000").s().p("AkIGkIAAs/QBVgSBxAAQBQAAA3APQA3AOAoAhQBHA0AABhQAAA+gnAyQgmAyhCAYIAAADQBFARAwAvQA4A8AABWQAABlhHBFQhWBPjLAAQhiAAhHgKgAicFUQAbAFBBAAQBcAAA4gkQBCgrAAhWQAAhShAgrQg6gmheAAIhaAAgAiclRIAAERIBjAAQBTAAAygpQAwgnAAg+QAAhIgzgjQgvgghVAAQg7AAgmAIg");
        this.shape_32.setTransform(508, 175.9, 0.185, 0.185);

        this.shape_33 = new cjs.Shape();
        this.shape_33.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_33.setTransform(513.6, 175.5, 0.185, 0.185, 0, 0, 0, 0, 0.1);

        this.shape_34 = new cjs.Shape();
        this.shape_34.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhuIArAAQBQBqAACVQAACThQBsg");
        this.shape_34.setTransform(471.2, 562.7, 0.185, 0.185);

        this.shape_35 = new cjs.Shape();
        this.shape_35.graphics.f("#000000").s().p("AhSDKQgagIgSgLIAQgrQAOAKAWAHQAcAJAaAAQAuAAAZgbQAUgWgBgeQgBgogggWQgdgUgpAAIgfAAIAAgnIAfAAQAhAAAZgRQAfgTAAghQAAgbgRgQQgTgTgiAAQgXAAgXAJQgUAHgPALIgPgoQASgNAbgJQAfgKAfAAQA2AAAgAeQAcAbAAApQAAAggSAZQgUAaglANIAAABQAoAIAYAZQAbAdAAApQAAA0gmAiQgpAlhEAAQgfAAgfgJg");
        this.shape_35.setTransform(466.7, 562.3, 0.185, 0.185);

        this.shape_36 = new cjs.Shape();
        this.shape_36.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBVhRAbgoQAlgvAAgrQAAgjgRgVQgVgYgpAAQgrAAgrAiIgRgnQAxgpBCAAQA7AAAiAlQAeAhgBAxQABA0gnA1QgcAphIBHIghAeIAAABIC1AAIAAAug");
        this.shape_36.setTransform(460.9, 562.2, 0.185, 0.185);

        this.shape_37 = new cjs.Shape();
        this.shape_37.graphics.f("#000000").s().p("AiBDPIAAgiIArgqQBVhRAcgoQAkgvABgrQAAgjgRgVQgWgYgnAAQguAAgpAiIgSgnQAygpBBAAQA8AAAiAlQAdAhABAxQAAA0gmA1QgeAphHBHIggAeIAAABIC0AAIAAAug");
        this.shape_37.setTransform(455, 562.2, 0.185, 0.185);

        this.shape_38 = new cjs.Shape();
        this.shape_38.graphics.f("#000000").s().p("AATD/QhQhsAAiSQABiSBPhuIArAAQhNBqAACWQAACOBNBwg");
        this.shape_38.setTransform(450.7, 562.7, 0.185, 0.185);

        this.shape_39 = new cjs.Shape();
        this.shape_39.graphics.f("#000000").s().p("AiMEQIDqngIAAgBIkIAAIAAg+IFVAAIAAAxIjrHug");
        this.shape_39.setTransform(453.1, 514.7, 0.185, 0.185);

        this.shape_40 = new cjs.Shape();
        this.shape_40.graphics.f("#000000").s().p("AiFDtQgxgpAAg+QAAgzAdglQAcgkAzgUIgBgDQgrgUgWgiQgVgfAAglQAAhAAxgpQAvgoBGAAQBKAAAsApQAoAmAAA3QAAAmgTAfQgYAkguAWIAAADQA0ATAcAiQAdAlAAAxQAABGg2AsQg0AshNAAQhTAAgygsgAhSA3QgZAdABAoQgDArAeAdQAeAgAxAAQAxAAAegcQAegbAAgrQgBgvgggdQgcgag5gRQgvAOgaAegAhDjKQgYAZgBAlQABBJBlAbQAlgMAWgZQAYgaAAgkQgBgkgUgZQgZgcguAAQgqAAgaAag");
        this.shape_40.setTransform(445.1, 514.7, 0.185, 0.185);

        this.shape_41 = new cjs.Shape();
        this.shape_41.graphics.f("#000000").s().p("AiRE3IAAmhQAAhtgGhRIBhAAIADB3IAFAAQAVg9AsgkQAugkA4AAQAQAAAOAEIAABoQgRgEgUAAQg5AAgoAoQglAngLBAQgGAeABAVIAAFDg");
        this.shape_41.setTransform(466.2, 540.5, 0.185, 0.185);

        this.shape_42 = new cjs.Shape();
        this.shape_42.graphics.f("#000000").s().p("AjiGnIAAtNIHFAAIAABbIlYAAIAAEaIE9AAIAABZIk9AAIAAF/g");
        this.shape_42.setTransform(457.1, 538.5, 0.185, 0.185);

        this.shape_43 = new cjs.Shape();
        this.shape_43.graphics.f("#000000").s().p("AhwEKQghgJgWgOIASg4QAUAMAcAIQAiAKAiAAQA0AAAlggQAmghAAg1QgBg4glgfQgogghMAAQgbAAgwAGIAjkGIEBAAIAAA+IjNAAIgVCMQAdgDAQAAQBBAAAyAdQAiAUAUAgQAXAmAAAwQAABQg5A1Qg5A2hWAAQgpAAgngLg");
        this.shape_43.setTransform(452.7, 442.1, 0.185, 0.185);

        this.shape_44 = new cjs.Shape();
        this.shape_44.graphics.f("#000000").s().p("AhwEKQghgJgWgOIASg4QAUAMAcAIQAjAKAhAAQA0AAAlggQAmghAAg1QgBg4glgfQgpgghLAAQgbAAgxAGIAjkGIEDAAIAAA+IjOAAIgUCMQAcgDAQAAQBBAAAyAdQAiAUAUAgQAXAmAAAwQAABRg4A0Qg6A2hWAAQgqAAgmgLg");
        this.shape_44.setTransform(444.8, 442.1, 0.185, 0.185);

        this.shape_45 = new cjs.Shape();
        this.shape_45.graphics.f("#000000").s().p("Ah5EyQgrgMghgTIAbhVQAcASAkAMQArAOAmAAQA5AAAegaQAdgYAAgoQAAgngZgZQgagZg7gXQhRgdgpgqQgmgrgBg4QABhMA3gyQA6g1BdAAQAsAAAqAMQAjAJAdARIgcBQQg4gjhEAAQgtAAgcAZQgbAXABAjQAAAkAcAXQAYAUA9AYQBRAgAmAnQAoAtAABCQAABSg7AyQg+A0hoAAQgwAAgugMg");
        this.shape_45.setTransform(467.7, 468.2, 0.185, 0.185);

        this.shape_46 = new cjs.Shape();
        this.shape_46.graphics.f("#000000").s().p("AjIFGQh3h0AAjLQAAjFB6h7QB6h7DCAAQBHAAA6ANQAsAKAcAPIgbBZQhHgjhjAAQiUAAhYBbQhbBeAACiQAACdBVBbQBXBdCXAAQAxAAAwgKQAvgJAhgQIAWBXQghARg3ALQg/ANhHAAQi2AAhyhvg");
        this.shape_46.setTransform(456.5, 466, 0.185, 0.185);

        this.shape_47 = new cjs.Shape();
        this.shape_47.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_47.setTransform(460.9, 466, 0.185, 0.185);

        this.shape_48 = new cjs.Shape();
        this.shape_48.graphics.f("#000000").s().p("AiMEQIDqngIAAgCIkIAAIAAg9IFVAAIAAAxIjrHug");
        this.shape_48.setTransform(453, 369.7, 0.185, 0.185);

        this.shape_49 = new cjs.Shape();
        this.shape_49.graphics.f("#000000").s().p("AhuENQgjgKgXgPIAUg5QATANAeAKQAlAMAiAAQA/AAAggkQAbgdgBgpQAAg2gsgdQgmgag4AAIgpAAIAAg1IApAAQAtAAAhgWQApgaAAgtQAAgjgWgWQgagZgtAAQgeAAggAMQgbAKgUAOIgTg1QAXgRAlgMQApgNApAAQBJAAArAoQAlAkAAA2QAAArgZAhQgaAigxASIAAACQA1AKAhAiQAjAnAAA3QAABFgyAtQg2AxhcAAQgqAAgpgMg");
        this.shape_49.setTransform(444.8, 369.7, 0.185, 0.185);

        this.shape_50 = new cjs.Shape();
        this.shape_50.graphics.f("#000000").s().p("Ai4FSIgDAAIgFBlIhgAAQAFhTAAhKIAAreIBtAAIAAF+IADAAQAeg0AzgdQA2gfBFAAQByAABHBWQBIBXgBCIQAACahVBbQhNBRhuAAQiJAAhAhzgAhng5QgwAlgQA8QgHAbAAASIAABuQAAAPAFAZQARA6AsAkQAtAkA8AAQBTAAAyhBQAxg/AAhqQAAhhgug8QgyhEhTAAQg5AAguAlg");
        this.shape_50.setTransform(467.2, 393.5, 0.185, 0.185);

        this.shape_51 = new cjs.Shape();
        this.shape_51.graphics.f("#000000").s().p("ACiGqQgSgggniqQgShYgmglQgnglhIgDIhmAAIAAFvIhtAAIAAtCQBTgRB+AAQBVAAA7AQQA6ARAoAkQAgAcARAqQARApAAAyQAABQguA7QgqA1hHAWIAAAEQBdAgAfCLQAYBnANAtQAQA+AMAWgAiklLIAAE1IBvAAQBVAAA0gsQAzgsAAhJQAAhPg2goQgxgmhZgBQhIAAgjAKg");
        this.shape_51.setTransform(454.4, 393.7, 0.185, 0.185);

        this.shape_52 = new cjs.Shape();
        this.shape_52.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_52.setTransform(460.9, 393.5, 0.185, 0.185);

        this.shape_53 = new cjs.Shape();
        this.shape_53.graphics.f("#000000").s().p("AiHEZIAAg8QATACAogFQBEgJArgsQA6g1AOhcIgCAAQgwA7hOAAQhIAAgsgxQgsgtAAhHQAAhQAzg4QA1g6BQAAQBSAAAxA/QAwA+AABpQAABTgaBEQgZA9grAqQgeAegqATQgnASgsAGQgeAEgZAAIgNAAgAhPi6QgeAlAAA6QABAzAcAgQAdAfAvAAQAiAAAdgRQAbgNAPgZQAGgMAAgPQABhKgbgrQgdgwg1AAIgBAAQguAAgfAmg");
        this.shape_53.setTransform(452, 297.2, 0.185, 0.185);

        this.shape_54 = new cjs.Shape();
        this.shape_54.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_54.setTransform(443.4, 297.2, 0.185, 0.185);

        this.shape_55 = new cjs.Shape();
        this.shape_55.graphics.f("#000000").s().p("ACpGnIkUmgIhRBdIAAFDIhtAAIAAtNIBtAAIAAGYIAEAAQAhgvAigrIEAk+ICHAAIkwFnIFIHmg");
        this.shape_55.setTransform(460.9, 321, 0.185, 0.185);

        this.shape_56 = new cjs.Shape();
        this.shape_56.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_56.setTransform(460.9, 321, 0.185, 0.185);

        this.shape_57 = new cjs.Shape();
        this.shape_57.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg5IB0g/IA/AAIAAIfg");
        this.shape_57.setTransform(451.3, 224.5, 0.185, 0.185);

        this.shape_58 = new cjs.Shape();
        this.shape_58.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg5IB1g/IA+AAIAAIfg");
        this.shape_58.setTransform(443.4, 224.5, 0.185, 0.185);

        this.shape_59 = new cjs.Shape();
        this.shape_59.graphics.f("#000000").s().p("AjCEIQgugyAAhHQAAhuBeg4QBeg7CuAAIAAgMQAAg3gWgjQgigzhQAAQgpAAgrANQgpAMggAUIgahJQAngZAzgOQA2gPA2AAQB/AAA5BPQAuA/AABrIAADiQAABbAKA3IhkAAIgJhNIgEAAQgcAngtAYQgzAcg7AAQhXgBg0g1gAiCCCQAAAzAfAdQAcAaAtAAQA1AAApggQAkgcAOgqQAHgSAAgRIAAhnIgTgBQjsAAAACHg");
        this.shape_59.setTransform(468.1, 250.5, 0.185, 0.185);

        this.shape_60 = new cjs.Shape();
        this.shape_60.graphics.f("#000000").s().p("ADOGnIkKmsQhpiog1hzIgEABQAJCUAADIIAAFqIhmAAIAAtNIB2AAIENGqQBZCNA+CHIADgBQgNiNAAjOIAAliIBnAAIAANNg");
        this.shape_60.setTransform(455.2, 248.3, 0.185, 0.185);

        this.shape_61 = new cjs.Shape();
        this.shape_61.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_61.setTransform(460.9, 248.5, 0.185, 0.185);

        this.shape_62 = new cjs.Shape();
        this.shape_62.graphics.f("#000000").s().p("AhvENQgigKgXgPIAUg5QATANAdAKQAlAMAjAAQA/AAAggkQAagdAAgpQgBg2grgdQgmgag5AAIgoAAIAAg1IAoAAQAuAAAhgWQApgaAAgtQAAgjgXgWQgZgZguAAQgdAAghAMQgbAKgTAOIgUg1QAYgRAlgMQApgNApAAQBJAAArAoQAlAkAAA2QAAArgZAhQgaAigxASIAAACQA1AKAgAiQAkAnAAA3QAABFgyAtQg3AxhbAAQgqAAgqgMg");
        this.shape_62.setTransform(444.8, 152.2, 0.185, 0.185);

        this.shape_63 = new cjs.Shape();
        this.shape_63.graphics.f("#000000").s().p("Ag1GoIAApeIBsAAIAAJegAgwkyQgTgTAAgcQAAgeAUgUQATgUAcAAQAeAAATAUQATATAAAfQABAdgUASQgTAUgfAAQgdAAgSgUg");
        this.shape_63.setTransform(466.2, 176, 0.185, 0.185);

        this.shape_64 = new cjs.Shape();
        this.shape_64.graphics.f("#000000").s().p("AjpGnIAAtNIBtAAIAALxIFnAAIAABcg");
        this.shape_64.setTransform(458.7, 176, 0.185, 0.185);

        this.shape_65 = new cjs.Shape();
        this.shape_65.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_65.setTransform(460.9, 176, 0.185, 0.185);

        this.shape_66 = new cjs.Shape();
        this.shape_66.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_66.setTransform(443.4, 79.5, 0.185, 0.185);

        this.shape_67 = new cjs.Shape();
        this.shape_67.graphics.f("#000000").s().p("ADLGnIAAmNImWAAIAAGNIhtAAIAAtNIBtAAIAAFiIGWAAIAAliIBuAAIAANNg");
        this.shape_67.setTransform(460.9, 103.5, 0.185, 0.185);

        this.shape_68 = new cjs.Shape();
        this.shape_68.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_68.setTransform(460.9, 103.5, 0.185, 0.185);

        this.shape_69 = new cjs.Shape();
        this.shape_69.graphics.f("#000000").s().p("AjPFUIEWoiIAAgCIk1AAIAAiDIHdAAIAABkIkWJDg");
        this.shape_69.setTransform(415.4, 540, 0.185, 0.185, 0, 0, 0, 0.2, 0.2);

        this.shape_70 = new cjs.Shape();
        this.shape_70.graphics.f("#000000").s().p("Ai/EHQhEhRAAiBQAAhcAhhQQAghMA4g0QBlhdCfgIQAlgDAaABIAAB7QgkABgaABQhiAIg4AxQgyApgPBCIAEAAQA1g3BZAAQBYAAA7A7QA/A7gBBnQABBnhHBGQhHBJhtAAQiAAAhIhYgAg6ANQgZAQgLAcQgHALAAAcQADA7AaAlQAdApAxAAIACAAQApAAAZgiQAZgigBg0QAAgygZggQgbgigvABQgfAAgaAPg");
        this.shape_70.setTransform(415.4, 467.3, 0.185, 0.185, 0, 0, 0, 0.2, 0.2);

        this.shape_71 = new cjs.Shape();
        this.shape_71.graphics.f("#000000").s().p("AihFOQgvgLgegQIAch4QAaAOAnAJQAtALArAAQA3AAAjgZQArgcABgyQAAhyi9AAQgyAAgqAHIAslkIF1AAIAACDIkFAAIgPBpQAPgCAdAAQAxAAAsALQAxANAiAZQBSA4ABBxQAABjhOBEQhSBIiBAAQg7AAg1gMg");
        this.shape_71.setTransform(415.4, 394.5, 0.185, 0.185, 0, 0, 0, 0.2, 0);

        this.shape_72 = new cjs.Shape();
        this.shape_72.graphics.f("#000000").s().p("AAiFUIAAijIkqAAIAAhnIEAmdIDAAAIAAGNIBSAAIAAB3IhSAAIAACjgAAEiaIgeA/IhbCTIAAACICXAAIAAiVQAAg1AFhJIgEAAIgfA/g");
        this.shape_72.setTransform(415.4, 321.9, 0.185, 0.185, 0, 0, 0, 0.2, 0.3);

        this.shape_73 = new cjs.Shape();
        this.shape_73.graphics.f("#000000").s().p("AibFRQgygNghgVIAgh3QAeAPAjALQAyAQArAAQA6AAAhgbQAfgYAAgoQAAgwgqgaQgjgYg6AAIhBAAIAAhwIA+AAQAvgBAggRQAogVAAgoQAAgggZgTQgbgUguAAQgmAAgrAOQgjALgaAQIgghzQAhgWA2gOQA9gQA9AAQBnAAA/AyQA6AvAABJQAAA3geAoQggAqg+AVIAAACQBAAMAoApQArAuAABBQAABchKA5QhNA8h9AAQg+AAg4gPg");
        this.shape_73.setTransform(415.4, 249.1, 0.185, 0.185, 0, 0, 0, 0.2, -0.1);

        this.shape_74 = new cjs.Shape();
        this.shape_74.graphics.f("#000000").s().p("AjvFaIAAhhIBXhPQB5htAsg4QA2hCACg5QAAgsgbgaQgdgdg2AAQhHAAhKA5IgthzQAqgfA2gTQA9gUBBAAQBvAABAA9QA+A5AABgQAABOg2BMQgpA8hWBOIg8AzIAAADID9AAIAACDg");
        this.shape_74.setTransform(415.4, 177.3, 0.185, 0.185, 0, 0, 0, 0.2, 0.1);

        this.shape_75 = new cjs.Shape();
        this.shape_75.graphics.f("#000000").s().p("AABFUIAAoaIgBAAIiAA+Igah3ICyhUICDAAIAAKng");
        this.shape_75.setTransform(415.4, 104.7, 0.185, 0.185, 0, 0, 0, 0.2, 0);

        this.shape_76 = new cjs.Shape();
        this.shape_76.graphics.f("#FF8375").s().p("AjvFSIAAqjIHfAAIAAKjg");
        this.shape_76.setTransform(460.9, 538.5);

        // Capa 1
        this.shape_77 = new cjs.Shape();
        this.shape_77.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape_77.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape_77, this.shape_76, this.shape_75, this.shape_74, this.shape_73, this.shape_72, this.shape_71, this.shape_70, this.shape_69, this.shape_68, this.shape_67, this.shape_66, this.shape_65, this.shape_64, this.shape_63, this.shape_62, this.shape_61, this.shape_60, this.shape_59, this.shape_58, this.shape_57, this.shape_56, this.shape_55, this.shape_54, this.shape_53, this.shape_52, this.shape_51, this.shape_50, this.shape_49, this.shape_48, this.shape_47, this.shape_46, this.shape_45, this.shape_44, this.shape_43, this.shape_42, this.shape_41, this.shape_40, this.shape_39, this.shape_38, this.shape_37, this.shape_36, this.shape_35, this.shape_34, this.shape_33, this.shape_32, this.shape_31, this.shape_30, this.shape_29, this.shape_28, this.shape_27, this.shape_26, this.shape_25, this.shape_24, this.shape_23, this.shape_22, this.shape_21, this.shape_20, this.shape_19, this.shape_18, this.shape_17, this.shape_16, this.shape_15, this.shape_14, this.shape_13, this.shape_12, this.shape_11, this.shape_10, this.shape_9, this.shape_8, this.shape_7, this.shape_6, this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape, this.text_12, this.text_11, this.text_10, this.text_9, this.text_8, this.text_7, this.text_6, this.text_5, this.text_4, this.text_3, this.text_2, this.text_1, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_02 = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib.FQ_10_11_021();
        this.instance.setTransform(225.3, 53.4);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_01 = function () {
        this.initialize();

        // Capa 3
        this.text = new cjs.Text("168,9", "8px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 10;
        this.text.setTransform(694, 510.1);

        this.text_1 = new cjs.Text("158,9", "8px Verdana");
        this.text_1.textAlign = "center";
        this.text_1.lineHeight = 10;
        this.text_1.setTransform(522.4, 510.1);

        this.text_2 = new cjs.Text("144,2", "8px Verdana");
        this.text_2.textAlign = "center";
        this.text_2.lineHeight = 10;
        this.text_2.setTransform(306.7, 510.1);

        this.text_3 = new cjs.Text("167,3", "8px Verdana");
        this.text_3.textAlign = "center";
        this.text_3.lineHeight = 10;
        this.text_3.setTransform(652.9, 510.1);

        this.text_4 = new cjs.Text("164,9", "8px Verdana");
        this.text_4.textAlign = "center";
        this.text_4.lineHeight = 10;
        this.text_4.setTransform(609.3, 510.1);

        this.text_5 = new cjs.Text("162,5", "8px Verdana");
        this.text_5.textAlign = "center";
        this.text_5.lineHeight = 10;
        this.text_5.setTransform(564.6, 510.1);

        this.text_6 = new cjs.Text("157,3", "8px Verdana");
        this.text_6.textAlign = "center";
        this.text_6.lineHeight = 10;
        this.text_6.setTransform(479.3, 510.1);

        this.text_7 = new cjs.Text("150,4", "8px Verdana");
        this.text_7.textAlign = "center";
        this.text_7.lineHeight = 10;
        this.text_7.setTransform(393.4, 510.1);

        this.text_8 = new cjs.Text("140,9", "8px Verdana");
        this.text_8.textAlign = "center";
        this.text_8.lineHeight = 10;
        this.text_8.setTransform(263.1, 510.1);

        this.text_9 = new cjs.Text("140,1", "8px Verdana");
        this.text_9.textAlign = "center";
        this.text_9.lineHeight = 10;
        this.text_9.setTransform(221.4, 510.1);

        this.text_10 = new cjs.Text("186,2", "8px Verdana");
        this.text_10.textAlign = "center";
        this.text_10.lineHeight = 10;
        this.text_10.setTransform(350.7, 391.7);

        this.text_11 = new cjs.Text("183,9", "8px Verdana");
        this.text_11.textAlign = "center";
        this.text_11.lineHeight = 10;
        this.text_11.setTransform(306.7, 391.7);

        this.text_12 = new cjs.Text("207,2", "8px Verdana");
        this.text_12.textAlign = "center";
        this.text_12.lineHeight = 10;
        this.text_12.setTransform(652.9, 391.7);

        this.text_13 = new cjs.Text("204,4", "8px Verdana");
        this.text_13.textAlign = "center";
        this.text_13.lineHeight = 10;
        this.text_13.setTransform(609.3, 391.7);

        this.text_14 = new cjs.Text("200,5", "8px Verdana");
        this.text_14.textAlign = "center";
        this.text_14.lineHeight = 10;
        this.text_14.setTransform(564.6, 391.7);

        this.text_15 = new cjs.Text("195,1", "8px Verdana");
        this.text_15.textAlign = "center";
        this.text_15.lineHeight = 10;
        this.text_15.setTransform(479.3, 391.7);

        this.text_16 = new cjs.Text("192,2", "8px Verdana");
        this.text_16.textAlign = "center";
        this.text_16.lineHeight = 10;
        this.text_16.setTransform(435.1, 391.7);

        this.text_17 = new cjs.Text("190,2", "8px Verdana");
        this.text_17.textAlign = "center";
        this.text_17.lineHeight = 10;
        this.text_17.setTransform(393.4, 391.7);

        this.text_18 = new cjs.Text("180,9", "8px Verdana");
        this.text_18.textAlign = "center";
        this.text_18.lineHeight = 10;
        this.text_18.setTransform(263.1, 391.7);

        this.text_19 = new cjs.Text("178,5", "8px Verdana");
        this.text_19.textAlign = "center";
        this.text_19.lineHeight = 10;
        this.text_19.setTransform(221.4, 391.7);

        this.text_20 = new cjs.Text("138,9", "8px Verdana");
        this.text_20.textAlign = "center";
        this.text_20.lineHeight = 10;
        this.text_20.setTransform(177.8, 391.7);

        this.text_21 = new cjs.Text("95,94", "8px Verdana");
        this.text_21.textAlign = "center";
        this.text_21.lineHeight = 10;
        this.text_21.setTransform(306.7, 332.8);

        this.text_22 = new cjs.Text("131,3", "8px Verdana");
        this.text_22.textAlign = "center";
        this.text_22.lineHeight = 10;
        this.text_22.setTransform(823.7, 332.8);

        this.text_23 = new cjs.Text("126,9", "8px Verdana");
        this.text_23.textAlign = "center";
        this.text_23.lineHeight = 10;
        this.text_23.setTransform(782, 332.8);

        this.text_24 = new cjs.Text("127,6", "8px Verdana");
        this.text_24.textAlign = "center";
        this.text_24.lineHeight = 10;
        this.text_24.setTransform(738.4, 332.8);

        this.text_25 = new cjs.Text("121,8", "8px Verdana");
        this.text_25.textAlign = "center";
        this.text_25.lineHeight = 10;
        this.text_25.setTransform(694.6, 332.8);

        this.text_26 = new cjs.Text("118,7", "8px Verdana");
        this.text_26.textAlign = "center";
        this.text_26.lineHeight = 10;
        this.text_26.setTransform(652.9, 332.8);

        this.text_27 = new cjs.Text("114,8", "8px Verdana");
        this.text_27.textAlign = "center";
        this.text_27.lineHeight = 10;
        this.text_27.setTransform(609.3, 332.8);

        this.text_28 = new cjs.Text("112,4", "8px Verdana");
        this.text_28.textAlign = "center";
        this.text_28.lineHeight = 10;
        this.text_28.setTransform(564.6, 332.8);

        this.text_29 = new cjs.Text("107,9", "8px Verdana");
        this.text_29.textAlign = "center";
        this.text_29.lineHeight = 10;
        this.text_29.setTransform(522.9, 332.8);

        this.text_30 = new cjs.Text("106,4", "8px Verdana");
        this.text_30.textAlign = "center";
        this.text_30.lineHeight = 10;
        this.text_30.setTransform(479.3, 332.8);

        this.text_31 = new cjs.Text("102,9", "8px Verdana");
        this.text_31.textAlign = "center";
        this.text_31.lineHeight = 10;
        this.text_31.setTransform(435.1, 332.8);

        this.text_32 = new cjs.Text("101,1", "8px Verdana");
        this.text_32.textAlign = "center";
        this.text_32.lineHeight = 10;
        this.text_32.setTransform(393.4, 332.8);

        this.text_33 = new cjs.Text("92,91", "8px Verdana");
        this.text_33.textAlign = "center";
        this.text_33.lineHeight = 10;
        this.text_33.setTransform(263.1, 332.8);

        this.text_34 = new cjs.Text("91,22", "8px Verdana");
        this.text_34.textAlign = "center";
        this.text_34.lineHeight = 10;
        this.text_34.setTransform(221.4, 332.8);

        this.text_35 = new cjs.Text("88,91", "8px Verdana");
        this.text_35.textAlign = "center";
        this.text_35.lineHeight = 10;
        this.text_35.setTransform(177.8, 332.8);

        this.text_36 = new cjs.Text("4,003", "8px Verdana");
        this.text_36.textAlign = "center";
        this.text_36.lineHeight = 10;
        this.text_36.setTransform(823.7, 97.2);

        this.text_37 = new cjs.Text("20,18", "8px Verdana");
        this.text_37.textAlign = "center";
        this.text_37.lineHeight = 10;
        this.text_37.setTransform(823.7, 155.7);

        this.text_38 = new cjs.Text("14,01", "8px Verdana");
        this.text_38.textAlign = "center";
        this.text_38.lineHeight = 10;
        this.text_38.setTransform(694.6, 155.7);

        this.text_39 = new cjs.Text("12,01", "8px Verdana");
        this.text_39.textAlign = "center";
        this.text_39.lineHeight = 10;
        this.text_39.setTransform(652.9, 155.7);

        this.text_40 = new cjs.Text("10,81", "8px Verdana");
        this.text_40.textAlign = "center";
        this.text_40.lineHeight = 10;
        this.text_40.setTransform(609.3, 155.7);

        this.text_41 = new cjs.Text("39,95", "8px Verdana");
        this.text_41.textAlign = "center";
        this.text_41.lineHeight = 10;
        this.text_41.setTransform(823.7, 215);

        this.text_42 = new cjs.Text("35,45", "8px Verdana");
        this.text_42.textAlign = "center";
        this.text_42.lineHeight = 10;
        this.text_42.setTransform(782, 215);

        this.text_43 = new cjs.Text("32,07", "8px Verdana");
        this.text_43.textAlign = "center";
        this.text_43.lineHeight = 10;
        this.text_43.setTransform(738.4, 215);

        this.text_44 = new cjs.Text("30,97", "8px Verdana");
        this.text_44.textAlign = "center";
        this.text_44.lineHeight = 10;
        this.text_44.setTransform(694.6, 215);

        this.text_45 = new cjs.Text("28,09", "8px Verdana");
        this.text_45.textAlign = "center";
        this.text_45.lineHeight = 10;
        this.text_45.setTransform(652.9, 215);

        this.text_46 = new cjs.Text("26,98", "8px Verdana");
        this.text_46.textAlign = "center";
        this.text_46.lineHeight = 10;
        this.text_46.setTransform(609.3, 215);

        this.text_47 = new cjs.Text("83,8", "8px Verdana");
        this.text_47.textAlign = "center";
        this.text_47.lineHeight = 10;
        this.text_47.setTransform(823.7, 273.8);

        this.text_48 = new cjs.Text("79,9", "8px Verdana");
        this.text_48.textAlign = "center";
        this.text_48.lineHeight = 10;
        this.text_48.setTransform(781.9, 273.8);

        this.text_49 = new cjs.Text("78,96", "8px Verdana");
        this.text_49.textAlign = "center";
        this.text_49.lineHeight = 10;
        this.text_49.setTransform(738.4, 273.8);

        this.text_50 = new cjs.Text("74,92", "8px Verdana");
        this.text_50.textAlign = "center";
        this.text_50.lineHeight = 10;
        this.text_50.setTransform(694.6, 273.8);

        this.text_51 = new cjs.Text("72,59", "8px Verdana");
        this.text_51.textAlign = "center";
        this.text_51.lineHeight = 10;
        this.text_51.setTransform(652.9, 273.8);

        this.text_52 = new cjs.Text("69,72", "8px Verdana");
        this.text_52.textAlign = "center";
        this.text_52.lineHeight = 10;
        this.text_52.setTransform(609.3, 273.8);

        this.text_53 = new cjs.Text("65,39", "8px Verdana");
        this.text_53.textAlign = "center";
        this.text_53.lineHeight = 10;
        this.text_53.setTransform(564.6, 273.8);

        this.text_54 = new cjs.Text("63,55", "8px Verdana");
        this.text_54.textAlign = "center";
        this.text_54.lineHeight = 10;
        this.text_54.setTransform(522.9, 273.8);

        this.text_55 = new cjs.Text("58,69", "8px Verdana");
        this.text_55.textAlign = "center";
        this.text_55.lineHeight = 10;
        this.text_55.setTransform(479.3, 273.8);

        this.text_56 = new cjs.Text("58,47", "8px Verdana");
        this.text_56.textAlign = "center";
        this.text_56.lineHeight = 10;
        this.text_56.setTransform(435.1, 273.8);

        this.text_57 = new cjs.Text("55,85", "8px Verdana");
        this.text_57.textAlign = "center";
        this.text_57.lineHeight = 10;
        this.text_57.setTransform(393.4, 273.8);

        this.text_58 = new cjs.Text("54,94", "8px Verdana");
        this.text_58.textAlign = "center";
        this.text_58.lineHeight = 10;
        this.text_58.setTransform(349.8, 273.8);

        this.text_59 = new cjs.Text("50,94", "8px Verdana");
        this.text_59.textAlign = "center";
        this.text_59.lineHeight = 10;
        this.text_59.setTransform(263.1, 273.8);

        this.text_60 = new cjs.Text("47,88", "8px Verdana");
        this.text_60.textAlign = "center";
        this.text_60.lineHeight = 10;
        this.text_60.setTransform(221.4, 273.8);

        this.text_61 = new cjs.Text("44,96", "8px Verdana");
        this.text_61.textAlign = "center";
        this.text_61.lineHeight = 10;
        this.text_61.setTransform(177.8, 273.8);

        this.text_62 = new cjs.Text("137,3", "8px Verdana");
        this.text_62.textAlign = "center";
        this.text_62.lineHeight = 10;
        this.text_62.setTransform(134.6, 391.7);

        this.text_63 = new cjs.Text("132,9", "8px Verdana");
        this.text_63.textAlign = "center";
        this.text_63.lineHeight = 10;
        this.text_63.lineWidth = 21;
        this.text_63.setTransform(92, 391.7);

        this.text_64 = new cjs.Text("87,62", "8px Verdana");
        this.text_64.textAlign = "center";
        this.text_64.lineHeight = 10;
        this.text_64.setTransform(134.6, 332.8);

        this.text_65 = new cjs.Text("85,47", "8px Verdana");
        this.text_65.textAlign = "center";
        this.text_65.lineHeight = 10;
        this.text_65.setTransform(91, 332.8);

        this.text_66 = new cjs.Text("40,08", "8px Verdana");
        this.text_66.textAlign = "center";
        this.text_66.lineHeight = 10;
        this.text_66.setTransform(134.6, 273.8);

        this.text_67 = new cjs.Text("39,10", "8px Verdana");
        this.text_67.textAlign = "center";
        this.text_67.lineHeight = 10;
        this.text_67.setTransform(91, 273.8);

        this.text_68 = new cjs.Text("24,31", "8px Verdana");
        this.text_68.textAlign = "center";
        this.text_68.lineHeight = 10;
        this.text_68.setTransform(134.6, 214.8);

        this.text_69 = new cjs.Text("22,99", "8px Verdana");
        this.text_69.textAlign = "center";
        this.text_69.lineHeight = 10;
        this.text_69.setTransform(91, 214.8);

        this.text_70 = new cjs.Text("9,012", "8px Verdana");
        this.text_70.textAlign = "center";
        this.text_70.lineHeight = 10;
        this.text_70.setTransform(134.6, 155.8);

        this.text_71 = new cjs.Text("6,941", "8px Verdana");
        this.text_71.textAlign = "center";
        this.text_71.lineHeight = 10;
        this.text_71.setTransform(91, 155.8);

        this.text_72 = new cjs.Text("1,008", "8px Verdana");
        this.text_72.textAlign = "center";
        this.text_72.lineHeight = 10;
        this.text_72.setTransform(91, 97.1);

        // Capa 2
        this.text_73 = new cjs.Text("18", "16px Arial");
        this.text_73.textAlign = "center";
        this.text_73.lineHeight = 18;
        this.text_73.setTransform(824, 32.3);

        this.text_74 = new cjs.Text("17", "16px Arial");
        this.text_74.textAlign = "center";
        this.text_74.lineHeight = 18;
        this.text_74.setTransform(780, 92.3);

        this.text_75 = new cjs.Text("16", "16px Arial");
        this.text_75.textAlign = "center";
        this.text_75.lineHeight = 18;
        this.text_75.setTransform(738, 92.3);

        this.text_76 = new cjs.Text("15", "16px Arial");
        this.text_76.textAlign = "center";
        this.text_76.lineHeight = 18;
        this.text_76.setTransform(694.1, 91.9);

        this.text_77 = new cjs.Text("14", "16px Arial");
        this.text_77.textAlign = "center";
        this.text_77.lineHeight = 18;
        this.text_77.setTransform(651.1, 91.9);

        this.text_78 = new cjs.Text("13", "16px Arial");
        this.text_78.textAlign = "center";
        this.text_78.lineHeight = 18;
        this.text_78.setTransform(608.1, 91.9);

        this.text_79 = new cjs.Text("12", "16px Arial");
        this.text_79.textAlign = "center";
        this.text_79.lineHeight = 18;
        this.text_79.setTransform(564.1, 209.9);

        this.text_80 = new cjs.Text("11", "16px Arial");
        this.text_80.textAlign = "center";
        this.text_80.lineHeight = 18;
        this.text_80.setTransform(523.1, 209.9);

        this.text_81 = new cjs.Text("10", "16px Arial");
        this.text_81.textAlign = "center";
        this.text_81.lineHeight = 18;
        this.text_81.setTransform(479.1, 209.9);

        this.text_82 = new cjs.Text("9", "16px Arial");
        this.text_82.textAlign = "center";
        this.text_82.lineHeight = 18;
        this.text_82.setTransform(437.1, 209.9);

        this.text_83 = new cjs.Text("VIII", "16px Arial");
        this.text_83.textAlign = "center";
        this.text_83.lineHeight = 18;
        this.text_83.setTransform(394.1, 209.9);

        this.text_84 = new cjs.Text("VII", "16px Arial");
        this.text_84.textAlign = "center";
        this.text_84.lineHeight = 18;
        this.text_84.setTransform(350.1, 209.9);

        this.text_85 = new cjs.Text("VI", "16px Arial");
        this.text_85.textAlign = "center";
        this.text_85.lineHeight = 18;
        this.text_85.setTransform(307.1, 208.9);

        this.text_86 = new cjs.Text("V", "16px Arial");
        this.text_86.textAlign = "center";
        this.text_86.lineHeight = 18;
        this.text_86.setTransform(264.1, 208.9);

        this.text_87 = new cjs.Text("IV", "16px Arial");
        this.text_87.textAlign = "center";
        this.text_87.lineHeight = 18;
        this.text_87.setTransform(221.1, 208.9);

        this.text_88 = new cjs.Text("III", "16px Arial");
        this.text_88.textAlign = "center";
        this.text_88.lineHeight = 18;
        this.text_88.setTransform(177.1, 208.9);

        this.text_89 = new cjs.Text("II", "16px Arial");
        this.text_89.textAlign = "center";
        this.text_89.lineHeight = 18;
        this.text_89.setTransform(135.1, 91.9);

        this.text_90 = new cjs.Text("I", "16px Arial");
        this.text_90.textAlign = "center";
        this.text_90.lineHeight = 18;
        this.text_90.setTransform(91.1, 32.9);

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000000").s().p("AiEDaQg1g/AAhqQAAhMAahBQAYg9AqgqQBEhEBogNQAdgEAYAAIAAA9QgXgCggAFQhQAOgyA4QguAzgLBJIADAAQAVgcAggRQAkgSAoAAQBJAAAtAwQAuAuAABQQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAOAAATQABBGAfAqQAgAsA1AAIABAAQAvAAAdgkQAdgkAAg7QAAg6geghQgegggzAAQgfAAgdATg");
        this.shape.setTransform(819.5, 241.1, 0.15, 0.15);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("AhuEOQgjgKgXgPIAUg5QAUAMAdAKQAlAMAjAAQA+AAAggkQAbgdgBgpQgBg2gqgdQgmgag5AAIgpAAIAAg1IApAAQAtAAAhgWQApgaAAgsQAAgkgWgWQgagZguAAQgeAAgfAMQgbAKgUAPIgTg2QAYgRAkgMQApgNApAAQBJAAAqAoQAmAkAAA2QAAArgZAhQgaAigxASIAAACQA1AKAgAiQAkAnAAA3QAABFgyAtQg2AxhcAAQgqAAgpgLg");
        this.shape_1.setTransform(812.9, 241.1, 0.15, 0.15);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#000000").s().p("AiSE3IAAmhQAAh3gFhHIBhAAIAEB4IAFAAQAUg9AsglQAugkA3AAQAQAAAQAEIAABpQgTgEgTAAQg5AAgoAoQglAmgMBAQgFAeAAAVIAAFDg");
        this.shape_2.setTransform(831.1, 262.2, 0.15, 0.15);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#000000").s().p("ACoGnIkTmgIhQBdIAAFDIhuAAIAAtNIBuAAIAAGYIADAAQAXggArg6IEBk+ICHAAIkvFnIFGHmg");
        this.shape_3.setTransform(823.1, 260.5, 0.15, 0.15);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#00E4F1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_4.setTransform(826, 260.5, 0.15, 0.15);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#000000").s().p("AhjCcQglg3gBhkQABhiAog6QAlg3A+ABQBAAAAjA2QAjA2AABiQABBmglA4QglA3hCABQg9AAgkg3gAg6h7QgYAuAABOQAABPAXAsQAWAsAlAAQAoAAAWguQAVgsAAhPQgBhNgUgrQgVgugpAAQgkAAgWAsg");
        this.shape_5.setTransform(826, 457.7, 0.15, 0.15);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#000000").s().p("AiGDuQgwgqAAg+QAAgyAdgmQAbgkA0gUIgBgDQgrgUgXgiQgUgfAAglQAAhAAwgpQAvgoBHAAQBLAAArAqQAoAlAAA3QAAAmgUAfQgWAkgvAXIAAACQAzATAcAjQAeAkAAAxQAABGg2AtQg0ArhNAAQhTAAgzgrgAhSA3QgZAdAAAoQgCArAdAeQAfAfAxAAQAxAAAegcQAdgbABgrQgBgvgggdQgcgag5gRQgvAOgaAegAhEjJQgYAYAAAlQAABJBmAcQAlgNAVgYQAZgbgBgjQAAglgUgYQgZgcgvAAQgqAAgaAag");
        this.shape_6.setTransform(825.1, 417.9, 0.15, 0.15);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f("#000000").s().p("AATEQIAAnbIgBAAIhdA0IgOg4IB1hAIA+AAIAAIfg");
        this.shape_7.setTransform(818.2, 417.9, 0.15, 0.15);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg5IB0g/IA/AAIAAIfg");
        this.shape_8.setTransform(811.7, 417.9, 0.15, 0.15);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f("#000000").s().p("AjTDpQhUhXAAiOQAAiSBYhZQBThWCAAAQCDAABQBXQBRBWAACMQAACchgBYQhUBNh4AAQh+AAhRhUgAiLifQgsBBAABeQAABlA0BDQA0BCBPAAQBOAAA1hCQA0hDAAhlQAAhagqhCQgyhOhaAAQhZAAgzBLg");
        this.shape_9.setTransform(836.9, 439, 0.15, 0.15);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f("#000000").s().p("Ai8ECQhFhFAAiRIAAliIBuAAIAAFPQAADCCIAAQAyAAAoggQAkgcARgpQAKgYAAggIAAl0IBuAAIAAG5QABBqAFA8IhjAAIgGhkIgCAAQgbAugsAeQg5AmhGAAQhXAAg2g1g");
        this.shape_10.setTransform(826.6, 439.1, 0.15, 0.15);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f("#000000").s().p("AjfFcQhXhdAAi7IAAnxIBvAAIAAH0QAACIA4BGQAzBABZAAQBfAAA1hBQA3hFAAiIIAAn0IBvAAIAAHsQAAC7hbBeQhTBWiQAAQiKAAhOhSg");
        this.shape_11.setTransform(815.4, 437.3, 0.15, 0.15);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_12.setTransform(826, 437.3, 0.15, 0.15);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f("#000000").s().p("Ag9EAQBNhvAAiRQAAiRhNhuIArAAQBQBrAACUQAACShQBug");
        this.shape_13.setTransform(834.4, 398.1, 0.15, 0.15);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBUhQAcgpQAlgvABgrQgBgjgRgVQgVgYgpAAQgtAAgpAjIgRgoQAwgpBDAAQA7AAAiAmQAdAgAAAwQAAA1gmA0QgdAqhHBHIghAeIAAABIC1AAIAAAug");
        this.shape_14.setTransform(830.8, 397.7, 0.15, 0.15);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f("#000000").s().p("AiBDPIAAgiIArgqQBVhRAcgoQAkgvABgrQAAgkgSgUQgUgYgoAAQgvAAgoAiIgSgmQAxgqBCAAQA8AAAiAmQAdAgAAAwQAAA1glA1QgeAphHBHIghAeIAAABIC1AAIAAAug");
        this.shape_15.setTransform(826, 397.7, 0.15, 0.15);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBUhRAcgoQAlgvAAgsQAAgigRgVQgVgYgpAAQgtAAgpAiIgSgnQAygpBCAAQA7AAAiAmQAdAgAAAxQAAAzgmA2QgcAphIBHIggAeIAAABIC1AAIAAAug");
        this.shape_16.setTransform(821.2, 397.7, 0.15, 0.15);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f("#000000").s().p("AATEAQhQhsAAiUQAAiRBQhuIArAAQhNBrAACUQAACRBNBvg");
        this.shape_17.setTransform(817.7, 398.1, 0.15, 0.15);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f("#000000").s().p("AiEDaQg1g/AAhqQAAhMAahBQAYg9AqgqQBFhEBngMQAbgFAaAAIAAA9QgYgCgfAFQhQAOgzA4QguAzgKBJIADAAQAVgcAggRQAjgSApAAQBIAAAuAwQAuAvAABPQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAOAAATQABBGAeAqQAgAsA2AAIABAAQAvAAAdgkQAdgkAAg7QAAg6geghQgfgggyAAQgfAAgdATg");
        this.shape_18.setTransform(819.6, 359, 0.15, 0.15);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f("#000000").s().p("AiFDtQgxgpAAg+QAAgzAdglQAcglAzgTIgBgDQgrgVgWghQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArAqQAoAlAAA3QAAAmgUAfQgWAkgvAWIAAADQA0ASAcAjQAdAlAAAwQAABGg2AtQg0AshNAAQhSAAgzgsgAhSA3QgZAdAAAnQgCArAeAfQAeAeAxABQAxAAAegcQAegcAAgqQAAgvgggeQgdgZg5gRQgvAOgaAegAhDjJQgYAYAAAlQAABJBlAbQAlgMAWgZQAYgaAAgjQAAglgVgZQgZgcguAAQgqAAgaAbg");
        this.shape_19.setTransform(813.1, 359, 0.15, 0.15);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f("#000000").s().p("ACVE3IAAldQAAhRgfguQgjg1hKAAQgzAAgoAhQgoAggOAwQgIAVAAAfIAAFsIhvAAIAAm6QAAhkgEhBIBhAAIAGBkIADAAQAZgwAxgeQA4gkBFAAQBRAAA5AzQBMBEAACMIAAFqg");
        this.shape_20.setTransform(831.1, 380.1, 0.15, 0.15);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.f("#000000").s().p("ACiGrQgSghgniqQgShYgmglQgnglhIgDIhmAAIAAFwIhtAAIAAtDQBXgSB6AAQBVAAA7ARQA6ARAoAjQAgAdARApQARAqAAAxQAABRguA6QgqA2hHAWIAAADQBdAhAfCKQAYBnANAuQAQA+AMAXgAiklMIAAE2IBvAAQBVAAA0gsQAzgsAAhJQAAhPg1gpQgygmhZAAQhIgBgjAKg");
        this.shape_21.setTransform(821.2, 378.3, 0.15, 0.15);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f("#00E4F1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_22.setTransform(826, 378.3, 0.15, 0.15);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.f("#000000").s().p("AA1EQIAAiUIj6AAIAAgxIDwlaIBPAAIAAFRIBMAAIAAA6IhMAAIAACUgAAIh3IiDC3IAAACICwAAIAAi0QAAgyADgkIgDAAQgaAwgTAhg");
        this.shape_23.setTransform(819.4, 299.9, 0.15, 0.15);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAjAKAhAAQA0AAAlggQAmghAAg1QgBg4glgfQgogghMAAQgbAAgxAGIAkkGIEBAAIAAA+IjNAAIgVCNQAWgEAXAAQBDAAAvAeQAjATAUAgQAXAmAAAxQAABQg5A1Qg5A1hWAAQgqAAgmgLg");
        this.shape_24.setTransform(812.9, 300, 0.15, 0.15);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.f("#000000").s().p("Ai7DpQhPhUAAiLQAAiMBMhbQBPhgB/AAQCFAABDBmQAzBOAABrQAAAMgEAmImoAAQACBqA+A4QA3AxBXAAQA3AAArgJQAigHAkgPIATBPQhXAnhzAAQiIAAhRhVgAhxiwQgnAxgHBFIE/AAQAChDgfgxQgog/hTAAQhKAAgvA9g");
        this.shape_25.setTransform(831.4, 321.1, 0.15, 0.15);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f("#000000").s().p("ADHGnIhsi7QhFhzgag0IgDAAQgoBTgzBVIhmC6Ih9AAIECmqIj4mjIB/AAIBvDHQA2BeAXAxIACAAQAdg7AwhUIBzjHIB9AAIkAGcIEHGxg");
        this.shape_26.setTransform(821.5, 319.3, 0.15, 0.15);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.f("#00E4F1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_27.setTransform(826, 319.4, 0.15, 0.15);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f("#000000").s().p("AiFDtQgxgpAAg+QAAgyAdgmQAcgkAzgUIgBgDQgrgUgXgiQgUgfAAglQAAhAAwgpQAwgoBGAAQBLAAArAqQAoAlAAA3QAAAmgUAfQgXAkgvAXIAAACQA0ATAcAjQAeAkAAAxQAABGg2AtQg0ArhNAAQhSAAgzgsgAhSA3QgZAdAAAoQgCArAeAeQAeAfAxAAQAwAAAfgcQAdgbAAgqQAAgwgggdQgcgag5gRQgvAOgaAegAhDjJQgZAYAAAlQAABJBmAcQAlgNAWgYQAYgbAAgjQAAglgVgYQgZgcguAAQgqAAgaAag");
        this.shape_28.setTransform(818.7, 182.2, 0.15, 0.15);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.f("#000000").s().p("AATEQIAAnbIgBAAIhdA0IgOg5IB0g/IA/AAIAAIfg");
        this.shape_29.setTransform(811.7, 182.2, 0.15, 0.15);

        this.shape_30 = new cjs.Shape();
        this.shape_30.graphics.f("#000000").s().p("AiSE3IAAmhQAAh3gFhHIBhAAIAEB4IAFAAQAUg9AsglQAugkA3AAQAQAAAQAEIAABpQgSgEgUAAQg5AAgoAoQglAmgLBAQgFAZAAAaIAAFDg");
        this.shape_30.setTransform(832.2, 203.2, 0.15, 0.15);

        this.shape_31 = new cjs.Shape();
        this.shape_31.graphics.f("#000000").s().p("ADsGnIhakKIkpAAIhYEKIhxAAIEftNICCAAIEgNNgAguisIhTDzID8AAIhSjyQgUg6gWhgIgDAAQgXBcgTA9g");
        this.shape_31.setTransform(822.9, 201.5, 0.15, 0.15);

        this.shape_32 = new cjs.Shape();
        this.shape_32.graphics.f("#00E4F1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_32.setTransform(826, 201.5, 0.15, 0.15);

        this.shape_33 = new cjs.Shape();
        this.shape_33.graphics.f("#000000").s().p("AiEDRQgyhLgBiFQAAiEA2hMQAyhJBTAAQBWAAAuBJQAvBIABCDQgBCJgwBKQgyBKhYAAQhRAAgwhIgAhOilQgfA9AABqQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhogag5Qgcg9g4AAQgwAAgeA6g");
        this.shape_33.setTransform(818.7, 123.3, 0.15, 0.15);

        this.shape_34 = new cjs.Shape();
        this.shape_34.graphics.f("#000000").s().p("AAUEQIAAnaIgCAAIhdAzIgOg5IB0g/IA/AAIAAIfg");
        this.shape_34.setTransform(811.7, 123.3, 0.15, 0.15);

        this.shape_35 = new cjs.Shape();
        this.shape_35.graphics.f("#000000").s().p("Ai7DpQhPhUAAiLQAAiMBMhbQBPhgB/AAQCFAABDBmQAzBOAABrQAAAMgEAmImoAAQACBqA+A3QA3AyBXAAQBfAABJgfIATBPQhXAnhzAAQiIAAhRhVgAhxiwQgnAygHBFIE/AAQAChEgegxQgpg/hTAAQhKAAgvA9g");
        this.shape_35.setTransform(831.9, 144.3, 0.15, 0.15);

        this.shape_36 = new cjs.Shape();
        this.shape_36.graphics.f("#000000").s().p("ADOGnIkKmsQhnikg3h3IgDACQAICXAADEIAAFqIhmAAIAAtNIB3AAIEMGrQBdCTA7CAIACgBQgMiOAAjNIAAliIBmAAIAANNg");
        this.shape_36.setTransform(820.9, 142.5, 0.15, 0.15);

        this.shape_37 = new cjs.Shape();
        this.shape_37.graphics.f("#00E4F1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_37.setTransform(826, 142.6, 0.15, 0.15);

        this.shape_38 = new cjs.Shape();
        this.shape_38.graphics.f("#000000").s().p("AisEVIAAguIA6g4QBxhrAmg2QAwhAABg6QAAgugYgcQgbggg3AAQg8AAg3AuIgXg0QAegaAlgOQApgQAtAAQBQAAAtAyQAnAsAABBQAABGgyBHQgmA2hhBgIgrAoIAAABIDyAAIAAA+g");
        this.shape_38.setTransform(813, 64.3, 0.15, 0.15);

        this.shape_39 = new cjs.Shape();
        this.shape_39.graphics.f("#000000").s().p("Ai7DpQhPhUAAiLQAAiMBMhbQBPhgB/AAQCFAABDBmQAzBOAABrIgCAeIgCAUImnAAQABBqA+A3QA3AyBXAAQA3AAArgJQAigHAkgPIATBPQhXAnhzAAQiJAAhQhVgAhxiwQgnAxgHBFIFAAAQAAhDgegxQgpg/hSAAQhLAAguA9g");
        this.shape_39.setTransform(831.8, 85.4, 0.15, 0.15);

        this.shape_40 = new cjs.Shape();
        this.shape_40.graphics.f("#000000").s().p("ADLGnIAAmNImXAAIAAGNIhsAAIAAtNIBsAAIAAFjIGXAAIAAljIBuAAIAANNg");
        this.shape_40.setTransform(821, 83.6, 0.15, 0.15);

        this.shape_41 = new cjs.Shape();
        this.shape_41.graphics.f("#00E4F1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_41.setTransform(826, 83.7, 0.15, 0.15);

        this.shape_42 = new cjs.Shape();
        this.shape_42.graphics.f("#000000").s().p("AhjCcQglg4AAhjQAAhjAng4QAmg4A+AAQBAAAAjA4QAjA2AABhQABBmgmA4QgkA3hCAAQg9AAgkg2gAg6h7QgYAuAABOQAABPAXAsQAWAsAlAAQApAAAVguQAUgsAAhOQAAhOgUgrQgUgtgqAAQgkgBgWAsg");
        this.shape_42.setTransform(783, 457.7, 0.15, 0.15);

        this.shape_43 = new cjs.Shape();
        this.shape_43.graphics.f("#000000").s().p("AiMEQIDqngIAAgCIkHAAIAAg9IFTAAIAAAxIjqHug");
        this.shape_43.setTransform(782.2, 417.8, 0.15, 0.15);

        this.shape_44 = new cjs.Shape();
        this.shape_44.graphics.f("#000000").s().p("AATEQIAAnbIgCAAIhcA0IgOg4IB1hAIA+AAIAAIfg");
        this.shape_44.setTransform(775.1, 417.8, 0.15, 0.15);

        this.shape_45 = new cjs.Shape();
        this.shape_45.graphics.f("#000000").s().p("AATEQIAAnbIgCAAIhcA0IgOg5IB0g/IA/AAIAAIfg");
        this.shape_45.setTransform(768.7, 417.8, 0.15, 0.15);

        this.shape_46 = new cjs.Shape();
        this.shape_46.graphics.f("#000000").s().p("Ah5ExQgrgKghgUIAbhUQAcASAkALQArAPAnAAQA3gBAggaQAcgYAAgoQAAgngagZQgZgZg7gXQigg4gBhyQAAhMA4gyQA7g0BdAAQArAAApALQAlAJAbARIgbBRQg3gkhFAAQgtAAgcAZQgaAXgBAkQAAAjAcAXQAZAUA9AYQBRAgAmAnQAoAtAABCQAABSg7AyQg+AzhoAAQgwAAgugMg");
        this.shape_46.setTransform(793.9, 439, 0.15, 0.15);

        this.shape_47 = new cjs.Shape();
        this.shape_47.graphics.f("#000000").s().p("Ai8ECQhEhFgBiRIAAliIBuAAIAAFPQABDCCHAAQAxAAAqggQAkgbAQgpQAKgaAAgfIAAl0IBuAAIAAG5QABBqAEA8IhhAAIgHhjIgCAAQgbAtgsAeQg5AmhGAAQhXAAg2g1g");
        this.shape_47.setTransform(785, 439.1, 0.15, 0.15);

        this.shape_48 = new cjs.Shape();
        this.shape_48.graphics.f("#000000").s().p("AjfFbQhXhbAAi8IAAnxIBuAAIAAHzQAACJA4BGQA0BABZAAQBfAAA1hBQA4hFAAiJIAAnzIBuAAIAAHsQAAC7hbBeQhTBWiQAAQiKAAhOhTg");
        this.shape_48.setTransform(773.8, 437.3, 0.15, 0.15);

        this.shape_49 = new cjs.Shape();
        this.shape_49.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_49.setTransform(783, 437.3, 0.15, 0.15);

        this.shape_50 = new cjs.Shape();
        this.shape_50.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiShNhsIArAAQBQBpAACVQAACShQBtg");
        this.shape_50.setTransform(791.3, 398.1, 0.15, 0.15);

        this.shape_51 = new cjs.Shape();
        this.shape_51.graphics.f("#000000").s().p("AhiCdQgmg5gBhjQAAhjAog5QAmg2A+AAQBAAAAkA2QAjA2AABiQAABmglA4QglA3hCABQg8gBgkg1gAg6h7QgXAtAABQQAABOAWAsQAWAsAlAAQApAAAVguQAVgsAAhOQAAhOgUgrQgWgugpAAQgjAAgXAsg");
        this.shape_51.setTransform(787.8, 397.7, 0.15, 0.15);

        this.shape_52 = new cjs.Shape();
        this.shape_52.graphics.f("#000000").s().p("AAODMIAAljIgBAAIhFAmIgLgqIBXgwIAwAAIAAGXg");
        this.shape_52.setTransform(782.6, 397.7, 0.15, 0.15);

        this.shape_53 = new cjs.Shape();
        this.shape_53.graphics.f("#000000").s().p("AiADPIAAgiIArgqQBVhRAcgoQAkgvAAgrQAAgjgRgVQgVgYgpAAQgsAAgqAiIgSgnQAygpBCAAQA7AAAiAlQAeAhAAAxQgBA0gmA0QgdAqhHBHIghAeIAAABIC2AAIAAAug");
        this.shape_53.setTransform(778.1, 397.7, 0.15, 0.15);

        this.shape_54 = new cjs.Shape();
        this.shape_54.graphics.f("#000000").s().p("AATD/QhQhtAAiRQABiUBPhrIArAAQhNBpAACWQAACOBNBwg");
        this.shape_54.setTransform(774.6, 398.1, 0.15, 0.15);

        this.shape_55 = new cjs.Shape();
        this.shape_55.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAiAKAiAAQA0AAAkggQAnghAAg1QgBg4glgfQgogghMAAQgcAAgwAGIAkkGIEBAAIAAA+IjNAAIgVCMQAZgDATAAQBDAAAwAdQAjAUAUAgQAXAmAAAwQAABRg5A0Qg5A2hWAAQgqAAgmgLg");
        this.shape_55.setTransform(776.3, 359.1, 0.15, 0.15);

        this.shape_56 = new cjs.Shape();
        this.shape_56.graphics.f("#000000").s().p("AiFDtQgxgqAAg+QAAhjBsgtIgBgCQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkgvAWIAAADQA1ATAcAiQAdAlAAAxQAABGg2AsQg0AshNAAQhSAAgzgsgAhSA3QgZAdAAAnQgCArAeAeQAeAfAxAAQAxAAAegbQAegcAAgqQAAgvgggdQgcgag6gRQgvAOgaAegAhDjKQgZAZAAAlQAAAnAdAZQAZAXAwANQAlgMAWgZQAYgaAAgkQAAgkgVgZQgZgcguAAQgqAAgaAag");
        this.shape_56.setTransform(770.1, 359, 0.15, 0.15);

        this.shape_57 = new cjs.Shape();
        this.shape_57.graphics.f("#000000").s().p("AgqFQQgrgtAAhyIAAlJIhdAAIAAhVIBdAAIAAhvIBqgjIAACSICeAAIAABVIieAAIAAFFQAAA7ATAdQAUAfAsAAQAnAAAZgIIAFBTQgpARg5AAQhMgBgpgvg");
        this.shape_57.setTransform(788.6, 379, 0.15, 0.15);

        this.shape_58 = new cjs.Shape();
        this.shape_58.graphics.f("#000000").s().p("ADsGnIhakLIkqAAIhXELIhxAAIEftNICBAAIEhNNgAguisIhTDzID8AAIhSjyQgSgygYhpIgCAAQgVBSgWBIg");
        this.shape_58.setTransform(780, 378.2, 0.15, 0.15);

        this.shape_59 = new cjs.Shape();
        this.shape_59.graphics.f("#95E4CB").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_59.setTransform(783, 378.3, 0.15, 0.15);

        this.shape_60 = new cjs.Shape();
        this.shape_60.graphics.f("#000000").s().p("AhuENQgkgKgWgPIAUg5QATANAdAKQAmAMAiAAQA+AAAhgkQAagdAAgpQAAg2gsgdQgngag3AAIgqAAIAAg1IAqAAQAtAAAhgWQApgaAAgtQAAgjgXgWQgZgZgtAAQgfAAggAMQgbAKgTAOIgUg1QAYgRAkgMQApgNApAAQBKAAArAoQAlAkAAA2QAAArgZAhQgbAigwASIAAACQA0AKAhAiQAkAnAAA3QAABFgyAtQg3AxhbAAQgrAAgogMg");
        this.shape_60.setTransform(776.3, 300.1, 0.15, 0.15);

        this.shape_61 = new cjs.Shape();
        this.shape_61.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAiAKAiAAQA0AAAkggQAnghAAg1QgBg4glgfQgogghMAAQggAAgsAGIAkkGIEBAAIAAA+IjNAAIgVCMQAZgDAUAAQBCAAAwAdQAjAUAUAgQAXAmAAAwQAABRg5A0Qg5A2hWAAQgqAAgmgLg");
        this.shape_61.setTransform(769.9, 300.1, 0.15, 0.15);

        this.shape_62 = new cjs.Shape();
        this.shape_62.graphics.f("#000000").s().p("Ag1GnIAAtNIBrAAIAANNg");
        this.shape_62.setTransform(783, 319.4, 0.15, 0.15);

        this.shape_63 = new cjs.Shape();
        this.shape_63.graphics.f("#95E4CB").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_63.setTransform(783, 319.4, 0.15, 0.15);

        this.shape_64 = new cjs.Shape();
        this.shape_64.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAiAKAiAAQA0AAAlggQAmghAAg1QgBg4glgfQgpgghMAAQgeAAgtAGIAjkGIECAAIAAA+IjNAAIgVCMQAegDAOAAQBCAAAyAdQAiAUAUAgQAXAmAAAwQAABQg5A1Qg5A2hWAAQgqAAgmgLg");
        this.shape_64.setTransform(776.3, 241.2, 0.15, 0.15);

        this.shape_65 = new cjs.Shape();
        this.shape_65.graphics.f("#000000").s().p("AhvENQgjgKgWgPIAUg5QAUANAdAJQAlAMAiAAQA/AAAggjQAbgdgBgpQAAg2gsgdQgmgag4AAIgpAAIAAg1IApAAQAtAAAigWQAogaAAgtQAAgjgWgWQgagZguAAQgdAAggAMQgbAKgUAOIgTg2QAXgRAkgLQAqgNApAAQBJAAArAoQAlAkAAA2QAAArgZAhQgaAigxASIAAACQA1AKAgAiQAkAmAAA4QAABFgyAtQg3AxhbAAQgrAAgpgMg");
        this.shape_65.setTransform(769.9, 241.1, 0.15, 0.15);

        this.shape_66 = new cjs.Shape();
        this.shape_66.graphics.f("#000000").s().p("AiSE3IAAmhQABhtgGhRIBhAAIAEB4IAEAAQAVg9AsglQAtgkA5AAQAPAAAPAEIAABpQgRgEgUAAQg5AAgoAoQglAmgMBAQgEAeAAAVIAAFDg");
        this.shape_66.setTransform(788, 262.2, 0.15, 0.15);

        this.shape_67 = new cjs.Shape();
        this.shape_67.graphics.f("#000000").s().p("AkJGkIAAtAQBTgRB1AAQBQAAA2APQA4AOAnAgQBGA0AABiQAAA9gmAyQgmAzhCAYIAAACQBFASAvAvQA6A7AABXQAABlhIBFQhVBPjMAAQhiAAhIgKgAicFTQAbAGBBAAQBcgBA4gjQBCgrAAhWQAAhThAgqQg6gnhdAAIhbAAgAiclRIAAERIBjAAQBTgBAygoQAwgnAAg/QAAhHg0gjQgugghWAAQg6AAgmAIg");
        this.shape_67.setTransform(779.7, 260.5, 0.15, 0.15);

        this.shape_68 = new cjs.Shape();
        this.shape_68.graphics.f("#95E4CB").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_68.setTransform(783, 260.5, 0.15, 0.15);

        this.shape_69 = new cjs.Shape();
        this.shape_69.graphics.f("#000000").s().p("AiMEQIDqnhIAAgBIkIAAIAAg9IFVAAIAAAxIjrHug");
        this.shape_69.setTransform(775.7, 182.1, 0.15, 0.15);

        this.shape_70 = new cjs.Shape();
        this.shape_70.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAyIgOg4IB0g/IA/AAIAAIfg");
        this.shape_70.setTransform(768.7, 182.1, 0.15, 0.15);

        this.shape_71 = new cjs.Shape();
        this.shape_71.graphics.f("#000000").s().p("Ag2G+IAAt7IBtAAIAAN7g");
        this.shape_71.setTransform(788.8, 201.4, 0.15, 0.15);

        this.shape_72 = new cjs.Shape();
        this.shape_72.graphics.f("#000000").s().p("AjIFGQh3h0AAjLQAAjFB6h7QB6h7DDAAQBGAAA6ANQAtAKAbAPIgaBZQhJgjhiAAQiUAAhYBbQhbBeAACiQAACdBVBcQBXBcCWAAQAyAAAwgJQAvgKAigQIAWBXQgiARg2ALQg/ANhIAAQi3AAhxhvg");
        this.shape_72.setTransform(781.2, 201.8, 0.15, 0.15);

        this.shape_73 = new cjs.Shape();
        this.shape_73.graphics.f("#95E4CB").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_73.setTransform(783, 201.5, 0.15, 0.15);

        this.shape_74 = new cjs.Shape();
        this.shape_74.graphics.f("#000000").s().p("AhlDSIAAgtQAOABAegDQAzgHAhggQArgnAKhGIgBAAQgkAsg6AAQg2AAgigkQghgiAAg1QAAg8AngqQAogrA7AAQA+AAAkAvQAlAuAABPQAAB6hHBEQgwAuhEAIQgVADgUAAIgKAAgAg6iLQgXAcAAArQAAAnAVAYQAWAWAkAAQAYAAAWgMQAUgKALgTQAFgHAAgNQAAg3gTghQgWgjgoAAIgBAAQgiAAgWAcg");
        this.shape_74.setTransform(785.1, 163, 0.15, 0.15);

        this.shape_75 = new cjs.Shape();
        this.shape_75.graphics.f("#000000").s().p("AAODLIAAliIgBAAIhFAmIgLgqIBYgwIAuAAIAAGWg");
        this.shape_75.setTransform(779.8, 163, 0.15, 0.15);

        this.shape_76 = new cjs.Shape();
        this.shape_76.graphics.f("#000000").s().p("AiHEZIAAg9QARACAqgEQBFgKArgrQA5g1APhcIgDAAQgwA7hNAAQhJAAgsgxQgsgtAAhHQAAhQAzg4QA2g6BPAAQBSAAAxA/QAwA+AABpQAABTgbBEQgYA9gqAqQgfAegrATQgmASgtAFQgcAFgYAAIgPAAgAhOi6QgeAlgBA6QAAAzAdAgQAdAeAvAAQAiAAAdgQQAbgNAPgaQAHgKAAgQQAAhKgbgsQgdgvg1AAIgCAAQguAAgdAmg");
        this.shape_76.setTransform(770.1, 123.3, 0.15, 0.15);

        this.shape_77 = new cjs.Shape();
        this.shape_77.graphics.f("#000000").s().p("AjiGnIAAtNIHFAAIAABcIlYAAIAAEZIE9AAIAABZIk9AAIAAF/g");
        this.shape_77.setTransform(783, 142.6, 0.15, 0.15);

        this.shape_78 = new cjs.Shape();
        this.shape_78.graphics.f("#95E4CB").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_78.setTransform(783, 142.6, 0.15, 0.15);

        this.shape_79 = new cjs.Shape();
        this.shape_79.graphics.f("#000000").s().p("Ag9EAQBNhvAAiRQAAiThNhrIArAAQBQBpAACVQAACShQBug");
        this.shape_79.setTransform(748.3, 457.2, 0.15, 0.15);

        this.shape_80 = new cjs.Shape();
        this.shape_80.graphics.f("#000000").s().p("AiBDPIAAgiIArgqQBVhRAcgoQAlgvAAgsQAAgigSgVQgUgYgpAAQgtAAgpAiIgRgnQAwgpBDAAQA7AAAiAlQAdAhAAAxQAAA0gmA0QgdAqhHBHIghAeIAAABIC2AAIAAAug");
        this.shape_80.setTransform(744.7, 456.7, 0.15, 0.15);

        this.shape_81 = new cjs.Shape();
        this.shape_81.graphics.f("#000000").s().p("AhlDSIAAgtQAOABAegDQAzgHAhggQAqgnAMhGIgCAAQgkAsg6AAQg2AAgigkQghgiAAg1QAAg8AngqQAogrA7AAQA+AAAkAvQAkAuAABPQABB6hHBEQgvAuhFAIQgVADgUAAIgKAAgAg6iLQgXAcAAArQAAAnAVAYQAWAWAjAAQAZAAAWgMQAVgKAKgTQAFgHABgNQgBg3gUghQgVgjgoAAIAAAAQgjAAgWAcg");
        this.shape_81.setTransform(740, 456.8, 0.15, 0.15);

        this.shape_82 = new cjs.Shape();
        this.shape_82.graphics.f("#000000").s().p("AiADPIAAgiIArgqQBVhRAbgoQAlgvAAgsQAAgigRgVQgVgYgpAAQgsAAgqAiIgRgnQAwgpBDAAQA7AAAiAlQAeAhAAAxQAAA0gnA0QgdAqhHBHIghAeIAAABIC2AAIAAAug");
        this.shape_82.setTransform(735.1, 456.7, 0.15, 0.15);

        this.shape_83 = new cjs.Shape();
        this.shape_83.graphics.f("#000000").s().p("AATD/QhQhtAAiSQAAiTBQhsIArAAQhNBrAACUQAACPBNBwg");
        this.shape_83.setTransform(731.6, 457.2, 0.15, 0.15);

        this.shape_84 = new cjs.Shape();
        this.shape_84.graphics.f("#000000").s().p("AiEDaQg1hAAAhqQAAhLAahCQAYg8AqgqQBFhEBngNQAYgEAdAAIAAA9QgXgCggAFQhQAOgzA4QguAzgKBJIADAAQAVgcAggRQAjgSApAAQBIAAAuAwQAuAvAABPQAABOgwA3Qg0A7hRAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAOAAATQABBGAeAqQAgAsA2AAIABAAQAvAAAdgkQAdglAAg6QAAg6gegiQgfgfgyAAQgfAAgdATg");
        this.shape_84.setTransform(739, 418.1, 0.15, 0.15);

        this.shape_85 = new cjs.Shape();
        this.shape_85.graphics.f("#000000").s().p("AATEQIAAnbIgCAAIhcA0IgOg4IB0hAIA/AAIAAIfg");
        this.shape_85.setTransform(732.1, 418.1, 0.15, 0.15);

        this.shape_86 = new cjs.Shape();
        this.shape_86.graphics.f("#000000").s().p("AATEQIAAnbIgBAAIhdA0IgOg5IB0g/IA/AAIAAIfg");
        this.shape_86.setTransform(725.6, 418.1, 0.15, 0.15);

        this.shape_87 = new cjs.Shape();
        this.shape_87.graphics.f("#000000").s().p("ACTG+IAAleQABhQgggtQgkg1hJAAQgxAAgqAgQgnAfgPAtQgIARAAAkIAAFvIhvAAIAAt7IBvAAIAAF8IADAAQAbgyA0gcQA1ggA5AAQBQABA4AzQBLBEAACLIAAFqg");
        this.shape_87.setTransform(751.2, 437.3, 0.15, 0.15);

        this.shape_88 = new cjs.Shape();
        this.shape_88.graphics.f("#000000").s().p("Ai7ECQhGhFAAiRIAAliIBuAAIAAFPQAADCCIAAQAxAAAqggQAjgcARgpQAKgbAAgdIAAl0IBvAAIAAG5QgBBqAFA8IhhAAIgHhkIgCAAQgbAugsAdQg5AnhHAAQhWAAg1g1g");
        this.shape_88.setTransform(740.8, 439.6, 0.15, 0.15);

        this.shape_89 = new cjs.Shape();
        this.shape_89.graphics.f("#000000").s().p("AjfFcQhXhdAAi7IAAnxIBvAAIAAHzQAACJA4BGQAzBABZAAQBfAAA1hBQA4hFAAiJIAAnzIBuAAIAAHsQAAC6hbBfQhTBWiQAAQiKAAhOhSg");
        this.shape_89.setTransform(729.5, 437.8, 0.15, 0.15);

        this.shape_90 = new cjs.Shape();
        this.shape_90.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_90.setTransform(739.9, 437.4, 0.15, 0.15);

        this.shape_91 = new cjs.Shape();
        this.shape_91.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiShNhtIArAAQBQBqAACVQAACShQBtg");
        this.shape_91.setTransform(748.3, 398.2, 0.15, 0.15);

        this.shape_92 = new cjs.Shape();
        this.shape_92.graphics.f("#000000").s().p("AhiCcQgmg3gBhkQAAhjAog5QAmg2A+AAQBAAAAkA2QAjA3AABhQAABmglA4QglA3hCABQg8gBgkg2gAg6h7QgXAuAABOQAABPAWAsQAWAsAlAAQApAAAVguQAVgsAAhOQAAhOgUgrQgWgtgpAAQgjAAgXArg");
        this.shape_92.setTransform(744.8, 397.9, 0.15, 0.15);

        this.shape_93 = new cjs.Shape();
        this.shape_93.graphics.f("#000000").s().p("AAODMIAAljIgBAAIhEAmIgMgqIBYgwIAvAAIAAGXg");
        this.shape_93.setTransform(739.5, 397.9, 0.15, 0.15);

        this.shape_94 = new cjs.Shape();
        this.shape_94.graphics.f("#000000").s().p("AiADPIAAgiIArgqQBVhRAbgoQAlgvAAgsQAAgigRgVQgVgYgpAAQgsAAgqAiIgRgnQAwgpBDAAQA7AAAiAlQAeAhAAAxQAAA0gnA0QgdAqhHBHIghAeIAAABIC2AAIAAAug");
        this.shape_94.setTransform(735.1, 397.8, 0.15, 0.15);

        this.shape_95 = new cjs.Shape();
        this.shape_95.graphics.f("#000000").s().p("AATD/QhQhsAAiTQAAiTBQhsIArAAQhNBsAACTQAACQBNBvg");
        this.shape_95.setTransform(731.6, 398.2, 0.15, 0.15);

        this.shape_96 = new cjs.Shape();
        this.shape_96.graphics.f("#000000").s().p("AA1EQIAAiVIj6AAIAAgwIDwlaIBPAAIAAFRIBMAAIAAA5IhMAAIAACVgAAIh3IiDC3IAAACICwAAIAAi0QAAgmACgwIgCAAQgTAlgaAsg");
        this.shape_96.setTransform(733.4, 359.1, 0.15, 0.15);

        this.shape_97 = new cjs.Shape();
        this.shape_97.graphics.f("#000000").s().p("AiFDtQgxgpAAg+QAAgzAdglQAbgkA0gUIgBgDQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkgvAWIAAADQA1ATAcAiQAdAlAAAxQAABGg2AsQg0AshNAAQhSAAgzgsgAhSA3QgZAdAAAnQgCArAeAeQAeAfAxAAQAxAAAegbQAdgbAAgrQAAgvgggdQgcgag5gRQgvAOgaAegAhDjKQgZAZAAAlQAAAnAdAZQAZAXAwANQAlgMAWgZQAYgaAAgkQAAgkgVgZQgZgcguAAQgqAAgaAag");
        this.shape_97.setTransform(727, 359.1, 0.15, 0.15);

        this.shape_98 = new cjs.Shape();
        this.shape_98.graphics.f("#000000").s().p("AjTDpQhUhXABiOQgBiSBYhaQBThVCAAAQCCAABRBXQBQBXAACLQAACchfBYQhUBOh4AAQh+AAhRhVgAiKifQgtBCAABeQAABkAzBDQA1BDBPAAQBOAAA0hDQA1hDAAhlQAAhagqhBQgyhPhaAAQhZAAgyBLg");
        this.shape_98.setTransform(744.3, 380.2, 0.15, 0.15);

        this.shape_99 = new cjs.Shape();
        this.shape_99.graphics.f("#000000").s().p("AkDGqIAAtDQBngRBqAAQCdAABOBHQAkAfATAtQAUAuAAA3QgBBxhBBCQgrAuhEAYQhCAXhPABQg6gBgegHIAAFTgAiWlKIAAFKQAiAGA4AAQBiAAA4gsQA5gvAAhYQgBhRg2gsQg0gphbAAQhIABgfAIg");
        this.shape_99.setTransform(735, 378.4, 0.15, 0.15);

        this.shape_100 = new cjs.Shape();
        this.shape_100.graphics.f("#BCB98F").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_100.setTransform(739.9, 378.5, 0.15, 0.15);

        this.shape_101 = new cjs.Shape();
        this.shape_101.graphics.f("#000000").s().p("AisEVIAAguIA6g4QBxhsAmg1QAxg/AAg7QAAgvgXgbQgcghg3AAQg8AAg3AuIgXgzQBBg4BYAAQBQAAAtAzQAoArAABBQAABFgzBIQgmA2hgBfIgsApIAAACIDyAAIAAA9g");
        this.shape_101.setTransform(733.3, 300.1, 0.15, 0.15);

        this.shape_102 = new cjs.Shape();
        this.shape_102.graphics.f("#000000").s().p("AhwEKQghgJgWgOIASg4QAUAMAcAIQAiAKAiAAQA0AAAkggQAnghAAg1QgBg4glgfQgogghMAAQggAAgsAGIAkkGIEBAAIAAA+IjNAAIgVCMQAZgDATAAQBDAAAwAdQAjAUAUAgQAXAmAAAwQAABRg5A0Qg5A2hWAAQgpAAgngLg");
        this.shape_102.setTransform(726.8, 300.3, 0.15, 0.15);

        this.shape_103 = new cjs.Shape();
        this.shape_103.graphics.f("#000000").s().p("Ai7DpQhPhUAAiLQAAiLBMhdQBPheB/gBQCFABBDBlQAzBNAABsQAAAWgEAbImoAAQACBrA+A3QA3AyBXAAQA2AAAsgJQAigHAkgQIATBPQhVAoh1gBQiJABhQhVgAhyiwQgmAxgIBFIFBAAQABhDgfgxQgohAhUAAQhJAAgwA+g");
        this.shape_103.setTransform(744.3, 321.2, 0.15, 0.15);

        this.shape_104 = new cjs.Shape();
        this.shape_104.graphics.f("#000000").s().p("Ag3GnIAArwIkAAAIAAhdIJvAAIAABdIkCAAIAALwg");
        this.shape_104.setTransform(736.2, 319.5, 0.15, 0.15);

        this.shape_105 = new cjs.Shape();
        this.shape_105.graphics.f("#BCB98F").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_105.setTransform(739.9, 319.6, 0.15, 0.15);

        this.shape_106 = new cjs.Shape();
        this.shape_106.graphics.f("#000000").s().p("AA1EQIAAiUIj6AAIAAgxIDwlaIBPAAIAAFRIBMAAIAAA6IhMAAIAACUgAAIh3IiDC3IAAACICwAAIAAi0QAAgyADgkIgDAAQgUAmgZArg");
        this.shape_106.setTransform(733.3, 241.3, 0.15, 0.15);

        this.shape_107 = new cjs.Shape();
        this.shape_107.graphics.f("#000000").s().p("AhvENQgjgKgWgPIAUg5QAUANAdAKQAlAMAiAAQA+AAAhgkQAbgdgBgpQAAg2gsgdQgngag4AAIgoAAIAAg1IAoAAQAuAAAhgWQApgaAAgtQAAgjgXgWQgZgZguAAQgeAAgfAMQgaAKgVAOIgUg1QAYgRAlgMQApgNApAAQBJAAArAoQAlAkAAA2QAAArgZAhQgaAigxASIAAACQA0AKAhAiQAkAnAAA3QAABFgyAtQg3AxhbAAQgrAAgpgMg");
        this.shape_107.setTransform(726.8, 241.3, 0.15, 0.15);

        this.shape_108 = new cjs.Shape();
        this.shape_108.graphics.f("#000000").s().p("Ai7DoQhPhTAAiMQAAiLBMhcQBOheCAAAQCFAABDBlQAzBNAABsQAAAVgEAcImoAAQACBqA+A5QA3AxBXAAQA2AAAsgJQAigIAkgPIATBPQhXAnhzAAQiIAAhRhVgAhyixQgmAzgIBEIFBAAQAAhEgegwQgog/hUAAQhJAAgwA8g");
        this.shape_108.setTransform(744.6, 262.4, 0.15, 0.15);

        this.shape_109 = new cjs.Shape();
        this.shape_109.graphics.f("#000000").s().p("AigGkQg8gPgigXIAbhcQAoAYAwAPQA3AQA1AAQBQAAAwgoQAugnABhBQAAg8glgmQglgmhUghQhsglg3g3Qg8g8AAhWQAAhkBLhAQBNhCB3AAQByAABJApIgeBZQhKgnhWgBQhOAAgrAqQgkAjAAAzQAAA4AoAmQAkAhBZAkQBvAqAzA2QA2A8AABbQAABohJBEQhRBJiMAAQg7AAg+gRg");
        this.shape_109.setTransform(735.1, 260.6, 0.15, 0.15);

        this.shape_110 = new cjs.Shape();
        this.shape_110.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_110.setTransform(739.9, 260.6, 0.15, 0.15);

        this.shape_111 = new cjs.Shape();
        this.shape_111.graphics.f("#000000").s().p("AiEDaQg1g/AAhrQAAhLAahCQAYg8AqgqQBEhEBogNQAZgEAcAAIAAA8QgcgBgbAFQhQAOgyA4QguAzgKBJIACAAQAVgcAggRQAkgSAoAAQBJAAAtAwQAuAuAABQQAABOgwA3QgzA7hRAAQhWAAg0g/gAg8gLQgcAQgQAeQgIANAAAUQABBGAfAqQAgAsA2AAIAAAAQAvAAAdgkQAeglAAg6QAAg6gfgiQgegfgzAAQgfAAgdATg");
        this.shape_111.setTransform(732.6, 182.3, 0.15, 0.15);

        this.shape_112 = new cjs.Shape();
        this.shape_112.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_112.setTransform(725.6, 182.3, 0.15, 0.15);

        this.shape_113 = new cjs.Shape();
        this.shape_113.graphics.f("#000000").s().p("AigGlQg7gQgjgXIAbhcQAoAZAwAOQA3ARA1gBQBRAAAvgoQAugnAAhBQAAg8gkgmQglgmhUghQhtglg1g2Qg9g9AAhWQABhkBLhAQBMhCB4AAQByAABIApIgeBZQhKgohWABQhOAAgrApQglAjABAzQgBA4ApAmQAkAhBZAkQBvArAzA2QA2A7AABbQAABohJBDQhRBKiMAAQg7AAg+gQg");
        this.shape_113.setTransform(739.9, 201.7, 0.15, 0.15);

        this.shape_114 = new cjs.Shape();
        this.shape_114.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_114.setTransform(739.9, 201.7, 0.15, 0.15);

        this.shape_115 = new cjs.Shape();
        this.shape_115.graphics.f("#000000").s().p("AhjCjQgngvAAhQQAAg4ATgwQASguAgggQA0gzBMgJQATgDAVAAIAAAtQgUgBgVADQg8ALgmArQgiAmgIA2IACAAQAQgWAYgMQAagNAeAAQA3gBAiAlQAiAiAAA7QAAA7gkApQgmAsg9AAQhAAAgngvgAgtgIQgVALgLAXQgHALAAANQABA1AXAgQAYAgAoAAIAAAAQAkAAAWgbQAWgbAAgrQAAgsgXgZQgXgXgmAAQgXAAgWAOg");
        this.shape_115.setTransform(742, 163.2, 0.15, 0.15);

        this.shape_116 = new cjs.Shape();
        this.shape_116.graphics.f("#000000").s().p("AAODMIAAljIgBAAIhFAmIgLgqIBXgwIAwAAIAAGXg");
        this.shape_116.setTransform(736.8, 163.2, 0.15, 0.15);

        this.shape_117 = new cjs.Shape();
        this.shape_117.graphics.f("#000000").s().p("AiFDtQgxgqAAg+QAAgyAdglQAbgkA0gUIgBgDQgrgUgXgiQgUgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkgvAWIAAADQA1ATAcAiQAdAlAAAxQAABGg2AsQg0AshNAAQhSAAgzgsgAhSA3QgZAdAAAnQgCArAeAeQAeAfAxAAQAwAAAfgcQAdgbAAgqQAAgvgggdQgcgag5gRQgvAOgaAegAhDjKQgZAZAAAlQAAAnAdAZQAZAXAwANQAlgMAWgZQAYgaAAgkQAAgkgVgZQgZgcguAAQgqAAgaAag");
        this.shape_117.setTransform(727, 123.4, 0.15, 0.15);

        this.shape_118 = new cjs.Shape();
        this.shape_118.graphics.f("#000000").s().p("AkWE+Qhqh4AAi/QAAjFBvh8QBuh6CpAAQCrAABpB4QBnB2AAC+QAADRhzB7QhsBxinAAQioAAhph3gAjIjwQhEBiAACTQAACOBHBhQBLBoB6AAQB9AABLhoQBGhiAAiUQAAiLhChhQhLhtiAAAQh/AAhKBrg");
        this.shape_118.setTransform(739.9, 142.8, 0.15, 0.15);

        this.shape_119 = new cjs.Shape();
        this.shape_119.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_119.setTransform(739.9, 142.8, 0.15, 0.15);

        this.shape_120 = new cjs.Shape();
        this.shape_120.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiThNhrIArAAQBQBpAACVQAACThQBsg");
        this.shape_120.setTransform(705.2, 457, 0.15, 0.15);

        this.shape_121 = new cjs.Shape();
        this.shape_121.graphics.f("#000000").s().p("AhkCyQgkggAAguQAAhLBRggIgBgCQgggPgRgaQgPgXAAgbQAAgxAkgfQAjgeA1AAQA4AAAhAgQAdAcAAApQAAA/hDAgIAAACQAnAOAVAaQAWAbAAAlQAAA1goAhQgnAhg6gBQg9ABgnghgAg9ApQgTAWAAAdQgBAhAWAWQAXAYAkgBQAkAAAXgUQAWgVAAggQAAgjgYgVQgVgUgqgNQgkALgTAWgAgyiXQgSATAAAbQAAA3BLAVQAcgKAQgRQASgUAAgbQAAgcgQgSQgSgVgjAAQgfAAgTATg");
        this.shape_121.setTransform(701.7, 456.6, 0.15, 0.15);

        this.shape_122 = new cjs.Shape();
        this.shape_122.graphics.f("#000000").s().p("AhkCyQgkggAAguQAAgmAWgcQAUgbAngOIgBgCQgggQgRgZQgPgWAAgdQAAgvAkggQAjgeA0AAQA4AAAhAgQAeAcAAApQAABAhDAgIAAABQAnAOAVAaQAWAbAAAlQAAA0goAiQgnAhg6gBQg+ABgmghgAg9ApQgSAWgBAdQgBAhAWAWQAXAXAkAAQAlAAAXgUQAVgVAAggQAAgjgYgWQgVgTgrgNQgjALgTAWgAgyiXQgSATAAAbQAAA4BLAUQAcgKAQgSQATgTAAgbQAAgcgRgSQgSgVgjAAQgfAAgTATg");
        this.shape_122.setTransform(696.9, 456.6, 0.15, 0.15);

        this.shape_123 = new cjs.Shape();
        this.shape_123.graphics.f("#000000").s().p("AiBDPIAAgiIArgqQBVhRAcgoQAlgvAAgrQAAgjgSgUQgUgZgpAAQgsAAgqAjIgRgoQAwgpBCAAQA8AAAiAmQAeAgAAAxQAAA0gnA1QgdAphHBHIghAeIAAABIC1AAIAAAug");
        this.shape_123.setTransform(692, 456.6, 0.15, 0.15);

        this.shape_124 = new cjs.Shape();
        this.shape_124.graphics.f("#000000").s().p("AATD/QhQhsAAiSQABiTBPhsIArAAQhNBrAACUQAACPBNBvg");
        this.shape_124.setTransform(688.5, 457, 0.15, 0.15);

        this.shape_125 = new cjs.Shape();
        this.shape_125.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAiAKAiAAQA0AAAkggQAnghAAg1QgBg3glggQgogghMAAQgbAAgwAGIAjkFIEBAAIAAA9IjNAAIgVCMQAWgDAXAAQBBAAAyAdQAiAUAUAgQAXAmAAAxQAABPg5A2Qg5A1hWAAQgqAAgmgLg");
        this.shape_125.setTransform(695.8, 417.9, 0.15, 0.15);

        this.shape_126 = new cjs.Shape();
        this.shape_126.graphics.f("#000000").s().p("AATEQIAAnbIgCAAIhcAzIgOg4IB0g/IA/AAIAAIfg");
        this.shape_126.setTransform(689, 417.8, 0.15, 0.15);

        this.shape_127 = new cjs.Shape();
        this.shape_127.graphics.f("#000000").s().p("AATEQIAAnbIgBAAIhdAzIgOg3IB1hAIA+AAIAAIfg");
        this.shape_127.setTransform(682.6, 417.8, 0.15, 0.15);

        this.shape_128 = new cjs.Shape();
        this.shape_128.graphics.f("#000000").s().p("AkbGzIAAqRQAAhSgFh1IBjAAIAFBpIADAAQBIh2CNAAQBvAABIBVQBKBXAACJQAACahVBZQhMBShzAAQg6AAgygZQgxgZgbguIgDAAIAAFLgAhnk1QgwAngPA9QgIAZAAAUIAABpQAAARAFAcQAPA4AuAkQAtAjA7AAQBUAAAyhBQAwg+AAhqQAAhggug/QgyhDhSAAQg5AAguAlg");
        this.shape_128.setTransform(708.1, 439, 0.15, 0.15);

        this.shape_129 = new cjs.Shape();
        this.shape_129.graphics.f("#000000").s().p("Ai7ECQhGhEAAiSIAAliIBvAAIAAFPQAADCCHAAQAxAAAqggQAkgcAQgpQAKgaAAgeIAAl0IBuAAIAAG5QAABiAFBEIhhAAIgHhjIgCAAQgaAtgtAeQg4AmhHAAQhXAAg1g1g");
        this.shape_129.setTransform(697.3, 437.3, 0.15, 0.15);

        this.shape_130 = new cjs.Shape();
        this.shape_130.graphics.f("#000000").s().p("AjfFbQhXhcABi7IAAnxIBtAAIAAH0QAACIA4BGQAzBABaAAQBfAAA1hBQA3hFAAiIIAAn0IBuAAIAAHsQAAC6hbBfQhSBWiPAAQiMAAhNhTg");
        this.shape_130.setTransform(686, 435.5, 0.15, 0.15);

        this.shape_131 = new cjs.Shape();
        this.shape_131.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_131.setTransform(696.9, 437.3, 0.15, 0.15);

        this.shape_132 = new cjs.Shape();
        this.shape_132.graphics.f("#000000").s().p("AhlDSIAAgtQAOABAfgDQAzgHAgggQArgoALhFIgCAAQgkAsg6AAQg2AAgigkQggghAAg2QAAg8AmgqQAogrA7AAQA+AAAkAvQAkAuAABPQAAB6hGBEQgwAuhEAIQgXADgRAAIgLAAgAg6iLQgXAcAAArQAAAnAVAYQAWAWAjAAQAZAAAWgMQAUgKAMgTQAFgIAAgMQAAg3gUggQgWgkgoAAIAAAAQgjAAgWAcg");
        this.shape_132.setTransform(701.7, 398.7, 0.15, 0.15);

        this.shape_133 = new cjs.Shape();
        this.shape_133.graphics.f("#000000").s().p("AhjCcQglg3gBhkQAAhjAog5QAmg3A+AAQBAAAAkA3QAjA2AABiQAABmglA4QglA4hCAAQg9AAgkg3gAg6h7QgYAtAABPQAABPAXAsQAWAsAlAAQApAAAVguQAVgsAAhOQAAhOgUgrQgWgugpAAQgjAAgXAsg");
        this.shape_133.setTransform(696.8, 398.7, 0.15, 0.15);

        this.shape_134 = new cjs.Shape();
        this.shape_134.graphics.f("#000000").s().p("AiADPIAAgiIArgqQBVhRAbgoQAlgvABgrQAAgjgSgVQgVgYgpAAQgsAAgqAiIgSgnQAzgpBBAAQA7AAAiAlQAdAhABAxQAAA0gnA0QgcAphIBIIghAeIAAABIC2AAIAAAug");
        this.shape_134.setTransform(692, 398.7, 0.15, 0.15);

        this.shape_135 = new cjs.Shape();
        this.shape_135.graphics.f("#000000").s().p("AhvENQgjgKgWgPIAUg5QATANAdAKQAlAMAjAAQA+AAAhgkQAbgdgBgpQAAg2gsgdQgngag4AAIgpAAIAAg1IApAAQAuAAAhgWQAogaAAgtQAAgjgWgWQgZgZguAAQgeAAgfAMQgbAKgUAOIgUg2QAYgRAkgLQAqgNAoAAQBKAAArAoQAlAkAAA2QAAArgZAhQgaAigyASIAAACQA1AKAhAiQAkAnAAA3QAABFgyAtQg2AxhcAAQgrAAgpgMg");
        this.shape_135.setTransform(690.3, 359, 0.15, 0.15);

        this.shape_136 = new cjs.Shape();
        this.shape_136.graphics.f("#000000").s().p("AiFDtQgxgpAAg+QAAhkBsgsIgBgDQgrgUgXgiQgUgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkgvAWIAAADQA0ATAcAiQAeAlAAAxQAABGg2AsQg0AshNAAQhSAAgzgsgAhSA3QgZAdAAAnQgCArAeAeQAeAfAxAAQAxAAAegbQAdgbAAgrQAAgvgggdQgcgag5gRQgvAOgaAegAhDjKQgZAZAAAlQAAAnAdAZQAZAXAwANQAlgMAWgZQAYgaAAgkQAAgkgVgZQgZgcguAAQgqAAgaAag");
        this.shape_136.setTransform(684, 359, 0.15, 0.15);

        this.shape_137 = new cjs.Shape();
        this.shape_137.graphics.f("#000000").s().p("Ag1GoIAApfIBsAAIAAJfgAgwkyQgTgTAAgdQAAgdAUgUQATgUAcAAQAfAAATAUQASATAAAeQABAdgTATQgUAUgeAAQgdAAgTgUg");
        this.shape_137.setTransform(701.8, 378.3, 0.15, 0.15);

        this.shape_138 = new cjs.Shape();
        this.shape_138.graphics.f("#000000").s().p("AkIGkIAAs/QBSgSB0AAQBQAAA4AOQA3APAoAgQBFA1AABhQAAA+gmAyQgmAxhDAZIAAADQBGARAwAwQA4A6AABXQAABkhHBGQgrAohJAUQhIAThmAAQhfAAhJgKgAicFTQAbAFBBAAQBcAAA4gkQBCgqAAhWQAAhShAgrQg6gmheAAIhaAAgAiclSIAAERIBjAAQBTAAAygoQAwgnAAg+QAAhIgzgjQgvgghVAAQg7AAgmAHg");
        this.shape_138.setTransform(694.9, 378.3, 0.15, 0.15);

        this.shape_139 = new cjs.Shape();
        this.shape_139.graphics.f("#FFE2B6").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_139.setTransform(696.9, 378.3, 0.15, 0.15);

        this.shape_140 = new cjs.Shape();
        this.shape_140.graphics.f("#000000").s().p("AATEQIAAnbIgCAAIhcAzIgOg4IB1g/IA+AAIAAIfg");
        this.shape_140.setTransform(689.8, 299.9, 0.15, 0.15);

        this.shape_141 = new cjs.Shape();
        this.shape_141.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAjAKAhAAQA0AAAkgfQAngiAAg1QgBg3glggQgogghNAAQgbAAgwAGIAjkFIECAAIAAA9IjNAAIgVCMQAdgDAPAAQBCAAAyAdQAiAUAUAgQAXAlAAAxQAABRg5A0Qg5A1hWAAQgpAAgngKg");
        this.shape_141.setTransform(683.8, 300, 0.15, 0.15);

        this.shape_142 = new cjs.Shape();
        this.shape_142.graphics.f("#000000").s().p("Ai4FSIgDAAIgFBlIhgAAQAFhTAAhKIAAreIBtAAIAAF/IADAAQAeg1AzgdQA2gfBGAAQBxAABHBWQBIBYgBCHQAACahVBbQhNBRhuAAQiJAAhAhzgAhng5QgwAmgQA7QgHAhAAAMIAABuQAAAOAFAbQARA5AsAkQAtAkA8AAQBTAAAyhBQAxg/AAhqQAAhhgug8QgyhDhTAAQg5AAguAkg");
        this.shape_142.setTransform(701.8, 319.4, 0.15, 0.15);

        this.shape_143 = new cjs.Shape();
        this.shape_143.graphics.f("#000000").s().p("AigGlQg7gQgjgXIAbhcQAoAYAwAPQA2AQA2AAQBQAAAwgoQAugnAAhBQAAg7gkgnQgkglhVgiQhtgkg2g3Qg8g9AAhWQAAhkBLhAQBNhCB3AAQBxAABKApIgeBaQhKgphWAAQhOAAgrAqQgkAjAAAyQAAA6AoAlQAkAiBZAjQBwArAyA1QA2A8AABbQAABohJBEQhRBJiMAAQg7AAg+gQg");
        this.shape_143.setTransform(691.5, 319.6, 0.15, 0.15);

        this.shape_144 = new cjs.Shape();
        this.shape_144.graphics.f("#BCB98F").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_144.setTransform(696.9, 319.4, 0.15, 0.15);

        this.shape_145 = new cjs.Shape();
        this.shape_145.graphics.f("#000000").s().p("AhvENQgjgKgWgPIAUg5QAUANAdAKQAlAMAiAAQA+AAAigkQAagdgBgpQgBg2grgdQgmgag4AAIgpAAIAAg1IApAAQAtAAAhgWQApgaAAgtQAAgjgWgWQgZgZgvAAQgdAAggAMQgbAKgUAOIgTg2QAXgRAlgLQApgNApAAQBJAAArAoQAlAjAAA3QAAArgZAhQgaAigxASIAAACQA0AKAhAiQAkAmAAA4QAABFgyAtQg2AxhcAAQgrAAgpgMg");
        this.shape_145.setTransform(690.2, 241.1, 0.15, 0.15);

        this.shape_146 = new cjs.Shape();
        this.shape_146.graphics.f("#000000").s().p("AhvENQgjgKgWgPIAUg5QATANAeAKQAlAMAiAAQA+AAAigkQAagdgBgpQgBg2grgdQgngag4AAIgpAAIAAg1IApAAQAuAAAhgWQAogaAAgtQAAgjgWgWQgZgZguAAQgdAAggAMQgbAKgUAOIgUg2QAYgRAkgLQAqgNAoAAQBKAAArAoQAlAkAAA2QAAArgZAhQgaAigxASIAAACQA0AKAiAiQAjAnAAA3QAABFgyAtQg3AxhbAAQgrAAgpgMg");
        this.shape_146.setTransform(683.8, 241.1, 0.15, 0.15);

        this.shape_147 = new cjs.Shape();
        this.shape_147.graphics.f("#000000").s().p("Ah5ExQgrgKghgUIAbhUQAbARAmANQAqAOAnAAQA3AAAggbQAdgYAAgoQAAgngagZQgagZg7gXQhQgdgpgqQgogrAAg4QAAhMA4gyQA6g0BdgBQAsAAApAMQAlAJAcARIgcBQQg3gjhFAAQgtAAgcAZQgaAXAAAkQAAAkAcAXQAYATA9AZQBRAfAmAoQAoAsAABCQAABSg7AyQg+AzhnABQgxAAgugNg");
        this.shape_147.setTransform(702.7, 262.2, 0.15, 0.15);

        this.shape_148 = new cjs.Shape();
        this.shape_148.graphics.f("#000000").s().p("ADsGnIhakLIkpAAIhYELIhxAAIEftNICCAAIEgNNgAguisIhTDzID9AAIhTjyQgRgygZhpIgCAAQgZBigSA4g");
        this.shape_148.setTransform(693.4, 260.4, 0.15, 0.15);

        this.shape_149 = new cjs.Shape();
        this.shape_149.graphics.f("#BCB98F").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_149.setTransform(696.9, 260.5, 0.15, 0.15);

        this.shape_150 = new cjs.Shape();
        this.shape_150.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAiAKAiAAQA0AAAlgfQAmgiAAg1QgBg4glgfQgogghNAAQgbAAgvAGIAjkGIECAAIAAA/IjOAAIgVCMQAegEAOAAQBCAAAxAdQAjAUAUAgQAXAlAAAxQAABRg4A0Qg6A1hWABQgqAAgmgLg");
        this.shape_150.setTransform(689.4, 182.1, 0.15, 0.15);

        this.shape_151 = new cjs.Shape();
        this.shape_151.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg5IB1g/IA+AAIAAIfg");
        this.shape_151.setTransform(682.6, 182.1, 0.15, 0.15);

        this.shape_152 = new cjs.Shape();
        this.shape_152.graphics.f("#000000").s().p("AkCGrIAAtEQBggRBxAAQCdAABOBHQAjAfATAsQATAvAAA3QAAByhBBCQgqAthEAYQhDAXhPAAQg4AAgfgHIAAFUgAiVlKIAAFKQAgAGA6AAQBhAAA4gsQA5gwAAhXQAAhRg3gsQg0gphbAAQhHAAgfAJg");
        this.shape_152.setTransform(696.9, 201.5, 0.15, 0.15);

        this.shape_153 = new cjs.Shape();
        this.shape_153.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_153.setTransform(696.9, 201.5, 0.15, 0.15);

        this.shape_154 = new cjs.Shape();
        this.shape_154.graphics.f("#000000").s().p("AiMEQIDqnhIAAgBIkHAAIAAg9IFTAAIAAAwIjqHvg");
        this.shape_154.setTransform(683.8, 123.1, 0.15, 0.15);

        this.shape_155 = new cjs.Shape();
        this.shape_155.graphics.f("#000000").s().p("ADOGnIkKmsQhnikg3h3IgDACQAICXAADEIAAFqIhmAAIAAtNIB3AAIEMGrQBdCTA7CAIACgBQgMiOAAjMIAAljIBmAAIAANNg");
        this.shape_155.setTransform(696.9, 142.6, 0.15, 0.15);

        this.shape_156 = new cjs.Shape();
        this.shape_156.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_156.setTransform(696.9, 142.6, 0.15, 0.15);

        this.shape_157 = new cjs.Shape();
        this.shape_157.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACThQBsg");
        this.shape_157.setTransform(662.2, 457, 0.15, 0.15);

        this.shape_158 = new cjs.Shape();
        this.shape_158.graphics.f("#000000").s().p("AhlDSIAAgtQAPABAdgDQAzgHAhggQArgnALhGIgCAAQgkAsg6AAQg2AAgigkQghgiAAg1QAAg8AngqQAogrA7AAQA+AAAkAvQAkAuAABPQAAB6hGBEQgvAuhFAIQgVADgUAAIgKAAgAg7iLQgWAcAAArQAAAnAVAYQAWAWAkAAQAYAAAWgMQAUgKALgTQAGgIAAgMQAAg3gUghQgWgjgoAAIgBAAQgiAAgXAcg");
        this.shape_158.setTransform(658.7, 456.6, 0.15, 0.15);

        this.shape_159 = new cjs.Shape();
        this.shape_159.graphics.f("#000000").s().p("AhkCyQgkggAAguQAAhMBRgfIgBgCQghgPgQgaQgQgXAAgcQAAgvAkggQAkgdA0gBQA5AAAhAgQAdAcAAApQAABAhDAgIAAACQAnANAVAaQAWAcAAAkQAAA0goAiQgnAgg6AAQg+AAgmgggAg9ApQgTAWAAAdQgBAhAWAWQAXAYAkAAQAlgBAWgUQAWgVABgfQAAgkgZgWQgVgTgqgNQgkALgTAWgAgyiWQgTASABAbQAAA3BLAVQAcgJARgSQARgVABgaQAAgcgRgSQgSgVgiAAQggAAgTAUg");
        this.shape_159.setTransform(653.8, 456.6, 0.15, 0.15);

        this.shape_160 = new cjs.Shape();
        this.shape_160.graphics.f("#000000").s().p("AiADPIAAgiIAqgqQBVhRAcgoQAkgvABgrQAAgjgRgVQgWgYgoAAQgtAAgpAiIgSgnQAxgpBDAAQA7AAAiAlQAeAhAAAxQAAA0gnA0QgdAqhHBHIghAeIAAABIC1AAIAAAug");
        this.shape_160.setTransform(649, 456.6, 0.15, 0.15);

        this.shape_161 = new cjs.Shape();
        this.shape_161.graphics.f("#000000").s().p("AATD/QhQhsAAiSQABiTBPhsIArAAQhNBpAACWQAACPBNBvg");
        this.shape_161.setTransform(645.5, 457, 0.15, 0.15);

        this.shape_162 = new cjs.Shape();
        this.shape_162.graphics.f("#000000").s().p("AA1EQIAAiVIj6AAIAAgwIDwlaIBPAAIAAFRIBMAAIAAA5IhMAAIAACVgAAIh3IiDC3IAAACICwAAIAAi1QAAgmACgvIgCAAQgUAngZAqg");
        this.shape_162.setTransform(652.9, 417.8, 0.15, 0.15);

        this.shape_163 = new cjs.Shape();
        this.shape_163.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_163.setTransform(646, 417.8, 0.15, 0.15);

        this.shape_164 = new cjs.Shape();
        this.shape_164.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_164.setTransform(639.5, 417.8, 0.15, 0.15);

        this.shape_165 = new cjs.Shape();
        this.shape_165.graphics.f("#000000").s().p("ACrGzIAAlXIgDAAQgaAxgwAbQg1AghEAAQhtAAhJhVQhLhXAAiGQAAifBZhbQBNhOBsAAQBBAAAzAeQAtAcAYAvIACAAIAEhcIBoAAQgDBJAABfIAAKwgAh8kZQgxBAAABpQAABhAsA7QAxBEBUAAQA3AAAqggQArggASg2QAJgbAAgaIAAhzQAAgdgEgSQgOg1gogjQgtglg8AAQhSAAgyBBg");
        this.shape_165.setTransform(664.7, 439, 0.15, 0.15);

        this.shape_166 = new cjs.Shape();
        this.shape_166.graphics.f("#000000").s().p("Ai8ECQhFhEAAiSIAAliIBuAAIAAFPQAADCCIAAQAyAAApggQAjgcARgpQAKgaAAgeIAAl0IBuAAIAAG5QAABkAGBCIhiAAIgHhjIgCAAQgbAtgsAeQg5AmhHAAQhWAAg2g1g");
        this.shape_166.setTransform(654.6, 437.3, 0.15, 0.15);

        this.shape_167 = new cjs.Shape();
        this.shape_167.graphics.f("#000000").s().p("AjfFbQhXhcAAi7IAAnxIBuAAIAAH0QAACIA4BGQAzBABaAAQBfAAA1hBQA3hFAAiIIAAn0IBvAAIAAHsQAAC6hcBfQhSBWiQAAQiLAAhNhTg");
        this.shape_167.setTransform(643.3, 435.5, 0.15, 0.15);

        this.shape_168 = new cjs.Shape();
        this.shape_168.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_168.setTransform(653.8, 437.3, 0.15, 0.15);

        this.shape_169 = new cjs.Shape();
        this.shape_169.graphics.f("#000000").s().p("AisEUIAAgtIA6g4QBwhrAmg2QAxhAABg6QAAgvgXgbQgdggg2AAQg8AAg3AtIgYg0QAegYAmgPQApgQAtAAQBQAAAtAyQAnAsAABBQAABFgyBHQgnA4hfBeIgsApIAAABIDyAAIAAA9g");
        this.shape_169.setTransform(647.3, 358.9, 0.15, 0.15);

        this.shape_170 = new cjs.Shape();
        this.shape_170.graphics.f("#000000").s().p("AiFDtQgxgpAAg+QAAhkBsgsIgBgDQgrgUgXgiQgUgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkgvAWIAAADQA0ATAcAiQAeAlAAAxQAABGg2AsQg0AshNAAQhSAAgzgsgAhSA3QgZAdAAAnQgCArAeAeQAeAfAxAAQAxAAAegbQAdgbAAgrQAAgvgggdQgcgag5gRQgvAOgaAegAhDjKQgZAZAAAlQAAAnAdAZQAZAXAwANQAlgMAWgZQAYgaAAgkQAAgkgVgZQgZgcguAAQgqAAgaAag");
        this.shape_170.setTransform(640.9, 359, 0.15, 0.15);

        this.shape_171 = new cjs.Shape();
        this.shape_171.graphics.f("#000000").s().p("Ai4FSIgEAAIgEBlIhgAAQAFhTAAhKIAAreIBtAAIAAF/IADAAQAeg1AzgdQA2gfBFAAQByABBHBVQBIBXgBCIQAACahVBaQhNBShuAAQiJAAhAhzgAhng5QgwAlgQA9QgHAgAAAMIAABuQAAAPAFAaQARA5AsAkQAtAkA8AAQBTAAAyhAQAxhAAAhqQAAhggug9QgyhEhTAAQg5AAguAlg");
        this.shape_171.setTransform(658.7, 378.3, 0.15, 0.15);

        this.shape_172 = new cjs.Shape();
        this.shape_172.graphics.f("#000000").s().p("AkCGqIAAtDQBggRBxABQCcgBBOBHQAkAfATAtQATAtAAA4QAAByhBBBQgqAuhEAYQhDAXhPAAQg6AAgdgHIAAFTgAiVlKIAAFKQAhAGA5AAQBhAAA4gsQA4gvAAhYQAAhRg2grQg0gqhbAAQhHAAgfAJg");
        this.shape_172.setTransform(648.5, 378.5, 0.15, 0.15);

        this.shape_173 = new cjs.Shape();
        this.shape_173.graphics.f("#FFE2B6").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_173.setTransform(653.8, 378.3, 0.15, 0.15);

        this.shape_174 = new cjs.Shape();
        this.shape_174.graphics.f("#000000").s().p("AiEDRQgyhLgBiFQAAiEA1hMQAzhJBTAAQBVAAAwBJQAvBIAACDQAACIgyBLQgxBKhYAAQhRAAgwhIgAhOilQgfA8AABrQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhogag5Qgdg9g3AAQgwAAgeA6g");
        this.shape_174.setTransform(647.3, 300.1, 0.15, 0.15);

        this.shape_175 = new cjs.Shape();
        this.shape_175.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAjAKAhAAQA0AAAlggQAmghAAg1QgBg4glgfQgogghMAAQgfAAgsAGIAjkGIEBAAIAAA+IjNAAIgVCMQAZgDATAAQBDAAAwAdQAjAUAUAgQAXAmAAAwQAABRg5A0Qg5A2hWAAQgpAAgngLg");
        this.shape_175.setTransform(640.7, 300.1, 0.15, 0.15);

        this.shape_176 = new cjs.Shape();
        this.shape_176.graphics.f("#000000").s().p("ACVE3IAAldQAAhRgfguQgkg1hJAAQgyAAgqAhQgnAggPAwQgHAVAAAfIAAFsIhuAAIAAm6QAAhdgFhIIBhAAIAHBlIACAAQAZgwAxgfQA4gkBEAAQBSAAA5AzQBMBEAACMIAAFqg");
        this.shape_176.setTransform(658.7, 321.1, 0.15, 0.15);

        this.shape_177 = new cjs.Shape();
        this.shape_177.graphics.f("#000000").s().p("AifGlQg8gQgjgXIAchcQAoAYAwAPQA2AQA1AAQBQAAAwgoQAugnAAhBQAAg7gkgnQglglhTgiQhtglg3g2Qg7g9AAhWQAAhkBLhAQBMhCB4AAQByAABIAqIgeBZQhIgohYAAQhOgBgrArQgkAiAAAzQAAA4AoAmQAkAiBZAjQBvArAzA1QA2A8AABbQAABohJBEQhRBJiMAAQg7AAg9gQg");
        this.shape_177.setTransform(648.9, 319.4, 0.15, 0.15);

        this.shape_178 = new cjs.Shape();
        this.shape_178.graphics.f("#FFE2B6").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_178.setTransform(653.8, 319.4, 0.15, 0.15);

        this.shape_179 = new cjs.Shape();
        this.shape_179.graphics.f("#000000").s().p("AisEUIAAgtIA6g4QBxhsAmg1QAwhAABg6QAAgvgYgbQgbghg3ABQg7AAg4AtIgXg0QAegYAlgPQAqgPAsgBQBQAAAtAyQAnAsAABBQAABGgyBHQgnA3hgBfIgrAoIAAACIDyAAIAAA8g");
        this.shape_179.setTransform(647.2, 241.1, 0.15, 0.15);

        this.shape_180 = new cjs.Shape();
        this.shape_180.graphics.f("#000000").s().p("AhvENQgjgKgWgPIAUg5QATANAdAKQAmAMAiAAQA+AAAhgkQAbgdgBgpQgBg2grgdQgmgag5AAIgpAAIAAg1IApAAQAuAAAhgWQAogaAAgtQAAgjgVgWQgagZguAAQgeAAgfAMQgbAKgUAOIgUg2QAYgRAkgLQAqgNAoAAQBKAAAqAoQAmAkAAA2QAAArgZAhQgbAigxASIAAACQA1AKAhAiQAkAnAAA3QAABFgyAtQg2AxhcAAQgrAAgpgMg");
        this.shape_180.setTransform(640.7, 241.1, 0.15, 0.15);

        this.shape_181 = new cjs.Shape();
        this.shape_181.graphics.f("#000000").s().p("Ai7DpQhPhUAAiMQAAiLBMhbQBPhgB/AAQCGAABCBmQAzBNAABsQAAANgEAlImoAAQACBpA+A4QA3AyBXAAQBeAABKggIATBPQhXAnhyAAQiJAAhRhUgAhxixQgnAygIBGIFAAAQABhFgegwQgohAhUAAQhJABgvA8g");
        this.shape_181.setTransform(660, 262.2, 0.15, 0.15);

        this.shape_182 = new cjs.Shape();
        this.shape_182.graphics.f("#000000").s().p("AhWGWQhQgcg9g6Qg3g1gfhSQgghTAAhhQABi/B6h5QB+h8DOAAQBDAAA+ANQAyAKAgAQIgaBZQhTgkhoAAQiZAAhcBaQhcBcAACdQAACfBZBcQBXBbCTgBQBkABAtgXIAAj9IirAAIAAhWIEWAAIAAGVQiBAviCAAQhhAAhMgag");
        this.shape_182.setTransform(648.9, 260.4, 0.15, 0.15);

        this.shape_183 = new cjs.Shape();
        this.shape_183.graphics.f("#BCB98F").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_183.setTransform(653.8, 260.5, 0.15, 0.15);

        this.shape_184 = new cjs.Shape();
        this.shape_184.graphics.f("#000000").s().p("AA1EQIAAiUIj6AAIAAgxIDwlaIBPAAIAAFRIBMAAIAAA6IhMAAIAACUgAAIh4IiDC4IAAACICwAAIAAi0QAAgzADgjIgDAAQgZAwgUAgg");
        this.shape_184.setTransform(646.5, 182.1, 0.15, 0.15);

        this.shape_185 = new cjs.Shape();
        this.shape_185.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_185.setTransform(639.5, 182.1, 0.15, 0.15);

        this.shape_186 = new cjs.Shape();
        this.shape_186.graphics.f("#000000").s().p("Ag1GoIAApfIBsAAIAAJfgAgwkxQgTgUAAgdQAAgdAUgUQATgUAcAAQAfAAATAUQASATAAAeQABAdgTAUQgUATgeAAQgdAAgTgTg");
        this.shape_186.setTransform(658.6, 201.5, 0.15, 0.15);

        this.shape_187 = new cjs.Shape();
        this.shape_187.graphics.f("#000000").s().p("AigGlQg7gQgjgXIAchcQAnAZAwAOQA3AQA1AAQBQAAAwgoQAugnAAhCQAAg6gkgnQgkgmhUghQhtgkg2g4Qg8g8AAhWQAAhkBLhBQBMhBB4AAQByAABIAqIgeBYQhJgnhXAAQhOAAgrApQgkAjAAAyQAAA5AoAmQAkAhBaAkQBvArAyA2QA2A7AABbQAABohJBEQhQBJiNAAQg7AAg+gQg");
        this.shape_187.setTransform(651.8, 201.5, 0.15, 0.15);

        this.shape_188 = new cjs.Shape();
        this.shape_188.graphics.f("#BCB98F").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_188.setTransform(653.8, 201.5, 0.15, 0.15);

        this.shape_189 = new cjs.Shape();
        this.shape_189.graphics.f("#000000").s().p("AiEDaQg1g/AAhqQAAhMAahBQAYg9AqgqQBEhEBogNQAYgEAdAAIAAA8QgcgBgbAFQhQAOgzA4QguAzgKBIIADAAQAVgbAggRQAjgSApAAQBIAAAuAwQAuAvAABPQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAOAAATQABBFAeAqQAgAtA2AAIABAAQAvAAAdgkQAdglAAg6QAAg6gegiQgfgfgyAAQgfAAgdATg");
        this.shape_189.setTransform(641, 123.3, 0.15, 0.15);

        this.shape_190 = new cjs.Shape();
        this.shape_190.graphics.f("#000000").s().p("AjIFGQh3h0AAjLQAAjFB6h7QB6h7DDAAQBGAAA7ANQArAKAcAPIgaBZQhHgjhjgBQiVAAhYBcQhbBeAACjQAACdBVBaQBXBdCXAAQAxAAAwgJQAvgKAhgQIAXBWQgiASg2ALQhAANhHAAQi2AAhyhvg");
        this.shape_190.setTransform(653.8, 142.6, 0.15, 0.15);

        this.shape_191 = new cjs.Shape();
        this.shape_191.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_191.setTransform(653.8, 142.6, 0.15, 0.15);

        this.shape_192 = new cjs.Shape();
        this.shape_192.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBoAACWQAACUhQBrg");
        this.shape_192.setTransform(619.1, 457, 0.15, 0.15);

        this.shape_193 = new cjs.Shape();
        this.shape_193.graphics.f("#000000").s().p("AAoDMIAAhvIi8AAIAAglIC0kDIA7AAIAAD9IA5AAIAAArIg5AAIAABvgAAFhZIhhCJIAAACICEAAIAAiHQgBgkACgcIgBAAQgRAggSAcg");
        this.shape_193.setTransform(615.6, 456.6, 0.15, 0.15);

        this.shape_194 = new cjs.Shape();
        this.shape_194.graphics.f("#000000").s().p("AhkCyQgkggAAguQAAhMBRgfIgBgCQghgQgQgZQgPgXgBgcQAAgvAkggQAkgdA1gBQA4AAAgAgQAeAcAAApQAABAhDAgIAAABQAnAOAVAaQAWAcAAAkQAAA1goAhQgnAgg6AAQg9AAgngggAg9ApQgTAWABAdQgCAhAWAWQAXAXAkAAQAkABAXgWQAWgUAAggQAAgjgYgWQgVgTgqgMQgkAKgTAWgAgyiWQgTASAAAbQABA4BLAUQAdgKAPgRQASgUABgbQAAgcgRgSQgSgVgiAAQggAAgTAUg");
        this.shape_194.setTransform(610.8, 456.6, 0.15, 0.15);

        this.shape_195 = new cjs.Shape();
        this.shape_195.graphics.f("#000000").s().p("AiADPIAAgiIAqgqQBVhRAcgnQAkgwABgrQAAgjgRgUQgWgZgnAAQguAAgpAjIgSgoQAxgpBCAAQA8AAAiAlQAdAhABAxQgBA0gmA1QgdAphHBHIggAeIAAABIC1AAIAAAug");
        this.shape_195.setTransform(605.9, 456.6, 0.15, 0.15);

        this.shape_196 = new cjs.Shape();
        this.shape_196.graphics.f("#000000").s().p("AATD/QhQhsAAiSQABiUBPhrIArAAQhNBpAACWQAACPBNBvg");
        this.shape_196.setTransform(602.4, 457, 0.15, 0.15);

        this.shape_197 = new cjs.Shape();
        this.shape_197.graphics.f("#000000").s().p("AhvENQgjgKgWgPIAUg5QAUANAdAKQAlAMAiAAQA+AAAhgkQAbgdgBgpQAAg2gsgdQgngag3AAIgqAAIAAg1IAqAAQAtAAAhgWQApgaAAgtQAAgjgXgWQgZgZgtAAQgfAAgfAMQgbAKgUAOIgTg1QAXgRAkgMQApgNApAAQBKAAAqAoQAmAkAAA2QAAArgZAhQgaAigxASIAAACQA0AKAhAiQAkAnAAA3QAABFgyAtQg2AxhcAAQgqAAgqgMg");
        this.shape_197.setTransform(609.7, 417.9, 0.15, 0.15);

        this.shape_198 = new cjs.Shape();
        this.shape_198.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_198.setTransform(602.9, 417.9, 0.15, 0.15);

        this.shape_199 = new cjs.Shape();
        this.shape_199.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_199.setTransform(596.5, 417.9, 0.15, 0.15);

        this.shape_200 = new cjs.Shape();
        this.shape_200.graphics.f("#000000").s().p("AgqFQQgqgtAAhyIAAlKIheAAIAAhUIBeAAIAAhvIBpgjIAACSICeAAIAABUIieAAIAAFHQAAA6ASAdQAUAfAtAAQAnAAAZgIIAFBUQgpAPg5AAQhMAAgpgvg");
        this.shape_200.setTransform(621.5, 438, 0.15, 0.15);

        this.shape_201 = new cjs.Shape();
        this.shape_201.graphics.f("#000000").s().p("Ai8ECQhEhEgBiSIAAliIBuAAIAAFQQAADBCIAAQAyAAApggQAkgbARgpQAKgcAAgdIAAl0IBuAAIAAG5QgBBqAFA8IhhAAIgGhjIgDAAQgbAtgsAeQg4AmhIAAQhWAAg2g1g");
        this.shape_201.setTransform(613.3, 439.1, 0.15, 0.15);

        this.shape_202 = new cjs.Shape();
        this.shape_202.graphics.f("#000000").s().p("AjfFbQhXhcAAi7IAAnxIBvAAIAAH0QAACIA4BGQAzBABZAAQBfAAA1hBQA4hFAAiIIAAn0IBuAAIAAHsQAAC7hbBeQhTBWiQAAQiKAAhOhTg");
        this.shape_202.setTransform(602, 437.3, 0.15, 0.15);

        this.shape_203 = new cjs.Shape();
        this.shape_203.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_203.setTransform(610.8, 437.3, 0.15, 0.15);

        this.shape_204 = new cjs.Shape();
        this.shape_204.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_204.setTransform(603.8, 359, 0.15, 0.15);

        this.shape_205 = new cjs.Shape();
        this.shape_205.graphics.f("#000000").s().p("AiGDtQgwgpAAg+QAAhkBsgsIgBgDQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkguAWIAAADQAzATAdAiQAdAlAAAxQAABGg2AsQg0AshNAAQhTAAgzgsgAhSA3QgYAdgBAnQgBArAdAeQAeAfAxAAQAxAAAegbQAegbAAgrQAAgvghgdQgcgag5gRQgvAOgaAegAhDjKQgYAZAAAlQAAAnAcAZQAZAXAwANQAlgMAVgZQAZgaAAgkQAAgkgVgZQgZgcguAAQgqAAgaAag");
        this.shape_205.setTransform(597.9, 359, 0.15, 0.15);

        this.shape_206 = new cjs.Shape();
        this.shape_206.graphics.f("#000000").s().p("Ag2G+IAAt7IBsAAIAAN7g");
        this.shape_206.setTransform(616.1, 378.3, 0.15, 0.15);

        this.shape_207 = new cjs.Shape();
        this.shape_207.graphics.f("#000000").s().p("Ag2GnIAArwIkBAAIAAhdIJvAAIAABdIkCAAIAALwg");
        this.shape_207.setTransform(609.3, 378.7, 0.15, 0.15);

        this.shape_208 = new cjs.Shape();
        this.shape_208.graphics.f("#FFE2B6").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_208.setTransform(610.8, 378.3, 0.15, 0.15);

        this.shape_209 = new cjs.Shape();
        this.shape_209.graphics.f("#000000").s().p("AiHEZIAAg9QAKACAQgBIAhgDQBDgJAtgsQA6g1ANhcIgCAAQgwA7hOAAQhIAAgtgxQgrgtAAhHQAAhQAzg4QA1g6BPAAQBUAAAwA/QAwA+AABpQAABTgbBEQgXA9gsAqQgeAegqATQgnASgsAGQgeAEgZAAIgNAAgAhOi6QgeAlAAA6QAAAzAcAgQAdAeAvAAQAiAAAdgQQAbgNAPgaQAGgKAAgQQAAhKgagrQgdgwg1AAIgBAAQgvAAgdAmg");
        this.shape_209.setTransform(604.6, 300.1, 0.15, 0.15);

        this.shape_210 = new cjs.Shape();
        this.shape_210.graphics.f("#000000").s().p("AA1EQIAAiUIj7AAIAAgxIDxlaIBPAAIAAFRIBNAAIAAA6IhNAAIAACUgAAIh3IiDC3IAAACICwAAIAAi0QAAgyACgjIgCAAQgaAwgTAgg");
        this.shape_210.setTransform(598.1, 300.1, 0.15, 0.15);

        this.shape_211 = new cjs.Shape();
        this.shape_211.graphics.f("#000000").s().p("ACWE3IAAldQAAhRgfguQgkg1hKAAQgyAAgqAhQgmAggPAwQgIAVABAfIAAFsIhvAAIAAm6QAAhmgFg/IBiAAIAGBlIACAAQAZgwAygfQA4gkBEAAQBSAAA4AzQBMBEAACMIAAFqg");
        this.shape_211.setTransform(613.1, 321.1, 0.15, 0.15);

        this.shape_212 = new cjs.Shape();
        this.shape_212.graphics.f("#000000").s().p("Ag1GnIAAtNIBrAAIAANNg");
        this.shape_212.setTransform(605.4, 319.4, 0.15, 0.15);

        this.shape_213 = new cjs.Shape();
        this.shape_213.graphics.f("#FFE2B6").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_213.setTransform(610.8, 319.4, 0.15, 0.15);

        this.shape_214 = new cjs.Shape();
        this.shape_214.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_214.setTransform(603.7, 241.1, 0.15, 0.15);

        this.shape_215 = new cjs.Shape();
        this.shape_215.graphics.f("#000000").s().p("AhuENQgjgKgXgPIAUg5QAUANAdAKQAlAMAjAAQA+AAAggkQAbgdgBgpQAAg2gsgdQglgag5AAIgpAAIAAg1IApAAQAtAAAhgWQApgaAAgtQAAgjgWgWQgagZgtAAQgeAAggAMQgbAKgUAOIgTg2QAYgRAkgLQApgNApAAQBKAAAqAoQAmAkAAA2QgBArgYAhQgbAigxASIAAACQA0AKAiAiQAjAmAAA4QAABFgyAtQg2AxhbAAQgrAAgpgMg");
        this.shape_215.setTransform(597.7, 241.1, 0.15, 0.15);

        this.shape_216 = new cjs.Shape();
        this.shape_216.graphics.f("#000000").s().p("AjCEHQgugxAAhHQAAhvBeg4QBeg7CuABIAAgMQAAg3gWgjQgigzhQAAQgqAAgqAMQgpANggAUIgZhJQAmgZAzgOQA1gPA3ABQB/AAA5BOQAuA+AABsIAADiQAABbAKA3IhkAAIgJhNIgEAAQgbAnguAZQgzAag7AAQhXAAg0g2gAgvAQQhTAiAABQQAAAzAfAdQAcAaAtAAQA1AAApggQAkgcAOgqQAHgSAAgRIAAhoIgTAAQhhAAg4AVg");
        this.shape_216.setTransform(616.9, 262.2, 0.15, 0.15);

        this.shape_217 = new cjs.Shape();
        this.shape_217.graphics.f("#000000").s().p("AhXGWQhQgcg8g6Qg3g2gfhRQgghTAAhhQABi/B6h5QB+h8DOAAQBDAAA9ANQAyAKAgAQIgaBZQhRglhpAAQiZAAhcBcQhdBbAACdQABCfBYBcQBYBbCTAAQBjgBAugWIAAj9IirAAIAAhWIEWAAIAAGWQiCAuiCAAQhgAAhNgag");
        this.shape_217.setTransform(606.2, 260.4, 0.15, 0.15);

        this.shape_218 = new cjs.Shape();
        this.shape_218.graphics.f("#FFE2B6").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_218.setTransform(610.8, 260.5, 0.15, 0.15);

        this.shape_219 = new cjs.Shape();
        this.shape_219.graphics.f("#000000").s().p("AhuENQgjgKgXgPIAUg5QAUANAdAKQAlAMAiAAQA/AAAhgkQAagdgBgpQgBg2gqgdQgngag4AAIgpAAIAAg1IApAAQAtAAAigWQAogaAAgtQAAgjgWgWQgagZgtAAQgeAAggAMQgbAKgTAOIgUg1QAYgRAkgMQApgNApAAQBJAAArAoQAlAkAAA2QAAArgYAhQgbAigxASIAAACQA0AKAhAiQAkAmAAA4QAABFgyAtQg3AxhbAAQgqAAgpgMg");
        this.shape_219.setTransform(603.3, 182.2, 0.15, 0.15);

        this.shape_220 = new cjs.Shape();
        this.shape_220.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_220.setTransform(596.5, 182.2, 0.15, 0.15);

        this.shape_221 = new cjs.Shape();
        this.shape_221.graphics.f("#000000").s().p("Ag2G+IAAt7IBsAAIAAN7g");
        this.shape_221.setTransform(617, 201.5, 0.15, 0.15);

        this.shape_222 = new cjs.Shape();
        this.shape_222.graphics.f("#000000").s().p("ADsGnIhakKIkpAAIhYEKIhxAAIEftNICCAAIEgNNgAguisIhTDzID9AAIhTjyQgSg2gYhlIgCAAQgVBSgWBIg");
        this.shape_222.setTransform(609.1, 201.9, 0.15, 0.15);

        this.shape_223 = new cjs.Shape();
        this.shape_223.graphics.f("#FFE2B6").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_223.setTransform(610.8, 201.5, 0.15, 0.15);

        this.shape_224 = new cjs.Shape();
        this.shape_224.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAjAKAhAAQA0AAAlgfQAmgiAAg1QgBg4glgfQgogghMAAQgbAAgwAGIAjkFIEBAAIAAA+IjNAAIgUCLQAWgDAWAAQBBAAAyAdQAiAUAUAfQAXAnAAAwQAABRg4A1Qg6A0hWABQgqAAgmgLg");
        this.shape_224.setTransform(597.7, 123.2, 0.15, 0.15);

        this.shape_225 = new cjs.Shape();
        this.shape_225.graphics.f("#000000").s().p("AkJGkIAAtAQBTgRB1AAQBPAAA4AOQA3APAnAhQBGAzAABiQAAA9gmAzQgmAyhCAYIAAADQBGARAvAvQA5A7AABXQAABkhIBGQhWBPjMAAQhgAAhJgKgAicFTQAbAGBBAAQBcAAA4glQBCgqAAhWQAAhShAgrQg5gnheAAIhbAAgAiclSIAAERIBjAAQBTAAAygoQAwgnAAg+QAAhIgzgjQgvgghVAAQg7AAgmAHg");
        this.shape_225.setTransform(610.8, 142.6, 0.15, 0.15);

        this.shape_226 = new cjs.Shape();
        this.shape_226.graphics.f("#BCB98F").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_226.setTransform(610.8, 142.6, 0.15, 0.15);

        this.shape_227 = new cjs.Shape();
        this.shape_227.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACThQBsg");
        this.shape_227.setTransform(576.1, 457, 0.15, 0.15);

        this.shape_228 = new cjs.Shape();
        this.shape_228.graphics.f("#000000").s().p("AhUDHQgZgHgQgKIAOgqQAmAWAxABQAmAAAcgZQAcgZAAgnQAAgqgcgXQgegXg5gBQgWAAgiAFIAajEIDBAAIAAAuIiZAAIgQBqQAQgDARAAQAxAAAlAWQAaAOAPAXQARAdAAAlQAAA7grApQgrAnhAAAQgfAAgdgIg");
        this.shape_228.setTransform(572.4, 456.7, 0.15, 0.15);

        this.shape_229 = new cjs.Shape();
        this.shape_229.graphics.f("#000000").s().p("AhkCyQgkggAAguQAAhLBRggIgBgCQghgPgQgZQgQgYAAgcQABgvAjggQAkgeA0AAQA4AAAhAfQAeAdAAApQAAA/hDAhIAAABQAnAOAVAaQAWAbAAAlQAAA0goAiQgoAgg5AAQg+AAgmgggAg9ApQgSAWAAAdQgCAhAWAWQAWAXAlAAQAkAAAXgVQAWgUAAggQAAgjgYgWQgWgTgqgMQgjAJgTAXgAgyiWQgTASAAAcQAAA2BMAVQAcgKARgSQASgUAAgaQAAgcgQgSQgTgVgjAAQgeAAgUAUg");
        this.shape_229.setTransform(567.7, 456.6, 0.15, 0.15);

        this.shape_230 = new cjs.Shape();
        this.shape_230.graphics.f("#000000").s().p("AiADPIAAgiIArgqQBVhRAbgnQAlgwAAgrQAAgjgRgVQgVgYgoAAQguAAgpAjIgRgoQAxgpBCAAQA7AAAiAmQAeAgAAAxQAAA0gmA1QgdAphIBHIghAeIAAACIC1AAIAAAtg");
        this.shape_230.setTransform(562.9, 456.6, 0.15, 0.15);

        this.shape_231 = new cjs.Shape();
        this.shape_231.graphics.f("#000000").s().p("AATD/QhQhsAAiSQAAiTBQhsIArAAQhNBpAACWQAACPBNBvg");
        this.shape_231.setTransform(559.4, 457, 0.15, 0.15);

        this.shape_232 = new cjs.Shape();
        this.shape_232.graphics.f("#000000").s().p("Ai4FTIgDAAIgFBkIhgAAQAFhTAAhLIAArdIBtAAIAAF+IADAAQAeg0AzgdQA2gfBFAAQByAABHBWQBIBXgBCIQAACahVBaQhNBShuAAQiJAAhAhygAhng5QgwAlgQA8QgHAhAAANIAABtQAAAOAFAaQARA6AsAkQAtAkA8AAQBTAAAyhBQAxg/AAhqQAAhhgug8QgyhEhTABQg5AAguAkg");
        this.shape_232.setTransform(578.9, 437.2, 0.15, 0.15);

        this.shape_233 = new cjs.Shape();
        this.shape_233.graphics.f("#000000").s().p("Ai7ECQhFhFgBiRIAAliIBuAAIAAFPQAADCCIAAQAxAAAqggQAjgcARgpQAKgZAAgfIAAl0IBvAAIAAG5QAABqAEA8IhhAAIgHhkIgCAAQgbAugrAdQg6AnhHAAQhWAAg1g1g");
        this.shape_233.setTransform(568.1, 439.4, 0.15, 0.15);

        this.shape_234 = new cjs.Shape();
        this.shape_234.graphics.f("#000000").s().p("AjfFcQhXhdAAi7IAAnxIBuAAIAAHzQAACJA4BGQA0BABZAAQBfAAA1hBQA4hFAAiJIAAnzIBuAAIAAHsQAAC6hbBfQhTBWiQAAQiLAAhNhSg");
        this.shape_234.setTransform(556.9, 437.6, 0.15, 0.15);

        this.shape_235 = new cjs.Shape();
        this.shape_235.graphics.f("#000000").s().p("AisEUIAAgtIA6g4QBwhsAmg1QAxhAABg6QAAgvgYgbQgcggg2gBQg7ABg4AtIgYgzQBCg4BYAAQBQAAAtAyQAnAsAABAQAABGgyBHQgnA4hgBeIgrAoIAAACIDyAAIAAA9g");
        this.shape_235.setTransform(566.8, 417.8, 0.15, 0.15);

        this.shape_236 = new cjs.Shape();
        this.shape_236.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_236.setTransform(559.9, 417.9, 0.15, 0.15);

        this.shape_237 = new cjs.Shape();
        this.shape_237.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_237.setTransform(553.4, 417.9, 0.15, 0.15);

        this.shape_238 = new cjs.Shape();
        this.shape_238.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_238.setTransform(567.7, 437.2, 0.15, 0.15);

        this.shape_239 = new cjs.Shape();
        this.shape_239.graphics.f("#000000").s().p("AiEDRQgyhLgBiFQAAiEA1hMQAzhJBTAAQBWAAAvBIQAvBJAACCQAACJgyBLQgxBKhYAAQhRAAgwhIgAhOilQgfA8AABrQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhogag5Qgdg9g3AAQgwAAgeA6g");
        this.shape_239.setTransform(561.3, 359, 0.15, 0.15);

        this.shape_240 = new cjs.Shape();
        this.shape_240.graphics.f("#000000").s().p("AiFDtQgxgpAAg/QAAgyAdglQAbgkA0gUIgBgDQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBKAAAsApQAoAmAAA3QAAAmgUAfQgXAkgvAWIAAADQA1ATAcAiQAdAlAAAxQAABGg2AsQg0AshNAAQhTAAgygsgAhSA3QgYAdAAAnQgDArAeAeQAeAfAxAAQAxAAAegbQAdgbABgrQAAgvghgdQgcgag5gRQgvAOgaAegAhEjKQgYAZAAAlQAAAnAcAZQAaAXAwANQAlgMAVgZQAYgaAAgkQAAgkgUgZQgZgcguAAQgrAAgaAag");
        this.shape_240.setTransform(554.8, 359, 0.15, 0.15);

        this.shape_241 = new cjs.Shape();
        this.shape_241.graphics.f("#000000").s().p("AiJGtQg4gOgkgXIAbhVQBPAxBjgBQBZAAAxgwQA4g3AAhtIAAhEIgDAAQgbAtgvAbQg0AehBAAQhvAAhKhWQhIhUAAh9QgBiTBVhcQBOhUBuAAQBGAAA1AiQApAbAYAsIACAAIAFhcIBgAAQgFBZAABPIAAFfQAABogVBEQgVBCgsAoQhNBJiNAAQg5AAg1gNgAh3kkQgzA/AABpQAABeAtA6QAxBABTABQAzAAAqgfQAqgfASgyQAJgbAAggIAAhtQAAghgHgSQgPgygnggQgqgjg5AAQhPAAgxA/g");
        this.shape_241.setTransform(573.5, 380, 0.15, 0.15);

        this.shape_242 = new cjs.Shape();
        this.shape_242.graphics.f("#000000").s().p("ADLGnIAAmNImWAAIAAGNIhtAAIAAtNIBtAAIAAFiIGWAAIAAliIBuAAIAANNg");
        this.shape_242.setTransform(562.4, 376.3, 0.15, 0.15);

        this.shape_243 = new cjs.Shape();
        this.shape_243.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_243.setTransform(567.7, 378.3, 0.15, 0.15);

        this.shape_244 = new cjs.Shape();
        this.shape_244.graphics.f("#000000").s().p("AiFDtQgxgpAAg/QAAgyAdglQAbgkA0gUIgBgDQgrgUgXgiQgUgfAAglQAAhAAwgpQAwgoBGAAQBKAAAtApQAnAmAAA3QAAAmgTAfQgYAkgvAWIAAADQA0ATAdAiQAdAlAAAxQAABGg2AsQg0AshNAAQhTAAgygsgAhRA3QgZAdAAAnQgDArAeAeQAfAfAwAAQAxAAAegcQAdgbABgqQAAgvghgdQgcgag5gRQgvAOgZAegAhDjKQgYAZAAAlQAAAnAcAZQAZAXAwANQAlgMAWgZQAXgaAAgkQAAgkgUgZQgZgcguAAQgqAAgaAag");
        this.shape_244.setTransform(561.5, 300, 0.15, 0.15);

        this.shape_245 = new cjs.Shape();
        this.shape_245.graphics.f("#000000").s().p("AA1EQIAAiVIj6AAIAAgwIDwlaIBPAAIAAFRIBMAAIAAA5IhMAAIAACVgAAIh3IiDC3IAAACICwAAIAAi0QAAgyADgkIgDAAQgbAzgSAeg");
        this.shape_245.setTransform(555.1, 300, 0.15, 0.15);

        this.shape_246 = new cjs.Shape();
        this.shape_246.graphics.f("#000000").s().p("AjSFvQhLhXAAiIQgBiSBRhcQBNhXBzAAQA/AAAzAcQAsAYAXAoIACAAIAAlrIBuAAIAALdQAABlAGA5IhjAAIgFhqIgDAAQgaA1g1AhQg4AihGAAQhvAAhJhWgAh9gcQgwA/AABoQAABgAtA+QAwBDBUgBQA5AAAsgiQAuglAOg8QAFgTAAgdIAAhqQAAgdgFgRQgMg2gqgjQgtgmg8AAQhRAAgyBDg");
        this.shape_246.setTransform(573.1, 319.4, 0.15, 0.15);

        this.shape_247 = new cjs.Shape();
        this.shape_247.graphics.f("#000000").s().p("AjIFGQh3h0AAjLQAAjFB6h7QB6h7DDAAQBGAAA6ANQAsAKAcAOIgaBaQhJgjhiAAQiUAAhZBbQhaBeAACiQAACdBVBbQBXBdCXAAQAxAAAwgKQAwgJAggQIAXBWQgiASg2ALQhAANhHAAQi3AAhxhvg");
        this.shape_247.setTransform(562.9, 319.6, 0.15, 0.15);

        this.shape_248 = new cjs.Shape();
        this.shape_248.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_248.setTransform(567.7, 319.4, 0.15, 0.15);

        this.shape_249 = new cjs.Shape();
        this.shape_249.graphics.f("#000000").s().p("AiEDRQgyhLgBiFQAAiEA1hMQA0hJBSAAQBWAAAuBIQAwBJgBCCQAACJgwBLQgyBKhYAAQhRAAgwhIgAhOilQgfA8AABrQAABpAeA7QAdA6AyAAQA2AAAcg9QAcg7AAhpQAAhogbg5Qgbg9g4AAQgwAAgeA6g");
        this.shape_249.setTransform(561.2, 241.1, 0.15, 0.15);

        this.shape_250 = new cjs.Shape();
        this.shape_250.graphics.f("#000000").s().p("AhuENQgjgKgXgPIAUg5QAUANAdAKQAlAMAiAAQA/AAAhgkQAagdgBgpQgBg2gqgdQgmgag5AAIgpAAIAAg2IApAAQAtAAAhgWQApgZAAgtQAAgjgWgWQgZgZguAAQgeAAggAMQgbAKgUAOIgTg2QAXgRAlgLQApgNApAAQBKAAAqAoQAmAkAAA2QAAArgaAhQgZAigyASIAAACQA1AKAgAiQAkAmAAA4QAABFgyAtQg2AxhcAAQgqAAgpgMg");
        this.shape_250.setTransform(554.6, 241.1, 0.15, 0.15);

        this.shape_251 = new cjs.Shape();
        this.shape_251.graphics.f("#000000").s().p("ACWE3IAAldQAAhRgfguQgkg1hJAAQgzAAgpAhQgnAggPAwQgIAVAAAfIAAFsIhuAAIAAm6QAAhkgFhBIBiAAIAGBlIACAAQAagwAwgfQA5gkBEAAQBRAAA5AzQBMBEAACMIAAFqg");
        this.shape_251.setTransform(573.3, 262.1, 0.15, 0.15);

        this.shape_252 = new cjs.Shape();
        this.shape_252.graphics.f("#000000").s().p("AkzGoIAAhBIHTquIAAgDImqAAIAAhdII3AAIAABEInQKrIAAADIHXAAIAABdg");
        this.shape_252.setTransform(562.9, 260.5, 0.15, 0.15);

        this.shape_253 = new cjs.Shape();
        this.shape_253.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_253.setTransform(567.7, 260.5, 0.15, 0.15);

        this.shape_254 = new cjs.Shape();
        this.shape_254.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhuIArAAQBQBqAACVQAACThQBsg");
        this.shape_254.setTransform(533.1, 457.2, 0.15, 0.15);

        this.shape_255 = new cjs.Shape();
        this.shape_255.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBUhRAcgoQAlgvAAgsQAAgigRgVQgVgYgoAAQguAAgpAiIgSgmQAxgqBDAAQA7AAAiAlQAdAhABAwQgBA1glA0QgeAqhHBHIggAeIAAABIC1AAIAAAug");
        this.shape_255.setTransform(529.5, 456.8, 0.15, 0.15);

        this.shape_256 = new cjs.Shape();
        this.shape_256.graphics.f("#000000").s().p("AhpDMICvlnIAAgCIjFAAIAAguID/AAIAAAlIiwFyg");
        this.shape_256.setTransform(524.7, 456.8, 0.15, 0.15);

        this.shape_257 = new cjs.Shape();
        this.shape_257.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBUhRAcgoQAlgvAAgsQAAgigRgVQgVgYgpAAQgtAAgpAiIgSgmQAygqBCAAQA7AAAiAlQAdAhAAAwQAAA0gmA1QgcAqhIBHIggAeIAAABIC1AAIAAAug");
        this.shape_257.setTransform(519.8, 456.8, 0.15, 0.15);

        this.shape_258 = new cjs.Shape();
        this.shape_258.graphics.f("#000000").s().p("AATD/QhQhrAAiTQAAiTBQhtIArAAQhNBrAACVQAACPBNBvg");
        this.shape_258.setTransform(516.3, 457.2, 0.15, 0.15);

        this.shape_259 = new cjs.Shape();
        this.shape_259.graphics.f("#000000").s().p("ACrGzIAAlXIgCAAQgaAwgxAcQg1AghEAAQhtAAhIhVQhMhXAAiGQAAifBZhbQBOhOBsAAQBBAAAyAeQAtAcAYAvIADAAIADhcIBoAAQgEBIAABgIAAKwgAh8kZQgxBAABBpQAABgArA8QAxBEBUAAQA3AAAqggQArggASg3QAJgZAAgcIAAhyQAAgdgFgSQgNg1gpgjQgsglg8AAQhSAAgyBBg");
        this.shape_259.setTransform(529.4, 439.2, 0.15, 0.15);

        this.shape_260 = new cjs.Shape();
        this.shape_260.graphics.f("#000000").s().p("AChGqQgSgigmioQgShYgmglQgnglhIgDIhmAAIAAFvIhtAAIAAtCQBXgRB6AAQBVAAA7AQQA7ARAnAkQAgAcARAqQARAqAAAxQAABQguA7QgqA1hHAWIAAAEQBdAfAfCMQAYBmAMAuQARA+ANAWgAiklLIAAE1IBvAAQBVAAA0gsQAzgsAAhJQAAhPg2goQgxgmhZgBQhKAAghAKg");
        this.shape_260.setTransform(519.8, 435.6, 0.15, 0.15);

        this.shape_261 = new cjs.Shape();
        this.shape_261.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_261.setTransform(523.2, 418, 0.15, 0.15);

        this.shape_262 = new cjs.Shape();
        this.shape_262.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_262.setTransform(516.8, 418, 0.15, 0.15);

        this.shape_263 = new cjs.Shape();
        this.shape_263.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_263.setTransform(510.4, 418, 0.15, 0.15);

        this.shape_264 = new cjs.Shape();
        this.shape_264.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_264.setTransform(524.7, 437.5, 0.15, 0.15);

        this.shape_265 = new cjs.Shape();
        this.shape_265.graphics.f("#000000").s().p("AhoDLICulnIAAgBIjFAAIAAguID/AAIAAAlIiwFxg");
        this.shape_265.setTransform(529.3, 398.9, 0.15, 0.15);

        this.shape_266 = new cjs.Shape();
        this.shape_266.graphics.f("#000000").s().p("AhlDSIAAgtQAKABAjgDQAygHAhghQArgnALhFIgCAAQgkAsg6AAQg2AAgigkQgggiAAg1QAAg8AmgqQAogrA7AAQA+AAAkAvQAkAuAABPQAAB5hGBEQgvAvhFAIQgVADgVAAIgJAAgAg6iLQgXAcAAArQAAAnAWAXQAVAXAkAAQAYAAAWgNQAUgJAMgTQAFgJAAgLQAAg3gUghQgWgjgoAAIAAAAQgjAAgWAcg");
        this.shape_266.setTransform(524.4, 398.9, 0.15, 0.15);

        this.shape_267 = new cjs.Shape();
        this.shape_267.graphics.f("#000000").s().p("AAPDLIAAliIgCAAIhEAmIgMgqIBXgwIAwAAIAAGWg");
        this.shape_267.setTransform(519.2, 398.9, 0.15, 0.15);

        this.shape_268 = new cjs.Shape();
        this.shape_268.graphics.f("#000000").s().p("AiHEZIAAg9QARACAqgEQBFgKArgrQA5g1APhcIgDAAQgwA7hOAAQhHAAgugxQgrgtAAhHQAAhQAzg4QA1g6BPAAQBUAAAwA+QAwA/AABpQAABTgbBEQgYA8gqAqQggAfgpATQgnASgtAFQgbAFgdAAIgLAAgAhPi7QgdAmAAA6QAAAzAcAgQAcAeAwAAQAiAAAdgQQAbgNAPgaQAGgKABgRQgBhJgagsQgdgvg1AAIgCAAQgtAAgfAlg");
        this.shape_268.setTransform(518, 359.2, 0.15, 0.15);

        this.shape_269 = new cjs.Shape();
        this.shape_269.graphics.f("#000000").s().p("AiMEQIDqngIAAgCIkIAAIAAg9IFVAAIAAAxIjrHug");
        this.shape_269.setTransform(511.6, 359.2, 0.15, 0.15);

        this.shape_270 = new cjs.Shape();
        this.shape_270.graphics.f("#000000").s().p("Ai8ECQhEhFAAiRIAAliIBuAAIAAFPQgBDCCIAAQAxAAAqggQAjgcARgpQAKgaAAgeIAAl0IBuAAIAAG5QABBqAEA8IhhAAIgHhjIgCAAQgbAtgsAeQg5AmhHAAQhWAAg2g1g");
        this.shape_270.setTransform(530.7, 380.3, 0.15, 0.15);

        this.shape_271 = new cjs.Shape();
        this.shape_271.graphics.f("#000000").s().p("ADsGnIhakKIkpAAIhYEKIhxAAIEftNICCAAIEgNNgAguisIhTDzID8AAIhTjyQgQgygZhoIgDAAQgUBSgWBHg");
        this.shape_271.setTransform(520.1, 378.4, 0.15, 0.15);

        this.shape_272 = new cjs.Shape();
        this.shape_272.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_272.setTransform(524.7, 378.5, 0.15, 0.15);

        this.shape_273 = new cjs.Shape();
        this.shape_273.graphics.f("#000000").s().p("AiMEQIDqngIAAgCIkIAAIAAg9IFVAAIAAAxIjrHug");
        this.shape_273.setTransform(518.6, 300.1, 0.15, 0.15);

        this.shape_274 = new cjs.Shape();
        this.shape_274.graphics.f("#000000").s().p("AA1EQIAAiUIj6AAIAAgxIDwlaIBPAAIAAFRIBMAAIAAA6IhMAAIAACUgAAIh3IiDC4IAAABICwAAIAAi0QAAgyADgkIgDAAQgRAhgcAwg");
        this.shape_274.setTransform(512, 300.1, 0.15, 0.15);

        this.shape_275 = new cjs.Shape();
        this.shape_275.graphics.f("#000000").s().p("AiJGtQg4gNgkgZIAchTQAgAUArAMQAxAPA1AAQBZAAAxgwQA3g3AAhuIAAhDIgCAAQgbAtgvAbQgzAehCgBQhvAAhKhUQhIhVAAh9QAAiUBUhbQBNhUBvAAQBGAAA1AiQApAbAXAsIADAAIAFhbIBgAAQgFBXAABQIAAFfQAABogUBEQgWBCgsAoQhOBJiNAAQg4AAg1gNgAh3kkQgzBAAABoQAABeAtA6QAwBBBUAAQAzgBAqgeQAqgfASgyQAIgZAAgiIAAhtQAAgfgGgUQgQgzgngfQgpgig6gBQhOABgxA+g");
        this.shape_275.setTransform(530.4, 321.3, 0.15, 0.15);

        this.shape_276 = new cjs.Shape();
        this.shape_276.graphics.f("#000000").s().p("ADsGnIhakKIkpAAIhYEKIhxAAIEftNICCAAIEgNNgAguisIhTDzID9AAIhTjyQgRgzgZhnIgCAAQgWBVgVBEg");
        this.shape_276.setTransform(520, 317.6, 0.15, 0.15);

        this.shape_277 = new cjs.Shape();
        this.shape_277.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_277.setTransform(524.7, 319.6, 0.15, 0.15);

        this.shape_278 = new cjs.Shape();
        this.shape_278.graphics.f("#000000").s().p("AiHEZIAAg9QASACApgEQBFgKArgrQA5g1AOhcIgCAAQgwA7hOAAQhHAAgugxQgrgtAAhHQAAhQAzg4QA2g6BOAAQBTAAAxA+QAwA/AABpQAABTgbBEQgXA8grAqQgfAfgqATQgnASgtAFQgbAFgdAAIgLAAgAhPi7QgdAmAAA6QgBAzAdAgQAdAeAvAAQAiAAAdgQQAagNAQgaQAGgKAAgRQAAhJgagsQgdgvg1AAIgBAAQgvAAgeAlg");
        this.shape_278.setTransform(518.1, 241.3, 0.15, 0.15);

        this.shape_279 = new cjs.Shape();
        this.shape_279.graphics.f("#000000").s().p("AisEVIAAguIA6g4QBxhrAmg2QAxhAAAg6QAAgugXgcQgcggg3AAQg8AAg3AuIgXg0QAegaAlgOQApgQAtAAQBQAAAtAyQAoAsAABBQAABGgzBHQgmA2hgBgIgsAoIAAACIDyAAIAAA9g");
        this.shape_279.setTransform(511.6, 241.2, 0.15, 0.15);

        this.shape_280 = new cjs.Shape();
        this.shape_280.graphics.f("#000000").s().p("Ai8ECQhFhFABiRIAAliIBuAAIAAFPQAADCCHAAQAxAAAqggQAjgcARgpQAKgbAAgdIAAl0IBuAAIAAG5QAABiAFBEIhhAAIgHhjIgCAAQgbAtgsAeQg5AmhGAAQhXAAg2g1g");
        this.shape_280.setTransform(530.3, 262.6, 0.15, 0.15);

        this.shape_281 = new cjs.Shape();
        this.shape_281.graphics.f("#000000").s().p("AjIFHQh3h1AAjLQAAjFB6h7QB6h7DDAAQBGAAA7ANQArAKAcAPIgaBZQhIgjhiAAQiVAAhYBbQhbBeAACiQAACdBVBcQBXBcCXAAQAxAAAwgJQAvgKAhgQIAXBXQgiARg2ALQhAANhHAAQi2AAhyhug");
        this.shape_281.setTransform(520, 260.7, 0.15, 0.15);

        this.shape_282 = new cjs.Shape();
        this.shape_282.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_282.setTransform(524.7, 260.7, 0.15, 0.15);

        this.shape_283 = new cjs.Shape();
        this.shape_283.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACThQBsg");
        this.shape_283.setTransform(490, 457, 0.15, 0.15);

        this.shape_284 = new cjs.Shape();
        this.shape_284.graphics.f("#000000").s().p("AAODLIAAliIgBAAIhFAmIgLgqIBXgwIAvAAIAAGWg");
        this.shape_284.setTransform(486.1, 456.6, 0.15, 0.15);

        this.shape_285 = new cjs.Shape();
        this.shape_285.graphics.f("#000000").s().p("AhoDLICulnIAAgBIjFAAIAAguID/AAIAAAlIivFxg");
        this.shape_285.setTransform(481.7, 456.6, 0.15, 0.15);

        this.shape_286 = new cjs.Shape();
        this.shape_286.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBVhRAcgnQAkgwABgrQgBgjgRgVQgVgYgoAAQgtAAgqAjIgSgoQAzgpBBAAQA8AAAhAmQAdAgABAxQAAA0gmA1QgeAphHBHIggAeIAAACIC1AAIAAAtg");
        this.shape_286.setTransform(476.8, 456.6, 0.15, 0.15);

        this.shape_287 = new cjs.Shape();
        this.shape_287.graphics.f("#000000").s().p("AATD/QhQhsAAiSQABiTBPhsIArAAQhMBqgBCVQABCPBMBvg");
        this.shape_287.setTransform(473.3, 457, 0.15, 0.15);

        this.shape_288 = new cjs.Shape();
        this.shape_288.graphics.f("#000000").s().p("Ah5EyQgrgMghgTIAbhUQAcASAkAMQArAOAmAAQA4AAAfgbQAdgYABgoQAAgngagZQgagZg7gXQhRgdgpgqQgngsAAg3QAAhMA4gyQA6g1BdAAQAsAAAqAMQAkAJAcARIgcBQQg4gjhEAAQgtAAgcAZQgbAXABAjQAAAkAcAXQAXAUA+AYQBSAgAlAnQAoAtAABCQAABSg7AyQg+A0hoAAQgwAAgugMg");
        this.shape_288.setTransform(487.5, 439, 0.15, 0.15);

        this.shape_289 = new cjs.Shape();
        this.shape_289.graphics.f("#000000").s().p("AlZGkIAAs/QBygSB2AAQDkAABwBqQB3BtAADDQAABlgfBUQgfBUg8A6Qg7A8hfAfQheAfh7AAQhqAAhcgKgAjslLIAAKbQAkAGBLAAQCrAABdheQBdhdAAiqQABiahVhVQhZhYinAAQhLAAg1ALg");
        this.shape_289.setTransform(477.9, 437.2, 0.15, 0.15);

        this.shape_290 = new cjs.Shape();
        this.shape_290.graphics.f("#000000").s().p("AiEDRQgxhLgCiFQAAiEA1hMQAzhJBTAAQBWAAAvBIQAvBJAACCQAACJgyBLQgxBKhYAAQhRAAgwhIgAhOilQgfA8AABrQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhpgag4Qgdg9g3AAQgwAAgeA6g");
        this.shape_290.setTransform(480.7, 417.9, 0.15, 0.15);

        this.shape_291 = new cjs.Shape();
        this.shape_291.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_291.setTransform(473.8, 417.9, 0.15, 0.15);

        this.shape_292 = new cjs.Shape();
        this.shape_292.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_292.setTransform(467.3, 417.9, 0.15, 0.15);

        this.shape_293 = new cjs.Shape();
        this.shape_293.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_293.setTransform(481.6, 437.2, 0.15, 0.15);

        this.shape_294 = new cjs.Shape();
        this.shape_294.graphics.f("#000000").s().p("AiFDtQgxgqAAg+QAAgyAdglQAbgkA0gUIgBgDQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkgvAWIAAADQA1ATAcAiQAdAlAAAxQAABGg2AsQg0AshNAAQhSAAgzgsgAhSA3QgZAdAAAnQgCArAeAeQAeAfAxAAQAxAAAegbQAdgbAAgrQAAgvgggdQgcgag5gRQgvAOgaAegAhDjKQgZAZAAAlQAAAnAdAZQAZAXAwANQAlgMAWgZQAYgaAAgkQAAgkgVgZQgZgcguAAQgqAAgaAag");
        this.shape_294.setTransform(474.9, 359, 0.15, 0.15);

        this.shape_295 = new cjs.Shape();
        this.shape_295.graphics.f("#000000").s().p("AiMEQIDqngIAAgBIkIAAIAAg+IFVAAIAAAwIjrHvg");
        this.shape_295.setTransform(468.6, 359, 0.15, 0.15);

        this.shape_296 = new cjs.Shape();
        this.shape_296.graphics.f("#000000").s().p("AgpFQQgrgtAAhyIAAlKIheAAIAAhUIBeAAIAAhwIBqgiIAACSICdAAIAABUIidAAIAAFHQAAA7ASAcQAUAfAsAAQAoAAAYgIIAFBTQgnARg7AAQhLAAgpgwg");
        this.shape_296.setTransform(486.1, 379.1, 0.15, 0.15);

        this.shape_297 = new cjs.Shape();
        this.shape_297.graphics.f("#000000").s().p("AkDGrIAAtEQBngQBrAAQCcAABOBGQAkAfATAtQATAtAAA4QAAByhBBBQgrAuhDAYQhDAXhOABQg5AAgfgIIAAFUgAiVlKIAAFJQAgAIA6gBQBhABA4gtQA4gwAAhWQAAhTg2gqQg0gqhbAAQhGAAggAJg");
        this.shape_297.setTransform(478.3, 378.2, 0.15, 0.15);

        this.shape_298 = new cjs.Shape();
        this.shape_298.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_298.setTransform(481.6, 378.3, 0.15, 0.15);

        this.shape_299 = new cjs.Shape();
        this.shape_299.graphics.f("#000000").s().p("AiEDaQg1hAAAhqQAAhLAahCQAYg8AqgqQBEhEBogNQAZgEAcAAIAAA8QgcgBgbAFQhQAOgzA4QguAzgKBIIADAAQAVgbAggRQAjgSApAAQBJAAAtAwQAuAuAABQQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgcAQgQAeQgIANAAAUQABBFAfAqQAgAtA1AAIABAAQAvAAAdgkQAdglAAg6QAAg6gegiQgegfgzAAQgfAAgdATg");
        this.shape_299.setTransform(475.4, 300, 0.15, 0.15);

        this.shape_300 = new cjs.Shape();
        this.shape_300.graphics.f("#000000").s().p("AA1EQIAAiUIj6AAIAAgxIDwlaIBPAAIAAFRIBMAAIAAA6IhMAAIAACUgAAIh3IiDC3IAAACICwAAIAAi0QAAgmACgwIgCAAQgUAngZAqg");
        this.shape_300.setTransform(469, 300, 0.15, 0.15);

        this.shape_301 = new cjs.Shape();
        this.shape_301.graphics.f("#000000").s().p("AjSFwQhKhYAAiIQgBiSBRhcQBMhYBzABQBAAAAyAcQAtAZAWAnIADAAIAAlrIBuAAIAALeQAABiAFA7IhjAAIgFhqIgCAAQgbA1g0AhQg5AihFAAQhvAAhKhVgAh9gbQgwA+AABnQAABiAtA9QAwBCBUAAQA5AAAsgiQAuglAPg8QAFgTAAgeIAAhpQAAgdgFgSQgNg1gqgjQgsgmg8AAQhSAAgyBEg");
        this.shape_301.setTransform(486, 319.4, 0.15, 0.15);

        this.shape_302 = new cjs.Shape();
        this.shape_302.graphics.f("#000000").s().p("AkDGqIAAtDQBhgRBwAAQCeABBOBGQAjAfATAtQAUAtgBA4QAAByhBBBQgrAuhEAYQhCAXhPAAQg4ABgggIIAAFTgAiWlKIAAFKQAhAGA6ABQBhgBA4gsQA4gwABhXQgBhSg2gqQg0gphbgBQhHAAggAJg");
        this.shape_302.setTransform(476.8, 319.6, 0.15, 0.15);

        this.shape_303 = new cjs.Shape();
        this.shape_303.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_303.setTransform(481.6, 319.4, 0.15, 0.15);

        this.shape_304 = new cjs.Shape();
        this.shape_304.graphics.f("#000000").s().p("AiFDtQgxgqAAg+QAAgyAdglQAbgkA0gUIgBgDQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgWAkgvAWIAAADQA0ATAcAiQAdAlAAAxQAABGg2AsQg0AshNAAQhSAAgzgsgAhSA3QgZAdAAAnQgCArAeAeQAeAfAxAAQAwAAAfgcQAdgbAAgqQAAgvgggdQgcgag5gRQgvAOgaAegAhDjKQgYAZAAAlQAAAnAcAZQAZAXAwANQAlgMAWgZQAYgaAAgkQAAgkgVgZQgZgcguAAQgqAAgaAag");
        this.shape_304.setTransform(475.1, 241.1, 0.15, 0.15);

        this.shape_305 = new cjs.Shape();
        this.shape_305.graphics.f("#000000").s().p("AisEVIAAgtIA6g5QBxhsAmg1QAwhAABg6QAAgvgYgbQgbggg3gBQg8ABg3AtIgXg0QBBg3BYAAQBQAAAtAzQAnArAABBQAABGgyBHQgnA3hgBeIgrApIAAABIDyAAIAAA+g");
        this.shape_305.setTransform(468.6, 241, 0.15, 0.15);

        this.shape_306 = new cjs.Shape();
        this.shape_306.graphics.f("#000000").s().p("Ag1GoIAApfIBsAAIAAJfgAgwkyQgTgTAAgdQAAgdAUgUQAUgUAbAAQAfAAATAUQASATAAAeQABAdgTATQgUAUgeAAQgdAAgTgUg");
        this.shape_306.setTransform(487.8, 260.5, 0.15, 0.15);

        this.shape_307 = new cjs.Shape();
        this.shape_307.graphics.f("#000000").s().p("ADOGnIkKmsQhoiog2hzIgDABQAICUAADIIAAFqIhnAAIAAtNIB4AAIEMGqQBcCUA7CAIADgCQgNiNAAjNIAAliIBoAAIAANNg");
        this.shape_307.setTransform(479.2, 260.5, 0.15, 0.15);

        this.shape_308 = new cjs.Shape();
        this.shape_308.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_308.setTransform(481.6, 260.5, 0.15, 0.15);

        this.shape_309 = new cjs.Shape();
        this.shape_309.graphics.f("#000000").s().p("Ag9D/QBNhtAAiSQAAiShNhsIArAAQBQBpAACVQAACThQBsg");
        this.shape_309.setTransform(447, 457, 0.15, 0.15);

        this.shape_310 = new cjs.Shape();
        this.shape_310.graphics.f("#000000").s().p("AhjCjQgngvAAhQQAAg4ATgxQASgtAgggQAzgzBNgJQAXgDARAAIAAAtQgUgBgVAEQg8AKgmArQgiAmgIA2IACAAQAQgVAXgMQAbgOAeAAQA3AAAiAkQAiAiAAA8QAAA6gkApQgmAsg9AAQhAAAgngvgAgtgIQgVAMgMAWQgGALAAAOQABA0AXAgQAYAhAoAAIAAAAQAkAAAVgbQAWgbAAgsQAAgsgXgZQgWgXgmAAQgXAAgWAOg");
        this.shape_310.setTransform(443.4, 456.6, 0.15, 0.15);

        this.shape_311 = new cjs.Shape();
        this.shape_311.graphics.f("#000000").s().p("AhjCjQgngvAAhQQAAg3ATgyQASgtAfggQA1gzBMgJQAXgDARAAIAAAtQgUgBgVAEQg7AKgnArQgiAmgIA2IACAAQAQgVAYgMQAbgOAdAAQA3AAAiAkQAjAiAAA8QgBA6gjApQgnAsg9AAQhAAAgngvgAgtgIQgVAMgMAWQgFALAAAOQAAA0AXAgQAYAhAoAAIABAAQAjAAAVgbQAWgbAAgsQAAgsgXgZQgWgXgmAAQgXAAgWAOg");
        this.shape_311.setTransform(438.6, 456.6, 0.15, 0.15);

        this.shape_312 = new cjs.Shape();
        this.shape_312.graphics.f("#000000").s().p("AiBDPIAAgiIArgqQBWhRAcgnQAkgwABgrQAAgjgSgVQgVgYgpAAQgsAAgqAjIgSgoQAzgpBBAAQA7AAAiAmQAdAgABAxQAAA0gmA1QgeAphHBHIggAeIAAACIC0AAIAAAtg");
        this.shape_312.setTransform(433.7, 456.6, 0.15, 0.15);

        this.shape_313 = new cjs.Shape();
        this.shape_313.graphics.f("#000000").s().p("AATD/QhQhsAAiSQABiTBPhsIArAAQhNBrAACUQAACPBNBvg");
        this.shape_313.setTransform(430.2, 457, 0.15, 0.15);

        this.shape_314 = new cjs.Shape();
        this.shape_314.graphics.f("#000000").s().p("AgqFQQgqgtAAhyIAAlKIheAAIAAhUIBeAAIAAhwIBpgiIAACSICeAAIAABUIieAAIAAFHQAAA6ATAdQAUAfAsAAQAoAAAYgHIAFBSQgnARg7AAQhLgBgqgvg");
        this.shape_314.setTransform(445.8, 437.9, 0.15, 0.15);

        this.shape_315 = new cjs.Shape();
        this.shape_315.graphics.f("#000000").s().p("AFEGnIgWl0QgNkHABhlIgEAAQgtCdg9CjIiVGbIhRAAIiImUQhCjAggiHIgDAAQgECtgMDIIgWFrIhoAAIA6tNICMAAICQGaQA4ClAdB2IACAAQAchxA8iqICXmaICLAAIA0NNg");
        this.shape_315.setTransform(435.2, 437.1, 0.15, 0.15);

        this.shape_316 = new cjs.Shape();
        this.shape_316.graphics.f("#000000").s().p("AiHEZIAAg9QAKACAQgBIAhgDQBEgKAsgrQA6g0AOhdIgCAAQgxA7hOAAQhHAAgugxQgrgtAAhHQAAhQAzg4QA2g6BOAAQBUAAAwA/QAwA+AABpQAABTgbBEQgYA9gqAqQgfAegqATQgnASgsAGQgeAEgZAAIgNAAgAhOi6QgeAlAAA6QAAAzAdAgQAcAeAvAAQAiAAAdgQQAbgNAPgaQAHgKAAgQQAAhKgbgsQgdgvg1AAIgBAAQgvAAgdAmg");
        this.shape_316.setTransform(437.7, 417.9, 0.15, 0.15);

        this.shape_317 = new cjs.Shape();
        this.shape_317.graphics.f("#000000").s().p("AiEDRQgyhLgBiFQAAiEA2hMQAzhJBSAAQBVAAAwBIQAuBJABCCQgBCJgxBLQgwBKhZAAQhRAAgwhIgAhNilQggA8AABrQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhogag5Qgcg9g4AAQgwAAgdA6g");
        this.shape_317.setTransform(431.3, 417.9, 0.15, 0.15);

        this.shape_318 = new cjs.Shape();
        this.shape_318.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_318.setTransform(424.3, 417.9, 0.15, 0.15);

        this.shape_319 = new cjs.Shape();
        this.shape_319.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_319.setTransform(438.6, 437.2, 0.15, 0.15);

        this.shape_320 = new cjs.Shape();
        this.shape_320.graphics.f("#000000").s().p("AiMEQIDqnhIAAgBIkIAAIAAg9IFVAAIAAAwIjrHvg");
        this.shape_320.setTransform(431.9, 358.8, 0.15, 0.15);

        this.shape_321 = new cjs.Shape();
        this.shape_321.graphics.f("#000000").s().p("AiMEQIDqnhIAAgBIkIAAIAAg9IFVAAIAAAwIjrHvg");
        this.shape_321.setTransform(425.5, 358.8, 0.15, 0.15);

        this.shape_322 = new cjs.Shape();
        this.shape_322.graphics.f("#000000").s().p("AiSE3IAAmhQAAh2gFhIIBhAAIADB3IAGAAQAUg9AsgkQAugkA3AAQASAAAOAEIAABoQgSgEgUAAQg5AAgoAoQgmAngLBAQgFAeAAAVIAAFDg");
        this.shape_322.setTransform(440.9, 380, 0.15, 0.15);

        this.shape_323 = new cjs.Shape();
        this.shape_323.graphics.f("#000000").s().p("Ag1GnIAAtNIBrAAIAANNg");
        this.shape_323.setTransform(434.9, 378.3, 0.15, 0.15);

        this.shape_324 = new cjs.Shape();
        this.shape_324.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_324.setTransform(438.6, 378.3, 0.15, 0.15);

        this.shape_325 = new cjs.Shape();
        this.shape_325.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAjAKAhAAQA0AAAlggQAmghAAg1QgBg4glgfQgogghMAAQgbAAgwAGIAjkFIEBAAIAAA+IjNAAIgVCLQAWgDAXAAQBBAAAyAdQAiAUAUAfQAXAmAAAyQAABQg5A0Qg5A1hWAAQgqABgmgLg");
        this.shape_325.setTransform(432.2, 300, 0.15, 0.15);

        this.shape_326 = new cjs.Shape();
        this.shape_326.graphics.f("#000000").s().p("AA1EQIAAiVIj6AAIAAgwIDwlaIBPAAIAAFQIBMAAIAAA6IhMAAIAACVgAAIh4IiDC4IAAABICwAAIAAizQAAgnACgvIgCAAQgUAngZApg");
        this.shape_326.setTransform(425.9, 299.9, 0.15, 0.15);

        this.shape_327 = new cjs.Shape();
        this.shape_327.graphics.f("#000000").s().p("ACTG+IAAldQAAhRgfgtQgkg2hJAAQgyAAgpAhQgnAfgQAtQgHASAAAjIAAFvIhvAAIAAt7IBvAAIAAF8IACAAQAbgxA0gdQA2ggA5AAQBQAAA4A0QBMBEAACLIAAFqg");
        this.shape_327.setTransform(443.7, 319.4, 0.15, 0.15);

        this.shape_328 = new cjs.Shape();
        this.shape_328.graphics.f("#000000").s().p("ACiGqQgSgggniqQgShYgmglQgnglhIgDIhmAAIAAFvIhtAAIAAtCQBXgSB6AAQBVAAA7ARQA6ARAoAkQAgAcARAqQARApAAAyQAABQguA6QgqA2hHAWIAAADQBdAiAfCJQAYBnANAuQAQA9AMAXgAiklLIAAE1IBvAAQBVAAA0gsQAzgsAAhJQAAhPg2goQgygmhYgBQhIAAgjAKg");
        this.shape_328.setTransform(433.7, 319.7, 0.15, 0.15);

        this.shape_329 = new cjs.Shape();
        this.shape_329.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_329.setTransform(438.6, 319.4, 0.15, 0.15);

        this.shape_330 = new cjs.Shape();
        this.shape_330.graphics.f("#000000").s().p("AiMEQIDqngIAAgBIkIAAIAAg+IFVAAIAAAwIjrHvg");
        this.shape_330.setTransform(432.1, 241.1, 0.15, 0.15);

        this.shape_331 = new cjs.Shape();
        this.shape_331.graphics.f("#000000").s().p("AisEVIAAgtIA6g5QBxhsAmg1QAwhAABg6QAAgvgYgbQgbggg3gBQg8ABg3AtIgXg0QBBg3BYAAQBQAAAtAzQAnArAABBQAABGgyBHQgnA3hgBeIgrApIAAABIDyAAIAAA+g");
        this.shape_331.setTransform(425.5, 241, 0.15, 0.15);

        this.shape_332 = new cjs.Shape();
        this.shape_332.graphics.f("#000000").s().p("AjTDpQhUhXAAiNQABiTBXhaQBThUCAAAQCCAABRBWQBQBXABCMQgBCbhgBZQhTBMh5AAQh9AAhRhUgAiLifQgtBBAABeQAABlA0BDQA0BCBQAAQBOAAA0hCQA1hEAAhkQAAhagqhBQgyhPhaAAQhZAAgzBLg");
        this.shape_332.setTransform(444, 262.2, 0.15, 0.15);

        this.shape_333 = new cjs.Shape();
        this.shape_333.graphics.f("#000000").s().p("AjIFHQh3h1AAjLQAAjFB6h7QB6h7DDAAQBGAAA7ANQArAKAcAOIgaBaQhHgjhjAAQiVgBhYBcQhbBeAACiQAACdBVBbQBXBdCXAAQAxAAAwgJQAvgKAhgQIAXBWQgiASg2ALQhAANhHAAQi2AAhyhug");
        this.shape_333.setTransform(433.6, 260.5, 0.15, 0.15);

        this.shape_334 = new cjs.Shape();
        this.shape_334.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_334.setTransform(438.6, 260.5, 0.15, 0.15);

        this.shape_335 = new cjs.Shape();
        this.shape_335.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiShNhsIArAAQBQBpAACVQAACThQBsg");
        this.shape_335.setTransform(403.9, 457, 0.15, 0.15);

        this.shape_336 = new cjs.Shape();
        this.shape_336.graphics.f("#000000").s().p("AhUDHQgagHgPgKIAOgqQAOAJAWAGQAZAIAZAAQAnAAAcgYQAcgaAAgnQAAgpgcgYQgegYg5AAQgXAAghAFIAajEIDBAAIAAAuIiaAAIgQBpQARgCARAAQAxAAAlAWQAaAOAPAYQARAcAAAlQAAA7gqAoQgsAohAAAQgfAAgdgIg");
        this.shape_336.setTransform(400.3, 456.7, 0.15, 0.15);

        this.shape_337 = new cjs.Shape();
        this.shape_337.graphics.f("#000000").s().p("AhjCjQgngvAAhQQAAg3ATgyQASgtAgggQA0gzBMgJQAXgDARAAIAAAtQgTgBgWAEQg8AKgmArQgiAmgIA2IACAAQAQgVAYgMQAbgOAeAAQA2AAAiAkQAiAiAAA8QAAA6gkApQgmAsg9AAQhAAAgngvgAgtgIQgVAMgLAWQgHALAAAOQABA0AXAgQAYAhAoAAIABAAQAjAAAWgbQAWgbAAgsQAAgsgXgZQgXgXgmAAQgXAAgWAOg");
        this.shape_337.setTransform(395.6, 456.6, 0.15, 0.15);

        this.shape_338 = new cjs.Shape();
        this.shape_338.graphics.f("#000000").s().p("AiADPIAAgiIAqgqQBWhRAbgnQAlgwABgrQAAgjgSgVQgVgYgpAAQgrAAgrAjIgSgoQAygpBCAAQA7AAAiAmQAdAgABAxQAAA0gnA1QgdAphHBHIghAeIAAACIC2AAIAAAtg");
        this.shape_338.setTransform(390.7, 456.6, 0.15, 0.15);

        this.shape_339 = new cjs.Shape();
        this.shape_339.graphics.f("#000000").s().p("AATD/QhQhsAAiSQABiTBPhsIArAAQhNBrAACUQAACPBNBvg");
        this.shape_339.setTransform(387.2, 457, 0.15, 0.15);

        this.shape_340 = new cjs.Shape();
        this.shape_340.graphics.f("#000000").s().p("Ah5EyQgrgMghgTIAchUQAbARAlAMQAqAPAnAAQA4AAAfgbQAdgYAAgoQAAgngagZQgZgZg8gXQigg4AAhyQAAhMA4gyQA6g0BdgBQArAAAqAMQAkAKAbAQIgbBQQg4gjhEAAQgtAAgcAZQgaAXAAAkQAAAjAcAXQAYAUA9AYQBRAfAmAoQAoAtAABCQAABSg7AyQg+AzhoABQgwgBgugLg");
        this.shape_340.setTransform(401.3, 438.9, 0.15, 0.15);

        this.shape_341 = new cjs.Shape();
        this.shape_341.graphics.f("#000000").s().p("ADLGnIAAmNImWAAIAAGNIhtAAIAAtNIBtAAIAAFiIGWAAIAAliIBuAAIAANNg");
        this.shape_341.setTransform(391.5, 437.1, 0.15, 0.15);

        this.shape_342 = new cjs.Shape();
        this.shape_342.graphics.f("#000000").s().p("AiFDtQgxgpAAg/QAAgyAdglQAbgkA0gUIgBgDQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkguAWIAAADQA0ASAcAjQAdAlAAAxQAABGg2AsQg0AshNAAQhTAAgygsgAhSA2QgZAeABAnQgDArAeAeQAeAfAxAAQAxAAAegcQAdgbABgqQgBgvgggeQgcgZg5gRQgvANgaAegAhDjKQgYAZgBAlQAABJBmAbQAlgMAWgZQAXgaABgkQgBgkgUgZQgZgcguAAQgqAAgaAag");
        this.shape_342.setTransform(394.6, 417.9, 0.15, 0.15);

        this.shape_343 = new cjs.Shape();
        this.shape_343.graphics.f("#000000").s().p("AiEDRQgxhLgCiFQAAiEA1hMQAzhJBTAAQBWAAAvBIQAvBJAACCQAACJgxBLQgxBKhZAAQhRAAgwhIgAhOilQgfA8AABrQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhogag5Qgcg9g4AAQgwAAgeA6g");
        this.shape_343.setTransform(388.2, 417.9, 0.15, 0.15);

        this.shape_344 = new cjs.Shape();
        this.shape_344.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_344.setTransform(381.3, 417.9, 0.15, 0.15);

        this.shape_345 = new cjs.Shape();
        this.shape_345.graphics.f("#BF9AC1").s().p("A0WcpMAAAg5RMAouAAAMAAAA5Rg");
        this.shape_345.setTransform(395.5, 437.2, 0.15, 0.15);

        this.shape_346 = new cjs.Shape();
        this.shape_346.graphics.f("#000000").s().p("AiEDaQg1hAAAhqQAAhLAahCQAYg8AqgqQBFhEBngNQAYgEAdAAIAAA8QgcgBgbAFQhQAOgzA4QguAzgKBJIADAAQAVgcAggRQAjgSApAAQBIAAAuAwQAuAvAABPQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAOAAATQABBFAeAqQAgAtA2AAIABAAQAvAAAdgkQAdglAAg6QAAg6gegiQgfgfgyAAQgfAAgdATg");
        this.shape_346.setTransform(388.8, 359, 0.15, 0.15);

        this.shape_347 = new cjs.Shape();
        this.shape_347.graphics.f("#000000").s().p("AiMEQIDqngIAAgBIkHAAIAAg+IFUAAIAAAxIjqHug");
        this.shape_347.setTransform(382.5, 359, 0.15, 0.15);

        this.shape_348 = new cjs.Shape();
        this.shape_348.graphics.f("#000000").s().p("Ah4EyQgsgMghgTIAchVQAbASAlAMQArAOAmABQA4gBAfgaQAcgYAAgoQAAgogZgYQgZgZg8gXQigg3AAhzQAAhMA4gyQA6g1BdAAQArAAApAMQAlAKAcAQIgcBRQg4gkhDAAQguAAgcAYQgaAYAAAjQAAAkAcAXQAYAUA9AYQBRAfAmAoQAoAtAABCQAABSg7AyQg+A0hngBQgxABgtgMg");
        this.shape_348.setTransform(402, 380.1, 0.15, 0.15);

        this.shape_349 = new cjs.Shape();
        this.shape_349.graphics.f("#000000").s().p("AkWE+Qhqh4AAi/QAAjFBvh8QBuh6CpAAQCrAABpB4QBnB3AAC9QAADRhzB7QhsBxinAAQioAAhph3gAjIjwQhEBiAACTQAACOBHBhQBLBoB6AAQB9AABKhoQBHhiAAiVQAAiKhDhhQhKhtiAAAQh/AAhKBrg");
        this.shape_349.setTransform(391.9, 378.3, 0.15, 0.15);

        this.shape_350 = new cjs.Shape();
        this.shape_350.graphics.f("#BF9AC1").s().p("A0WcpMAAAg5RMAouAAAMAAAA5Rg");
        this.shape_350.setTransform(395.5, 378.3, 0.15, 0.15);

        this.shape_351 = new cjs.Shape();
        this.shape_351.graphics.f("#000000").s().p("AA1EQIAAiVIj6AAIAAgwIDwlaIBPAAIAAFQIBMAAIAAA6IhMAAIAACVgAAIh4IiDC4IAAABICwAAIAAizQAAgnACgvIgCAAQgUAngZApg");
        this.shape_351.setTransform(389.3, 299.9, 0.15, 0.15);

        this.shape_352 = new cjs.Shape();
        this.shape_352.graphics.f("#000000").s().p("AA1EQIAAiVIj6AAIAAgwIDwlaIBPAAIAAFQIBMAAIAAA6IhMAAIAACVgAAIh4IiDC4IAAABICwAAIAAizQAAgnACgvIgCAAQgUAngZApg");
        this.shape_352.setTransform(382.9, 299.9, 0.15, 0.15);

        this.shape_353 = new cjs.Shape();
        this.shape_353.graphics.f("#000000").s().p("Ai7ECQhFhFAAiRIAAliIBuAAIAAFPQAADCCHAAQAyAAApggQAjgcARgpQAKgZAAgfIAAl0IBuAAIAAG5QAABqAFA8IhhAAIgGhkIgDAAQgbAugrAdQg5AnhHAAQhXAAg1g1g");
        this.shape_353.setTransform(400.5, 321.2, 0.15, 0.15);

        this.shape_354 = new cjs.Shape();
        this.shape_354.graphics.f("#000000").s().p("ACiGrQgSghgniqQgShYgmglQgnglhIgCIhnAAIAAFvIhsAAIAAtDQBXgRB6AAQBVgBA7ASQA6AQAoAkQAgAcARAqQARAqAAAwQAABRguA7QgqA1hHAWIAAAEQBdAgAfCLQAYBmANAuQAQA+AMAXgAillLIAAE1IBwAAQBVAAA0gsQAzgsAAhIQAAhQg2gpQgyglhYgBQhJAAgjAKg");
        this.shape_354.setTransform(390.8, 319.3, 0.15, 0.15);

        this.shape_355 = new cjs.Shape();
        this.shape_355.graphics.f("#BF9AC1").s().p("A0WcpMAAAg5RMAouAAAMAAAA5Rg");
        this.shape_355.setTransform(395.5, 319.4, 0.15, 0.15);

        this.shape_356 = new cjs.Shape();
        this.shape_356.graphics.f("#000000").s().p("AiEDaQg1g/AAhrQAAhLAahCQAYg8AqgqQBFhEBngMQAbgFAaAAIAAA8QgZgBgeAFQhQANgzA5QguA0gKBHIADAAQAVgbAggRQAjgTApAAQBIAAAuAxQAuAuAABQQAABOgwA3Qg0A7hRAAQhVAAg0g/gAg8gMQgdARgPAeQgIAOAAATQABBFAeArQAgAsA2AAIABAAQAvAAAdgkQAdglAAg6QAAg6geghQgfgggyAAQgfAAgdASg");
        this.shape_356.setTransform(389, 241.1, 0.15, 0.15);

        this.shape_357 = new cjs.Shape();
        this.shape_357.graphics.f("#000000").s().p("AisEVIAAgtIA6g5QBwhrAmg2QAxhAABg6QAAgvgYgbQgbggg3gBQg8ABg3AtIgYg0QBCg3BYAAQBQAAAtAzQAnArAABBQAABGgyBHQgnA3hgBeIgrApIAAABIDyAAIAAA+g");
        this.shape_357.setTransform(382.5, 241, 0.15, 0.15);

        this.shape_358 = new cjs.Shape();
        this.shape_358.graphics.f("#000000").s().p("Ai7DoQhPhTAAiMQAAiLBMhbQBPhfCAgBQCFAABCBmQAzBNAABsQAAAWgEAcImnAAQACBpA9A5QA3AxBXAAQA3AAArgJQAigIAkgOIATBOQhUAnh2ABQiIAAhRhWgAhxiwQgmAxgIBGIFAAAQABhEgfgxQgog/hTAAQhKgBgvA+g");
        this.shape_358.setTransform(399.5, 262.1, 0.15, 0.15);

        this.shape_359 = new cjs.Shape();
        this.shape_359.graphics.f("#000000").s().p("AjiGnIAAtNIHFAAIAABbIlYAAIAAEaIE9AAIAABZIk9AAIAAF/g");
        this.shape_359.setTransform(391, 260.4, 0.15, 0.15);

        this.shape_360 = new cjs.Shape();
        this.shape_360.graphics.f("#BF9AC1").s().p("A0WcpMAAAg5RMAouAAAMAAAA5Rg");
        this.shape_360.setTransform(395.5, 260.5, 0.15, 0.15);

        this.shape_361 = new cjs.Shape();
        this.shape_361.graphics.f("#000000").s().p("Ag9EAQBNhwAAiQQAAiShNhsIArAAQBQBpAACVQAACThQBtg");
        this.shape_361.setTransform(360.9, 457.4, 0.15, 0.15);

        this.shape_362 = new cjs.Shape();
        this.shape_362.graphics.f("#000000").s().p("AiBDPIAAgiIAsgpQBVhSAbgoQAlguAAgtQABgjgSgUQgVgYgpAAQgsAAgqAiIgSgmQAygqBCAAQA7AAAiAlQAeAhgBAxQABA0gnA0QgcAphHBIIgiAeIAAABIC1AAIAAAug");
        this.shape_362.setTransform(357.3, 457, 0.15, 0.15);

        this.shape_363 = new cjs.Shape();
        this.shape_363.graphics.f("#000000").s().p("AhjCjQgngvAAhQQAAg3ATgyQASgtAgggQA0gzBMgJQAXgDARAAIAAAtQgUgBgVAEQg8AKgmArQgiAmgIA2IACAAQAQgVAYgMQAbgOAeAAQA2AAAiAkQAiAiAAA7QAAA7gkApQgmAsg9AAQhAAAgngvgAgtgIQgVAMgLAWQgHALAAAOQABA0AXAgQAYAhAoAAIABAAQAjAAAWgbQAWgbAAgsQAAgsgXgZQgXgXgmAAQgXAAgWAOg");
        this.shape_363.setTransform(352.5, 457.1, 0.15, 0.15);

        this.shape_364 = new cjs.Shape();
        this.shape_364.graphics.f("#000000").s().p("AiBDPIAAgiIAsgpQBVhSAbgoQAlguAAgtQAAgjgRgUQgVgYgoAAQguAAgpAiIgSgmQAxgqBDAAQA7AAAiAlQAdAhABAxQgBA0glA0QgeAqhHBHIggAeIAAABIC1AAIAAAug");
        this.shape_364.setTransform(347.6, 457, 0.15, 0.15);

        this.shape_365 = new cjs.Shape();
        this.shape_365.graphics.f("#000000").s().p("AATEAQhQhuAAiSQABiSBPhsIArAAQhNBpAACVQAACPBNBxg");
        this.shape_365.setTransform(344.1, 457.4, 0.15, 0.15);

        this.shape_366 = new cjs.Shape();
        this.shape_366.graphics.f("#000000").s().p("ACTG+IAAleQAAhQgegtQglg2hJAAQgyAAgpAhQgnAfgQAtQgHARAAAkIAAFvIhvAAIAAt7IBvAAIAAF8IADAAQAbgxA0gdQA1ggA5AAQBQAAA4A0QBMBEgBCLIAAFqg");
        this.shape_366.setTransform(357.6, 437.7, 0.15, 0.15);

        this.shape_367 = new cjs.Shape();
        this.shape_367.graphics.f("#000000").s().p("AkIGkIAAs/QBSgSB1AAQBPAAA3AOQA3APAoAgQBGA0AABiQAAA9gmAzQgmAyhDAYIAAACQBHASAuAvQA6A8AABWQAABkhIBGQhVBPjMAAQhiAAhHgKgAicFTQAbAGBAAAQBdAAA5glQBCgqgBhWQAAhThAgqQg6gmhdgBIhbAAgAiclSIAAERIBjAAQBTAAAygoQAwgnAAg/QAAhHg0gjQgugghWAAQg+AAgiAHg");
        this.shape_367.setTransform(347.6, 438, 0.15, 0.15);

        this.shape_368 = new cjs.Shape();
        this.shape_368.graphics.f("#000000").s().p("AiMEQIDqngIAAgCIkIAAIAAg9IFVAAIAAAxIjrHug");
        this.shape_368.setTransform(351.7, 418.4, 0.15, 0.15);

        this.shape_369 = new cjs.Shape();
        this.shape_369.graphics.f("#000000").s().p("AiEDRQgxhLgCiFQAAiEA1hMQAzhJBTAAQBWAAAvBIQAvBJAACCQAACJgyBLQgxBKhYAAQhRAAgwhIgAhOilQgfA8AABrQAABpAeA7QAdA6AyAAQA2AAAdg+QAbg6AAhpQAAhpgag4Qgdg9g3AAQgwAAgeA6g");
        this.shape_369.setTransform(345.2, 418.4, 0.15, 0.15);

        this.shape_370 = new cjs.Shape();
        this.shape_370.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_370.setTransform(338.2, 418.4, 0.15, 0.15);

        this.shape_371 = new cjs.Shape();
        this.shape_371.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_371.setTransform(352.5, 437.7, 0.15, 0.15);

        this.shape_372 = new cjs.Shape();
        this.shape_372.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAVAMAbAIQAjAKAhAAQA0AAAkggQAnghAAg1QgBg4glgfQgogghMAAQgcAAgwAGIAjkFIECAAIAAA+IjNAAIgVCLQAWgDAWAAQBDAAAwAdQAjAUAUAfQAXAmAAAyQAABQg5A0Qg5A1hWAAQgqAAgmgKg");
        this.shape_372.setTransform(345.6, 359.4, 0.15, 0.15);

        this.shape_373 = new cjs.Shape();
        this.shape_373.graphics.f("#000000").s().p("AiLEQIDpnhIAAgBIkIAAIAAg9IFVAAIAAAxIjqHug");
        this.shape_373.setTransform(339.4, 359.3, 0.15, 0.15);

        this.shape_374 = new cjs.Shape();
        this.shape_374.graphics.f("#000000").s().p("Ai7DpQhPhUAAiMQAAiLBMhcQBPhfB/AAQCFAABDBmQAzBNAABsQAAAMgEAmImoAAQACBqA+A3QA3AyBXAAQA3AAArgJQAigIAkgPIATBQQhWAnh0AAQiIAAhRhVgAhxiwQgnAxgHBFIE/AAQAChEgfgwQgohAhTAAQhKAAgvA+g");
        this.shape_374.setTransform(357.2, 380.5, 0.15, 0.15);

        this.shape_375 = new cjs.Shape();
        this.shape_375.graphics.f("#000000").s().p("ACiGqQgSgfgnirQgShYgmglQgnglhIgDIhnAAIAAFvIhsAAIAAtCQBWgRB7gBQBVAAA7ARQA6ARAoAkQAgAcARAqQARApAAAyQAABQguA6QgqA2hHAWIAAAEQBdAgAfCLQAYBmANAuQAQA+AMAWgAillLIAAE1IBwAAQBVAAA0gsQAzgsAAhJQAAhPg2goQgygmhYgBQhJAAgjAKg");
        this.shape_375.setTransform(347.9, 378.7, 0.15, 0.15);

        this.shape_376 = new cjs.Shape();
        this.shape_376.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_376.setTransform(352.5, 378.8, 0.15, 0.15);

        this.shape_377 = new cjs.Shape();
        this.shape_377.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACThQBsg");
        this.shape_377.setTransform(358.5, 339.6, 0.15, 0.15);

        this.shape_378 = new cjs.Shape();
        this.shape_378.graphics.f("#000000").s().p("AhkCxQgkgfAAguQAAhLBQggIAAgCQghgPgQgZQgPgYAAgcQgBgwAlgfQAjgeA1AAQA3AAAiAfQAdAdAAApQAAA/hDAhIAAABQAnAOAVAaQAWAbAAAlQAAA0goAiQgnAgg6ABQg+AAgmgigAg9ApQgTAWAAAeQgBAgAVAWQAXAXAlAAQAkAAAXgVQAWgUAAggQAAgjgYgWQgVgTgrgNQgjALgTAWgAgyiWQgSASAAAcQAAA3BLAUQAcgKAQgSQASgUAAgaQAAgcgQgSQgSgVgjAAQgfAAgTAUg");
        this.shape_378.setTransform(354.9, 339.2, 0.15, 0.15);

        this.shape_379 = new cjs.Shape();
        this.shape_379.graphics.f("#000000").s().p("AhlDSIAAgtQAKABAigDQAzgHAhggQArgnALhGIgCAAQgkAsg6AAQg2AAgigkQghgiAAg1QAAg8AngqQAogrA7AAQA+AAAkAvQAlAuAABPQgBA+gTAzQgTAtggAfQgvAvhFAIQgVADgUAAIgKAAgAg7iLQgWAcAAArQAAAmAVAYQAWAXAjAAQAZAAAWgMQAVgKALgTQAFgIAAgMQAAg3gUghQgWgjgoAAIAAAAQgjAAgXAcg");
        this.shape_379.setTransform(350.1, 339.2, 0.15, 0.15);

        this.shape_380 = new cjs.Shape();
        this.shape_380.graphics.f("#000000").s().p("AATD/QhQhsAAiTQAAiSBQhsIArAAQhNBpAACVQAACQBNBvg");
        this.shape_380.setTransform(346.5, 339.6, 0.15, 0.15);

        this.shape_381 = new cjs.Shape();
        this.shape_381.graphics.f("#000000").s().p("AhvENQgigKgXgPIAUg4QATAMAeAJQAlAMAiABQA/AAAggkQAbgdgBgpQgBg2grgdQgngag3AAIgpAAIAAg1IApAAQAtAAAigXQAogZAAgtQAAgjgWgWQgagZgtAAQgfAAgfAMQgbAKgUAOIgTg2QAXgRAlgMQApgNApABQBJAAAqAoQAmAjAAA3QAAArgZAhQgaAigxASIAAACQA0AKAiAiQAjAmAAA3QAABGgyAuQg2AxhcgBQgrAAgpgMg");
        this.shape_381.setTransform(346.1, 300.5, 0.15, 0.15);

        this.shape_382 = new cjs.Shape();
        this.shape_382.graphics.f("#000000").s().p("AA1EQIAAiUIj7AAIAAgxIDxlaIBPAAIAAFQIBNAAIAAA7IhNAAIAACUgAAIh3IiDC3IAAABICwAAIAAi0QAAgyADgjIgDAAQgZAvgUAig");
        this.shape_382.setTransform(339.8, 300.5, 0.15, 0.15);

        this.shape_383 = new cjs.Shape();
        this.shape_383.graphics.f("#000000").s().p("AibDnQhThWAAiMQAAiMBZhZQBahcCRAAQAtAAAtAKQAlAIAaANIgZBWQgzgdhNAAQhiAAg7BDQg3BAAABhQAABoA8A/QA6A9BaAAQAqAAAmgKQAYgHAggOIASBTQgaAOgpALQg0AMg3AAQiHAAhShWg");
        this.shape_383.setTransform(356.9, 321.5, 0.15, 0.15);

        this.shape_384 = new cjs.Shape();
        this.shape_384.graphics.f("#000000").s().p("Ag3GnIAArwIkAAAIAAhdIJvAAIAABdIkCAAIAALwg");
        this.shape_384.setTransform(349.2, 319.7, 0.15, 0.15);

        this.shape_385 = new cjs.Shape();
        this.shape_385.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_385.setTransform(352.5, 319.9, 0.15, 0.15);

        this.shape_386 = new cjs.Shape();
        this.shape_386.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAiAKAiAAQA0AAAkggQAnghAAg1QgBg4glgfQgogghMAAQgbAAgxAGIAkkGIEBAAIAAA+IjNAAIgVCMQAdgDAPAAQBDAAAwAdQAjAUAUAgQAXAmAAAwQAABQg5A1Qg5A2hWAAQgpAAgngLg");
        this.shape_386.setTransform(345.8, 241.6, 0.15, 0.15);

        this.shape_387 = new cjs.Shape();
        this.shape_387.graphics.f("#000000").s().p("AisEUIAAgtIA6g4QBwhrAmg3QAxg/ABg6QAAgvgYgbQgcghg2ABQg8gBg3AvIgYg0QBBg3BZAAQBQAAAtAxQAnAsAABAQAABGgyBHQgmA2hhBhIgrAnIAAACIDyAAIAAA9g");
        this.shape_387.setTransform(339.4, 241.5, 0.15, 0.15);

        this.shape_388 = new cjs.Shape();
        this.shape_388.graphics.f("#000000").s().p("ACWE3IAAldQAAhQgfguQgkg2hKAAQgyAAgqAiQgnAfgOAwQgIAXAAAdIAAFsIhuAAIAAm6QAAhmgFg/IBhAAIAHBlIACAAQAagwAwgfQA5gkBEAAQBSAAA5A0QBLBEAACLIAAFqg");
        this.shape_388.setTransform(360.3, 262.6, 0.15, 0.15);

        this.shape_389 = new cjs.Shape();
        this.shape_389.graphics.f("#000000").s().p("AFEGnIgVl0QgOj9ABhvIgEAAQgsCZg+CnIiVGbIhRAAIiImTQhEjIgeiAIgDAAQgECvgMDGIgWFrIhoAAIA7tNICLAAICQGaQA4CmAdB1IACAAQAbhuA9itICXmaICLAAIA0NNg");
        this.shape_389.setTransform(347.3, 260.9, 0.15, 0.15);

        this.shape_390 = new cjs.Shape();
        this.shape_390.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_390.setTransform(352.5, 260.9, 0.15, 0.15);

        this.shape_391 = new cjs.Shape();
        this.shape_391.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACThQBsg");
        this.shape_391.setTransform(317.8, 457.8, 0.15, 0.15);

        this.shape_392 = new cjs.Shape();
        this.shape_392.graphics.f("#000000").s().p("AhSDJQgagHgSgLIAQgrQAOAJAWAIQAcAJAaAAQAuAAAZgbQATgVAAgfQgBgogggXQgdgTgpAAIgfAAIAAgnIAfAAQAhAAAZgQQAfgUAAghQAAgbgRgRQgTgSgiAAQgWAAgYAJQgUAHgPALIgPgoQARgNAcgJQAfgKAfAAQA2AAAgAeQAcAbAAApQAAAhgSAYQgUAaglANIAAABQAoAIAYAZQAbAdAAApQAAA0gmAiQgoAkhFAAQgfABgfgKg");
        this.shape_392.setTransform(314.2, 457.4, 0.15, 0.15);

        this.shape_393 = new cjs.Shape();
        this.shape_393.graphics.f("#000000").s().p("AhjCjQgngvAAhQQAAg4ATgxQASgtAgggQA0gzBMgJQAXgDARAAIAAAtQgUgBgVAEQg8AKgmArQgiAmgIA2IACAAQAQgVAYgMQAagOAeAAQA3AAAiAkQAiAiAAA7QAAA7gkApQgmAsg9AAQhAAAgngvgAgtgIQgVAMgLAWQgHALAAAOQABA0AXAfQAYAiAoAAIABAAQAjAAAWgbQAWgcAAgrQAAgsgXgZQgXgXgmAAQgXAAgWAOg");
        this.shape_393.setTransform(309.5, 457.4, 0.15, 0.15);

        this.shape_394 = new cjs.Shape();
        this.shape_394.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBUhRAcgoQAlgvAAgsQAAgjgRgUQgVgYgoAAQgvAAgoAiIgSgnQAxgpBCAAQA8AAAiAmQAdAhABAwQgBA0glA1QgdAphIBHIggAeIAAABIC0AAIAAAug");
        this.shape_394.setTransform(304.6, 457.4, 0.15, 0.15);

        this.shape_395 = new cjs.Shape();
        this.shape_395.graphics.f("#000000").s().p("AATD/QhQhsAAiTQABiTBPhrIArAAQhNBpAACVQAACQBNBvg");
        this.shape_395.setTransform(301.1, 457.8, 0.15, 0.15);

        this.shape_396 = new cjs.Shape();
        this.shape_396.graphics.f("#000000").s().p("AiJGtQg5gOgjgXIAbhVQAhAVArAMQAyAPA1AAQBXAAAygxQA3g2AAhuIAAhDIgCAAQgbAuguAaQg0AdhBABQhxAAhJhVQhJhVAAh9QABiUBUhbQBOhUBuAAQBGAAA0AiQAqAbAXAtIADAAIAFhcIBhAAQgFBXgBBQIAAFfQABBogWBDQgUBDgtAoQhNBJiOAAQg4AAg1gNgAh4kkQgyBAAABnQAABfAtA6QAxBABTAAQA0AAApgeQAqgfARgyQAJgaAAghIAAhuQABgegHgTQgQg0gmgfQgrgjg5ABQhNgBgzA/g");
        this.shape_396.setTransform(314, 439.8, 0.15, 0.15);

        this.shape_397 = new cjs.Shape();
        this.shape_397.graphics.f("#000000").s().p("AigGlQg8gQgigYIAbhbQAoAZAxAOQA1AQA2AAQBQAAAwgoQAugoAAhAQABg8glgmQglgmhTghQhtglg2g3Qg9g8AAhWQABhkBKhAQBNhCB3AAQBzAABIApIgeBZQhJgnhXAAQhOgBgrAqQglAjAAAzQAAA4ApAmQAkAhBaAkQBvAqAyA3QA2A7AABbQAABphJBDQhRBJiMAAQg7AAg+gQg");
        this.shape_397.setTransform(304.4, 436.2, 0.15, 0.15);

        this.shape_398 = new cjs.Shape();
        this.shape_398.graphics.f("#000000").s().p("AiEDaQg1hAAAhqQAAhLAahCQAYg8AqgqQBFhEBngNQAdgEAZAAIAAA8QgZgBgfAFQhQANgyA5QguA0gKBHIACAAQAVgcAggQQAkgTAoAAQBJABAtAvQAuAvAABQQAABOgwA3QgzA7hRAAQhWAAg0g/gAg8gMQgcARgQAeQgIANAAATQABBGAfArQAgAsA2AAIAAAAQAwgBAdgjQAdglAAg6QAAg6gfgiQgegfgzAAQgfAAgdASg");
        this.shape_398.setTransform(308.6, 418.7, 0.15, 0.15);

        this.shape_399 = new cjs.Shape();
        this.shape_399.graphics.f("#000000").s().p("AiEDRQgxhLgCiFQAAiEA1hMQAzhKBTAAQBWAAAvBKQAvBIAACDQAACIgyBLQgxBKhYABQhRgBgwhIgAhOilQgfA9AABqQAABpAeA8QAdA5AyAAQA2AAAdg+QAbg6AAhpQAAhogag5Qgdg9g3AAQgwAAgeA6g");
        this.shape_399.setTransform(302.1, 418.7, 0.15, 0.15);

        this.shape_400 = new cjs.Shape();
        this.shape_400.graphics.f("#000000").s().p("AATEQIAAnbIgCAAIhcA0IgOg5IB1g/IA+AAIAAIfg");
        this.shape_400.setTransform(295.2, 418.7, 0.15, 0.15);

        this.shape_401 = new cjs.Shape();
        this.shape_401.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_401.setTransform(309.4, 438.1, 0.15, 0.15);

        this.shape_402 = new cjs.Shape();
        this.shape_402.graphics.f("#000000").s().p("AA1EQIAAiUIj6AAIAAgxIDwlaIBPAAIAAFRIBMAAIAAA6IhMAAIAACUgAAIh3IiDC3IAAACICwAAIAAi0QAAgmACgwIgCAAQgUAngZAqg");
        this.shape_402.setTransform(302.7, 359.6, 0.15, 0.15);

        this.shape_403 = new cjs.Shape();
        this.shape_403.graphics.f("#000000").s().p("AiMEQIDqngIAAgCIkIAAIAAg9IFVAAIAAAxIjqHug");
        this.shape_403.setTransform(296.4, 359.6, 0.15, 0.15);

        this.shape_404 = new cjs.Shape();
        this.shape_404.graphics.f("#000000").s().p("ACiGnIhrm3QgpingOhuIAAAAQgXB/gqCWIh5G3IhyAAIjWtNIBzAAIBlGrQAnCkAXCBIADAAQAJg4AThSIAoidIBxmpIBwAAIBnGsQAsC7APBnIACAAQAPhMA1jZIBvmpIBwAAIjvNNg");
        this.shape_404.setTransform(309.4, 379.1, 0.15, 0.15);

        this.shape_405 = new cjs.Shape();
        this.shape_405.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_405.setTransform(309.4, 379.1, 0.15, 0.15);

        this.shape_406 = new cjs.Shape();
        this.shape_406.graphics.f("#000000").s().p("AisEVIAAguIA6g4QBxhsAmg1QAwhAABg6QAAgugYgcQgbggg3AAQg8AAg3AuIgXg0QAegaAlgOQApgQAtAAQBQAAAtAyQAnAsAABBQAABGgyBHQgmA2hhBgIgrAoIAAACIDyAAIAAA9g");
        this.shape_406.setTransform(303.2, 300.8, 0.15, 0.15);

        this.shape_407 = new cjs.Shape();
        this.shape_407.graphics.f("#000000").s().p("AA1EQIAAiVIj7AAIAAgwIDxlaIBPAAIAAFQIBNAAIAAA6IhNAAIAACVgAAIh4IiDC4IAAABICwAAIAAizQAAgzADgjIgDAAQgZAwgUAgg");
        this.shape_407.setTransform(296.8, 300.8, 0.15, 0.15);

        this.shape_408 = new cjs.Shape();
        this.shape_408.graphics.f("#000000").s().p("AjTDpQhUhXAAiNQAAiUBYhZQBThUCAAAQCCgBBRBXQBRBWAACMQAACchgBZQhUBMh4AAQh+ABhRhVgAiLifQgsBBAABeQAABlAzBDQA1BDBPgBQBOABA1hDQA0hDAAhlQAAhagqhCQgyhNhaAAQhZgBgzBLg");
        this.shape_408.setTransform(316.9, 321.9, 0.15, 0.15);

        this.shape_409 = new cjs.Shape();
        this.shape_409.graphics.f("#000000").s().p("AFEGnIgVl0QgOj/ABhtIgEAAQgtCcg9CkIiVGbIhRAAIiImTQhEjIgeiAIgDAAQgECtgMDIIgWFrIhoAAIA7tNICLAAICQGaQA4CmAdB1IACAAQAbhvA9isICXmaICLAAIA0NNg");
        this.shape_409.setTransform(304, 320.1, 0.15, 0.15);

        this.shape_410 = new cjs.Shape();
        this.shape_410.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_410.setTransform(309.4, 320.2, 0.15, 0.15);

        this.shape_411 = new cjs.Shape();
        this.shape_411.graphics.f("#000000").s().p("AiADPIAAgiIAqgqQBVhQAcgpQAlgvAAgsQAAgigRgVQgVgYgpAAQgsAAgqAiIgRgnQAwgpBDAAQA7AAAiAlQAeAhgBAxQAAA0gmA0QgcAqhIBHIghAeIAAABIC1AAIAAAug");
        this.shape_411.setTransform(311.9, 281.6, 0.15, 0.15);

        this.shape_412 = new cjs.Shape();
        this.shape_412.graphics.f("#000000").s().p("AhUDHQgZgHgQgKIANgqQAnAXAxgBQAmAAAcgYQAdgYAAgoQgBgpgcgYQgegXg5gBQgXABgiAEIAbjEIDBAAIAAAuIiZAAIgQBqQAQgDARAAQAxAAAlAWQAaAOAPAXQARAdAAAkQAAA9grAoQgqAnhAAAQggAAgdgIg");
        this.shape_412.setTransform(307, 281.7, 0.15, 0.15);

        this.shape_413 = new cjs.Shape();
        this.shape_413.graphics.f("#000000").s().p("AA1EQIAAiUIj6AAIAAgxIDwlaIBPAAIAAFQIBMAAIAAA7IhMAAIAACUgAAIh3IiDC3IAAABICwAAIAAizQAAgmACgwIgCAAQgTAlgaAsg");
        this.shape_413.setTransform(302.8, 241.9, 0.15, 0.15);

        this.shape_414 = new cjs.Shape();
        this.shape_414.graphics.f("#000000").s().p("AisEVIAAguIA6g4QBwhrAmg2QAxhAABg6QAAgugYgcQgbggg3AAQg8AAg3AuIgYg0QAfgaAlgOQApgQAtAAQBQAAAtAyQAnAsAABBQABBGgzBHQgmA2hhBgIgrAoIAAACIDyAAIAAA9g");
        this.shape_414.setTransform(296.4, 241.8, 0.15, 0.15);

        this.shape_415 = new cjs.Shape();
        this.shape_415.graphics.f("#000000").s().p("AiSE3IAAmhQAAhtgFhRIBhAAIADB4IAFAAQAVg9AsglQAtgkA4AAQAQAAAQAEIAABpQgTgEgTAAQg5AAgoAoQglAmgMBAQgFAfAAAVIAAFCg");
        this.shape_415.setTransform(315.2, 262.9, 0.15, 0.15);

        this.shape_416 = new cjs.Shape();
        this.shape_416.graphics.f("#000000").s().p("AjIFHQh3h1AAjLQAAjFB6h7QB6h7DDAAQBGAAA7ANQArAKAcAOIgaBaQhIgjhjAAQiUgBhYBcQhbBeAACiQAACdBVBbQBXBdCWAAQAxAAAxgJQAvgKAhgQIAXBWQgiASg2ALQhAANhHAAQi3AAhxhug");
        this.shape_416.setTransform(306.2, 261.3, 0.15, 0.15);

        this.shape_417 = new cjs.Shape();
        this.shape_417.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_417.setTransform(309.4, 261.3, 0.15, 0.15);

        this.shape_418 = new cjs.Shape();
        this.shape_418.graphics.f("#000000").s().p("Ag9D/QBNhvAAiQQAAiShNhtIArAAQBQBqAACVQAACShQBtg");
        this.shape_418.setTransform(274.4, 457, 0.15, 0.15);

        this.shape_419 = new cjs.Shape();
        this.shape_419.graphics.f("#000000").s().p("AhiCcQgmg4AAhjQgBhjAog5QAmg3A+AAQBAAAAjA3QAjA2AABiQAABmglA4QglA4hBAAQg9AAgjg3gAg6h7QgXAtAABPQAABPAWAsQAWAsAlAAQAoAAAWguQAVgsgBhOQAAhOgTgrQgVgugqAAQgkAAgWAsg");
        this.shape_419.setTransform(270.8, 456.6, 0.15, 0.15);

        this.shape_420 = new cjs.Shape();
        this.shape_420.graphics.f("#000000").s().p("AhjCjQgngvAAhQQAAg4ATgxQASgtAgggQAzgzBNgJQAUgDAUAAIAAAtQgUgBgVADQg8ALgmAqQgiAmgIA2IACAAQAQgUAXgNQAbgOAeAAQA3AAAiAkQAiAjAAA7QAAA7gkApQgmAsg9AAQhAAAgngvgAgtgIQgVAMgMAWQgGALAAANQABA1AXAfQAYAhAoAAIAAAAQAkAAAVgbQAWgbAAgsQAAgrgXgZQgWgXgmAAQgXAAgWAOg");
        this.shape_420.setTransform(266, 456.6, 0.15, 0.15);

        this.shape_421 = new cjs.Shape();
        this.shape_421.graphics.f("#000000").s().p("AiADPIAAgiIArgqQBVhRAbgoQAlgvAAgrQAAgjgRgVQgVgYgpAAQgsAAgqAiIgRgnQAygpBBAAQA8AAAhAlQAdAhAAAxQAAA0gmA0QgcAphHBIIgiAeIAAABIC1AAIAAAug");
        this.shape_421.setTransform(261.1, 456.6, 0.15, 0.15);

        this.shape_422 = new cjs.Shape();
        this.shape_422.graphics.f("#000000").s().p("AATD/QhQhsAAiTQAAiSBQhtIArAAQhNBqAACVQAACPBNBwg");
        this.shape_422.setTransform(257.6, 457, 0.15, 0.15);

        this.shape_423 = new cjs.Shape();
        this.shape_423.graphics.f("#000000").s().p("Ai4FSIgEAAIgFBlIhfAAQAFhTAAhKIAAreIBtAAIAAF+IADAAQAeg0AzgdQA2geBFgBQBxAABIBXQBIBWgBCIQAACahVBaQhNBShuAAQiJAAhAhzgAhng5QgwAlgRA8QgGAeAAAPIAABuQAAAPAFAaQAQA5AtAkQAtAkA7AAQBUAAAyhBQAwg/AAhqQAAhhgug8QgxhEhTAAQg5ABguAkg");
        this.shape_423.setTransform(272.2, 437.2, 0.15, 0.15);

        this.shape_424 = new cjs.Shape();
        this.shape_424.graphics.f("#000000").s().p("AlZGkIAAtAQB1gRBzAAQDkAABwBqQB3BsAADEQAABlgfBUQgfBTg8A7Qg7A7hfAgQheAfh7AAQhxAAhVgKgAjslLIAAKaQAkAHBLAAQCrAABdheQBdhdAAirQABiZhVhVQhZhZinABQhMgBg0AMg");
        this.shape_424.setTransform(260.7, 437.5, 0.15, 0.15);

        this.shape_425 = new cjs.Shape();
        this.shape_425.graphics.f("#000000").s().p("AhwEKQghgJgWgOIASg4QAUAMAcAIQAiAKAiAAQA0AAAkggQAnghAAg1QgBg4glgfQgpgghMAAQgaAAgxAGIAjkGIEDAAIAAA+IjOAAIgUCMQAYgDATAAQBEAAAvAeQAjATAUAgQAXAmAAAxQAABQg4A1Qg6A1hWAAQgqAAgmgLg");
        this.shape_425.setTransform(264.9, 418, 0.15, 0.15);

        this.shape_426 = new cjs.Shape();
        this.shape_426.graphics.f("#000000").s().p("AiEDRQgxhLgCiFQAAiEA1hMQA0hJBSAAQBWAAAuBJQAwBIgBCDQAACIgwBLQgxBKhZAAQhRAAgwhIgAhOilQgfA8AABrQAABpAeA7QAeA6AxAAQA3AAAcg9QAbg7AAhpQABhogbg5Qgdg9g3AAQgvAAgfA6g");
        this.shape_426.setTransform(258.7, 417.9, 0.15, 0.15);

        this.shape_427 = new cjs.Shape();
        this.shape_427.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_427.setTransform(251.7, 417.9, 0.15, 0.15);

        this.shape_428 = new cjs.Shape();
        this.shape_428.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_428.setTransform(266, 437.2, 0.15, 0.15);

        this.shape_429 = new cjs.Shape();
        this.shape_429.graphics.f("#000000").s().p("AAUEQIAAnbIgCAAIhdA0IgOg5IB1g/IA+AAIAAIfg");
        this.shape_429.setTransform(259.2, 299.9, 0.15, 0.15);

        this.shape_430 = new cjs.Shape();
        this.shape_430.graphics.f("#000000").s().p("AA1EQIAAiVIj6AAIAAgwIDwlaIBPAAIAAFQIBMAAIAAA6IhMAAIAACVgAAIh4IiDC4IAAABICwAAIAAizQAAgzADgjIgDAAQgVAogYAog");
        this.shape_430.setTransform(253.3, 299.9, 0.15, 0.15);

        this.shape_431 = new cjs.Shape();
        this.shape_431.graphics.f("#000000").s().p("Ai4FTIgEAAIgEBkIhgAAQAFhTAAhKIAAreIBtAAIAAF+IADAAQAeg0AzgdQA2gfBFABQByAABHBVQBIBXgBCIQAACahVBaQhNBShuAAQiJAAhAhygAhng5QgwAmgQA7QgHAhAAAMIAABuQAAAPAFAZQARA6AsAkQAtAkA8AAQBTAAAyhBQAxg/AAhqQAAhggug9QgyhEhTAAQg5AAguAlg");
        this.shape_431.setTransform(272.2, 319.4, 0.15, 0.15);

        this.shape_432 = new cjs.Shape();
        this.shape_432.graphics.f("#000000").s().p("ADOGnIkKmsQhnimg3h1IgDABQAICYAADEIAAFqIhmAAIAAtNIB3AAIEMGqQBcCSA8CCIACgBQgMiOAAjNIAAliIBmAAIAANNg");
        this.shape_432.setTransform(260.2, 319.6, 0.15, 0.15);

        this.shape_433 = new cjs.Shape();
        this.shape_433.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_433.setTransform(266, 319.4, 0.15, 0.15);

        this.shape_434 = new cjs.Shape();
        this.shape_434.graphics.f("#000000").s().p("AhuENQgkgKgWgPIAUg5QATANAdAKQAmAMAiAAQA/AAAggkQAagdAAgpQgBg2grgdQgngag4AAIgpAAIAAg1IApAAQAuAAAhgWQAogaAAgtQABgjgXgWQgZgZgtAAQgeAAggAMQgaAKgVAOIgTg1QAXgRAkgMQApgNApAAQBKAAArAoQAlAkAAA2QAAArgZAhQgaAigxASIAAACQA1AKAgAiQAkAnAAA3QAABFgyAtQg3AxhbAAQgrAAgogMg");
        this.shape_434.setTransform(259.5, 359, 0.15, 0.15);

        this.shape_435 = new cjs.Shape();
        this.shape_435.graphics.f("#000000").s().p("AiMEQIDqngIAAgBIkIAAIAAg+IFVAAIAAAwIjqHvg");
        this.shape_435.setTransform(253.3, 359, 0.15, 0.15);

        this.shape_436 = new cjs.Shape();
        this.shape_436.graphics.f("#000000").s().p("AjCEHQgugxAAhHQAAhuBeg5QBfg6CtAAIAAgMQAAg4gWgiQgigzhPAAQgqAAgqAMQgqAMggAVIgZhJQAmgZAzgOQA2gPA2AAQB/AAA6BPQAtA+AABsIAADiQAABaAKA4IhkAAIgJhNIgDAAQgcAngtAYQg0Acg7AAQhXAAg0g3gAiCCCQAAAzAfAdQAcAaAtAAQA1AAApggQAkgcAPgqQAGgTAAgQIAAhoIgTAAQjsAAAACHg");
        this.shape_436.setTransform(270.8, 380, 0.15, 0.15);

        this.shape_437 = new cjs.Shape();
        this.shape_437.graphics.f("#000000").s().p("Ag2GnIAArwIkBAAIAAhdIJvAAIAABdIkCAAIAALwg");
        this.shape_437.setTransform(263.1, 378.2, 0.15, 0.15);

        this.shape_438 = new cjs.Shape();
        this.shape_438.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_438.setTransform(266.4, 378.3, 0.15, 0.15);

        this.shape_439 = new cjs.Shape();
        this.shape_439.graphics.f("#000000").s().p("AhuENQgjgKgXgPIAUg5QAUANAdAKQAlAMAiAAQA/AAAggkQAbgdgBgpQAAg2gsgdQgmgag4AAIgpAAIAAg2IApAAQAtAAAhgWQApgZAAgtQAAgjgWgWQgagZgtAAQgeAAggAMQgbAKgUAOIgTg2QAXgRAlgLQApgNApAAQBJAAArAoQAlAkAAA2QAAArgZAhQgaAigxASIAAACQA0AKAiAiQAjAnAAA3QAABFgyAtQg2AxhcAAQgqAAgpgMg");
        this.shape_439.setTransform(259.3, 241.1, 0.15, 0.15);

        this.shape_440 = new cjs.Shape();
        this.shape_440.graphics.f("#000000").s().p("AisEVIAAgtIA6g5QBxhsAmg1QAwhAABg6QAAgvgYgbQgbggg3gBQg7ABg4AtIgXg0QBBg3BYAAQBQAAAtAzQAnArAABBQAABGgyBHQgnA3hgBeIgrApIAAABIDyAAIAAA+g");
        this.shape_440.setTransform(252.9, 241, 0.15, 0.15);

        this.shape_441 = new cjs.Shape();
        this.shape_441.graphics.f("#000000").s().p("AhIGnIkTtNIB1AAICEGhQA/DEAbB3IACAAQAahwBFjJICPmjIB0AAIkuNNg");
        this.shape_441.setTransform(266, 260.5, 0.15, 0.15);

        this.shape_442 = new cjs.Shape();
        this.shape_442.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_442.setTransform(266, 260.5, 0.15, 0.15);

        this.shape_443 = new cjs.Shape();
        this.shape_443.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACThQBsg");
        this.shape_443.setTransform(231.3, 457, 0.15, 0.15);

        this.shape_444 = new cjs.Shape();
        this.shape_444.graphics.f("#000000").s().p("AhpDLICvlnIAAgBIjFAAIAAguID/AAIAAAlIiwFxg");
        this.shape_444.setTransform(227.8, 456.6, 0.15, 0.15);

        this.shape_445 = new cjs.Shape();
        this.shape_445.graphics.f("#000000").s().p("AhUDHQgagHgPgKIANgqQAnAWAxABQAmAAAbgYQAdgZAAgoQgBgpgbgYQgegYg5AAQgXAAgiAFIAbjEIDBAAIAAAuIiZAAIgQBpQAPgCASAAQAxAAAkAWQAaAOAQAYQARAcAAAlQAAA7grAoQgqAohBAAQgeAAgegIg");
        this.shape_445.setTransform(222.8, 456.7, 0.15, 0.15);

        this.shape_446 = new cjs.Shape();
        this.shape_446.graphics.f("#000000").s().p("AiADPIAAgiIArgqQBUhRAcgnQAlgwAAgrQAAgjgRgVQgVgYgpAAQgsAAgqAjIgRgoQAygpBBAAQA7AAAiAmQAdAgAAAxQAAA0gmA1QgcAphIBHIghAeIAAACIC2AAIAAAtg");
        this.shape_446.setTransform(218.1, 456.6, 0.15, 0.15);

        this.shape_447 = new cjs.Shape();
        this.shape_447.graphics.f("#000000").s().p("AATD/QhQhsAAiSQAAiTBQhsIArAAQhNBrAACUQAACPBNBvg");
        this.shape_447.setTransform(214.6, 457, 0.15, 0.15);

        this.shape_448 = new cjs.Shape();
        this.shape_448.graphics.f("#000000").s().p("AhwHFIAAoLIhVAAIAAhUIBVAAIAAgdQAAiRBHhDQAdgdAmgOQAlgOApAAQAzAAArASIgPBWQgdgOgpgBQh0AAAACxIAAAgICQAAIAABUIiQAAIAAILg");
        this.shape_448.setTransform(227.4, 437.2, 0.15, 0.15);

        this.shape_449 = new cjs.Shape();
        this.shape_449.graphics.f("#000000").s().p("ACiGqQgSgggniqQgShYgmglQgnglhIgDIhmAAIAAFvIhtAAIAAtCQBXgSB6AAQBVAAA7ARQA6ARAoAjQAgAdARApQARAqAAAxQAABRguA7QgqA1hHAWIAAADQBdAhAfCLQAYBlANAvQAQA+AMAWgAiklLIAAE1IBvAAQBVAAA0gsQAzgsAAhJQAAhPg2gpQgxglhZgBQhIAAgjAKg");
        this.shape_449.setTransform(219.6, 437.6, 0.15, 0.15);

        this.shape_450 = new cjs.Shape();
        this.shape_450.graphics.f("#000000").s().p("AA1EQIAAiVIj6AAIAAgwIDwlaIBPAAIAAFRIBMAAIAAA5IhMAAIAACVgAAIh3IiDC3IAAACICwAAIAAi0QAAgyADgjIgDAAQgWApgXAng");
        this.shape_450.setTransform(222, 417.9, 0.15, 0.15);

        this.shape_451 = new cjs.Shape();
        this.shape_451.graphics.f("#000000").s().p("AiEDRQgyhLAAiFQgBiEA1hMQA0hJBSAAQBVAAAvBIQAwBJgBCCQABCJgyBLQgxBKhYAAQhRAAgwhIgAhOilQgfA8AABrQAABpAeA7QAeA6AxAAQA2AAAcg9QAcg7AAhpQAAhogbg5Qgbg9g4AAQgwAAgeA6g");
        this.shape_451.setTransform(215.6, 417.9, 0.15, 0.15);

        this.shape_452 = new cjs.Shape();
        this.shape_452.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_452.setTransform(208.6, 417.9, 0.15, 0.15);

        this.shape_453 = new cjs.Shape();
        this.shape_453.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_453.setTransform(222.9, 437.2, 0.15, 0.15);

        this.shape_454 = new cjs.Shape();
        this.shape_454.graphics.f("#000000").s().p("AisEUIAAgtIA6g4QBxhsAmg1QAxhAAAg6QAAgvgXgbQgcggg3gBQg8AAg3AuIgXg0QAegYAlgPQAqgQAsAAQBQAAAtAzQAoArAABBQAABFgzBIQgmA3hgBfIgsAnIAAACIDyAAIAAA9g");
        this.shape_454.setTransform(216.2, 358.9, 0.15, 0.15);

        this.shape_455 = new cjs.Shape();
        this.shape_455.graphics.f("#000000").s().p("AiMEQIDqngIAAgBIkIAAIAAg+IFVAAIAAAwIjrHvg");
        this.shape_455.setTransform(209.9, 359, 0.15, 0.15);

        this.shape_456 = new cjs.Shape();
        this.shape_456.graphics.f("#000000").s().p("AhvHFIAAoLIhWAAIAAhUIBWAAIAAgdQgBiSBHhCQA4g5BZAAQA0AAAqASIgPBVQgdgOgpAAQh0AAABCwIAAAhICQAAIAABUIiQAAIAAILg");
        this.shape_456.setTransform(228.6, 378.3, 0.15, 0.15);

        this.shape_457 = new cjs.Shape();
        this.shape_457.graphics.f("#000000").s().p("ADLGnIAAmNImWAAIAAGNIhtAAIAAtNIBtAAIAAFiIGWAAIAAliIBuAAIAANNg");
        this.shape_457.setTransform(219, 378.8, 0.15, 0.15);

        this.shape_458 = new cjs.Shape();
        this.shape_458.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_458.setTransform(222.9, 378.3, 0.15, 0.15);

        this.shape_459 = new cjs.Shape();
        this.shape_459.graphics.f("#000000").s().p("AiEDRQgxhLgCiFQAAiEA1hMQAzhJBTAAQBWAAAvBIQAvBJAACCQAACJgxBLQgxBKhZAAQhRAAgwhIgAhOilQgfA8AABrQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhpgag4Qgdg9g3AAQgwAAgeA6g");
        this.shape_459.setTransform(216.7, 300, 0.15, 0.15);

        this.shape_460 = new cjs.Shape();
        this.shape_460.graphics.f("#000000").s().p("AA1EQIAAiVIj6AAIAAgwIDwlaIBPAAIAAFRIBMAAIAAA5IhMAAIAACVgAAIh3IiDC3IAAACICwAAIAAi0QAAgvACgnIgCAAQgUAngZAqg");
        this.shape_460.setTransform(210.3, 300, 0.15, 0.15);

        this.shape_461 = new cjs.Shape();
        this.shape_461.graphics.f("#000000").s().p("AiSE2IAAmgQAAhugFhQIBhAAIADB3IAGAAQAUg8AsglQAugjA3gBQASAAAOAEIAABoQgSgEgUAAQg5AAgoAoQglAngMBAQgEAeAAAVIAAFCg");
        this.shape_461.setTransform(228.5, 321.1, 0.15, 0.15);

        this.shape_462 = new cjs.Shape();
        this.shape_462.graphics.f("#000000").s().p("AkzGnIAAhAIHTqtIAAgEImqAAIAAhcII3AAIAABDInPKrIAAAEIHWAAIAABbg");
        this.shape_462.setTransform(219.7, 319.4, 0.15, 0.15);

        this.shape_463 = new cjs.Shape();
        this.shape_463.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_463.setTransform(222.9, 319.4, 0.15, 0.15);

        this.shape_464 = new cjs.Shape();
        this.shape_464.graphics.f("#000000").s().p("AisEVIAAgtIA6g5QBwhrAmg2QAyhAAAg6QAAgvgYgbQgbggg2gBQg9ABg3AtIgYg0QBCg3BYAAQBQAAAtAzQAoArAABBQAABGgzBHQgnA3hgBeIgrApIAAABIDyAAIAAA+g");
        this.shape_464.setTransform(216.3, 241, 0.15, 0.15);

        this.shape_465 = new cjs.Shape();
        this.shape_465.graphics.f("#000000").s().p("AisEVIAAgtIA6g5QBxhsAmg1QAwhAABg6QAAgvgYgbQgbggg3gBQg7ABg4AtIgXg0QBBg3BYAAQBQAAAtAzQAnArAABBQAABGgyBHQgnA3hgBeIgrApIAAABIDyAAIAAA+g");
        this.shape_465.setTransform(209.9, 241, 0.15, 0.15);

        this.shape_466 = new cjs.Shape();
        this.shape_466.graphics.f("#000000").s().p("Ag1GoIAApfIBsAAIAAJfgAgwkyQgTgTAAgdQAAgdAUgUQATgUAcAAQAeAAATAUQATATAAAeQABAdgUATQgTAUgfAAQgcAAgTgUg");
        this.shape_466.setTransform(228.1, 260.5, 0.15, 0.15);

        this.shape_467 = new cjs.Shape();
        this.shape_467.graphics.f("#000000").s().p("Ag2GnIAArwIkBAAIAAhdIJvAAIAABdIkCAAIAALwg");
        this.shape_467.setTransform(221.5, 260.5, 0.15, 0.15);

        this.shape_468 = new cjs.Shape();
        this.shape_468.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_468.setTransform(222.9, 260.5, 0.15, 0.15);

        this.shape_469 = new cjs.Shape();
        this.shape_469.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACThQBsg");
        this.shape_469.setTransform(188.3, 457, 0.15, 0.15);

        this.shape_470 = new cjs.Shape();
        this.shape_470.graphics.f("#000000").s().p("AhpDLICvlnIAAgBIjFAAIAAguID/AAIAAAlIivFxg");
        this.shape_470.setTransform(184.8, 456.6, 0.15, 0.15);

        this.shape_471 = new cjs.Shape();
        this.shape_471.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBVhRAcgnQAkgwABgrQAAgjgSgVQgVgYgoAAQgsAAgrAjIgSgoQAzgpBBAAQA8AAAhAmQAdAgABAxQgBA0glA1QgdAohIBIIggAeIAAACIC1AAIAAAtg");
        this.shape_471.setTransform(179.9, 456.6, 0.15, 0.15);

        this.shape_472 = new cjs.Shape();
        this.shape_472.graphics.f("#000000").s().p("AiADPIAAgiIArgqQBVhRAbgnQAlgwABgrQgBgjgRgVQgVgYgoAAQgsAAgrAjIgSgoQAygpBCAAQA7AAAiAmQAeAgAAAxQAAA0gnA1QgdAphHBHIghAeIAAACIC2AAIAAAtg");
        this.shape_472.setTransform(175, 456.6, 0.15, 0.15);

        this.shape_473 = new cjs.Shape();
        this.shape_473.graphics.f("#000000").s().p("AATD/QhQhsAAiSQAAiTBQhsIArAAQhNBrAACUQAACPBNBvg");
        this.shape_473.setTransform(171.5, 457, 0.15, 0.15);

        this.shape_474 = new cjs.Shape();
        this.shape_474.graphics.f("#000000").s().p("AiHEZIAAg9QAKACAQgBIAhgDQBFgKAqgrQA6g0AOhdIgCAAQgwA7hNAAQhJAAgsgxQgsgtAAhHQAAhQAzg4QA1g6BPAAQBUAAAwA/QAwA+AABpQAABTgbBEQgXA9grAqQgfAegqATQgnASgtAFQgcAFgYAAIgPAAgAhPi6QgdAlAAA6QgBAzAdAgQAcAeAwAAQAiAAAdgQQAbgNAPgaQAGgKAAgQQABhKgbgsQgdgvg1AAIgBAAQgvAAgeAmg");
        this.shape_474.setTransform(173.5, 417.9, 0.15, 0.15);

        this.shape_475 = new cjs.Shape();
        this.shape_475.graphics.f("#000000").s().p("AiFDtQgxgqAAg+QAAgyAdgmQAcgkAzgTIgBgDQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkgvAWIAAADQA0ASAdAjQAdAlAAAxQAABGg2AsQg0AshNAAQhSAAgzgsgAhSA2QgZAeAAAnQgCArAeAeQAeAfAxAAQAwAAAfgcQAdgbAAgqQAAgvgggeQgcgZg5gRQgvANgaAegAhDjKQgZAZAAAlQAAAnAdAZQAZAXAwANQAlgMAWgZQAYgaAAgkQAAgkgVgZQgZgcguAAQgqAAgaAag");
        this.shape_475.setTransform(167, 417.9, 0.15, 0.15);

        this.shape_476 = new cjs.Shape();
        this.shape_476.graphics.f("#000000").s().p("AibDnQhThWAAiMQAAiMBZhaQBahbCRAAQAtAAAtAKQAlAIAaANIgZBWQgzgdhNAAQhjAAg6BDQg3BAAABhQAABoA8A/QA6A9BaAAQAqAAAmgKQAZgHAegOIATBTQgbAOgoALQg0AMg3AAQiHAAhShWg");
        this.shape_476.setTransform(185.7, 438.9, 0.15, 0.15);

        this.shape_477 = new cjs.Shape();
        this.shape_477.graphics.f("#000000").s().p("ADsGnIhakLIkpAAIhYELIhxAAIEftNICCAAIEgNNgAguisIhTDzID8AAIhSjyQgSgzgYhoIgDAAQgWBcgUA+g");
        this.shape_477.setTransform(175.8, 437.1, 0.15, 0.15);

        this.shape_478 = new cjs.Shape();
        this.shape_478.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_478.setTransform(179.9, 437.2, 0.15, 0.15);

        this.shape_479 = new cjs.Shape();
        this.shape_479.graphics.f("#000000").s().p("AiLEQIDpnhIAAgBIkIAAIAAg9IFVAAIAAAwIjrHvg");
        this.shape_479.setTransform(173.4, 358.8, 0.15, 0.15);

        this.shape_480 = new cjs.Shape();
        this.shape_480.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAiAKAiAAQA0AAAkgfQAngiAAg1QgBg4glgfQgogghMAAQgcAAgwAGIAjkGIECAAIAAA+IjNAAIgVCMQAWgDAWAAQBCAAAxAeQAjATAUAgQAXAmAAAwQAABQg5A1Qg5A1hWAAQgqAAgmgKg");
        this.shape_480.setTransform(166.8, 358.9, 0.15, 0.15);

        this.shape_481 = new cjs.Shape();
        this.shape_481.graphics.f("#000000").s().p("AjCEHQgugxAAhHQAAhuBeg5QBfg6CtABIAAgNQAAg3gWgjQgigzhQAAQgpAAgrAMQgpAMggAWIgZhJQAmgaAzgOQA2gOA2AAQB/AAA6BOQAtA+AABsIAADiQAABbAKA3IhkAAIgJhNIgEAAQgbAngtAYQg0Abg7AAQhXAAg0g2gAgvARQhTAhAABQQAAA0AfAcQAcAaAtAAQA1AAApgfQAkgdAOgqQAHgSAAgRIAAhoIgTAAQhgAAg5AWg");
        this.shape_481.setTransform(183.9, 380, 0.15, 0.15);

        this.shape_482 = new cjs.Shape();
        this.shape_482.graphics.f("#000000").s().p("AjpGnIAAtNIBtAAIAALxIFmAAIAABcg");
        this.shape_482.setTransform(175.7, 378.2, 0.15, 0.15);

        this.shape_483 = new cjs.Shape();
        this.shape_483.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_483.setTransform(179.9, 378.3, 0.15, 0.15);

        this.shape_484 = new cjs.Shape();
        this.shape_484.graphics.f("#000000").s().p("AiHEZIAAg9QAPACAsgEQBEgKAsgrQA5g0APhdIgDAAQgwA7hOAAQhHAAgugxQgrgtAAhHQAAhQAzg4QA1g6BPAAQBTAAAxA/QAwA+AABpQAABTgbBEQgYA9grAqQgeAegrATQgmASgsAGQgfAEgYAAIgNAAgAhOi6QgeAlgBA6QAAAzAdAgQAcAeAwAAQAhAAAdgQQAcgNAPgaQAGgKABgQQAAhKgbgsQgegvg1AAIgBAAQguAAgdAmg");
        this.shape_484.setTransform(173.4, 300, 0.15, 0.15);

        this.shape_485 = new cjs.Shape();
        this.shape_485.graphics.f("#000000").s().p("AhuENQgjgKgXgPIAUg5QAUANAdAKQAlAMAjAAQA9AAAigkQAagdgBgpQgBg2grgdQgngag4AAIgpAAIAAg1IApAAQAuAAAigWQAogaAAgtQAAgjgWgWQgagZgtAAQgeAAggAMQgaAKgVAOIgTg1QAXgRAkgMQApgNAqAAQBJAAArAoQAlAkAAA2QAAArgZAhQgaAigxASIAAABQA1ALAgAiQAkAmAAA3QAABGgyAtQg3AxhbAAQgrAAgogMg");
        this.shape_485.setTransform(166.8, 300, 0.15, 0.15);

        this.shape_486 = new cjs.Shape();
        this.shape_486.graphics.f("#000000").s().p("Ag+GnIAAlnIkKnmIB7AAIB4DqQAzBnAhBIIABAAQAPgoBFiHIB5jqIB9AAIkbHlIAAFog");
        this.shape_486.setTransform(179.9, 319.4, 0.15, 0.15);

        this.shape_487 = new cjs.Shape();
        this.shape_487.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_487.setTransform(179.9, 319.4, 0.15, 0.15);

        this.shape_488 = new cjs.Shape();
        this.shape_488.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_488.setTransform(172.8, 241.1, 0.15, 0.15);

        this.shape_489 = new cjs.Shape();
        this.shape_489.graphics.f("#000000").s().p("AisEVIAAgtIA6g5QBwhrAmg2QAxhAABg6QAAgvgYgbQgbggg3gBQg8ABg3AtIgYg0QAegYAmgPQApgQAtAAQBQAAAtAzQAnArAABBQAABGgyBHQgnA3hgBeIgrApIAAABIDyAAIAAA+g");
        this.shape_489.setTransform(166.8, 241, 0.15, 0.15);

        this.shape_490 = new cjs.Shape();
        this.shape_490.graphics.f("#000000").s().p("AibDnQhThWAAiMQAAiMBZhZQBahcCRAAQAtAAAtAKQAlAJAaANIgZBVQgzgdhNAAQhjAAg6BEQg3A+AABiQAABoA8A+QA6A+BagBQAqAAAmgJQAZgHAegNIATBSQgbAOgoALQg0AMg3AAQiHAAhShWg");
        this.shape_490.setTransform(184.5, 262.3, 0.15, 0.15);

        this.shape_491 = new cjs.Shape();
        this.shape_491.graphics.f("#000000").s().p("AigGkQg8gPgigXIAchcQAmAYAxAPQA2AQA2AAQBQAAAwgoQAugnAAhBQABg7gmgnQgkglhTgiQhugkg2g3Qg7g9AAhWQAAhkBKhBQBNhBB3AAQBzAABIApIgeBZQhJgohXABQhOgBgrAqQglAjAAAyQABA5AoAmQAkAhBaAkQBuArAzA1QA2A9AABaQAABohJBEQhQBJiNAAQg8AAg9gRg");
        this.shape_491.setTransform(175.5, 260.5, 0.15, 0.15);

        this.shape_492 = new cjs.Shape();
        this.shape_492.graphics.f("#BF9AC1").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_492.setTransform(179.9, 260.5, 0.15, 0.15);

        this.shape_493 = new cjs.Shape();
        this.shape_493.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiShNhsIArAAQBQBpAACVQAACShQBtg");
        this.shape_493.setTransform(145.2, 457, 0.15, 0.15);

        this.shape_494 = new cjs.Shape();
        this.shape_494.graphics.f("#000000").s().p("AhjCjQgngvAAhQQAAg4ATgxQASgtAfggQA0gyBNgKQAUgDAUAAIAAAtQgUgBgVADQg8ALgmAqQgjAmgHA3IACAAQAQgVAXgNQAbgOAeAAQA3AAAiAkQAiAjAAA7QAAA7gkApQgmAsg9AAQhAAAgngvgAgtgIQgVAMgMAWQgGALAAAOQABA0AXAfQAYAhAoAAIAAAAQAkAAAVgbQAWgbAAgrQAAgsgXgZQgWgXgmAAQgXAAgWAOg");
        this.shape_494.setTransform(141.7, 456.6, 0.15, 0.15);

        this.shape_495 = new cjs.Shape();
        this.shape_495.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBVhRAcgoQAkgvABgrQAAgkgSgUQgVgYgoAAQgsgBgrAjIgSgnQAygpBCAAQA7AAAiAmQAdAgABAxQAAA0gmA1QgeAphHBHIggAeIAAABIC0AAIAAAug");
        this.shape_495.setTransform(136.8, 456.6, 0.15, 0.15);

        this.shape_496 = new cjs.Shape();
        this.shape_496.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBVhRAbgoQAlgvABgrQAAgkgSgUQgVgYgoAAQgtgBgqAjIgSgnQAxgpBDAAQA7AAAiAmQAdAgABAxQgBA0glA1QgeAphHBHIggAeIAAABIC1AAIAAAug");
        this.shape_496.setTransform(132, 456.6, 0.15, 0.15);

        this.shape_497 = new cjs.Shape();
        this.shape_497.graphics.f("#000000").s().p("AATD/QhQhsAAiTQABiSBPhsIArAAQhNBqAACUQAACPBNBwg");
        this.shape_497.setTransform(128.5, 457, 0.15, 0.15);

        this.shape_498 = new cjs.Shape();
        this.shape_498.graphics.f("#000000").s().p("AiFDtQgxgpAAg+QAAhkBsgsIgBgDQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgWAkgvAWIAAADQA0ASAcAkQAdAkAAAxQAABGg2AtQg0ArhNAAQhSAAgzgsgAhSA3QgZAdAAAoQgCArAeAdQAfAgAwAAQAxAAAegcQAegbAAgrQAAgvgggdQgdgag5gRQgvAOgaAegAhDjJQgYAYAAAlQAABJBlAbQAlgMAWgYQAYgbAAgkQAAgkgVgYQgZgcguAAQgqAAgaAag");
        this.shape_498.setTransform(130.4, 417.9, 0.15, 0.15);

        this.shape_499 = new cjs.Shape();
        this.shape_499.graphics.f("#000000").s().p("AiFDtQgxgpAAg+QAAgzAdglQAbgkA0gUIgBgDQgrgUgXgiQgUgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkgvAWIAAADQA0ATAcAjQAeAkAAAxQAABGg2AtQg0ArhNAAQhSAAgzgsgAhSA3QgZAdAAAoQgCArAeAdQAfAgAwAAQAxAAAegcQAdgbAAgrQAAgvgggdQgcgag5gRQgvAOgaAegAhDjJQgZAYAAAlQAABJBmAbQAlgMAWgYQAYgbAAgkQAAgkgVgYQgZgcguAAQgqAAgaAag");
        this.shape_499.setTransform(123.9, 417.9, 0.15, 0.15);

        this.shape_500 = new cjs.Shape();
        this.shape_500.graphics.f("#000000").s().p("AjBEHQgvgxAAhHQAAhuBeg5QBeg6CuABIAAgOQAAg2gWgjQgigzhPAAQgrAAgqAMQgpAMghAVIgZhJQAmgYA0gPQA1gPA2AAQCAAAA6BPQAtA+AABsIAADiQAABaAKA4IhkAAIgJhNIgDAAQgcAngtAYQg0Acg7gBQhXAAgzg2gAgvARQhTAhAABQQAAA0AfAcQAcAaAtAAQA2AAAogfQAkgdAPgqQAGgVAAgPIAAhnIgTAAQhhAAg4AWg");
        this.shape_500.setTransform(141.6, 439, 0.15, 0.15);

        this.shape_501 = new cjs.Shape();
        this.shape_501.graphics.f("#000000").s().p("ACiGqQgSgggniqQgShYgmglQgnglhIgDIhmAAIAAFvIhtAAIAAtCQBTgRB+AAQBVAAA7AQQA7ARAnAkQAgAcARAqQARAqAAAxQAABQguA7QgqA1hHAWIAAAEQBdAgAfCLQAYBnANAtQAQA+AMAWgAiklLIAAE1IBvAAQBVAAA0gsQAzgsAAhJQAAhPg2goQgxgmhZgBQhIAAgjAKg");
        this.shape_501.setTransform(132.6, 437.1, 0.15, 0.15);

        this.shape_502 = new cjs.Shape();
        this.shape_502.graphics.f("#FF9F00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_502.setTransform(136.8, 437.2, 0.15, 0.15);

        this.shape_503 = new cjs.Shape();
        this.shape_503.graphics.f("#000000").s().p("AiEDaQg1g/AAhqQAAhMAahBQAYg9AqgqQBFhEBngMQAbgFAaAAIAAA9QgXgCggAFQhQAOgzA4QguAzgKBJIADAAQAVgcAggRQAjgSApAAQBIAAAuAwQAuAvAABPQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAPAAASQABBGAeAqQAgAsA2AAIABAAQAvAAAdgkQAdglAAg6QAAg6geghQgegggzAAQgfAAgdATg");
        this.shape_503.setTransform(130.3, 359, 0.15, 0.15);

        this.shape_504 = new cjs.Shape();
        this.shape_504.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAdAIQAhAKAiAAQA0AAAkgfQAngiAAg1QgBg4glgfQgogghNAAQgaAAgxAGIAkkGIECAAIAAA+IjOAAIgVCNQAXgEAVAAQBEAAAvAeQAjATAUAfQAXAmAAAxQAABRg4A0Qg6A2hWgBQgpAAgngKg");
        this.shape_504.setTransform(123.7, 359, 0.15, 0.15);

        this.shape_505 = new cjs.Shape();
        this.shape_505.graphics.f("#000000").s().p("AjCEHQgugxAAhHQAAhuBeg5QBeg6CuABIAAgNQAAg3gWgiQgig0hQAAQgpAAgqAMQgqAMggAVIgZhJQAmgZA0gOQA1gPA2AAQB+AAA6BPQAuA+AABsIAADiQAABaAKA4IhkAAIgJhNIgEAAQgcAngsAYQg0Acg7AAQhXAAg0g3gAgvARQhTAhAABQQAAAzAfAdQAcAaAtAAQA1AAApggQAkgbAOgrQAHgVAAgOIAAhoIgTAAQhhAAg4AWg");
        this.shape_505.setTransform(141.5, 380, 0.15, 0.15);

        this.shape_506 = new cjs.Shape();
        this.shape_506.graphics.f("#000000").s().p("AkJGkIAAtAQBUgRBzAAQBQAAA4APQA3APAnAfQBGA1ABBhQgBA9glAyQgnAzhCAYIAAACQBFASAwAvQA4A8AABWQABBkhIBGQhWBPjMAAQhgAAhJgKgAicFUQAbAEBBAAQBcAAA4gkQBDgqAAhWQAAhShBgrQg6gmhegBIhaAAgAiclSIAAESIBjAAQBTAAAygpQAwgnAAg/QAAhHgzgjQgvgghVAAQg7AAgmAHg");
        this.shape_506.setTransform(132.5, 378.3, 0.15, 0.15);

        this.shape_507 = new cjs.Shape();
        this.shape_507.graphics.f("#FF9F00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_507.setTransform(136.8, 378.3, 0.15, 0.15);

        this.shape_508 = new cjs.Shape();
        this.shape_508.graphics.f("#000000").s().p("AiFDtQgxgpAAg+QAAgzAdglQAbgkA0gUIgBgDQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkgvAWIAAADQA0ATAcAiQAeAlAAAxQAABGg2AsQg0AshNAAQhSAAgzgsgAhSA3QgZAdAAAoQgCArAeAdQAfAgAwAAQAxAAAegcQAdgbAAgrQAAgvgggdQgcgag5gRQgvAOgaAegAhDjJQgZAYAAAlQAABJBmAbQAlgMAWgZQAYgaAAgkQAAgkgVgYQgZgcguAAQgqAAgaAag");
        this.shape_508.setTransform(130.3, 300, 0.15, 0.15);

        this.shape_509 = new cjs.Shape();
        this.shape_509.graphics.f("#000000").s().p("AhuENQgkgKgWgPIAUg5QAUANAdAKQAkAMAjAAQA+AAAigkQAagdgBgpQAAg2gsgdQgmgag5AAIgoAAIAAg1IAoAAQAuAAAhgWQApgaAAgtQAAgjgXgWQgZgZgtAAQgeAAggAMQgaAKgVAOIgTg1QAXgRAkgMQApgNAqAAQBJAAArAoQAlAkAAA2QAAArgZAhQgaAigxASIAAACQA1AKAgAiQAkAnAAA3QAABFgyAtQg2AxhcAAQgqAAgpgMg");
        this.shape_509.setTransform(123.7, 300, 0.15, 0.15);

        this.shape_510 = new cjs.Shape();
        this.shape_510.graphics.f("#000000").s().p("AiSE3IAAmhQAAh1gFhJIBhAAIADB3IAGAAQAUg9AsgkQAugkA4AAQARAAAOAEIAABoQgSgEgUAAQg5AAgoAoQglAngMBAQgFAeAAAVIAAFDg");
        this.shape_510.setTransform(141.7, 321.1, 0.15, 0.15);

        this.shape_511 = new cjs.Shape();
        this.shape_511.graphics.f("#000000").s().p("AigGlQg7gQgjgXIAchcQAnAYAxAPQA2ARA1AAQBQAAAwgpQAugnAAhBQAAg7gkgnQglgmhTghQhugkg2g3Qg7g9AAhWQAAhkBKhBQBNhBB3AAQBzAABIApIgeBaQhIgohYAAQhOgBgrAqQgkAjAAAyQAAA6AoAlQAkAhBaAkQBuArAzA1QA2A9AABaQAABphJBDQhQBJiMAAQg8AAg+gQg");
        this.shape_511.setTransform(133.5, 319.4, 0.15, 0.15);

        this.shape_512 = new cjs.Shape();
        this.shape_512.graphics.f("#FF9F00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_512.setTransform(136.8, 319.4, 0.15, 0.15);

        this.shape_513 = new cjs.Shape();
        this.shape_513.graphics.f("#000000").s().p("AiEDRQgyhLgBiFQAAiEA1hMQAzhJBTAAQBVAAAwBJQAvBIAACDQAACIgyBLQgxBKhYAAQhRAAgwhIgAhOilQgfA9AABqQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhogag5Qgdg9g3AAQgwAAgeA6g");
        this.shape_513.setTransform(130.3, 241.1, 0.15, 0.15);

        this.shape_514 = new cjs.Shape();
        this.shape_514.graphics.f("#000000").s().p("AisEUIAAgtIA6g4QBwhrAmg2QAxhAABg6QAAgvgYgbQgbghg3ABQg8AAg3AuIgYg0QBCg3BYAAQBQAAAtAxQAnAsAABBQAABGgyBGQgnA4hgBfIgrAoIAAABIDyAAIAAA9g");
        this.shape_514.setTransform(123.8, 241, 0.15, 0.15);

        this.shape_515 = new cjs.Shape();
        this.shape_515.graphics.f("#000000").s().p("AjBEIQgvgyAAhHQAAhuBeg4QBfg7CtAAIAAgMQAAg3gWgjQgigzhPAAQgqAAgqANQgqAMggAUIgZhJQAmgZA0gOQA1gPA2AAQB/AAA6BPQAtA/AABrIAADiQAABaAKA4IhkAAIgJhNIgDAAQgcAngtAYQg0Abg7AAQhXAAgzg1gAiCCCQAAAzAfAdQAcAaAtAAQA2AAApggQAjgcAPgqQAGgTAAgQIAAhnIgTgBQjsAAAACHg");
        this.shape_515.setTransform(142.2, 262.2, 0.15, 0.15);

        this.shape_516 = new cjs.Shape();
        this.shape_516.graphics.f("#000000").s().p("AjHFGQh4h0AAjLQAAjFB7h7QB5h7DDAAQBGAAA7ANQAsAKAbAPIgaBZQhIgjhiAAQiVAAhZBcQhaBdAACiQAACdBVBcQBXBcCWAAQAyAAAwgKQAvgJAigQIAWBXQgiAQg2AMQhAANhHAAQi3AAhwhvg");
        this.shape_516.setTransform(132.7, 260.4, 0.15, 0.15);

        this.shape_517 = new cjs.Shape();
        this.shape_517.graphics.f("#FF9F00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_517.setTransform(136.8, 260.4, 0.15, 0.15);

        this.shape_518 = new cjs.Shape();
        this.shape_518.graphics.f("#000000").s().p("AisEVIAAgtIA6g5QBxhsAlg1QAxg/ABg7QAAgvgYgbQgbggg3gBQg7ABg4AtIgYg0QAegYAmgPQApgQAtAAQBQAAAtAzQAnArAABBQAABFgyBIQgnA3hgBeIgrApIAAABIDyAAIAAA+g");
        this.shape_518.setTransform(129.5, 182.1, 0.15, 0.15);

        this.shape_519 = new cjs.Shape();
        this.shape_519.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_519.setTransform(122.6, 182.2, 0.15, 0.15);

        this.shape_520 = new cjs.Shape();
        this.shape_520.graphics.f("#000000").s().p("AiJGtQg4gOgjgXIAbhVQAhAWAqAMQAyAPA1AAQBYAAAxgxQA4g2AAhuIAAhEIgDAAQgbAtguAbQg0AehBAAQhwAAhKhWQhIhUAAh9QAAiTBUhcQBOhUBuAAQBHAAA0AiQApAbAYAtIADAAIAEhcIBhAAQgGBYAABPIAAFfQABBogVBEQgWBCgrAoQhPBJiMAAQg5AAg1gNgAh3kkQgzA/AABpQAABfAtA5QAwBBBUAAQA0gBApgeQAqgeASgzQAJgaAAggIAAhuQAAgfgGgTQgRg0gmgeQgqgjg6AAQhNAAgyA+g");
        this.shape_520.setTransform(144.2, 203.2, 0.15, 0.15);

        this.shape_521 = new cjs.Shape();
        this.shape_521.graphics.f("#000000").s().p("AFEGnIgVl0QgOj+ABhuIgEAAQguCeg8CiIiVGbIhRAAIiImUQhDjFgfiCIgDAAQgECtgMDIIgWFrIhoAAIA7tNICLAAICQGaQA6CsAbBvIACAAQAbhvA9isICXmaICLAAIA0NNg");
        this.shape_521.setTransform(131.7, 199.5, 0.15, 0.15);

        this.shape_522 = new cjs.Shape();
        this.shape_522.graphics.f("#FF9F00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_522.setTransform(136.8, 201.5, 0.15, 0.15);

        this.shape_523 = new cjs.Shape();
        this.shape_523.graphics.f("#000000").s().p("AA1EQIAAiVIj6AAIAAgwIDwlaIBPAAIAAFRIBMAAIAAA5IhMAAIAACVgAAIh4IiDC4IAAACICwAAIAAi0QAAgnACgvIgCAAQgUAngZApg");
        this.shape_523.setTransform(124.2, 123.1, 0.15, 0.15);

        this.shape_524 = new cjs.Shape();
        this.shape_524.graphics.f("#000000").s().p("Ai7DpQhPhUAAiMQAAiLBMhbQBPhgCAAAQCEAABDBmQAzBOAABrQAAAVgEAdImoAAQACBqA+A3QA3AyBXAAQA3AAArgJQAjgIAjgPIATBQQhXAnhzAAQiJAAhQhVgAhyiwQgmAxgHBFIFAAAQAAhEgegwQgog/hTAAQhLAAgvA9g");
        this.shape_524.setTransform(141.6, 144.3, 0.15, 0.15);

        this.shape_525 = new cjs.Shape();
        this.shape_525.graphics.f("#000000").s().p("AkIGkIAAs/QBVgSBxAAQBQAAA3APQA3AOAoAhQBGA0ABBhQAAA+gnAyQgmAyhCAYIAAADQBFARAwAvQA4A8AABWQAABlhHBFQhWBPjLAAQhiAAhHgKgAicFUQAbAFBBAAQBcAAA5gkQBCgrgBhWQAAhShAgrQg6gmheAAIhaAAgAiclRIAAERIBjAAQBTAAAygpQAwgnAAg+QAAhIgzgjQgvgghVAAQg7AAgmAIg");
        this.shape_525.setTransform(132.1, 142.5, 0.15, 0.15);

        this.shape_526 = new cjs.Shape();
        this.shape_526.graphics.f("#FF9F00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_526.setTransform(136.8, 142.6, 0.15, 0.15);

        this.shape_527 = new cjs.Shape();
        this.shape_527.graphics.f("#000000").s().p("Ag9D/QBNhvAAiQQAAiShNhsIArAAQBQBoAACWQAACShQBtg");
        this.shape_527.setTransform(102.2, 457, 0.15, 0.15);

        this.shape_528 = new cjs.Shape();
        this.shape_528.graphics.f("#000000").s().p("AhSDKQgagIgSgLIAQgrQAOAKAWAHQAcAJAaAAQAuAAAZgbQAUgWgBgeQgBgogggWQgdgUgpAAIgfAAIAAgnIAfAAQAhAAAZgRQAfgTAAghQAAgbgRgQQgTgTgiAAQgXAAgXAJQgUAHgPALIgPgoQASgNAbgJQAfgKAfAAQA2AAAgAeQAcAbAAApQAAAggSAZQgUAaglANIAAABQAoAIAYAZQAbAdAAApQAAA0gmAiQgpAlhEAAQgfAAgfgJg");
        this.shape_528.setTransform(98.5, 456.6, 0.15, 0.15);

        this.shape_529 = new cjs.Shape();
        this.shape_529.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBVhRAcgoQAkgvABgrQAAgjgSgVQgVgYgpAAQgrAAgrAiIgSgnQAygpBCAAQA7AAAiAlQAeAhgBAxQABA0gmA1QgeAphHBHIggAeIAAABIC0AAIAAAug");
        this.shape_529.setTransform(93.8, 456.6, 0.15, 0.15);

        this.shape_530 = new cjs.Shape();
        this.shape_530.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBUhRAcgoQAlgvAAgrQAAgjgRgVQgWgYgnAAQguAAgpAiIgSgnQAygpBCAAQA7AAAiAlQAdAhABAxQgBA0glA1QgdAphIBHIggAeIAAABIC1AAIAAAug");
        this.shape_530.setTransform(88.9, 456.6, 0.15, 0.15);

        this.shape_531 = new cjs.Shape();
        this.shape_531.graphics.f("#000000").s().p("AATD/QhQhsAAiTQABiSBPhsIArAAQhNBpAACVQAACPBNBwg");
        this.shape_531.setTransform(85.4, 457, 0.15, 0.15);

        this.shape_532 = new cjs.Shape();
        this.shape_532.graphics.f("#000000").s().p("AiMEQIDqngIAAgCIkIAAIAAg9IFVAAIAAAxIjrHug");
        this.shape_532.setTransform(87.4, 417.9, 0.15, 0.15);

        this.shape_533 = new cjs.Shape();
        this.shape_533.graphics.f("#000000").s().p("AiGDtQgwgpAAg+QAAhkBsgsIgBgDQgrgUgWgiQgVgfAAglQAAhAAxgpQAvgoBGAAQBKAAAsApQAoAmAAA3QAAAmgUAfQgWAkgvAWIAAADQAzATAdAiQAdAlAAAxQAABGg1AsQg1AshNAAQhTAAgzgsgAhSA3QgZAdAAAoQgBArAdAdQAeAgAxAAQAxAAAegcQAegbAAgrQgBgvgggdQgcgag5gRQgvAOgaAegAhDjKQgYAZgBAlQAABJBmAbQAlgMAWgZQAXgaABgkQAAgkgWgZQgYgcguAAQgqAAgaAag");
        this.shape_533.setTransform(80.9, 417.9, 0.15, 0.15);

        this.shape_534 = new cjs.Shape();
        this.shape_534.graphics.f("#000000").s().p("AiRE3IAAmhQAAhtgGhRIBhAAIADB3IAGAAQAUg9AsgkQAugkA4AAQARAAAOAEIAABoQgSgEgUAAQg5AAgoAoQglAngMBAQgEAeAAAVIAAFDg");
        this.shape_534.setTransform(98.1, 438.9, 0.15, 0.15);

        this.shape_535 = new cjs.Shape();
        this.shape_535.graphics.f("#000000").s().p("AjiGnIAAtNIHFAAIAABbIlYAAIAAEaIE9AAIAABZIk9AAIAAF/g");
        this.shape_535.setTransform(90.7, 437.2, 0.15, 0.15);

        this.shape_536 = new cjs.Shape();
        this.shape_536.graphics.f("#FBDE7B").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_536.setTransform(93.8, 437.2, 0.15, 0.15);

        this.shape_537 = new cjs.Shape();
        this.shape_537.graphics.f("#000000").s().p("AhwEKQghgJgWgOIASg4QAUAMAcAIQAiAKAiAAQA0AAAlggQAmghAAg1QgBg4glgfQgogghMAAQgbAAgwAGIAjkGIEBAAIAAA+IjNAAIgVCMQAdgDAQAAQBBAAAyAdQAiAUAUAgQAXAmAAAwQAABQg5A1Qg5A2hWAAQgpAAgngLg");
        this.shape_537.setTransform(87.1, 358.9, 0.15, 0.15);

        this.shape_538 = new cjs.Shape();
        this.shape_538.graphics.f("#000000").s().p("AhwEKQghgJgWgOIASg4QAUAMAcAIQAjAKAhAAQA0AAAlggQAmghAAg1QgBg4glgfQgpgghMAAQgaAAgxAGIAjkGIEDAAIAAA+IjOAAIgUCMQAcgDAPAAQBCAAAxAdQAjAUAUAgQAXAmAAAwQAABRg4A0Qg6A2hWAAQgqAAgmgLg");
        this.shape_538.setTransform(80.7, 358.9, 0.15, 0.15);

        this.shape_539 = new cjs.Shape();
        this.shape_539.graphics.f("#000000").s().p("Ah5EyQgrgMghgTIAbhVQAbASAlAMQArAOAmAAQA5AAAegaQAdgYAAgoQAAgngagZQgYgZg8gXQhRgdgpgqQgngrAAg4QABhMA3gyQA6g1BdAAQAsAAAqAMQAjAJAdARIgcBQQg4gjhEAAQgtAAgcAZQgaAXAAAjQAAAkAcAXQAYAUA8AYQBSAgAmAnQAoAtAABCQAABSg7AyQg+A0hoAAQgwAAgugMg");
        this.shape_539.setTransform(99.3, 380.1, 0.15, 0.15);

        this.shape_540 = new cjs.Shape();
        this.shape_540.graphics.f("#000000").s().p("AjIFGQh3h0AAjLQAAjFB6h7QB6h7DDAAQBGAAA6ANQAsAKAcAPIgbBZQhHgjhjAAQiUAAhYBbQhbBeAACiQAACdBVBbQBXBdCXAAQAxAAAwgKQAwgJAggQIAXBXQgjARg2ALQg/ANhHAAQi2AAhyhvg");
        this.shape_540.setTransform(90.2, 378.3, 0.15, 0.15);

        this.shape_541 = new cjs.Shape();
        this.shape_541.graphics.f("#FBDE7B").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_541.setTransform(93.8, 378.3, 0.15, 0.15);

        this.shape_542 = new cjs.Shape();
        this.shape_542.graphics.f("#000000").s().p("AiMEQIDqngIAAgBIkIAAIAAg+IFVAAIAAAxIjrHug");
        this.shape_542.setTransform(87.3, 300, 0.15, 0.15);

        this.shape_543 = new cjs.Shape();
        this.shape_543.graphics.f("#000000").s().p("AhuENQgjgKgXgPIAUg5QATANAeAKQAlAMAiAAQA/AAAggkQAbgdgBgpQAAg2gsgdQgmgag4AAIgpAAIAAg1IApAAQAtAAAhgWQApgaAAgtQAAgjgWgWQgagZgtAAQgeAAggAMQgbAKgUAOIgTg1QAXgRAlgMQApgNApAAQBJAAArAoQAlAkAAA2QAAArgZAhQgaAigxASIAAACQA1AKAhAiQAjAnAAA3QAABFgyAtQg2AxhcAAQgqAAgpgMg");
        this.shape_543.setTransform(80.7, 300, 0.15, 0.15);

        this.shape_544 = new cjs.Shape();
        this.shape_544.graphics.f("#000000").s().p("Ai4FSIgDAAIgFBlIhgAAQAFhTAAhKIAAreIBtAAIAAF+IADAAQAeg0AzgdQA2gfBFAAQByAABHBWQBIBXgBCIQAACahVBbQhNBRhuAAQiJAAhAhzgAhng5QgwAlgQA8QgHAbAAASIAABuQAAAPAFAZQARA6AsAkQAtAkA8AAQBTAAAyhBQAxg/AAhqQAAhhgug8QgyhEhTAAQg5AAguAlg");
        this.shape_544.setTransform(98.9, 319.4, 0.15, 0.15);

        this.shape_545 = new cjs.Shape();
        this.shape_545.graphics.f("#000000").s().p("ACiGqQgSgggniqQgShYgmglQgnglhIgDIhmAAIAAFvIhtAAIAAtCQBTgRB+AAQBVAAA7AQQA6ARAoAkQAgAcARAqQARApAAAyQAABQguA7QgqA1hHAWIAAAEQBdAgAfCLQAYBnANAtQAQA+AMAWgAiklLIAAE1IBvAAQBVAAA0gsQAzgsAAhJQAAhPg2goQgxgmhZgBQhIAAgjAKg");
        this.shape_545.setTransform(88.5, 319.6, 0.15, 0.15);

        this.shape_546 = new cjs.Shape();
        this.shape_546.graphics.f("#FBDE7B").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_546.setTransform(93.8, 319.4, 0.15, 0.15);

        this.shape_547 = new cjs.Shape();
        this.shape_547.graphics.f("#000000").s().p("AiHEZIAAg8QATACAogFQBEgJArgsQA6g1AOhcIgCAAQgwA7hOAAQhHAAgtgxQgsgtAAhHQAAhQAzg4QA1g6BPAAQBUAAAwA/QAwA+AABpQAABTgbBEQgXA9grAqQgfAegqATQgnASgtAGQgdAEgZAAIgNAAgAhPi6QgdAlAAA6QgBAzAdAgQAdAfAvAAQAhAAAegRQAbgNAPgZQAGgMAAgPQABhKgbgrQgdgwg1AAIgBAAQgvAAgeAmg");
        this.shape_547.setTransform(86.5, 241.1, 0.15, 0.15);

        this.shape_548 = new cjs.Shape();
        this.shape_548.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB1hAIA+AAIAAIfg");
        this.shape_548.setTransform(79.5, 241.1, 0.15, 0.15);

        this.shape_549 = new cjs.Shape();
        this.shape_549.graphics.f("#000000").s().p("ACpGnIkUmgIhRBdIAAFDIhtAAIAAtNIBtAAIAAGYIAEAAQAhgvAigrIEAk+ICHAAIkwFnIFIHmg");
        this.shape_549.setTransform(93.8, 260.5, 0.15, 0.15);

        this.shape_550 = new cjs.Shape();
        this.shape_550.graphics.f("#FBDE7B").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_550.setTransform(93.8, 260.4, 0.15, 0.15);

        this.shape_551 = new cjs.Shape();
        this.shape_551.graphics.f("#000000").s().p("AATEQIAAnbIgCAAIhcA0IgOg4IB0hAIA/AAIAAIfg");
        this.shape_551.setTransform(85.9, 182, 0.15, 0.15);

        this.shape_552 = new cjs.Shape();
        this.shape_552.graphics.f("#000000").s().p("AATEQIAAnbIgBAAIhdA0IgOg4IB1hAIA+AAIAAIfg");
        this.shape_552.setTransform(79.5, 182, 0.15, 0.15);

        this.shape_553 = new cjs.Shape();
        this.shape_553.graphics.f("#000000").s().p("AjCEIQgugyAAhHQAAhuBeg4QBeg7CuAAIAAgMQAAg3gWgiQgig0hQAAQgpAAgrAMQgpANggAUIgahJQAngZAzgNQA2gQA2AAQB/ABA5BPQAuA9AABtIAADhQAABcAKA2IhkAAIgJhNIgEAAQgcAngtAZQgzAbg7AAQhXAAg0g2gAiCCDQAAAzAfAcQAcAaAtAAQA1AAApggQAkgcAOgqQAHgSAAgRIAAhnIgTgBQjsAAAACIg");
        this.shape_553.setTransform(99.6, 203.2, 0.15, 0.15);

        this.shape_554 = new cjs.Shape();
        this.shape_554.graphics.f("#000000").s().p("ADOGnIkKmsQhpiog1hzIgEABQAJCUAADIIAAFqIhmAAIAAtNIB2AAIENGqQBZCNA+CHIADgBQgNiNAAjOIAAliIBnAAIAANNg");
        this.shape_554.setTransform(89.1, 201.4, 0.15, 0.15);

        this.shape_555 = new cjs.Shape();
        this.shape_555.graphics.f("#FBDE7B").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_555.setTransform(93.8, 201.5, 0.15, 0.15);

        this.shape_556 = new cjs.Shape();
        this.shape_556.graphics.f("#000000").s().p("AhvENQgjgKgWgPIAUg5QATANAdAKQAlAMAjAAQA+AAAhgkQAagdAAgpQAAg2gsgdQgmgag5AAIgoAAIAAg1IAoAAQAuAAAhgWQApgaAAgtQAAgjgXgWQgZgZguAAQgdAAghAMQgbAKgTAOIgTg1QAXgRAlgMQApgNApAAQBJAAArAoQAlAkAAA2QAAArgZAhQgbAigwASIAAACQA1AKAgAiQAkAnAAA3QAABFgyAtQg2AxhcAAQgqAAgqgMg");
        this.shape_556.setTransform(80.7, 123.2, 0.15, 0.15);

        this.shape_557 = new cjs.Shape();
        this.shape_557.graphics.f("#000000").s().p("Ag1GoIAApfIBsAAIAAJfgAgwkxQgTgUAAgdQAAgdAUgUQATgUAcAAQAeAAATAUQATAUAAAdQABAdgUAUQgTATgfABQgdgBgSgTg");
        this.shape_557.setTransform(98.1, 142.6, 0.15, 0.15);

        this.shape_558 = new cjs.Shape();
        this.shape_558.graphics.f("#000000").s().p("AjpGnIAAtNIBtAAIAALxIFnAAIAABcg");
        this.shape_558.setTransform(92, 142.6, 0.15, 0.15);

        this.shape_559 = new cjs.Shape();
        this.shape_559.graphics.f("#FBDE7B").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_559.setTransform(93.8, 142.6, 0.15, 0.15);

        this.shape_560 = new cjs.Shape();
        this.shape_560.graphics.f("#000000").s().p("AATEQIAAnbIgBAAIhdA0IgOg4IB1hAIA+AAIAAIfg");
        this.shape_560.setTransform(79.5, 64.2, 0.15, 0.15);

        this.shape_561 = new cjs.Shape();
        this.shape_561.graphics.f("#000000").s().p("ADLGnIAAmNImWAAIAAGNIhtAAIAAtNIBtAAIAAFiIGWAAIAAliIBuAAIAANNg");
        this.shape_561.setTransform(93.8, 83.7, 0.15, 0.15);

        this.shape_562 = new cjs.Shape();
        this.shape_562.graphics.f("#FF8375").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_562.setTransform(93.8, 83.6, 0.15, 0.15);

        this.shape_563 = new cjs.Shape();
        this.shape_563.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACShQBtg");
        this.shape_563.setTransform(792.5, 575.7, 0.15, 0.15);

        this.shape_564 = new cjs.Shape();
        this.shape_564.graphics.f("#000000").s().p("AhoDLICulmIAAgBIjFAAIAAgvID/AAIAAAlIiwFxg");
        this.shape_564.setTransform(789, 575.3, 0.15, 0.15);

        this.shape_565 = new cjs.Shape();
        this.shape_565.graphics.f("#000000").s().p("AhUDHQgagHgPgKIANgqQAnAXAwAAQAnAAAcgZQAcgZAAgnQAAgqgcgXQgegYg5ABQgWAAgiAEIAajEIDBAAIAAAuIiaAAIgQBpQAQgCASAAQAyAAAjAWQAaAPAQAWQARAdAAAkQAAA8gqAoQgsAohAAAQgfAAgdgIg");
        this.shape_565.setTransform(784, 575.3, 0.15, 0.15);

        this.shape_566 = new cjs.Shape();
        this.shape_566.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBUhRAdgoQAkgvAAgsQAAgigRgVQgVgYgpAAQgtAAgpAjIgSgnQAygqBCAAQA7AAAiAmQAdAgAAAxQAAA0gmA1QgcAphIBHIggAeIAAACIC1AAIAAAtg");
        this.shape_566.setTransform(779.3, 575.2, 0.15, 0.15);

        this.shape_567 = new cjs.Shape();
        this.shape_567.graphics.f("#000000").s().p("AATD/QhQhsAAiTQABiSBPhsIArAAQhNBrAACTQAACQBNBvg");
        this.shape_567.setTransform(775.8, 575.7, 0.15, 0.15);

        this.shape_568 = new cjs.Shape();
        this.shape_568.graphics.f("#000000").s().p("AhuENQgjgJgXgQIAUg4QAUAMAdAKQAlAMAiAAQA/AAAggkQAbgdgBgpQgBg2grgdQgmgag4AAIgpAAIAAg1IApAAQAtAAAhgWQApgaAAgtQAAgjgWgWQgagYgtAAQgegBggAMQgbAKgUAOIgTg2QAXgRAlgLQAogNAqAAQBJAAArAoQAlAjAAA3QAAArgZAhQgaAjgxARIAAACQA0AKAiAiQAjAmAAA4QAABFgyAtQg3AxhbAAQgqAAgpgMg");
        this.shape_568.setTransform(783.1, 536.6, 0.15, 0.15);

        this.shape_569 = new cjs.Shape();
        this.shape_569.graphics.f("#000000").s().p("AiEDQQgyhKAAiFQAAiEA0hMQAzhJBTAAQBWAAAuBIQAvBJAACCQAACJgxBLQgwBKhZAAQhRAAgwhJgAhNilQggA8AABrQAABpAeA8QAeA6AxAAQA3AAAcg+QAbg7AAhpQAAhogbg5Qgcg9g3AAQgwAAgdA6g");
        this.shape_569.setTransform(776.8, 536.6, 0.15, 0.15);

        this.shape_570 = new cjs.Shape();
        this.shape_570.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_570.setTransform(769.9, 536.6, 0.15, 0.15);

        this.shape_571 = new cjs.Shape();
        this.shape_571.graphics.f("#000000").s().p("AiSE2IAAmgQAAhtgFhRIBhAAIAEB3IAFAAQAUg9AsgjQAugkA4gBQARAAANAEIAABpQgRgFgUABQg5AAgoAnQglAngLBAQgGAeABAVIAAFCg");
        this.shape_571.setTransform(788.5, 557.6, 0.15, 0.15);

        this.shape_572 = new cjs.Shape();
        this.shape_572.graphics.f("#000000").s().p("AjpGnIAAtNIBsAAIAALyIFnAAIAABbg");
        this.shape_572.setTransform(781, 555.9, 0.15, 0.15);

        this.shape_573 = new cjs.Shape();
        this.shape_573.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_573.setTransform(784.2, 555.9, 0.15, 0.15);

        this.shape_574 = new cjs.Shape();
        this.shape_574.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiShNhsIArAAQBQBpAACVQAACShQBtg");
        this.shape_574.setTransform(749.5, 575.7, 0.15, 0.15);

        this.shape_575 = new cjs.Shape();
        this.shape_575.graphics.f("#000000").s().p("AAnDMIAAhwIi6AAIAAgkICzkDIA8AAIAAD8IA4AAIAAArIg4AAIAABwgAAGhZIhiCJIAAABICDAAIAAiGIADhAIgDAAIghA8g");
        this.shape_575.setTransform(745.9, 575.3, 0.15, 0.15);

        this.shape_576 = new cjs.Shape();
        this.shape_576.graphics.f("#000000").s().p("AhUDHQgagHgPgKIAOgqQAmAWAwAAQAnABAbgZQAdgYAAgoQAAgqgcgXQgegXg5AAQgXAAghAEIAajEIDBAAIAAAuIiZAAIgRBpQAQgCASAAQAyAAAkAWQAZAOAQAYQARAcAAAkQAAA9grAnQgrAohAAAQgeAAgegIg");
        this.shape_576.setTransform(741, 575.3, 0.15, 0.15);

        this.shape_577 = new cjs.Shape();
        this.shape_577.graphics.f("#000000").s().p("AiBDPIAAgiIArgqQBVhQAcgpQAlgvABgsQAAgjgSgUQgVgYgpAAQgtAAgpAiIgSgnQAxgpBDAAQA7AAAiAlQAdAhAAAwQABA1gnA1QgdAphHBHIghAeIAAABIC1AAIAAAug");
        this.shape_577.setTransform(736.2, 575.2, 0.15, 0.15);

        this.shape_578 = new cjs.Shape();
        this.shape_578.graphics.f("#000000").s().p("AATD/QhQhsAAiTQABiSBPhsIArAAQhNBrAACTQAACQBNBvg");
        this.shape_578.setTransform(732.7, 575.7, 0.15, 0.15);

        this.shape_579 = new cjs.Shape();
        this.shape_579.graphics.f("#000000").s().p("AisEUIAAgtIA6g4QBwhsAng2QAxg/AAg6QAAgugYgcQgcghg2ABQg8gBg3AvIgXg1QBAg2BZAAQBQAAAtAxQAnArAABCQAABGgyBGQgmA2hhBgIgrAoIAAACIDyAAIAAA9g");
        this.shape_579.setTransform(740.2, 536.5, 0.15, 0.15);

        this.shape_580 = new cjs.Shape();
        this.shape_580.graphics.f("#000000").s().p("AiEDQQgyhKgBiFQAAiEA1hMQAzhJBTAAQBVAAAvBIQAwBJgBCDQAACIgxBLQgwBKhZAAQhRAAgwhJgAhNilQggA9AABqQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhogbg5Qgbg9g4AAQgwAAgdA6g");
        this.shape_580.setTransform(733.8, 536.6, 0.15, 0.15);

        this.shape_581 = new cjs.Shape();
        this.shape_581.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_581.setTransform(726.8, 536.6, 0.15, 0.15);

        this.shape_582 = new cjs.Shape();
        this.shape_582.graphics.f("#000000").s().p("AjTDpQhUhXAAiOQAAiTBYhZQBThUCAAAQCCAABRBWQBRBWAACMQAACchgBZQhUBNh4AAQh+AAhRhVgAiLifQgsBBAABfQAABkAzBDQA1BCBPAAQBOAAA0hCQA1hEAAhkQAAhagqhCQgyhNhagBQhZAAgzBLg");
        this.shape_582.setTransform(746.9, 557.6, 0.15, 0.15);

        this.shape_583 = new cjs.Shape();
        this.shape_583.graphics.f("#000000").s().p("ADOGnIkKmsQhliig5h5IgDABQAJCUAADIIAAFqIhnAAIAAtNIB3AAIEMGqQBdCUA7CAIACgBQgMiOAAjMIAAljIBmAAIAANNg");
        this.shape_583.setTransform(735.6, 555.8, 0.15, 0.15);

        this.shape_584 = new cjs.Shape();
        this.shape_584.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_584.setTransform(741.1, 555.9, 0.15, 0.15);

        this.shape_585 = new cjs.Shape();
        this.shape_585.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiThNhrIArAAQBQBpAACVQAACShQBtg");
        this.shape_585.setTransform(706.4, 575.7, 0.15, 0.15);

        this.shape_586 = new cjs.Shape();
        this.shape_586.graphics.f("#000000").s().p("AhjCjQgngvAAhQQAAg3ATgyQASgtAfggQA1gzBMgJQAXgDARAAIAAAtQgUgBgVAEQg8AKgmAqQgjAngHA2IACAAQAQgVAXgMQAbgOAeAAQA3AAAiAkQAiAiAAA7QAAA7gkApQgmAsg9AAQhAAAgngvgAgtgIQgVAMgMAWQgGALAAAOQABA0AXAgQAYAhAoAAIAAAAQAkAAAVgbQAWgbAAgsQAAgsgXgZQgWgXgmAAQgXAAgWAOg");
        this.shape_586.setTransform(702.9, 575.3, 0.15, 0.15);

        this.shape_587 = new cjs.Shape();
        this.shape_587.graphics.f("#000000").s().p("AhUDHQgZgGgQgLIAOgqQAmAXAxgBQAmAAAcgYQAcgZAAgnQAAgqgcgXQgegXg5gBQgWAAgiAFIAajEIDBAAIAAAvIiZAAIgQBpQAQgDARAAQAyAAAkAWQAaAOAPAXQARAdAAAlQAAA7grAoQgrAohAAAQgfAAgdgIg");
        this.shape_587.setTransform(697.9, 575.3, 0.15, 0.15);

        this.shape_588 = new cjs.Shape();
        this.shape_588.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBUhQAcgpQAlgvAAgrQAAgkgSgUQgUgYgpAAQguAAgoAiIgSgnQAxgpBCAAQA8AAAiAlQAdAhAAAxQAAA0gmA1QgdAphHBHIggAeIAAABIC0AAIAAAug");
        this.shape_588.setTransform(693.2, 575.2, 0.15, 0.15);

        this.shape_589 = new cjs.Shape();
        this.shape_589.graphics.f("#000000").s().p("AATD/QhQhsAAiTQABiSBPhsIArAAQhNBrAACTQAACQBNBvg");
        this.shape_589.setTransform(689.7, 575.7, 0.15, 0.15);

        this.shape_590 = new cjs.Shape();
        this.shape_590.graphics.f("#000000").s().p("AATEQIAAnbIgBAAIhdA0IgOg4IB1hAIA+AAIAAIfg");
        this.shape_590.setTransform(696.6, 536.6, 0.15, 0.15);

        this.shape_591 = new cjs.Shape();
        this.shape_591.graphics.f("#000000").s().p("AiEDQQgxhJgCiGQAAiEA1hMQAzhJBTAAQBWAAAvBJQAvBIAACCQAACJgxBLQgxBKhZAAQhRAAgwhJgAhOilQgfA9AABqQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhogag5Qgcg9g4AAQgwAAgeA6g");
        this.shape_591.setTransform(690.7, 536.6, 0.15, 0.15);

        this.shape_592 = new cjs.Shape();
        this.shape_592.graphics.f("#000000").s().p("AATEQIAAnaIgCAAIhcAzIgOg5IB0g/IA/AAIAAIfg");
        this.shape_592.setTransform(683.8, 536.6, 0.15, 0.15);

        this.shape_593 = new cjs.Shape();
        this.shape_593.graphics.f("#000000").s().p("AjSFvQhLhXAAiIQAAiSBQhcQBNhXBzAAQBAAAAyAcQAtAZAWAoIADAAIAAlsIBuAAIAALeQAABpAFA0IhjAAIgFhqIgDAAQgaA2g0AgQg5AihFAAQhwAAhJhWgAh9gbQgwA/AABnQAABhAtA9QAwBDBUAAQA5AAAsgjQAugkAPg9QAFgWAAgaIAAhqQAAgagFgUQgNg1gqgkQgsgmg8AAQhSAAgyBEg");
        this.shape_593.setTransform(705.5, 555.9, 0.15, 0.15);

        this.shape_594 = new cjs.Shape();
        this.shape_594.graphics.f("#000000").s().p("AFEGnIgVl0QgOj+ABhuIgEAAQgqCUhACsIiVGbIhRAAIiImUQhEjKgeh9IgCAAQgFC4gMC9IgWFrIhoAAIA7tNICLAAICQGaQA6CrAbBwIACAAQAbhwA9irICXmaICLAAIA0NNg");
        this.shape_594.setTransform(692.8, 556.2, 0.15, 0.15);

        this.shape_595 = new cjs.Shape();
        this.shape_595.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_595.setTransform(698.1, 555.9, 0.15, 0.15);

        this.shape_596 = new cjs.Shape();
        this.shape_596.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiThNhrIAqAAQBRBpAACVQAACShRBtg");
        this.shape_596.setTransform(663.4, 575.7, 0.15, 0.15);

        this.shape_597 = new cjs.Shape();
        this.shape_597.graphics.f("#000000").s().p("AhSDKQgagIgSgLIAQgrQAOAKAWAHQAcAJAaAAQAuAAAZgbQATgVAAgfQgBgogggXQgdgTgpAAIgfAAIAAgnIAfAAQAhAAAZgRQAegTAAghQAAgbgQgRQgTgSgiAAQgrAAgmAbIgPgoQASgNAbgJQAfgJAfAAQA2gBAgAeQAcAbAAApQAAAggSAZQgUAaglANIAAABQAoAIAYAZQAbAdAAApQAAA0gmAiQgoAlhFAAQgfgBgfgIg");
        this.shape_597.setTransform(659.7, 575.3, 0.15, 0.15);

        this.shape_598 = new cjs.Shape();
        this.shape_598.graphics.f("#000000").s().p("AhUDHQgZgHgQgKIAOgqQAmAWAxABQAmgBAcgXQAcgaABgnQgBgqgcgXQgegYg5ABQgWgBgiAFIAajEIDBAAIAAAvIiaAAIgPBpQAQgDARAAQAzAAAjAWQAaAOAPAYQARAcAAAkQAAA9grAnQgrAohAAAQgfAAgdgIg");
        this.shape_598.setTransform(654.9, 575.3, 0.15, 0.15);

        this.shape_599 = new cjs.Shape();
        this.shape_599.graphics.f("#000000").s().p("AiBDPIAAgiIArgqQBVhRAcgoQAkgvABgsQAAgigRgVQgVgYgoAAQgvAAgoAiIgSgmQAxgqBCAAQA8AAAiAmQAdAgAAAxQAAA0glA0QgeAqhHBHIghAeIAAABIC1AAIAAAug");
        this.shape_599.setTransform(650.1, 575.2, 0.15, 0.15);

        this.shape_600 = new cjs.Shape();
        this.shape_600.graphics.f("#000000").s().p("AATD/QhQhsAAiTQABiSBPhsIArAAQhNBpAACVQAACQBNBvg");
        this.shape_600.setTransform(646.6, 575.7, 0.15, 0.15);

        this.shape_601 = new cjs.Shape();
        this.shape_601.graphics.f("#000000").s().p("AiEDQQgyhKgBiFQAAiEA2hMQAyhJBTAAQBWAAAuBIQAwBJAACDQAACIgyBLQgxBKhYAAQhRAAgwhJgAhOilQgfA8AABrQAABpAeA8QAdA5AyAAQA2AAAdg9QAbg7AAhpQAAhogag5Qgcg9g4AAQgwAAgeA6g");
        this.shape_601.setTransform(654.1, 536.6, 0.15, 0.15);

        this.shape_602 = new cjs.Shape();
        this.shape_602.graphics.f("#000000").s().p("AiEDRQgxhLgCiFQAAiEA1hMQAzhJBTAAQBWAAAvBIQAvBJAACDQAACIgyBLQgxBKhYAAQhRAAgwhIgAhOilQgfA8AABrQAABpAeA7QAdA6AyABQA2gBAdg9QAbg7AAhpQAAhogag5Qgdg9g3AAQgwAAgeA6g");
        this.shape_602.setTransform(647.7, 536.6, 0.15, 0.15);

        this.shape_603 = new cjs.Shape();
        this.shape_603.graphics.f("#000000").s().p("AATEQIAAnbIgBAAIhdA0IgOg4IB1hAIA+AAIAAIfg");
        this.shape_603.setTransform(640.7, 536.6, 0.15, 0.15);

        this.shape_604 = new cjs.Shape();
        this.shape_604.graphics.f("#000000").s().p("AFHE3IAAlXQAAhaghgvQghgyhCAAQgtAAgkAeQgiAcgPAqQgJAdAAAbIAAF2IhqAAIAAlrQAAhMgfgsQghgvg+AAQgwAAgnAjQgjAegOAtQgJAYAAAeIAAFuIhrAAIAAm6QgBhdgEhIIBfAAIAGBiIAEAAQBBhvB9AAQA8AAAvAhQAqAhAUA3IADAAQAagwAqgfQAcgWAegKQAhgKAqAAQBNgBA1A1QBGBFAACPIAAFkg");
        this.shape_604.setTransform(659.3, 557.6, 0.15, 0.15);

        this.shape_605 = new cjs.Shape();
        this.shape_605.graphics.f("#000000").s().p("AjiGnIAAtNIHFAAIAABcIlYAAIAAEZIE9AAIAABZIk9AAIAAF/g");
        this.shape_605.setTransform(647.6, 555.9, 0.15, 0.15);

        this.shape_606 = new cjs.Shape();
        this.shape_606.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_606.setTransform(655, 555.9, 0.15, 0.15);

        this.shape_607 = new cjs.Shape();
        this.shape_607.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACShQBtg");
        this.shape_607.setTransform(620.3, 575.7, 0.15, 0.15);

        this.shape_608 = new cjs.Shape();
        this.shape_608.graphics.f("#000000").s().p("AAnDLIAAhvIi6AAIAAgkICzkDIA7AAIAAD8IA5AAIAAArIg5AAIAABvgAAGhZIhiCJIAAABICDAAIAAiGQABgkABgcIgCAAQgTAlgOAXg");
        this.shape_608.setTransform(616.8, 575.3, 0.15, 0.15);

        this.shape_609 = new cjs.Shape();
        this.shape_609.graphics.f("#000000").s().p("AhUDHQgZgHgQgKIAOgqQAOAJAWAGQAZAIAaAAQAngBAbgYQAcgYABgoQgBgqgcgXQgegXg5gBQgWAAgiAFIAajEIDBAAIAAAvIiaAAIgPBpQAQgDARAAQAyAAAkAWQAaAOAPAYQARAcAAAlQAAA8grAnQgrAog/AAQggAAgdgIg");
        this.shape_609.setTransform(611.8, 575.3, 0.15, 0.15);

        this.shape_610 = new cjs.Shape();
        this.shape_610.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBUhRAcgoQAkgvABgsQAAgjgRgUQgVgYgpAAQguAAgoAiIgSgnQAxgpBCAAQA8AAAiAlQAeAhgBAxQAAA0glA0QgeAqhHBHIghAeIAAABIC2AAIAAAug");
        this.shape_610.setTransform(607.1, 575.2, 0.15, 0.15);

        this.shape_611 = new cjs.Shape();
        this.shape_611.graphics.f("#000000").s().p("AATD/QhQhsAAiTQAAiSBQhsIArAAQhNBpAACVQAACQBNBvg");
        this.shape_611.setTransform(603.6, 575.7, 0.15, 0.15);

        this.shape_612 = new cjs.Shape();
        this.shape_612.graphics.f("#000000").s().p("AiHEZIAAg9QAPACAsgEQBFgKAqgrQA6g0AOhdIgCAAQgwA7hOAAQhHAAgugxQgrgtAAhHQAAhQAzg4QA1g6BPAAQBTAAAxA/QAwA+AABpQAABTgbBEQgYA9grApQgfAfgqATQgmASgtAFQgbAFgdAAIgLAAgAhOi6QgfAlAAA6QAAAzAdAgQAcAeAwAAQAiAAAdgQQAbgNAPgaQAHgKgBgQQAAhKgagsQgdgvg2AAIAAAAQguAAgeAmg");
        this.shape_612.setTransform(605.5, 536.6, 0.15, 0.15);

        this.shape_613 = new cjs.Shape();
        this.shape_613.graphics.f("#000000").s().p("AiHEZIAAg9QAKACAQgBIAhgDQBFgKArgrQA5g0APhdIgCAAQgxA7hNAAQhIAAgtgxQgsgtAAhHQAAhQAzg4QA1g6BPAAQBTAAAxA/QAwA+AABpQAABTgaBEQgZA9gqApQgfAfgqATQgnASgsAFQgcAFgdAAIgLAAgAhOi6QgeAlAAA6QAAAzAcAgQAdAeAvAAQAiAAAdgQQAbgNAPgaQAHgKAAgQQAAhKgbgsQgdgvg2AAIAAAAQgvAAgdAmg");
        this.shape_613.setTransform(599, 536.6, 0.15, 0.15);

        this.shape_614 = new cjs.Shape();
        this.shape_614.graphics.f("#000000").s().p("Ah4EyQgsgMghgTIAbhUQAcARAkANQArANAnAAQA4AAAfgaQAcgYABgoQgBgngZgZQgZgZg8gXQihg4AAhyQAAhMA4gyQA7g1BcAAQAsAAApAMQAlAKAcAQIgcBQQg3gjhFAAQgtABgcAYQgaAXAAAjQAAAkAbAXQAZAUA9AZQBRAeAmAoQAoAtAABCQAABSg7AyQg+AzhnAAQgxAAgtgLg");
        this.shape_614.setTransform(616.2, 557.6, 0.15, 0.15);

        this.shape_615 = new cjs.Shape();
        this.shape_615.graphics.f("#000000").s().p("AjsGnIAAtNIHGAAIAABcIlZAAIAAELIFGAAIAABZIlGAAIAAExIFsAAIAABcg");
        this.shape_615.setTransform(608.3, 555.8, 0.15, 0.15);

        this.shape_616 = new cjs.Shape();
        this.shape_616.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_616.setTransform(612, 555.9, 0.15, 0.15);

        this.shape_617 = new cjs.Shape();
        this.shape_617.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACShQBtg");
        this.shape_617.setTransform(577.3, 575.7, 0.15, 0.15);

        this.shape_618 = new cjs.Shape();
        this.shape_618.graphics.f("#000000").s().p("AhlDSIAAgtQAOABAegDQA0gHAfggQArgnALhGIgCAAQgkAsg5AAQg2AAgigkQghgiAAg1QABg8AmgqQAogrA6AAQA/AAAkAvQAkAuAABPQAAB6hGBDQgvAvhGAIQgUADgUAAIgKAAgAg7iLQgWAcAAArQAAAnAVAXQAWAXAjAAQAaAAAVgMQAUgKALgTQAGgIgBgMQAAg3gTghQgXgjgnAAIgBAAQgjAAgWAcg");
        this.shape_618.setTransform(573.8, 575.3, 0.15, 0.15);

        this.shape_619 = new cjs.Shape();
        this.shape_619.graphics.f("#000000").s().p("AAoDLIAAhvIi8AAIAAgkIC0kDIA8AAIAAD8IA5AAIAAArIg5AAIAABvgAAGhZIhiCJIAAABICEAAIAAiGQAAghABgfIgBAAQgUAlgOAXg");
        this.shape_619.setTransform(568.9, 575.3, 0.15, 0.15);

        this.shape_620 = new cjs.Shape();
        this.shape_620.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBUhRAcgoQAlgvAAgrQAAgkgRgUQgVgYgpAAQguAAgoAiIgSgnQAygpBCAAQA7AAAiAlQAeAhAAAxQAAAzgmA2QgdAohIBIIggAeIAAABIC1AAIAAAug");
        this.shape_620.setTransform(564, 575.2, 0.15, 0.15);

        this.shape_621 = new cjs.Shape();
        this.shape_621.graphics.f("#000000").s().p("AATD/QhQhsAAiTQAAiSBQhsIArAAQhNBpAACVQAACQBNBvg");
        this.shape_621.setTransform(560.5, 575.7, 0.15, 0.15);

        this.shape_622 = new cjs.Shape();
        this.shape_622.graphics.f("#000000").s().p("AiFDuQgxgqAAg/QAAgyAdgmQAcgkAzgTIgBgDQgrgUgWgiQgVgfAAglQAAhAAwgpQAwgoBGAAQBLAAArAqQAoAlAAA3QAAAmgUAfQgXAkgvAWIAAADQA0ASAdAjQAdAlAAAxQAABFg2AuQg0ArhNAAQhSAAgzgrgAhSA2QgZAeAAAnQgCArAeAeQAfAfAwABQAxAAAegdQAegbAAgpQAAgwgggeQgdgZg5gRQgvANgaAegAhDjJQgZAYAAAlQAAAnAdAaQAZAWAwAOQAlgNAWgZQAYgaAAgjQAAglgVgZQgZgbguAAQgqAAgaAag");
        this.shape_622.setTransform(562.4, 536.6, 0.15, 0.15);

        this.shape_623 = new cjs.Shape();
        this.shape_623.graphics.f("#000000").s().p("AiHEZIAAg9QAKACAQgBIAigDQBDgKAsgrQA5g0AOhdIgCAAQgwA7hOAAQhIAAgtgxQgrgtAAhHQAAhQAzg4QA2g6BPAAQBSAAAxA/QAwA+AABpQAABTgaBEQgZA9grApQgeAfgqATQgmASgtAFQgcAFgdAAIgLAAgAhPi6QgdAlAAA6QAAAzAcAgQAdAeAvAAQAiAAAdgQQAbgNAPgaQAHgKgBgQQAAhKgagsQgdgvg2AAIgBAAQguAAgeAmg");
        this.shape_623.setTransform(556, 536.6, 0.15, 0.15);

        this.shape_624 = new cjs.Shape();
        this.shape_624.graphics.f("#000000").s().p("AhwHFIAAoLIhVAAIAAhUIBVAAIAAgcQAAiSBGhEQA4g4BaAAQAzAAArASIgPBVQgegOgoABQh0AAAACvIAAAhICQAAIAABUIiQAAIAAILg");
        this.shape_624.setTransform(574.1, 555.8, 0.15, 0.15);

        this.shape_625 = new cjs.Shape();
        this.shape_625.graphics.f("#000000").s().p("AjIFGQh3h1AAjKQAAjFB6h7QB6h7DDAAQBGAAA7ANQArAKAcAOIgaBaQhJgkhhAAQiVAAhYBcQhbBeAACiQAACeBVBbQBXBcCXAAQAxAAAwgKQAwgJAggQIAXBXQgiAQg2AMQhAANhHAAQi2AAhyhvg");
        this.shape_625.setTransform(565.5, 556.3, 0.15, 0.15);

        this.shape_626 = new cjs.Shape();
        this.shape_626.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_626.setTransform(568.9, 555.9, 0.15, 0.15);

        this.shape_627 = new cjs.Shape();
        this.shape_627.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACShQBtg");
        this.shape_627.setTransform(534.2, 575.7, 0.15, 0.15);

        this.shape_628 = new cjs.Shape();
        this.shape_628.graphics.f("#000000").s().p("AhoDLICulnIAAgBIjFAAIAAguID/AAIAAAlIivFxg");
        this.shape_628.setTransform(530.7, 575.3, 0.15, 0.15);

        this.shape_629 = new cjs.Shape();
        this.shape_629.graphics.f("#000000").s().p("AAoDLIAAhvIi8AAIAAgkIC0kDIA8AAIAAD8IA4AAIAAArIg4AAIAABvgAAGhZIhiCJIAAABICEAAIAAiGQAAghABgfIgBAAg");
        this.shape_629.setTransform(525.8, 575.3, 0.15, 0.15);

        this.shape_630 = new cjs.Shape();
        this.shape_630.graphics.f("#000000").s().p("AiADPIAAgiIArgqQBUhRAdgoQAkgvAAgrQAAgkgRgUQgVgYgoAAQguAAgpAiIgSgnQAygpBCAAQA7AAAiAlQAdAhAAAxQAAAzglA2QgdAohHBIIgiAeIAAABIC1AAIAAAug");
        this.shape_630.setTransform(521, 575.2, 0.15, 0.15);

        this.shape_631 = new cjs.Shape();
        this.shape_631.graphics.f("#000000").s().p("AATD/QhQhsAAiTQAAiSBQhsIArAAQhNBpAACVQAACQBNBvg");
        this.shape_631.setTransform(517.5, 575.7, 0.15, 0.15);

        this.shape_632 = new cjs.Shape();
        this.shape_632.graphics.f("#000000").s().p("AiMEQIDqngIAAgCIkIAAIAAg9IFVAAIAAAwIjrHvg");
        this.shape_632.setTransform(519.4, 536.6, 0.15, 0.15);

        this.shape_633 = new cjs.Shape();
        this.shape_633.graphics.f("#000000").s().p("AiHEZIAAg9QAKACAQgBIAhgDQBEgKAsgrQA5g1AOhcIgCAAQgwA7hOAAQhIAAgtgxQgrgtAAhHQAAhQAzg4QA1g6BQAAQBSAAAxA/QAwA+AABpQAABTgaBEQgYA9gsApQgfAfgqATQgmASgsAFQgcAFgdAAIgLAAgAhPi6QgeAlAAA6QAAAzAdAgQAdAeAvAAQAiAAAdgQQAbgNAPgaQAHgKgBgQQAAhKgagsQgdgvg2AAIAAAAQguAAgfAmg");
        this.shape_633.setTransform(512.9, 536.6, 0.15, 0.15);

        this.shape_634 = new cjs.Shape();
        this.shape_634.graphics.f("#000000").s().p("AB3G+IjPkjIg4A/IAADkIhtAAIAAt7IBtAAIAAIxIADAAQAQgXAlgtICwjRICFAAIjoD4IEJFng");
        this.shape_634.setTransform(530.9, 555.9, 0.15, 0.15);

        this.shape_635 = new cjs.Shape();
        this.shape_635.graphics.f("#000000").s().p("AkJGkIAAs/QBWgSByAAQBPAAA4APQA3AOAnAhQBHA0AABhQgBA+gmAyQgmAyhDAYIAAADQBHARAvAvQA5A8gBBWQABBlhIBFQhVBPjNAAQhgAAhJgKgAicFUQAbAFBBAAQBcAAA5gkQBBgrABhWQAAhShBgrQg6gmhdAAIhbAAgAiclRIAAERIBjAAQBTAAAygpQAwgnAAg+QAAhIgzgjQgvgghWAAQg6AAgmAIg");
        this.shape_635.setTransform(521, 556.2, 0.15, 0.15);

        this.shape_636 = new cjs.Shape();
        this.shape_636.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_636.setTransform(525.9, 555.9, 0.15, 0.15);

        this.shape_637 = new cjs.Shape();
        this.shape_637.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACShQBtg");
        this.shape_637.setTransform(491.2, 575.7, 0.15, 0.15);

        this.shape_638 = new cjs.Shape();
        this.shape_638.graphics.f("#000000").s().p("AhpDLICvlnIAAgBIjFAAIAAguID/AAIAAAlIiwFxg");
        this.shape_638.setTransform(487.7, 575.3, 0.15, 0.15);

        this.shape_639 = new cjs.Shape();
        this.shape_639.graphics.f("#000000").s().p("AAnDLIAAhvIi7AAIAAgkIC0kDIA7AAIAAD8IA6AAIAAArIg6AAIAABvgAAGhZIhiCJIAAABICDAAIAAiGIAChAIgCAAIghA8g");
        this.shape_639.setTransform(482.8, 575.3, 0.15, 0.15);

        this.shape_640 = new cjs.Shape();
        this.shape_640.graphics.f("#000000").s().p("AiADPIAAgiIArgqQBUhRAcgoQAlgvABgrQgBgkgRgUQgVgYgoAAQguAAgpAiIgRgnQAxgpBCAAQA7AAAiAlQAeAhAAAxQgBAzgmA2QgcAohIBIIggAeIAAABIC1AAIAAAug");
        this.shape_640.setTransform(477.9, 575.2, 0.15, 0.15);

        this.shape_641 = new cjs.Shape();
        this.shape_641.graphics.f("#000000").s().p("AATD/QhQhsAAiTQABiSBPhsIArAAQhNBqABCUQgBCQBNBvg");
        this.shape_641.setTransform(474.4, 575.7, 0.15, 0.15);

        this.shape_642 = new cjs.Shape();
        this.shape_642.graphics.f("#000000").s().p("AiEDaQg1g/AAhqQAAhMAahBQAYg9AqgqQBFhEBngNQAcgEAZAAIAAA9QgZgCgeAFQhQAOgzA4QguAzgKBJIADAAQAVgcAggRQAjgSApAAQBIAAAuAwQAuAvAABPQAABOgwA3Qg0A7hRAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAPAAASQABBGAeAqQAgAsA2AAIABAAQAvAAAdgkQAdgkAAg7QAAg6geghQgegggzAAQgfAAgdATg");
        this.shape_642.setTransform(476.3, 536.6, 0.15, 0.15);

        this.shape_643 = new cjs.Shape();
        this.shape_643.graphics.f("#000000").s().p("AiHEZIAAg9QARACAqgEQBFgKArgrQA5g0AOhdIgCAAQgwA7hOAAQhIAAgtgxQgrgtAAhHQAAhQAzg4QA1g6BPAAQBTAAAxA/QAwA+AABpQAABTgbBEQgXA8gsAqQgfAfgqATQgmASgtAFQgbAFgdAAIgLAAgAhPi6QgeAlAAA6QAAAzAdAgQAdAeAvAAQAiAAAdgQQAbgNAPgaQAGgKAAgQQAAhKgagsQgdgvg2AAIgBAAQgtAAgfAmg");
        this.shape_643.setTransform(469.9, 536.6, 0.15, 0.15);

        this.shape_644 = new cjs.Shape();
        this.shape_644.graphics.f("#000000").s().p("AFHE3IAAlXQAAhZgggwQgigyhBAAQguAAgkAeQgiAcgPArQgJAZAAAeIAAF2IhpAAIAAlrQAAhLgggtQgigvg9AAQgxAAgmAjQgjAegOAuQgJAWAAAgIAAFtIhsAAIAAm6QAAhkgFhBIBgAAIAFBiIAFAAQBBhwB9AAQA9AAAuAiQAqAhAUA3IADAAQAZgvAqggQAdgVAegLQAigLAqAAQBMAAA1A1QBFBFAACOIAAFlg");
        this.shape_644.setTransform(488.5, 557.6, 0.15, 0.15);

        this.shape_645 = new cjs.Shape();
        this.shape_645.graphics.f("#000000").s().p("AjIFGQh3h1AAjKQAAjFB7h7QB5h7DDAAQBGAAA6ANQAsAKAcAPIgaBZQhJgkhiABQiUAAhYBbQhbBdAACjQAACdBVBbQBXBdCXAAQAxAAAwgKQAvgJAigRIAWBXQgjASg1ALQhAANhHAAQi2AAhyhvg");
        this.shape_645.setTransform(475.4, 555.9, 0.15, 0.15);

        this.shape_646 = new cjs.Shape();
        this.shape_646.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_646.setTransform(482.8, 555.9, 0.15, 0.15);

        this.shape_647 = new cjs.Shape();
        this.shape_647.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACShQBtg");
        this.shape_647.setTransform(448.1, 575.7, 0.15, 0.15);

        this.shape_648 = new cjs.Shape();
        this.shape_648.graphics.f("#000000").s().p("AhSDKQgbgIgRgLIAPgrQAPAKAWAHQAcAJAaAAQAuAAAYgbQAUgWAAgeQgBgogggXQgdgTgqAAIgeAAIAAgnIAeAAQAiAAAZgRQAegTAAgiQAAgagQgQQgTgTgiAAQgXAAgYAJQgTAHgQALIgOgoQASgNAbgIQAfgLAeAAQA3ABAgAeQAcAaAAApQAAAhgTAYQgUAagkANIAAACQAnAHAZAZQAbAdAAApQAAA0gmAiQgpAkhEAAQggAAgegIg");
        this.shape_648.setTransform(444.5, 575.3, 0.15, 0.15);

        this.shape_649 = new cjs.Shape();
        this.shape_649.graphics.f("#000000").s().p("AAnDLIAAhvIi7AAIAAgkIC0kDIA7AAIAAD8IA5AAIAAArIg5AAIAABvgAAGhZIhiCJIAAABICDAAIAAiGIAChAIgCAAIghA8g");
        this.shape_649.setTransform(439.7, 575.3, 0.15, 0.15);

        this.shape_650 = new cjs.Shape();
        this.shape_650.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBVhRAbgoQAlgvAAgrQAAgkgRgUQgVgYgpAAQgtAAgpAiIgSgnQAygpBCAAQA7AAAiAlQAdAhAAAxQAAAzglA2QgdAohHBIIgiAeIAAABIC2AAIAAAug");
        this.shape_650.setTransform(434.9, 575.2, 0.15, 0.15);

        this.shape_651 = new cjs.Shape();
        this.shape_651.graphics.f("#000000").s().p("AATD/QhQhsAAiTQABiSBPhsIArAAQhNBqAACUQAACQBNBvg");
        this.shape_651.setTransform(431.4, 575.7, 0.15, 0.15);

        this.shape_652 = new cjs.Shape();
        this.shape_652.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAjAKAhAAQA0AAAlgfQAmgiAAg1QgBg4glgfQgogghMAAQgbAAgwAGIAjkGIEBAAIAAA+IjNAAIgVCMQAdgDAQAAQBBAAAyAeQAiATAUAgQAXAmAAAwQAABQg5A1Qg5A1hWAAQgqAAgmgKg");
        this.shape_652.setTransform(433.1, 536.6, 0.15, 0.15);

        this.shape_653 = new cjs.Shape();
        this.shape_653.graphics.f("#000000").s().p("AiHEZIAAg9QARACAqgEQBEgKAsgrQA5g1APhcIgDAAQgwA7hOAAQhIAAgtgxQgrgtAAhHQAAhQAzg4QA1g6BPAAQBTAAAxA/QAwA+AABpQAABTgbBEQgYA8gqAqQgfAfgrATQgmASgtAFQgbAFgdAAIgLAAgAhOi6QgfAlAAA6QAAAzAdAgQAcAeAwAAQAiAAAdgQQAbgNAPgaQAHgKAAgQQgBhKgagsQgdgvg2AAIAAAAQgvAAgdAmg");
        this.shape_653.setTransform(426.8, 536.6, 0.15, 0.15);

        this.shape_654 = new cjs.Shape();
        this.shape_654.graphics.f("#000000").s().p("AFHE3IAAlXQAAhZgggwQgigyhBAAQgtAAglAeQgiAcgPArQgIAZAAAeIAAF2IhqAAIAAlrQAAhLgggtQgigvg9AAQgwAAgnAjQgjAegOAuQgJAWAAAgIAAFtIhsAAIAAm6QAAhmgFg/IBhAAIAFBiIAEAAQBAhwB+AAQA8AAAvAiQAqAhAVA3IACAAQAagvAqggQAcgVAfgLQAhgLAqAAQBMAAA1A1QBGBFAACOIAAFlg");
        this.shape_654.setTransform(445.9, 557.6, 0.15, 0.15);

        this.shape_655 = new cjs.Shape();
        this.shape_655.graphics.f("#000000").s().p("ADsGnIhakKIkpAAIhYEKIhxAAIEftNICCAAIEgNNgAguisIhTDzID8AAIhSjyQgSgzgYhnIgDAAQgXBfgTA6g");
        this.shape_655.setTransform(432.4, 555.9, 0.15, 0.15);

        this.shape_656 = new cjs.Shape();
        this.shape_656.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_656.setTransform(439.8, 555.9, 0.15, 0.15);

        this.shape_657 = new cjs.Shape();
        this.shape_657.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACShQBtg");
        this.shape_657.setTransform(405.1, 575.7, 0.15, 0.15);

        this.shape_658 = new cjs.Shape();
        this.shape_658.graphics.f("#000000").s().p("AiADPIAAgiIArgqQBUhRAcgoQAlgvABgrQAAgkgSgUQgVgYgoAAQgvAAgoAiIgRgnQAwgpBDAAQA7AAAiAlQAdAhAAAxQAAA0glA1QgdAphIBHIggAeIAAABIC0AAIAAAug");
        this.shape_658.setTransform(401.5, 575.2, 0.15, 0.15);

        this.shape_659 = new cjs.Shape();
        this.shape_659.graphics.f("#000000").s().p("AAoDLIAAhvIi8AAIAAgkIC0kDIA7AAIAAD8IA5AAIAAArIg5AAIAABvgAAGhZIhiCJIAAABICEAAIAAiGIAChAIgCAAIgiA8g");
        this.shape_659.setTransform(396.7, 575.3, 0.15, 0.15);

        this.shape_660 = new cjs.Shape();
        this.shape_660.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBVhRAbgoQAlgvAAgrQAAgkgRgUQgVgYgpAAQgtAAgpAiIgSgnQAygpBCAAQA7AAAiAlQAdAhAAAxQAAA0glA1QgeAphHBHIggAeIAAABIC1AAIAAAug");
        this.shape_660.setTransform(391.9, 575.2, 0.15, 0.15);

        this.shape_661 = new cjs.Shape();
        this.shape_661.graphics.f("#000000").s().p("AATD/QhQhsAAiTQAAiSBQhsIArAAQhNBqAACUQAACRBNBug");
        this.shape_661.setTransform(388.4, 575.7, 0.15, 0.15);

        this.shape_662 = new cjs.Shape();
        this.shape_662.graphics.f("#000000").s().p("AA1EQIAAiVIj6AAIAAgwIDwlaIBPAAIAAFRIBMAAIAAA5IhMAAIAACVgAAIh3IiDC3IAAACICwAAIAAi1QAAgvACgmIgCAAQgVAogYApg");
        this.shape_662.setTransform(390.1, 536.6, 0.15, 0.15);

        this.shape_663 = new cjs.Shape();
        this.shape_663.graphics.f("#000000").s().p("AiHEZIAAg9QARACAqgEQBEgKAsgrQA5g1AOhcIgCAAQgwA7hNAAQhJAAgsgxQgsgtAAhHQAAhQAzg4QA2g6BPAAQBSAAAxA/QAwA+AABpQAABTgaBEQgZA8grAqQgeAfgrATQgmASgsAFQgcAFgdAAIgLAAgAhPi6QgeAlAAA6QAAAzAdAgQAdAeAvAAQAiAAAdgQQAbgNAPgaQAHgKgBgQQAAhKgagsQgdgvg2AAIAAAAQgvAAgeAmg");
        this.shape_663.setTransform(383.8, 536.6, 0.15, 0.15);

        this.shape_664 = new cjs.Shape();
        this.shape_664.graphics.f("#000000").s().p("Ai7ECQhFhEAAiSIAAliIBuAAIAAFQQAADBCHAAQAyAAApggQAjgbARgpQAKgaAAgfIAAl0IBuAAIAAG5QAABqAFA8IhiAAIgGhjIgCAAQgbAtgsAeQg4AmhHAAQhXAAg1g1g");
        this.shape_664.setTransform(401.5, 557.8, 0.15, 0.15);

        this.shape_665 = new cjs.Shape();
        this.shape_665.graphics.f("#000000").s().p("AkDGqIAAtDQBhgRBxAAQCdAABOBHQAiAfAUAsQAUAvAAA4QgBBxhBBCQgqAthEAYQhDAXhPABQg5gBgfgHIAAFTgAiWlKIAAFJQAiAHA4AAQBiAAA4gsQA5gwAAhWQAAhTg3grQg0gphbAAQhGAAghAJg");
        this.shape_665.setTransform(391.9, 555.8, 0.15, 0.15);

        this.shape_666 = new cjs.Shape();
        this.shape_666.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_666.setTransform(396.7, 555.9, 0.15, 0.15);

        this.shape_667 = new cjs.Shape();
        this.shape_667.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACShQBtg");
        this.shape_667.setTransform(362, 575.7, 0.15, 0.15);

        this.shape_668 = new cjs.Shape();
        this.shape_668.graphics.f("#000000").s().p("AhoDLICulnIAAgBIjFAAIAAguID/AAIAAAlIivFxg");
        this.shape_668.setTransform(358.6, 575.3, 0.15, 0.15);

        this.shape_669 = new cjs.Shape();
        this.shape_669.graphics.f("#000000").s().p("AhSDKQgbgIgQgLIAOgrQAPAKAWAHQAcAJAZAAQAvAAAYgbQAUgWAAgeQgBgogggXQgdgTgqAAIgfAAIAAgnIAfAAQAiAAAZgRQAfgTgBgiQAAgagQgQQgTgTgiAAQgsAAglAbIgPgoQASgNAbgIQAfgLAeAAQA3ABAgAeQAcAaAAApQAAAhgSAYQgVAagkANIAAACQAoAHAYAZQAaAdAAApQAAA0glAiQgoAkhFAAQgfAAgfgIg");
        this.shape_669.setTransform(353.6, 575.3, 0.15, 0.15);

        this.shape_670 = new cjs.Shape();
        this.shape_670.graphics.f("#000000").s().p("AiBDPIAAgiIArgqQBVhQAcgpQAlgvAAgrQAAgkgRgUQgVgYgoAAQguAAgpAiIgSgnQAxgpBDAAQA7AAAiAlQAdAhAAAxQAAA0gmA1QgcAphIBHIghAeIAAABIC1AAIAAAug");
        this.shape_670.setTransform(348.8, 575.2, 0.15, 0.15);

        this.shape_671 = new cjs.Shape();
        this.shape_671.graphics.f("#000000").s().p("AATD/QhQhsAAiTQAAiSBQhsIArAAQhNBrAACTQAACQBNBvg");
        this.shape_671.setTransform(345.3, 575.7, 0.15, 0.15);

        this.shape_672 = new cjs.Shape();
        this.shape_672.graphics.f("#000000").s().p("AhuEOQgjgKgXgPIAUg5QAUAMAdAKQAmAMAhAAQA/AAAggkQAbgdgBgpQgBg2grgdQgmgag4AAIgpAAIAAg1IApAAQAtAAAhgWQApgaAAgsQAAgkgWgWQgZgZgvAAQgeAAgfAMQgbAKgUAPIgTg2QAXgRAlgMQApgNApAAQBKAAApAoQAmAkAAA2QAAArgZAhQgaAigxASIAAACQA0AKAhAiQAkAnAAA3QAABFgyAtQg3AxhbAAQgqAAgpgLg");
        this.shape_672.setTransform(347, 536.6, 0.15, 0.15);

        this.shape_673 = new cjs.Shape();
        this.shape_673.graphics.f("#000000").s().p("AiHEZIAAg9QARACAqgEQBEgKArgrQA6g0AOhdIgCAAQgwA7hOAAQhIAAgsgxQgsgtAAhHQAAhQAzg4QA1g6BQAAQBSAAAxA/QAwA+AABpQAABTgaBEQgZA8grAqQgfAfgqATQgmASgsAFQgcAFgdAAIgLAAgAhPi6QgeAlAAA6QABAzAcAgQAdAeAvAAQAiAAAcgQQAcgNAPgaQAHgKgBgQQAAhKgagsQgdgvg2AAIAAAAQguAAgfAmg");
        this.shape_673.setTransform(340.8, 536.6, 0.15, 0.15);

        this.shape_674 = new cjs.Shape();
        this.shape_674.graphics.f("#000000").s().p("AkbGzIAAqRQAAhTgFhzIBjAAIAFBoIADAAQBHh2COAAQBvAABIBVQBKBXAACJQAACahUBZQhNBShzAAQg6AAgxgZQgygagbgtIgDAAIAAFLgAhnk1QgvAngQA8QgIAbAAATIAABpQAAASAFAbQAPA3AuAkQAuAkA7AAQBUABAxhCQAxg+AAhqQAAhggvg+QgyhEhSAAQg5AAguAlg");
        this.shape_674.setTransform(359.9, 557.6, 0.15, 0.15);

        this.shape_675 = new cjs.Shape();
        this.shape_675.graphics.f("#000000").s().p("ADOGnIkKmsQhnikg3h3IgEACQAJCUAADHIAAFqIhmAAIAAtNIB3AAIEMGrQBcCRA8CCIACgBQgMiOAAjNIAAliIBmAAIAANNg");
        this.shape_675.setTransform(347.9, 554, 0.15, 0.15);

        this.shape_676 = new cjs.Shape();
        this.shape_676.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_676.setTransform(353.7, 555.9, 0.15, 0.15);

        this.shape_677 = new cjs.Shape();
        this.shape_677.graphics.f("#000000").s().p("Ag9D/QBNhtAAiSQAAiShNhsIArAAQBQBpAACVQAACShQBtg");
        this.shape_677.setTransform(319, 575.7, 0.15, 0.15);

        this.shape_678 = new cjs.Shape();
        this.shape_678.graphics.f("#000000").s().p("AhkCyQgkggAAguQAAhLBQggIAAgCQghgPgQgaQgPgXAAgcQAAgwAjgeQAkgeA1gBQA3ABAiAeQAdAdAAApQAAA/hDAhIAAACQAnANAVAaQAWAcAAAkQAAA0goAiQgoAgg5AAQg9AAgngggAg9ApQgTAWAAAdQgBAhAVAWQAXAXAlAAQAkAAAXgUQAWgVAAgfQAAgkgYgWQgVgTgrgMQgjAKgTAWgAgyiXQgSATAAAbQAAA3BLAVQAcgJAQgTQASgUAAgbQAAgbgPgSQgTgVgjAAQgeAAgUATg");
        this.shape_678.setTransform(315.5, 575.3, 0.15, 0.15);

        this.shape_679 = new cjs.Shape();
        this.shape_679.graphics.f("#000000").s().p("AhSDKQgagIgSgLIAQgrQAOAKAWAHQAcAJAaAAQAuAAAZgbQATgVAAgfQgBgogggXQgdgTgpAAIgfAAIAAgnIAfAAQAhAAAZgRQAegTAAgiQAAgagQgQQgTgTgiAAQgWAAgYAJQgUAHgPALIgPgoQASgNAbgIQAfgLAfAAQA2ABAgAeQAcAaAAApQAAAhgSAYQgUAaglANIAAACQAoAHAYAZQAbAdAAApQAAA0gmAiQgoAkhFAAQgfAAgfgIg");
        this.shape_679.setTransform(310.5, 575.3, 0.15, 0.15);

        this.shape_680 = new cjs.Shape();
        this.shape_680.graphics.f("#000000").s().p("AiADPIAAgiIAqgqQBWhRAbgoQAlgvABgrQAAgkgSgUQgVgYgpAAQgtAAgpAiIgRgnQAwgpBDAAQA7AAAiAlQAeAhAAAxQAAA0gnA1QgcAphIBHIggAeIAAABIC1AAIAAAug");
        this.shape_680.setTransform(305.8, 575.2, 0.15, 0.15);

        this.shape_681 = new cjs.Shape();
        this.shape_681.graphics.f("#000000").s().p("AATD/QhQhsAAiTQABiSBPhsIArAAQhNBrAACTQAACQBNBvg");
        this.shape_681.setTransform(302.3, 575.7, 0.15, 0.15);

        this.shape_682 = new cjs.Shape();
        this.shape_682.graphics.f("#000000").s().p("AisEVIAAgtIA6g5QBxhsAmg1QAwhAABg6QAAgugYgcQgbggg3AAQg8AAg3AuIgXg0QAegaAlgOQApgQAtAAQBQAAAtAyQAnAsAABBQAABGgyBHQgmA2hhBgIgrAoIAAABIDyAAIAAA+g");
        this.shape_682.setTransform(304, 536.5, 0.15, 0.15);

        this.shape_683 = new cjs.Shape();
        this.shape_683.graphics.f("#000000").s().p("AiHEZIAAg9QARACAqgEQBEgKAsgrQA5g0APhdIgDAAQgwA7hOAAQhIAAgtgxQgrgtAAhHQAAhQAzg4QA1g6BQAAQBSAAAxA/QAwA+AABpQAABTgaBEQgYA8gsAqQgfAfgqATQgmASgsAFQgcAFgdAAIgLAAgAhOi6QgfAlAAA6QAAAzAdAgQAdAeAvAAQAiAAAcgQQAcgNAPgaQAHgKAAgQQAAhKgbgsQgdgvg2AAIgBAAQgtAAgeAmg");
        this.shape_683.setTransform(297.7, 536.6, 0.15, 0.15);

        this.shape_684 = new cjs.Shape();
        this.shape_684.graphics.f("#000000").s().p("AjfFcQhXhdAAi7IAAnxIBvAAIAAH0QAACIA4BGQAzBABZAAQBgAAA0hBQA4hFAAiIIAAn0IBuAAIAAHsQAAC7hbBeQhTBWiQAAQiKAAhOhSg");
        this.shape_684.setTransform(310.6, 555.9, 0.15, 0.15);

        this.shape_685 = new cjs.Shape();
        this.shape_685.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_685.setTransform(310.6, 555.9, 0.15, 0.15);

        this.shape_686 = new cjs.Shape();
        this.shape_686.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiThNhrIArAAQBQBpAACVQAACShQBtg");
        this.shape_686.setTransform(275.9, 575.7, 0.15, 0.15);

        this.shape_687 = new cjs.Shape();
        this.shape_687.graphics.f("#000000").s().p("AAODLIAAliIgBAAIhEAmIgLgqIBWgwIAwAAIAAGWg");
        this.shape_687.setTransform(272, 575.3, 0.15, 0.15);

        this.shape_688 = new cjs.Shape();
        this.shape_688.graphics.f("#000000").s().p("AhSDKQgbgIgRgLIAPgrQAPAKAWAHQAcAJAaAAQAuAAAZgbQATgVAAgfQgBgogggXQgdgTgpAAIgfAAIAAgnIAfAAQAhAAAZgRQAegTAAgiQAAgagQgQQgTgTgiAAQgrAAgmAbIgPgoQASgNAbgIQAfgLAfAAQA2ABAgAeQAcAaAAApQAAAhgTAYQgTAaglANIAAACQAnAHAZAZQAbAdAAApQAAA0gmAiQgoAkhFAAQgfAAgfgIg");
        this.shape_688.setTransform(267.5, 575.3, 0.15, 0.15);

        this.shape_689 = new cjs.Shape();
        this.shape_689.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBUhRAcgoQAlgvAAgrQAAgjgSgVQgUgYgpAAQgtAAgpAiIgSgnQAxgpBCAAQA8AAAiAlQAdAhAAAxQAAA0glA1QgeAphHBHIghAeIAAABIC2AAIAAAug");
        this.shape_689.setTransform(262.7, 575.2, 0.15, 0.15);

        this.shape_690 = new cjs.Shape();
        this.shape_690.graphics.f("#000000").s().p("AATD/QhQhsAAiTQABiSBPhsIArAAQhNBrAACTQAACQBNBvg");
        this.shape_690.setTransform(259.2, 575.7, 0.15, 0.15);

        this.shape_691 = new cjs.Shape();
        this.shape_691.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg5IB1g/IA+AAIAAIfg");
        this.shape_691.setTransform(260.5, 536.6, 0.15, 0.15);

        this.shape_692 = new cjs.Shape();
        this.shape_692.graphics.f("#000000").s().p("AiHEZIAAg9QARACAqgEQBEgKAsgrQA5g0APhdIgDAAQgwA7hOAAQhHAAgugxQgrgtAAhHQAAhQAzg4QA1g6BPAAQBTAAAwA/QAxA+AABpQAABTgbBEQgXA8gsAqQgfAfgqATQgmASgtAFQgbAFgdAAIgLAAgAhOi6QgfAlAAA6QAAAzAdAgQAcAeAwAAQAhAAAdgQQAcgNAPgaQAHgKAAgQQAAhKgbgsQgdgvg2AAIgBAAQguAAgdAmg");
        this.shape_692.setTransform(254.7, 536.6, 0.15, 0.15);

        this.shape_693 = new cjs.Shape();
        this.shape_693.graphics.f("#000000").s().p("AjBEHQgvgxAAhHQAAhuBeg5QBfg6CtAAIAAgMQAAg4gWghQgig0hPAAQgqAAgqANQgqALggAWIgZhJQAmgaA0gOQA1gOA2gBQB/AAA6BQQAtA+AABsIAADhQAABaAKA4IhkAAIgJhNIgDAAQgcAngtAYQg0Acg7AAQhXgBgzg2gAguAQQhUAiAABRQAAAzAfAcQAcAaAtAAQA2AAApgfQAjgdAPgqQAGgTAAgQIAAhoIgTAAQhhAAg3AVg");
        this.shape_693.setTransform(271.9, 557.7, 0.15, 0.15);

        this.shape_694 = new cjs.Shape();
        this.shape_694.graphics.f("#000000").s().p("AkCGqIAAtDQBggRBxAAQCdAABOBHQAjAfATAsQATAvAAA4QAABxhBBCQgqAthEAYQhDAXhPABQg4gBgfgHIAAFTgAiVlKIAAFJQAgAHA6AAQBhAAA4gsQA4gwAAhWQAAhTg2grQg0gphbAAQhHAAgfAJg");
        this.shape_694.setTransform(263.5, 555.8, 0.15, 0.15);

        this.shape_695 = new cjs.Shape();
        this.shape_695.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_695.setTransform(267.6, 555.9, 0.15, 0.15);

        this.shape_696 = new cjs.Shape();
        this.shape_696.graphics.f("#000000").s().p("AiBDPIAAgiIArgqQBWhRAbgoQAlgvAAgrQAAgjgSgVQgUgYgoAAQguAAgpAiIgSgnQAxgpBCAAQA8AAAiAlQAdAhAAAxQAAA0glA0QgdAqhIBHIggAeIAAABIC0AAIAAAug");
        this.shape_696.setTransform(229.3, 576.3, 0.15, 0.15);

        this.shape_697 = new cjs.Shape();
        this.shape_697.graphics.f("#000000").s().p("AhSDKQgbgHgRgMIAPgqQAPAJAWAHQAcAJAZAAQAvAAAYgaQAUgWgBgfQAAgoghgWQgcgUgqAAIgeAAIAAgnIAeAAQAiAAAZgQQAegUAAghQAAgbgRgRQgSgSgiAAQgXAAgYAJQgTAHgQALIgOgoQASgNAbgIQAegLAfAAQA3ABAgAdQAcAbAAApQAAAggTAZQgUAagkANIAAABQAnAJAZAYQAbAdAAApQAAA0gmAiQgpAkhEAAQggABgegJg");
        this.shape_697.setTransform(224.5, 576.3, 0.15, 0.15);

        this.shape_698 = new cjs.Shape();
        this.shape_698.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBVhRAcgoQAkgvABgrQAAgjgSgVQgVgYgpAAQgrAAgrAiIgRgnQAxgpBCAAQA7AAAiAlQAdAhAAAxQAAA0gmA0QgcAqhIBHIghAeIAAABIC2AAIAAAug");
        this.shape_698.setTransform(219.7, 576.3, 0.15, 0.15);

        this.shape_699 = new cjs.Shape();
        this.shape_699.graphics.f("#000000").s().p("AiEDRQgxhLgCiFQAAiEA2hMQAzhJBSAAQBWAAAvBJQAvBIAACDQAACIgxBLQgxBKhZAAQhRAAgwhIgAhNilQggA9AABqQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhogag5Qgcg9g4AAQgwAAgdA6g");
        this.shape_699.setTransform(218, 536.6, 0.15, 0.15);

        this.shape_700 = new cjs.Shape();
        this.shape_700.graphics.f("#000000").s().p("AiHEZIAAg9QASACAqgEQBDgKAsgrQA6g0AOhdIgDAAQgwA7hNAAQhIAAgtgxQgsgtAAhHQAAhQAzg4QA2g6BOAAQBUAAAwA/QAwA+AABpQAABTgaBEQgZA8grAqQgeAfgqATQgnASgsAFQgcAFgdAAIgLAAgAhOi6QgeAlAAA6QAAAzAcAgQAdAeAwAAQAhAAAdgQQAbgNAPgaQAHgKAAgQQAAhKgbgsQgdgvg1AAIgBAAQguAAgeAmg");
        this.shape_700.setTransform(211.6, 536.6, 0.15, 0.15);

        this.shape_701 = new cjs.Shape();
        this.shape_701.graphics.f("#000000").s().p("ACTG+IAAleQAAhQgfgtQgkg2hJAAQgxAAgrAhQgnAfgPAtQgIATABAiIAAFvIhuAAIAAt7IBuAAIAAF8IACAAQAbgyA0gcQA2gfA4AAQBRAAA4AzQBMBEAACLIAAFqg");
        this.shape_701.setTransform(229.8, 555.9, 0.15, 0.15);

        this.shape_702 = new cjs.Shape();
        this.shape_702.graphics.f("#000000").s().p("Ag2GnIAArwIkBAAIAAhdIJvAAIAABdIkCAAIAALwg");
        this.shape_702.setTransform(220, 556.3, 0.15, 0.15);

        this.shape_703 = new cjs.Shape();
        this.shape_703.graphics.f("#68BEFC").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_703.setTransform(224.5, 555.9, 0.15, 0.15);

        this.shape_704 = new cjs.Shape();
        this.shape_704.graphics.f("#000000").s().p("AhUDHQgZgHgQgKIANgqQAnAWAwAAQAnAAAbgXQAdgaAAgnQAAgpgcgYQgfgXg4AAQgXAAgiAEIAbjEIDBAAIAAAvIiaAAIgQBpQAQgDASAAQAxAAAkAWQAaAOAQAYQARAdAAAjQAAA8grAoQgrAohAAAQgfAAgdgIg");
        this.shape_704.setTransform(787.2, 517.4, 0.15, 0.15);

        this.shape_705 = new cjs.Shape();
        this.shape_705.graphics.f("#000000").s().p("AhpDMICwloIAAgBIjGAAIAAguID/AAIAAAlIivFyg");
        this.shape_705.setTransform(782.5, 517.4, 0.15, 0.15);

        this.shape_706 = new cjs.Shape();
        this.shape_706.graphics.f("#000000").s().p("AAODMIAAljIgBAAIhFAmIgLgqIBXgwIAwAAIAAGXg");
        this.shape_706.setTransform(777.2, 517.4, 0.15, 0.15);

        this.shape_707 = new cjs.Shape();
        this.shape_707.graphics.f("#000000").s().p("AATEQIAAnbIgCAAIhcAzIgOg4IB0g/IA/AAIAAIfg");
        this.shape_707.setTransform(775.4, 477.5, 0.15, 0.15);

        this.shape_708 = new cjs.Shape();
        this.shape_708.graphics.f("#000000").s().p("AiMEQIDqnhIAAgBIkIAAIAAg9IFVAAIAAAwIjrHvg");
        this.shape_708.setTransform(769.6, 477.5, 0.15, 0.15);

        this.shape_709 = new cjs.Shape();
        this.shape_709.graphics.f("#000000").s().p("Ai8ECQhFhFAAiRIAAliIBuAAIAAFPQAABdAeAwQAiA1BIAAQAxAAAqggQAjgcARgpQAKgYAAggIAAl0IBuAAIAAG5QAABqAGA8IhiAAIgHhjIgCAAQgbAtgsAeQg5AmhGAAQhXAAg2g1g");
        this.shape_709.setTransform(786.9, 498.8, 0.15, 0.15);

        this.shape_710 = new cjs.Shape();
        this.shape_710.graphics.f("#000000").s().p("AjqGnIAAtNIBtAAIAALyIFoAAIAABbg");
        this.shape_710.setTransform(778.1, 496.9, 0.15, 0.15);

        this.shape_711 = new cjs.Shape();
        this.shape_711.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_711.setTransform(782.6, 497, 0.15, 0.15);

        this.shape_712 = new cjs.Shape();
        this.shape_712.graphics.f("#000000").s().p("AhSDKQgbgIgRgLIAPgqQAPAJAWAHQAcAJAaAAQAuAAAYgaQAUgXAAgeQgBgogggWQgdgUgqABIgeAAIAAgoIAeAAQAiAAAZgRQAegTAAghQAAgbgQgRQgTgSgiAAQgXAAgYAJQgUAIgPAKIgOgoQASgNAbgIQAfgLAfABQA2AAAgAdQAcAbAAApQAAAggTAZQgTAaglANIAAACQAnAIAZAYQAbAdAAApQAAA0gmAiQgpAkhEAAQggAAgegIg");
        this.shape_712.setTransform(744.1, 517.4, 0.15, 0.15);

        this.shape_713 = new cjs.Shape();
        this.shape_713.graphics.f("#000000").s().p("AhoDMICuloIAAgBIjFAAIAAguID/AAIAAAlIivFyg");
        this.shape_713.setTransform(739.5, 517.4, 0.15, 0.15);

        this.shape_714 = new cjs.Shape();
        this.shape_714.graphics.f("#000000").s().p("AAODMIAAljIgBAAIhFAmIgLgqIBXgwIAwAAIAAGXg");
        this.shape_714.setTransform(734.2, 517.4, 0.15, 0.15);

        this.shape_715 = new cjs.Shape();
        this.shape_715.graphics.f("#000000").s().p("AiEDQQgxhKgCiFQAAiDA2hNQAzhJBSAAQBWAAAvBIQAvBJAACCQAACJgxBLQgxBKhZAAQhRAAgwhJgAhOilQgfA9AABqQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhpgag5Qgcg9g4ABQgwgBgeA7g");
        this.shape_715.setTransform(732.9, 477.6, 0.15, 0.15);

        this.shape_716 = new cjs.Shape();
        this.shape_716.graphics.f("#000000").s().p("AiMEQIDqngIAAgCIkIAAIAAg9IFVAAIAAAxIjrHug");
        this.shape_716.setTransform(726.5, 477.6, 0.15, 0.15);

        this.shape_717 = new cjs.Shape();
        this.shape_717.graphics.f("#000000").s().p("Ai4FTIgEAAIgFBkIhfAAQAFhTAAhKIAAreIBtAAIAAF/IADAAQAeg1AzgdQA2geBFAAQBxAABIBWQBIBWgBCIQAACahVBbQhNBRhuAAQiJAAhAhygAhog5QgvAlgRA8QgGAfAAAPIAABtQAAAPAFAZQAQA7AtAjQAtAkA7AAQBUAAAyhBQAwg/AAhqQAAhggug9QgxhDhTAAQg5AAgvAkg");
        this.shape_717.setTransform(745.1, 497, 0.15, 0.15);

        this.shape_718 = new cjs.Shape();
        this.shape_718.graphics.f("#000000").s().p("Ag+GnIAAloIkKnlIB8AAIB3DqQAwBgAjBOIACAAQAUgwBAh+IB5jqIB9AAIkcHkIAAFpg");
        this.shape_718.setTransform(734.7, 497.2, 0.15, 0.15);

        this.shape_719 = new cjs.Shape();
        this.shape_719.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_719.setTransform(739.6, 497, 0.15, 0.15);

        this.shape_720 = new cjs.Shape();
        this.shape_720.graphics.f("#000000").s().p("AiHEZIAAg9QARACAqgEQBEgKAsgrQA5g0AOhdIgCAAQgwA7hOAAQhIAAgtgxQgrgtAAhHQAAhQAzg4QA2g6BOAAQBTAAAxA/QAwA+AABpQAABTgbBEQgXA9gsAqQgfAegqATQgmASgsAFQgcAFgdAAIgLAAgAhPi7QgeAmAAA6QAAAzAdAgQAcAeAwAAQAiAAAdgQQAbgNAPgaQAHgKgBgQQAAhKgagsQgdgvg1AAIgBAAQguAAgfAlg");
        this.shape_720.setTransform(690.1, 477.6, 0.15, 0.15);

        this.shape_721 = new cjs.Shape();
        this.shape_721.graphics.f("#000000").s().p("AiEDaQg1g/AAhqQAAhMAahBQAYg9AqgqQBGhEBmgMQAcgFAZAAIAAA9QgYgCgfAFQhQAOgzA5QguAzgKBIIADAAQAVgcAggRQAjgSApAAQBJAAAtAwQAuAuAABQQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAPAAASQABBGAeAqQAgAsA2AAIABAAQAvAAAdgkQAdgkAAg7QAAg6geghQgegggzAAQgfAAgdATg");
        this.shape_721.setTransform(683.7, 477.6, 0.15, 0.15);

        this.shape_722 = new cjs.Shape();
        this.shape_722.graphics.f("#000000").s().p("AFHE3IAAlXQAAhZgggwQgigyhBAAQgtAAglAeQgiAcgPArQgIAZAAAeIAAF2IhqAAIAAlrQAAhLgggtQgigvg9AAQgwAAgnAiQgjAfgOAuQgJAWAAAgIAAFtIhsAAIAAm6QAAhmgFg/IBhAAIAFBiIAEAAQBAhwB+AAQA8AAAvAiQAqAhAVA3IACAAQAbgwApgfQA4grBOAAQBMAAA1A1QBGBGAACOIAAFkg");
        this.shape_722.setTransform(701.4, 498.7, 0.15, 0.15);

        this.shape_723 = new cjs.Shape();
        this.shape_723.graphics.f("#000000").s().p("Ag3GnIAArwIkAAAIAAhdIJvAAIAABdIkCAAIAALwg");
        this.shape_723.setTransform(689.8, 497, 0.15, 0.15);

        this.shape_724 = new cjs.Shape();
        this.shape_724.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_724.setTransform(696.5, 497, 0.15, 0.15);

        this.shape_725 = new cjs.Shape();
        this.shape_725.graphics.f("#000000").s().p("AiGDuQgwgqAAg/QAAgxAdgnQAbgkA0gTIgBgDQgrgVgXghQgUgfAAglQAAhAAwgpQAwgoBGAAQBKAAAsAqQAnAlAAA3QABAmgUAfQgWAkgwAWIAAADQA1ATAbAiQAeAlAAAxQAABGg1AtQg1ArhNAAQhTAAgzgrgAhSA2QgZAeAAAnQgCArAdAeQAfAfAxAAQAxAAAegcQAdgaAAgqQABgwghgeQgcgZg5gRQgvANgaAegAhEjKQgYAZAAAlQAABJBmAbQAlgMAVgYQAYgbAAgkQAAgkgVgZQgZgcguAAQgqAAgaAag");
        this.shape_725.setTransform(647.1, 477.6, 0.15, 0.15);

        this.shape_726 = new cjs.Shape();
        this.shape_726.graphics.f("#000000").s().p("AiEDaQg1g/AAhqQAAhMAahBQAYg8AqgrQBGhEBmgMQAbgFAaAAIAAA9QgZgCgeAFQhQAOgzA5QguAzgKBIIADAAQAVgcAggRQAjgSApAAQBIAAAuAwQAuAvAABPQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAPAAASQABBGAeAqQAgAsA2AAIABAAQAvAAAdgkQAdgkAAg7QAAg6geghQgfgggyAAQgfAAgdATg");
        this.shape_726.setTransform(640.6, 477.6, 0.15, 0.15);

        this.shape_727 = new cjs.Shape();
        this.shape_727.graphics.f("#000000").s().p("AiSE3IAAmhQAAhtgEhRIBgAAIAEB4IAFAAQAUg9AsglQAtgkA4AAQAPAAAQAEIAABpQgRgEgUAAQg5AAgoAoQglAmgMBAQgFAeAAAVIAAFDg");
        this.shape_727.setTransform(658, 498.7, 0.15, 0.15);

        this.shape_728 = new cjs.Shape();
        this.shape_728.graphics.f("#000000").s().p("AjsGnIAAtNIHGAAIAABcIlZAAIAAEMIFGAAIAABYIlGAAIAAEyIFsAAIAABbg");
        this.shape_728.setTransform(650.2, 497, 0.15, 0.15);

        this.shape_729 = new cjs.Shape();
        this.shape_729.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_729.setTransform(653.5, 497, 0.15, 0.15);

        this.shape_730 = new cjs.Shape();
        this.shape_730.graphics.f("#000000").s().p("AiLEQIDpngIAAgBIkIAAIAAg+IFVAAIAAAxIjqHug");
        this.shape_730.setTransform(604.1, 477.6, 0.15, 0.15);

        this.shape_731 = new cjs.Shape();
        this.shape_731.graphics.f("#000000").s().p("AiEDaQg1hAAAhqQAAhLAahCQAYg8AqgqQBFhEBngNQAYgEAdAAIAAA8QgZgBgeAFQhQAOgzA4QguAzgKBIIADAAQAVgcAggQQAjgTApAAQBIAAAuAxQAuAuAABQQAABOgwA3Qg0A7hRAAQhVAAg0g/gAg8gLQgcAQgQAeQgIAOAAATQABBFAeAqQAgAtA2AAIABAAQAvAAAdgkQAdglAAg6QAAg6gegiQgfgfgyAAQgfAAgdATg");
        this.shape_731.setTransform(597.6, 477.6, 0.15, 0.15);

        this.shape_732 = new cjs.Shape();
        this.shape_732.graphics.f("#000000").s().p("AjTDpQhUhXAAiOQAAiSBYhaQBThVCAAAQCCAABRBXQBRBXAACLQAACchgBZQhUBMh4ABQh+AAhRhVgAiLieQgsBAAABfQAABkAzBDQA1BDBPgBQBOABA0hDQA1hDAAhlQAAhagqhBQgyhPhaAAQhZAAgzBMg");
        this.shape_732.setTransform(616.2, 498.7, 0.15, 0.15);

        this.shape_733 = new cjs.Shape();
        this.shape_733.graphics.f("#000000").s().p("ADLGoIAAmOImWAAIAAGOIhtAAIAAtPIBtAAIAAFjIGWAAIAAljIBuAAIAANPg");
        this.shape_733.setTransform(604.9, 496.9, 0.15, 0.15);

        this.shape_734 = new cjs.Shape();
        this.shape_734.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_734.setTransform(610.4, 497, 0.15, 0.15);

        this.shape_735 = new cjs.Shape();
        this.shape_735.graphics.f("#000000").s().p("AiEDaQg1hAAAhqQAAhLAahCQAYg8AqgqQBEhEBogNQAYgEAdAAIAAA8QgZgBgeAFQhQAOgzA4QguAzgKBIIADAAQAVgcAggQQAjgTApAAQBIAAAuAxQAuAuAABQQAABOgwA3Qg0A7hRAAQhVAAg0g/gAg8gLQgcAQgQAeQgIAOAAATQABBFAeAqQAgAtA2AAIABAAQAvAAAdgkQAdglAAg6QAAg6gegiQgegfgzAAQgfAAgdATg");
        this.shape_735.setTransform(561, 477.6, 0.15, 0.15);

        this.shape_736 = new cjs.Shape();
        this.shape_736.graphics.f("#000000").s().p("AiEDaQg1g/AAhrQAAhLAahCQAYg8AqgqQBEhEBogNQAYgEAdAAIAAA8QgZgBgeAFQhQAOgzA4QgtAzgLBIIADAAQAWgcAfgQQAjgTApAAQBIAAAuAxQAuAuAABQQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgdAQgPAeQgIANAAAUQABBFAeAqQAhAtA1AAIABAAQAvAAAegkQAcglAAg6QAAg6gegiQgfgfgyAAQgfAAgdATg");
        this.shape_736.setTransform(554.5, 477.6, 0.15, 0.15);

        this.shape_737 = new cjs.Shape();
        this.shape_737.graphics.f("#000000").s().p("Aj6FeQA0gQAtgmQA7gvAhhMQAJgVAAgGQAAgIgHgVIjgovIB4AAICFFoQAWBBAOA6IADAAIASg7IAVhCIB4lmIB0AAIilGyQg+ChgsBSQgtBZg3AvQgkAggpAUQgfAPgbAFg");
        this.shape_737.setTransform(573.1, 498.8, 0.15, 0.15);

        this.shape_738 = new cjs.Shape();
        this.shape_738.graphics.f("#000000").s().p("AlZGkIAAtAQB1gRBzAAQDjAABxBpQB3BvAADCQAABlgfBUQgfBUg8A6Qg7A8hfAfQheAfh7AAQhqAAhcgKgAjslLIAAKbQAkAGBKAAQCsAABdheQBdhdAAirQABiZhVhVQhZhYinAAQhLAAg1ALg");
        this.shape_738.setTransform(562.6, 495, 0.15, 0.15);

        this.shape_739 = new cjs.Shape();
        this.shape_739.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_739.setTransform(567.4, 497, 0.15, 0.15);

        this.shape_740 = new cjs.Shape();
        this.shape_740.graphics.f("#000000").s().p("AhwEKQghgJgWgOIASg4QAUAMAcAIQAiAKAiAAQA0AAAlggQAmghAAg1QgBg4glgfQgogghMAAQgbAAgxAGIAkkGIEBAAIAAA+IjNAAIgVCNQAWgEAXAAQBCAAAxAdQAiAUAUAgQAXAmAAAxQAABQg5A1Qg5A1hWAAQgpAAgngLg");
        this.shape_740.setTransform(517.7, 477.7, 0.15, 0.15);

        this.shape_741 = new cjs.Shape();
        this.shape_741.graphics.f("#000000").s().p("AiEDaQg1g/AAhrQAAhLAahCQAYg8AqgqQBEhEBogNQAZgEAcAAIAAA8QgYgBgfAFQhQAOgzA4QgtAzgKBIIACAAQAVgbAggRQAkgTAoAAQBJAAAtAxQAuAuAABQQAABOgwA3QgzA7hRAAQhWAAg0g/gAg8gLQgcAQgQAeQgIANAAAUQABBFAfAqQAgAtA2AAIAAAAQAvAAAdgkQAeglAAg6QAAg6gfgiQgegfgzAAQgfAAgdATg");
        this.shape_741.setTransform(511.5, 477.6, 0.15, 0.15);

        this.shape_742 = new cjs.Shape();
        this.shape_742.graphics.f("#000000").s().p("Ai4FTIgEAAIgFBkIhfAAQAFhTAAhKIAAreIBtAAIAAF/IADAAQAeg1AzgdQA2geBFAAQByAABHBWQBIBWgBCIQAACahVBbQhNBRhuAAQiJAAhAhygAhng5QgwAlgRA8QgGAfAAAPIAABtQAAAPAFAZQARA7AsAjQAtAkA8AAQBTAAAyhBQAxg/AAhqQAAhggug9QgyhDhTAAQg5AAguAkg");
        this.shape_742.setTransform(529.6, 497, 0.15, 0.15);

        this.shape_743 = new cjs.Shape();
        this.shape_743.graphics.f("#000000").s().p("Ag2GnIAArwIkBAAIAAhdIJvAAIAABdIkCAAIAALwg");
        this.shape_743.setTransform(519.4, 497.2, 0.15, 0.15);

        this.shape_744 = new cjs.Shape();
        this.shape_744.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_744.setTransform(524.3, 497, 0.15, 0.15);

        this.shape_745 = new cjs.Shape();
        this.shape_745.graphics.f("#000000").s().p("AA1EQIAAiUIj6AAIAAgxIDwlaIBPAAIAAFRIBMAAIAAA6IhMAAIAACUgAAIh3IiDC3IAAACICwAAIAAi0QAAgmACgwIgCAAQgUAogZApg");
        this.shape_745.setTransform(474.8, 477.6, 0.15, 0.15);

        this.shape_746 = new cjs.Shape();
        this.shape_746.graphics.f("#000000").s().p("AiEDaQg1hAAAhqQAAhLAahCQAYg8AqgqQBEhEBogNQAZgEAcAAIAAA8QgYgBgfAFQhQAOgzA4QguAzgKBIIADAAQAVgbAggRQAkgTAoAAQBJAAAtAxQAuAuAABQQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgcAQgQAeQgIAOAAATQABBFAfAqQAgAtA1AAIABAAQAvAAAdgkQAeglAAg6QAAg6gfgiQgegfgzAAQgfAAgdATg");
        this.shape_746.setTransform(468.4, 477.6, 0.15, 0.15);

        this.shape_747 = new cjs.Shape();
        this.shape_747.graphics.f("#000000").s().p("AjSFvQhKhXAAiIQgBiSBQhcQBNhXBzAAQBAAAAyAcQAtAZAWAoIADAAIAAlsIBuAAIAALeQAABiAFA7IhjAAIgFhqIgDAAQgaA2g0AgQg5AihFAAQhwAAhJhWgAh9gbQgwA+AABoQAABhAtA9QAxBDBTAAQA5AAAsgjQAugkAPg9QAFgWAAgaIAAhqQAAgbgFgTQgNg1gqgkQgsgmg8AAQhSAAgyBEg");
        this.shape_747.setTransform(487.4, 497, 0.15, 0.15);

        this.shape_748 = new cjs.Shape();
        this.shape_748.graphics.f("#000000").s().p("AhWGWQhQgcg9g6Qg3g1gfhSQgghTAAhhQABi/B6h5QB+h8DOAAQBDAAA+ANQAyAKAgAQIgaBZQhRglhqAAQiZAAhcBcQhcBbAACdQAACfBZBcQBXBaCTAAQBkAAAtgWIAAj9IirAAIAAhWIEWAAIAAGVQiCAviBAAQhhAAhMgag");
        this.shape_748.setTransform(476.1, 497.2, 0.15, 0.15);

        this.shape_749 = new cjs.Shape();
        this.shape_749.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_749.setTransform(481.3, 497, 0.15, 0.15);

        this.shape_750 = new cjs.Shape();
        this.shape_750.graphics.f("#000000").s().p("AiBDPIAAgiIAsgqQBVhRAcgoQAkgvAAgsQABgigSgVQgVgYgpAAQgrAAgrAiIgSgnQAygpBCAAQA7AAAiAlQAdAhAAAxQABA0gmA0QgdAphIBIIggAeIAAABIC0AAIAAAug");
        this.shape_750.setTransform(442.8, 517.3, 0.15, 0.15);

        this.shape_751 = new cjs.Shape();
        this.shape_751.graphics.f("#000000").s().p("AhUDHQgZgGgQgLIAOgqQAmAWAxABQAmAAAcgZQAcgZAAgnQAAgqgcgXQgegYg5ABQgWgBgiAFIAajEIDBAAIAAAvIiaAAIgPBoQAQgCARAAQAxAAAlAWQAaAPAPAXQARAdAAAjQAAA9grAnQgrAohAAAQgfAAgdgIg");
        this.shape_751.setTransform(437.9, 517.4, 0.15, 0.15);

        this.shape_752 = new cjs.Shape();
        this.shape_752.graphics.f("#000000").s().p("AAODMIAAljIgBAAIhFAmIgLgqIBYgwIAuAAIAAGXg");
        this.shape_752.setTransform(432.8, 517.4, 0.15, 0.15);

        this.shape_753 = new cjs.Shape();
        this.shape_753.graphics.f("#000000").s().p("AhuEOQgkgLgWgOIAUg6QATANAeAJQAlAMAiAAQA+AAAigjQAagdgBgpQAAg2gsgdQgmgag5AAIgoAAIAAg2IAoAAQAuAAAhgVQApgaAAgtQAAgjgXgWQgZgZguAAQgeAAgfAMQgaAJgVAPIgTg2QAXgRAkgLQApgNAqAAQBKAAAqAoQAlAkAAA2QAAAqgZAiQgaAigxASIAAABQA1ALAgAiQAkAmAAA4QAABFgyAtQg3AxhbAAQgrAAgogLg");
        this.shape_753.setTransform(431.7, 477.6, 0.15, 0.15);

        this.shape_754 = new cjs.Shape();
        this.shape_754.graphics.f("#000000").s().p("AiEDaQg1g/AAhqQAAhMAahBQAYg9AqgqQBGhEBmgMQAcgFAZAAIAAA9QgYgCgfAFQhQAOgzA5QguAzgKBIIADAAQAVgcAggRQAjgSApAAQBJAAAtAwQAuAuAABQQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAPAAASQABBGAfAqQAgAsA1AAIABAAQAvAAAdgkQAdgkAAg7QAAg6geghQgegggzAAQgfAAgdATg");
        this.shape_754.setTransform(425.4, 477.6, 0.15, 0.15);

        this.shape_755 = new cjs.Shape();
        this.shape_755.graphics.f("#000000").s().p("Ai8ECQhFhFABiRIAAliIBtAAIAAFPQAABdAeAwQAiA1BIAAQAxAAAqggQAjgcARgpQAKgYAAggIAAl0IBuAAIAAG5QAABqAFA8IhhAAIgGhjIgDAAQgbAtgsAeQg5AmhGAAQhXAAg2g1g");
        this.shape_755.setTransform(442.7, 498.8, 0.15, 0.15);

        this.shape_756 = new cjs.Shape();
        this.shape_756.graphics.f("#000000").s().p("AjsGnIAAtNIHGAAIAABcIlZAAIAAEMIFGAAIAABYIlGAAIAAEyIFsAAIAABbg");
        this.shape_756.setTransform(433.4, 496.9, 0.15, 0.15);

        this.shape_757 = new cjs.Shape();
        this.shape_757.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_757.setTransform(438.2, 497, 0.15, 0.15);

        this.shape_758 = new cjs.Shape();
        this.shape_758.graphics.f("#000000").s().p("AisEVIAAguIA6g4QBxhsAmg2QAwg/ABg6QAAgugYgcQgbghg3ABQg7AAg4AuIgXg1QBAg3BZAAQBQABAtAxQAnAsAABAQAABHgyBGQgmA3hhBfIgrAoIAAADIDyAAIAAA9g");
        this.shape_758.setTransform(388.7, 477.6, 0.15, 0.15);

        this.shape_759 = new cjs.Shape();
        this.shape_759.graphics.f("#000000").s().p("AiEDaQg1g/AAhqQAAhMAahBQAYg9AqgqQBGhEBmgMQAcgFAZAAIAAA9QgYgCgfAFQhQAOgzA5QguAzgKBIIADAAQAVgcAggRQAjgSApAAQBJAAAtAwQAuAuAABQQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAPAAASQABBGAfAqQAgAsA1AAIABAAQAvAAAdgkQAdgkAAg7QAAg6geghQgegggzAAQgfAAgdATg");
        this.shape_759.setTransform(382.3, 477.6, 0.15, 0.15);

        this.shape_760 = new cjs.Shape();
        this.shape_760.graphics.f("#000000").s().p("AFHE3IAAlXQgBhZgggwQgigyhBAAQgtAAgkAeQgiAcgOArQgKAbABAcIAAF2IhqAAIAAlrQAAhLgggtQghgvg9AAQgxAAgnAiQgjAfgOAuQgJAWAAAgIAAFtIhrAAIAAm6QgBhdgFhIIBhAAIAFBiIAEAAQBBhwB9AAQA9AAAuAiQAqAhAUA3IADAAQAcgxAogeQAcgVAegLQAigLApAAQBNAAA1A1QBGBFAACOIAAFlg");
        this.shape_760.setTransform(400.1, 498.7, 0.15, 0.15);

        this.shape_761 = new cjs.Shape();
        this.shape_761.graphics.f("#000000").s().p("AigGlQg7gQgjgYIAchbQAnAYAwAPQA2AQA2AAQBQAAAwgoQAvgnAAhCQAAg6glgnQgkgmhVghQhsglg3g3Qg7g8AAhWQAAhkBLhAQBMhCB4AAQByAABJApIgfBZQhJgnhXAAQhOAAgqApQglAkAAAyQAAA4AoAmQAkAhBaAkQBvArAyA2QA2A7AABbQAABphJBCQhQBKiNAAQg7AAg+gQg");
        this.shape_761.setTransform(387.6, 497, 0.15, 0.15);

        this.shape_762 = new cjs.Shape();
        this.shape_762.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_762.setTransform(395.2, 497, 0.15, 0.15);

        this.shape_763 = new cjs.Shape();
        this.shape_763.graphics.f("#000000").s().p("Ag9D/QBNhuAAiRQAAiRhNhtIArAAQBQBpAACVQAACThQBsg");
        this.shape_763.setTransform(360.5, 516.7, 0.15, 0.15);

        this.shape_764 = new cjs.Shape();
        this.shape_764.graphics.f("#000000").s().p("AhoDMICulnIAAgCIjFAAIAAguID/AAIAAAlIiwFyg");
        this.shape_764.setTransform(357, 516.4, 0.15, 0.15);

        this.shape_765 = new cjs.Shape();
        this.shape_765.graphics.f("#000000").s().p("AAnDMIAAhwIi7AAIAAgkIC0kDIA7AAIAAD8IA5AAIAAArIg5AAIAABwgAAGhZIhiCJIAAABICDAAIAAiGIAChAIgCAAIghA8g");
        this.shape_765.setTransform(352.1, 516.4, 0.15, 0.15);

        this.shape_766 = new cjs.Shape();
        this.shape_766.graphics.f("#000000").s().p("AAPDMIAAljIgCAAIhFAmIgLgqIBXgwIAwAAIAAGXg");
        this.shape_766.setTransform(346.9, 516.4, 0.15, 0.15);

        this.shape_767 = new cjs.Shape();
        this.shape_767.graphics.f("#000000").s().p("AATD/QhQhsAAiTQAAiSBQhsIArAAQhNBpAACVQAACSBNBtg");
        this.shape_767.setTransform(343.8, 516.7, 0.15, 0.15);

        this.shape_768 = new cjs.Shape();
        this.shape_768.graphics.f("#000000").s().p("AATEQIAAnaIgBAAIhdAzIgOg4IB0hAIA/AAIAAIfg");
        this.shape_768.setTransform(345.2, 477.6, 0.15, 0.15);

        this.shape_769 = new cjs.Shape();
        this.shape_769.graphics.f("#000000").s().p("AiEDaQg1hAAAhqQAAhLAahCQAYg8AqgqQBEhEBogNQAYgEAdAAIAAA8QgYgBgfAFQhQAOgzA4QguAzgKBJIADAAQAVgcAggRQAjgSApAAQBJAAAtAwQAuAuAABQQAABOgwA3QgzA7hSAAQhVAAg0g/gAg8gLQgcAQgQAeQgIAOAAATQABBGAeApQAgAtA2AAIABAAQAvAAAdgkQAdglAAg6QAAg6gegiQgegfgzAAQgfAAgdATg");
        this.shape_769.setTransform(339.3, 477.6, 0.15, 0.15);

        this.shape_770 = new cjs.Shape();
        this.shape_770.graphics.f("#000000").s().p("AFHE3IAAlXQAAhaghgvQghgyhCAAQgtAAgkAeQgiAbgPArQgJAbAAAdIAAF2IhpAAIAAlrQAAhLgggtQgigvg9AAQgwAAgnAiQgjAfgOAtQgJAYAAAeIAAFuIhsAAIAAm6QAAhmgFg/IBhAAIAFBiIAEAAQBAhwB+AAQA9AAAuAiQAqAhAUA3IADAAQAbgwApgfQAcgWAfgKQAhgLAqAAQBMAAA1A1QBGBFAACOIAAFlg");
        this.shape_770.setTransform(356.9, 498.7, 0.15, 0.15);

        this.shape_771 = new cjs.Shape();
        this.shape_771.graphics.f("#000000").s().p("AkDGqIAAtDQBigQBwAAQCdAABOBGQAjAeATAtQAUAuAAA4QgBByhABBQgsAuhEAYQhCAYhPAAQg4gBgggHIAAFTgAiWlKIAAFKQAhAGA6AAQBhAAA4gsQA4gwABhXQgBhSg2grQg0gphaAAQhFAAgjAJg");
        this.shape_771.setTransform(344.7, 497, 0.15, 0.15);

        this.shape_772 = new cjs.Shape();
        this.shape_772.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_772.setTransform(352.2, 497, 0.15, 0.15);

        this.shape_773 = new cjs.Shape();
        this.shape_773.graphics.f("#000000").s().p("AiEDQQgxhKgCiFQAAiEA1hMQAzhJBTAAQBVAAAvBIQAvBJAACCQAACJgwBLQgyBKhYAAQhRAAgwhJgAhOimQgfA9AABrQAABpAeA7QAdA6AyAAQA2AAAdg9QAbg7AAhpQAAhogbg6Qgcg8g3AAQgwAAgeA5g");
        this.shape_773.setTransform(302.7, 477.6, 0.15, 0.15);

        this.shape_774 = new cjs.Shape();
        this.shape_774.graphics.f("#000000").s().p("AiEDaQg1g/AAhqQAAhMAahBQAYg9AqgqQBFhEBngMQAbgFAaAAIAAA9QgZgCgeAFQhQAOgzA5QguAzgKBIIADAAQAVgcAggRQAjgSApAAQBIAAAuAwQAuAvAABPQAABOgwA3Qg0A7hRAAQhVAAg0g/gAg8gLQgdAQgPAeQgIAPAAASQABBGAeAqQAgAsA2AAIABAAQAvAAAdgkQAdgkAAg7QAAg6geghQgegggzAAQgfAAgdATg");
        this.shape_774.setTransform(296.2, 477.6, 0.15, 0.15);

        this.shape_775 = new cjs.Shape();
        this.shape_775.graphics.f("#000000").s().p("AjSFvQhKhXAAiIQgBiSBRhcQBNhXByAAQBAAAAyAcQAtAZAWAoIADAAIAAlsIBuAAIAALeQAABiAFA7IhjAAIgFhqIgCAAQgbA2g0AgQg5AihFAAQhwAAhJhWgAh9gbQgwA+AABoQAABhAtA9QAxBDBTAAQA5AAAsgjQAugkAPg9QAFgTAAgdIAAhqQAAgdgFgRQgNg1gqgkQgsgmg8AAQhSAAgyBEg");
        this.shape_775.setTransform(314.9, 497, 0.15, 0.15);

        this.shape_776 = new cjs.Shape();
        this.shape_776.graphics.f("#000000").s().p("ADOGnIkKmsQhlijg5h4IgDACQAICXAADEIAAFqIhmAAIAAtNIB3AAIEMGqQBbCSA9CCIACgBQgNiOAAjNIAAliIBoAAIAANNg");
        this.shape_776.setTransform(303.7, 497.2, 0.15, 0.15);

        this.shape_777 = new cjs.Shape();
        this.shape_777.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_777.setTransform(309.1, 497, 0.15, 0.15);

        this.shape_778 = new cjs.Shape();
        this.shape_778.graphics.f("#000000").s().p("AiHEZIAAg9QASACApgEQBEgKAsgrQA6g0AOhdIgCAAQgxA7hOAAQhHAAgugxQgrgtAAhHQAAhQAzg4QA2g6BOAAQBTAAAxA/QAwA+AABpQAABTgbBEQgYA9gqAqQgfAegqATQgnASgsAFQgcAFgdAAIgLAAgAhOi6QgeAlAAA6QAAAzAdAgQAcAeAvAAQAiAAAdgQQAbgNAPgaQAHgKAAgQQAAhKgbgsQgdgvg1AAIgBAAQgvAAgdAmg");
        this.shape_778.setTransform(259.5, 477.6, 0.15, 0.15);

        this.shape_779 = new cjs.Shape();
        this.shape_779.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAjAKAhAAQA0AAAkggQAnghAAg1QgBg4glgfQgogghMAAQgfAAgsAGIAjkFIEBAAIAAA9IjNAAIgVCMQAagDASAAQBDAAAwAdQAjAUAUAgQAXAmAAAxQAABQg5A0Qg5A2hWgBQgpAAgngKg");
        this.shape_779.setTransform(252.9, 477.7, 0.15, 0.15);

        this.shape_780 = new cjs.Shape();
        this.shape_780.graphics.f("#000000").s().p("AiRE3IAAmhQgBhugFhQIBhAAIADB3IAGAAQAUg9AsgkQAugkA3AAQASAAAOAEIAABoQgQgDgWAAQg5AAgoAoQglAmgMBAQgEAeAAAVIAAFDg");
        this.shape_780.setTransform(270.8, 498.7, 0.15, 0.15);

        this.shape_781 = new cjs.Shape();
        this.shape_781.graphics.f("#000000").s().p("AkCGqIAAtDQBggQBxAAQCdAABOBGQAjAeATAtQATAuAAA4QAAByhBBBQgqAuhEAYQhDAYhPAAQg4gBgfgHIAAFTgAiVlKIAAFKQAhAGA5AAQBhAAA4gsQA5gwAAhXQAAhSg3grQg0gphbAAQhEAAgiAJg");
        this.shape_781.setTransform(262.9, 497, 0.15, 0.15);

        this.shape_782 = new cjs.Shape();
        this.shape_782.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_782.setTransform(266.1, 497, 0.15, 0.15);

        this.shape_783 = new cjs.Shape();
        this.shape_783.graphics.f("#000000").s().p("AiFDtQgxgqAAg9QAAgyAdgmQAcglAzgTIgBgDQgrgUgXgiQgUgfAAglQAAhAAwgpQAwgoBGAAQBLAAArApQAoAmAAA3QAAAmgUAfQgXAkgvAXIAAACQA0ASAcAjQAeAlAAAxQAABGg2AsQg0AshNAAQhSAAgzgsgAhSA3QgZAdAAAnQgCArAeAfQAeAeAxAAQAwAAAfgbQAdgcAAgqQAAgvgggdQgcgag5gRQgvAOgaAegAhDjKQgZAZAAAlQAABJBmAbQAlgMAWgZQAXgaAAgkQAAgkgVgZQgYgcguAAQgqAAgaAag");
        this.shape_783.setTransform(216.5, 477.6, 0.15, 0.15);

        this.shape_784 = new cjs.Shape();
        this.shape_784.graphics.f("#000000").s().p("AhwEKQgigJgVgOIASg4QAUAMAcAIQAjAKAhAAQA0AAAlggQAmghAAg1QgBg4glgfQgogghMAAQgfAAgsAGIAjkFIECAAIAAA9IjOAAIgUCMQAZgDATAAQBCAAAxAdQAiAUAUAgQAXAmAAAxQAABQg4A0Qg6A2hWgBQgqAAgmgKg");
        this.shape_784.setTransform(209.9, 477.7, 0.15, 0.15);

        this.shape_785 = new cjs.Shape();
        this.shape_785.graphics.f("#000000").s().p("Ai7DpQhPhUAAiLQAAiMBMhcQBPhfB/AAQCFAABDBmQAzBOAABrQAAAMgEAlImoAAQACBqA+A4QA3AyBXAAQA3AAArgJQAigIAkgPIATBQQhXAnhzgBQiIAAhRhUgAhxixQgnAzgHBEIE/AAQAChEgfgwQgohAhTAAQhKAAgvA9g");
        this.shape_785.setTransform(228.4, 498.8, 0.15, 0.15);

        this.shape_786 = new cjs.Shape();
        this.shape_786.graphics.f("#000000").s().p("AjHFGQh4h0AAjLQAAjFB6h7QB6h7DCAAQBHAAA7ANQAsAKAbAPIgaBZQhIgkhiABQiVgBhZBcQhaBdAACjQAACdBVBbQBXBdCWAAQAyAAAwgKQAvgJAhgQIAXBWQgiARg2AMQhAANhHAAQi3AAhwhvg");
        this.shape_786.setTransform(218.4, 497, 0.15, 0.15);

        this.shape_787 = new cjs.Shape();
        this.shape_787.graphics.f("#D4DF00").s().p("A0XcpMAAAg5RMAovAAAMAAAA5Rg");
        this.shape_787.setTransform(223, 497, 0.15, 0.15);

        this.shape_788 = new cjs.Shape();
        this.shape_788.graphics.f("#000000").s().p("EAJtAlrIAqhSIgvAAIAAgUIBIAAIAAAOIgpBYgAJYcaQgKgMAAgTQAAgOAFgMQAEgLAJgIQAPgOAYgCIAKAAIAAASIgJABQgQACgIAGQgIAHgCAKIABAAQAHgJAPABQANAAAIAIQAKAKAAAPQAAAPgLALQgLALgQAAQgTgBgLgNgAJsb1QgEADgCAEIgBAGQABAIAEAGQAEAGAIAAQAGAAAEgFQAEgFAAgIQAAgHgEgGQgEgEgHAAQgFgBgEADgAqnTNIAqhTIguAAIAAgUIBIAAIAAAPIgrBYgAqkJyQgLgMAAgUQABgOAEgMQAFgLAIgIQAQgOAYgBIAKAAIAAASIgKABQgOABgKAHQgHAGgCAKIAAAAQAJgIANAAQANAAAJAIQAJAKAAAPQAAAQgKAKQgLALgQAAQgUAAgKgNgAqQJNQgEACgCAEIgBAGQAAAIAFAGQAEAHAIgBIAAAAQAGABADgGQAEgFAAgIQAAgHgEgFQgDgGgIAAQgEAAgEAEgAqgAsQgHgBgEgCIADgSIAKADIAOABQAIABAFgEQAHgEAAgIQAAgOgcAAIgPAAIAHg1IA4AAIAAATIgnAAIgCAQIAGAAQAIAAAGABQAIACAFAEQANAJAAAOQAAAQgMAJQgMALgUAAQgJAAgIgCgAqDoeIAAgZIgtAAIAAgQIAng+IAdAAIAAA8IAMAAIAAASIgMAAIAAAZgAqHppIgFAKIgNAWIAWAAIAAgWIABgUIAAAAIgFAKgAqfxuQgIgCgEgEIAEgRIAKAEQAHACAHAAQAJAAAFgEQAEgEAAgFQABgHgHgFQgFgDgJAAIgJAAIAAgSIAJAAQAHABAFgDQAGgDAAgGQAAgFgEgDQgEgCgHAAQgGAAgGACIgJADIgGgRQAFgDAJgCQAJgCAJAAQAQgBAJAIQAJAHAAALQAAAIgEAGQgFAHgKADIAAAAQAKACAGAGQAGAHABAKQgBANgKAJQgMAJgTAAQgKAAgIgCgAqr61IAAgOIAMgNQATgPAGgJQAJgKAAgJQAAgGgEgFQgEgDgJAAQgLAAgKAIIgHgRQAGgFAIgDQAJgDAKAAQARAAAKAJQAIAJABAOQgBAMgHAMQgGAJgNALIgJAIIAAAAIAmAAIAAAUgEgKHgkEIAAhRIAAAAIgUAJIgEgRIAbgNIAUAAIAABmg");
        this.shape_788.setTransform(121.9, 321.1);

        this.addChild(this.shape_788, this.shape_787, this.shape_786, this.shape_785, this.shape_784, this.shape_783, this.shape_782, this.shape_781, this.shape_780, this.shape_779, this.shape_778, this.shape_777, this.shape_776, this.shape_775, this.shape_774, this.shape_773, this.shape_772, this.shape_771, this.shape_770, this.shape_769, this.shape_768, this.shape_767, this.shape_766, this.shape_765, this.shape_764, this.shape_763, this.shape_762, this.shape_761, this.shape_760, this.shape_759, this.shape_758, this.shape_757, this.shape_756, this.shape_755, this.shape_754, this.shape_753, this.shape_752, this.shape_751, this.shape_750, this.shape_749, this.shape_748, this.shape_747, this.shape_746, this.shape_745, this.shape_744, this.shape_743, this.shape_742, this.shape_741, this.shape_740, this.shape_739, this.shape_738, this.shape_737, this.shape_736, this.shape_735, this.shape_734, this.shape_733, this.shape_732, this.shape_731, this.shape_730, this.shape_729, this.shape_728, this.shape_727, this.shape_726, this.shape_725, this.shape_724, this.shape_723, this.shape_722, this.shape_721, this.shape_720, this.shape_719, this.shape_718, this.shape_717, this.shape_716, this.shape_715, this.shape_714, this.shape_713, this.shape_712, this.shape_711, this.shape_710, this.shape_709, this.shape_708, this.shape_707, this.shape_706, this.shape_705, this.shape_704, this.shape_703, this.shape_702, this.shape_701, this.shape_700, this.shape_699, this.shape_698, this.shape_697, this.shape_696, this.shape_695, this.shape_694, this.shape_693, this.shape_692, this.shape_691, this.shape_690, this.shape_689, this.shape_688, this.shape_687, this.shape_686, this.shape_685, this.shape_684, this.shape_683, this.shape_682, this.shape_681, this.shape_680, this.shape_679, this.shape_678, this.shape_677, this.shape_676, this.shape_675, this.shape_674, this.shape_673, this.shape_672, this.shape_671, this.shape_670, this.shape_669, this.shape_668, this.shape_667, this.shape_666, this.shape_665, this.shape_664, this.shape_663, this.shape_662, this.shape_661, this.shape_660, this.shape_659, this.shape_658, this.shape_657, this.shape_656, this.shape_655, this.shape_654, this.shape_653, this.shape_652, this.shape_651, this.shape_650, this.shape_649, this.shape_648, this.shape_647, this.shape_646, this.shape_645, this.shape_644, this.shape_643, this.shape_642, this.shape_641, this.shape_640, this.shape_639, this.shape_638, this.shape_637, this.shape_636, this.shape_635, this.shape_634, this.shape_633, this.shape_632, this.shape_631, this.shape_630, this.shape_629, this.shape_628, this.shape_627, this.shape_626, this.shape_625, this.shape_624, this.shape_623, this.shape_622, this.shape_621, this.shape_620, this.shape_619, this.shape_618, this.shape_617, this.shape_616, this.shape_615, this.shape_614, this.shape_613, this.shape_612, this.shape_611, this.shape_610, this.shape_609, this.shape_608, this.shape_607, this.shape_606, this.shape_605, this.shape_604, this.shape_603, this.shape_602, this.shape_601, this.shape_600, this.shape_599, this.shape_598, this.shape_597, this.shape_596, this.shape_595, this.shape_594, this.shape_593, this.shape_592, this.shape_591, this.shape_590, this.shape_589, this.shape_588, this.shape_587, this.shape_586, this.shape_585, this.shape_584, this.shape_583, this.shape_582, this.shape_581, this.shape_580, this.shape_579, this.shape_578, this.shape_577, this.shape_576, this.shape_575, this.shape_574, this.shape_573, this.shape_572, this.shape_571, this.shape_570, this.shape_569, this.shape_568, this.shape_567, this.shape_566, this.shape_565, this.shape_564, this.shape_563, this.shape_562, this.shape_561, this.shape_560, this.shape_559, this.shape_558, this.shape_557, this.shape_556, this.shape_555, this.shape_554, this.shape_553, this.shape_552, this.shape_551, this.shape_550, this.shape_549, this.shape_548, this.shape_547, this.shape_546, this.shape_545, this.shape_544, this.shape_543, this.shape_542, this.shape_541, this.shape_540, this.shape_539, this.shape_538, this.shape_537, this.shape_536, this.shape_535, this.shape_534, this.shape_533, this.shape_532, this.shape_531, this.shape_530, this.shape_529, this.shape_528, this.shape_527, this.shape_526, this.shape_525, this.shape_524, this.shape_523, this.shape_522, this.shape_521, this.shape_520, this.shape_519, this.shape_518, this.shape_517, this.shape_516, this.shape_515, this.shape_514, this.shape_513, this.shape_512, this.shape_511, this.shape_510, this.shape_509, this.shape_508, this.shape_507, this.shape_506, this.shape_505, this.shape_504, this.shape_503, this.shape_502, this.shape_501, this.shape_500, this.shape_499, this.shape_498, this.shape_497, this.shape_496, this.shape_495, this.shape_494, this.shape_493, this.shape_492, this.shape_491, this.shape_490, this.shape_489, this.shape_488, this.shape_487, this.shape_486, this.shape_485, this.shape_484, this.shape_483, this.shape_482, this.shape_481, this.shape_480, this.shape_479, this.shape_478, this.shape_477, this.shape_476, this.shape_475, this.shape_474, this.shape_473, this.shape_472, this.shape_471, this.shape_470, this.shape_469, this.shape_468, this.shape_467, this.shape_466, this.shape_465, this.shape_464, this.shape_463, this.shape_462, this.shape_461, this.shape_460, this.shape_459, this.shape_458, this.shape_457, this.shape_456, this.shape_455, this.shape_454, this.shape_453, this.shape_452, this.shape_451, this.shape_450, this.shape_449, this.shape_448, this.shape_447, this.shape_446, this.shape_445, this.shape_444, this.shape_443, this.shape_442, this.shape_441, this.shape_440, this.shape_439, this.shape_438, this.shape_437, this.shape_436, this.shape_435, this.shape_434, this.shape_433, this.shape_432, this.shape_431, this.shape_430, this.shape_429, this.shape_428, this.shape_427, this.shape_426, this.shape_425, this.shape_424, this.shape_423, this.shape_422, this.shape_421, this.shape_420, this.shape_419, this.shape_418, this.shape_417, this.shape_416, this.shape_415, this.shape_414, this.shape_413, this.shape_412, this.shape_411, this.shape_410, this.shape_409, this.shape_408, this.shape_407, this.shape_406, this.shape_405, this.shape_404, this.shape_403, this.shape_402, this.shape_401, this.shape_400, this.shape_399, this.shape_398, this.shape_397, this.shape_396, this.shape_395, this.shape_394, this.shape_393, this.shape_392, this.shape_391, this.shape_390, this.shape_389, this.shape_388, this.shape_387, this.shape_386, this.shape_385, this.shape_384, this.shape_383, this.shape_382, this.shape_381, this.shape_380, this.shape_379, this.shape_378, this.shape_377, this.shape_376, this.shape_375, this.shape_374, this.shape_373, this.shape_372, this.shape_371, this.shape_370, this.shape_369, this.shape_368, this.shape_367, this.shape_366, this.shape_365, this.shape_364, this.shape_363, this.shape_362, this.shape_361, this.shape_360, this.shape_359, this.shape_358, this.shape_357, this.shape_356, this.shape_355, this.shape_354, this.shape_353, this.shape_352, this.shape_351, this.shape_350, this.shape_349, this.shape_348, this.shape_347, this.shape_346, this.shape_345, this.shape_344, this.shape_343, this.shape_342, this.shape_341, this.shape_340, this.shape_339, this.shape_338, this.shape_337, this.shape_336, this.shape_335, this.shape_334, this.shape_333, this.shape_332, this.shape_331, this.shape_330, this.shape_329, this.shape_328, this.shape_327, this.shape_326, this.shape_325, this.shape_324, this.shape_323, this.shape_322, this.shape_321, this.shape_320, this.shape_319, this.shape_318, this.shape_317, this.shape_316, this.shape_315, this.shape_314, this.shape_313, this.shape_312, this.shape_311, this.shape_310, this.shape_309, this.shape_308, this.shape_307, this.shape_306, this.shape_305, this.shape_304, this.shape_303, this.shape_302, this.shape_301, this.shape_300, this.shape_299, this.shape_298, this.shape_297, this.shape_296, this.shape_295, this.shape_294, this.shape_293, this.shape_292, this.shape_291, this.shape_290, this.shape_289, this.shape_288, this.shape_287, this.shape_286, this.shape_285, this.shape_284, this.shape_283, this.shape_282, this.shape_281, this.shape_280, this.shape_279, this.shape_278, this.shape_277, this.shape_276, this.shape_275, this.shape_274, this.shape_273, this.shape_272, this.shape_271, this.shape_270, this.shape_269, this.shape_268, this.shape_267, this.shape_266, this.shape_265, this.shape_264, this.shape_263, this.shape_262, this.shape_261, this.shape_260, this.shape_259, this.shape_258, this.shape_257, this.shape_256, this.shape_255, this.shape_254, this.shape_253, this.shape_252, this.shape_251, this.shape_250, this.shape_249, this.shape_248, this.shape_247, this.shape_246, this.shape_245, this.shape_244, this.shape_243, this.shape_242, this.shape_241, this.shape_240, this.shape_239, this.shape_238, this.shape_237, this.shape_236, this.shape_235, this.shape_234, this.shape_233, this.shape_232, this.shape_231, this.shape_230, this.shape_229, this.shape_228, this.shape_227, this.shape_226, this.shape_225, this.shape_224, this.shape_223, this.shape_222, this.shape_221, this.shape_220, this.shape_219, this.shape_218, this.shape_217, this.shape_216, this.shape_215, this.shape_214, this.shape_213, this.shape_212, this.shape_211, this.shape_210, this.shape_209, this.shape_208, this.shape_207, this.shape_206, this.shape_205, this.shape_204, this.shape_203, this.shape_202, this.shape_201, this.shape_200, this.shape_199, this.shape_198, this.shape_197, this.shape_196, this.shape_195, this.shape_194, this.shape_193, this.shape_192, this.shape_191, this.shape_190, this.shape_189, this.shape_188, this.shape_187, this.shape_186, this.shape_185, this.shape_184, this.shape_183, this.shape_182, this.shape_181, this.shape_180, this.shape_179, this.shape_178, this.shape_177, this.shape_176, this.shape_175, this.shape_174, this.shape_173, this.shape_172, this.shape_171, this.shape_170, this.shape_169, this.shape_168, this.shape_167, this.shape_166, this.shape_165, this.shape_164, this.shape_163, this.shape_162, this.shape_161, this.shape_160, this.shape_159, this.shape_158, this.shape_157, this.shape_156, this.shape_155, this.shape_154, this.shape_153, this.shape_152, this.shape_151, this.shape_150, this.shape_149, this.shape_148, this.shape_147, this.shape_146, this.shape_145, this.shape_144, this.shape_143, this.shape_142, this.shape_141, this.shape_140, this.shape_139, this.shape_138, this.shape_137, this.shape_136, this.shape_135, this.shape_134, this.shape_133, this.shape_132, this.shape_131, this.shape_130, this.shape_129, this.shape_128, this.shape_127, this.shape_126, this.shape_125, this.shape_124, this.shape_123, this.shape_122, this.shape_121, this.shape_120, this.shape_119, this.shape_118, this.shape_117, this.shape_116, this.shape_115, this.shape_114, this.shape_113, this.shape_112, this.shape_111, this.shape_110, this.shape_109, this.shape_108, this.shape_107, this.shape_106, this.shape_105, this.shape_104, this.shape_103, this.shape_102, this.shape_101, this.shape_100, this.shape_99, this.shape_98, this.shape_97, this.shape_96, this.shape_95, this.shape_94, this.shape_93, this.shape_92, this.shape_91, this.shape_90, this.shape_89, this.shape_88, this.shape_87, this.shape_86, this.shape_85, this.shape_84, this.shape_83, this.shape_82, this.shape_81, this.shape_80, this.shape_79, this.shape_78, this.shape_77, this.shape_76, this.shape_75, this.shape_74, this.shape_73, this.shape_72, this.shape_71, this.shape_70, this.shape_69, this.shape_68, this.shape_67, this.shape_66, this.shape_65, this.shape_64, this.shape_63, this.shape_62, this.shape_61, this.shape_60, this.shape_59, this.shape_58, this.shape_57, this.shape_56, this.shape_55, this.shape_54, this.shape_53, this.shape_52, this.shape_51, this.shape_50, this.shape_49, this.shape_48, this.shape_47, this.shape_46, this.shape_45, this.shape_44, this.shape_43, this.shape_42, this.shape_41, this.shape_40, this.shape_39, this.shape_38, this.shape_37, this.shape_36, this.shape_35, this.shape_34, this.shape_33, this.shape_32, this.shape_31, this.shape_30, this.shape_29, this.shape_28, this.shape_27, this.shape_26, this.shape_25, this.shape_24, this.shape_23, this.shape_22, this.shape_21, this.shape_20, this.shape_19, this.shape_18, this.shape_17, this.shape_16, this.shape_15, this.shape_14, this.shape_13, this.shape_12, this.shape_11, this.shape_10, this.shape_9, this.shape_8, this.shape_7, this.shape_6, this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape, this.text_90, this.text_89, this.text_88, this.text_87, this.text_86, this.text_85, this.text_84, this.text_83, this.text_82, this.text_81, this.text_80, this.text_79, this.text_78, this.text_77, this.text_76, this.text_75, this.text_74, this.text_73, this.text_72, this.text_71, this.text_70, this.text_69, this.text_68, this.text_67, this.text_66, this.text_65, this.text_64, this.text_63, this.text_62, this.text_61, this.text_60, this.text_59, this.text_58, this.text_57, this.text_56, this.text_55, this.text_54, this.text_53, this.text_52, this.text_51, this.text_50, this.text_49, this.text_48, this.text_47, this.text_46, this.text_45, this.text_44, this.text_43, this.text_42, this.text_41, this.text_40, this.text_39, this.text_38, this.text_37, this.text_36, this.text_35, this.text_34, this.text_33, this.text_32, this.text_31, this.text_30, this.text_29, this.text_28, this.text_27, this.text_26, this.text_25, this.text_24, this.text_23, this.text_22, this.text_21, this.text_20, this.text_19, this.text_18, this.text_17, this.text_16, this.text_15, this.text_14, this.text_13, this.text_12, this.text_11, this.text_10, this.text_9, this.text_8, this.text_7, this.text_6, this.text_5, this.text_4, this.text_3, this.text_2, this.text_1, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(53, 32.3, 792.7, 551.1);



    (lib.Imagen_03 = function () {
        this.initialize();

        // TABLA
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#003399").ss(2, 0, 0, 4).p("EBKKAAAMiUTAAA");
        this.shape.setTransform(0.5, 95.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#003399").ss(2, 0, 0, 4).p("EhJ7AAAMCT3AAA");
        this.shape_1.setTransform(1.4, 43.4);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AkBAAIICAA");
        this.shape_2.setTransform(448.5, -167.2);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#003399").ss(2, 0, 0, 4).p("A4oAAMAxRAAA");
        this.shape_3.setTransform(317.1, -114.2);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#003399").ss(2, 0, 0, 4).p("A4gAAMAxBAAA");
        this.shape_4.setTransform(316.8, -62.1);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#003399").ss(2, 0, 0, 4).p("EhKCAAAMCUFAAA");
        this.shape_5.setTransform(0.9, -9.5);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AISAAIwjAA");
        this.shape_6.setTransform(-419.9, -61.6);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AINAAIwZAA");
        this.shape_7.setTransform(-419.9, -114.2);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AEBAAIoBAA");
        this.shape_8.setTransform(-447.7, -166.7);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAoWIAAQt");
        this.shape_9.setTransform(-208.9, 221.3);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAoVIAAQr");
        this.shape_10.setTransform(-156.3, 220.7);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAobIAAQ3");
        this.shape_11.setTransform(-103.7, 221.3);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAoYIAAQx");
        this.shape_12.setTransform(-51, 220.4);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAoVIAAQr");
        this.shape_13.setTransform(0.4, 220.7);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAoYIAAQx");
        this.shape_14.setTransform(54.2, 221);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAobIAAQ3");
        this.shape_15.setTransform(106.2, 220.7);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAobIAAQ3");
        this.shape_16.setTransform(159.4, 220.7);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAoeIAAQ9");
        this.shape_17.setTransform(212, 220.4);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAoYIAAQx");
        this.shape_18.setTransform(264.7, 220.4);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAoeIAAQ9");
        this.shape_19.setTransform(316.7, 221);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAobIAAQ3");
        this.shape_20.setTransform(369.4, 220.7);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAohIAARD");
        this.shape_21.setTransform(423.1, 221.3);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAA4yMAAAAxl");
        this.shape_22.setTransform(423.5, -9.2);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAA41MAAAAxr");
        this.shape_23.setTransform(369.9, -8.3);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAA4yMAAAAxl");
        this.shape_24.setTransform(317.3, -9.2);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAA4sMAAAAxZ");
        this.shape_25.setTransform(265.2, -8.6);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAA4vMAAAAxf");
        this.shape_26.setTransform(210.9, -9.5);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAwYMAAAAgx");
        this.shape_27.setTransform(158.4, 43.9);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAwhMAAAAhD");
        this.shape_28.setTransform(105.6, 43.6);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAweMAAAAg9");
        this.shape_29.setTransform(54.2, 44.5);

        this.shape_30 = new cjs.Shape();
        this.shape_30.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAwkMAAAAhJ");
        this.shape_30.setTransform(0.4, 43.4);

        this.shape_31 = new cjs.Shape();
        this.shape_31.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAwbMAAAAg3");
        this.shape_31.setTransform(-51.6, 43.1);

        this.shape_32 = new cjs.Shape();
        this.shape_32.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAweMAAAAg9");
        this.shape_32.setTransform(-104.2, 43.4);

        this.shape_33 = new cjs.Shape();
        this.shape_33.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAwbMAAAAg3");
        this.shape_33.setTransform(-156.3, 44.2);

        this.shape_34 = new cjs.Shape();
        this.shape_34.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAwbMAAAAg3");
        this.shape_34.setTransform(-209.5, 43.1);

        this.shape_35 = new cjs.Shape();
        this.shape_35.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAwVMAAAAgr");
        this.shape_35.setTransform(-262.1, 43.6);

        this.shape_36 = new cjs.Shape();
        this.shape_36.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAwbMAAAAg3");
        this.shape_36.setTransform(-314.7, 43.7);

        this.shape_37 = new cjs.Shape();
        this.shape_37.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAA4vMAAAAxf");
        this.shape_37.setTransform(-422, -8.9);

        this.shape_38 = new cjs.Shape();
        this.shape_38.graphics.f().s("#003399").ss(2, 0, 0, 4).p("AAAwcMAAAAg5");
        this.shape_38.setTransform(-368, 43.5);

        this.shape_39 = new cjs.Shape();
        this.shape_39.graphics.f().s("#003399").ss(4, 0, 0, 4).p("EBKFgciMAAAA5lMiUJAAAMgABg6FIINAAIAAImIIcAAIAAQkMBSNAAAIAAwkMApOAAAIAAoGg");
        this.shape_39.setTransform(0.7, -36.8);

        this.shape_40 = new cjs.Shape();
        this.shape_40.graphics.f().s("#003399").ss(2, 0, 0, 4).p("Eg50AAAMBzpAAA");
        this.shape_40.setTransform(106.9, 219.9);

        this.shape_41 = new cjs.Shape();
        this.shape_41.graphics.f().s("#003399").ss(4, 0, 0, 4).p("EA5rAIcMhzVAAAIAAw3MBzVAAAg");
        this.shape_41.setTransform(106.9, 220.9);

        // COLORES
        this.shape_42 = new cjs.Shape();
        this.shape_42.graphics.f("#96B3BD").s().p("AkBEEIAAoHIIDAAIAAIHg");
        this.shape_42.setTransform(449.4, -193.2);

        this.shape_43 = new cjs.Shape();
        this.shape_43.graphics.f("#96B3BD").s().p("EgpEAQjMAAAghGMBSJAAAMAAAAhGg");
        this.shape_43.setTransform(-100.2, 44.1, 1.018, 1);

        this.shape_44 = new cjs.Shape();
        this.shape_44.graphics.f("#96B3BD").s().p("A4wYzMAAAgxlMAxhAAAMAAAAxlg");
        this.shape_44.setTransform(317, -8.9);

        this.shape_45 = new cjs.Shape();
        this.shape_45.graphics.f("#96B3BD").s().p("AoRdAMgAEg6EIIUAFIgEIiIIbAJMgAOAxZg");
        this.shape_45.setTransform(-420.5, -36.9);

        this.shape_46 = new cjs.Shape();
        this.shape_46.graphics.f("#96B3BD").s().p("Eg5xAIZIAAwxMBzjAAAIAAQxg");
        this.shape_46.setTransform(107.6, 220.9);

        this.addChild(this.shape_46, this.shape_45, this.shape_44, this.shape_43, this.shape_42, this.shape_41, this.shape_40, this.shape_39, this.shape_38, this.shape_37, this.shape_36, this.shape_35, this.shape_34, this.shape_33, this.shape_32, this.shape_31, this.shape_30, this.shape_29, this.shape_28, this.shape_27, this.shape_26, this.shape_25, this.shape_24, this.shape_23, this.shape_22, this.shape_21, this.shape_20, this.shape_19, this.shape_18, this.shape_17, this.shape_16, this.shape_15, this.shape_14, this.shape_13, this.shape_12, this.shape_11, this.shape_10, this.shape_9, this.shape_8, this.shape_7, this.shape_6, this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-474, -223.1, 951.5, 498.1);



    (lib.CdP_Practica = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape.setTransform(65, 15);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_1.setTransform(65, 15);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#666666").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_2.setTransform(65, 15);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 130, 30);


    (lib.btn_practica = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape.setTransform(65, 15);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 3).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);



    (lib.IMG_08 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        mask.setTransform(160.6, 187.5);

        // Capa 2
        this.instance = new lib.CdP_Ampliacio_08();
        this.instance.setTransform(-22.3, 185, 0.71, 0.71, 0, 0, 0, 475, 303.9);

        this.instance.mask = mask;

        this.timeline.addTween(cjs.Tween.get(this.instance).to({x: 307.6}, 24).wait(1));

        // Capa 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        this.shape.setTransform(160.6, 187.5);

        this.shape.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).wait(250000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-359.8, -30.8, 681, 431.9);


    (lib.IMG_04 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        mask.setTransform(160.6, 187.5);

        // Capa 2
        this.instance = new lib.CdP_Ampliacio_04();
        this.instance.setTransform(155.9, 175.4, 0.608, 0.608, 0, 0, 0, 475, 303.9);

        this.instance.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}]}).wait(25));

        // Capa 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        this.shape.setTransform(160.6, 187.5);

        this.shape.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).wait(25));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-132.8, -9.3, 577.5, 384.3);


    (lib.IMG_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        mask.setTransform(160.6, 187.5);

        // Capa 5
        this.instance = new lib.CdP_Ampliacio_02();
        this.instance.setTransform(157, 185.6, 0.653, 0.653, 0, 0, 0, 475, 303.9);

        this.instance.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}]}).wait(25));

        // Capa 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        this.shape.setTransform(160.6, 187.5);

        this.shape.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).wait(25));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-153.2, -12.8, 620.5, 397.1);


    (lib.IMG_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        mask.setTransform(160.6, 187.5);

        // Capa 2
        this.instance = new lib.CdP_Ampliacio_01();
        this.instance.setTransform(310.4, 186.6, 0.596, 0.596, 0, 0, 0, 475, 303.9);

        this.instance.mask = mask;

        this.timeline.addTween(cjs.Tween.get(this.instance).to({x: 80.4}, 24).wait(1));

        // Capa 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        this.shape.setTransform(160.6, 187.5);

        this.shape.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).wait(250000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 531.3, 374.9);


    (lib.popup_ampliar_08 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

      

        // Capa 4
        this.instance_1 = new lib.CdP_Ampliacio_08();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_07 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

     

        // Capa 4
        this.instance_1 = new lib.CdP_Ampliacio_07();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_05 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

     
        // Capa 4
        this.instance_1 = new lib.CdP_Ampliacio_05();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_04 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

      

        // Capa 4
        this.instance_1 = new lib.CdP_Ampliacio_04();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(10000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

       

        // Capa 4
        this.instance_1 = new lib.CdP_Ampliacio_02();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(10000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 4
        this.instance = new lib.CdP_Ampliacio_01();
        this.instance.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX: 449.3, regY: 307.9, x: 449.3, y: 307.9, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(10000));



    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_06 = function () {
        this.initialize();

        // Capa 2
        this.text = new cjs.Text("Electronegatividad y energía de ionización", "20px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 21;
        this.text.lineWidth = 531;
        this.text.setTransform(397.7, 269.4);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#CC0000").ss(3, 1, 1).p("Ag7A8IB3h3");
        this.shape.setTransform(481.5, 363, 0.999, 0.999, 0, 180, 0);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#CC0000").ss(3, 1, 1).p("Ag7A8IB3h3");
        this.shape_1.setTransform(480.5, 350.9, 0.999, 0.999);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#CC0000").ss(3, 1, 1).p("ARGAAMgiLAAA");
        this.shape_2.setTransform(583.9, 357);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#CC0000").ss(3, 1, 1).p("Ag7A8IB3h3");
        this.shape_3.setTransform(598.2, 249.9, 0.999, 0.999, 0, 0, -179.9);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#CC0000").ss(3, 1, 1).p("Ag7A8IB3h3");
        this.shape_4.setTransform(598.4, 262.1, 0.999, 0.999, -179.9);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#CC0000").ss(3, 1, 1).p("EghTAAAMBCnAAA");
        this.shape_5.setTransform(391.3, 256);

        this.text_1 = new cjs.Text("Radio atómico", "18px Verdana");
        this.text_1.textAlign = "center";
        this.text_1.lineHeight = 19;
        this.text_1.lineWidth = 247;
        this.text_1.setTransform(578.8, 329.1);

        // Capa 4
        this.instance = new lib.mc_pastillaBlanca();
        this.instance.setTransform(525.7, 345.8, 0.67, 0.525, 0, 0, 0, 230.5, 54);

        this.instance_1 = new lib.mc_pastillaBlanca();
        this.instance_1.setTransform(396.5, 286.6, 1, 0.525, 0, 0, 0, 230.5, 54);

        // Capa 3
        this.instance_2 = new lib.Imagen_03();
        this.instance_2.setTransform(477, 303, 0.815, 0.815, 0, 0, 0, 1.3, 26);
        this.instance_2.alpha = 0.578;

        // Capa 1
        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape_6.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape_6, this.instance_2, this.instance_1, this.instance, this.text_1, this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.CdP_Ampliacio_03 = function () {
        this.initialize();

        // Capa 4
        this.instance = new lib.CdP_Ampliacio_06();
        this.instance.setTransform(463.5, 302.1, 1.02, 1.02, 0, 0, 0, 475.1, 303.9);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-21.1, -7.8, 969.1, 620.2);


    (lib.IMG_06 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        mask.setTransform(160.6, 187.5);

        // Capa 2
        this.instance = new lib.CdP_Ampliacio_06();
        this.instance.setTransform(-22.3, 215, 0.71, 0.71, 0, 0, 0, 475, 303.9);

        this.instance.mask = mask;

        this.timeline.addTween(cjs.Tween.get(this.instance).to({x: 307.6}, 24).wait(1));

        // Capa 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        this.shape.setTransform(160.6, 187.5);

        this.shape.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).wait(200005));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-359.8, -0.8, 681, 431.9);


    (lib.IMG_03 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        mask.setTransform(160.6, 187.5);

        // Capa 5
        this.instance = new lib.CdP_Ampliacio_06();
        this.instance.setTransform(307, 185.6, 0.653, 0.653, 0, 0, 0, 475.1, 303.9);

        this.instance.mask = mask;

        this.timeline.addTween(cjs.Tween.get(this.instance).to({x: 47}, 24).wait(1));

        // Capa 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        this.shape.setTransform(160.6, 187.5);

        this.shape.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).wait(250000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-3.2, -12.8, 620.5, 397.1);


    (lib.popup_ampliar_06 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

     

        // Capa 4
        this.instance_1 = new lib.CdP_Ampliacio_06();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_03 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});


        // Capa 4
        this.instance_1 = new lib.CdP_Ampliacio_03();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX: 463.4, regY: 302.2, x: 463.4, y: 302.2, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-21.1, -7.8, 969.1, 620.2);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}