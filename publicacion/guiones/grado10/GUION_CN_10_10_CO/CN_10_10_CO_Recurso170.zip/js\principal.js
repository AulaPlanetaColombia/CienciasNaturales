(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
        titulo1(this, txt['titol']);
        this.txt_selecciona = new cjs.Text(txt['txt_selecciona'], "16px Arial");
        this.txt_selecciona.textAlign = "center";
        this.txt_selecciona.lineHeight = 16;
        this.txt_selecciona.lineWidth = 363;
        this.txt_selecciona.setTransform(483.7, 562.3);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCCCCC").s().p("AygCDIAAkEMAlBAAAIAAEEg");
        this.shape.setTransform(485.4, 570.8, 1.544, 1);



        this.btn_07 = new lib.btn_01();
        this.btn_07.setTransform(343.8, 143.2, 0.462, 0.366, 0, 0, 0, 108, 89.5);
        new cjs.ButtonHelper(this.btn_07, 0, 1, 2, false, new lib.btn_01(), 3);

        this.btn_08 = new lib.btn_01();
        this.btn_08.setTransform(488.4, 482.5, 0.603, 0.264, 0, 0, 0, 108, 89.5);
        new cjs.ButtonHelper(this.btn_08, 0, 1, 2, false, new lib.btn_01(), 3);

        this.btn_06 = new lib.btn_01();
        this.btn_06.setTransform(588, 131.4, 0.621, 0.21, 0, 0, 0, 108, 89.4);
        new cjs.ButtonHelper(this.btn_06, 0, 1, 2, false, new lib.btn_01(), 3);

        this.btn_05 = new lib.btn_01();
        this.btn_05.setTransform(334.5, 326.6, 0.366, 0.195, 0, 0, 0, 108, 89.4);
        new cjs.ButtonHelper(this.btn_05, 0, 1, 2, false, new lib.btn_01(), 3);

        this.btn_04 = new lib.btn_01();
        this.btn_04.setTransform(348.6, 273.7, 0.597, 0.385, 0, 0, 0, 108.1, 89.5);
        new cjs.ButtonHelper(this.btn_04, 0, 1, 2, false, new lib.btn_01(), 3);

        this.btn_03 = new lib.btn_01();
        this.btn_03.setTransform(579, 171.4, 0.704, 0.221, 0, 0, 0, 108, 89.4);
        new cjs.ButtonHelper(this.btn_03, 0, 1, 2, false, new lib.btn_01(), 3);

        this.btn_02 = new lib.btn_01();
        this.btn_02.setTransform(489, 422.1, 1, 0.313, 0, 0, 0, 108, 89.4);
        new cjs.ButtonHelper(this.btn_02, 0, 1, 2, false, new lib.btn_01(), 3);

        this.btn_01 = new lib.btn_01();
        this.btn_01.setTransform(563, 298.7, 1, 1, 0, 0, 0, 108, 89.5);
        new cjs.ButtonHelper(this.btn_01, 0, 1, 2, false, new lib.btn_01(), 3);

        this.btn_01.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.btn_08.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.btn_02.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
        this.btn_03.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
        this.btn_04.on("click", function (evt) {
            putStage(new lib.frame1_4());
        });
        this.btn_05.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });
        this.btn_06.on("click", function (evt) {
            putStage(new lib.frame1_6());
        });
        this.btn_07.on("click", function (evt) {
            putStage(new lib.frame1_7());
        });

        this.instance_1 = new lib.GTFQ_10_11_011();
        this.instance_1.setTransform(276, 105.2, 0.844, 0.844);

        this.addChild(this.instance_1, this.btn_01, this.btn_02, this.btn_03, this.btn_04, this.btn_05, this.btn_06, this.btn_08, this.btn_07, this.titulo, this.shape, this.txt_selecciona, this.logo);


    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_popup_01'], 1, 320);

        this.ampliar = new lib.btn_ampliarneg();
        this.ampliar.setTransform(361.3, 169.5);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_1b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("EgRAApLMAAAg6kMAu2AAAMAAAA6kg");
        mask.setTransform(191, 263.5);

        // Imatge
        this.instance_1 = new lib.mc_Ficha_01();
        this.instance_1.setTransform(382, 339.5, 1, 1, 0, 0, 0, 300, 187.5);

        this.instance_1.mask = mask;

        // Capa 4
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#91B7C6").s().p("EhKMAdXMAAAg6tMCUZAAAMAAAA6tg");
        this.shape.setTransform(475, 339.5, 1, 0.997);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape_1.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape_1, this.shape, this.instance_1, this.texto, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_1b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_01();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_2 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_popup_02'], 1, 350);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(432.3, 169.5);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_2b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.instance_1 = new lib.mc_Ficha_02();
        this.instance_1.setTransform(381, 339.5, 1, 1, 0, 0, 0, 300, 187.5);

        // Capa 4
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#E19481").s().p("EhKMAdXMAAAg6tMCUZAAAMAAAA6tg");
        this.shape.setTransform(475, 339.5, 1, 0.997);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape_1.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape_1, this.shape, this.instance_1, this.texto, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_2b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_02();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_3 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_popup_03'], 1, 290,-440,790);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(361.3, 169.5);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_3b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(2, 1, 1).p("AXX9MMAAAA6ZMgutAAAMAAAg6Zg");
        this.shape.setTransform(232, 339.5, 1.003, 1.003);

        // Mask (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("EgRAApLMAAAg6kMAu2AAAMAAAA6kg");
        mask.setTransform(191, 263.5);

        // Imatge
        this.instance_1 = new lib.mc_Ficha_03();
        this.instance_1.setTransform(382, 339.5, 1, 1, 0, 0, 0, 300, 187.5);

        this.instance_1.mask = mask;

        // Capa 4
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#D59CA3").s().p("EhKMAdXMAAAg6tMCUZAAAMAAAA6tg");
        this.shape_1.setTransform(475, 339.5, 1, 0.997);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape_2.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape_2, this.shape_1, this.shape, this.instance_1, this.texto, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_3b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_03();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_4 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_popup_04'], 1, 350);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(361.3, 169.5);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_4b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

       this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AXX9MMAAAA6ZMgutAAAMAAAg6Zg");
	this.shape.setTransform(232,339.5,1.003,1.003);

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgRAApLMAAAg6kMAu2AAAMAAAA6kg");
	mask.setTransform(191,263.5);

	// Imatge
	this.instance_1 = new lib.mc_Ficha_04();
	this.instance_1.setTransform(382,339.5,1,1,0,0,0,300,187.5);

	this.instance_1.mask = mask;

	// Capa 4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9CBA9D").s().p("EhKMAdXMAAAg6tMCUZAAAMAAAA6tg");
	this.shape_1.setTransform(475,339.5,1,0.997);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
	this.shape_2.setTransform(475,304,1.054,1.031);

        this.addChild(this.shape_2,this.shape_1, this.shape, this.instance_1, this.texto, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_4b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_04();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_4());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame1_5 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_popup_05'], 1, 350);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(361.3, 169.5);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_5b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

       // Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AXX9MMAAAA6ZMgutAAAMAAAg6Zg");
	this.shape.setTransform(232,339.5,1.003,1.003);

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgRAApLMAAAg6kMAu2AAAMAAAA6kg");
	mask.setTransform(191,263.5);

	// Imatge
	this.instance_1 = new lib.mc_Ficha_05();
	this.instance_1.setTransform(382,339.5,1,1,0,0,0,300,187.5);

	this.instance_1.mask = mask;

	// Capa 4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BA9ABA").s().p("EhKMAdXMAAAg6tMCUZAAAMAAAA6tg");
	this.shape_1.setTransform(475,339.5,1,0.997);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
	this.shape_2.setTransform(475,304,1.054,1.031);

        this.addChild(this.shape_2,this.shape_1, this.shape, this.instance_1, this.texto, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_5b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_05();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame1_6 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_popup_06'], 1, 350);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(361.3, 169.5);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_6b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

       // Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AXX9MMAAAA6ZMgutAAAMAAAg6Zg");
	this.shape.setTransform(232,339.5,1.003,1.003);

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgRAApLMAAAg6kMAu2AAAMAAAA6kg");
	mask.setTransform(191,263.5);

	// Imatge
	this.instance_1 = new lib.mc_Ficha_06();
	this.instance_1.setTransform(382,339.5,1,1,0,0,0,300,187.5);

	this.instance_1.mask = mask;

	// Capa 4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B6A798").s().p("EhKMAdXMAAAg6tMCUZAAAMAAAA6tg");
	this.shape_1.setTransform(475,339.5,1,0.997);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
	this.shape_2.setTransform(475,304,1.054,1.031);

        this.addChild(this.shape_2,this.shape_1, this.shape, this.instance_1, this.texto, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_6b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_06();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_6());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
   
    (lib.frame1_7 = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_popup_07'], 1, 350);

        this.ampliar = new lib.btn_ampliar();
        this.ampliar.setTransform(361.3, 169.5);
        new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

        this.ampliar.on("click", function (evt) {
            putStage(new lib.frame1_7b());
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

       this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AXX9MMAAAA6ZMgutAAAMAAAg6Zg");
	this.shape.setTransform(232,339.5,1.003,1.003);

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgRAApLMAAAg6kMAu2AAAMAAAA6kg");
	mask.setTransform(191,263.5);

	// Imatge
	this.instance_1 = new lib.mc_Ficha_07();
	this.instance_1.setTransform(382,339.5,1,1,0,0,0,300,187.5);

	this.instance_1.mask = mask;

	// Capa 4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A4ABDC").s().p("EhKMAdXMAAAg6tMCUZAAAMAAAA6tg");
	this.shape_1.setTransform(475,339.5,1,0.997);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
	this.shape_2.setTransform(475,304,1.054,1.031);

        this.addChild(this.shape_2,this.shape_1, this.shape, this.instance_1, this.texto, this.cerrar, this.ampliar, this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_7b = function () {
        this.initialize();
        clearTexts();
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);

        this.imagen = new lib.popup_ampliar_07();

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_7());
        });


        this.addChild(this.imagen, this.logo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
   
// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho, top,w) {
        top = top || -402;
        w = w || 730;
        width = w - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left", "texto");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
    (lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
    (lib.GTFQ_10_11_011 = function () {
        this.initialize(img.GTFQ_10_11_011);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 500, 500);


    (lib.GTFQ_10_11_012 = function () {
        this.initialize(img.GTFQ_10_11_012);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 500, 500);


    (lib.GTFQ_10_11_013 = function () {
        this.initialize(img.GTFQ_10_11_013);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1267, 730);


    (lib.GTFQ_10_11_014 = function () {
        this.initialize(img.GTFQ_10_11_014);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1700, 730);


    (lib.GTFQ_10_11_015 = function () {
        this.initialize(img.GTFQ_10_11_015);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1942, 730);


    (lib.GTFQ_10_11_016 = function () {
        this.initialize(img.GTFQ_10_11_016);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1825, 730);


    (lib.GTFQ_10_11_017 = function () {
        this.initialize(img.GTFQ_10_11_017);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 587, 730);


    (lib.pautas950x608nuevosarreglos = function () {
        this.initialize(img.pautas950x608nuevosarreglos);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.shutterstock_74170765 = function () {
        this.initialize(img.shutterstock_74170765);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1168, 730);

    (lib.mc_Ampliar_07 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.GTFQ_10_11_017();
        this.instance.setTransform(233.5, 2.7, 0.817, 0.817);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.mc_Ampliar_06 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.GTFQ_10_11_016();
        this.instance.setTransform(90, 119.7, 0.422, 0.422);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.mc_Ampliar_05 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.GTFQ_10_11_015();
        this.instance.setTransform(-11.3, 96.7, 0.501, 0.501);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-11.3, 0, 973.6, 608);


    (lib.mc_Ampliar_04 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.GTFQ_10_11_014();
        this.instance.setTransform(-34.9, 79.7, 0.6, 0.6);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-34.9, 0, 1020, 608);


    (lib.mc_Ampliar_03 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.GTFQ_10_11_013();
        this.instance.setTransform(95.1, 79.7, 0.6, 0.6);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.mc_Ampliar_02 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.GTFQ_10_11_012();
        this.instance.setTransform(225.4, 44.7);

        // Capa 2
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.mc_Ampliar_01 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.shutterstock_74170765();
        this.instance.setTransform(125.1, 79.7, 0.6, 0.6);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhGYAuEMAAAhcHMCMxAAAMAAABcHg");
        this.shape.setTransform(475, 304, 1.054, 1.031);

        this.addChild(this.shape, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.mc_Ficha_07_int = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.GTFQ_10_11_017();
        this.instance.setTransform(99, 0, 0.65, 0.65);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(99, 0, 381.3, 474.2);


    (lib.mc_Ficha_06_int = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.GTFQ_10_11_016();
        this.instance.setTransform(99, 0, 0.65, 0.65);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(99, 0, 1185.5, 474.2);


    (lib.mc_Ficha_05_int = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.GTFQ_10_11_015();
        this.instance.setTransform(0, 0, 0.514, 0.514);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 997.6, 375);


    (lib.mc_Ficha_04_int = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.GTFQ_10_11_014();
        this.instance.setTransform(0, 0, 0.514, 0.514);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 873.3, 375);


    (lib.mc_Ficha_03_int = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.GTFQ_10_11_013();
        this.instance.setTransform(0, 0, 0.514, 0.514);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 650.9, 375);


    (lib.mc_Ficha_02_int = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.GTFQ_10_11_012();
        this.instance.setTransform(0, 0, 0.75, 0.75);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 375, 375);


    (lib.mc_Ficha_01_int = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.shutterstock_74170765();
        this.instance.setTransform(0, 0, 0.514, 0.514);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 600, 375);


    (lib.btn_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.498)").s().p("Aw3N+IAA77MAhuAAAIAAb7g");
        this.shape.setTransform(108, 89.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(0,255,255,0.498)").s().p("Aw3N+IAA77MAhuAAAIAAb7g");
        this.shape_1.setTransform(108, 89.5);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 1).to({state: []}, 1).to({state: [{t: this.shape_1}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);


    (lib.popup_ampliar_07 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance_1 = new lib.mc_Ampliar_07();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_06 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance_1 = new lib.mc_Ampliar_06();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_05 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance_1 = new lib.mc_Ampliar_05();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX: 475.5, regY: 304, x: 475.5, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-11.3, 0, 973.6, 608);


    (lib.popup_ampliar_04 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance_1 = new lib.mc_Ampliar_04();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-34.9, 0, 1020, 608);


    (lib.popup_ampliar_03 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance_1 = new lib.mc_Ampliar_03();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance_1 = new lib.mc_Ampliar_02();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.popup_ampliar_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 4
        this.instance_1 = new lib.mc_Ampliar_01();
        this.instance_1.setTransform(475, 303.9, 1, 1, 0, 0, 0, 475, 303.9);
        this.instance_1.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY: 304, y: 304, alpha: 0.071}, 0).wait(1).to({alpha: 0.143}, 0).wait(1).to({alpha: 0.214}, 0).wait(1).to({alpha: 0.286}, 0).wait(1).to({alpha: 0.357}, 0).wait(1).to({alpha: 0.429}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.571}, 0).wait(1).to({alpha: 0.643}, 0).wait(1).to({alpha: 0.714}, 0).wait(1).to({alpha: 0.786}, 0).wait(1).to({alpha: 0.857}, 0).wait(1).to({alpha: 0.929}, 0).wait(1).to({alpha: 1}, 0).wait(10000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.mc_Ficha_07 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.instance = new lib.mc_Ficha_07_int();
        this.instance.setTransform(163, 140.5, 0.861, 0.861, 0, 0, 0, 300, 187.5);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX: 289.7, regY: 237.1, x: 154.2, y: 183.3, alpha: 0.063}, 0).wait(1).to({alpha: 0.125}, 0).wait(1).to({alpha: 0.188}, 0).wait(1).to({alpha: 0.25}, 0).wait(1).to({alpha: 0.313}, 0).wait(1).to({alpha: 0.375}, 0).wait(1).to({alpha: 0.438}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.563}, 0).wait(1).to({alpha: 0.625}, 0).wait(1).to({alpha: 0.688}, 0).wait(1).to({alpha: 0.75}, 0).wait(1).to({alpha: 0.813}, 0).wait(1).to({alpha: 0.875}, 0).wait(1).to({alpha: 0.938}, 0).wait(1).to({alpha: 1}, 0).wait(12000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.1, -20.9, 328.5, 408.5);


    (lib.mc_Ficha_06 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.instance = new lib.mc_Ficha_06_int();
        this.instance.setTransform(175, 187.5, 1, 1, 0, 0, 0, 300, 187.5);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX: 691.8, regY: 237.1, x: 566.8, y: 237.1, alpha: 0.063}, 0).wait(1).to({alpha: 0.125}, 0).wait(1).to({alpha: 0.188}, 0).wait(1).to({alpha: 0.25}, 0).wait(1).to({alpha: 0.313}, 0).wait(1).to({alpha: 0.375}, 0).wait(1).to({alpha: 0.438}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.563}, 0).wait(1).to({alpha: 0.625}, 0).wait(1).to({alpha: 0.688}, 0).wait(1).to({alpha: 0.75}, 0).wait(1).to({alpha: 0.813}, 0).wait(1).to({alpha: 0.875}, 0).wait(1).to({alpha: 0.938}, 0).wait(1).to({alpha: 1}, 0).wait(11).wait(1).to({x: 555.7}, 0).wait(1).to({x: 544.5}, 0).wait(1).to({x: 533.3}, 0).wait(1).to({x: 522.1}, 0).wait(1).to({x: 510.9}, 0).wait(1).to({x: 499.7}, 0).wait(1).to({x: 488.5}, 0).wait(1).to({x: 477.3}, 0).wait(1).to({x: 466.1}, 0).wait(1).to({x: 454.9}, 0).wait(1).to({x: 443.8}, 0).wait(1).to({x: 432.6}, 0).wait(1).to({x: 421.4}, 0).wait(1).to({x: 410.2}, 0).wait(1).to({x: 399}, 0).wait(1).to({x: 387.8}, 0).wait(1).to({x: 376.6}, 0).wait(1).to({x: 365.4}, 0).wait(1).to({x: 354.2}, 0).wait(1).to({x: 343}, 0).wait(1).to({x: 331.8}, 0).wait(1).to({x: 320.7}, 0).wait(1).to({x: 309.5}, 0).wait(1).to({x: 298.3}, 0).wait(1).to({x: 287.1}, 0).wait(1).to({x: 275.9}, 0).wait(1).to({x: 264.7}, 0).wait(1).to({x: 253.5}, 0).wait(1).to({x: 242.3}, 0).wait(1).to({x: 231.1}, 0).wait(1).to({x: 219.9}, 0).wait(1).to({x: 208.8}, 0).wait(1).to({x: 197.6}, 0).wait(1).to({x: 186.4}, 0).wait(1).to({x: 175.2}, 0).wait(1).to({x: 164}, 0).wait(1).to({x: 152.8}, 0).wait(18).wait(1).to({x: 142.7}, 0).wait(1).to({x: 132.6}, 0).wait(1).to({x: 122.6}, 0).wait(1).to({x: 112.5}, 0).wait(1).to({x: 102.4}, 0).wait(1).to({x: 92.3}, 0).wait(1).to({x: 82.3}, 0).wait(1).to({x: 72.2}, 0).wait(1).to({x: 62.1}, 0).wait(1).to({x: 52}, 0).wait(1).to({x: 42}, 0).wait(1).to({x: 31.9}, 0).wait(1).to({x: 21.8}, 0).wait(1).to({x: 11.7}, 0).wait(1).to({x: 1.7}, 0).wait(1).to({x: -8.2}, 0).wait(1).to({x: -18.3}, 0).wait(1).to({x: -28.4}, 0).wait(1).to({x: -38.4}, 0).wait(1).to({x: -48.5}, 0).wait(1).to({x: -58.6}, 0).wait(1).to({x: -68.7}, 0).wait(1).to({x: -78.7}, 0).wait(1).to({x: -88.8}, 0).wait(1).to({x: -98.9}, 0).wait(1).to({x: -109}, 0).wait(1).to({x: -119}, 0).wait(1).to({x: -129.1}, 0).wait(1).to({x: -139.2}, 0).wait(1).to({x: -149.3}, 0).wait(1).to({x: -159.3}, 0).wait(1).to({x: -169.4}, 0).wait(1).to({x: -179.5}, 0).wait(1).to({x: -189.6}, 0).wait(1).to({x: -199.6}, 0).wait(1).to({x: -209.7}, 0).wait(1).to({x: -219.8}, 0).wait(1).to({x: -229.9}, 0).wait(1).to({x: -239.9}, 0).wait(1).to({x: -250}, 0).wait(10000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-25.9, 0, 1185.5, 474.2);


    (lib.mc_Ficha_05 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.instance = new lib.mc_Ficha_05_int();
        this.instance.setTransform(175, 187.5, 1, 1, 0, 0, 0, 300, 187.5);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX: 498.8, x: 373.8, alpha: 0.063}, 0).wait(1).to({alpha: 0.125}, 0).wait(1).to({alpha: 0.188}, 0).wait(1).to({alpha: 0.25}, 0).wait(1).to({alpha: 0.313}, 0).wait(1).to({alpha: 0.375}, 0).wait(1).to({alpha: 0.438}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.563}, 0).wait(1).to({alpha: 0.625}, 0).wait(1).to({alpha: 0.688}, 0).wait(1).to({alpha: 0.75}, 0).wait(1).to({alpha: 0.813}, 0).wait(1).to({alpha: 0.875}, 0).wait(1).to({alpha: 0.938}, 0).wait(1).to({alpha: 1}, 0).wait(11).wait(1).to({x: 362.2}, 0).wait(1).to({x: 350.5}, 0).wait(1).to({x: 338.8}, 0).wait(1).to({x: 327.1}, 0).wait(1).to({x: 315.5}, 0).wait(1).to({x: 303.8}, 0).wait(1).to({x: 292.1}, 0).wait(1).to({x: 280.4}, 0).wait(1).to({x: 268.8}, 0).wait(1).to({x: 257.1}, 0).wait(1).to({x: 245.4}, 0).wait(1).to({x: 233.7}, 0).wait(1).to({x: 222}, 0).wait(1).to({x: 210.4}, 0).wait(1).to({x: 198.7}, 0).wait(1).to({x: 187}, 0).wait(1).to({x: 175.3}, 0).wait(1).to({x: 163.7}, 0).wait(1).to({x: 152}, 0).wait(1).to({x: 140.3}, 0).wait(1).to({x: 128.6}, 0).wait(1).to({x: 117}, 0).wait(1).to({x: 105.3}, 0).wait(1).to({x: 93.6}, 0).wait(1).to({x: 81.9}, 0).wait(1).to({x: 70.2}, 0).wait(1).to({x: 58.6}, 0).wait(1).to({x: 46.9}, 0).wait(1).to({x: 35.2}, 0).wait(1).to({x: 23.5}, 0).wait(1).to({x: 11.9}, 0).wait(1).to({x: 0.2}, 0).wait(1).to({x: -11.3}, 0).wait(1).to({x: -23}, 0).wait(1).to({x: -34.6}, 0).wait(1).to({x: -46.3}, 0).wait(1).to({x: -58}, 0).wait(10000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-124.9, 0, 997.6, 375);


    (lib.mc_Ficha_04 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.instance = new lib.mc_Ficha_04_int();
        this.instance.setTransform(237, 187.5, 1, 1, 0, 0, 0, 300, 187.5);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX: 436.6, x: 373.6, alpha: 0.063}, 0).wait(1).to({alpha: 0.125}, 0).wait(1).to({alpha: 0.188}, 0).wait(1).to({alpha: 0.25}, 0).wait(1).to({alpha: 0.313}, 0).wait(1).to({alpha: 0.375}, 0).wait(1).to({alpha: 0.438}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.563}, 0).wait(1).to({alpha: 0.625}, 0).wait(1).to({alpha: 0.688}, 0).wait(1).to({alpha: 0.75}, 0).wait(1).to({alpha: 0.813}, 0).wait(1).to({alpha: 0.875}, 0).wait(1).to({alpha: 0.938}, 0).wait(1).to({alpha: 1}, 0).wait(11).wait(1).to({x: 367.5}, 0).wait(1).to({x: 361.3}, 0).wait(1).to({x: 355.2}, 0).wait(1).to({x: 349}, 0).wait(1).to({x: 342.8}, 0).wait(1).to({x: 336.7}, 0).wait(1).to({x: 330.5}, 0).wait(1).to({x: 324.3}, 0).wait(1).to({x: 318.2}, 0).wait(1).to({x: 312}, 0).wait(1).to({x: 305.9}, 0).wait(1).to({x: 299.7}, 0).wait(1).to({x: 293.5}, 0).wait(1).to({x: 287.4}, 0).wait(1).to({x: 281.2}, 0).wait(1).to({x: 275}, 0).wait(1).to({x: 268.9}, 0).wait(1).to({x: 262.7}, 0).wait(1).to({x: 256.5}, 0).wait(1).to({x: 250.4}, 0).wait(1).to({x: 244.2}, 0).wait(1).to({x: 238.1}, 0).wait(1).to({x: 231.9}, 0).wait(1).to({x: 225.7}, 0).wait(1).to({x: 219.6}, 0).wait(1).to({x: 213.4}, 0).wait(1).to({x: 207.2}, 0).wait(1).to({x: 201.1}, 0).wait(1).to({x: 194.9}, 0).wait(1).to({x: 188.7}, 0).wait(1).to({x: 182.6}, 0).wait(1).to({x: 176.4}, 0).wait(1).to({x: 170.3}, 0).wait(1).to({x: 164.1}, 0).wait(1).to({x: 157.9}, 0).wait(1).to({x: 151.8}, 0).wait(1).to({x: 145.6}, 0).wait(16).wait(1).to({x: 139}, 0).wait(1).to({x: 132.5}, 0).wait(1).to({x: 125.9}, 0).wait(1).to({x: 119.4}, 0).wait(1).to({x: 112.8}, 0).wait(1).to({x: 106.3}, 0).wait(1).to({x: 99.7}, 0).wait(1).to({x: 93.2}, 0).wait(1).to({x: 86.6}, 0).wait(1).to({x: 80}, 0).wait(1).to({x: 73.5}, 0).wait(1).to({x: 66.9}, 0).wait(1).to({x: 60.4}, 0).wait(1).to({x: 53.8}, 0).wait(1).to({x: 47.3}, 0).wait(1).to({x: 40.7}, 0).wait(1).to({x: 34.2}, 0).wait(1).to({x: 27.6}, 0).wait(1).to({x: 21}, 0).wait(1).to({x: 14.5}, 0).wait(1).to({x: 7.9}, 0).wait(1).to({x: 1.4}, 0).wait(1).to({x: -5}, 0).wait(1).to({x: -11.5}, 0).wait(1).to({x: -18.1}, 0).wait(1).to({x: -24.6}, 0).wait(1).to({x: -31.2}, 0).wait(1).to({x: -37.8}, 0).wait(1).to({x: -44.3}, 0).wait(1).to({x: -50.9}, 0).wait(1).to({x: -57.4}, 0).wait(1).to({x: -64}, 0).wait(1).to({x: -70.5}, 0).wait(1).to({x: -77.1}, 0).wait(1).to({x: -83.6}, 0).wait(1).to({x: -90.2}, 0).wait(10000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-62.9, 0, 873.3, 375);


    (lib.mc_Ficha_03 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.instance = new lib.mc_Ficha_03_int();
        this.instance.setTransform(300, 187.5, 1, 1, 0, 0, 0, 300, 187.5);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX: 325.4, x: 325.4, alpha: 0.063}, 0).wait(1).to({alpha: 0.125}, 0).wait(1).to({alpha: 0.188}, 0).wait(1).to({alpha: 0.25}, 0).wait(1).to({alpha: 0.313}, 0).wait(1).to({alpha: 0.375}, 0).wait(1).to({alpha: 0.438}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.563}, 0).wait(1).to({alpha: 0.625}, 0).wait(1).to({alpha: 0.688}, 0).wait(1).to({alpha: 0.75}, 0).wait(1).to({alpha: 0.813}, 0).wait(1).to({alpha: 0.875}, 0).wait(1).to({alpha: 0.938}, 0).wait(1).to({alpha: 1}, 0).wait(11).wait(1).to({x: 316.4}, 0).wait(1).to({x: 307.3}, 0).wait(1).to({x: 298.2}, 0).wait(1).to({x: 289.1}, 0).wait(1).to({x: 280}, 0).wait(1).to({x: 271}, 0).wait(1).to({x: 261.9}, 0).wait(1).to({x: 252.8}, 0).wait(1).to({x: 243.7}, 0).wait(1).to({x: 234.6}, 0).wait(1).to({x: 225.5}, 0).wait(1).to({x: 216.5}, 0).wait(1).to({x: 207.4}, 0).wait(1).to({x: 198.3}, 0).wait(1).to({x: 189.2}, 0).wait(1).to({x: 180.1}, 0).wait(1).to({x: 171.1}, 0).wait(1).to({x: 162}, 0).wait(1).to({x: 152.9}, 0).wait(1).to({x: 143.8}, 0).wait(1).to({x: 134.7}, 0).wait(1).to({x: 125.7}, 0).wait(1).to({x: 116.6}, 0).wait(1).to({x: 107.5}, 0).wait(1).to({x: 98.4}, 0).wait(1).to({x: 89.3}, 0).wait(1).to({x: 80.3}, 0).wait(1).to({x: 71.2}, 0).wait(1).to({x: 62.1}, 0).wait(1).to({x: 53}, 0).wait(1).to({x: 43.9}, 0).wait(1).to({x: 34.9}, 0).wait(1).to({x: 25.8}, 0).wait(1).to({x: 16.7}, 0).wait(1).to({x: 7.6}, 0).wait(1).to({x: -1.3}, 0).wait(1).to({x: -10.4}, 0).wait(1000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 650.9, 375);


    (lib.mc_Ficha_02 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.mc_Ficha_02_int();
        this.instance.setTransform(300, 187.5, 1, 1, 0, 0, 0, 300, 187.5);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 375, 375);


    (lib.mc_Ficha_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.instance = new lib.mc_Ficha_01_int();
        this.instance.setTransform(300, 187.5, 1, 1, 0, 0, 0, 300, 187.5);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha: 0.063}, 0).wait(1).to({alpha: 0.125}, 0).wait(1).to({alpha: 0.188}, 0).wait(1).to({alpha: 0.25}, 0).wait(1).to({alpha: 0.313}, 0).wait(1).to({alpha: 0.375}, 0).wait(1).to({alpha: 0.438}, 0).wait(1).to({alpha: 0.5}, 0).wait(1).to({alpha: 0.563}, 0).wait(1).to({alpha: 0.625}, 0).wait(1).to({alpha: 0.688}, 0).wait(1).to({alpha: 0.75}, 0).wait(1).to({alpha: 0.813}, 0).wait(1).to({alpha: 0.875}, 0).wait(1).to({alpha: 0.938}, 0).wait(1).to({alpha: 1}, 0).wait(11).wait(1).to({x: 292}, 0).wait(1).to({x: 284}, 0).wait(1).to({x: 276}, 0).wait(1).to({x: 267.9}, 0).wait(1).to({x: 259.9}, 0).wait(1).to({x: 251.9}, 0).wait(1).to({x: 243.9}, 0).wait(1).to({x: 235.8}, 0).wait(1).to({x: 227.8}, 0).wait(1).to({x: 219.8}, 0).wait(1).to({x: 211.7}, 0).wait(1).to({x: 203.7}, 0).wait(1).to({x: 195.7}, 0).wait(1).to({x: 187.7}, 0).wait(1).to({x: 179.6}, 0).wait(1).to({x: 171.6}, 0).wait(1).to({x: 163.6}, 0).wait(1).to({x: 155.6}, 0).wait(1).to({x: 147.5}, 0).wait(1).to({x: 139.5}, 0).wait(1).to({x: 131.5}, 0).wait(1).to({x: 123.5}, 0).wait(1).to({x: 115.4}, 0).wait(1).to({x: 107.4}, 0).wait(1).to({x: 99.4}, 0).wait(1).to({x: 91.3}, 0).wait(1).to({x: 83.3}, 0).wait(1).to({x: 75.3}, 0).wait(1).to({x: 67.3}, 0).wait(1).to({x: 59.2}, 0).wait(1).to({x: 51.2}, 0).wait(1).to({x: 43.2}, 0).wait(1).to({x: 35.2}, 0).wait(1).to({x: 27.1}, 0).wait(1).to({x: 19.1}, 0).wait(1).to({x: 11.1}, 0).wait(1).to({x: 3}, 0).wait(1000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 600, 375);
    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}