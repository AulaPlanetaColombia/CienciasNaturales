window.onresize = resize;
var scale 	= 1;
var mgLeft	= 0;
var mgTop	= 0;
var nVector = 0;
var centerPressed = false;
var canvas;
var context;
var Ax = 301;
var Ay = 312;
var endX = new Array(3);
var endY = new Array(3);
var line, isDown, auxLine1, auxLine2, sumLine;
var endPointsX = new Array(4);
var endPointsY = new Array(4);
var lastX;
var lastY;

var balls;
var maxV = 5;
var totalBalls1;
var totalBalls2;
var totalMolecules;
var speedFactor;

var  slider1, slider2, slider3;

$(document).ready(function(){
	resize();
	initialize();
	if (window.navigator && window.navigator.userAgent.indexOf('534.30') > 0) {

    // Tweak the canvas opacity, causing it to redraw
    $('canvas').css('opacity', '0.99');

    // Set the canvas opacity back to normal after 5ms
    setTimeout(function() {
        $('canvas').css('opacity', '1');
    }, 5);

}
});

function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		//apply margin left
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
		//apply margin top
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}

function initialize(){
	speedFactor = 0.5;
	maxV = 5;
	totalMolecules=0;
	totalBalls1=0;
	totalBalls2=5;
	slider1 = $('#sld1');
	slider1.val(0);
	$('#r1').html(0);
	$('#r2').html(5);
	$('#r3').html(0);
	$('#r4').html(50);
	slider1.on("change",function(){
		if(totalBalls1>0 && totalBalls1>=$(this).val()){
			
			for(var ii = 0;ii<(totalBalls1-$(this).val()); ii++){
				var removeBall = true;
				for(var i=0; i<balls.length;i++){
					if(balls[i].type == 1 && removeBall== true){
						var index = balls.indexOf(balls[i]);
						if (index > -1) {
							balls.splice(index, 1);
							removeBall = false;
						}
					}
				}
			}
			totalBalls1 = $(this).val();
		}else{
			var nTot = $(this).val()-totalBalls1;
			for(var i=0;i<(nTot);i++){
				balls.addABall(1);
				totalBalls1++;
			}
		}
		$('#r1').html($(this).val());
		
	});
	slider1.on("input", function(){   
		$('#r1').html($(this).val());
	
	});

	slider2 = $('#sld2');
	slider2.val(5);
	slider2.on("change",function(){
		if(totalBalls2>0 && totalBalls2>=$(this).val()){
			
			for(var ii = 0;ii<(totalBalls2-$(this).val()); ii++){
				var removeBall = true;
				for(var i=0; i<balls.length;i++){
					if(balls[i].type == 2 && removeBall == true){
						var index = balls.indexOf(balls[i]);
						if (index > -1) {
							balls.splice(index, 1);
							removeBall = false;
						}
					}
				}
			}
			totalBalls2 = $(this).val();
		}else{
			var nTot = $(this).val()-totalBalls2;	
			for(var i=0;i<(nTot);i++){
				balls.addABall(2);
				totalBalls2++;
			}
		}
		$('#r2').html($(this).val());
	});
	slider2.on("input", function(){   
		$('#r2').html($(this).val());
	
	});

	slider3 = $('#sld3');
	slider3.val(50);
	slider3.on("change",function(){
		maxV = 3+$(this).val()/10;
		balls.moveAgain();
		$('#r4').html($(this).val());

	});
	/*
	slider3.on("input", function(){
		$('#r4').html($(this).val());
	});
	*/
	
	slider1.attr("type","range");
	slider2.attr("type","range");
	slider3.attr("type","range");
	
	(function() {
		$('#ballsCanvas').css("width","430px");
		$('#ballsCanvas').css("height","306px");
		
		var i, canvas, ctx, w, h, intervalID;
		canvas = $('#ballsCanvas')[0];
		ctx = canvas.getContext("2d");
		w = canvas.width;
		h = canvas.height;
		var drawFrame = (function(ctx) {
			return function() {
				ctx.strokeStyle = 'DarkGrey';
				ctx.strokeRect(0.5, 0.5, w - 1, h - 1);
			};
		})(ctx);
		var getBalls = function() {
			var draw = function(ctx) {
				var i, b;
				for (i = 0; i < this.length; i += 1) {
					b = this[i];
					var x = 100,
					y = 75,
					// Radii of the white glow.
					innerRadius = 3,
					outerRadius = 15,
					// Radius of the entire circle.
					radius = 60;
					var gradient = ctx.createRadialGradient(b.center.x, b.center.y, innerRadius, b.center.x, b.center.y, outerRadius);
					gradient.addColorStop(0, 'white');
					if(b.type == 1){
						gradient.addColorStop(1, '#43A5D8');
					}else if(b.type == 2){
						gradient.addColorStop(1, '#DA5053');
					}else if(b.type == 3){
						gradient.addColorStop(1, '#cccccc');
					}
					
					if(b.type == 1 || b.type == 2){
						ctx.strokeStyle = 'transparent';
						ctx.fillStyle = gradient;
						ctx.beginPath();
						ctx.arc(b.center.x, b.center.y, b.radius, 0, Math.PI * 2, true);
						ctx.fill();
						ctx.stroke();	
					}else{
						ctx.strokeStyle = 'transparent';
						if(b.drawSplash){
							var gradientBack = ctx.createRadialGradient(b.center.x+5, b.center.y+2, innerRadius+5, b.center.x+5, b.center.y+2, outerRadius+10);
							gradientBack.addColorStop(0, '#FFE623');
							gradientBack.addColorStop(1, 'white');
							ctx.fillStyle = gradientBack;
							ctx.beginPath();
							ctx.arc(b.center.x+5, b.center.y+2, 25, 0, Math.PI * 2, true);
							ctx.fill();
							ctx.stroke();
							b.nSplash--;
							if(b.nSplash<0){
								b.drawSplash = false;
							}
						}
						var gradient1 = ctx.createRadialGradient(b.center.x, b.center.y, innerRadius, b.center.x, b.center.y, outerRadius);
						gradient1.addColorStop(0, 'white');
						gradient1.addColorStop(1, '#DE6567');
						ctx.fillStyle = gradient1;
						ctx.beginPath();
						ctx.arc(b.center.x, b.center.y, 13, 0, Math.PI * 2, true);
						ctx.fill();
						ctx.stroke();
						var gradient2 = ctx.createRadialGradient(b.center.x+10, b.center.y+5, innerRadius, b.center.x+10, b.center.y+5, outerRadius);
						gradient2.addColorStop(0, 'white');
						gradient2.addColorStop(1, '#81BFE2');
						ctx.fillStyle = gradient2;
						ctx.beginPath();
						ctx.arc(b.center.x+10, b.center.y+5, 13, 0, Math.PI * 2, true);
						ctx.fill();
						ctx.stroke();
					}
						
				}
			};
			var move = function() {
				var i, b;
				for (i = 0; i < this.length; i += 1) {
					b = this[i];
					if (b.center.x + b.radius >= w || b.center.x - b.radius <= 0) {
						b.center.x += 4*b.velocity.x;
					}else{
						b.center.x += b.velocity.x;
					}
					if (b.center.y + b.radius >= h || b.center.y - b.radius <= 0) {
						b.center.y += 4*b.velocity.y;
					}else{
						b.center.y += b.velocity.y;
					}
					
					
				}
			};
			var isCollision = function(b, c) {
				var dx = b.center.x - c.center.x;
				var dy = b.center.y - c.center.y;
				var dist = Math.sqrt(dx * dx + dy * dy);
				if (dist < b.radius + c.radius) {
					return true;
				}
				return false;
			};

			// http://en.m.wikipedia.org/wiki/Elastic_collision
			// http://en.m.wikipedia.org/wiki/Dot_product
			var resolveCollision = function(b, c) {
				if((b.type == 1 && c.type == 2) || (b.type == 2 && c.type == 1)){
					var startx = parseInt(b.center.x);
					var starty = parseInt(b.center.y);
					var speedx = parseInt(b.velocity.x);
					var speedy = parseInt(b.velocity.y);
					
					var indexb = balls.indexOf(b);
					if (indexb > -1) {
						balls.splice(indexb, 1);
					}
					var indexc = balls.indexOf(c);
					if (indexc > -1) {
						balls.splice(indexc, 1);
					}
					var newVal1 = 0;
					var newVal2 = 0;
					if(slider1.val()>0){
						newVal1 = slider1.val()-1;
					}
					if(slider2.val()>0){
						newVal2 = slider2.val()-1;
					}
					
					slider1.val(newVal1);
					slider2.val(newVal2);
					
					
					totalBalls1--;
					totalBalls2--;
					$('#r1').html(totalBalls1);	
					$('#r2').html(totalBalls2);	
					totalMolecules++;
					$('#r3').html(totalMolecules);					
					balls.addABall(3,startx,starty,speedx,speedy,true);
				}else{
					var vector = function(p1, p2) {
						return {
							x: p1.x - p2.x,
							y: p1.y - p2.y
						};
					};
					var length = function(v) {
						return Math.sqrt(v.x * v.x + v.y * v.y);
					};
					var dot = function(v1, v2) {
						return v1.x * v2.x + v1.y + v2.y;
					};
					var normalize = function(v) {
						var len = length(v);
						return {
							x: v.x / len,
							y: v.y / len
						};
					};

					var dn = vector(b.center, c.center);

					// The distance between the balls
					var delta = length(dn);

					// The normal vector of the collision plane
					dn = normalize(dn);

					// The tangential vector of the collision plane
					var dt = {
						x: dn.y,
						y: -dn.x
					};

					// avoid division by zero
					if (delta === 0) {
						c.center.x += 0.01;
					}

					//the masses of the two balls
					var m1 = b.mass;
					var m2 = c.mass;
					var M = m1 + m2;

					// minimum translation distance to push balls apart
					var mt = {
						x: dn.x * (b.radius + c.radius - delta),
						y: dn.y * (b.radius + c.radius - delta)
					};

					// push the balls apart proportional to their mass
					b.center = {
						x: b.center.x + mt.x * m2 / M,
						y: b.center.y + mt.y * m2 / M
					};

					c.center = {
						x: c.center.x - mt.x * m1 / M,
						y: c.center.y - mt.y * m1 / M
					};

					// the velocity vectors of the balls before the collision
					var v1 = b.velocity;
					var v2 = c.velocity;

					// split the velocity vector of the first ball into a normal and a tangential
					// component in respect of the collision plane
					var v1n = {
						x: dn.x * dot(v1, dn),
						y: dn.y * dot(v1, dn)
					};
					
					if(v1n.x > maxV){
						v1n.x = maxV;
					}
					if(v1n.y > maxV){
						v1n.y = maxV;
					}

					var v1t = {
						x: dt.x * dot(v1, dt),
						y: dt.x * dot(v1, dt)
					};
					if(v1t.x > maxV){
						v1t.x = maxV;
					}
					if(v1t.y > maxV){
						v1t.y = maxV;
					}

					// split the velocity vector of the second ball into a normal and a tangential
					// component in respect of the collision plane
					var v2n = {
						x: dt.x * dot(v1, dt),
						y: dn.y * dot(v2, dn)
					};
					if(v2n.x > maxV){
						v2n.x = maxV;
					}
					if(v2n.y > maxV){
						v2n.y = maxV;
					}
					var v2t = {
						x: dt.x * dot(v2, dt),
						y: dt.y * dot(v2, dt)
					};
					if(v2t.x > maxV){
						v2t.x = maxV;
					}
					if(v2t.y > maxV){
						v2t.y = maxV;
					}

					// calculate new velocity vectors of the balls, the tangential component stays
					// the same, the normal component changes analog to the  1-Dimensional case
					b.velocity = {
						x: v1t.x + dn.x * ((m1 - m2) / M * length(v1n) + 2 * m2 / M * length(v2n)),
						y: v1t.y + dn.y * ((m1 - m2) / M * length(v1n) + 2 * m2 / M * length(v2n))
					};
					c.velocity = {
						x: v2t.x - dn.x * ((m2 - m1) / M * length(v2n) + 2 * m1 / M * length(v1n)),
						y: v2t.y - dn.y * ((m2 - m1) / M * length(v2n) + 2 * m1 / M * length(v1n))
					};
				}
			};
			
			var moveAgain = function() {
				var i, j, b, c, tx, ty;
				for (i = 0; i < this.length; i += 1) {
					b = this[i];
					b.velocity.x = (-maxV + Math.random() * maxV);
					b.velocity.y = (-maxV + Math.random() * maxV);
				}			
			};

			var applyForce = function() {
				var i, j, b, c, tx, ty;
				for (i = 0; i < this.length; i += 1) {
					b = this[i];
					for (j = i + 1; j < this.length; j += 1) {
						c = this[j];
						if (isCollision(b, c)) {
							resolveCollision(b, c);
						}
					}
					if (b.center.x + b.radius >= w || b.center.x - b.radius <= 0) {
						b.velocity.x = -b.velocity.x;
					}
					if (b.center.y + b.radius >= h || b.center.y - b.radius <= 0) {
						b.velocity.y = -b.velocity.y;
					}
				}
			};

			var addABall = function(type,x,y,speedx,speedy,drawSplash) {
				var nx,ny;
				var dSplash = false;
				if(drawSplash){
					dSplash = drawSplash;
				}
				if(parseInt(x)){
					nx = x;
					ny = y;
					sx = speedx;
					sy = speedy;
				}else{
					nx = w / 4 + Math.random() * w / 2,
					ny = h / 4 + Math.random() * w / 2
					sx = (-maxV + Math.random() * maxV);
					sy = (-maxV + Math.random() * maxV);
				}
				this.push({
					radius: 15,
					mass: 50,
					center: {
						x: nx,
						y: ny
					},
					velocity: {
						x: sx,
						y: sy
					},
					startx:	x,
					starty: y,
					type:	type,
					drawSplash: dSplash,
					nSplash:	5
				});
			};
			var balls = [];
			balls.move = move;
			balls.draw = draw;
			balls.applyForce = applyForce;
			balls.addABall = addABall;
			balls.moveAgain = moveAgain;
			return balls;
		};
		balls = getBalls();
		for (i = 0; i < 5; i += 1) {
			balls.addABall(2);
		}
		intervalID = setInterval(function() {
			balls.applyForce();
			balls.move();
			ctx.clearRect(0, 0, w, h);
			drawFrame();
			balls.draw(ctx);
		}, 33);

	})();
}

function iniciar(){
	balls.addABall(1);
	if(!iniciat){
		iniciat = true;
	}
}

function reiniciar(){
//balls.addABall(2);
	initialize();
}