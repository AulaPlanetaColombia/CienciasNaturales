window.onresize = resize;
var scale 	= 1;
var iniciat;

var maxDrag=145;
var minDrag=0;

var c;
var ctx;
var m1=38;
var m2=25;
var scaleM1=1;
var scaleM2=1;
var sizeLeft=203;
var sizeRight=203;
var m1Anterior;
var m2Anterior;

var onePixelToOneCm=1.492537313432836;
var MIN_FORCE = 0.00000000007;
var MAX_WIDTH = 300;
var MAX_FORCE = 0.00000007500;
var G		  = 6.672 * Math.pow(10, -11);
var meters;


var m1Middle;
var m1Hand;

var globalColision=false;
var globalLeft="";
var globalRight="";


$(document).ready(function(){
	resize();
	initialize();
});

function resize(){

	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;

	//scaleh = 2;
	//scalew = 2;

	var margLeft = 0;
	var margTop = 0;
	if(scaleh<scalew){
		scale = scaleh;
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
	}

	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');

}

function restart(){
	var valueLeft="38";
	var valueRight="25";

	changeIntToGrafic(valueLeft,"Left");
	changeIntToGrafic(valueRight,"Right");
	showM(valueLeft,"Left");
	showM(valueRight,"Right");
	positionTextForce();
	init4meters();

	$("#countMeters").html('4.00m');
	$(".forceN").html('0.00000000396');

}

var lastLeftOk;

function initialize(){


	iniciat = false;
	volts = 0;
	elecSpeed = 0;
	direction = 0;

	meterPosition();

	$("#bolaEsq").draggable({
		scroll: false,
		axis: "x",

		start: function(evt,ui){


			m1Anterior=Math.round(ui.position.left / scale);


		},

		drag: function(evt,ui){
			// zoom fix

			ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);



			var pos=ui.position.left;
			var limit=(scaleM1*100)-100;


			if(pos<=limit){
				ui.position.left =limit;
			}

			meterPosition();

			var collisionVar=collision();


			if(globalColision==true){
				setTimeout(function(){whileCollision('bolaEsq');},100);
				return false;

				//console.log('left=='+globalLeft);

			}else{
				var newPos=m1Anterior-ui.position.left;

				m1Middle=ui.position.left+209;

				$("#middleLeftImg").css('left',m1Middle+"px");
				m1Anterior=ui.position.left;
				calculateG();
			}

		}
	});


	$("#bolaDreta").draggable({
		scroll: false,
		axis: "x",

		start: function(evt,ui){

			m2Anterior=ui.position.left/scale

		},

		drag: function(evt,ui){
			// zoom fix
			ui.position.top 	= Math.round(ui.position.top / scale);
			ui.position.left 	= Math.round(ui.position.left / scale);
			//var pos=parseInt($(this).css('top'));
			var pos=ui.position.left;

			console.log((950)/scale);
			console.log(ui.position.left);

			if(ui.position.left > 605 && ui.position.left>m2Anterior){

				ui.position.left = m2Anterior;
			}

			meterPosition();
			var collisionVar=collision();

			if(globalColision==true){

				setTimeout(function(){

					whileCollision('bolaDreta');



				},100);
				return false;

				if(ui.position.left<m2Anterior){
					ui.position.left=m2Anterior;
				}

			}else{
				m2Middle=ui.position.left+198;

				$("#middleRightImg").css('left',m2Middle+"px");
				m2Anterior=ui.position.left;
				calculateG();
			}


		}
	});


	$("#leftDrag").draggable({
		scroll: false,
		axis: "y",

		start: function(evt,ui){


		},

		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);
			//var pos=parseInt($(this).css('top'));
			var pos=ui.position.top;
			var collisionVar=collision();
			if(collisionVar=='si'){
				whileCollision('bolaEsq');
			}

			if((pos)>=maxDrag){

				ui.position.top =maxDrag;

				//var pos2=parseInt($(this).css('top'));

			}else if(pos<0){
				ui.position.top =0;

			}

			showM(changeGraficToInt(ui.position.top),'Left');
			calculateG();
			////console.log("top="+pos);

		}
	});

	$("#rightDrag").draggable({
		scroll: false,
		axis: "y",

		start: function(evt,ui){


		},

		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);
			//var pos=parseInt($(this).css('top'));
			var pos=ui.position.top;
			var collisionVar=collision();
			if(collisionVar=='si'){
				whileCollision('bolaDreta');
			}
			if((pos)>=(maxDrag)){
				ui.position.top =maxDrag;
			}else if(pos<0){


				ui.position.top =0;

			}

			showM(changeGraficToInt(ui.position.top),'Right');
			moveRightHand();

			calculateG();

		}
	});
	restart();





}

function whileCollision(div){

	var collisionVar=collision();

	var cont=0;
	pos=parseInt($("#"+div).css('left'));
	while(collisionVar=='si') {

		if(div=="bolaEsq"){
			pos=pos-3;
			m1Middle=pos+209;
			$("#middleLeftImg").css('left',m1Middle+"px");
		}else{
			pos=pos+3;
			m2Middle=pos+198;
			$("#middleRightImg").css('left',m2Middle+"px");
		}

		collisionVar=collision();

		//showM(changeGraficToInt(//console.log($("#rightDrag").css('top'))),'Right');

		cont++;
	}
	$("#"+div).css('left',(pos)+'px');
	meterPosition();
	showDistance();

	calculateG();
	positionTextForce();



}

function init4meters(){
	var posE=101;
	var posD=364;
	bolaEsq
	$("#bolaEsq").css('left',posE+'px');
	$("#bolaDreta").css('left',posD+'px');
	m1Middle=posE+209;
	m2Middle=posD+198;
	$("#middleLeftImg").css('left',m1Middle+"px");
	$("#middleRightImg").css('left',m2Middle+"px");



	showDistance();
	positionTextForce();
	meterPosition();

}


function calculateWidth(value){
	var width=(value*MAX_WIDTH)/MAX_FORCE;
	return width;
}

function showDistance(){

	var rightBar = $('#middleRightImg').offset();
	var leftBar = $('#middleLeftImg').offset();

	var newLeft=Math.round(leftBar.left /scale);
	var newRight=Math.round(rightBar.left/scale)+12;

	var dif=newRight-newLeft;

	var cm=dif*onePixelToOneCm;
	meters=(cm/100);
	var meters2=1.7*(cm/10000);

	meters+=meters2;
	$("#lineMeter").css('min-width',(dif-12)+'px');
	var mmeters=(meters + "").split(".");
	var n=parseInt(mmeters[0]);
	var t=meters-n;
	if(t>0.96){

		meters=n+1;
	}else if(0.03>t){
		meters=n;
	}

	$("#countMeters").html((meters.toFixed(2))+"m");


}

function calculateG(){

	positionTextForce();
	var multi=(G*m1*m2);
	var div=(Math.pow(meters,2));
	var result=multi/div;

	$(".forceN").html(result.toFixed(11));
	var width=calculateWidth(result.toFixed(11));
	$("#rectangle-left").css('min-width',width+"px");
	$("#rectangle-right").css('min-width',width+"px");


}

function collision(){


	var leftPosition = $('#mLeftImg').offset();
	var rightPosition = $('#mRightImg').offset();
	var rightBar = $('#middleRightImg').offset();
	var leftBar = $('#middleLeftImg').offset();

	var newLeft=Math.round(leftBar.left /scale)+((sizeLeft/2));
	var newRight=Math.round(rightBar.left/scale)-(sizeRight/2);

	var dif=newLeft-newRight;

	if((dif)<11){
		if(globalColision==false){
			//console.log("globalColision="+globalLeft);
		}
		globalLeft=parseInt($("#bolaEsq").css('left'));
		globalRight=parseInt($("#bolaDreta").css('left'));

		//console.log('No touch' );
		globalColision=false;
		return "no";
	}else{

		//console.log('TOUCH');
		globalColision=true;
		return "si";

	}

	/*
	 //console.log('LeftBar='+leftBar.left +' RightBar='+rightBar.left);
	 //console.log('sizELeft='+sizeLeft + 'Sizeright='+sizeRight);
	 */
}



function moveRightHand(){

	var pos=parseInt($("#mRightImg").css('width'));

}

function meterPosition(){

	var positionMeter=parseInt($("#middleLeftImg").css('left'))-7; //45
	$("#lineMeter").css('left',(positionMeter+12)+'px');
	$("#meter").css('left',positionMeter+"px");
	var width=parseInt($("#lineMeter").css('width'));
	//console.log(width);
	var position=(positionMeter+((width/2)-10));
	$("#countMeters").css('left',position+"px");


}

function positionTextForce(){
	var positionMeter=parseInt($("#middleLeftImg").css('left'));
	$("#f2").css('left',positionMeter+"px");
	var widthArrow=parseInt($("#rectangle-left ").css('width'));
	$("#triangle-left ").css('left',(positionMeter+widthArrow)+"px");
	$("#rectangle-left ").css('left',positionMeter+"px");

	var positionMeter2=parseInt($("#middleRightImg").css('left'))-400;
	var positionMeterBasic=parseInt($("#middleRightImg").css('left'));
	$("#f1").css('left',positionMeter2+"px");

	$("#triangle-right ").css('left',(positionMeterBasic-widthArrow+5)+"px");
	$("#rectangle-right ").css('left',(positionMeterBasic-widthArrow+12)+"px");

	showDistance();

}

function showM(value,side){


	$("#inputProf"+side).val(value);
	imgSize(value,side);

}

function imgSize(value,side){

	var scale2=value/100;

	var size= parseInt((value*203)/100); <!--200 is imgSize-->

	if(side=='Left'){
		var bolaS=size+109;
		$("#bolaEsq").css('width',size+"px");
		sizeLeft=size;
		scaleM1=scale2;
		m1=value;
	}else{
		var bolaS=size+109;
		//$("#bolaDreta").css('width',size+"px");
		scaleM2=scale2;
		sizeRight=size;
		m2=value;
	}


	// //console.log("value="+value+" scale="+scale);
	$("#m"+side+"Img").css('-ms-transform-origin',"50% 50%");
	$("#m"+side+"Img").css('-webkit-transform-origin',"50% 50%");
	$("#m"+side+"Img").css('transform-origin',"50% 50%");
	$("#m"+side+"Img").css('-ms-transform','scale('+scale2+','+scale2+')');
	$("#m"+side+"Img").css('-webkit-transform', 'scale('+scale2+','+scale2+')');
	$("#m"+side+"Img").css('transform','scale('+scale2+','+scale2+')');
	var collisionVar=collision();
	if(side=="Left"){
		if(collisionVar=='si'){

			var rightB=$("#middleRightImg").offset();
			//var pos=rightB.left-(sizeRight/2)-(sizeLeft);
			var pos=m2Anterior-(sizeLeft);
			$("#bolaEsq").css('left',pos+"px");
			//console.log("POSS="+pos+"anteriorM2"+m2Anterior);

		}


		var handLeft=(203-size)/2;
		$(".handM1").css('margin-left',handLeft+"px");

	}else{
		var handLeft=(209-(value*(-1))); <!--109 is handWidth-->
		$(".handM2").css('left',handLeft+"px");
	}

	calculateG();

	//$("#m"+side+"Img").attr('width',size+"px");
}

function changeGraficToInt(value){
	var m= parseInt((value*100)/maxDrag); <!--100 is max Profundidad-->
	if(m>100){
		m=0;
	}
	//printProfunditat(prof);

	return 100-m;
}

function changeIntToGrafic(value,side){
	side=side.toLowerCase();
	value=100-value;
	var prof=((value*maxDrag)/100);
	$("#"+side+'Drag').css("top",prof)
	var pos=$("#"+side+'Drag').position();





}

var timeOutSearch;
var profTemp;
var profSide;
function assigProf(value,side){

	clearTimeout(timeOutSearch);
	profTemp=value;
	profSide=side;
	timeOutSearch=setTimeout(doAssigProf,1500);

}

function doAssigProf(){
	var value=profTemp;

	if(tiene_letras(value)){
		if(value>100){
			value=100;
		}else if(value<0){
			value=0;
		}else{
			value=value;
		}
	}else{
		value=100;

	}
	if(profSide=='Left'){
		m1=value;
		var div='bolaEsq'
	}else{
		m2=value;
		var div='bolaDreta'
	}

	changeIntToGrafic(value,profSide);
	showM(value,profSide);
	positionTextForce();
	var collisionVar=collision();
	if(collisionVar=='si'){

		whileCollision(div);
	}

}

function tiene_letras(texto){
	var letras="abcdefghyjklmnñopqrstuvwxyz";
	texto = texto.toLowerCase();
	for(i=0; i<texto.length; i++){
		if (letras.indexOf(texto.charAt(i),0)!=-1){
			return 0;
		}
	}
	return 1;
}



function addHover(value){

	$("#selOptionA"+value).addClass('selectOptionsHover');

}
function removeHover(value){

	$("#selOptionA"+value).removeClass('selectOptionsHover');

}
function showSelects(){
	for(var x=1;x<7;x++){
		$("#selOptionA"+x).css("display","block");
	}

}
function iniciar(){
	if(!iniciat){

	}
}

function reiniciar(){
	if(canChange){
		restart();
		initialize();
	}
}