window.onresize = resize;
var scale 	= 1;
var mgLeft	= 0;
var mgTop	= 0;
var nVector = 0;
var centerPressed = false;
var canvas;
var context;
var Ax = 301;
var Ay = 312;
var endX = new Array(3);
var endY = new Array(3);
var line, isDown, auxLine1, auxLine2, sumLine;
var endPointsX = new Array(4);
var endPointsY = new Array(4);
var lastX;
var lastY;

$(document).ready(function(){
	resize();
	initialize();
	
	$(function() {
		var leftButtonDown = false;
		/*
		$(document).mousedown(function(e){
			// Left mouse button was pressed, set flag
			if(e.which === 1) leftButtonDown = true;
		});
		*/
		$(document).mouseup(function(e){
			// Left mouse button was released, clear flag
			if(e.which === 1) leftButtonDown = false;
		});
	
		$("#center").bind("mousedown touchstart",function(e){
			startMove(e);
		});
		$("#center").css('-ms-touch-action', 'none');
	
		window.ondragstart = function() { return false; } 
		
		$(document).bind("mousemove touchmove",function(e) {		
			mouseMoving(e);
		});
	
		$(document).bind("mouseup touchend",function(e) {
			mouseStop(e);
		});
	});
});

function mouseStop(e){
	isDown = false;
	if(centerPressed && nVector<3){
		nVector++;
	}
	centerPressed = false;
}

function mouseMoving(e){

	if (!isDown) return;

	if(centerPressed && nVector<3){
		var mouse;
		var newX;
		var newY;
		
		if(e.type == "mousemove"){
			mouse = canvas.getPointer(e);
			newX = mouse.x/scale;
			newY = mouse.y/scale;
		}else{
			mouse = canvas.getPointer(e.e);
			newX = mouse.x/scale;
			newY = mouse.y/scale;
		}
		console.log(newX);
		console.log(newY);
		var line = canvas.getActiveObject();
		if(newX > 515){
			newX = 515;
		}
		if(newX < 88){
			newX = 88;
		}
		if(newY < 97){
			newY = 97;
		}
		if(newY > 524){
			newY = 524;
		}

		line.set('x2', newX).set('y2', newY);
		line.setCoords();
		var tip2;
		if(nVector>0){
			var endX = newX + endPointsX[nVector-1]-301;
			var endY = newY +  endPointsY[nVector-1]-312;

			auxLine1.set('x2', (endX)).set('y2', endY);
			auxLine1.setCoords();
			auxLine2.set('x1', (newX )).set('y1', newY-3 );
			auxLine2.set('x2', (endX)).set('y2', endY);
			auxLine2.setCoords();

			canvas.setActiveObject(sumLine);

			sumLine.set('x2', (endX)).set('y2', endY);
			sumLine.setCoords();

			tip2 = sumLine.get('tip');

			tip2.set({ x1: endX , y1: endY, x2: Ax, y2: Ay });

			tip2.setLeft(endX);
			tip2.setTop(endY);

			var xx1 = tip2.get('x2')/scale - tip2.get('x1')/scale;
			var yy1 = tip2.get('y2')/scale - tip2.get('y1')/scale;
			var angle;

			if (xx1 == 0){
				if(yy1 == 0){
					angle = 0;
				}else if(yy1 > 0){
					angle = Math.PI / 2;
				}else{
					angle = Math.PI * 3 / 2;
				}
			}else if (yy1 == 0) {
				if(xx1 > 0){
					angle = 0;
				}else{
					angle = Math.PI;
				}
			}else{
				if(xx1 < 0){
					angle = Math.atan(yy1 / xx1) + Math.PI;
				}else if (yy1 < 0){
					angle = Math.atan(yy1 / xx1) + (2 * Math.PI);
				}else{
					angle = Math.atan(yy1 / xx1);
				}
			}
			angle = angle * 180 / Math.PI;

			tip2.set('angle', angle-90);
		}
		
		canvas.setActiveObject(line);

		var tip = line.get('tip');
		tip.set({ x1: newX, y1: newY, x2: lastY, y2: lastY });

		var x = tip.get('x2')/scale - tip.get('x1')/scale;
		var y = tip.get('y2')/scale - tip.get('y1')/scale;
		
		tip.setLeft(newX);
		tip.setTop(newY);
		
		if(nVector == 0){
			endPointsX[nVector] = newX;
			endPointsY[nVector] = newY;
		}else{
			endPointsX[nVector] = newX + endPointsX[nVector-1]-301;
			endPointsY[nVector] = newY +  endPointsY[nVector-1]-312 ;
		}
		
		var angle;
		if (x == 0){
			if(y == 0){
				angle = 0;
			}else if(y > 0){
				angle = Math.PI / 2;
			}else{
				angle = Math.PI * 3 / 2;
			}
		}else if (y == 0) {
			if(x > 0){
				angle = 0;
			}else{
				angle = Math.PI;
			}
		}else{
			if(x < 0){
				angle = Math.atan(y / x) + Math.PI;
			}else if (y < 0){
				angle = Math.atan(y / x) + (2 * Math.PI);
			}else{
				angle = Math.atan(y / x);
			}
		}
		angle = angle * 180 / Math.PI;

		tip.set('angle', angle-90);

		canvas.renderAll();
		canvas.calcOffset();
		
		var xf = line.get('x2')/scale - line.get('x1')/scale;
		var yf = line.get('y2')/scale - line.get('y1')/scale;
		
		var res = Math.sqrt(Math.pow((xf-0.5)/42.7*scale,2) + Math.pow((yf+1.2)/42.7*scale,2));

		if(nVector==0){
			$("#res"+(nVector+1)).html(Math.round(res*100)/100 + ' N');
			$("#res"+(nVector+1)).formatNumber();
		}else if(nVector==1){
			var xfs = sumLine.get('x2')/scale - sumLine.get('x1')/scale;
			var yfs = sumLine.get('y2')/scale - sumLine.get('y1')/scale;
			
			var res2 = Math.sqrt(Math.pow((xfs-0.5)/42.7*scale,2) + Math.pow((yfs+1.2)/42.7*scale,2));
		
			$("#res"+(nVector+1)).html(Math.round((res)*100)/100 + ' N');
			$("#res"+(nVector+2)).html(Math.round((res2)*100)/100 + ' N');
			$("#res"+(nVector+1)).formatNumber();
			$("#res"+(nVector+2)).formatNumber();
		}else if(nVector==2){
			var xfs = sumLine.get('x2')/scale - sumLine.get('x1')/scale;
			var yfs = sumLine.get('y2')/scale - sumLine.get('y1')/scale;
			
			var res2 = Math.sqrt(Math.pow((xfs-0.5)/42.7*scale,2) + Math.pow((yfs+1.2)/42.7*scale,2));
		
			$("#res"+(nVector+2)).html(Math.round((res)*100)/100 + ' N');
			$("#res"+(nVector+3)).html(Math.round((res2)*100)/100 + ' N');
			$("#res"+(nVector+2)).formatNumber();
			$("#res"+(nVector+3)).formatNumber();
		}
	}
}

function startMove(e){
	$("#pie").html(getText("pie2"));
	if(nVector<3){
		if(nVector==0){
			$("#result"+(nVector+1)).css("display","block");
		}else if(nVector==1){
			$("#result"+(nVector+1)).css("display","block");
			$("#result"+(nVector+2)).css("display","block");
		}else if(nVector==2){
			$("#result"+(nVector+2)).css("display","block");
			$("#result"+(nVector+3)).css("display","block");
		}
		started = true;
		var mouse;
		
		if(e.type == "mousedown"){
			mouse = canvas.getPointer(e);
			lastX = mouse.x/scale;
			lastY = mouse.y/scale;
		}else{
			mouse = canvas.getPointer(e.e);
			lastX = mouse.x/scale;
			lastY = mouse.y/scale;
		}
		
		

		e.preventDefault();
		centerPressed = true;
		isDown = true;
		var lineC = "#FF9900";
		if(nVector==1){
			lineC = "#3399CC";
			sumlineC = "#666666";
		}else if(nVector==2){
			lineC = "#669900";
			sumlineC = "#000000";
		}

		var points = [ Ax, Ay, Ax,  Ay ];
		line = new fabric.Line(points, {
			strokeWidth: 2,
			fill: lineC,
			stroke: lineC,
			originX: 'center',
			originY: 'center',
			hasControls: false,
			perPixelTargetFind: true,
			hasBorders: false,
			hoverCursor: 'default'
		});
		line.lockScalingX = line.lockScalingY = true;
		line.lockMovementX = line.lockMovementY = true;
		var tip = new fabric.Path('M 0 0 L -5 10 L 5 10 L 0 0 z', {
			left: lastX,
			top: lastY,
			fill: lineC,
			strokeWidth: 2,
			stroke: lineC,
			strokeLineCap: 'round',
			hasControls: false,
			originX: 'center',
			originY: 'top'
		});

		tip.line = line;
		line.tip = tip;

		var tip;

		if(nVector>0){
			auxLine1 = new fabric.Line([endPointsX[nVector-1],endPointsY[nVector-1],endPointsX[nVector-1],endPointsY[nVector-1]], {
				strokeWidth: 1,
				fill: '#cccccc',
				stroke: '#cccccc',
				originX: 'center',
				originY: 'center',
				hasControls: false,
				perPixelTargetFind: true,
				hasBorders: false,
				hoverCursor: 'default',
				strokeDashArray: [5, 5]
			});

			auxLine2 = new fabric.Line([lastX,lastY,lastX,lastY], {
				strokeWidth: 1,
				fill: '#cccccc',
				stroke: '#cccccc',
				originX: 'center',
				originY: 'center',
				hasControls: false,
				perPixelTargetFind: true,
				hasBorders: false,
				hoverCursor: 'default',
				strokeDashArray: [5, 5]
			});

			sumLine = new fabric.Line([Ax, Ay, Ax,  Ay], {
				strokeWidth: 2,
				fill: sumlineC,
				stroke: sumlineC,
				originX: 'center',
				originY: 'center',
				hasControls: false,
				perPixelTargetFind: true,
				hasBorders: false,
				hoverCursor: 'default'
			});
			sumLine.lockScalingX = sumLine.lockScalingY = true;
			sumLine.lockMovementX = sumLine.lockMovementY = true;
			tip2 = new fabric.Path('M 0 0 L -5 10 L 5 10 L 0 0 z', {
				left: Ax,
				top: Ay,
				fill: sumlineC,
				strokeWidth: 2,
				stroke: sumlineC,
				strokeLineCap: 'round',
				hasControls: false,
				originX: 'center',
				originY: 'top'
			});

			tip2.sumLine = sumLine;
			sumLine.tip = tip2;

			canvas.add(auxLine1);
			canvas.add(auxLine2);
			canvas.add(sumLine);
			canvas.add(tip2);

			tip2.bringToFront();
		}

		canvas.add(line);
		canvas.add(tip);

		tip.bringToFront();
		canvas.setActiveObject(line);
		canvas.renderAll();
	}
}

function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}

function initialize(){
	nVector = 0;
	$("#result1").css("display","none");
	$("#result2").css("display","none");
	$("#result3").css("display","none");
	$("#result4").css("display","none");
	$("#result5").css("display","none");
	$("#ver1").css('display','block');
	$("#ver2").css('display','block');
	canvas = new fabric.Canvas('arrowsCanvas', { selection: false });
}

function iniciar(){
	if(!iniciat){
		iniciat = true;
	}
}

function reiniciar(){

	nVector = 0;
	centerPressed = false;
	endPointsX = new Array(4);
	endPointsY = new Array(4);

	canvas.clear();

	initialize();
}