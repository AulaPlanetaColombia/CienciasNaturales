window.onresize = resize;
var scale 	= 1;
var iniciat;

var box = 1;
var fuerza = 0;
var angle = 15;
var angleBox = 0;
var angleMan = 0;
var moveForward;
var isUp;
var direction = "right";
var FAwidth;
var FRwidth;
var backForce = 0;
var fallLeft = 0;
var showNeta;
var moveInterval;

function cot(aValue)
{
	return 1/Math.tan(aValue);
}
// Register the new function

$(document).ready(function(){
	resize();
	initialize();
});

function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}

function restart(){
	location.reload();
}

function initialize(){
	iniciat = false;
	moveForward = true;
	isUp = false;
	direction = "right";
	box = 10;
	fuerza = 0;
	angle = 15;
	angleBox = 0;
	angleMan = 0;
	backForce = 0;
	fallLeft = 0;
	showNeta = true;

	moveInterval = setInterval(function() {
		rotateBox();
		rotateMan();
		moveMan();
	},33);

	$("#handle").draggable({
		axis:"x",
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);

			if(ui.position.left<80){
				ui.position.left = 80;
			}
			if(ui.position.left>678){
				ui.position.left = 678;
			}

			fuerza = (ui.position.left - 80)/(678-80)*1000;
			fuerza = Math.round(fuerza*100)/100;
			var txtFuerza = "";
			if(fuerza == 1000) {
				txtFuerza = "1.000 N";
			}else{
				txtFuerza = (fuerza + " N").replace(".",",");
			}
			if(fuerza <=20){
				$("#man").attr("src","images/man1.png");
			}else if(fuerza>20 && fuerza<50) {
				$("#man").attr("src","images/man2.png");
			}else if(fuerza>=50){
				$("#man").attr("src","images/man3.png");
			}
			



			checkMoveForward();
			
			FAwidth = fuerza*150/1000;
			$( "#flechaFA" ).css("width",FAwidth+"px");
			
			
			$( "#resultFuerza" ).html(txtFuerza);
		}
	});
	$("#handle").css('-ms-touch-action', 'none');

}

function checkMoveForward(){
	var boxLeft = $("#box").css("left");
	boxLeft = parseInt(boxLeft.substring(0,boxLeft.length-2));
	var minForce = 0;
	if(angle == 15) {
		if(box==10){
			minForce = 5;
		}else if(box==50){
			minForce = 150;
		}else if(box==100){
			minForce = 310;
		}
	}else if(angle == 25){
		if(box==10){
			minForce = 20;
		}else if(box==50){
			minForce = 260;
		}else if(box==100){
			minForce = 560;
		}
	}else if(angle == 35){
		if(box==10){
			minForce = 70;
		}else if(box==50){
			minForce = 290;
		}else if(box==100){
			minForce = 580;
		}
	}

	if(angle == 15){

		if(fuerza<minForce){
			if(isUp && boxLeft>380){
				moveForward = false;
				if(backForce==0){
					var boxTop = $("#box").css("top");
					boxTop = parseInt(boxTop.substring(0,boxTop.length-2));
					backForce = boxTop;
					fallLeft = 280+(72 - (315 - Math.abs(boxTop)))*3/4;
				}
			}
		}
	}else if(angle == 25){
		if(fuerza<minForce){
			if(isUp && boxLeft>380){
				moveForward = false;
				if(backForce==0){
					var boxTop = $("#box").css("top");
					boxTop = parseInt(boxTop.substring(0,boxTop.length-2));
					backForce = boxTop;
					fallLeft = 280+(163 - (315 - Math.abs(boxTop)))*3/4;
				}
			}
		}
	}else if(angle == 35){
		if(fuerza<minForce){
			if(isUp && boxLeft>380){
				moveForward = false;
				if(backForce==0){
					var boxTop = $("#box").css("top");
					boxTop = parseInt(boxTop.substring(0,boxTop.length-2));
					backForce = boxTop;
					fallLeft = 280+(72 - (315 - Math.abs(boxTop)))*3/4;
				}
			}
		}
	}

	if(!moveForward){
		if(fuerza>minForce){
			moveForward = true;
			backForce = 0;
		}
	}
}

function showFNeta(){
	if(showNeta){
		$("#checkFuerzaX").css("display","none");
		$("#sfneta").css("display","none");
		$("#flechaFNeta").css("display","none");
		showNeta = false;
	}else{
		$("#checkFuerzaX").css("display","block");
		$("#sfneta").css("display","block");
		$("#flechaFNeta").css("display","block");
		showNeta = true;
	}
}

function rotateBox(){
	var boxLeft = $("#box").css("left");	
	boxLeft = parseInt(boxLeft.substring(0,boxLeft.length-2));

	if(boxLeft>= 380){
		if(angleBox != -angle) {
			angleBox = -angle;
			$("#boxImg").velocity({
				rotateZ: -angle + "deg"
			}, {
				duration: 0
			});
		}
	}else{
		angleBox = 0;
		$("#boxImg").velocity({
				rotateZ: "0deg"
			}, {
				duration: 0
			});
	}


}
function rotateMan(){
	var boxLeft = $("#box").css("left");
	boxLeft = parseInt(boxLeft.substring(0,boxLeft.length-2));
	var topMan = 0;
	if(angle == 15){
		if(box==10){
			topMan = -11;
		}else if(box==50){
			topMan = -7;
		}else if(box==100){
			topMan = -3;
		}

	}else if(angle == 25){
		if(box==10){
			topMan = -1;
		}else if(box==50){
			topMan = 0;
		}else if(box==100){
			topMan = 5;
		}
	}else if(angle == 35){
		if(box==10){
			topMan =6;
		}else if(box==50){
			topMan = 12;
		}else if(box==100){
			topMan = 18;
		}
	}
	if(boxLeft>= 390){
		$("#man").velocity({
			top: topMan
		}, {
			duration: 0
		});
	}else{
		$("#man").velocity({
			top: -21
		}, {
			duration: 0
		});
	}
	if(boxLeft>= 425){
		if(angleMan != -angle) {
			angleMan = -angle;
			$("#man").velocity({
				rotateZ: -angle + "deg"
			}, {
				duration: 0
			});
		}
	}else{
		angleMan = 0;
		$("#man").velocity({
			rotateZ: "0deg"
		}, {
			duration: 0
		});
	}
}
function moveMan(){
	var boxLeft = $("#box").css("left");
	boxLeft = parseInt(boxLeft.substring(0,boxLeft.length-2));
	var boxTop = $("#box").css("top");
	boxTop = parseInt(boxTop.substring(0,boxTop.length-2));

	$("#box").velocity("stop");
	var speed = fuerza/box/10;
	var newLeft = boxLeft+speed;
	var newTop = boxLeft-1;
	
	if(boxLeft <= 380) {
		if(moveForward){
			speed = fuerza/box/10;
			newLeft = boxLeft+speed;
		}else{
			speed = 250/box/10;
			newLeft = boxLeft-speed;
			if(newLeft<fallLeft){
				newLeft = fallLeft;
			}
		}
		if(fuerza >= 0) {
			$("#box").velocity({
				left: newLeft,
				top: 315
			}, {
				duration: 33,
				easing: "linear"
			});
		}		
	}else{
		if(!isUp){
			isUp = true;
		}
		
		if(moveForward){
			console.log(box);
			if(box == 10){
				speed = (fuerza/box/angle)+1;
			}else if(box == 50){
				speed = (fuerza/box/angle)+1;
			}else if(box == 100){
				speed = (fuerza/box/angle)+1;
			}
		//	speed = fuerza/(box-5)/angle;
			console.log("speed: " + speed);
			newLeft = boxLeft+speed;
		}else{
			if(angle == 15){
				speed = 600/box/(36-angle);
			}else if(angle == 25){
				speed = 250/box/(36-angle);	
			}else if(angle == 35){
				speed = 75/box/(36-angle);
			}
			newLeft = boxLeft-speed;

			if(newLeft<fallLeft){
				newLeft = fallLeft;
			}
		}
		
		if(angle == 15) {		
			if(box==10){
				if (newLeft > 646){
					newLeft = 646;
				}				
				newTop = (newLeft-380)*cot(angle);
				newTop = 315 + newTop*0.23;
				if(newTop < 243 ) {
					newTop = 243;
				}
			}else if(box==50){
				if (newLeft > 632){
					newLeft = 632;
				}				
				newTop = (newLeft-380)*cot(angle);
				newTop = 312 + newTop*0.23;
				if(newTop < 240 ) {
					newTop = 240;
				}
			}else if(box==100){	
				if (newLeft > 618){
					newLeft = 618;
				}				
				newTop = (newLeft-380)*cot(angle);
				newTop = 309 + newTop*0.23;
				if(newTop < 237 ) {
					newTop = 237;
				}
			}
		}else if(angle == 25){
			if(box==10){
				if (newLeft > 629){
					newLeft = 629;
				}				
				newTop = (newLeft-380)*cot(angle);
				newTop = 313 + newTop*0.064;
				if(newTop < 197 ) {
					newTop = 197;
				}
			}else if(box==50){
				if (newLeft > 614){
					newLeft = 614;
				}				
				newTop = (newLeft-380)*cot(angle);
				newTop = 312 + newTop*0.064;
				if(newTop < 197 ) {
					newTop = 197;
				}
			}else if(box==100){	
				if (newLeft > 599){
					newLeft = 599;
				}				
				newTop = (newLeft-380)*cot(angle);
				newTop = 306 + newTop*0.064;
				if(newTop < 197 ) {
					newTop = 197;
				}
			}
		}else if(angle == 35){
			if(box==10){
				if (newLeft > 600){
					newLeft = 600;
				}				
				newTop = (newLeft-380)*cot(angle);
				newTop = 310 - newTop*0.33;
				if(newTop < 152 ) {
					newTop = 152;
				}
			}else if(box==50){
				if (newLeft > 585){
					newLeft = 585;
				}
				newTop = (newLeft-380)*cot(angle);
				newTop = 305 - newTop*0.33;
				if(newTop < 152 ) {
					newTop = 152;
				}
			}else if(box==100){	
				if (newLeft > 568){
					newLeft = 568;
				}				
				newTop = (newLeft-380)*cot(angle);
				newTop = 296 - newTop*0.33;
				if(newTop < 152 ) {
					newTop = 152;
				}
			}
		}
		if(fuerza >= 0) {
			$("#box").velocity({
				left: newLeft,
				top:  newTop
			}, {
				duration: 33
			});
		}
	}
	
	if(boxLeft<newLeft){
		direction = "right";
	}else if(boxLeft > newLeft){
		direction = "left";
	}

	var FNetaWidth = FAwidth*0.8;
	if(FNetaWidth<0) {
		FNetaWidth = 0;
	}
	if(newLeft<380){
		FRwidth = fuerza*100/1000;
		if(direction == "right"){
			FRwidth = fuerza*100/1000;



			$( "#flechaFR" ).css("width",FRwidth+"px");
			$( "#flechaFR" ).css("transform","rotateZ(180deg)");
			$( "#flechaFA" ).css("transform","rotateZ(0deg)");
			$( "#flechaFN" ).css("transform","rotateZ(180deg)");
			$( "#flechaFNeta" ).css("transform","rotateZ(0deg)");
			$( "#flechaFNeta" ).css("width",FNetaWidth+"px");
			$( "#flechaFNeta" ).css("left","13px");
		}else{
			FRwidth = 400*100/1000;
			$( "#flechaFR" ).css("width",FRwidth+"px");
			$( "#flechaFR" ).css("transform","rotateZ(0deg)");
			$( "#flechaFA" ).css("transform","rotateZ(0deg)");
			$( "#flechaFN" ).css("transform","rotateZ(180deg)");
			$( "#flechaFNeta" ).css("transform","rotateZ(0deg)");
			$( "#flechaFNeta" ).css("width",FNetaWidth+"px");
			$( "#flechaFNeta" ).css("left","13px");
		}
	}else{
		if(direction == "right"){
			FRwidth = fuerza*50/1000;
			$( "#flechaFR" ).css("width",FRwidth+"px");
			$( "#flechaFR" ).css("transform","rotateZ(-"+(angle+180)+"deg)");
			$( "#flechaFA" ).css("transform","rotateZ(-"+(angle)+"deg)");
			$( "#flechaFN" ).css("transform","rotateZ("+(180-angle)+"deg)");
			$( "#flechaFNeta" ).css("transform","rotateZ(-"+(angle)+"deg)");
			$( "#flechaFNeta" ).css("width",FNetaWidth+"px");
			$( "#flechaFNeta" ).css("left","13px");
			//$( "#flechaFA" ).css("top","3px");
		}else{
			FRwidth = 400*100/1000;
			$( "#flechaFR" ).css("width",FRwidth+"px");
			$( "#flechaFR" ).css("transform","rotateZ(-"+angle+"deg)");
			$( "#flechaFA" ).css("transform","rotateZ(-"+(angle)+"deg)");
			$( "#flechaFN" ).css("transform","rotateZ("+(180-angle)+"deg)");
			$( "#flechaFNeta" ).css("transform","rotateZ(-"+(angle)+"deg)");
			$( "#flechaFNeta" ).css("width",FNetaWidth+"px");
			$( "#flechaFNeta" ).css("left","13px");
			//$( "#flechaFA" ).css("top","3px");
		}
	}
}

function selectBox(n){
	switch(n){
		case 1:
			$("#btCaja1 img").addClass("selected");
			$("#btCaja2 img").removeClass("selected");
			$("#btCaja3 img").removeClass("selected");
			$("#boxImg").attr("src","images/box1.png");
			$("#boxImg").css("top","1px");
			
			$("#flechaFA").css("left","13px").css("top","13px");
			$("#flechaFG").css("left","13px").css("top","13px");
			$("#flechaFN").css("left","13px").css("top","13px");
			$("#flechaFNeta").css("left","13px");
			$("#flechaFR").css("left","13px").css("top","13px");
			
			$("#flechaFN").css("height","9px");
			$("#flechaFN img").css("top","8px");
			$("#flechaFG").css("height","16px");
			$("#flechaFG img").css("top","16px");
			
			$("#sfa").css("left","50px").css("top","-5px");
			$("#sfg").css("left","20px").css("top","80px");
			$("#sfn").css("left","-8px").css("top","-85px");
			$("#sfneta").css("left","22px").css("top","-60px");
			$("#sfr").css("left","-13px").css("top","-22px");
			box = 10;
			break;
		case 2:
			$("#btCaja1 img").removeClass("selected");
			$("#btCaja2 img").addClass("selected");
			$("#btCaja3 img").removeClass("selected");
			$("#boxImg").attr("src","images/box2.png");
			$("#boxImg").css("top","-12px");	

			$("#flechaFA").css("left","21px").css("top","8px");
			$("#flechaFG").css("left","21px").css("top","8px");
			$("#flechaFN").css("left","21px").css("top","8px");
			$("#flechaFNeta").css("left","21px");
			$("#flechaFR").css("left","21px").css("top","8px");
			
			$("#flechaFN").css("height","67");
			$("#flechaFN img").css("top","66px");
			$("#flechaFG").css("height","74px");
			$("#flechaFG img").css("top","74px");
			
			$("#sfa").css("left","55px").css("top","-10px");
			$("#sfg").css("left","-2px").css("top","80px");
			$("#sfn").css("left","-8px").css("top","-85px");
			$("#sfneta").css("left","35px").css("top","-60px");
			$("#sfr").css("left","-13px").css("top","-22px");
			box = 50;
			break;
		case 3:
			$("#btCaja1 img").removeClass("selected");
			$("#btCaja2 img").removeClass("selected");
			$("#btCaja3 img").addClass("selected");
			$("#boxImg").attr("src","images/box3.png");
			$("#boxImg").css("top","-24px");			
			
			$("#flechaFA").css("left","27px").css("top","2px");
			$("#flechaFG").css("left","27px").css("top","2px");
			$("#flechaFN").css("left","27px").css("top","2px");
			$("#flechaFNeta").css("left","35px");
			$("#flechaFR").css("left","27px").css("top","2px");
			
			$("#flechaFN").css("height","150px");
			$("#flechaFN img").css("top","149px");
			$("#flechaFG").css("height","157px");
			$("#flechaFG img").css("top","156px");
			
			$("#sfa").css("left","60px").css("top","-20px");
			$("#sfg").css("left","0px").css("top","80px");
			$("#sfn").css("left","-8px").css("top","-85px");
			$("#sfneta").css("left","42px").css("top","-60px");
			$("#sfr").css("left","-13px").css("top","-22px");
			box = 100;
			break;
	}
	checkMoveForward();
}

function selectAngle(n){
	switch(n){
		case 1:
			$("#btAngulo1 img").addClass("selected");
			$("#btAngulo2 img").removeClass("selected");
			$("#btAngulo3 img").removeClass("selected");

			$("#rampa").attr("src","images/rampa1.png");
			$("#rampa").css("top","118px");
			$("#rampa").css("left","385px");

			angle = 15;
			break;
		case 2:
			$("#btAngulo1 img").removeClass("selected");
			$("#btAngulo2 img").addClass("selected");
			$("#btAngulo3 img").removeClass("selected");
			$("#rampa").attr("src","images/rampa2.png");
			$("#rampa").css("top","79px");
			$("#rampa").css("left","385px");

			angle = 25;
			break;
		case 3:
			$("#btAngulo1 img").removeClass("selected");
			$("#btAngulo2 img").removeClass("selected");
			$("#btAngulo3 img").addClass("selected");
			$("#rampa").attr("src","images/rampa3.png");
			$("#rampa").css("top","51px");
			$("#rampa").css("left","390px");

			angle = 35;
			break;
	}
	checkMoveForward();
}
function iniciar(){
	if(!iniciat){	
			
	}
}

function reiniciar(){
	restart();
	initialize();
}