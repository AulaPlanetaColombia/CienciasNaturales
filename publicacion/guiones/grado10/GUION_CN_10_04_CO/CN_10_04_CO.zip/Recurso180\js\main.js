window.onresize = resize;
var scale 	= 1;
var iniciat;

var f1,f2,f3,f4,f5,f6;


$(document).ready(function(){
	resize();
	initialize();
});

function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}

function restart(){
	equilibrarA();
	equilibrarB();
	equilibrarC();
}

function initialize(){
	iniciat = false;
	f1 = 4;
	f2 = 4;
	f3 = 6;
	f4 = 3;
	f5 = 8;
	f6 = 2;
	
	$("#slide1").draggable({
		axis: "y",
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / (scale*2));
			ui.position.left = Math.round(ui.position.left / (scale*2));
			
			if(ui.position.top < 0){
				ui.position.top = 0;
			}else if(ui.position.top > 31){
				ui.position.top = 31;
			}
			
		},
		stop: function (evt,ui){
			f1 = Math.round(10-((ui.position.top/34)*10));			
			$("#f1").html(f1 + " N");
			moveSystem1();
		}
	});
	$("#slide1").css('-ms-touch-action', 'none');
	$("#slide2").draggable({
		axis: "y",
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / (scale*2));
			ui.position.left = Math.round(ui.position.left / (scale*2));
			
			if(ui.position.top < 0){
				ui.position.top = 0;
			}else if(ui.position.top > 31){
				ui.position.top = 31;
			}
			
		},
		stop: function (evt,ui){
			f2 = Math.round(10-((ui.position.top/34)*10));			
			$("#f2").html(f2 + " N");
			moveSystem1();
		}
	});
	$("#slide2").css('-ms-touch-action', 'none');
	$("#slide3").draggable({
		axis: "y",
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / (scale*2));
			ui.position.left = Math.round(ui.position.left / (scale*2));
			
			if(ui.position.top < 0){
				ui.position.top = 0;
			}else if(ui.position.top > 31){
				ui.position.top = 31;
			}
			
		},
		stop: function (evt,ui){
			f3 = Math.round(10-((ui.position.top/34)*10));			
			$("#f3").html(f3 + " N");
			moveSystem2();
		}
	});
	$("#slide3").css('-ms-touch-action', 'none');
	$("#slide4").draggable({
		axis: "y",
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / (scale*2));
			ui.position.left = Math.round(ui.position.left / (scale*2));
			
			if(ui.position.top < 0){
				ui.position.top = 0;
			}else if(ui.position.top > 31){
				ui.position.top = 31;
			}
			
		},
		stop: function (evt,ui){
			f4 = Math.round(10-((ui.position.top/34)*10));			
			$("#f4").html(f4 + " N");
			moveSystem2();
		}
	});
	$("#slide4").css('-ms-touch-action', 'none');
	$("#slide5").draggable({
		axis: "y",
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / (scale*2));
			ui.position.left = Math.round(ui.position.left / (scale*2));
			
			if(ui.position.top < 0){
				ui.position.top = 0;
			}else if(ui.position.top > 31){
				ui.position.top = 31;
			}
			
		},
		stop: function (evt,ui){
			f5 = Math.round(10-((ui.position.top/34)*10));			
			$("#f5").html(f5 + " N");
			moveSystem3();
		}
	});
	$("#slide5").css('-ms-touch-action', 'none');
	$("#slide6").draggable({
		axis: "y",
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / (scale*2));
			ui.position.left = Math.round(ui.position.left / (scale*2));
			
			if(ui.position.top < 0){
				ui.position.top = 0;
			}else if(ui.position.top > 31){
				ui.position.top = 31;
			}
			
		},
		stop: function (evt,ui){
			f6 = Math.round(10-((ui.position.top/34)*10));			
			$("#f6").html(f6 + " N");
			moveSystem3();
		}
	});
	$("#slide6").css('-ms-touch-action', 'none');
}

function moveSystem1(){
	$("#res1").css("display","block");
	$("#res2").css("display","block");
	
	$("#pcu1").velocity("stop");
	$("#cableS1_1").velocity("stop");
	$("#cableS1_2").velocity("stop");
	$("#peso1").velocity("stop");
	$("#peso2").velocity("stop");
	if(f1>f2){
		//moveLeft
		$("#pcu1").velocity({
			rotateZ: "-135deg"
		},{
			duration:	2000
		});
		$("#cableS1_1").velocity({
			height: "257"
		},{
			duration:	2000
		});
		$("#cableS1_2").velocity({
			height: "17"
		},{
			duration:	2000
		});
		$("#peso1").velocity({
			top: "417"
		},{
			duration:	2000
		});
		$("#peso2").velocity({
			top: "217"
		},{
			duration:	2000
		});		
	}else if(f1<f2){
		//moveRight	
		$("#pcu1").velocity({
			rotateZ: "135deg"
		},{
			duration:	2000
		});
		$("#cableS1_1").velocity({
			height: "17"
		},{
			duration:	2000
		});
		$("#cableS1_2").velocity({
			height: "257"
		},{
			duration:	2000
		});
		$("#peso1").velocity({
			top: "217"
		},{
			duration:	2000
		});
		$("#peso2").velocity({
			top: "417"
		},{
			duration:	2000
		});
	}else{
		//equilibrium
		/*$("#pcu1").velocity({
			rotateZ: "0deg"
		},{
			duration:	2000
		});
		$("#cableS1_1").velocity({
			height: "137"
		},{
			duration:	2000
		});
		$("#cableS1_2").velocity({
			height: "137"
		},{
			duration:	2000
		});
		$("#peso1").velocity({
			top: "336"
		},{
			duration:	2000
		});
		$("#peso2").velocity({
			top: "336"
		},{
			duration:	2000
		});*/
		
	}
}

function equilibrarA(){
	$("#res1").css("display","none");
	$("#res2").css("display","none");
	$("#slide1").css("top","21px");
	$("#slide2").css("top","21px");
	$("#f1").html("4 N");
	$("#f2").html("4 N");

	$("#pcu1").velocity("stop");
	$("#cableS1_1").velocity("stop");
	$("#cableS1_2").velocity("stop");
	$("#peso1").velocity("stop");
	$("#peso2").velocity("stop");

	$("#pcu1").velocity({
		rotateZ: "0deg"
	},{
		duration:	0
	});
	$("#cableS1_1").velocity({
		height: "137"
	},{
		duration:	0
	});
	$("#cableS1_2").velocity({
		height: "137"
	},{
		duration:	0
	});
	$("#peso1").velocity({
		top: "336"
	},{
		duration:	0
	});
	$("#peso2").velocity({
		top: "336"
	},{
		duration:	0
	});
}

function moveSystem2(){
	$("#res3").css("display","block");
	$("#res4").css("display","block");

	$("#pcu2").velocity("stop");
	$("#pcd1").velocity("stop");
	$("#pd1").velocity("stop");
	$("#cableS2_1").velocity("stop");
	$("#cableS2_2").velocity("stop");
	$("#cableS2_3").velocity("stop");
	$("#peso3").velocity("stop");
	$("#peso4").velocity("stop");
	
	if(f3>(2*f4)){
		//moveLeft
		$("#pcu2").velocity({
			rotateZ: "-135deg"
		},{
			duration:	2000
		});
		$("#pcd1").velocity({
			rotateZ: "135deg"
		},{
			duration:	2000
		});
		$("#pd1").velocity({
			top: "300"
		},{
			duration:	2000
		});
		$("#peso3").velocity({
			top: "401"
		},{
			duration:	2000
		});
		$("#cableS2_1").velocity({
			height: "190"
		},{
			duration:	2000
		});
		$("#cableS2_2").velocity({
			height: "125"
		},{
			duration:	2000
		});
		$("#cableS2_3").velocity({
			height: "17"
		},{
			duration:	2000
		});
		$("#peso4").velocity({
			top: "217"
		},{
			duration:	2000
		});
		
	}else if(f3<(2*f4)){
		//moveRight	
		$("#pcu2").velocity({
			rotateZ: "135deg"
		},{
			duration:	2000
		});
		$("#pcd1").velocity({
			rotateZ: "-135deg"
		},{
			duration:	2000
		});
		$("#pd1").velocity({
			top: "200"
		},{
			duration:	2000
		});
		$("#peso3").velocity({
			top: "301"
		},{
			duration:	2000
		});
		$("#cableS2_1").velocity({
			height: "100"
		},{
			duration:	2000
		});
		$("#cableS2_2").velocity({
			height: "25"
		},{
			duration:	2000
		});
		$("#cableS2_3").velocity({
			height: "228"
		},{
			duration:	2000
		});
		$("#peso4").velocity({
			top: "427"
		},{
			duration:	2000
		});
	
	}else{
		//equilibrium
		
	}
}


function equilibrarB(){
	$("#res3").css("display","none");
	$("#res4").css("display","none");
	$("#slide3").css("top","13px");
	$("#slide4").css("top","25px");
	$("#f3").html("6 N");
	$("#f4").html("3 N");

	$("#pcu2").velocity("stop");
	$("#pcd1").velocity("stop");
	$("#pd1").velocity("stop");
	$("#cableS2_1").velocity("stop");
	$("#cableS2_2").velocity("stop");
	$("#cableS2_3").velocity("stop");
	$("#peso3").velocity("stop");
	$("#peso4").velocity("stop");

	$("#pcu2").velocity({
		rotateZ: "0deg"
	},{
		duration:	0
	});
	$("#pcd1").velocity({
		rotateZ: "0deg"
	},{
		duration:	0
	});
	$("#pd1").velocity({
		top: "235"
	},{
		duration:	0
	});
	$("#peso3").velocity({
		top: "336"
	},{
		duration:	0
	});
	$("#cableS2_1").velocity({
		height: "130"
	},{
		duration:	0
	});
	$("#cableS2_2").velocity({
		height: "55"
	},{
		duration:	0
	});
	$("#cableS2_3").velocity({
		height: "137"
	},{
		duration:	0
	});
	$("#peso4").velocity({
		top: "336"
	},{
		duration:	0
	});
}

function moveSystem3(){
	$("#res5").css("display","block");
	$("#res6").css("display","block");
	
	$("#pcu3").velocity("stop");
	$("#pcu4").velocity("stop");
	$("#pcd2").velocity("stop");
	$("#pcd3").velocity("stop");
	$("#pd2").velocity("stop");
	$("#pd3").velocity("stop");
	$("#cableS3_1").velocity("stop");
	$("#cableS3_2").velocity("stop");
	$("#cableS3_3").velocity("stop");
	$("#cableS3_4").velocity("stop");
	$("#cableS3_5").velocity("stop");
	$("#peso5").velocity("stop");
	$("#peso6").velocity("stop");
	
	if(f5>(4*f6)){
		//moveLeft
		$("#pcu3").velocity({
			rotateZ: "-135deg"
		},{
			duration:	2000
		});
		$("#pcd2").velocity({
			rotateZ: "135deg"
		},{
			duration:	2000
		});
		$("#pcu4").velocity({
			rotateZ: "-135deg"
		},{
			duration:	2000
		});
		$("#pcd3").velocity({
			rotateZ: "135deg"
		},{
			duration:	2000
		});
		$("#pd2").velocity({
			top: "260"
		},{
			duration:	2000
		});
		$("#pd3").velocity({
			top: "260"
		},{
			duration:	2000
		});
		$("#peso5").velocity({
			top: "361"
		},{
			duration:	2000
		});
		$("#cableS3_1").velocity({
			height: "150"
		},{
			duration:	2000
		});
		$("#cableS3_2").velocity({
			height: "85"
		},{
			duration:	2000
		});
		$("#cableS3_3").velocity({
			height: "85"
		},{
			duration:	2000
		});
		$("#cableS3_4").velocity({
			height: "85"
		},{
			duration:	2000
		});
		$("#cableS3_5").velocity({
			height: "17"
		},{
			duration:	2000
		});
		$("#peso6").velocity({
			top: "217"
		},{
			duration:	2000
		});
		
	}else if(f5<(4*f6)){
		//moveRight	
		$("#pcu3").velocity({
			rotateZ: "135deg"
		},{
			duration:	2000
		});
		$("#pcd2").velocity({
			rotateZ: "-135deg"
		},{
			duration:	2000
		});
		$("#pcu4").velocity({
			rotateZ: "135deg"
		},{
			duration:	2000
		});
		$("#pcd3").velocity({
			rotateZ: "-135deg"
		},{
			duration:	2000
		});
		$("#pd2").velocity({
			top: "195"
		},{
			duration:	2000
		});
		$("#pd3").velocity({
			top: "195"
		},{
			duration:	2000
		});
		$("#peso5").velocity({
			top: "296"
		},{
			duration:	2000
		});
		$("#cableS3_1").velocity({
			height: "90"
		},{
			duration:	2000
		});
		$("#cableS3_2").velocity({
			height: "15"
		},{
			duration:	2000
		});
		$("#cableS3_3").velocity({
			height: "15"
		},{
			duration:	2000
		});
		$("#cableS3_4").velocity({
			height: "15"
		},{
			duration:	2000
		});
		$("#cableS3_5").velocity({
			height: "237"
		},{
			duration:	2000
		});
		$("#peso6").velocity({
			top: "436"
		},{
			duration:	2000
		});
	
	}else{
		//equilibrium
		
	}
}


function equilibrarC(){
	$("#res5").css("display","none");
	$("#res6").css("display","none");
	$("#slide5").css("top","7px");
	$("#slide6").css("top","27px");
	$("#f5").html("8 N");
	$("#f6").html("2 N");

	$("#pcu3").velocity("stop");
	$("#pcu4").velocity("stop");
	$("#pcd2").velocity("stop");
	$("#pcd3").velocity("stop");
	$("#pd2").velocity("stop");
	$("#pd3").velocity("stop");
	$("#cableS3_1").velocity("stop");
	$("#cableS3_2").velocity("stop");
	$("#cableS3_3").velocity("stop");
	$("#cableS3_4").velocity("stop");
	$("#cableS3_5").velocity("stop");
	$("#peso5").velocity("stop");
	$("#peso6").velocity("stop");

	$("#pcu3").velocity({
		rotateZ: "0deg"
	},{
		duration:	0
	});
	$("#pcd2").velocity({
		rotateZ: "0deg"
	},{
		duration:	0
	});
	$("#pcu4").velocity({
		rotateZ: "0deg"
	},{
		duration:	0
	});
	$("#pcd3").velocity({
		rotateZ: "0deg"
	},{
		duration:	0
	});
	$("#pd2").velocity({
		top: "235"
	},{
		duration:	0
	});
	$("#pd3").velocity({
		top: "235"
	},{
		duration:	0
	});
	$("#peso5").velocity({
		top: "336"
	},{
		duration:	0
	});
	$("#cableS3_1").velocity({
		height: "130"
	},{
		duration:	0
	});
	$("#cableS3_2").velocity({
		height: "55"
	},{
		duration:	0
	});
	$("#cableS3_3").velocity({
		height: "55"
	},{
		duration:	0
	});
	$("#cableS3_4").velocity({
		height: "55"
	},{
		duration:	0
	});
	$("#cableS3_5").velocity({
		height: "137"
	},{
		duration:	0
	});
	$("#peso6").velocity({
		top: "336"
	},{
		duration:	0
	});
}

function iniciar(){
	if(!iniciat){	
		iniciat = true;
	
			
	}
}

function reiniciar(){
	equilibrarA();
	equilibrarB();
	equilibrarC();
}