window.onresize = resize;
var scale 	= 1;
var mgLeft	= 0;
var mgTop	= 0;
var iniciat = false;

var flechaM;

/*
	SCENES
	earth	= 1
	moon 	= 2
	both 	= 3
*/
var scene = 1;
var canChange = true;

$(document).ready(function(){
	resize();
	initialize();
});

function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}

function restart(){
	resetScene(1);
	resetScene(2);
	resetScene(3);
}

function initialize(){	
	iniciat = false;
	//scene = 1;
}

function showEarth(){
	if(canChange){
		scene = 1;
		$("#earth").css("display","block");
		$("#moon").css("display","none");
		$("#bothEM").css("display","none");
		
		$("#btTierra").css("display","none");
		$("#btLuna").css("display","inline");
		$("#btAmbos").css("display","inline");
		
		$("#titulo").css("color","#000000");
		
		resetScene(2);
		resetScene(3);
	}
}
function showMoon(){
	if(canChange){
		scene = 2;
		$("#earth").css("display","none");
		$("#moon").css("display","block");
		$("#bothEM").css("display","none");
		
		$("#btTierra").css("display","inline");
		$("#btLuna").css("display","none");
		$("#btAmbos").css("display","inline");
		
		$("#titulo").css("color","#ffffff");	
		
		resetScene(1);
		resetScene(3);
	}
}
function showBoth(){
	if(canChange){
		scene = 3;
		$("#earth").css("display","none");
		$("#moon").css("display","none");
		$("#bothEM").css("display","block");
		
		$("#btTierra").css("display","inline");
		$("#btLuna").css("display","inline");
		$("#btAmbos").css("display","none");
		
		$("#titulo").css("color","#ffffff");
		
		resetScene(1);
		resetScene(2);
	}
}

function resetScene(id){
	$("#btPlay").css("display","inline-block");
	switch(id){
		case 1:
			$("#downArrow1").css("display", "none");
			$("#downArrow2").css("display", "none");
			$("#downArrow3").css("display", "none");
			$("#downArrow1").css("top", "150px");
			$("#downArrow2").css("top", "150px");
			$("#downArrow3").css("top", "150px");
			
			$("#upArrow1").css("top", "92px");
			$("#upArrow2").css("top", "111px");
			$("#upArrow3").css("top", "125px");
			
			$("#formV1").css("top", "190px");
			$("#formV2").css("top", "190px");
			$("#formV3").css("top", "190px");
			
			$("#h1").attr("src", "images/hand.png");
			$("#h1").css("width", "100px");
			$("#h1").css("left", "220px");
			
			$("#h2").attr("src", "images/hand.png");
			$("#h2").css("width", "100px");
			$("#h2").css("left", "435px");
			
			$("#h3").attr("src", "images/hand.png");
			$("#h3").css("width", "100px");
			$("#h3").css("left", "650px");
			
			$("#metal1").velocity({	rotateZ: "0deg",	top:	"113px"	},0);
			$("#wood1").velocity({	rotateZ: "0deg",	top:	"115px"	},0);
			$("#paper1").velocity({	rotateZ: "0deg",	top:	"113px"	},0);
			break;
		case 2:
			$("#downArrow4").css("display", "none");
			$("#downArrow5").css("display", "none");
			$("#downArrow6").css("display", "none");
			$("#downArrow4").css("top", "150px");
			$("#downArrow5").css("top", "150px");
			$("#downArrow6").css("top", "150px");
			
			$("#v1").velocity({ scale:	1,	top:	"140px",	left:	"259px"	},0);
			$("#v2").velocity({ scale:	1,	top:	"140px",	left:	"475px"	},0);
			$("#v3").velocity({ scale:	1,	top:	"140px",	left:	"689px"	},0);
			
			$("#v1").css("display", "none");
			$("#v2").css("display", "none");
			$("#v3").css("display", "none");
			
			$("#h4").attr("src", "images/hand.png");
			$("#h4").css("width", "100px");
			$("#h4").css("left", "220px");
			
			$("#h5").attr("src", "images/hand.png");
			$("#h5").css("width", "100px");
			$("#h5").css("left", "435px");
			
			$("#h6").attr("src", "images/hand.png");
			$("#h6").css("width", "100px");
			$("#h6").css("left", "650px");
			
			$("#metal2").velocity({	rotateZ: "0deg",	top:	"113px"	},0);
			$("#wood2").velocity({	rotateZ: "0deg",	top:	"115px"	},0);
			$("#paper2").velocity({	rotateZ: "0deg",	top:	"113px"	},0);
			break;
		case 3:
			$("#downArrow10").css("display", "none");
			$("#downArrow11").css("display", "none");
			$("#downArrow12").css("display", "none");
			$("#downArrow10").css("top", "150px");
			$("#downArrow11").css("top", "150px");
			$("#downArrow12").css("top", "150px");
			
			$("#upArrow4").css("top", "92px");
			$("#upArrow5").css("top", "111px");
			$("#upArrow6").css("top", "125px");
			
			$("#formV4").css("top", "190px");
			$("#formV5").css("top", "190px");
			$("#formV6").css("top", "190px");
			
			$("#downArrow7").css("display", "none");
			$("#downArrow8").css("display", "none");
			$("#downArrow9").css("display", "none");
			$("#downArrow7").css("top", "150px");
			$("#downArrow8").css("top", "150px");
			$("#downArrow9").css("top", "150px");
			
			$("#v4").velocity({ scale:	1,	top:	"140px",	left:	"110px"	},0);
			$("#v5").velocity({ scale:	1,	top:	"140px",	left:	"242px"	},0);
			$("#v6").velocity({ scale:	1,	top:	"140px",	left:	"371px"	},0);
			
			$("#v4").css("display", "none");
			$("#v5").css("display", "none");
			$("#v6").css("display", "none");
			
			$("#h7").attr("src", "images/hand.png");
			$("#h7").css("width", "100px");
			$("#h7").css("left", "70px");
			
			$("#h8").attr("src", "images/hand.png");
			$("#h8").css("width", "100px");
			$("#h8").css("left", "200px");
			
			$("#h9").attr("src", "images/hand.png");
			$("#h9").css("width", "100px");
			$("#h9").css("left", "330px");
			
			$("#h10").attr("src", "images/hand.png"); 
			$("#h10").css("width", "100px");
			$("#h10").css("left", "520px");
			
			$("#h11").attr("src", "images/hand.png");
			$("#h11").css("width", "100px");
			$("#h11").css("left", "650px");
			
			$("#h12").attr("src", "images/hand.png");
			$("#h12").css("width", "100px");
			$("#h12").css("left", "780px");
			
			$("#metal3").velocity({	rotateZ: "0deg",	top:	"113px"	},0);
			$("#wood3").velocity({	rotateZ: "0deg",	top:	"115px"	},0);
			$("#paper3").velocity({	rotateZ: "0deg",	top:	"113px"	},0);
			
			$("#metal4").velocity({	rotateZ: "0deg",	top:	"113px"	},0);
			$("#wood4").velocity({	rotateZ: "0deg",	top:	"115px"	},0);
			$("#paper4").velocity({	rotateZ: "0deg",	top:	"113px"	},0);
			break;
	}
}

function iniciar(){
	if(!iniciat){
		$("#btPlay").css("display","none");
		canChange = false;
		switch(scene){
			case 1:
				$("#h1").attr("src", "images/hand_open.png");
				$("#h1").css("width", "110px");
				$("#h1").css("left", "215px");
	
				$("#h2").attr("src", "images/hand_open.png");
				$("#h2").css("width", "110px");
				$("#h2").css("left", "430px");
				
				$("#h3").attr("src", "images/hand_open.png");
				$("#h3").css("width", "110px");
				$("#h3").css("left", "645px");
				
				$("#downArrow1").css("display", "block");
				$("#downArrow2").css("display", "block");
				$("#downArrow3").css("display", "block");
				
				$("#metal1").velocity({	rotateZ: "360deg",	top:	"383px"	},1500,"easeInCubic");
				$("#wood1").velocity({	rotateZ: "360deg",	top:	"383px"	},2000,"easeInCubic");
				$("#paper1").velocity({	rotateZ: "360deg",	top:	"383px"	},2500,"easeInCubic");
				
				$("#downArrow1").velocity({	top:	"420px"	},1500,"easeInCubic");
				$("#downArrow2").velocity({	top:	"420px"	},2000,"easeInCubic");
				$("#downArrow3").velocity({	top:	"420px"	},2500,"easeInCubic");
				
				
				
				$("#upArrow1").velocity({	top:	"362px"	},1500,"easeInCubic");
				$("#upArrow2").velocity({	top:	"381px"	},2000,"easeInCubic");
				$("#upArrow3").velocity({	top:	"395px"	},2500,"easeInCubic");
				
				$("#formV1").velocity({	top:	"452px"	},1500,"easeInCubic");
				$("#formV2").velocity({	top:	"452px"	},2000,"easeInCubic");
				$("#formV3").velocity({	top:	"452px"	},2500,"easeInCubic");
				
				setTimeout(function(){	
										$("#upArrow1").css("display","block");
										$("#formV1").css("display","block");
									},1200);
				setTimeout(function(){	
										$("#upArrow2").css("display","block");	
										$("#formV2").css("display","block");
									},1000);
				setTimeout(function(){
										$("#upArrow3").css("display","block");	
										$("#formV3").css("display","block");
									},800);
				
				setTimeout(function(){	
										$("#upArrow1").css("display","none");	
										$("#formV1").css("display","none");
									},1500);
				setTimeout(function(){
										$("#upArrow2").css("display","none");	
										$("#formV2").css("display","none");
									},2000);
				setTimeout(function(){	
										$("#upArrow3").css("display","none");	
										$("#formV3").css("display","none");
									},2500);
									
				setTimeout(function(){
					canChange = true;
				},2500);
				
				break;
			case 2:
				$("#h4").attr("src", "images/hand_open.png");
				$("#h4").css("width", "110px");
				$("#h4").css("left", "215px");
				
				$("#h5").attr("src", "images/hand_open.png");
				$("#h5").css("width", "110px");
				$("#h5").css("left", "430px");
				
				$("#h6").attr("src", "images/hand_open.png");
				$("#h6").css("width", "110px");
				$("#h6").css("left", "645px");
				
				$("#downArrow4").css("display", "block");
				$("#downArrow5").css("display", "block");
				$("#downArrow6").css("display", "block");
				
				$("#metal2").velocity({ rotateZ: "360deg",	top:	"383px"	},5000,"linear");
				$("#wood2").velocity({ rotateZ: "360deg",	top:	"383px"	},5000,"linear");
				$("#paper2").velocity({	rotateZ: "360deg",	top:	"383px"	},5000,"linear");
				
				$("#downArrow4").velocity({	top:	"420px"	},5000,"linear");
				$("#downArrow5").velocity({	top:	"420px"	},5000,"linear");
				$("#downArrow6").velocity({	top:	"420px"	},5000,"linear");
				
				setTimeout(function(){
					$("#v1").css("display","block");
					$("#v2").css("display","block");
					$("#v3").css("display","block");
					
					$("#v1").velocity({ scale:	2.5,	top:	"310px",	left:	"247px"	},3500,"linear");
					$("#v2").velocity({ scale:	2.5,	top:	"310px",	left:	"462px"	},3500,"linear");
					$("#v3").velocity({ scale:	2.5,	top:	"310px",	left:	"676px"	},3500,"linear");
				},1500);
				
				setTimeout(function(){
					canChange = true;
				},5000);
				
				break;
			case 3:
				$("#h7").attr("src", "images/hand_open.png");
				$("#h7").css("width", "110px");
				$("#h7").css("left", "65px");
				
				$("#h8").attr("src", "images/hand_open.png");
				$("#h8").css("width", "110px");
				$("#h8").css("left", "195px");
				
				$("#h9").attr("src", "images/hand_open.png");
				$("#h9").css("width", "110px");
				$("#h9").css("left", "325px");
				
				$("#h10").attr("src", "images/hand_open.png");
				$("#h10").css("width", "110px");
				$("#h10").css("left", "515px");
				
				$("#h11").attr("src", "images/hand_open.png");
				$("#h11").css("width", "110px");
				$("#h11").css("left", "645px");
				
				$("#h12").attr("src", "images/hand_open.png");
				$("#h12").css("width", "110px");
				$("#h12").css("left", "775px");
				
				$("#downArrow7").css("display", "block");
				$("#downArrow8").css("display", "block");
				$("#downArrow9").css("display", "block");
				$("#downArrow10").css("display", "block");
				$("#downArrow11").css("display", "block");
				$("#downArrow12").css("display", "block");
				
				
				$("#metal3").velocity({	rotateZ: "360deg",	top:	"383px"	},5000,"linear");
				$("#wood3").velocity({	rotateZ: "360deg",	top:	"383px"	},5000,"linear");
				$("#paper3").velocity({	rotateZ: "360deg",	top:	"383px"	},5000,"linear");
				
				$("#metal4").velocity({ rotateZ: "360deg",	top:	"383px"	},1500,"easeInCubic");
				$("#wood4").velocity({	rotateZ: "360deg",	top:	"383px"	},2000,"easeInCubic");
				$("#paper4").velocity({ rotateZ: "360deg",	top:	"383px"	},2500,"easeInCubic");
							
				$("#downArrow7").velocity({	top:	"420px"	},5000,"linear");
				$("#downArrow8").velocity({	top:	"420px"	},5000,"linear");
				$("#downArrow9").velocity({	top:	"420px"	},5000,"linear");
				$("#downArrow10").velocity({	top:	"420px"	},1500,"easeInCubic");
				$("#downArrow11").velocity({	top:	"420px"	},2000,"easeInCubic");
				$("#downArrow12").velocity({	top:	"420px"	},2500,"easeInCubic");
				
				$("#upArrow4").velocity({	top:	"362px"	},1500,"easeInCubic");
				$("#upArrow5").velocity({	top:	"381px"	},2000,"easeInCubic");
				$("#upArrow6").velocity({	top:	"395px"	},2500,"easeInCubic");
				
				$("#formV4").velocity({	top:	"452px"	},1500,"easeInCubic");
				$("#formV5").velocity({	top:	"452px"	},2000,"easeInCubic");
				$("#formV6").velocity({	top:	"452px"	},2500,"easeInCubic");
				
				setTimeout(function(){	
										$("#upArrow4").css("display","block");	
										$("#formV4").css("display","block");
									},1200);
				setTimeout(function(){	
										$("#upArrow5").css("display","block");	
										$("#formV5").css("display","block");
									},1000);
				setTimeout(function(){	
										$("#upArrow6").css("display","block");
										$("#formV6").css("display","block");
									},800);
				
				setTimeout(function(){
										$("#upArrow4").css("display","none");
										$("#formV4").css("display","none");
									},1500);
				setTimeout(function(){	
										$("#upArrow5").css("display","none");	
										$("#formV5").css("display","none");
									},2000);
				setTimeout(function(){	
										$("#upArrow6").css("display","none");	
										$("#formV6").css("display","none");
									},2500);
				
				setTimeout(function(){
					$("#v4").css("display","block");
					$("#v5").css("display","block");
					$("#v6").css("display","block");
					
					$("#v4").velocity({ scale:	2.5,	top:	"310px",	left:	"95px"	},3500,"linear");
					$("#v5").velocity({ scale:	2.5,	top:	"310px",	left:	"227px"	},3500,"linear");
					$("#v6").velocity({ scale:	2.5,	top:	"310px",	left:	"356px"	},3500,"linear");
				},1500);				
				
				setTimeout(function(){
					canChange = true;
				},5000);
				
				break;
		}
	}
}

function reiniciar(){
	if(canChange){
		iniciat = false;
		restart();
		initialize();
	}
}