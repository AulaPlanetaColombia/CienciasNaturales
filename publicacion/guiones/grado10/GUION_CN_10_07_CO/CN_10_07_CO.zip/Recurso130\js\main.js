window.onresize = resize;
var scale 	= 1;

var waterRel;

var canvas;
var canvasW;
var canvasH;

$(document).ready(function(){
	
	initialize();
	resize();
});

function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
	
	canvas.wScale = scale;
	if(scale >1){
		canvas.width = canvasW * scale;
		canvas.height = canvasH * scale;
	}
}

var terrain,water,scales1,scales2,cube1,cube2,waterLevel;
var maxWaterLevel;
var nameCube1,nameCube2,massCube1,massCube2,bgText1,bgText2,txtNewtons1,txtNewtons2;
var totalWeight1, totalWeight2;
var showing2Bloques;

function initialize(){
	$("#contentCanvas").css('-ms-touch-action', 'none');
	showing2Bloques = false;
	maxWaterLevel = 362;
	waterRel = 100/145;
	canvas = oCanvas.create({	canvas: "#contentCanvas", wScale: scale	});
	canvasW = canvas.width;
	canvasH = canvas.height;
	
	terrain = canvas.display.image({
		x:-1,
		y:306,		
		origin: { x: "left", y: "top" },
		image: "images/terrain.png",
		initx: -1,
		inity: 306
	}); 

	water = canvas.display.rectangle({
		x: 285,
		y: 362,
		opacity:0.4,
		width: 390,
		height: 600,
		fill: "#B6D3E0",
		initx: 285,
		inity: 362,
		density: 1
	});
	
	scales1 = canvas.display.image({
		x:55,
		y:278,		
		origin: { x: 0, y: 0 },
		image: "images/scales.png",
		initx: 55,
		inity: 278,
		volume: 7.83,
		submerged: false,
		lasty:278,
		direction: "up",
		name: "scales1",
		over: [],
		falling: false,
		floats:	false,
		mass:	2.96,
		floating: false,
		floaty: 464,
		underwater: 0
	});

	txtNewtons1 = canvas.display.text({
		x: 95,
		y: 286,
		initx: 95,
		inity: 286,
		origin: { x: "center", y: "top" },
		font: "17px Verdana",
		text: "0 N",
		fill: "#000000"
	});
	
	scales2 = canvas.display.image({
		x:800,
		y:278,		
		origin: { x: 0, y: 0 },
		image: "images/scales.png",
		initx: 800,
		inity: 278,
		volume: 7.83,
		submerged: false,
		lasty:278,
		direction: "up",
		name: "scales2",
		over: [],
		falling: false,
		floats:	false,
		mass:	2.96,
		floating: false,
		floaty: 464,
		underwater: 0
	});

	txtNewtons2 = canvas.display.text({
		x: 840,
		y: 286,
		initx: 840,
		inity: 286,
		origin: { x: "center", y: "top" },
		font: "17px Verdana",
		text: "0 N",
		fill: "#000000"
	});

	cube1 = canvas.display.image({
		x:180,
		y:278,		
		origin: { x: 0, y: 49 },
		image: "images/wood.png",
		width: 78,
		height:78,
		initx: 180,
		inity: 278,
		volume: 7.25,
		submerged: false,
		lasty:278,
		direction: "up",
		name: "cube1",
		over: [],
		falling: false,
		floats:	true,
		mass:	2.95,
		size:	2,
		material: 1,
		density: 0.59,
		floatPercent: 59,
		floating: false,
		floaty: 464,
		underwater: 0
	});




	nameCube1 = canvas.display.text({
		x: 192,
		y: 235,
		initx: 192,
		inity: 235,
		origin: { x: "center", y: "top" },
		font: "bold 18px Verdana",
		text: "A",
		fill: "#ffffff"
	});
	bgText1 = canvas.display.rectangle({
		x: 180,
		y: 287,
		opacity:0.4,
		width: 78,
		height: 20,
		fill: "#ffffff",
		initx: 180,
		inity: 287
	});
	massCube1 = canvas.display.text({
		x: 216,
		y: 292,
		initx: 216,
		inity: 292,
		origin: { x: "center", y: "top" },
		font: "bold 12px Verdana",
		text: "5 kg",
		fill: "#000000"
	});


	cube2 = canvas.display.image({
		x:690,	
		y:278,		
		origin: { x: 0, y: 49 },
		image: "images/wood.png",
		width: 78,
		height:78,
		initx: 690,
		inity: 278,
		volume: 7.25,
		submerged: false,
		lasty:278,
		direction: "up",
		name: "cube2",
		over: [],
		falling: false,
		floats:	true,
		mass:	2.95,
		size:	2,
		material: 1,
		density: 0.59,
		floatPercent: 59,
		floating: false,
		floaty: 464,
		underwater: 0
	});

	nameCube2 = canvas.display.text({
		x: 702,
		y: 235,
		initx: 702,
		inity: 235,
		origin: { x: "center", y: "top" },
		font: "bold 18px Verdana",
		text: "B",
		fill: "#ffffff"
	});
	bgText2 = canvas.display.rectangle({
		x: 690,
		y: 287,
		opacity:0.4,
		width: 78,
		height: 20,
		fill: "#ffffff",
		initx: 690,
		inity: 287
	});
	massCube2 = canvas.display.text({
		x: 726,
		y: 292,
		initx: 726,
		inity: 292,
		origin: { x: "center", y: "top" },
		font: "bold 12px Verdana",
		text: "5 kg",
		fill: "#000000"
	});
	
	waterLevel = canvas.display.text({
		x: 750,
		y: 350,
		origin: { x: "center", y: "top" },
		font: "bold 24px sans-serif",
		text: "100 m"+String.fromCharCode(179),
		fill: "#ffffff"
	});
	setTimeout(function(){
		canvas.addChild(water);
		canvas.addChild(terrain);
		canvas.addChild(waterLevel);

		canvas.addChild(scales1);
		canvas.addChild(txtNewtons1);
		canvas.addChild(scales2);
		canvas.addChild(txtNewtons2);
		canvas.addChild(cube1);
		canvas.addChild(nameCube1);
		canvas.addChild(bgText1);
		canvas.addChild(massCube1);
	},1000);
	
	/*canvas.addChild(cube2);
	canvas.addChild(nameCube2);
	canvas.addChild(bgText2);
	canvas.addChild(massCube2);*/
	
	scales1.dragAndDrop({
		bubble: true,
		start: function () {
			this.falling = false;
		},
		move: function () {
			fixAllPositions();
			moveAllOver();
			//checkDirection(this);
			setWater(this);
			setTextPosition();
			setMaxWaterLevel();
			setUnderwater();
		},
		end: function () {
			this.falling = true;
		}
	},scale);
	scales2.dragAndDrop({
		start: function () {
			this.falling = false;
		},
		move: function () {
			fixAllPositions();
			moveAllOver();
			//checkDirection(this);
			setWater(this);
			setTextPosition();
			setMaxWaterLevel();
			setUnderwater();
		},
		end: function () {
			this.falling = true;
		}
	},scale);
	cube1.dragAndDrop({
		start: function () {
			this.falling = false;
		},
		move: function () {
			fixAllPositions();
			moveAllOver();
			//checkDirection(this);
			setWater(this);
			setTextPosition();
			setMaxWaterLevel();
			setUnderwater();
		},
		end: function () {
			this.falling = true;
		}
	},scale);
	cube2.dragAndDrop({
		start: function () {
			this.falling = false;
		},
		move: function () {
			fixAllPositions();
			moveAllOver();
			//checkDirection(this);
			setWater(this);
			setTextPosition();
			setMaxWaterLevel();
			setUnderwater();
		},
		end: function () {
			this.falling = true;
			//applyGravity(this);
		}
	},scale);

	applyGravity();
	actualizarInfo();
}

function elementMove(element){	
	fixAllPositions();
	moveAllOver();
	checkDirection(element);
	setWater(element);
	setTextPosition();
	checkContact(element);
	setMaxWaterLevel();
	setUnderwater();
}

function setUnderwater(){
	if(cube1.submerged) {
		var c1u = Math.abs((cube1.y + cube1.height - cube1.origin.y) - water.y);


		if (c1u > cube1.height) {
			c1u = cube1.height;
		}
		cube1.underwater = c1u/cube1.height;
	}else{
		cube1.underwater = 0;
	}
	if(cube2.submerged) {
		var c2u = Math.abs((cube2.y + cube2.height - cube2.origin.y) - water.y);
		if (c2u > cube2.height) {
			c2u = cube2.height;
		}
		cube2.underwater = c2u/cube2.height;
	}else{
		cube2.underwater = 0;
	}
	if(scales1.submerged) {
		var c3u = Math.abs((scales1.y) - water.y);
		if (c3u > 10) {
			c3u = 10
		}
		scales1.underwater = 1;
	}else{
		scales1.underwater = 0;
	}
	if(scales2.submerged) {
		var c4u = Math.abs((scales2.y) - water.y);
		if (c4u > 10) {
			c4u = 10;
		}
		scales2.underwater = 1;
	}else{
		scales2.underwater = 0;
	}




}
function setTextPosition(){	
		nameCube1.x = cube1.x+(nameCube1.initx-cube1.initx);
		nameCube1.y = cube1.y+(nameCube1.inity-cube1.inity);
		massCube1.x = cube1.x+(massCube1.initx-cube1.initx);
		massCube1.y = cube1.y+(massCube1.inity-cube1.inity);
		bgText1.x = cube1.x+(bgText1.initx-cube1.initx);
		bgText1.y = cube1.y+(bgText1.inity-cube1.inity);

		txtNewtons1.x = scales1.x+(txtNewtons1.initx-scales1.initx);
		txtNewtons1.y = scales1.y+(txtNewtons1.inity-scales1.inity);

		nameCube2.x = cube2.x+(nameCube2.initx-cube2.initx);
		nameCube2.y = cube2.y+(nameCube2.inity-cube2.inity);
		massCube2.x = cube2.x+(massCube2.initx-cube2.initx);
		massCube2.y = cube2.y+(massCube2.inity-cube2.inity);
		bgText2.x = cube2.x+(bgText2.initx-cube2.initx);
		bgText2.y = cube2.y+(bgText2.inity-cube2.inity);

		txtNewtons2.x = scales2.x+(txtNewtons2.initx-scales2.initx);
		txtNewtons2.y = scales2.y+(txtNewtons2.inity-scales2.inity);
}
function moveAllOver(){
	moveOver(scales1);
	moveOver(scales2);
	moveOver(cube1);
	moveOver(cube2);
}

function moveOver(element){
	for(var i=0;i<element.over.length;i++){
		if(element.over[i].dragging==false) {
			if (element.x >= (element.over[i].x - element.width) && element.x <= (element.over[i].x + element.width)) {
				//moveOver(element.over[i]);
				element.over[i].y = element.y - element.height;
			} else {
				element.over[i].falling = true;
				var index = element.over.indexOf(element.over[i]);
				if (index > -1) {
					element.over.splice(index, 1);
				}
			}
		}else{
			var index = element.over.indexOf(element.over[i]);
			if (index > -1) {
				element.over.splice(index, 1);
			}
		}
	}
}

var gLoop;
function applyGravity(){
	var speed = 1;
	var speedWater = 4;
	var speedAir = 15;


	gLoop = canvas.setLoop(function(){	
		if(scales1.falling){
			if((scales1.y +scales1.height-scales1.origin.y) <= water.y ){
				speed = speedAir;
			}else{
				speed = speedWater;
			}
			scales1.y = scales1.y+speed;
			fixAllPositions();
			moveAllOver();
			checkDirection(scales1);
			setWater(scales1);
			checkContact(scales1);
			setMaxWaterLevel();
			setUnderwater();
			setTextPosition();
		}
		

		if(scales2.falling){
			if((scales2.y +scales2.height-scales2.origin.y) <= water.y ){
				speed = speedAir;
			}else{
				speed = speedWater;
			}
			scales2.y = scales2.y+speed;
			fixAllPositions();
			moveAllOver();
			checkDirection(scales2);
			setWater(scales2);
			checkContact(scales2);
			setMaxWaterLevel();
			setUnderwater();
			setTextPosition();
		}
	
		
		
		if(cube1.falling){
			if((cube1.y +cube1.height-cube1.origin.y) <= water.y ){
				speed = speedAir;
			}else{
				speed = speedWater;
			}
			cube1.y = cube1.y+speed;
			fixAllPositions();
			moveAllOver();
			checkDirection(cube1);
			setWater(cube1);
			checkContact(cube1);
			setMaxWaterLevel();
			setUnderwater();
			setTextPosition();				
		}

		if(cube1.floating){
			if(cube1.y < cube1.floaty){
				cube1.y = cube1.y+speed;	
				if(cube1.y >= cube1.floaty){	
					cube1.y = cube1.floaty;	
				}					
			}else{
				cube1.y = cube1.y-speed;
				if(cube1.y <= cube1.floaty){	
					cube1.y = cube1.floaty;	
				}	
			}
			moveAllOver();
			checkDirection(cube1);
			setWater(cube1);
			checkContact(cube1);
			setMaxWaterLevel();
			setUnderwater();
			setTextPosition();					
		}


		if(cube2.falling){
			if((cube2.y +cube2.height-cube2.origin.y) <= water.y ){
				speed = speedAir;
			}else{
				speed = speedWater;
			}
			cube2.y = cube2.y+speed;
			fixAllPositions();
			moveAllOver();
			checkDirection(cube2);
			setWater(cube2);
			checkContact(cube2);
			setMaxWaterLevel();
			setUnderwater();
			setTextPosition();
		}
		if(cube2.floating){
			if(cube2.y < cube2.floaty){
				cube2.y = cube2.y+speed;	
				if(cube2.y >= cube2.floaty){	
					cube2.y = cube2.floaty;	
				}					
			}else{
				cube2.y = cube2.y-speed;
				if(cube2.y <= cube2.floaty){	
					cube2.y = cube2.floaty;	
				}	
			}
			moveAllOver();
			checkDirection(cube2);
			setWater(cube2);
			checkContact(cube2);
			setMaxWaterLevel();
			setUnderwater();
			setTextPosition();
		}

		totalWeight1 = 0;
		setWeight1(scales1);

		totalWeight2 = 0;
		setWeight2(scales2);


		
	}).start();
}

function setWeight1(element){
	if(element.over.length>0) {
		for (var i = 0; i < element.over.length; i++) {
			if(element.over[i].submerged) {
				//console.log(element.over[i].underwater);
				//totalWeight1 += element.over[i].mass*9.8+((element.over[i].volume*water.density*element.over[i].underwater*9.8));
				//totalWeight1 += ((-(element.over[i].mass*9.8*water.density)+(element.over[i].mass*9.8*element.over[i].density))/element.over[i].density);
				totalWeight1 += (element.over[i].mass*9.8)-element.over[i].underwater*((element.over[i].mass*9.8)*0.4*water.density);

			}else {
				totalWeight1 += element.over[i].mass*9.8;
			}

			setWeight1(element.over[i]);
		}

		totalWeight1 = Math.round(totalWeight1 * 100 / 100);
		txtNewtons1.text = totalWeight1 + " N";
	}else{
		if(element.name == "scales1") {

			txtNewtons1.text = totalWeight1 + " N";
		}
	}
}


function setWeight2(element){
	if(element.over.length>0) {
		for (var i = 0; i < element.over.length; i++) {
			if(element.over[i].submerged) {
				totalWeight2 += (element.over[i].mass*9.8)-element.over[i].underwater*((element.over[i].mass*9.8)*0.4*water.density);
			}else {
				totalWeight2 += element.over[i].mass*9.8;
			}

			setWeight2(element.over[i]);
		}

		totalWeight2 = Math.round(totalWeight2 * 100 / 100);
		txtNewtons2.text = totalWeight2 + " N";
	}else{
		if(element.name == "scales2") {

			txtNewtons2.text = totalWeight2 + " N";
		}
	}
}

function checkCollision(el1,el2){
		var isthere = false;
		for(var i=0; i<el1.over.length;i++){
			if(el1.over[i].name == el2.name){
				isthere = true;
			}
		}
		
		if(!isthere){
			var distX = Math.abs(el1.x - el2.x);
			var distY = Math.abs(el1.y - el2.y);

			if (distX > (el2.width)) {
				return false;
			}
			if (distY > (el2.height)) {
				return false;
			}

			if (distX <= (el2.width)) {
				return true;
			}
			if (distY <= (el2.height)) {
				return true;
			}
		}else{
			return false;
		}

	/*	var dx = distX - el2.width;
		var dy = distY - el2.height;
		return (dx * dx + dy * dy <= (el1.r * el1.r));*/
}

function pushElement(element,where){	
	var isthere = false;
	for(var i=0; i<where.over.length;i++){
		if(where.over[i].name == element.name){
			isthere = true;
		}
	}
	for(var i=0; i<element.over.length;i++){
		if(element.over[i].name == where.name){
			isthere = true;
		}
	}
	
	if(!isthere){
		where.over.push(element);
	}
}

function checkContact(element){
	if(element.name!="scales1"){
		//check contact with scales1
		if(checkCollision(element,scales1)){
			element.y = scales1.y-scales1.height;
			element.falling = false;
			pushElement(element,scales1);
		}


		/*if(element.x>=(scales1.x -element.width) && element.x<=(scales1.x+element.width)){
			if((element.y+30+element.origin.y)>=scales1.y && (element.y+30+element.origin.y)<=(scales1.y+scales1.height)){
				element.y = scales1.y-scales1.height;
				element.falling = false;
				scales1.over.push(element);
			}
		}*/
	}
	if(element.name!="scales2"){
		//check contact with scales2
		if(checkCollision(element,scales2)){
			element.y = scales2.y-scales2.height;
			element.falling = false;
			pushElement(element,scales2);
		}
	}
	if(element.name!="cube1"){
		//check contact with cube1
		if(checkCollision(element,cube1)){
			element.y = cube1.y-cube1.height;
			element.falling = false;
			pushElement(element,cube1);
		}
	}
	if(element.name!="cube2"){
		//check contact with cube2
		if(checkCollision(element,cube2)){
			element.y = cube2.y-cube2.height;
			element.falling = false;
			pushElement(element,cube2);
		}
	}
	fixAllPositions();
}
function fixAllPositions(){
	fixPosInContainer(scales1);
	fixPosInContainer(scales2);
	fixPosInContainer(cube1);
	fixPosInContainer(cube2);
}


function fixPosInContainer(element){
	if(element.x<285 && element.y>278){
		element.y = 278;
		element.falling = false;
		element.floating = false;
		if(element.submerged){
			element.submerged = false;
			water.y = water.y+element.volume;
			setWaterLevel();
		}
	}
	if(element.x>591 && element.y>278){
		element.y = 278;
		element.falling = false;
		element.floating = false;
		if(element.submerged){
			element.submerged = false;
			water.y = water.y+element.volume;			
			setWaterLevel();
		}
	}
	if(element.floats){		
		var floatingY = 464.8;
		if(element.dragging == false){
			if(element.floatPercent<100){
				floatingY = maxWaterLevel +	(element.height*element.floatPercent/100)- element.height/2 + 10*element.density;
				for(var i = 0; i< element.over.length;i++) {
					floatingY += (element.over[i].height * element.over[i].floatPercent / 100) - element.over[i].height / 2;
				}
			}
			if(floatingY>463.8) {
				floatingY=463.8;
			}

			//floatingY+=10;
			//console.log(floatingY);
		}
		if(element.x>285 && element.x<=591 && element.y>=floatingY){
			//element.y = floatingY;
			element.floaty = floatingY;
			element.floating = true;
			element.falling = false;
			return 1;
		}else if(element.x>285 && element.x<=591 && element.y<floatingY){
			element.floaty = floatingY;
			if(!element.dragging){
				element.floating = false;
				element.falling = true;
			}
		}
	}else{
		if(element.x>285 && element.x<=591 && element.y>464.8){
			element.y = 464.8;
			element.falling = false;
		}
	}
}

function checkDirection(element){
	if(element.y < element.lasty){
		element.direction = "up";
	}else if(element.y > element.lasty){
		element.direction = "down";
	}else{
		element.direction = "still";
	}
	element.lasty = element.y;
}

function setWaterLevel(){
	var newLevel = ((water.inity-water.y)*waterRel)+100;
	waterLevel.text = (Math.round((newLevel)*10)/10) + " m"+String.fromCharCode(179);
}

function setMaxWaterLevel(){
	maxWaterLevel=362;
	if(scales1.submerged){
		maxWaterLevel-=scales1.volume;
	}
	if(scales2.submerged){
		maxWaterLevel-=scales2.volume;
	}
	if(cube1.submerged){
		maxWaterLevel-=cube1.volume;
	}
	if(cube2.submerged){
		maxWaterLevel-=cube2.volume;
	}
}

function setWater(element){
	
	/*if(element.submerged){
		water.y = maxWaterLevel + element.volume - (0);
	}*/

	var ySum = element.volume/element.height;
	if((element.y +element.height-element.origin.y) <= water.y ){
		//element over water
		element.submerged = false;
		setMaxWaterLevel();
		water.y = maxWaterLevel;
		setWaterLevel();
	}else if((element.y +element.height-element.origin.y) > water.y && (element.y-element.origin.y)< water.y){
		//element entering water
		element.submerged = true;
		setMaxWaterLevel();	
		
		water.y = maxWaterLevel  + ySum*(water.y - element.y +element.height-element.origin.y);
		
		/*if(element.direction == "up"){
			water.y = water.y + ySum;
		}else if(element.direction == "down"){
			water.y = water.y - ySum;
		}*/
		setWaterLevel();
	}else if((element.y-element.origin.y)>= water.y){
		//element under water
		element.submerged = true;
		setMaxWaterLevel();
		water.y = maxWaterLevel;
		setWaterLevel();
	}
}

function iniciar(){
	
}

function reiniciar(){
	restart();
	//initialize();
}

function deselectA(){
	$("#sizeA1").removeClass("sizeSelected");
	$("#sizeA2").removeClass("sizeSelected");
	$("#sizeA3").removeClass("sizeSelected");
}
function deselectB(){
	$("#sizeB1").removeClass("sizeSelected");
	$("#sizeB2").removeClass("sizeSelected");
	$("#sizeB3").removeClass("sizeSelected");
}

function actualizarInfo(){
	$("#kg1").html(cube1.mass);
	$("#vol1").html(cube1.volume*100/145);
	
	$("#kg2").html(cube2.mass);
	$("#vol2").html(cube2.volume*100/145);
	
	massCube1.text = cube1.mass + " kg";
	massCube2.text = cube2.mass + " kg";
	
	cube1.floatPercent = cube1.density/water.density*100;
	cube2.floatPercent = cube2.density/water.density*100;
}

function changeElementA(n){
	deselectA();
	$("#sizeA"+n).addClass("sizeSelected");
	switch(n){
		case 1:
			cube1.width = 55;
			cube1.height = 55;
			cube1.origin.y = 27;
			cube1.volume = 3.625;
			cube1.size = 1;
			setMass(cube1);	
			actualizarInfo();
			nameCube1.inity = cube1.inity -20;
			bgText1.width = 55;
			massCube1.initx = cube1.initx +27;
			break;
		case 2:
			cube1.width = 78;
			cube1.height = 78;
			cube1.origin.y = 49;
			cube1.volume = 7.25;
			cube1.size = 2;
			setMass(cube1);	
			actualizarInfo();
			nameCube1.inity = cube1.inity -43;
			bgText1.width = 78;
			massCube1.initx = cube1.initx +36;
			break;
		case 3:
			cube1.width = 110;
			cube1.height = 110;
			cube1.origin.y = 82;
			cube1.volume = 14.5;
			cube1.size = 3;
			setMass(cube1);	
			actualizarInfo();
			nameCube1.inity = cube1.inity -75;
			bgText1.width = 110;
			massCube1.initx = cube1.initx +52;
			break;
	}
	setTextPosition();
}

function changeElementB(n){
	deselectB();
	$("#sizeB"+n).addClass("sizeSelected");
	switch(n){
		case 1:
			cube2.width = 55;
			cube2.height = 55;
			cube2.origin.y = 27;
			cube2.volume = 3.625;
			cube2.size = 1;
			setMass(cube2);	
			actualizarInfo();
			nameCube2.inity = cube2.inity -20;
			bgText2.width = 55;
			massCube2.initx = cube2.initx +27;	
			break;
		case 2:
			cube2.width = 78;
			cube2.height = 78;
			cube2.origin.y = 49;
			cube2.volume = 7.25;
			cube2.size = 2;
			setMass(cube2);	
			actualizarInfo();
			nameCube2.inity = cube2.inity -43;
			bgText2.width = 78;
			massCube2.initx = cube2.initx +36;
			break;
		case 3:
			cube2.width = 110;
			cube2.height = 110;
			cube2.origin.y = 82;
			cube2.volume = 14.5;
			cube2.size = 3;
			setMass(cube2);	
			actualizarInfo();
			nameCube2.inity = cube2.inity -75;
			bgText2.width = 110;
			massCube2.initx = cube2.initx +52;
			break;
	}
	setTextPosition();
}

function changeWater(n){
	if (n === 1) {
		$("#checkX1").css("display", "block");
		$("#checkX2").css("display", "none");
		$("#checkX3").css("display", "none");
		water.fill = "#CCCCCC";
		water.density = 0.78;
	} else if (n === 2) {
		$("#checkX1").css("display", "none");
		$("#checkX2").css("display", "block");
		$("#checkX3").css("display", "none");
		water.fill = "#87D0EF";
		water.density = 1;
	} else if (n === 3) {
		$("#checkX1").css("display", "none");
		$("#checkX2").css("display", "none");
		$("#checkX3").css("display", "block");
		water.fill = "#FF9900";
		water.density = 1.42;
	}
	actualizarInfo();
	fixAllPositions();
}
function showSelect(n){
	if (n === 1) {
		if ($("#select1options").css("display") == "none") {
			$("#select1options").css("display", "block");
		} else {
			$("#select1options").css("display", "none");
		}
	} else if (n === 2) {
		if ($("#select2options").css("display") == "none") {
			$("#select2options").css("display", "block");
		} else $("#select2options").css("display", "none");
	}
}

function setMass(element){
	if (element.material === 1) {
		element.density = 0.59;
		element.img.src = "images/wood.png";
	} else if (element.material === 2) {
		element.density = 0.92;
		element.img.src = "images/ice.png";
	} else if (element.material === 3) {
		element.density = 2.4;
		element.img.src = "images/brick.png";
	} else if (element.material === 4) {
		element.density = 7.87;
		element.img.src = "images/iron.png";
	}
	var mss = Math.round(((element.volume*100/145)*element.density)*100)/100;
	element.mass = mss;
}

function changeMaterialA(n){	
	cube1.material = n;
	setMass(cube1);	
	$("#select1options").css("display","none");

	if (n === 1) {
		$("#select1txt").html("Madera");
		$("#density1").html("0,59 kg/dm&#179;");
		$("#selArrow1").css("left", "39px");
		$("#density1").css("left", "10px");
	} else if (n === 2) {
		$("#select1txt").html("Hielo");
		$("#density1").html("0,92 kg/dm&#179;");
		$("#selArrow1").css("left", "74px");
		$("#density1").css("left", "44px");
	} else if (n === 3) {
		$("#select1txt").html("Ladrillo");
		$("#density1").html("2,4 kg/dm&#179;");
		$("#selArrow1").css("left", "148px");
		$("#density1")
	} else if (n === 4) {
		$("#select1txt").html("Hierro");
		$("#density1").html("7,87 kg/dm&#179;");
		$("#selArrow1").css("left", "196px");
		$("#density1").css("left", "160px");
	}
	actualizarInfo();
	elementMove(cube1);
	
}
function changeMaterialB(n){	
	cube2.material = n;
	setMass(cube2);	
	$("#select2options").css("display","none");

	if (n === 1) {
		$("#select2txt").html("Madera");
		$("#density2").html("0,59 kg/dm&#179;");
		$("#selArrow2").css("left", "39px");
		$("#density2").css("left", "10px");
	} else if (n === 2) {
		$("#select2txt").html("Hielo");
		$("#density2").html("0,92 kg/dm&#179;");
		$("#selArrow2").css("left", "74px");
		$("#density2").css("left", "44px");
	} else if (n === 3) {
		$("#select2txt").html("Ladrillo");
		$("#density2").html("2,4 kg/dm&#179;");
		$("#selArrow2").css("left", "148px");
		$("#density2").css("left", "118px");
	} else if (n === 4) {
		$("#select2txt").html("Hierro");
		$("#density2").html("7,87 kg/dm&#179;");
		$("#selArrow2").css("left", "196px");
		$("#density2").css("left", "160px");
	}
	actualizarInfo();
	elementMove(cube2);
}
function unBloque() {
	if(showing2Bloques) {
		$("#controls2").css("display","none");
		showing2Bloques = false;
		canvas.removeChild(cube2);
		canvas.removeChild(nameCube2);
		canvas.removeChild(bgText2);
		canvas.removeChild(massCube2);
	}
}
function dosBloques(){
	if(!showing2Bloques) {
		$("#controls2").css("display","block");
		showing2Bloques = true;
		cube2.x = cube2.initx;
		cube2.y = cube2.inity;

		canvas.addChild(cube2);
		canvas.addChild(nameCube2);
		canvas.addChild(bgText2);
		canvas.addChild(massCube2);
		changeMaterialB(1);
		changeElementB(2);
		fixAllPositions();
		moveAllOver();
		checkDirection(cube2);
		setWater(cube2);
		checkContact(cube2);
		setMaxWaterLevel();
		setUnderwater();
		setTextPosition();
		cube2.falling = true;
		cube2.submerged = false;
	}
}

function restart(){

	unBloque();

	canvas.removeChild(cube2);
	canvas.removeChild(nameCube2);
	canvas.removeChild(bgText2);
	canvas.removeChild(massCube2);

	cube1.x = cube1.initx;
	cube1.y = cube1.inity;

	cube2.x = cube2.initx;
	cube2.y = cube2.inity;

	scales1.x = scales1.initx;
	scales1.y = scales1.inity;

	scales2.x = scales2.initx;
	scales2.y = scales2.inity;

	changeMaterialA(1);
	changeMaterialB(1);
	changeElementA(2);
	changeElementB(2);
	fixAllPositions();
	moveAllOver();
	checkDirection(scales1);
	checkDirection(scales2);
	checkDirection(cube1);
	checkDirection(cube2);
	setWater(scales1);
	setWater(scales2);
	setWater(cube1);
	setWater(cube2);
	checkContact(cube1);
	checkContact(cube2);
	setMaxWaterLevel();
	setUnderwater();
	setTextPosition();
	scales1.falling = true;
	scales2.falling = true;
	cube1.falling = true;
	cube2.falling = true;
	scales1.submerged = false;
	scales2.submerged = false;
	cube1.submerged = false;
	cube2.submerged = false;

	changeWater(2);


}
