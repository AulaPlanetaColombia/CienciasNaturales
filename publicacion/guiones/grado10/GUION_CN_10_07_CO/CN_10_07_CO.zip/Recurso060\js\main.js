window.onresize = resize;
var scale 	= 1;
var iniciat;

var maxDrag=128.58;
var minDrag=0;

var c;
var ctx;

$(document).ready(function(){
	resize();
	initialize();
});

function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}

function restart(){
	
}


function drawCanvas(press){
   
	var height=(press*100)/400;
	height= (height*44)/100;

	if(height>44){  height=44;}
	else if (height<0) {height=0;}
  
	ctx.clearRect(0, 0, 91, 44);
	ctx.beginPath();
	ctx.moveTo(0, 0);
	ctx.bezierCurveTo(0, height, 91, height, 91, 0);
	ctx.lineTo(91,44);
	ctx.lineTo(0,44);
	ctx.lineTo(0,0);
	ctx.stroke();
	ctx.fill();

}


var magnets;
var volts = 0;
var rElectrons;
var lElectrons;
var elecSpeed = 0;
var direction = 0;
var scene = 1;
var inverted = false;
var profunditat=0;
var densidad=0;
var maxLimbHeight = 100 ;
var minLimbHeight = 1 ;

function initialize(){
	c = document.getElementById("myCanvas");
	ctx = c.getContext("2d");
	
	iniciat = false;
	volts = 0;
	elecSpeed = 0;
	direction = 0;
	magnets = document.getElementsByClassName("fm");
	rElectrons = document.getElementsByClassName("re");
	lElectrons = document.getElementsByClassName("le");
	changeMaterialA(1);
	for(var i=0;i<magnets.length;i++){
		var ang = calculateAngle(magnets[i],327,250);
	}
	$("#tool").draggable({
		scroll: false,
		axis: "y",
		//containment: "#parentTool",
		start: function(evt,ui){
			console.log("top: " +ui.position.top); 
		
		},
		
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);
			//var pos=parseInt($(this).css('top'));
			var pos=ui.position.top;
			console.log("topPX="+pos + " topScale="+(pos*scale));
			
			if((pos)>=131){
				
				ui.position.top =130;
				
				//var pos2=parseInt($(this).css('top'));
			  
			}else if(pos<0){
				ui.position.top =0;
				
			}
			changeGraficToInt(ui.position.top);
			//console.log("top="+pos);
		
		}        
	});
	
	
	
	
	
}
function changeGraficToInt(value){
	var prof= parseInt((value*100)/maxDrag); <!--100 is max Profundidad-->
	if(prof>100){
		prof=100;
	}
	printProfunditat(prof);

}

function changeIntToGrafic(value){
	var prof= ((value*maxDrag)/100);
	$("#tool").css("top",prof)
	var pos=$("#tool").position();
	

	


}

function changeWater(n){
	if (n === 1) {
		$("#checkX1").css("display", "block");
		$("#checkX2").css("display", "none");
		$("#checkX3").css("display", "none");
		water.fill = "#CCCCCC";
		water.density = 0.78;
	} else if (n === 2) {
		$("#checkX1").css("display", "none");
		$("#checkX2").css("display", "block");
		$("#checkX3").css("display", "none");
		water.fill = "#87D0EF";
		water.density = 1;
	} else if (n === 3) {
		$("#checkX1").css("display", "none");
		$("#checkX2").css("display", "none");
		$("#checkX3").css("display", "block");
		water.fill = "#FF9900";
		water.density = 1.42;
	}
	actualizarInfo();
}
function showSelect(n){
	if (n === 1) {
		if ($("#select1options").css("display") == "none") {
			$("#select1options").css("display", "block");
		} else {
			$("#select1options").css("display", "none");
		}
	} else if (n === 2) {
		if ($("#select2options").css("display") == "none") {
			$("#select2options").css("display", "block");
		} else $("#select2options").css("display", "none");
	}
}

function setMass(element){
	if (element.material === 1) {
		element.density = 0.59;
		element.img.src = "images/wood.png";
	} else if (element.material === 2) {
		element.density = 0.92;
		element.img.src = "images/ice.png";
	} else if (element.material === 3) {
		element.density = 2.4;
		element.img.src = "images/brick.png";
	} else if (element.material === 4) {
		element.density = 7.87;
		element.img.src = "images/iron.png";
	}
	var mss = Math.round(((element.volume*100/145)*element.density)*100)/100;
	element.mass = mss;
}

function suma(){
	profunditat+=5;
	if(profunditat>100){
		profunditat=100;
	}
	
	changeIntToGrafic(profunditat);
	printProfunditat(profunditat);
}




function resta(){
	profunditat-=5;
	if(profunditat<0){
		profunditat=0;
	}
	changeIntToGrafic(profunditat);
	printProfunditat(profunditat);
}

function calcultatePressure(value){

	var pressure = 9.8 * (value/100.0) * densidad;
	pressure=pressure / 100;
	
	
	/*	
	var barHeight= maxLimbHeight - pressure ;
	var barHeight=  barHeight < 1 ? 1 : barHeight ;
	var barHeight= maxLimbHeight + pressure ;
	var barHeight=  barHeight > 50 ? 50 : barHeight ;
	*/
	// 196hp es heighestBAr
	var barHeight=(50*pressure)/196;
	if(barHeight>50){ barHeight=50;}

	var barHeight2=barHeight;
	if(barHeight2>30){
	 	barHeight2=30;
	}
	
	if(pressure>0){
		$("#presBar").css('min-height',barHeight+"px");
		$("#presBar2").css('min-height',barHeight2+"px");
		var initialTop=81;
		var top=initialTop-barHeight;
		$("#presBar").css('margin-top',top+"px");
		
	}
	
	//$("#presBar").css('top',pos+"px");
	return pressure.toFixed(2);

}
function printProfunditat(value){
	profunditat=value;
	var hpa= calcultatePressure(value);
	drawCanvas(hpa);
	var txtHpa = (hpa+"").replace(".",",").replace(",00","");
	$("#hpaVar").html(txtHpa);
	$("#inputProf").val(value);
	$("#cmCubeta").html(value+" cm");
	$("#pressioCubeta").html(densidad+" kg/m<sup>3</sup>");
	
	
}

var timeOutSearch;
var profTemp;
function assigProf(value){
	
	clearTimeout(timeOutSearch);
    timeOutSearch=setTimeout(doAssigProf,1500);
    profTemp=value;
	
}

function doAssigProf(){
	var value=profTemp;
	
	if(tiene_letras(value)){
			if(value>100){
				profunditat=100;
			}else if(value<0){
				profunditat=0;
			}else{
				profunditat=value;
			}
	}else{
		 profunditat=100;
	 
	}
	changeIntToGrafic(profunditat);
	printProfunditat(profunditat);

}

function tiene_letras(texto){
   var letras="abcdefghyjklmnñopqrstuvwxyz";
   texto = texto.toLowerCase();
   for(i=0; i<texto.length; i++){
      if (letras.indexOf(texto.charAt(i),0)!=-1){
         return 0;
      }
   }
   return 1;
} 


function changeMaterialA(n){	

	$("#varDen").css("display","block");
	$("#inputDen").css("display","none");
	$("#select1options").css("display","none");
	 showSelects();
	$("#selOptionA"+n).css("display","none");
	
	if (n === 1) {
		$("#txtSel").html(getText('agua'));
			densidad=1000;
			var color="A8DCF8";
			var densityToShow="1.000";
	} else if (n === 2) {
		$("#txtSel").html(getText('etanol'));
			densidad=790;
			var densityToShow="790";
			var color="A8A8A8";
	} else if (n === 3) {
		$("#txtSel").html(getText('benceno'));
		densidad=880;
		var densityToShow="880";
		var color="C97F7F";
	} else if (n === 4) {
		$("#txtSel").html(getText('treta'));
		densidad=1590;
		var densityToShow="1.590";
		var color="2B7726";
	}else if (n === 5) {
		$("#txtSel").html(getText('mercurio'));
		densidad=13550;
		var densityToShow="13.550";
		var color="D47AEE";
	}else if (n === 6) {
		$("#txtSel").html(getText('desconocido'));
			densidad=5000;
		var densityToShow="5.000";
			$("#varDen").css("display","none");
			$("#inputDen").css("display","block");
			$("#inputDen").val(densityToShow);
			var color="FFC2ED";
			
	}
	printProfunditat(profunditat);
	$("#varDen").html(densityToShow+" kg/m<sup>3</sup>");
	$(".bckCubeta").css('background-color','#'+color);
	//actualizarInfo();
	
}
function addHover(value){
	
	$("#selOptionA"+value).addClass('selectOptionsHover');

}
function removeHover(value){
	
	$("#selOptionA"+value).removeClass('selectOptionsHover');

}
function showSelects(){
	for(var x=1;x<7;x++){
		$("#selOptionA"+x).css("display","block");
	}
	
}
function changeMaterialB(n){	
	cube2.material = n;
	setMass(cube2);	
	$("#select2options").css("display","none");

	if (n === 1) {
		$("#density2").html("0,59 kg/dm&#179;");
		$("#selArrow2").css("left", "39px");
		$("#density2").css("left", "10px");
	} else if (n === 2) {
		$("#density2").html("0,92 kg/dm&#179;");
		$("#selArrow2").css("left", "74px");
		$("#density2").css("left", "44px");
	} else if (n === 3) {
		$("#density2").html("2,4 kg/dm&#179;");
		$("#selArrow2").css("left", "148px");
		$("#density2").css("left", "118px");
	} else if (n === 4) {
		$("#density2").html("7,87 kg/dm&#179;");
		$("#selArrow2").css("left", "196px");
		$("#density2").css("left", "160px");
	}
	actualizarInfo();
	elementMove(cube2);
}
function iniciar(){
	if(!iniciat){	
			
	}
}

function reiniciar(){
	if(canChange){
		restart();
		initialize();
	}
}