window.onresize = resize;
var scale 	= 1;

/* CONST */

var ENV_AIR 	= 1;
var ENV_WATER 	= 2;
var ENV_GLASS 	= 3;
var ENV_OTHER	= 4;

var ENV_AIR_TEXT 	= "aire";
var ENV_WATER_TEXT 	= "agua";
var ENV_GLASS_TEXT 	= "cristal";
var ENV_OTHER_TEXT	= "eleccion";

var ENV_UP		= 1;
var ENV_DOWN	= 2;

var DEFAULT_ENV_UP 		= ENV_AIR;
var DEFAULT_ENV_DOWN 	= ENV_WATER;

/* END CONST */


var canvas;
var lantern;

var ORIGINX 			= 383;
var ORIGINY 			= 326;
var RADIOUS 			= 240;
var REFRACTION_RADIOUS 	= 1000;
var LASER_WIDTH			= 4;

var currentEnv1 = DEFAULT_ENV_UP;
var currentEnv2 = DEFAULT_ENV_DOWN;

var currentEnvIndex1 = 1;
var currentEnvIndex2 = 1.33;

var lampState = false;
var mirror = false;
var firstLine = null;
var refractionLine1 = null;
var refractionLine2 = null;
var degree = 45;
var lanternSelected = false;

var moveStarted = false;
var touched = false;

$(document).ready(function(){

	addSlider();
	resize();
	initialize();
	reiniciar();

	changeEnv(DEFAULT_ENV_UP,ENV_AIR_TEXT,ENV_UP);
	changeEnv(DEFAULT_ENV_DOWN,ENV_WATER_TEXT,ENV_DOWN);

	$(function() {
	
		var iOS = /(iPad|iPhone|iPod)/g.test( navigator.userAgent );
		/*if(iOS){
			$("#lantern").on("touch",function(e) {
				moveStarted = true;
				touchStart(e);
				//e.preventDefault();
			});
			
		}else*/

			$("#lantern").on("mousedown touchstart",function(e) {
				if (e.target == this) {
					console.log("Touch Start")
					moveStarted = true;
					touchStart(e);	
				}else{
					lanternButtonOnPress();
				}
				
				e.preventDefault();
			});
			

		
		$("#lantern").css('-ms-touch-action', 'none');
		$(document).on("mousemove touchmove",function(e) {
			if (!moveStarted)
				return;

			touchMove(e);
			e.preventDefault();
		});
	
		$(document).on("mouseup touchend",function(e) {
			if (moveStarted) {
				touchEnd(e);
				e.preventDefault();
			}

			moveStarted = false;

		});

	});
});

function touchStart(evt) {
	lanternSelected = true;
}

function touchMove(evt){

	if (lanternSelected) {

		var center_x = (lantern.width());
		var center_y = (parseInt(lantern.css('top')));

		var mouse_x = evt.pageX/scale - margLeft/scale;
		var mouse_y = evt.pageY/scale -	margTop/scale;
		
		if (typeof (evt.pageX) == "undefined") {
			mouse_x = evt.originalEvent.touches[0].pageX/scale - margLeft;
			mouse_y = evt.originalEvent.touches[0].pageY/scale - margTop;
		}

		console.log("CENTER: " + center_x + " - " + center_y);
		console.log("MOUSE: " +  mouse_x  + " - " + mouse_y);

		var radians = Math.atan2(mouse_x - center_x, (mouse_y - center_y)*-1);
		degree = (radians * (180 / Math.PI)) + 90;

		console.log("DEGREEE: " + degree);

		if (degree < 0)
			degree = 0;

		if (degree > 90) {
			degree = 90;
		}

		setLanternRotation();
		updateLaser();
	}

}

function setLanternRotation() {
	lantern.css('-moz-transform', 'rotate('+degree+'deg)');
	lantern.css('-webkit-transform', 'rotate('+degree+'deg)');
	lantern.css('-o-transform', 'rotate('+degree+'deg)');
	lantern.css('-ms-transform', 'rotate('+degree+'deg)');
}


function touchEnd(evt){
	lanternSelected = false;
}

var margLeft = 0;
var margTop = 0;

function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	
	if(scaleh<scalew){
		scale = scaleh;
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}

function initialize(){

	lantern = $('#lantern');

	$("#compass").draggable({
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);
		}
	});

	canvas = oCanvas.create({ canvas: "#canvas", wScale:scale });
}

function lanternButtonOnPress() {
	if(touched==false){
		if (lampState) {
			$("#lantern button").removeClass("toggle");
			$("#lightButton").html(getText("encender"));
		}else{
			$("#lantern button").addClass("toggle");
			$("#lightButton").html(getText("apagar"));
		}

		lampState = !lampState;

		updateState();
		touched = true;
	}
	setTimeout(function(){
		touched = false;
	},600);
	
}

function resetLantern () {

	$("#lantern button").removeClass("toggle");
	$("#lightButton").html(getText("encender"));

	setLanternRotation(degree);
	lampState = 0;
	$("#lanternButton").removeClass("toggle");
	updateState();
}


function updateLaser() {

	if (firstLine != null)
		canvas.removeChild(firstLine);

	if (refractionLine1 != null)
		canvas.removeChild(refractionLine1);

	if (refractionLine2 != null)
		canvas.removeChild(refractionLine2);

	drawLanternLight();
	drawRefraction();
}

function drawLanternLight() {

	if (!lampState)
		return;

	console.log("Degree: " + degree);

	var endX = RADIOUS * Math.cos(degree * (Math.PI/180));
	var endY = RADIOUS * Math.sin(degree * (Math.PI/180));

	console.log("END: x-"+endX+" y-"+endY);

	firstLine = canvas.display.line({
		start: { x: ORIGINX, y: ORIGINY },
		end: { x: ORIGINX - endX, y: ORIGINY - endY},
		stroke: LASER_WIDTH+"px rgb(255, 0, 0)",
		cap: "round"
	});

	canvas.addChild(firstLine);
}

function drawRefraction() {
	if (!lampState)
		return;

	var endX,endY,alpha;

	if (mirror) {
		endX = REFRACTION_RADIOUS * Math.cos(degree * (Math.PI/180));
		endY = REFRACTION_RADIOUS * Math.sin(degree * (Math.PI/180))*-1;
		alpha = 1;
	}else{

		endX = REFRACTION_RADIOUS * Math.cos(degree * (Math.PI/180));
		endY = REFRACTION_RADIOUS * Math.sin(degree * (Math.PI/180));

		if (currentEnv1 != currentEnv2) {
			endY *= -1;
			alpha = getEnvVars().reflectionAlpha;
		}else{
			alpha = 1;
		}
	}

	refractionLine1 = canvas.display.line({
		start: { x: ORIGINX, y: ORIGINY },
		end: { x: ORIGINX + endX, y: ORIGINY + endY},
		stroke: LASER_WIDTH+"px rgba(255, 0, 0, "+alpha+")",
		cap: "round"
	});

	canvas.addChild(refractionLine1);

	if (!mirror && currentEnv1 != currentEnv2)
		drawSecondRefraction();
}

function drawSecondRefraction() {

	var refractionAngle = getEnvVars().refraction

	var endX = REFRACTION_RADIOUS * Math.cos((refractionAngle) * (Math.PI/180))*-1;
	var endY = REFRACTION_RADIOUS * Math.sin((refractionAngle) * (Math.PI/180));

	var alpha = getEnvVars().refractionAlpha;

	refractionLine2 = canvas.display.line({
		start: { x: ORIGINX, y: ORIGINY },
		end: { x: ORIGINX + endX, y: ORIGINY + endY},
		stroke: LASER_WIDTH+"px rgba(255, 0, 0, "+alpha+")",
		cap: "round"
	});

	canvas.addChild(refractionLine2);
}


/* BEGIN SELECT */

function changeEnv(env,text,id){
	setEnvText(id,text);
	setEnv(id,env);
	updateState();
}

function addHover(value){
	$(value).addClass('selectOptionsHover');
}
function removeHover(value){
	$(value).removeClass('selectOptionsHover');
}

function showSelect(n){
	if ($(n).css("display") == "none") {
		$(n).css("display", "block");
	} else {
		$(n).css("display", "none");
	}
}

/* END SELECT */

/* BEGIN REFRACTION SLIDER */

function changeRefractionFromSlide(pos,id) {
	changeRefractionIndex(pos,id,true);
}

function changeRefractionIndex(pos,id,fromSlide) {

	pos = ((pos - 10) * 0.5/140) +1;

	window["currentEnvIndex"+id] = pos.toFixed(2);
	$("#refractionIndex"+id).val(pos.toFixed(2));

	var alpha = pos-0.9;
	var color = '#41A6D7';
	var rgbaCol = 'rgba(' + parseInt(color.slice(-6,-4),16)
		+ ',' + parseInt(color.slice(-4,-2),16)
		+ ',' + parseInt(color.slice(-2),16)
		+','+alpha+')';

	$('#envBackground'+id).css('background-color', rgbaCol);

	if (fromSlide)
		setEnvText(id,"eleccion");
}

function addSlider() {

	$(".slider").css("left",10);
	$(".slider").draggable({
		scroll: false,
		axis: "x",
		start: function(evt,ui){

		},
		drag: function(evt,ui){
			// zoom fix

			console.log("Left: "+ui.position.left);

			ui.position.top = Math.round(ui.position.top / scale);
			var pos = ui.position.left = Math.round(ui.position.left / scale);

			var itemid 	= (evt.target.id).slice(-1);

			if((pos)>=151) {
				pos = 150;
			}else if(pos<10) {
				pos = 10;
			}

			ui.position.left=pos;

			changeRefractionFromSlide(pos,itemid);
			updateState();
		}
	});
}

/* END REFRACTION SLIDER */


/* BEGIN SET ENV */

function setEnvText(id,text) {

	$("#txtSel"+id).html(getText(text));
}

function setEnv(id,env) {

	window["currentEnv"+id] = env;
	$("#select"+id+"options").css("display","none");

	var pos = 10;

	switch (env) {
		case ENV_AIR:
			pos = 10;
			break;
		case ENV_WATER:
			pos = 102;
			break;
		case ENV_GLASS:
			pos = 150;
			break;
		case ENV_OTHER:
			break;
	}

	$("#slider"+id).css("left",pos);
	changeRefractionIndex(pos,id);
}

/* END SET ENV */

function mirrorChange(){
	mirror = !mirror;
	updateState();
}
function mirrorOff() {
	mirror = false;
	updateState();
}

function getEnvVars() {

	var incident = (degree*-1)- 217;
	var incidentDeg = -306.0472-incident;
	var medium01Index = currentEnvIndex1;
	var medium02Index = currentEnvIndex2;
	var incidentDegSin = Math.sin(incidentDeg*Math.PI/180);
	var refractionConstant = medium01Index/medium02Index;
	var refraction = 90-(Math.asin(incidentDegSin*refractionConstant)/(Math.PI/180));
	var refractionAlpha = ((medium01Index*Math.cos(incidentDeg*Math.PI/180)-medium02Index*Math.cos((90-refraction)*Math.PI/180))/(medium01Index*Math.cos(incidentDeg*Math.PI/180)+medium02Index*Math.cos((90-refraction)*Math.PI/180)))*((medium01Index*Math.cos(incidentDeg*Math.PI/180)-medium02Index*Math.cos((90-refraction)*Math.PI/180))/(medium01Index*Math.cos(incidentDeg*Math.PI/180)+medium02Index*Math.cos((90-refraction)*Math.PI/180)));
	var newRefractionAlpha = (1-refractionAlpha)*1.2;
	var newReflectionAlpha = 1
	if (newRefractionAlpha > 0)
		newReflectionAlpha = (1-(1-refractionAlpha))*1.2;

	return {"refraction":refraction,"refractionAlpha":newRefractionAlpha,"reflectionAlpha":newReflectionAlpha};
}


/* UPDATE */
function updateState() {

	updateLaser();
}

function reiniciar() {
	resetLantern();
	mirrorOff();
	// resetValues();
}