(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
        titulo1(this, txt['titulo']);

        this.btn6 = new lib.btn6();
        this.btn6.setTransform(741.3, 431);
        new cjs.ButtonHelper(this.btn6, 0, 1, 1);

        this.btn5 = new lib.btn5();
        this.btn5.setTransform(476.3, 431);
        new cjs.ButtonHelper(this.btn5, 0, 1, 1);

        this.btn4 = new lib.btn4();
        this.btn4.setTransform(211.3, 431);
        new cjs.ButtonHelper(this.btn4, 0, 1, 1);

        this.btn3 = new lib.btn3();
        this.btn3.setTransform(741.3, 245);
        new cjs.ButtonHelper(this.btn3, 0, 1, 1);

        this.btn2 = new lib.btn2();
        this.btn2.setTransform(476.8, 245);
        new cjs.ButtonHelper(this.btn2, 0, 1, 1);

        this.btn1 = new lib.Btn1();
        this.btn1.setTransform(212.3, 245);
        new cjs.ButtonHelper(this.btn1, 0, 1, 1);

        this.btn1.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });

        this.btn2.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });

        this.btn3.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });

        this.btn4.on("click", function (evt) {
            putStage(new lib.frame1_4());
        });

        this.btn5.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });

        this.btn6.on("click", function (evt) {
            putStage(new lib.frame1_6());
        });

        this.text = new cjs.Text(txt['btnselec'], "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 229;
        this.text.setTransform(472.2, 532.7 + incremento);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCCCCC").s().p("AyMCoIAAlPMAkZAAAIAAFPg");
        this.shape.setTransform(474.1, 545);
        this.practica = new lib.btn_practica(txt['btnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.practica.on("click", function (evt) {
            putStage(new lib.frame4());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.shape, this.text, this.btn1, this.btn2, this.btn3, this.btn4, this.btn5, this.btn6, this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit_para']);
        texto(this, txt['text_para'], 1, 200);
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000033").s().p("A0odhMAAAg7BMApRAAAMAAAA7Bg");
        this.shape.setTransform(208.2, 343);
        this.instance = new lib._01_94177503_OPT();
        this.instance.setTransform(65.2, 145.5, 0.449, 0.449);
        this.instance.mask = this.shape;
        this.i1 = new lib.btn_grupo();
        this.i1.setTransform(786.8, 572.3);
        new cjs.ButtonHelper(this.i1, 0, 1, 2, false, new lib.btn_grupo(), 3);


        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCFF").s().p("EhEqAdhMAAAg7BMCJVAAAMAAAA7Bg");
        this.shape_1.setTransform(475, 343, 1.081, 1);
        this.i1.on("click", function (evt) {
            putStage(new lib.frame2(1));
        });

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.imagen, this.cerrar, this.shape_1, this.i1, this.texto, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


    (lib.frame1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
     titulo2(this, txt['tit_radio']);
        texto(this, txt['text_radio'], 1, 200);
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000033").s().p("A0odhMAAAg7BMApRAAAMAAAA7Bg");
        this.shape.setTransform(208.2, 343);
        this.instance = new lib._02_104681576_OPT();
        this.instance.setTransform(-118.9,139,0.604,0.604);
        this.instance.mask = this.shape;
        this.i1 = new lib.btn_grupo();
        this.i1.setTransform(786.8, 572.3);
        new cjs.ButtonHelper(this.i1, 0, 1, 2, false, new lib.btn_grupo(), 3);


        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCFF").s().p("EhEqAdhMAAAg7BMCJVAAAMAAAA7Bg");
        this.shape_1.setTransform(475, 343, 1.081, 1);
        this.i1.on("click", function (evt) {
            putStage(new lib.frame2(2));
        });




        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.imagen, this.cerrar, this.shape_1, this.i1, this.texto, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
           titulo2(this, txt['tit_bomb']);
        texto(this, txt['text_bomb'], 1, 200);
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000033").s().p("A0odhMAAAg7BMApRAAAMAAAA7Bg");
        this.shape.setTransform(208.2, 343);
        this.instance = new lib._03_104429226_OPT();
        this.instance.setTransform(32.8,146,0.361,0.361);
        this.instance.mask = this.shape;
        this.i1 = new lib.btn_grupo();
        this.i1.setTransform(786.8, 572.3);
        new cjs.ButtonHelper(this.i1, 0, 1, 2, false, new lib.btn_grupo(), 3);


        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCFF").s().p("EhEqAdhMAAAg7BMCJVAAAMAAAA7Bg");
        this.shape_1.setTransform(475, 343, 1.081, 1);
        this.i1.on("click", function (evt) {
            putStage(new lib.frame2(3));
        });



        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.imagen, this.cerrar, this.shape_1, this.i1, this.texto, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
           titulo2(this, txt['tit_gen']);
        texto(this, txt['text_gen'], 1, 200);
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000033").s().p("A0odhMAAAg7BMApRAAAMAAAA7Bg");
        this.shape.setTransform(208.2, 343);
        this.instance = new lib._04_87684470_OPT();
        this.instance.setTransform(-141.8,144.5,0.636,0.636);
        this.instance.mask = this.shape;
        this.i1 = new lib.btn_grupo();
        this.i1.setTransform(786.8, 572.3);
        new cjs.ButtonHelper(this.i1, 0, 1, 2, false, new lib.btn_grupo(), 3);


        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCFF").s().p("EhEqAdhMAAAg7BMCJVAAAMAAAA7Bg");
        this.shape_1.setTransform(475, 343, 1.081, 1);
        this.i1.on("click", function (evt) {
            putStage(new lib.frame2(4));
        });



        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.imagen, this.cerrar, this.shape_1, this.i1, this.texto, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
          titulo2(this, txt['tit_tel']);
        texto(this, txt['text_tel'], 1, 200);
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000033").s().p("A0odhMAAAg7BMApRAAAMAAAA7Bg");
        this.shape.setTransform(208.2, 343);
        this.instance = new lib._05_78367298_OPT();
        this.instance.setTransform(23.8,147.2,0.538,0.538);
        this.instance.mask = this.shape;
        this.i1 = new lib.btn_grupo();
        this.i1.setTransform(786.8, 572.3);
        new cjs.ButtonHelper(this.i1, 0, 1, 2, false, new lib.btn_grupo(), 3);


        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCFF").s().p("EhEqAdhMAAAg7BMCJVAAAMAAAA7Bg");
        this.shape_1.setTransform(475, 343, 1.081, 1);
        this.i1.on("click", function (evt) {
            putStage(new lib.frame2(5));
        });



        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.imagen, this.cerrar, this.shape_1, this.i1, this.texto, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
         titulo2(this, txt['tit_telef']);
        texto(this, txt['text_telef'], 1, 200);
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000033").s().p("A0odhMAAAg7BMApRAAAMAAAA7Bg");
        this.shape.setTransform(208.2, 343);
        this.instance = new lib._06_92074792_OPT();
        this.instance.setTransform(-77.8,144.9,0.555,0.555);
        this.instance.mask = this.shape;
        this.i1 = new lib.btn_grupo();
        this.i1.setTransform(786.8, 572.3);
        new cjs.ButtonHelper(this.i1, 0, 1, 2, false, new lib.btn_grupo(), 3);


        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCFF").s().p("EhEqAdhMAAAg7BMCJVAAAMAAAA7Bg");
        this.shape_1.setTransform(475, 343, 1.081, 1);
        this.i1.on("click", function (evt) {
            putStage(new lib.frame2(6));
        });



        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.imagen, this.cerrar, this.shape_1, this.i1, this.texto, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);



    (lib.frame2 = function (invento) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 0);
        titulo2(this, txt['tit_mosaico']);

        this.instance = new lib.mosaico();
        this.instance.setTransform(669.5, 343, 1, 1, 0, 0, 0, 250.5, 189);

        this.r1 = new lib.Respuesta1();
        this.r1.setTransform(201.3, 188.9);
        new cjs.ButtonHelper(this.r1, 0, 1, 2, false, new lib.Respuesta1(), 3);

        this.r1.on("click", function (evt) {
            if (invento == 1)
                putStage(new lib.frame2_1());
            else
                putStage(new lib.frame3(invento));
        });

        this.r1Error = new lib.Respuesta1();
        this.r1Error.setTransform(201.3, 189);
        new cjs.ButtonHelper(this.r1Error, 0, 1, 2, false, new lib.Respuesta1(), 3);

        this.r1Error6 = new lib.respuesta6();
        this.r1Error6.setTransform(201.3, 496);
        new cjs.ButtonHelper(this.r1Error6, 0, 1, 2, false, new lib.respuesta6(), 3);
 this.r1Error6.on("click", function (evt) {
            if (invento == 6)
                putStage(new lib.frame2_6());
            else
                putStage(new lib.frame3(invento));
        });
        this.r1Error5 = new lib.respuesta5();
        this.r1Error5.setTransform(201.3, 434.5);
        new cjs.ButtonHelper(this.r1Error5, 0, 1, 2, false, new lib.respuesta5(), 3);
 this.r1Error5.on("click", function (evt) {
            if (invento == 5)
                putStage(new lib.frame2_5());
            else
                putStage(new lib.frame3(invento));
        });
        this.r1Error4 = new lib.respuesta4();
        this.r1Error4.setTransform(201.3, 373.1);
        new cjs.ButtonHelper(this.r1Error4, 0, 1, 2, false, new lib.respuesta4(), 3);
 this.r1Error4.on("click", function (evt) {
            if (invento == 4)
                putStage(new lib.frame2_4());
            else
                putStage(new lib.frame3(invento));
        });
        this.r1Error3 = new lib.respuesta3();
        this.r1Error3.setTransform(201.3, 311.7);
        new cjs.ButtonHelper(this.r1Error3, 0, 1, 2, false, new lib.respuesta3(), 3);
 this.r1Error3.on("click", function (evt) {
            if (invento == 3)
                putStage(new lib.frame2_3());
            else
                putStage(new lib.frame3(invento));
        });
        this.r1Error1 = new lib.respuesta2();
        this.r1Error1.setTransform(201.3, 250.3);
        new cjs.ButtonHelper(this.r1Error1, 0, 1, 2, false, new lib.respuesta2(), 3);
    this.r1Error1.on("click", function (evt) {
            if (invento == 2)
                putStage(new lib.frame2_2());
            else
                putStage(new lib.frame3(invento));
        });
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCCCFF").s().p("EhEqAdhMAAAg7BMCJVAAAMAAAA7Bg");
        this.shape.setTransform(475, 343, 1.081, 1);


        this.anterior.on("click", function (evt) {
            if (invento == 1)
                putStage(new lib.frame1_1());
            if (invento == 2)
                putStage(new lib.frame1_2());
            if (invento == 3)
                putStage(new lib.frame1_3());
            if (invento == 4)
                putStage(new lib.frame1_4());
            if (invento == 5)
                putStage(new lib.frame1_5());
            if (invento == 6)
                putStage(new lib.frame1_6());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.shape, this.r1Error1, this.r1Error3, this.r1Error4, this.r1Error5, this.r1Error6, this.r1Error, this.r1, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit_benj']);
// Capa 1
        this.text = new cjs.Text("Boston, 17 de enero de 1706 â€“ Filadelfia, 17 de abril de 1790", "20px Verdana");
        this.text.lineHeight = 20;
        this.text.setTransform(79.5, 103.9);
        var html = createDiv(txt['text_benj_1'], "Verdana", "20px", '770px', '40px', "20px", "185px", "left");
        this.text = new cjs.DOMElement(html);
        this.text.setTransform(90, -522);
        this.instance = new lib.Path_1();
        this.instance.setTransform(880.9, 465, 0.839, 0.839, 0, 0, 0, 98, 103.7);
        this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.706)", 7, 7, 15);

        texto(this, txt['text_benj_2'], 1, 200);
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000033").s().p("A0XdhMAAAg7BMAovAAAMAAAA7Bg");
        this.shape_1.setTransform(209.9, 339);
        this.instance_1 = new lib.BenjaminFranklin();
        this.instance_1.setTransform(60.6, 144.6, 0.453, 0.453);
        this.instance_1.mask = this.shape_1;
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCFFCC").s().p("A1FdhMAAAg7BMBfTAAAMAAAA7BgEhKNAdhMAAAg7BIMXAAMAAAA7Bg");
        this.shape.setTransform(475.5, 339);



        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.titulo, this.logo, this.home, this.shape_1, this.shape, this.instance_1, this.texto, this.instance, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit_nik']);
        var html = createDiv(txt['text_nik_1'], "Verdana", "20px", '770px', '40px', "20px", "185px", "left");
        this.text = new cjs.DOMElement(html);
        this.text.setTransform(90, -522);
        this.instance = new lib.Path_1();
        this.instance.setTransform(880.9, 465, 0.839, 0.839, 0, 0, 0, 98, 103.7);
        this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.706)", 7, 7, 15);

        texto(this, txt['text_nik_2'], 1, 200);
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000033").s().p("A0XdhMAAAg7BMAovAAAMAAAA7Bg");
        this.shape_1.setTransform(209.9, 339);
        this.instance_1 = new lib.NikolaTEsla();
        this.instance_1.setTransform(31.5, 149.7, 0.67, 0.67);
        this.instance_1.mask = this.shape_1;
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCFFCC").s().p("A1FdhMAAAg7BMBfTAAAMAAAA7BgEhKNAdhMAAAg7BIMXAAMAAAA7Bg");
        this.shape.setTransform(475.5, 339);
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.titulo, this.logo, this.home, this.shape_1, this.shape, this.instance_1, this.texto, this.instance, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
             titulo2(this, txt['tit_edis']);
        var html = createDiv(txt['text_edis_1'], "Verdana", "20px", '770px', '40px', "20px", "185px", "left");
        this.text = new cjs.DOMElement(html);
        this.text.setTransform(90, -522);
        this.instance = new lib.Path_1();
        this.instance.setTransform(880.9, 465, 0.839, 0.839, 0, 0, 0, 98, 103.7);
        this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.706)", 7, 7, 15);

        texto(this, txt['text_edis_2'], 1, 200);
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000033").s().p("A0XdhMAAAg7BMAovAAAMAAAA7Bg");
        this.shape_1.setTransform(209.9, 339);
        this.instance_1 = new lib.ImagenNueva();
        this.instance_1.setTransform(97,296.9,1,1,0,0,0,523.5,384);
        this.instance_1.mask=this.shape_1;
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCFFCC").s().p("A1FdhMAAAg7BMBfTAAAMAAAA7BgEhKNAdhMAAAg7BIMXAAMAAAA7Bg");
        this.shape.setTransform(475.5, 339);
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

 this.addChild(this.titulo, this.logo, this.home, this.shape_1, this.shape, this.instance_1, this.texto, this.instance, this.text);   
  }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
              titulo2(this, txt['tit_farad']);
        var html = createDiv(txt['text_farad_1'], "Verdana", "20px", '770px', '40px', "20px", "185px", "left");
        this.text = new cjs.DOMElement(html);
        this.text.setTransform(90, -522);
        this.instance = new lib.Path_1();
        this.instance.setTransform(880.9, 465, 0.839, 0.839, 0, 0, 0, 98, 103.7);
        this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.706)", 7, 7, 15);

        texto(this, txt['text_farad_2'], 1, 200);
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000033").s().p("A0XdhMAAAg7BMAovAAAMAAAA7Bg");
        this.shape_1.setTransform(209.9, 339);
        this.instance_1 = new lib.faraday();
        this.instance_1.setTransform(64.5,140.2,0.68,0.68);
        this.instance_1.mask = this.shape_1;
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCFFCC").s().p("A1FdhMAAAg7BMBfTAAAMAAAA7BgEhKNAdhMAAAg7BIMXAAMAAAA7Bg");
        this.shape.setTransform(475.5, 339);
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

 this.addChild(this.titulo, this.logo, this.home, this.shape_1, this.shape, this.instance_1, this.texto, this.instance, this.text);   
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
              titulo2(this, txt['tit_mor']);
        var html = createDiv(txt['text_mor_1'], "Verdana", "20px", '770px', '40px', "20px", "185px", "left");
        this.text = new cjs.DOMElement(html);
        this.text.setTransform(90, -522);
        this.instance = new lib.Path_1();
        this.instance.setTransform(880.9, 465, 0.839, 0.839, 0, 0, 0, 98, 103.7);
        this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.706)", 7, 7, 15);

        texto(this, txt['text_mor_2'], 1, 200);
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000033").s().p("A0XdhMAAAg7BMAovAAAMAAAA7Bg");
        this.shape_1.setTransform(209.9, 339);
        this.instance_1 = new lib.SamuelMorse();
        this.instance_1.setTransform(31.1,134,0.465,0.465);
        this.instance_1.mask = this.shape_1;
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCFFCC").s().p("A1FdhMAAAg7BMBfTAAAMAAAA7BgEhKNAdhMAAAg7BIMXAAMAAAA7Bg");
        this.shape.setTransform(475.5, 339);
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

 this.addChild(this.titulo, this.logo, this.home, this.shape_1, this.shape, this.instance_1, this.texto, this.instance, this.text);   
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
              titulo2(this, txt['tit_bell']);
        var html = createDiv(txt['text_bell_1'], "Verdana", "20px", '770px', '40px', "20px", "185px", "left");
        this.text = new cjs.DOMElement(html);
        this.text.setTransform(90, -522);
        this.instance = new lib.Path_1();
        this.instance.setTransform(880.9, 465, 0.839, 0.839, 0, 0, 0, 98, 103.7);
        this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.706)", 7, 7, 15);

        texto(this, txt['text_bell_2'], 1, 200);
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000033").s().p("A0XdhMAAAg7BMAovAAAMAAAA7Bg");
        this.shape_1.setTransform(209.9, 339);
        this.instance_1 = new lib.grahamBell();
        this.instance_1.setTransform(63.5,139.7,0.444,0.444);
        this.instance_1.mask = this.shape_1;
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCFFCC").s().p("A1FdhMAAAg7BMBfTAAAMAAAA7BgEhKNAdhMAAAg7BIMXAAMAAAA7Bg");
        this.shape.setTransform(475.5, 339);
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

 this.addChild(this.titulo, this.logo, this.home, this.shape_1, this.shape, this.instance_1, this.texto, this.instance, this.text);   
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


    (lib.frame3 = function (invento) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
       this.error1 = new lib.panelError();
	this.error1.setTransform(475,345);

        this.cerrar.on("click", function (evt) {
            if (invento == 1)
                putStage(new lib.frame1_1());
            if (invento == 2)
                putStage(new lib.frame1_2());
            if (invento == 3)
                putStage(new lib.frame1_3());
            if (invento == 4)
                putStage(new lib.frame1_4());
            if (invento == 5)
                putStage(new lib.frame1_5());
            if (invento == 6)
                putStage(new lib.frame1_6());
        });
     

        this.addChild(this.error1,this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit_rel']);
        this.instance = new lib.tabla();
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        
 this.practica = new lib.btn_practica(txt['btnsolucion']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
this.practica.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
       
        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.cerrar,this.instance,this.practica );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
           titulo2(this, txt['tit_rel']);
        this.instance = new lib.tabla();

this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#339900").ss(4,1,1).p("Am+unIDlE5IDelJInDpwAm+ElIG6pwIjVkjIjlFRAG/5CIm6KLIDYErIDilAADdqMIDiE2ADdqMIjhFBIHDJpAm+OkIG+FHIG/lXAm+ZDIG+lYIG6FE");
	this.shape.setTransform(481.2,358.7);
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });
     

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.cerrar,this.instance,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '40px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -442);
        else
            escena.texto.setTransform(170 + ancho, -442);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }


    //Simbolillos
(lib.tabla = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._05_OPT();
	this.instance.setTransform(88.5,481.1,0.334,0.346);

	this.instance_1 = new lib._02_OPT();
	this.instance_1.setTransform(88.5,356,0.334,0.346);

	this.instance_2 = new lib._01_OPT();
	this.instance_2.setTransform(88.5,293,0.334,0.346);

	this.instance_3 = new lib._04_OPT();
	this.instance_3.setTransform(88.5,230,0.334,0.346);

	this.instance_4 = new lib._03_OPT();
	this.instance_4.setTransform(88.5,167,0.334,0.346);

	this.text = new cjs.Text(txt['btnmosaico_6'], "22px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.setTransform(743,497.8+incremento);

	this.text_1 = new cjs.Text(txt['btnmosaico_5'], "24px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 24;
	this.text_1.setTransform(743,430.8+incremento);

	this.text_2 = new cjs.Text(txt['btnmosaico_4'], "24px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 24;
	this.text_2.setTransform(743,304.8+incremento);

	this.text_3 = new cjs.Text(txt['btnmosaico_3'], "24px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 24;
	this.text_3.setTransform(743,241.8+incremento);

	this.text_4 = new cjs.Text(txt['btnmosaico_2'], "24px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 24;
	this.text_4.setTransform(743,178.8+incremento);

	this.text_5 = new cjs.Text(txt['btnmosaico_1'], "24px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 24;
	this.text_5.setTransform(743,367.8+incremento);

	this.text_6 = new cjs.Text(txt['text_rel6_1'], "24px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 24;
	this.text_6.setTransform(303,493.8+incremento);

	this.text_7 = new cjs.Text(txt['text_rel5_1'], "24px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 24;
	this.text_7.setTransform(303,430.8+incremento);

	this.text_8 = new cjs.Text(txt['text_rel3_1'], "24px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 24;
	this.text_8.setTransform(303,304.8+incremento);

	this.text_9 = new cjs.Text(txt['text_rel2_1'], "24px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 24;
	this.text_9.setTransform(303,241.8+incremento);

	this.text_10 = new cjs.Text(txt['text_rel1_1'], "24px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 24;
	this.text_10.setTransform(303,178.8+incremento);

	this.text_11 = new cjs.Text(txt['text_rel4_1'], "24px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 24;
	this.text_11.setTransform(303,367.8+incremento);

	this.instance_5 = new lib._06_OPT();
	this.instance_5.setTransform(88.5,418.6,0.334,0.346);

	this.instance_6 = new lib.thomasMini();
	this.instance_6.setTransform(568,324.4,1,1,0,0,0,43.5,31);

	this.instance_7 = new lib.GrahamBell_Mini();
	this.instance_7.setTransform(524.5,481.4);

	this.instance_8 = new lib.Morse_mini();
	this.instance_8.setTransform(524.5,419.4);

	this.instance_9 = new lib.Faraday_Mini();
	this.instance_9.setTransform(524.5,356.4);

	this.instance_10 = new lib.Tesla_Mini();
	this.instance_10.setTransform(524.5,230.4);

	this.instance_11 = new lib.Benjamin_Mini();
	this.instance_11.setTransform(524.5,167.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA99gJzIAAJzIAAJzIAAJ0IAAJ1MgqMAAAItmAAIAAp1IAAp0IAApzIAApzIAAp0IAAp0INmAAMAqMAAAIAAJ0gAmKpzIAAJzIAAJzIAAJ0IAAJ1MgqMAAAItmAAIAAp1IAAp0IAApzIAApzIAAp0IAAp0INmAAMAqMAAAIAAJ0gEA99gTnMgqMAAAIAAJ0MAqMAAAAGLAAINmAAIAApzItmAAAGLznINmAAIAAp0AmKznMgqMAAAIAAJ0MAqMAAAEgwWgJzIAAJzMAqMAAAEg98gTnINmAAIAAp0Eg98gJzINmAAEg98AAAINmAAAmKJzMgqMAAAIAAJ0MAqMAAAEgwWATnIAAJ1Eg98AJzINmAAIAApzEg98ATnINmAAEA99AJzMgqMAAAIAAJ0MAqMAAAAGLTnINmAAIAAJ1AGLJzINmAAIAApzMAqMAAA");
	this.shape.setTransform(484.5,355.5);

	this.addChild(this.shape,this.instance_11,this.instance_10,this.instance_9,this.instance_8,this.instance_7,this.instance_6,this.instance_5,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(88,167,793,377);

    (lib._00086K01 = function () {
        this.initialize(img._00086K01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1047, 768);


    (lib._000IVJ01 = function () {
        this.initialize(img._000IVJ01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 255, 396);


    (lib._01_94177503_OPT = function () {
        this.initialize(img._01_94177503_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 622, 929);


    (lib._01_OPT = function () {
        this.initialize(img._01_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 260, 180);


    (lib._02_104681576_OPT = function () {
        this.initialize(img._02_104681576_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 862, 657);


    (lib._02_OPT = function () {
        this.initialize(img._02_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 260, 180);


    (lib._03_104429226_OPT = function () {
        this.initialize(img._03_104429226_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 968, 1137);


    (lib._03_OPT = function () {
        this.initialize(img._03_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 260, 180);


    (lib._04_87684470_OPT = function () {
        this.initialize(img._04_87684470_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 792, 621);


    (lib._04_OPT = function () {
        this.initialize(img._04_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 260, 180);


    (lib._05_78367298_OPT = function () {
        this.initialize(img._05_78367298_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 808, 746);


    (lib._05_OPT = function () {
        this.initialize(img._05_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 260, 180);


    (lib._06_92074792_OPT = function () {
        this.initialize(img._06_92074792_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1049, 697);


    (lib._06_OPT = function () {
        this.initialize(img._06_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 260, 180);


    (lib.Benjamin_Mini = function () {
        this.initialize(img.Benjamin_Mini);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 87, 62);


    (lib.BenjaminFranklin = function () {
        this.initialize(img.BenjaminFranklin);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 668, 859);


    (lib.Edison_Minicopia = function () {
        this.initialize(img.Edison_Minicopia);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 87, 62);


    (lib.faraday = function () {
        this.initialize(img.faraday);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 448, 576);


    (lib.Faraday_Mini = function () {
        this.initialize(img.Faraday_Mini);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 87, 62);


    (lib.grahamBell = function () {
        this.initialize(img.grahamBell);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 653, 879);


    (lib.GrahamBell_Mini = function () {
        this.initialize(img.GrahamBell_Mini);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 87, 62);


    (lib.Morse_mini = function () {
        this.initialize(img.Morse_mini);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 87, 62);


    (lib.NikolaTEsla = function () {
        this.initialize(img.NikolaTEsla);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 556, 571);


    (lib.pautas950x608nuevosarreglos = function () {
        this.initialize(img.pautas950x608nuevosarreglos);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.SamuelMorse = function () {
        this.initialize(img.SamuelMorse);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 768, 1159);


    (lib.Tesla_Mini = function () {
        this.initialize(img.Tesla_Mini);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 87, 62);


    (lib.thomasAlvaEdison = function () {
        this.initialize(img.thomasAlvaEdison);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 656, 875);


    (lib.thomasMini = function () {
        this.initialize();

        // Capa 1 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("Amyk1INlAAIAAJrItlAAg");
        mask.setTransform(43.5, 31);

        // Capa 2
        this.instance = new lib._00086K01();
        this.instance.setTransform(-231.5, -68.2, 0.368, 0.368);

        this.instance.mask = mask;

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-231.5, -68.2, 385.1, 282.5);


    (lib.ImagenNueva = function () {
        this.initialize();

        // Capa 2 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("A2ZfAMAAAg9/MAs0AAAMAAAA9/g");
        mask.setTransform(641, 420.5);

        // Capa 1
        this.instance = new lib._00086K01();
        this.instance.setTransform(193, 141.6, 0.631, 0.631);

        this.instance.mask = mask;

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(193, 141.6, 661.1, 485);


    (lib.Path = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#F09122", "#DF081F"], [0, 1], 22.6, 52.5, -22, -52.8).s().p("AEVG3IlKlxIjbFxQg1gdgvglQhehKAhglIECkIIjbjkQARhAAZg6QAzh1AmAdIDYFRIEWkqIBGAlQBBArgbAfIkXEXIF/EWQgbA4gjAxQg0BLghAAQgKAAgJgIg");
        this.shape.setTransform(102.6, 102.6, 1, 1, 0, 0, 0, 0.8, -0.3);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(57.5, 58.2, 88.7, 89.5);


    (lib.Path_1 = function () {
        this.initialize();

        // Capa 1
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.lf(["#0B6635", "#95C030"], [0, 1], 34.5, 77.7, -16.7, -68.8).s().p("ApNImQhWg8hWgzIhFgnIg/kOIAKAAQCVAUD6CeQB9BPBfBLQAhogGXnoQCAiZCWiAQBLhBAyghIE7E3QpsF1kSKEQhVDKgpDNQgVBmgDA+QiljQkSjAg");
        this.shape_1.setTransform(97.9, 103.7, 0.5, 0.5);

        this.addChild(this.shape_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(53.3, 56.2, 89.4, 95.1);


    (lib.btn6 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib._06_OPT();
        this.instance.setTransform(-129.9, -89.9);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-129.9, -89.9, 260, 180);


    (lib.btn5 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib._05_OPT();
        this.instance.setTransform(-129.9, -89.9);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-129.9, -89.9, 260, 180);


    (lib.btn4 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib._04_OPT();
        this.instance.setTransform(-129.9, -89.9);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-129.9, -89.9, 260, 180);


    (lib.btn3 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib._03_OPT();
        this.instance.setTransform(-129.9, -89.9);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-129.9, -89.9, 260, 180);


    (lib.btn2 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib._02_OPT();
        this.instance.setTransform(-129.9, -89.9);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-129.9, -89.9, 260, 180);


    (lib.Btn1 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib._01_OPT();
        this.instance.setTransform(-129.9, -89.9);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-129.9, -89.9, 260, 180);


    (lib.respuesta6 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(txt['btnmosaico_6'], "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 16;
        this.text.lineWidth = 228;
        this.text.setTransform(-2, -12.3 + incremento);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#666666").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -2, text: "Alexander Graham Bell", textAlign: "center", lineWidth: 228}}]}).to({state: [{t: this.shape_1}, {t: this.text, p: {color: "#000000", x: -2, text: "Alexander Graham Bell", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape_2}, {t: this.text, p: {color: "#FFFFFF", x: -2, text: "Alexander Graham Bell", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -114.1, text: "¿A qué grupo pertenece?", textAlign: "", lineWidth: 225}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-120.9, -14.9, 242, 30);


    (lib.respuesta5 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(txt['btnmosaico_5'], "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 16;
        this.text.lineWidth = 228;
        this.text.setTransform(-2, -12.3 + incremento);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#666666").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -2, text: "Samuel Morse", textAlign: "center", lineWidth: 228}}]}).to({state: [{t: this.shape_1}, {t: this.text, p: {color: "#000000", x: -2, text: "Samuel Morse", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape_2}, {t: this.text, p: {color: "#FFFFFF", x: -2, text: "Samuel Morse", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -114.1, text: "¿A qué grupo pertenece?", textAlign: "", lineWidth: 225}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-120.9, -14.9, 242, 30);


    (lib.respuesta4 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(txt['btnmosaico_4'], "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 16;
        this.text.lineWidth = 228;
        this.text.setTransform(-2, -12.3 + incremento);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#666666").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -2, text: "Michael Faraday", textAlign: "center", lineWidth: 228}}]}).to({state: [{t: this.shape_1}, {t: this.text, p: {color: "#000000", x: -2, text: "Michael Faraday", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape_2}, {t: this.text, p: {color: "#FFFFFF", x: -2, text: "Michael Faraday", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -114.1, text: "¿A qué grupo pertenece?", textAlign: "", lineWidth: 225}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-120.9, -14.9, 242, 30);


    (lib.respuesta3 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(txt['btnmosaico_3'], "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 16;
        this.text.lineWidth = 228;
        this.text.setTransform(-2, -12.3 + incremento);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#666666").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -2, text: "Thomas Alva Edison", textAlign: "center", lineWidth: 228}}]}).to({state: [{t: this.shape_1}, {t: this.text, p: {color: "#000000", x: -2, text: "Thomas Alva Edison", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape_2}, {t: this.text, p: {color: "#FFFFFF", x: -2, text: "Thomas Alva Edison", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -114.1, text: "¿A qué grupo pertenece?", textAlign: "", lineWidth: 225}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-120.9, -14.9, 242, 30);


    (lib.respuesta2 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(txt['btnmosaico_2'], "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 16;
        this.text.lineWidth = 228;
        this.text.setTransform(-2, -12.3 + incremento);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#666666").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -2, text: "Nikola Tesla", textAlign: "center", lineWidth: 228}}]}).to({state: [{t: this.shape_1}, {t: this.text, p: {color: "#000000", x: -2, text: "Nikola Tesla", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape_2}, {t: this.text, p: {color: "#FFFFFF", x: -2, text: "Nikola Tesla", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -114.1, text: "¿A qué grupo pertenece?", textAlign: "", lineWidth: 225}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-120.9, -14.9, 242, 30);


    (lib.Respuesta1 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(txt['btnmosaico_1'], "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 16;
        this.text.lineWidth = 228;
        this.text.setTransform(-2, -12.3 + incremento);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#666666").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -2, text: "Benjamin Franklin", textAlign: "center", lineWidth: 228}}]}).to({state: [{t: this.shape_1}, {t: this.text, p: {color: "#000000", x: -2, text: "Benjamin Franklin", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape_2}, {t: this.text, p: {color: "#FFFFFF", x: -2, text: "Benjamin Franklin", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -114.1, text: "¿A qué grupo pertenece?", textAlign: "", lineWidth: 225}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-120.9, -14.9, 242, 30);


    (lib.btn_solucion = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text("SOLUCIÓN", "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.setTransform(7.5, -14.8);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-59.3, -11.9, 118.6, 23.8, 6);
        this.shape.setTransform(9.3, -3, 1.096, 1.262);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1, 1, 1).rr(-59.3, -11.9, 118.6, 23.8, 6);
        this.shape_1.setTransform(9.3, -3, 1.096, 1.262);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#666666").ss(1, 1, 1).rr(-59.3, -11.9, 118.6, 23.8, 6);
        this.shape_2.setTransform(9.3, -3, 1.096, 1.262);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_1}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_2}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-55.6, -18.1, 130, 30);


    (lib.btn_practica = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text("PRACTICA", "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.setTransform(7.5, -15.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-50.85, -14.4, 101.7, 28.8, 6);
        this.shape.setTransform(9.4, -2.9, 1.278, 1.043, 0, 0, 0, 0, 0.1);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1, 1, 1).rr(-50.85, -14.4, 101.7, 28.8, 6);
        this.shape_1.setTransform(9.4, -2.9, 1.278, 1.043, 0, 0, 0, 0, 0.1);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#666666").ss(1, 1, 1).rr(-50.85, -14.4, 101.7, 28.8, 6);
        this.shape_2.setTransform(9.4, -2.9, 1.278, 1.043, 0, 0, 0, 0, 0.1);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_1}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_2}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-55.5, -18.1, 130.1, 30);


    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_grupo = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(txt['btnquien'], "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 16;
        this.text.lineWidth = 228;
        this.text.setTransform(-2, -12.3 + incremento);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#666666").ss(1, 1, 1).rr(-121, -15, 242, 30, 6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -2, text: "¿Quién fue el inventor?", textAlign: "center", lineWidth: 228}}]}).to({state: [{t: this.shape_1}, {t: this.text, p: {color: "#000000", x: -2, text: "¿Quién fue el inventor?", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape_2}, {t: this.text, p: {color: "#FFFFFF", x: -2, text: "¿Quién fue el inventor?", textAlign: "center", lineWidth: 228}}]}, 1).to({state: [{t: this.shape}, {t: this.text, p: {color: "#000000", x: -114.1, text: "¿A qué grupo pertenece?", textAlign: "", lineWidth: 225}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-120.9, -14.9, 242, 30);


    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
        this.text.textAlign = "center";
        this.text.lineHeight = 24;
        this.text.lineWidth = 27;
        this.text.setTransform(-6, -16.6, 1.247, 1.197);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
        this.shape.setTransform(0, 5.2, 1.247, 1.197);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
        this.shape_1.setTransform(0, 5.2, 1.247, 1.197);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1, p: {scaleX: 1.247, scaleY: 1.197, y: 5.2}}, {t: this.shape, p: {scaleX: 1.247, scaleY: 1.197, y: 5.2}}, {t: this.text, p: {scaleX: 1.247, scaleY: 1.197, x: -6, y: -16.6}}]}).to({state: [{t: this.shape_1, p: {scaleX: 1.412, scaleY: 1.356, y: 5.3}}, {t: this.shape, p: {scaleX: 1.412, scaleY: 1.356, y: 5.3}}, {t: this.text, p: {scaleX: 1.412, scaleY: 1.356, x: -8.5, y: -19.4}}]}, 1).to({state: [{t: this.shape_1, p: {scaleX: 1.247, scaleY: 1.197, y: 5.2}}, {t: this.shape, p: {scaleX: 1.247, scaleY: 1.197, y: 5.2}}, {t: this.text, p: {scaleX: 1.247, scaleY: 1.197, x: -6, y: -16.6}}]}, 1).to({state: [{t: this.shape_1, p: {scaleX: 1.247, scaleY: 1.197, y: 5.2}}, {t: this.shape, p: {scaleX: 1.247, scaleY: 1.197, y: 5.2}}, {t: this.text, p: {scaleX: 1.247, scaleY: 1.197, x: -6, y: -16.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.panelError = function () {
        this.initialize();

        // Capa 3
       this.instance = new lib.Path();
        this.instance.setTransform(-10.8, -34.9, 1.389, 1.389, 0, 0, 0, 101.9, 102.9);
        this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.706)", 7, 7, 15);

        // Capa 2
        this.text = new cjs.Text(txt['text_incorrect'], "20px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 20;
        this.text.setTransform(-9.7, 71.7);

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFCCCC").s().p("EhKNAdhMAAAg7BMCUbAAAMAAAA7Bg");

        // Capa 4
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("EhKNAvfMAAAhe9MCUbAAAMAAABe9g");
        this.shape_1.setTransform(0, -36.9);

        this.addChild(this.shape_1, this.shape, this.text, this.instance, this.cerrar1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-474.9, -340.9, 950, 608);


    (lib.mosaico = function () {
        this.initialize();

        // Capa 4 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("AqONqIAA7UIUdAAIAAbUg");
        mask.setTransform(69.5, 87.5);

        // Capa 5
        this.instance = new lib.ImagenNueva();
        this.instance.setTransform(-46.7, 139.8, 0.892, 0.892, 0, 0, 0, 523.5, 384.1);

        this.instance.mask = mask;

        // Capa 3 (mask)
        var mask_1 = new cjs.Shape();
        mask_1._off = true;
        mask_1.graphics.p("ARCdTIAA7XIUdAAIAAbXgArjdTIAA7XIUdAAIAAbXgEgmHAdTIAA7XIUeAAIAAbXgARph8IAA7WIUfAAIAAbWgArZh8IAA7WIUdAAIAAbWg");
        mask_1.setTransform(248, 187.5);

        // Capa 2
        this.instance_1 = new lib.BenjaminFranklin();
        this.instance_1.setTransform(164.1, 192.5, 0.228, 0.228);

        this.instance_2 = new lib.faraday();
        this.instance_2.setTransform(342, 179.9, 0.349, 0.349);

        this.instance_3 = new lib.grahamBell();
        this.instance_3.setTransform(0.4, 197.8, 0.205, 0.205);

        this.instance_4 = new lib.NikolaTEsla();
        this.instance_4.setTransform(338.6, 2, 0.305, 0.305);

        this.instance_5 = new lib.SamuelMorse();
        this.instance_5.setTransform(150.1, -9.9, 0.239, 0.239);

        this.instance_1.mask = this.instance_2.mask = this.instance_3.mask = this.instance_4.mask = this.instance_5.mask = mask_1;

        this.addChild(this.instance_5, this.instance_4, this.instance_3, this.instance_2, this.instance_1, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-70, -9.9, 578.2, 398.1);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '400px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);

    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
    this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
    new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}