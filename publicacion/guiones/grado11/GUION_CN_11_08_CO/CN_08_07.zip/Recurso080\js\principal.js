(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 1, 0);
       this.encendido = new lib.on();
	this.encendido.setTransform(475.3,319.4,1.5,1.5,0,0,0,44,0);
	new cjs.ButtonHelper(this.encendido, 0, 1, 2, false, new lib.on(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EhKNAvgMAAAhe/MCUbAAAMAAABe/g");
	this.shape.setTransform(475,304);
        
        
this.encendido.on("click", function (evt) {
            putStage(new lib.frame1_0());
 });

    

        this.addChild(this.logo, this.titulo, this.siguiente, this.shape,this.encendido);
    }).prototype = p = new cjs.Container();
    
       (lib.frame1_0 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 1, 0);
        this.encendido = new lib.encendido();
	

    

        this.addChild(this.logo, this.titulo, this.siguiente, this.shape,this.encendido);
    }).prototype = p = new cjs.Container();
     p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     
     (lib.frame1_0b = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 1, 0);
           titulo1(this,txt['titulo']);


	// Capa 10
	this.text = new cjs.Text(txt['nom_2'], "16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(635.6,272.9);

	this.text_1 = new cjs.Text(txt['nom_4'], "16px Verdana");
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(635.6,462.3);

	this.text_2 = new cjs.Text(txt['nom_3'], "16px Verdana");
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(635.6,375.3);

	this.text_3 = new cjs.Text(txt['nom_1'], "16px Verdana");
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(635.6,188.9);

	this.btn4 = new lib.tipos();
	this.btn4.setTransform(235,494);
	new cjs.ButtonHelper(this.btn4, 0, 1, 2, false, new lib.tipos(), 3);

	this.btn3 = new lib.conductores();
	this.btn3.setTransform(235,404);
	new cjs.ButtonHelper(this.btn3, 0, 1, 2, false, new lib.conductores(), 3);

	this.btn2 = new lib.gasRelleno();
	this.btn2.setTransform(720,340);
	new cjs.ButtonHelper(this.btn2, 0, 1, 2, false, new lib.gasRelleno(), 3);

	this.btn1 = new lib.Filamento();
	this.btn1.setTransform(235,272);
	new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.Filamento(), 3);

   this.btn1.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
   this.btn2.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
   this.btn3.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
   this.btn4.on("click", function (evt) {
            putStage(new lib.frame1_4());
        });

         this.informacion.on("click", function (evt) {
            putStage(new lib.frame2());
        });
         this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        
	this.instance_1 = new lib.bombilla();
	this.instance_1.setTransform(467.5,330.4,2.208,2.208,0,0,0,44,0);
        this.addChild(this.logo, this.titulo, this.siguiente,this.home,this.informacion,this.instance_1,this.btn1,this.btn2,this.btn3,this.btn4,this.text_3,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
     p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 
    (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['popup_1_tit']);
        texto(this, txt['popup_1_text'],1,250,-440);
this.instance_1 = new lib._0012XN01();
	this.instance_1.setTransform(81.6,528.4,0.49,0.49,-89.9);
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_0b());
        });
        

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.texto,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['popup_3_tit']);
        texto(this, txt['popup_3_text'],1,250,-400);
this.instance = new lib.Mapadebits6();
	this.instance.setTransform(81,240.4,0.669,0.67);
     this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_0b());
        });    

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.texto,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame1_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['popup_2_tit']);
         texto(this, txt['popup_2_text'],1,250,-440);
this.instance = new lib.haloAnim();
	this.instance.setTransform(219,282.5);

	this.instance_1 = new lib.animacionLuz();
	this.instance_1.setTransform(217.4,314.9,0.871,0.871,0,0,0,0,3.5);    this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_0b());
        });     

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.texto,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame1_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['popup_4_tit']);
           texto(this, txt['popup_4_text'],0,-40);
this.instance = new lib.Halogena2_MC();
	this.instance.setTransform(179.8,340.1,1,1,0,0,0,134.9,90);

	this.text = new cjs.Text(txt['popup_4nom_3'], "20px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(742.4,470.9);

	this.text_1 = new cjs.Text(txt['popup_4nom_2'], "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(407.4,470.9);

	this.text_2 = new cjs.Text(txt['popup_4nom_1'], "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(85.4,470.9);

	this.instance_1 = new lib._104462060_OPT();
	this.instance_1.setTransform(635.4,250,0.3,0.3);

	this.instance_2 = new lib._101485277_OPT();
	this.instance_2.setTransform(340.2,250.1,0.312,0.312);
    this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_0b());
        });     

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.cerrar,this.texto,this.instance_2,this.instance_1,this.text_2,this.text_1,this.text,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['info1'],1,250);
	this.instance_1 = new lib._000Z8401();
	this.instance_1.setTransform(81,153,0.487,0.487);


        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_0b());
        });
       

        this.addChild(this.logo, this.texto, this.home, this.siguiente, this.cerrar,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   
// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
   function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(70, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
      function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
   
   //Simbolillos
   (lib.encendido = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{intro:0});

this.frame_2 = function() {
    
		  putStage(new lib.frame1_0b());
                 
	}
      this.timeline.addTween(cjs.Tween.get(this).wait(115).call(this.frame_2).wait(105));
  
	// timeline functions:
	this.frame_1 = function() {
		playSound("interruptor");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(105));

	// Capa 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhKNAfAMAAAg9/MCUbAAAMAAAA9/g");
	mask.setTransform(475,330.5);

	// Capa 5
	this.instance = new lib.luz();
	this.instance.setTransform(475,330.7,0.441,0.441);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(15).to({_off:false},0).to({alpha:1},16).to({scaleX:0.85,scaleY:0.85,x:562.1,y:510.8},58).wait(18));

	// Capa 7
	this.off = new lib.off();
	this.off.setTransform(475.3,319.4,1.5,1.5,0,0,0,44,0);
	new cjs.ButtonHelper(this.off, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.off}]}).wait(107));

	// fondo
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EhKNAvgMAAAhe/MCUbAAAMAAABe/g");
	this.shape.setTransform(475,304);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(107));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);

   (lib.Path_168 = function() {
	this.initialize(img.Path_168);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,249,178);


(lib._000Z8401 = function() {
	this.initialize(img._000Z8401);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,507,768);


(lib._0012XN01 = function() {
	this.initialize(img._0012XN01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,768,508);


(lib._101485277_OPT = function() {
	this.initialize(img._101485277_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,864,576);


(lib._104462060_OPT = function() {
	this.initialize(img._104462060_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,900,600);


(lib._89952737_OPT = function() {
	this.initialize(img._89952737_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,722,480);


(lib.halogena_OPT_2 = function() {
	this.initialize(img.halogena_OPT_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,333,500);


(lib.halogena2_OPT = function() {
	this.initialize(img.halogena2_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,533,400);


(lib.Mapadebits6 = function() {
	this.initialize(img.Mapadebits6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,396,298);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.shutterstock_58198057_OPT = function() {
	this.initialize(img.shutterstock_58198057_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1344,896);


(lib.luz = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.shutterstock_58198057_OPT();
	this.instance.setTransform(-671.9,-447.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-671.9,-447.9,1344,896);


(lib.Halogena2_MC = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A1EuCMAqJAAAIAAcFMgqJAAAg");
	mask.setTransform(135,90);

	// Capa 2
	this.instance = new lib.halogena2_OPT();
	this.instance.setTransform(-0.9,-11.9,0.511,0.511);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.9,-11.9,272.6,204.6);


(lib.halo = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF99").s().p("As2M3QlVlVAAniQAAnhFVlWQFVlUHhAAQHiAAFWFUQFUFWAAHhQAAHilUFVQlWFVniAAQnhAAlVlVg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-116.4,-116.4,233,233);


(lib.Grupodeclips0_36 = function() {
	this.initialize();

	// Capa 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#448592").ss(0.3,0,0,3.9).p("AGlA1QgsBdhOBDQghAcgTAmQgUAogBAtIAADMQAAAYgRAQQgRARgXAAIlRAAQgYAAgQgRQgRgQAAgYIACjLQgBgsgUgoQgSgmghgcQhPhDgtheQguhfAAhsQAAjFCJiKQCIiLDAAAQDAAACJCLQCJCKAADFQAABrgtBfg");
	this.shape.setTransform(46.8,62.6);

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AioJwQgYABgQgRQgRgRAAgXIACjMQgBgrgUgoQgSgmghgdQhPhDgthdQguhfAAhsQAAjFCJiKQCIiMDAAAQDAAACJCMQCJCKAADFQAABrgtBeQgsBehOBCQghAcgTAnQgUAogBAtIAADMQAAAXgRARQgRARgXgBg");
	mask.setTransform(46.8,62.6);

	// Capa 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D3DCE0").s().p("AiXIyQgVAAgPgPQgPgPAAgVIABi3QAAgogSgjQgQgjgegZQhIg9gohTQgphWAAhiQAAiwB7h9QB7h9CsAAQCtAAB7B9QB7B9AACwQAABigoBVQgoBUhGA7QgeAZgRAjQgSAkgBAoIAAC4QAAAVgPAPQgPAPgVAAg");
	this.shape_1.setTransform(46.8,62.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D2DBDF").s().p("AiYIzQgUAAgQgPQgPgOABgWIABi3QAAgogSgkQgRgigdgaQhJg8gohVQgphVAAhiQAAixB7h9QB8h9CsAAQCuAAB7B9QB7B9AACxQAABhgoBWQgoBThHA9QgeAZgRAjQgRAjgCApIAAC4QABAWgQAOQgPAPgVAAg");
	this.shape_2.setTransform(46.8,62.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D0D9DE").s().p("AiYI0QgVAAgPgOQgPgPAAgWIACi4QgBgogRgjQgSgjgdgaQhIg8gohUQgqhWAAhiQAAixB7h+QB8h9CtAAQCuAAB8B9QB7B+AACxQAABhgpBWQgoBUhGA8QgeAZgRAjQgSAlgBAnIAAC5QAAAWgPAPQgPAOgVAAg");
	this.shape_3.setTransform(46.8,62.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CED8DD").s().p("AiYI1QgWAAgPgOQgOgQAAgUIACi5QgBgngSgkQgRgkgdgZQhJg9gohVQgqhVAAhjQAAixB8h+QB7h9CuAAQCuAAB9B9QB7B9AACyQAABigpBWQgoBUhGA9QgeAYgSAkQgSAkgBAoIAAC6QABAUgPAQQgQAOgVAAg");
	this.shape_4.setTransform(46.8,62.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCD6DB").s().p("AiZI3QgVAAgPgPQgPgPAAgVIACi5QgBgogSgkQgRgjgdgaQhJg8gohVQgqhWAAhjQAAiyB8h+QB8h+CuAAQCvAAB8B+QB8B+AACyQAABigpBWQgoBVhHA8QgeAZgRAjQgSAkgBAoIAAC7QAAAVgPAPQgPAPgWAAg");
	this.shape_5.setTransform(46.8,62.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CAD5DA").s().p("AiZI4QgVAAgPgPQgQgPAAgWIACi4QgBgogRglQgRgjgegZQhIg9gphVQgqhWAAhjQAAiyB9h/QB8h+CuAAQCvAAB8B+QB9B/AACyQAABigqBWQgnBVhHA8QgeAagSAjQgSAkgBAoIAAC6QAAAWgPAPQgPAPgVAAg");
	this.shape_6.setTransform(46.8,62.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#C8D4D9").s().p("AiZI6QgWAAgPgQQgOgPAAgWIABi4QgBgpgRgkQgSgjgegaQhIg8gohWQgqhWgBhkQAAizB9h+QB8h/CvAAQCvAAB9B/QB9B+AACzQAABjgqBWQgoBVhGA8QgeAagSAjQgSAlgBAoIAAC6QAAAWgPAPQgPAQgWAAg");
	this.shape_7.setTransform(46.8,62.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#C6D2D8").s().p("AiaI6QgVAAgPgPQgPgPAAgVIACi6QgCgogRglQgRgigegaQhIg9gphWQgqhWgBhkQABizB8h/QB9h/CvAAQCwAAB9B/QB9B/AACzQAABjgqBWQgoBVhHA9QgeAagRAjQgSAlgCAoIAAC7QAAAVgPAPQgPAPgVAAg");
	this.shape_8.setTransform(46.8,62.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C4D1D7").s().p("AiaI8QgVAAgQgQQgPgPAAgVIACi6QgBgpgRgkQgRgjgfgaQhIg9gphWQgqhXgBhjQABi0B9h/QB9h/CvAAQCxAAB8B/QB9B/ABC0QAABjgqBWQgoBWhHA8QgfAagRAjQgSAlgCApIAAC7QAAAVgOAPQgPAQgWAAg");
	this.shape_9.setTransform(46.8,62.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#C3D0D6").s().p("AiaI9QgWAAgPgPQgPgQAAgVIACi6QgBgpgSglQgRgigegbQhJg8gphXQgqhXAAhkQAAi0B9h/QB+h/CvAAQCxAAB9B/QB9B/AAC0QAABjgpBXQgoBWhIA9QgeAagRAjQgTAkgBAqIAAC7QAAAVgPAQQgPAPgWAAg");
	this.shape_10.setTransform(46.8,62.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C1CED4").s().p("AibI+QgVAAgPgPQgQgPAAgWIACi6QgBgqgSgkQgRgjgegaQhJg+gphWQgqhXAAhkQAAi0B9h/QB+iACwAAQCxAAB+CAQB9B/AAC0QAABjgpBXQgpBWhHA9QgfAagRAjQgTAlgBApIAAC8QAAAWgPAPQgPAPgWAAg");
	this.shape_11.setTransform(46.8,62.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BFCDD3").s().p("AibJAQgVgBgQgPQgPgPAAgWIACi7QgBgpgSglQgRgjgegZQhKg+gphXQgqhXAAhkQAAi1B+h/QB+iBCwABQCygBB9CBQB+B/AAC1QAABjgpBXQgpBWhIA+QgeAagRAjQgTAkgBAqIAAC8QAAAWgPAPQgPAPgWABg");
	this.shape_12.setTransform(46.8,62.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#BDCCD2").s().p("AibJBQgWAAgPgQQgQgPAAgVIACi8QAAgpgTglQgRgjgegaQhJg+gqhXQgqhXAAhkQAAi2B+h/QB+iBCxAAQCyAAB+CBQB+B/AAC2QAABjgpBXQgpBXhIA9QgfAagRAjQgSAmgBApIAAC9QAAAVgQAPQgPAQgWAAg");
	this.shape_13.setTransform(46.8,62.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#BBCAD1").s().p("AicJCQgVAAgPgQQgQgOAAgXIACi8QgBgogSglQgSgkgdgZQhKg+gqhYQgqhXAAhlQAAi1B/iAQB+iBCxAAQCzAAB9CBQB/CAAAC1QAABkgqBXQgoBXhJA9QgeAagRAkQgTAlgBApIAAC9QAAAXgPAOQgPAQgWAAg");
	this.shape_14.setTransform(46.8,62.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#BAC9D0").s().p("AicJDQgWAAgPgQQgQgPAAgWIACi8QAAgpgTgkQgRgkgegaQhKg+gphYQgrhYAAhkQAAi2B+iBQCAiACxAAQCzAAB+CAQB/CBAAC2QAABkgqBYQgpBWhIA+QgeAagSAkQgSAlgBApIAAC9QAAAXgQAOQgPAQgWAAg");
	this.shape_15.setTransform(46.8,62.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#B8C8CF").s().p("AicJEQgWAAgPgPQgQgPAAgXIACi8QgBgpgSglQgRgkgegaQhLg+gphXQgrhYAAhlQAAi2B/iCQB/iACygBQCzABB/CAQB/CCAAC2QAABkgqBYQgpBWhJA/QgeAZgRAkQgTAlgBApIAAC+QAAAXgQAPQgPAPgWAAg");
	this.shape_16.setTransform(46.8,62.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#B6C7CE").s().p("AidJFQgVAAgQgPQgPgPAAgWIABi+QgBgpgSgkQgRgkgegaQhKg/gqhXQgrhZAAhkQAAi3B/iCQB/iACzAAQCzAACACAQB/CCAAC3QAABkgrBYQgoBXhJA+QgfAagRAkQgTAlgBApIAAC/QAAAVgPAQQgQAPgWAAg");
	this.shape_17.setTransform(46.8,62.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#B4C5CD").s().p("AicJHQgXAAgPgPQgQgQAAgWIACi+QgBgpgSglQgSgjgdgbQhLg+gphYQgrhZgBhkQAAi4CAiCQB/iBCzAAQC0AAB/CBQCACCAAC4QgBBkgqBYQgpBXhIA/QgfAagSAkQgSAkgBAqIAAC/QAAAWgQAQQgPAPgWAAg");
	this.shape_18.setTransform(46.8,62.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#B3C4CC").s().p("AidJIQgWAAgPgPQgQgQAAgWIACi+QgBgpgSglQgSgkgegaQhLg/gphYQgrhYgBhmQAAi3CAiCQCAiCCzAAQC0AACACCQCACCAAC3QgBBlgqBYQgpBYhIA+QggAagRAkQgSAlgCApIAADAQAAAWgQAQQgPAPgWAAg");
	this.shape_19.setTransform(46.8,62.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#B1C3CB").s().p("AidJKQgXAAgPgQQgPgQAAgWIABi+QAAgpgTglQgSglgegaQhKg+gqhZQgshZABhlQAAi4B/iCQCBiDCzAAQC0AACBCDQB/CCAAC4QABBlgrBYQgpBYhJA+QgfAagSAlQgTAlgBApIAADAQAAAWgPAQQgPAQgXAAg");
	this.shape_20.setTransform(46.8,62.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#AFC2C9").s().p("AidJLQgXAAgPgQQgQgQAAgVIACi/QgBgqgSglQgSgkgegbQhMg/gphYQgrhZAAhlQgBi5CBiCQCAiCC0gBQC1ABCBCCQB/CCAAC5QAABlgqBYQgpBYhJA/QgfAagTAkQgSAmgBApIAADBQAAAVgQAQQgPAQgWAAg");
	this.shape_21.setTransform(46.8,62.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#ADC0C8").s().p("AieJMQgWAAgQgQQgPgPAAgXIABi/QAAgqgTglQgSgjgegcQhLg+gqhZQgrhZAAhmQAAi4CAiDQCBiCC0gBQC2ABCACCQCBCDgBC4QAABlgqBZQgpBYhKA/QgfAagSAlQgTAlgBAqIAADAQAAAXgPAPQgQAQgWAAg");
	this.shape_22.setTransform(46.8,62.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#ACBFC7").s().p("AifJNQgWAAgQgQQgPgPAAgXIACi/QgBgqgTglQgRgkgfgbQhLg/gqhZQgrhZAAhmQAAi6CAiCQCBiDC1AAQC2AACACDQCBCDAAC5QAABmgqBZQgqBXhJBAQggAagSAkQgSAmgBAqIAADAQAAAXgQAPQgQAQgWAAg");
	this.shape_23.setTransform(46.8,62.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#AABEC6").s().p("AieJOQgXAAgQgQQgPgPAAgXIACi/QgBgqgTgmQgSgkgegbQhMg/gqhZQgrhZAAhmQAAi6CBiDQCBiDC1AAQC2AACBCDQCBCDAAC6QAABlgqBaQgqBYhJA/QggAbgSAkQgSAmgCAqIAADAQAAAXgPAPQgQAQgWAAg");
	this.shape_24.setTransform(46.8,62.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#A8BDC5").s().p("AifJPQgWAAgQgPQgPgQAAgXIABjAQgBgqgSglQgSgkgfgbQhLhAgrhYQgrhaAAhmQAAi6CCiEQCAiEC2ABQC2gBCCCEQCBCEAAC6QAABlgrBaQgpBYhKA/QgfAbgTAkQgSAmgBAqIAADBQAAAXgPAQQgRAPgWAAg");
	this.shape_25.setTransform(46.8,62.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#A6BBC4").s().p("AifJQQgWAAgRgPQgPgQAAgWIACjBQgCgqgSgmQgRgjgggcQhLg/grhZQgrhaAAhnQAAi6CCiEQCBiDC2AAQC3AACBCDQCCCEAAC6QAABngrBZQgqBYhJA/QggAbgSAlQgSAlgCArIAADCQAAAWgPAQQgRAPgWAAg");
	this.shape_26.setTransform(46.8,62.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#A4BAC3").s().p("AifJSQgXAAgQgQQgPgQAAgWIACjBQgCgqgSgmQgSgkgfgbQhMhAgqhZQgshbAAhmQAAi7CCiEQCCiEC2AAQC3AACCCEQCCCEAAC7QAABmgrBaQgqBZhKA/QggAbgRAkQgTAmgCAqIAADDQAAAWgPAQQgQAQgWAAg");
	this.shape_27.setTransform(46.8,62.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#A3B9C2").s().p("AigJTQgXAAgPgQQgQgPAAgXIACjCQgBgqgTgmQgSgjgfgcQhMg/gqhaQgshaAAhnQAAi8CCiEQCCiEC3AAQC3AACDCEQCCCEAAC8QAABmgrBaQgqBZhKA/QggAbgSAlQgTAlgBArIAADDQAAAXgQAPQgQAQgWAAg");
	this.shape_28.setTransform(46.8,62.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#A1B8C1").s().p("AihJVQgWgBgQgQQgQgPAAgXIACjCQgBgqgSgmQgSgkgfgcQhMg/grhaQgshaAAhoQAAi8CDiEQCCiEC3gBQC4ABCCCEQCDCEAAC8QAABngsBaQgpBahLA/QgfAagTAlQgSAngCAqIAADDQAAAXgPAPQgQAQgXABg");
	this.shape_29.setTransform(46.8,62.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#9FB7C0").s().p("AihJWQgWgBgQgQQgQgPAAgWIACjDQgBgqgTgmQgSglgfgbQhMhAgqhaQgshbAAhnQgBi8CDiEQCDiGC3AAQC4AACDCGQCDCEgBC8QAABngrBaQgqBZhKBAQggAbgSAlQgTAmgBAqIAADFQAAAWgPAPQgQAQgXABg");
	this.shape_30.setTransform(46.8,62.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#9EB6BF").s().p("AihJWQgXAAgQgPQgQgQAAgXIADjDQgCgqgSglQgSglgfgcQhMg/grhbQgshbAAhoQAAi7CCiFQCDiGC4ABQC5gBCDCGQCCCFAAC7QABBogsBaQgpBahMA/QggAcgRAkQgUAnAAAqIAADEQAAAXgQAQQgQAPgXAAg");
	this.shape_31.setTransform(46.8,62.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#9CB4BE").s().p("AiiJYQgWAAgQgQQgQgQAAgXIACjCQgBgrgTgmQgRglgggbQhMhAgrhbQgshbAAhoQAAi8CCiFQCEiGC4AAQC5AACECGQCCCFAAC8QAABogrBaQgqBahLBAQggAbgSAlQgTAngBAqIAADEQAAAXgQAQQgQAQgWAAg");
	this.shape_32.setTransform(46.8,62.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#9AB3BD").s().p("AiiJZQgWAAgQgQQgQgPAAgYIABjDQgBgrgSglQgSglgfgbQhOhBgqhbQgshbAAhoQAAi9CDiFQCDiGC5AAQC5AACECGQCDCFAAC9QAABogrBbQgqBahMA/QggAcgRAkQgUAnAAAqIAADFQAAAYgQAPQgQAQgXAAg");
	this.shape_33.setTransform(46.8,62.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#99B2BC").s().p("AiiJbQgXAAgQgQQgQgQAAgYIACjDQgBgrgTgmQgSgkgfgcQhNhAgrhbQgshcAAhpQAAi9CDiGQCEiFC5AAQC6AACDCFQCECGAAC9QAABogrBbQgrBbhLBAQggAbgSAmQgTAlgBAsIAADEQAAAYgQAQQgQAQgXAAg");
	this.shape_34.setTransform(46.8,62.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#97B1BB").s().p("AijJcQgWAAgQgQQgQgQAAgXIACjEQgCgrgSgmQgSgmgggbQhNhAgrhbQgshbAAhqQAAi+CEiGQCEiGC5AAQC6AACECGQCECHAAC9QAABpgsBbQgqBahLBAQggAbgTAmQgTAmgBArIAADGQAAAXgQAQQgQAQgXAAg");
	this.shape_35.setTransform(46.8,62.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#95B0BA").s().p("AijJdQgWAAgQgQQgQgQgBgXIACjEQAAgrgUgnQgSglgfgbQhNhBgshbQgshcAAhpQAAi+CEiHQCFiGC5AAQC7AACECGQCECHAAC+QAABogsBcQgqBahLBBQghAbgSAmQgTAmgBArIAADGQgBAXgQAQQgPAQgXAAg");
	this.shape_36.setTransform(46.8,62.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#94AFB9").s().p("AijJeQgXAAgQgQQgQgQAAgXIACjFQgBgrgTgmQgSgmgfgbQhOhBgshbQgshcAAhqQAAi+CFiHQCEiGC6AAQC7AACFCGQCECHAAC+QAABpgsBcQgqBbhMBAQggAbgTAmQgTAngBArIAADGQAAAXgQAQQgQAQgXAAg");
	this.shape_37.setTransform(46.8,62.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#92AEB8").s().p("AikJfQgXAAgPgQQgQgQgBgXIACjGQgBgqgTgnQgRglghgbQhNhCgrhbQgthcAAhqQAAi/CFiGQCFiIC6AAQC7AACFCIQCFCGAAC/QAABqgsBbQgrBbhLBBQghAbgSAmQgTAmgBAsIAADGQgBAXgQAQQgQAQgWAAg");
	this.shape_38.setTransform(46.8,62.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#90ADB7").s().p("AikJgQgXABgPgRQgRgPAAgYIACjGQgBgrgTgmQgSgmgggbQhNhCgshbQgthdAAhpQAAi/CFiHQCFiHC7AAQC8AACFCHQCFCHAAC/QAABpgsBcQgrBbhMBBQggAcgTAlQgTAngBArIAADHQAAAYgQAPQgQARgXgBg");
	this.shape_39.setTransform(46.8,62.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#8EACB6").s().p("AikJiQgXAAgQgQQgRgRAAgXIACjGQgBgrgTgnQgSglgggbQhOhCgrhcQgthcAAhqQAAjACFiHQCGiIC7AAQC8AACFCIQCGCHAADAQAABpgsBcQgrBchMBBQghAbgSAmQgUAngBAqIAADIQAAAXgQARQgQAQgXAAg");
	this.shape_40.setTransform(46.8,62.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#8DABB5").s().p("AilJjQgXAAgQgQQgQgRAAgXIACjGQgBgrgTgnQgSgmgggbQhOhCgshcQgthdAAhqQAAjACGiHQCFiIC8AAQC8AACGCIQCGCHAADAQAABqgtBcQgrBchMBBQggAcgTAlQgTAngBArIAADIQAAAXgRARQgQAQgXAAg");
	this.shape_41.setTransform(46.8,62.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#8BAAB5").s().p("AilJkQgXAAgQgQQgQgQAAgYIABjHQgBgrgSgnQgTglgggcQhOhBgrhdQguhdABhqQAAjBCGiHQCFiIC8AAQC9AACFCIQCGCHAADBQABBqgtBcQgrBchMBCQghAbgSAmQgUAmgBAsIAADIQAAAYgQAQQgQAQgXAAg");
	this.shape_42.setTransform(46.8,62.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#8AA9B4").s().p("AilJmQgXAAgQgRQgQgQAAgXIABjIQgBgrgTgnQgSgmgggcQhPhCgrhcQgthdAAhqQAAjBCFiIQCHiJC8AAQC9AACGCJQCGCIAADBQAABpgsBdQgrBchNBCQggAcgTAlQgTAngBAsIAADJQAAAXgRAQQgQARgXAAg");
	this.shape_43.setTransform(46.8,62.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#88A8B3").s().p("AilJnQgYAAgPgRQgRgQAAgXIACjIQgCgrgSgoQgTglgggcQhOhBgshdQgthdgBhrQAAjBCHiJQCGiIC9gBQC+ABCGCIQCGCJAADBQAABpgsBdQgrBchNBCQghAcgSAlQgTAogCArIAADKQAAAXgQAQQgQARgXAAg");
	this.shape_44.setTransform(46.8,62.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#86A6B2").s().p("AilJoQgYAAgQgRQgQgPAAgYIACjIQgBgsgUgnQgSgmghgcQhOhCgshcQgthegBhqQAAjCCHiJQCHiJC9AAQC+AACHCJQCHCJAADCQgBBqgsBdQgrBchOBCQggAbgSAmQgUAngCAsIAADKQAAAXgQAQQgQARgXAAg");
	this.shape_45.setTransform(46.8,62.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#85A5B1").s().p("AimJpQgXAAgRgRQgQgQAAgXIACjIQgBgsgUgoQgSglgggcQhPhCgshdQgtheAAhrQAAjCCHiJQCGiJC+AAQC+AACHCJQCHCJAADCQAABqgtBeQgrBchNBCQghAcgSAmQgUAngBAsIAADKQAAAXgRAQQgQARgXAAg");
	this.shape_46.setTransform(46.8,62.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#83A4B0").s().p("AimJqQgYAAgQgQQgQgRAAgXIACjJQgCgrgTgoQgSgmgggcQhQhCgshdQgtheAAhrQAAjCCHiKQCHiKC+ABQC/gBCHCKQCHCKAADCQAABqgsBeQgsBdhNBBQghAcgSAmQgUAngCAtIAADKQAAAXgQARQgQAQgYAAg");
	this.shape_47.setTransform(46.8,62.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#82A3AF").s().p("AimJrQgYAAgRgQQgQgQAAgYIACjJQgBgsgUgnQgRgmghgdQhPhCgthcQgthfAAhrQAAjDCHiKQCIiJC+AAQC/AACICJQCHCKAADDQAABrgtBdQgrBdhOBCQghAcgSAmQgUAngBAtIAADKQAAAYgQAQQgRAQgXAAg");
	this.shape_48.setTransform(46.8,62.6);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#80A2AE").s().p("AinJtQgXAAgRgQQgQgRgBgYIADjJQgCgsgTgoQgSgmgggcQhQhDgshcQguhfAAhsQAAjDCIiKQCIiKC+AAQDAAACICKQCHCKAADDQAABrgtBeQgrBdhOBCQghAcgTAmQgTAogCAsIAADLQAAAYgQARQgRAQgXAAg");
	this.shape_49.setTransform(46.8,62.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#7EA1AD").s().p("AinJuQgYAAgRgQQgQgRAAgYIACjJQgBgsgUgoQgRgmghgdQhPhCgthdQguhfAAhsQAAjECIiKQCIiKC/AAQDAAACICKQCICKAADEQAABrgtBeQgsBdhNBCQgiAcgSAnQgUAogBAsIAADLQAAAYgQARQgRAQgYAAg");
	this.shape_50.setTransform(46.8,62.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#7DA0AC").s().p("AinJwQgYAAgRgRQgQgRAAgXIACjLQgCgsgTgnQgSgnghgcQhPhDgthdQguhfAAhsQAAjFCJiKQCIiKC/gBQDAABCJCKQCICKAADFQAABrgtBeQgsBehOBCQghAcgTAnQgTAogBAsIAADMQgBAXgQARQgQARgYAAg");
	this.shape_51.setTransform(46.8,62.6);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#7B9FAB").s().p("AioJwQgYABgQgRQgRgRAAgXIACjMQgBgrgUgoQgSgmghgdQhPhDgthdQguhfAAhsQAAjFCJiKQCIiMDAAAQDAAACJCMQCJCKAADFQAABrgtBeQgsBehOBCQghAcgTAnQgUAogBAtIAADMQAAAXgRARQgRARgXgBg");
	this.shape_52.setTransform(46.8,62.6);

	this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = this.shape_37.mask = this.shape_38.mask = this.shape_39.mask = this.shape_40.mask = this.shape_41.mask = this.shape_42.mask = this.shape_43.mask = this.shape_44.mask = this.shape_45.mask = this.shape_46.mask = this.shape_47.mask = this.shape_48.mask = this.shape_49.mask = this.shape_50.mask = this.shape_51.mask = this.shape_52.mask = mask;

	// Capa 1
	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#AEC1C9").s().p("AioJwQgYABgQgRQgRgRAAgXIACjMQgBgrgUgoQgSgmghgdQhPhDgthdQguhfAAhsQAAjFCJiKQCIiMDAAAQDAAACJCMQCJCKAADFQAABrgtBeQgsBehOBCQghAcgTAnQgUAogBAtIAADMQAAAXgRARQgRARgXgBg");
	this.shape_53.setTransform(46.8,62.6);

	this.addChild(this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0.2,0.1,93.3,125);


(lib.Grupodeclips0_35 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkeEfQh3h3AAioQAAinB3h3QB3h3CnAAQCoAAB3B3QB3B3AACnQAACoh3B3Qh3B3ioAAQinAAh3h3g");
	mask.setTransform(46.5,46.5);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E7EBED").s().p("AjvDwQhkhkAAiMQAAiLBkhkQBkhkCLAAQCNAABjBkQBkBkAACLQAACMhkBkQhjBkiNAAQiLAAhkhkg");
	this.shape.setTransform(46.5,46.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E7EBED").s().p("AjwDxQhkhkAAiNQAAiMBkhkQBkhkCMAAQCNAABkBkQBkBkAACMQAACNhkBkQhkBkiNAAQiMAAhkhkgAjojnQhgBgAACHQAACHBgBhQBhBgCHAAQCHAABhhgQBhhhAAiHQAAiHhhhgQhhhhiHAAQiHAAhhBhg");
	this.shape_1.setTransform(46.6,46.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E4E8EB").s().p("Aj5D6QhnhoAAiSQAAiRBnhoQBohnCRAAQCSAABoBnQBnBoAACRQAACShnBoQhoBniSAAQiRAAhohngAjwjwQhkBkAACMQAACNBkBkQBkBkCMAAQCNAABkhkQBkhkAAiNQAAiMhkhkQhkhkiNAAQiMAAhkBkg");
	this.shape_2.setTransform(46.5,46.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E1E6E9").s().p("AkBECQhrhrAAiXQAAiWBrhrQBrhsCWABQCXgBBrBsQBrBrAACWQAACXhrBrQhrBriXAAQiWAAhrhrgAj4j3QhnBoAACQQAACSBnBnQBoBoCQAAQCTAABohoQBnhnAAiSQAAiRhnhnQhohoiTAAQiQAAhoBog");
	this.shape_3.setTransform(46.4,46.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DDE3E6").s().p("AkKELQhvhvAAicQAAibBvhvQBvhvCbAAQCcAABvBvQBvBvAACbQAACchvBvQhvBvicAAQibAAhvhvgAkAkAQhsBrAACVQAACYBsBrQBrBrCVAAQCYAABrhrQBrhrAAiYQAAiVhrhrQhrhsiYAAQiVAAhrBsg");
	this.shape_4.setTransform(46.4,46.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DAE1E4").s().p("AkSEUQhzhzAAihQAAigBzhyQByhzCgAAQChAABzBzQByByAACgQAAChhyBzQhzByihAAQigAAhyhygAkKkKQhvBuAACcQAACbBvBwQBuBuCcAAQCcAABvhuQBuhwAAibQAAichuhuQhwhvibAAQicAAhuBvg");
	this.shape_5.setTransform(46.6,46.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D7DEE2").s().p("AkbEcQh2h2AAimQAAilB2h2QB2h2ClAAQCmAAB2B2QB2B2AAClQAACmh2B2Qh2B2imAAQilAAh2h2gAkTkTQhyBzAACgQAAChByByQBzBzCgAAQChAAByhzQBzhyAAihQAAighzhzQhyhyihAAQigAAhzByg");
	this.shape_6.setTransform(46.5,46.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D3DCE0").s().p("AkkElQh6h6AAirQAAirB6h5QB5h6CrAAQCrAAB6B6QB5B5AACrQAACrh5B6Qh6B5irAAQiqAAh6h5gAkbkbQh3B1AACmQAACmB3B2QB1B2CmAAQCmAAB2h2QB2h2AAimQAAimh2h1Qh2h3imAAQimAAh1B3g");
	this.shape_7.setTransform(46.6,46.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D3DCE0").s().p("AlHFIQiIiIAAjAQAAi/CIiIQCIiIC/AAQDAAACICIQCICIAAC/QAADAiICIQiICIjAAAQi/AAiIiIgAkbkbQh2B2AAClQAACoB2B2QB2B2ClAAQCoAAB2h2QB2h2AAioQAAilh2h2Qh2h3ioAAQilAAh2B3g");
	this.shape_8.setTransform(46.4,46.4);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = mask;

	this.addChild(this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,92.9,92.9);


(lib.Grupodeclips0_34 = function() {
	this.initialize();

	// Capa 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#448592").ss(0.3,0,0,3.9).p("AATieQAAAOAKAHIAXAQQAMAIAAATIAAFuIh/AAIAAluQAAgTANgIIAWgQQAKgHAAgOIAAhxIAlAAgAAPhmQAGAGAAAJQAAAIgGAHQgHAGgIAAQgHAAgGgGQgGgHAAgIQAAgJAGgGQAGgHAHAAQAIAAAHAHg");
	this.shape.setTransform(6.5,27.4);

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag/EQIAAluQAAgUANgHIAWgQQAKgHAAgNIAAhyIAlAAIAAByQAAANAKAHIAXAQQAMAHAAAUIAAFug");
	mask.setTransform(6.5,27.4);

	// Capa 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#AEC1C9").s().p("AgSATQgIgIAAgLQAAgKAIgIQAIgIAKAAQALAAAIAIQAIAIAAAKQAAALgIAIQgIAIgLAAQgKAAgIgIg");
	this.shape_1.setTransform(6.5,18.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E7EBED").s().p("AgwEQIAAlrQAAgSAKgJIARgPQAIgGAAgOIAAh2IAbAAIAAB2QAAAOAIAGIARAPQAJAJAAASIAAFrg");
	this.shape_2.setTransform(6.6,27.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D8DFE3").s().p("AgxEQIAAlrQAAgTAJgIIASgPQAIgHAAgOIAAh1IAcAAIAAB1QAAAOAJAHIARAPQAKAIAAATIAAFrg");
	this.shape_3.setTransform(6.6,27.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C9D4D9").s().p("AgzEQIAAlrQAAgTAKgJIATgPQAIgHAAgNIAAh1IAdAAIAAB1QAAANAJAHIASAPQAKAJAAATIAAFrg");
	this.shape_4.setTransform(6.5,27.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#BACAD0").s().p("Ag0EQIAAlsQgBgTALgIIASgPQAKgHgBgOIAAh0IAfAAIAAB0QAAAOAJAHIASAPQALAIAAATIAAFsg");
	this.shape_5.setTransform(6.6,27.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#ACC0C8").s().p("Ag2EQIAAltQAAgTALgIIATgOQAJgIAAgOIAAhzIAfAAIAABzQAAAOAJAIIAUAOQAKAJAAASIAAFtg");
	this.shape_6.setTransform(6.6,27.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#9FB6C0").s().p("Ag4EQIAAltQAAgSALgJIAUgPQAKgHAAgOIAAhzIAgAAIAABzQAAAOAJAHIAUAPQALAJAAASIAAFtg");
	this.shape_7.setTransform(6.5,27.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#91ADB8").s().p("Ag6EQIAAltQABgTAKgIIAVgPQAKgIAAgNIAAhzIAhAAIAABzQAAANAKAIIAUAPQALAIAAATIAAFtg");
	this.shape_8.setTransform(6.6,27.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#84A5B1").s().p("Ag7EQIAAluQAAgTALgIIAVgPQALgHAAgOIAAhyIAiAAIAAByQAAAOAKAHIAVAPQALAIAAATIAAFug");
	this.shape_9.setTransform(6.5,27.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#779DA9").s().p("Ag9EQIAAluQAAgTALgIIAXgPQAJgIABgNIAAhyIAjAAIAAByQAAAOAKAHIAWAPQAMAJAAASIAAFug");
	this.shape_10.setTransform(6.6,27.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#6A96A2").s().p("Ag/EQIAAluQAAgUANgHIAWgQQAKgHAAgNIAAhyIAlAAIAAByQAAANAKAHIAXAQQAMAHAAAUIAAFug");
	this.shape_11.setTransform(6.5,27.4);

	this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = mask;

	// Capa 1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#6A96A2").s().p("Ag/EQIAAluQAAgUANgHIAWgQQAKgHAAgNIAAhyIAlAAIAAByQAAANAKAHIAXAQQAMAHAAAUIAAFug");
	this.shape_12.setTransform(6.5,27.4);

	this.addChild(this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0.1,0.1,12.9,54.6);


(lib.Grupodeclips0_33 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhVAZIglgxID1AAIgkAxg");
	mask.setTransform(12.7,2.5);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5A6B80").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape.setTransform(24.8,2.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#617084").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_1.setTransform(23.8,2.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#687488").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_2.setTransform(22.9,2.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#6F798D").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_3.setTransform(21.9,2.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#767E91").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_4.setTransform(21,2.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#7D8496").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_5.setTransform(20,2.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#7D8496").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_6.setTransform(19.6,2.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#767E91").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_7.setTransform(18.5,2.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#6F798D").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_8.setTransform(17.5,2.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#687488").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_9.setTransform(16.4,2.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#617084").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_10.setTransform(15.3,2.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#5A6B80").s().p("AgDAZIAAgxIAIAAIAAAxg");
	this.shape_11.setTransform(14.3,2.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#5A6B80").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_12.setTransform(13.7,2.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#55687E").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_13.setTransform(12.7,2.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#4F657B").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_14.setTransform(11.7,2.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#4A6278").s().p("AgEAZIAAgxIAIAAIAAAxg");
	this.shape_15.setTransform(10.7,2.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#455F76").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_16.setTransform(9.7,2.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#405C73").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_17.setTransform(8.7,2.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3A5A71").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_18.setTransform(7.7,2.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#36576F").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_19.setTransform(6.7,2.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#36576F").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_20.setTransform(6.2,2.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3B5A71").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_21.setTransform(5.3,2.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#415D74").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_22.setTransform(4.3,2.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#486177").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_23.setTransform(3.4,2.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#4E647A").s().p("AgDAZIAAgxIAHAAIAAAxg");
	this.shape_24.setTransform(2.4,2.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#54687D").s().p("AgDAZIAAgxIAIAAIAAAxg");
	this.shape_25.setTransform(1.5,2.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#5A6B80").s().p("AgEAZIAAgxIAIAAIAAAxg");
	this.shape_26.setTransform(0.5,2.5);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = mask;

	this.addChild(this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,25.3,5.1);


(lib.Grupodeclips0_32 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah5AkIg3hIIFhAAIg0BIg");
	mask.setTransform(19.6,20.5);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C5C1BE").s().p("AhEBdICDi9IAGAFIiDC8g");
	this.shape.setTransform(30.6,26.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BCB9B5").s().p("AhEBcICDi8IAGAEIiDC9g");
	this.shape_1.setTransform(29.9,25.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B4B1AD").s().p("AhEBdICDi9IAGAFIiDC8g");
	this.shape_2.setTransform(29.2,25.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#ACA9A5").s().p("AhEBcICDi8IAGAEIiDC9g");
	this.shape_3.setTransform(28.5,24.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#A5A19D").s().p("AhEBdICDi9IAGAFIiDC8g");
	this.shape_4.setTransform(27.9,24.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A5A19D").s().p("AirAUICFi8IDSCVIiFC8g");
	this.shape_5.setTransform(17.3,16.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = mask;

	this.addChild(this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,37.5,36);


(lib.Grupodeclips0_31 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAHQAAgFgEgCQgEgEgFgBIFUgQQgMAEAAALQAAAKANACIlTAQQALgEAAgLg");
	mask.setTransform(17.4,2.3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#96938F").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape.setTransform(34.3,2.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A09D99").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_1.setTransform(33.3,2.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#ABA8A4").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_2.setTransform(32.4,2.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B7B3AF").s().p("AgEAWIAAgrIAIAAIAAArg");
	this.shape_3.setTransform(31.4,2.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C2BFBC").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_4.setTransform(30.4,2.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CECBC8").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_5.setTransform(29.5,2.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DBD8D6").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_6.setTransform(28.5,2.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E8E6E4").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_7.setTransform(27.5,2.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E8E6E4").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_8.setTransform(27.1,2.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#DCDAD8").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_9.setTransform(26.1,2.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D1CECC").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_10.setTransform(25.2,2.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C7C3C0").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_11.setTransform(24.2,2.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BCB9B5").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_12.setTransform(23.2,2.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#B2AFAB").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_13.setTransform(22.3,2.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#A8A5A1").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_14.setTransform(21.3,2.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#9F9C98").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_15.setTransform(20.3,2.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#96938F").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_16.setTransform(19.4,2.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#96938F").s().p("AgEAWIAAgrIAJAAIAAArg");
	this.shape_17.setTransform(18.9,2.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#8F8D88").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_18.setTransform(17.9,2.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#888782").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_19.setTransform(16.8,2.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#81817C").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_20.setTransform(15.8,2.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#7B7C77").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_21.setTransform(14.8,2.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#747772").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_22.setTransform(13.8,2.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#6D726D").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_23.setTransform(12.7,2.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#676D68").s().p("AgEAWIAAgrIAJAAIAAArg");
	this.shape_24.setTransform(11.7,2.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#606963").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_25.setTransform(10.7,2.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#606963").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_26.setTransform(10.1,2.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#656C67").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_27.setTransform(9.2,2.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#6B706B").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_28.setTransform(8.2,2.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#70746F").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_29.setTransform(7.2,2.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#757873").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_30.setTransform(6.3,2.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#7B7C77").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_31.setTransform(5.3,2.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#80807B").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_32.setTransform(4.3,2.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#858580").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_33.setTransform(3.4,2.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#8B8984").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_34.setTransform(2.4,2.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#908E89").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_35.setTransform(1.4,2.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#96938F").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_36.setTransform(0.5,2.3);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = mask;

	this.addChild(this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,34.8,4.6);


(lib.Grupodeclips0_30 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAIQAAgGgDgCQgEgEgGgCIFVgPQgMAEAAALQAAAKAMADIlTAPQALgEAAgKg");
	mask.setTransform(17.9,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#606963").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape.setTransform(10.5,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#636A65").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_1.setTransform(9.5,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#656C67").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_2.setTransform(8.5,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#686E69").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_3.setTransform(7.5,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6B706B").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_4.setTransform(6.5,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6D726D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_5.setTransform(5.5,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#70746F").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(4.5,1.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737671").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_7.setTransform(3.5,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#757873").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_8.setTransform(2.5,1.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#787A75").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_9.setTransform(1.5,1.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#7B7C77").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_10.setTransform(0.5,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = mask;

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,11,3.9);


(lib.Grupodeclips0_29 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAIQAAgGgDgCQgFgEgFgCIFVgPQgMAEgBALQAAAKANADIlTAPQALgEAAgKg");
	mask.setTransform(17.2,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#888782").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape.setTransform(18.9,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#84837E").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_1.setTransform(18,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7F7F7A").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_2.setTransform(17,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#7B7C77").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_3.setTransform(16,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#767873").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_4.setTransform(15.1,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#727570").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_5.setTransform(14.1,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#6D726D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(13.1,1.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#696F69").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_7.setTransform(12.2,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#646C66").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_8.setTransform(11.2,1.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#606963").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_9.setTransform(10.3,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = mask;

	this.addChild(this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(9.8,0,9.6,3.9);


(lib.Grupodeclips0_28 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAIQAAgGgDgCQgFgEgFgCIFVgPQgMAEgBALQAAAKANADIlTAPQALgEAAgKg");
	mask.setTransform(17.2,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E8E6E4").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape.setTransform(27.4,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DAD7D5").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_1.setTransform(26.4,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CDCAC7").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_2.setTransform(25.4,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C1BDBA").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_3.setTransform(24.4,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B4B1AD").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_4.setTransform(23.4,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A8A5A1").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_5.setTransform(22.4,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#9D9A96").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(21.4,1.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#92908B").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_7.setTransform(20.4,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#888782").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_8.setTransform(19.4,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = mask;

	this.addChild(this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(19,0,9,3.9);


(lib.Grupodeclips0_27 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAIQAAgGgDgCQgFgEgFgCIFVgPQgMAEgBALQAAAKANADIlTAPQALgEAAgKg");
	mask.setTransform(17.2,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A09D99").s().p("AgDATIAAglIAIAAIAAAlg");
	this.shape.setTransform(34,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ABA8A4").s().p("AgDATIAAglIAIAAIAAAlg");
	this.shape_1.setTransform(33,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B7B3AF").s().p("AgEATIAAglIAJAAIAAAlg");
	this.shape_2.setTransform(32,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C2BFBC").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_3.setTransform(31,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CECBC8").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_4.setTransform(30,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DBD8D6").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_5.setTransform(28.9,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E8E6E4").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(27.9,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = mask;

	this.addChild(this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(27.5,0,7,3.9);


(lib.Grupodeclips0_26 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AitARQgKgDgBgFQAAgGAJgDQAKgDAOAAIEugPQAOgBAKADQAJAEABAFQAAAFgJACQgKAEgOABIkuAOIgGAAQgJAAgIgCg");
	mask.setTransform(18.7,2);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5A19D").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape.setTransform(37,2.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B0ACA8").s().p("AgEATIAAgkIAJAAIAAAkg");
	this.shape_1.setTransform(36,2.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BBB8B4").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_2.setTransform(35,2.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C7C4C1").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_3.setTransform(33.9,2.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D3D0CE").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_4.setTransform(32.9,2.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E0DEDC").s().p("AgEATIAAgkIAIAAIAAAkg");
	this.shape_5.setTransform(31.9,2.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EEECEB").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_6.setTransform(30.8,2.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_7.setTransform(29.8,2.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_8.setTransform(29.2,2.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EFEEEC").s().p("AgDATIAAgkIAIAAIAAAkg");
	this.shape_9.setTransform(28.2,2.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E3E1DF").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_10.setTransform(27.2,2.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D8D5D3").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_11.setTransform(26.1,2.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CDCAC7").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_12.setTransform(25.1,2.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#C3BFBC").s().p("AgDATIAAgkIAIAAIAAAkg");
	this.shape_13.setTransform(24.1,2.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#B8B5B1").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_14.setTransform(23,2.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#AEABA7").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_15.setTransform(22,2.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#A5A19D").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_16.setTransform(20.9,2.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#A5A19D").s().p("AgEATIAAgkIAIAAIAAAkg");
	this.shape_17.setTransform(20.4,2.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#9E9B96").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_18.setTransform(19.4,2.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#979590").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_19.setTransform(18.5,2.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#918F8A").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_20.setTransform(17.5,2.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#8B8984").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_21.setTransform(16.5,2.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#84847F").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_22.setTransform(15.5,2.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#7E7F7A").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_23.setTransform(14.6,2.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#787A75").s().p("AgDATIAAgkIAIAAIAAAkg");
	this.shape_24.setTransform(13.6,2.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#727570").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_25.setTransform(12.6,2.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#6C716C").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_26.setTransform(11.7,2.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#666D67").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_27.setTransform(10.7,2.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#606963").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_28.setTransform(9.7,2.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#606963").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_29.setTransform(9.2,2.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#676E68").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_30.setTransform(8.3,2.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#6F736E").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_31.setTransform(7.3,2.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#767873").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_32.setTransform(6.3,2.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#7E7E79").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_33.setTransform(5.3,2.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#85847F").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_34.setTransform(4.4,2.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#8D8B86").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_35.setTransform(3.4,2.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#94928D").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_36.setTransform(2.4,2.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#9C9995").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_37.setTransform(1.4,2.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#A5A19D").s().p("AgDATIAAgkIAHAAIAAAkg");
	this.shape_38.setTransform(0.5,2.1);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = this.shape_37.mask = this.shape_38.mask = mask;

	this.addChild(this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.2,37.5,3.8);


(lib.Grupodeclips0_25 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAHQAAgFgEgCQgEgFgFgBIFUgPQgMADAAALQAAAKANAEIlTAPQALgEAAgLg");
	mask.setTransform(17.4,2.4);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#96938F").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape.setTransform(34.3,2.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A09D99").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_1.setTransform(33.3,2.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#ABA8A4").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_2.setTransform(32.4,2.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B7B3AF").s().p("AgEAWIAAgrIAIAAIAAArg");
	this.shape_3.setTransform(31.4,2.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C2BFBC").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_4.setTransform(30.4,2.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CECBC8").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_5.setTransform(29.5,2.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DBD8D6").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_6.setTransform(28.5,2.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E8E6E4").s().p("AgDAWIAAgrIAIAAIAAArg");
	this.shape_7.setTransform(27.6,2.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E8E6E4").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_8.setTransform(27.1,2.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#DCDAD8").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_9.setTransform(26.1,2.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D1CECC").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_10.setTransform(25.2,2.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C7C3C0").s().p("AgEAWIAAgrIAIAAIAAArg");
	this.shape_11.setTransform(24.2,2.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BCB9B5").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_12.setTransform(23.2,2.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#B2AFAB").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_13.setTransform(22.3,2.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#A8A5A1").s().p("AgEAWIAAgrIAIAAIAAArg");
	this.shape_14.setTransform(21.3,2.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#9F9C98").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_15.setTransform(20.3,2.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#96938F").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_16.setTransform(19.4,2.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#96938F").s().p("AgEAWIAAgrIAJAAIAAArg");
	this.shape_17.setTransform(18.9,2.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#8F8D88").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_18.setTransform(17.9,2.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#888782").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_19.setTransform(16.8,2.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#81817C").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_20.setTransform(15.8,2.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#7B7C77").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_21.setTransform(14.8,2.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#747772").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_22.setTransform(13.8,2.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#6D726D").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_23.setTransform(12.7,2.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#676D68").s().p("AgEAWIAAgrIAJAAIAAArg");
	this.shape_24.setTransform(11.7,2.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#606963").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_25.setTransform(10.7,2.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#606963").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_26.setTransform(10.1,2.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#656C67").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_27.setTransform(9.2,2.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#6B706B").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_28.setTransform(8.2,2.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#70746F").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_29.setTransform(7.2,2.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#757873").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_30.setTransform(6.3,2.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#7B7C77").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_31.setTransform(5.3,2.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#80807B").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_32.setTransform(4.3,2.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#858580").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_33.setTransform(3.4,2.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#8B8984").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_34.setTransform(2.4,2.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#908E89").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_35.setTransform(1.4,2.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#96938F").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_36.setTransform(0.5,2.3);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = mask;

	this.addChild(this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,34.8,4.6);


(lib.Grupodeclips0_24 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAHQAAgFgDgCQgEgFgGAAIFVgQQgMADAAALQAAAKAMADIlTAQQALgEAAgLg");
	mask.setTransform(17.9,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#606963").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape.setTransform(10.5,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#636A65").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_1.setTransform(9.5,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#656C67").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_2.setTransform(8.5,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#686E69").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_3.setTransform(7.5,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6B706B").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_4.setTransform(6.5,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6D726D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_5.setTransform(5.5,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#70746F").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(4.5,1.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737671").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_7.setTransform(3.5,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#757873").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_8.setTransform(2.5,1.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#787A75").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_9.setTransform(1.5,1.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#7B7C77").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_10.setTransform(0.5,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = mask;

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,11,3.9);


(lib.Grupodeclips0_23 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAHQAAgKgNgCIFVgQQgMADgBALQAAAKANADIlTAQQALgEAAgLg");
	mask.setTransform(17.2,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#888782").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape.setTransform(18.9,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#84837E").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_1.setTransform(18,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7F7F7A").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_2.setTransform(17,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#7B7C77").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_3.setTransform(16,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#767873").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_4.setTransform(15.1,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#727570").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_5.setTransform(14.1,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#6D726D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(13.1,1.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#696F69").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_7.setTransform(12.2,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#646C66").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_8.setTransform(11.2,1.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#606963").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_9.setTransform(10.3,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = mask;

	this.addChild(this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(9.8,0,9.6,3.9);


(lib.Grupodeclips0_22 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAHQAAgKgNgCIFVgQQgMADgBALQAAAKANADIlTAQQALgEAAgLg");
	mask.setTransform(17.2,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E8E6E4").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape.setTransform(27.4,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DAD7D5").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_1.setTransform(26.4,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CDCAC7").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_2.setTransform(25.4,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C1BDBA").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_3.setTransform(24.4,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B4B1AD").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_4.setTransform(23.4,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A8A5A1").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_5.setTransform(22.4,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#9D9A96").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(21.4,1.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#92908B").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_7.setTransform(20.4,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#888782").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_8.setTransform(19.4,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = mask;

	this.addChild(this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(19,0,9,3.9);


(lib.Grupodeclips0_21 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAHQAAgKgNgCIFVgQQgMADgBALQAAAKANADIlTAQQALgEAAgLg");
	mask.setTransform(17.2,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A09D99").s().p("AgDATIAAglIAIAAIAAAlg");
	this.shape.setTransform(34,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ABA8A4").s().p("AgDATIAAglIAIAAIAAAlg");
	this.shape_1.setTransform(33,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B7B3AF").s().p("AgEATIAAglIAJAAIAAAlg");
	this.shape_2.setTransform(32,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C2BFBC").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_3.setTransform(31,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CECBC8").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_4.setTransform(30,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DBD8D6").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_5.setTransform(28.9,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E8E6E4").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(27.9,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = mask;

	this.addChild(this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(27.5,0,7,3.9);


(lib.Grupodeclips0_20 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhDADQgBgDANgBIBvgFQAMAAAAAEQABACgNACIhvAFQgMAAAAgEg");
	mask.setTransform(6.9,0.8);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape.setTransform(13.3,0.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FAF9F9").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_1.setTransform(12.3,0.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F6F5F4").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_2.setTransform(11.3,0.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F3F1F0").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_3.setTransform(10.3,0.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F0EEED").s().p("AgEAHIAAgNIAIAAIAAANg");
	this.shape_4.setTransform(9.4,0.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EDEBE9").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_5.setTransform(8.4,0.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EAE8E6").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_6.setTransform(7.4,0.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E7E5E3").s().p("AgDAHIAAgNIAIAAIAAANg");
	this.shape_7.setTransform(6.4,0.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E4E2E0").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_8.setTransform(5.4,0.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E1DEDC").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_9.setTransform(4.4,0.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DEDBD9").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_10.setTransform(3.4,0.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#DBD9D6").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_11.setTransform(2.5,0.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D8D6D3").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_12.setTransform(1.5,0.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D6D3D0").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_13.setTransform(0.5,0.8);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = mask;

	this.addChild(this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.1,13.8,1.5);


(lib.Grupodeclips0_19 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AitARQgKgDgBgGQAAgFAJgDQAKgDAOgBIEugOQAOgBAKADQAJADABAGQAAAFgJACQgKAEgOABIkuAOIgGAAQgKAAgHgCg");
	mask.setTransform(18.7,2);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5A19D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape.setTransform(37,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B0ACA8").s().p("AgEATIAAglIAJAAIAAAlg");
	this.shape_1.setTransform(36,2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BBB8B4").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_2.setTransform(35,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C7C4C1").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_3.setTransform(33.9,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D3D0CE").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_4.setTransform(32.9,2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E0DEDC").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_5.setTransform(31.9,2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EEECEB").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(30.8,2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_7.setTransform(29.8,2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_8.setTransform(29.2,2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EFEEEC").s().p("AgDATIAAglIAIAAIAAAlg");
	this.shape_9.setTransform(28.2,2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E3E1DF").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_10.setTransform(27.2,2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D8D5D3").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_11.setTransform(26.1,2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CDCAC7").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_12.setTransform(25.1,2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#C3BFBC").s().p("AgDATIAAglIAIAAIAAAlg");
	this.shape_13.setTransform(24.1,2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#B8B5B1").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_14.setTransform(23,2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#AEABA7").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_15.setTransform(22,2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#A5A19D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_16.setTransform(20.9,2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#A5A19D").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_17.setTransform(20.4,2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#9E9B96").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_18.setTransform(19.4,2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#979590").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_19.setTransform(18.5,2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#918F8A").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_20.setTransform(17.5,2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#8B8984").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_21.setTransform(16.5,2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#84847F").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_22.setTransform(15.5,2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#7E7F7A").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_23.setTransform(14.6,2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#787A75").s().p("AgDATIAAglIAIAAIAAAlg");
	this.shape_24.setTransform(13.6,2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#727570").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_25.setTransform(12.6,2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#6C716C").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_26.setTransform(11.7,2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#666D67").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_27.setTransform(10.7,2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#606963").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_28.setTransform(9.7,2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#606963").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_29.setTransform(9.2,2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#676E68").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_30.setTransform(8.3,2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#6F736E").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_31.setTransform(7.3,2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#767873").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_32.setTransform(6.3,2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#7E7E79").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_33.setTransform(5.3,2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#85847F").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_34.setTransform(4.4,2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#8D8B86").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_35.setTransform(3.4,2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#94928D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_36.setTransform(2.4,2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#9C9995").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_37.setTransform(1.4,2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#A5A19D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_38.setTransform(0.5,2);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = this.shape_37.mask = this.shape_38.mask = mask;

	this.addChild(this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.1,37.5,3.9);


(lib.Grupodeclips0_18 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAHQAAgJgNgEIFUgPQgMADAAAMQAAAJANAEIlTAPQALgEAAgLg");
	mask.setTransform(17.4,2.3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#96938F").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape.setTransform(34.3,2.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A09D99").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_1.setTransform(33.3,2.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#ABA8A4").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_2.setTransform(32.4,2.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B7B3AF").s().p("AgEAWIAAgrIAIAAIAAArg");
	this.shape_3.setTransform(31.4,2.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C2BFBC").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_4.setTransform(30.4,2.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CECBC8").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_5.setTransform(29.5,2.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DBD8D6").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_6.setTransform(28.5,2.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E8E6E4").s().p("AgDAWIAAgrIAIAAIAAArg");
	this.shape_7.setTransform(27.6,2.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E8E6E4").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_8.setTransform(27.1,2.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#DCDAD8").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_9.setTransform(26.1,2.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D1CECC").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_10.setTransform(25.2,2.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C7C3C0").s().p("AgEAWIAAgrIAIAAIAAArg");
	this.shape_11.setTransform(24.2,2.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BCB9B5").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_12.setTransform(23.2,2.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#B2AFAB").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_13.setTransform(22.3,2.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#A8A5A1").s().p("AgEAWIAAgrIAIAAIAAArg");
	this.shape_14.setTransform(21.3,2.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#9F9C98").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_15.setTransform(20.3,2.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#96938F").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_16.setTransform(19.4,2.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#96938F").s().p("AgEAWIAAgrIAJAAIAAArg");
	this.shape_17.setTransform(18.9,2.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#8F8D88").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_18.setTransform(17.9,2.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#888782").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_19.setTransform(16.8,2.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#81817C").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_20.setTransform(15.8,2.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#7B7C77").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_21.setTransform(14.8,2.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#747772").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_22.setTransform(13.8,2.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#6D726D").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_23.setTransform(12.7,2.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#676D68").s().p("AgEAWIAAgrIAJAAIAAArg");
	this.shape_24.setTransform(11.7,2.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#606963").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_25.setTransform(10.7,2.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#606963").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_26.setTransform(10.1,2.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#656C67").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_27.setTransform(9.2,2.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#6B706B").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_28.setTransform(8.2,2.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#70746F").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_29.setTransform(7.2,2.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#757873").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_30.setTransform(6.3,2.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#7B7C77").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_31.setTransform(5.3,2.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#80807B").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_32.setTransform(4.3,2.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#858580").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_33.setTransform(3.4,2.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#8B8984").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_34.setTransform(2.4,2.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#908E89").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_35.setTransform(1.4,2.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#96938F").s().p("AgDAWIAAgrIAHAAIAAArg");
	this.shape_36.setTransform(0.5,2.3);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = mask;

	this.addChild(this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,34.8,4.6);


(lib.Grupodeclips0_17 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAHQAAgJgNgEIFVgPQgMADAAAMQAAAJAMAEIlTAPQALgEAAgLg");
	mask.setTransform(17.9,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#606963").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape.setTransform(10.5,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#636A65").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_1.setTransform(9.5,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#656C67").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_2.setTransform(8.5,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#686E69").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_3.setTransform(7.5,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6B706B").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_4.setTransform(6.5,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6D726D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_5.setTransform(5.5,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#70746F").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(4.5,1.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737671").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_7.setTransform(3.5,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#757873").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_8.setTransform(2.5,1.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#787A75").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_9.setTransform(1.5,1.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#7B7C77").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_10.setTransform(0.5,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = mask;

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,11,3.9);


(lib.Grupodeclips0_16 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAHQAAgJgNgEIFVgPQgMADgBAMQAAAJANAEIlTAPQALgEAAgLg");
	mask.setTransform(17.2,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#888782").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape.setTransform(18.9,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#84837E").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_1.setTransform(18,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7F7F7A").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_2.setTransform(17,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#7B7C77").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_3.setTransform(16,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#767873").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_4.setTransform(15.1,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#727570").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_5.setTransform(14.1,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#6D726D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(13.1,1.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#696F69").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_7.setTransform(12.2,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#646C66").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_8.setTransform(11.2,1.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#606963").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_9.setTransform(10.3,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = mask;

	this.addChild(this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(9.8,0,9.6,3.9);


(lib.Grupodeclips0_15 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAHQAAgJgNgEIFVgPQgMADgBAMQAAAJANAEIlTAPQALgEAAgLg");
	mask.setTransform(17.2,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E8E6E4").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape.setTransform(27.4,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DAD7D5").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_1.setTransform(26.4,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CDCAC7").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_2.setTransform(25.4,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C1BDBA").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_3.setTransform(24.4,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B4B1AD").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_4.setTransform(23.4,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A8A5A1").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_5.setTransform(22.4,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#9D9A96").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(21.4,1.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#92908B").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_7.setTransform(20.4,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#888782").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_8.setTransform(19.4,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = mask;

	this.addChild(this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(19,0,9,3.9);


(lib.Grupodeclips0_14 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAHQAAgJgNgEIFVgPQgMADgBAMQAAAJANAEIlTAPQALgEAAgLg");
	mask.setTransform(17.2,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A09D99").s().p("AgDATIAAglIAIAAIAAAlg");
	this.shape.setTransform(34,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ABA8A4").s().p("AgDATIAAglIAIAAIAAAlg");
	this.shape_1.setTransform(33,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B7B3AF").s().p("AgEATIAAglIAJAAIAAAlg");
	this.shape_2.setTransform(32,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C2BFBC").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_3.setTransform(31,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CECBC8").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_4.setTransform(30,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DBD8D6").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_5.setTransform(28.9,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E8E6E4").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(27.9,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = mask;

	this.addChild(this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(27.5,0,7,3.9);


(lib.Grupodeclips0_13 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhDADQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAABAAQAEAAAFAAIBvgGQAMgBAAAFQAAABAAAAQAAABAAAAQgBAAAAAAQgBAAgBAAQgEABgFAAIhvAGIgEAAQgIAAAAgEg");
	mask.setTransform(6.9,0.7);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape.setTransform(13.3,0.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FAF9F9").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_1.setTransform(12.3,0.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F6F5F4").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_2.setTransform(11.3,0.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F3F1F0").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_3.setTransform(10.3,0.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F0EEED").s().p("AgEAHIAAgNIAIAAIAAANg");
	this.shape_4.setTransform(9.4,0.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EDEBE9").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_5.setTransform(8.4,0.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EAE8E6").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_6.setTransform(7.4,0.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E7E5E3").s().p("AgDAHIAAgNIAIAAIAAANg");
	this.shape_7.setTransform(6.4,0.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E4E2E0").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_8.setTransform(5.4,0.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E1DEDC").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_9.setTransform(4.4,0.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DEDBD9").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_10.setTransform(3.4,0.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#DBD9D6").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_11.setTransform(2.5,0.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D8D6D3").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_12.setTransform(1.5,0.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D6D3D0").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_13.setTransform(0.5,0.7);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = mask;

	this.addChild(this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,13.8,1.5);


(lib.Grupodeclips0_12 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AitARQgKgEgBgFQAAgFAJgDQAKgDAOgBIEugOQANgBALADQAJADABAFQAAAGgJACQgKAEgOAAIkuAPIgEAAQgLAAgIgCg");
	mask.setTransform(18.7,2);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5A19D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape.setTransform(37,2.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B0ACA8").s().p("AgEATIAAglIAJAAIAAAlg");
	this.shape_1.setTransform(36,2.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BBB8B4").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_2.setTransform(35,2.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C7C4C1").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_3.setTransform(33.9,2.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D3D0CE").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_4.setTransform(32.9,2.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E0DEDC").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_5.setTransform(31.9,2.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EEECEB").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_6.setTransform(30.8,2.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_7.setTransform(29.8,2.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_8.setTransform(29.2,2.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EFEEEC").s().p("AgDATIAAglIAIAAIAAAlg");
	this.shape_9.setTransform(28.2,2.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E3E1DF").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_10.setTransform(27.2,2.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D8D5D3").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_11.setTransform(26.1,2.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CDCAC7").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_12.setTransform(25.1,2.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#C3BFBC").s().p("AgDATIAAglIAIAAIAAAlg");
	this.shape_13.setTransform(24.1,2.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#B8B5B1").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_14.setTransform(23,2.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#AEABA7").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_15.setTransform(22,2.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#A5A19D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_16.setTransform(20.9,2.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#A5A19D").s().p("AgEATIAAglIAIAAIAAAlg");
	this.shape_17.setTransform(20.4,2.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#9E9B96").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_18.setTransform(19.4,2.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#979590").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_19.setTransform(18.5,2.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#918F8A").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_20.setTransform(17.5,2.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#8B8984").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_21.setTransform(16.5,2.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#84847F").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_22.setTransform(15.5,2.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#7E7F7A").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_23.setTransform(14.6,2.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#787A75").s().p("AgDATIAAglIAIAAIAAAlg");
	this.shape_24.setTransform(13.6,2.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#727570").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_25.setTransform(12.6,2.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#6C716C").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_26.setTransform(11.7,2.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#666D67").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_27.setTransform(10.7,2.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#606963").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_28.setTransform(9.7,2.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#606963").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_29.setTransform(9.2,2.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#676E68").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_30.setTransform(8.3,2.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#6F736E").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_31.setTransform(7.3,2.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#767873").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_32.setTransform(6.3,2.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#7E7E79").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_33.setTransform(5.3,2.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#85847F").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_34.setTransform(4.4,2.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#8D8B86").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_35.setTransform(3.4,2.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#94928D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_36.setTransform(2.4,2.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#9C9995").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_37.setTransform(1.4,2.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#A5A19D").s().p("AgDATIAAglIAHAAIAAAlg");
	this.shape_38.setTransform(0.5,2.1);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = this.shape_37.mask = this.shape_38.mask = mask;

	this.addChild(this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.2,37.5,3.9);


(lib.Grupodeclips0_11 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAHQAAgFgEgCQgEgFgFgBIFUgPQgMADAAAMQAAAKANADIlTAPQALgEAAgLg");
	mask.setTransform(17.4,2.4);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#96938F").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape.setTransform(34.3,2.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A09D99").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_1.setTransform(33.3,2.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#ABA8A4").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_2.setTransform(32.4,2.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B7B3AF").s().p("AgEAWIAAgsIAIAAIAAAsg");
	this.shape_3.setTransform(31.4,2.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C2BFBC").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_4.setTransform(30.4,2.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CECBC8").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_5.setTransform(29.5,2.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DBD8D6").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_6.setTransform(28.5,2.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E8E6E4").s().p("AgDAWIAAgsIAIAAIAAAsg");
	this.shape_7.setTransform(27.6,2.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E8E6E4").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_8.setTransform(27.1,2.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#DCDAD8").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_9.setTransform(26.1,2.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D1CECC").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_10.setTransform(25.2,2.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C7C3C0").s().p("AgEAWIAAgsIAIAAIAAAsg");
	this.shape_11.setTransform(24.2,2.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#BCB9B5").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_12.setTransform(23.2,2.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#B2AFAB").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_13.setTransform(22.3,2.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#A8A5A1").s().p("AgEAWIAAgsIAIAAIAAAsg");
	this.shape_14.setTransform(21.3,2.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#9F9C98").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_15.setTransform(20.3,2.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#96938F").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_16.setTransform(19.4,2.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#96938F").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_17.setTransform(18.9,2.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#8F8D88").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_18.setTransform(17.9,2.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#888782").s().p("AgDAWIAAgsIAIAAIAAAsg");
	this.shape_19.setTransform(16.9,2.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#81817C").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_20.setTransform(15.8,2.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#7B7C77").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_21.setTransform(14.8,2.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#747772").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_22.setTransform(13.8,2.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#6D726D").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_23.setTransform(12.7,2.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#676D68").s().p("AgEAWIAAgsIAJAAIAAAsg");
	this.shape_24.setTransform(11.7,2.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#606963").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_25.setTransform(10.7,2.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#606963").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_26.setTransform(10.1,2.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#656C67").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_27.setTransform(9.2,2.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#6B706B").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_28.setTransform(8.2,2.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#70746F").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_29.setTransform(7.2,2.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#757873").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_30.setTransform(6.3,2.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#7B7C77").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_31.setTransform(5.3,2.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#80807B").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_32.setTransform(4.3,2.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#858580").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_33.setTransform(3.4,2.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#8B8984").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_34.setTransform(2.4,2.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#908E89").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_35.setTransform(1.4,2.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#96938F").s().p("AgDAWIAAgsIAHAAIAAAsg");
	this.shape_36.setTransform(0.5,2.3);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = mask;

	this.addChild(this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,34.8,4.6);


(lib.Grupodeclips0_10 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAIQAAgGgDgCQgEgEgGgCIFVgPQgMADAAAMQAAAKAMADIlTAPQALgEAAgKg");
	mask.setTransform(17.9,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#606963").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape.setTransform(10.5,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#636A65").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_1.setTransform(9.5,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#656C67").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_2.setTransform(8.5,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#686E69").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_3.setTransform(7.5,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#6B706B").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_4.setTransform(6.5,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6D726D").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_5.setTransform(5.5,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#70746F").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_6.setTransform(4.5,1.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737671").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_7.setTransform(3.5,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#757873").s().p("AgEASIAAgkIAIAAIAAAkg");
	this.shape_8.setTransform(2.5,1.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#787A75").s().p("AgEASIAAgkIAIAAIAAAkg");
	this.shape_9.setTransform(1.5,1.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#7B7C77").s().p("AgEASIAAgkIAIAAIAAAkg");
	this.shape_10.setTransform(0.5,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = mask;

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,11,3.8);


(lib.Grupodeclips0_9 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAIQAAgLgNgDIFVgPQgMADgBAMQAAAKANADIlTAPQALgEAAgKg");
	mask.setTransform(17.2,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#888782").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape.setTransform(18.9,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#84837E").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_1.setTransform(18,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7F7F7A").s().p("AgEASIAAgkIAIAAIAAAkg");
	this.shape_2.setTransform(17,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#7B7C77").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_3.setTransform(16,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#767873").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_4.setTransform(15.1,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#727570").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_5.setTransform(14.1,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#6D726D").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_6.setTransform(13.1,1.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#696F69").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_7.setTransform(12.2,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#646C66").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_8.setTransform(11.2,1.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#606963").s().p("AgEASIAAgkIAIAAIAAAkg");
	this.shape_9.setTransform(10.3,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = mask;

	this.addChild(this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(9.8,0,9.6,3.8);


(lib.Grupodeclips0_8 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAIQAAgLgNgDIFVgPQgMADgBAMQAAAKANADIlTAPQALgEAAgKg");
	mask.setTransform(17.2,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E8E6E4").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape.setTransform(27.4,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DAD7D5").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_1.setTransform(26.4,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CDCAC7").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_2.setTransform(25.4,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C1BDBA").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_3.setTransform(24.4,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B4B1AD").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_4.setTransform(23.4,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A8A5A1").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_5.setTransform(22.4,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#9D9A96").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_6.setTransform(21.4,1.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#92908B").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_7.setTransform(20.4,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#888782").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_8.setTransform(19.4,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = mask;

	this.addChild(this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(19,0,9,3.8);


(lib.Grupodeclips0_7 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AidAIQAAgLgNgDIFVgPQgMADgBAMQAAAKANADIlTAPQALgEAAgKg");
	mask.setTransform(17.2,3);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A09D99").s().p("AgDASIAAgkIAIAAIAAAkg");
	this.shape.setTransform(34,1.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ABA8A4").s().p("AgDASIAAgkIAIAAIAAAkg");
	this.shape_1.setTransform(33,1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B7B3AF").s().p("AgEASIAAgkIAJAAIAAAkg");
	this.shape_2.setTransform(32,1.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C2BFBC").s().p("AgEASIAAgkIAIAAIAAAkg");
	this.shape_3.setTransform(31,1.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CECBC8").s().p("AgEASIAAgkIAIAAIAAAkg");
	this.shape_4.setTransform(30,1.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DBD8D6").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_5.setTransform(28.9,1.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E8E6E4").s().p("AgDASIAAgkIAHAAIAAAkg");
	this.shape_6.setTransform(27.9,1.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = mask;

	this.addChild(this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(27.5,0,7,3.8);


(lib.Grupodeclips0_6 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhDADQgBgDANgBIBvgFQAMAAAAAEQABACgNACIhvAFQgMAAAAgEg");
	mask.setTransform(6.9,0.8);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape.setTransform(13.3,0.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FAF9F9").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_1.setTransform(12.3,0.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F6F5F4").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_2.setTransform(11.3,0.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F3F1F0").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_3.setTransform(10.3,0.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F0EEED").s().p("AgEAHIAAgNIAIAAIAAANg");
	this.shape_4.setTransform(9.4,0.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EDEBE9").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_5.setTransform(8.4,0.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EAE8E6").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_6.setTransform(7.4,0.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E7E5E3").s().p("AgDAHIAAgNIAIAAIAAANg");
	this.shape_7.setTransform(6.4,0.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E4E2E0").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_8.setTransform(5.4,0.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E1DEDC").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_9.setTransform(4.4,0.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DEDBD9").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_10.setTransform(3.4,0.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#DBD9D6").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_11.setTransform(2.5,0.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D8D6D3").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_12.setTransform(1.5,0.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D6D3D0").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_13.setTransform(0.5,0.8);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = mask;

	this.addChild(this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.1,13.8,1.5);


(lib.Grupodeclips0_5 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiyAJQAKgEALAAIEugNQAOAAAKADQAKADAAADQAAAFgGADg");
	mask.setTransform(18.1,1);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5A19D").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape.setTransform(35.9,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B0ACA8").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_1.setTransform(34.9,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BBB8B4").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_2.setTransform(33.9,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C7C4C1").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_3.setTransform(32.9,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D3D0CE").s().p("AgEAJIAAgRIAIAAIAAARg");
	this.shape_4.setTransform(31.9,1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E0DEDC").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_5.setTransform(30.8,1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EEECEB").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_6.setTransform(29.8,1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_7.setTransform(28.8,1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_8.setTransform(28.3,1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EFEEEC").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_9.setTransform(27.3,1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E3E1DF").s().p("AgDAJIAAgRIAIAAIAAARg");
	this.shape_10.setTransform(26.3,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D8D5D3").s().p("AgDAJIAAgRIAIAAIAAARg");
	this.shape_11.setTransform(25.3,1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CDCAC7").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_12.setTransform(24.3,1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#C3BFBC").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_13.setTransform(23.3,1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#B8B5B1").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_14.setTransform(22.3,1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#AEABA7").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_15.setTransform(21.3,1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#A5A19D").s().p("AgEAJIAAgRIAJAAIAAARg");
	this.shape_16.setTransform(20.3,1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#A5A19D").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_17.setTransform(19.7,1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#9D9A96").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_18.setTransform(18.7,1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#96938F").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_19.setTransform(17.7,1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#8F8D88").s().p("AgEAJIAAgRIAJAAIAAARg");
	this.shape_20.setTransform(16.7,1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#888782").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_21.setTransform(15.6,1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#81817C").s().p("AgDAJIAAgRIAIAAIAAARg");
	this.shape_22.setTransform(14.6,1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#7B7C77").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_23.setTransform(13.6,1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#747772").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_24.setTransform(12.5,1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#6D726D").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_25.setTransform(11.5,1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#676D68").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_26.setTransform(10.5,1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#606963").s().p("AgEAJIAAgRIAJAAIAAARg");
	this.shape_27.setTransform(9.5,1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#606963").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_28.setTransform(8.9,1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#686E69").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_29.setTransform(7.9,1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#71746F").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_30.setTransform(6.8,1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#797B76").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_31.setTransform(5.8,1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#81817C").s().p("AgDAJIAAgRIAIAAIAAARg");
	this.shape_32.setTransform(4.7,1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#8A8884").s().p("AgEAJIAAgRIAIAAIAAARg");
	this.shape_33.setTransform(3.7,1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#92908B").s().p("AgEAJIAAgRIAIAAIAAARg");
	this.shape_34.setTransform(2.6,1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#9B9894").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_35.setTransform(1.5,1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#A5A19D").s().p("AgDAJIAAgRIAHAAIAAARg");
	this.shape_36.setTransform(0.5,1);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = mask;

	this.addChild(this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,36.4,2);


(lib.Grupodeclips0_4 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhDADQgBgDANAAIBvgGQAMgBAAAFQABADgNABIhvAFIgEAAQgIAAAAgEg");
	mask.setTransform(6.9,0.7);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAGIAAgLIAHAAIAAALg");
	this.shape.setTransform(13.3,0.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FAF9F9").s().p("AgDAGIAAgLIAHAAIAAALg");
	this.shape_1.setTransform(12.3,0.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F6F5F4").s().p("AgDAGIAAgLIAHAAIAAALg");
	this.shape_2.setTransform(11.3,0.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F3F1F0").s().p("AgDAGIAAgLIAHAAIAAALg");
	this.shape_3.setTransform(10.3,0.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F0EEED").s().p("AgEAGIAAgLIAIAAIAAALg");
	this.shape_4.setTransform(9.4,0.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EDEBE9").s().p("AgDAGIAAgLIAHAAIAAALg");
	this.shape_5.setTransform(8.4,0.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EAE8E6").s().p("AgDAGIAAgLIAHAAIAAALg");
	this.shape_6.setTransform(7.4,0.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E7E5E3").s().p("AgDAGIAAgLIAIAAIAAALg");
	this.shape_7.setTransform(6.4,0.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E4E2E0").s().p("AgDAGIAAgLIAHAAIAAALg");
	this.shape_8.setTransform(5.4,0.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E1DEDC").s().p("AgDAGIAAgLIAHAAIAAALg");
	this.shape_9.setTransform(4.4,0.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DEDBD9").s().p("AgDAGIAAgLIAHAAIAAALg");
	this.shape_10.setTransform(3.4,0.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#DBD9D6").s().p("AgDAGIAAgLIAHAAIAAALg");
	this.shape_11.setTransform(2.5,0.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D8D6D3").s().p("AgDAGIAAgLIAHAAIAAALg");
	this.shape_12.setTransform(1.5,0.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D6D3D0").s().p("AgDAGIAAgLIAHAAIAAALg");
	this.shape_13.setTransform(0.5,0.8);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = mask;

	this.addChild(this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.1,13.8,1.4);


(lib.Grupodeclips0_3 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AisAoQgKgDgBgFIAAg2QAAgGgDgFQgEgHgGgBIGJgBQgFABgEAGQgDAFgBAFIACAAIAAAnQAAAFgJAEQgKAFgOAAIkuAPIgEAAQgLAAgIgDg");
	mask.setTransform(19.9,4.4);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A5A19D").s().p("AgDArIAAhVIAIAAIAABVg");
	this.shape.setTransform(39.4,4.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#AEABA7").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_1.setTransform(38.4,4.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B8B5B1").s().p("AgEArIAAhVIAIAAIAABVg");
	this.shape_2.setTransform(37.4,4.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C3BFBC").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_3.setTransform(36.4,4.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CDCAC7").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_4.setTransform(35.4,4.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D8D5D3").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_5.setTransform(34.5,4.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E3E1DF").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_6.setTransform(33.5,4.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EFEEEC").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_7.setTransform(32.5,4.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_8.setTransform(31.5,4.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_9.setTransform(31.1,4.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F1EFEE").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_10.setTransform(30.1,4.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E6E4E2").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_11.setTransform(29.1,4.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#DCD9D7").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_12.setTransform(28.1,4.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D2CFCC").s().p("AgDArIAAhVIAIAAIAABVg");
	this.shape_13.setTransform(27.1,4.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#C9C5C2").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_14.setTransform(26.1,4.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#BFBCB8").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_15.setTransform(25.1,4.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#B6B2AF").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_16.setTransform(24.1,4.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#ADAAA6").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_17.setTransform(23.1,4.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#A5A19D").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_18.setTransform(22.1,4.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#A5A19D").s().p("AgEArIAAhVIAIAAIAABVg");
	this.shape_19.setTransform(21.7,4.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#9E9B96").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_20.setTransform(20.6,4.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#979590").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_21.setTransform(19.6,4.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#918F8A").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_22.setTransform(18.6,4.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#8B8984").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_23.setTransform(17.5,4.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#84847F").s().p("AgDArIAAhVIAIAAIAABVg");
	this.shape_24.setTransform(16.5,4.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#7E7F7A").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_25.setTransform(15.5,4.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#787A75").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_26.setTransform(14.4,4.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#727570").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_27.setTransform(13.4,4.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#6C716C").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_28.setTransform(12.4,4.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#666D67").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_29.setTransform(11.3,4.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#606963").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_30.setTransform(10.3,4.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#606963").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_31.setTransform(9.8,4.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#676E68").s().p("AgDArIAAhVIAIAAIAABVg");
	this.shape_32.setTransform(8.8,4.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#6F736E").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_33.setTransform(7.7,4.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#767873").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_34.setTransform(6.7,4.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#7E7E79").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_35.setTransform(5.6,4.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#85847F").s().p("AgDArIAAhVIAIAAIAABVg");
	this.shape_36.setTransform(4.6,4.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#8D8B86").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_37.setTransform(3.6,4.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#94928D").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_38.setTransform(2.5,4.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#9C9995").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_39.setTransform(1.5,4.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#A5A19D").s().p("AgDArIAAhVIAHAAIAABVg");
	this.shape_40.setTransform(0.5,4.4);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = this.shape_37.mask = this.shape_38.mask = this.shape_39.mask = this.shape_40.mask = mask;

	this.addChild(this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.1,39.9,8.7);


(lib.Grupodeclips0_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhDADQgBgDANgBIBvgFQAMgBAAAFQABACgNABIhvAGIgEAAQgIAAAAgEg");
	mask.setTransform(6.9,0.8);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape.setTransform(13.3,0.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FAF9F9").s().p("AgEAHIAAgNIAIAAIAAANg");
	this.shape_1.setTransform(12.3,0.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F6F5F4").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_2.setTransform(11.3,0.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F3F1F0").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_3.setTransform(10.3,0.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F0EEED").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_4.setTransform(9.3,0.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EDEBE9").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_5.setTransform(8.4,0.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EAE8E6").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_6.setTransform(7.4,0.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E7E5E3").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_7.setTransform(6.4,0.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E4E2E0").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_8.setTransform(5.4,0.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E1DEDC").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_9.setTransform(4.4,0.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DEDBD9").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_10.setTransform(3.4,0.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#DBD9D6").s().p("AgDAHIAAgNIAIAAIAAANg");
	this.shape_11.setTransform(2.5,0.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D8D6D3").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_12.setTransform(1.5,0.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#D6D3D0").s().p("AgDAHIAAgNIAHAAIAAANg");
	this.shape_13.setTransform(0.5,0.8);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = mask;

	this.addChild(this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.1,13.8,1.5);


(lib.Grupodeclips0_1 = function() {
	this.initialize();

	// Capa 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#448592").ss(0.3,0,0,3.9).p("AAwAAQAAADgEADQgDACgFAAIhHAAQgFAAgDgCQgEgDAAgDQAAgCAEgDQADgCAFAAIBHAAQAMAAAAAHg");
	this.shape.setTransform(5.1,1);

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgjAIQgFAAgDgCQgEgDAAgDQAAgCAEgDQADgCAFAAIBHAAQAMAAAAAHQAAADgEADQgDACgFAAg");
	mask.setTransform(5.1,1);

	// Capa 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6A96A2").s().p("AgBAIIAAgPIADAAIAAAPg");
	this.shape_1.setTransform(10,1.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#87A7B2").s().p("AgBAIIAAgPIADAAIAAAPg");
	this.shape_2.setTransform(9.4,1.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A5BBC4").s().p("AgBAIIAAgPIADAAIAAAPg");
	this.shape_3.setTransform(8.8,1.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C5D1D7").s().p("AgBAIIAAgPIADAAIAAAPg");
	this.shape_4.setTransform(8.3,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E7EBED").s().p("AgBAIIAAgPIADAAIAAAPg");
	this.shape_5.setTransform(7.7,1.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E7EBED").s().p("AgYAIIAAgPIAxAAIAAAPg");
	this.shape_6.setTransform(5.3,1.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E7EBED").s().p("AgCAIIAAgPIAFAAIAAAPg");
	this.shape_7.setTransform(2.9,1.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#C5D1D7").s().p("AgCAIIAAgPIAFAAIAAAPg");
	this.shape_8.setTransform(2.3,1.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#A5BBC4").s().p("AgCAIIAAgPIAFAAIAAAPg");
	this.shape_9.setTransform(1.6,1.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#87A7B2").s().p("AgCAIIAAgPIAFAAIAAAPg");
	this.shape_10.setTransform(1,1.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#6A96A2").s().p("AgCAIIAAgPIAFAAIAAAPg");
	this.shape_11.setTransform(0.4,1.1);

	this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = mask;

	this.addChild(this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.2,10.2,1.8);


(lib.Grupodeclips0 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgCBtQgLAAgJgIQgIgJAAgMIAAiZQAPAFAWgOQAXgOABgMIAAC8QAAAMgIAJQgJAIgMAAg");
	mask.setTransform(3.1,11);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E7EBED").s().p("AgDBtIAAjZIAHAAIAADZg");
	this.shape.setTransform(5.8,11);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E3E8EA").s().p("AgDBtIAAjZIAHAAIAADZg");
	this.shape_1.setTransform(4.7,11);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DFE5E8").s().p("AgDBtIAAjZIAHAAIAADZg");
	this.shape_2.setTransform(3.7,11);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#DBE2E5").s().p("AgDBtIAAjZIAHAAIAADZg");
	this.shape_3.setTransform(2.6,11);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D7DFE3").s().p("AgDBtIAAjZIAHAAIAADZg");
	this.shape_4.setTransform(1.6,11);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D3DCE0").s().p("AgDBtIAAjZIAIAAIAADZg");
	this.shape_5.setTransform(0.6,11);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = mask;

	this.addChild(this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0.1,0.1,6.2,21.9);


(lib.Grupodeclips0_14_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AlPAQIJvgsIAwALIp5Aug");
	mask_1.setTransform(33.7,3);

	// Capa 3
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#CDCDCC","#F3F2F3"],[0,1],-33.5,0.1,33.7,0.1).s().p("AlPAdIAAg5IKfAAIAAA5g");
	this.shape_7.setTransform(33.7,3);

	this.shape_7.mask = mask_1;

	this.addChild(this.shape_7);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,67.4,5.9);


(lib.Grupodeclips0_11_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ak8kyIABgGIADgFIAEgDIAGgCIJrgvQg3D7ilDDQijDDjrBig");
	mask_1.setTransform(31.8,37);

	// Capa 3
	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.rf(["#CDCDCC","#F3F2F3"],[0,1],-66.5,-56.3,0,-66.5,-56.3,99.1).s().p("Ak8FyIAArjIJ5AAIAALjg");
	this.shape_37.setTransform(31.8,37);

	this.shape_37.mask = mask_1;

	this.addChild(this.shape_37);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,63.5,74.1);


(lib.Grupodeclips0_10_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgLAiQgNgEgFgOQgFgNAFgMQAFgMAJgHQAJgHAJAAQAFAAAEACQANAEAFAOQAFANgGAMQgFAPgMAHQgIAEgFAAQgFAAgFgCg");
	mask_1.setTransform(3.7,3.7);

	// Capa 3
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.rf(["#FFFFFF","#6C6B6B"],[0,1],1.5,-0.8,0,1.5,-0.8,5.2).s().p("AgkAmIAAhLIBIAAIAABLg");
	this.shape_11.setTransform(3.7,3.9);

	this.shape_11.mask = mask_1;

	this.addChild(this.shape_11);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,7.4,7.8);


(lib.Grupodeclips0_9_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgLAiQgNgEgFgOQgFgNAFgNQAFgLAJgHQAJgHAJAAIAJABQANAFAFANQAFAOgGAMQgFAPgMAHQgIAEgFAAQgFAAgFgCg");
	mask_1.setTransform(3.7,3.7);

	// Capa 3
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["#FFFFFF","#6C6B6B"],[0,1],1.5,-0.8,0,1.5,-0.8,5.3).s().p("AgjAmIAAhLIBHAAIAABLg");
	this.shape_10.setTransform(3.7,3.9);

	this.shape_10.mask = mask_1;

	this.addChild(this.shape_10);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,7.4,7.8);


(lib.Grupodeclips0_8_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgNgrIAIAMIATBCIgCAJg");
	mask_1.setTransform(3.8,5.2);

	// Capa 3
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#B6B5B5","#E6E6E6"],[0,1],1.1,4.1,-1,-3.8).s().p("AgkglIAwgOIAZBZIgwAOg");
	this.shape_9.setTransform(3.8,5.2);

	this.shape_9.mask = mask_1;

	this.addChild(this.shape_9);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,7.6,10.5);


(lib.Grupodeclips0_7_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AAAAnIgThCIANgQIAaBXg");
	mask_1.setTransform(2,4.5);

	// Capa 3
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#B6B5B5","#E6E6E6"],[0,1],-1.9,0,2,0).s().p("AgTAsIAAhXIAnAAIAABXg");
	this.shape_7.setTransform(2,4.5);

	this.shape_7.mask = mask_1;

	this.addChild(this.shape_7);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,4.1,9);


(lib.Grupodeclips0_6_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgkgnIAugJIAbBYIgtAJg");
	mask_1.setTransform(3.8,4.9);

	// Capa 3
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#B6B5B5","#CDCDCC"],[0,1],-3.6,0,3.7,0).s().p("AgkAxIAAhhIBJAAIAABhg");
	this.shape_14.setTransform(3.8,4.9);

	this.shape_14.mask = mask_1;

	this.addChild(this.shape_14);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,7.5,9.8);


(lib.Grupodeclips0_5_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AALgaIAwgJIhHA+IguAJg");
	mask_1.setTransform(7,5.3);

	// Capa 3
	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#858484","#CDCDCC"],[0,1],0.4,2.5,-0.2,-2.2).s().p("AhEghIB9gTIAMBWIh8ATg");
	this.shape_37.setTransform(7,5.3);

	this.shape_37.mask = mask_1;

	this.addChild(this.shape_37);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,14,10.7);


(lib.Grupodeclips0_4_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgrAcIBDg9IAUAFIhFA+g");
	mask_1.setTransform(4.5,3.5);

	// Capa 3
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#B6B5B5","#E6E6E6"],[0,1],-4.3,0,4.5,0).s().p("AgrAiIAAhDIBXAAIAABDg");
	this.shape_14.setTransform(4.5,3.5);

	this.shape_14.mask = mask_1;

	this.addChild(this.shape_14);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,9,6.9);


(lib.Grupodeclips0_3_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgUgIIAegEIALARIgpAIg");
	mask_1.setTransform(2.7,2.1);

	// Capa 3
	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#555454","#858484"],[0,1],-0.1,-1,0.2,1).s().p("AgZgLIAtgJIAGAgIgtAJg");
	this.shape_41.setTransform(2.7,2.1);

	this.shape_41.mask = mask_1;

	this.addChild(this.shape_41);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,5.4,4.3);


(lib.Grupodeclips0_2_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgnBJQAIgHAFgIQAJgOAFgYQAGgTABgYQABgWgDgbIAsgJQAEAWgBAbQgCAagFARQgHAYgIANQgKARgKAHIgMAGIgZAEg");
	mask_1.setTransform(6.6,9.6);

	// Capa 3
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#E6E6E6","#F3F2F3","#555454"],[0,0.224,1],-1,-6.9,1.1,7.1).s().p("AhBhOIBngQIAcCtIhnAQg");
	this.shape_14.setTransform(6.6,9.6);

	this.shape_14.mask = mask_1;

	this.addChild(this.shape_14);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,13.2,19.1);


(lib.Grupodeclips0_1_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgohhIA8geIAVBFIhDA9QACAcAAAWQAAAXgFAWQgEAPgHAOg");
	mask_1.setTransform(4.2,12.8);

	// Capa 3
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#6C6B6B","#9B9B9B","#E6E6E6"],[0,0.051,1],-4,0,4.2,0).s().p("AgoB/IAAj+IBRAAIAAD+g");
	this.shape_12.setTransform(4.2,12.8);

	this.shape_12.mask = mask_1;

	this.addChild(this.shape_12);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,8.3,25.6);


(lib.Grupodeclips0_37 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgQAvQAGgKAEgQQAFgTABgWQAAgXgBgZIgBgBIAAgDIAAgCIAAgCIAQAHIAAACIAAABIAAACIABACQACAZgBAXQgCAUgFAVQgFASgIAQQgFAKgHAFg");
	mask_1.setTransform(1.7,7.7);

	// Capa 3
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#555454","#575656","#7B7978","#9C9A99","#B7B5B4","#C7C7C6","#CDCDCC"],[0,0.012,0.22,0.424,0.624,0.816,1],-1.5,0,1.7,0).s().p("AgQBMIAAiYIAhAAIAACYg");
	this.shape_6.setTransform(1.7,7.7);

	this.shape_6.mask = mask_1;

	this.addChild(this.shape_6);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,3.5,15.4);


(lib.Grupodeclips0_13_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AlPAQIJvgsIAwALIp5Aug");
	mask_1.setTransform(33.7,3);

	// Capa 3
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#CDCDCC","#F3F2F3"],[0,1],-33.5,0,33.8,0).s().p("AlPAdIAAg5IKfAAIAAA5g");
	this.shape_14.setTransform(33.7,3);

	this.shape_14.mask = mask_1;

	this.addChild(this.shape_14);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,67.4,6);


(lib.Grupodeclips0_11_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgYABIABgEQABgDACgCQACgDACAAIAFgCIAkANIgFAAQgCAAgCADIgDAFIgBAGg");
	mask_2.setTransform(3.6,3.3);

	// Capa 3
	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["#CDCDCC","#F3F2F3","#CDCDCC"],[0,0.518,1],0.4,-0.7,-0.2,0.9).s().p("AgiAKIARgpIA0AWIgRApg");
	this.shape_38.setTransform(3.6,3.3);

	this.shape_38.mask = mask_2;

	this.addChild(this.shape_38);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,7.2,6.6);


(lib.Grupodeclips0_10_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("Ak8kyIABgGIADgFQACgDACAAIAGgBIJrgwQg3D7ilDCQijDEjrBig");
	mask_2.setTransform(31.8,37.1);

	// Capa 3
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.rf(["#CDCDCC","#F3F2F3"],[0,1],-66.6,-56.3,0,-66.6,-56.3,99.1).s().p("Ak8FyIAArjIJ5AAIAALjg");
	this.shape_12.setTransform(31.8,37.1);

	this.shape_12.mask = mask_2;

	this.addChild(this.shape_12);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,63.5,74.1);


(lib.Grupodeclips0_9_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AAfBRQgCgWgGgaQgEgUgJgYQgJgVgKgVQgMgSgNgNIAIAIQAMALAMATQAIASAJAVQAIAUAGAYQAEAVACAbg");
	mask_2.setTransform(3.7,8.6);

	// Capa 3
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#6C6B6B","#E6E6E6"],[0,1],-3.5,0,3.6,0).s().p("AgjBVIAAipIBGAAIAACpg");
	this.shape_11.setTransform(3.6,8.6);

	this.shape_11.mask = mask_2;

	this.addChild(this.shape_11);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,7.2,17.2);


(lib.Grupodeclips0_8_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AADgoIAEACIgHA+IgGARg");
	mask_2.setTransform(0.7,4.2);

	// Capa 3
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#B6B5B5","#E6E6E6"],[0,1],0,4.2,0,-4).s().p("AgGApIAAhRIANAAIAABRg");
	this.shape_10.setTransform(0.7,4.2);

	this.shape_10.mask = mask_2;

	this.addChild(this.shape_10);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,1.4,8.4);


(lib.Grupodeclips0_7_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgMAcIAIg+IARgHIgLBSg");
	mask_2.setTransform(1.3,4.2);

	// Capa 3
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#B6B5B5","#E6E6E6"],[0,1],0,4.2,0,-4).s().p("AgMApIAAhSIAZAAIAABSg");
	this.shape_8.setTransform(1.3,4.2);

	this.shape_8.mask = mask_2;

	this.addChild(this.shape_8);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,2.7,8.4);


(lib.Grupodeclips0_6_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgRgkIAtgJIgLBSIgtAJg");
	mask_2.setTransform(2.9,4.7);

	// Capa 3
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#B6B5B5","#CDCDCC"],[0,1],-2.8,0,2.9,0).s().p("AgcAuIAAhbIA4AAIAABbg");
	this.shape_15.setTransform(2.9,4.7);

	this.shape_15.mask = mask_2;

	this.addChild(this.shape_15);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,5.8,9.3);


(lib.Grupodeclips0_5_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgNAqQgGgYgJgXIgLgWIAAhBIAHAFQAOALAOAUQAKATAKAYQAKAWAGAZQAGAZACAZIgtAJQgCgZgGgag");
	mask_2.setTransform(7.1,10.7);

	// Capa 3
	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["#E6E6E6","#F3F2F3","#555454"],[0,0.224,1],1.5,8.8,-1.5,-9.5).s().p("AhFhWIBrgTIAgDBIhrASg");
	this.shape_38.setTransform(7.1,10.7);

	this.shape_38.mask = mask_2;

	this.addChild(this.shape_38);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,14.1,21.3);


(lib.Grupodeclips0_4_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgJAFIAHgMIAMAKIgBACIgSADg");
	mask_2.setTransform(1.7,1.7);

	// Capa 3
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#555454","#858484"],[0,1],-0.4,1.1,0.2,-0.2).s().p("AgQAFIALgUIAWALIgLAUg");
	this.shape_15.setTransform(1.7,1.7);

	this.shape_15.mask = mask_2;

	this.addChild(this.shape_15);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,3.4,3.4);


(lib.Grupodeclips0_3_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AAAAzIAAgEIgFgeIgHgbIgDgJIAAgsIAIARIAJAcIAIAcIAFAeIABAIIAAAEIAAAEIgQAIg");
	mask_2.setTransform(1.7,6.5);

	// Capa 3
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#555454","#B5B5B5"],[0,1],-1.5,0,1.7,0).s().p("AgPBAIAAh/IAfAAIAAB/g");
	this.shape_42.setTransform(1.7,6.5);

	this.shape_42.mask = mask_2;

	this.addChild(this.shape_42);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,3.4,13);


(lib.Grupodeclips0_2_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgrA4IgGAPIAAi7QAFAPAFAUQAGAYABAaIBSBUIgIA/g");
	mask_2.setTransform(5.1,11.7);

	// Capa 3
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#6C6B6B","#9B9B9B","#E6E6E6"],[0,0.051,1],-4.9,0,5.1,0).s().p("AgxB0IAAjoIBjAAIAADog");
	this.shape_15.setTransform(5.1,11.7);

	this.shape_15.mask = mask_2;

	this.addChild(this.shape_15);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,10.1,23.4);


(lib.Grupodeclips0_1_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgLAiQgNgEgFgNQgFgOAFgMQAFgMAJgHQAJgHAIAAQAFAAAFACQAMAEAGAOQAFANgGAMQgFAPgMAHQgIAEgFAAQgFAAgFgCg");
	mask_2.setTransform(3.7,3.6);

	// Capa 3
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.rf(["#FFFFFF","#6C6B6B"],[0,1],1.5,-0.8,0,1.5,-0.8,5.3).s().p("AgkAmIAAhLIBIAAIAABLg");
	this.shape_13.setTransform(3.7,3.9);

	this.shape_13.mask = mask_2;

	this.addChild(this.shape_13);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,7.4,7.7);


(lib.Grupodeclips0_38 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgLAiQgNgEgFgOQgFgNAFgMQAFgMAJgHQAJgHAJAAQAFAAAEACQANAEAFAOQAFANgGAMQgFAPgMAHQgIAEgFAAQgFAAgFgCg");
	mask_2.setTransform(3.7,3.7);

	// Capa 3
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["#FFFFFF","#6C6B6B"],[0,1],1.5,-0.8,0,1.5,-0.8,5.3).s().p("AgkAmIAAhLIBIAAIAABLg");
	this.shape_7.setTransform(3.7,3.9);

	this.shape_7.mask = mask_2;

	this.addChild(this.shape_7);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,7.4,7.8);


(lib.corriente = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF9900").ss(1,1,1).p("AAqgpQASARAAAYQAAAZgSARQgRASgZAAQgYAAgRgSQgSgRAAgZQAAgYASgRQARgSAYAAQAZAAARASg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgpAqQgSgSAAgYQAAgXASgSQASgSAXAAQAYAAASASQASASAAAXQAAAYgSASQgSASgYAAQgXAAgSgSg");

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-5.9,-5.9,12,12);


(lib.tipos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_3'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 228;
	this.text.setTransform(-2,-12.3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(0,0,0.8,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(0,0,0.8,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(0,0,0.8,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-116.1,-14.9,232.2,30);


(lib.gasRelleno = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_4'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 228;
	this.text.setTransform(-2,-12.3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(0,0,0.8,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(0,0,0.8,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(0,0,0.8,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-116.1,-14.9,232.2,30);


(lib.Filamento = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_1'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 228;
	this.text.setTransform(-2,-12.3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(0,0,0.8,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(0,0,0.8,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(0,0,0.8,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-116.1,-14.9,232.2,30);


(lib.conductores = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['btn_2'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 228;
	this.text.setTransform(-2,-12.3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(0,0,0.8,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(0,0,0.8,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(0,0,0.8,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-116.1,-14.9,232.2,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_info = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("i", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 8;
	this.text.setTransform(13.1,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape.setTransform(15,15.9,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_1.setTransform(15,15.9,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]}).to({state:[{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:12.5,y:-1}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.5,30,30.7);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-6,-16.6,1.247,1.197);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0,5.2,1.247,1.197);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_1.setTransform(0,5.2,1.247,1.197);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.shape,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.text,p:{scaleX:1.412,scaleY:1.356,x:-8.5,y:-19.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.5,-16.7,38.7,40.9);


(lib.on = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Grupodeclips0_37();
	this.instance.setTransform(42.8,6.1,1,1,0,0,0,1.7,7.7);

	this.instance_1 = new lib.Grupodeclips0_1_1();
	this.instance_1.setTransform(45.3,-1.8,1,1,0,0,0,4.2,12.8);

	this.instance_2 = new lib.Grupodeclips0_2_1();
	this.instance_2.setTransform(45.1,6.5,1,1,0,0,0,6.6,9.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E6E6E6").s().p("AgkAMIBJgiIgNARIg8Abg");
	this.shape.setTransform(44.8,-14);

	this.instance_3 = new lib.Grupodeclips0_3_1();
	this.instance_3.setTransform(43.2,-13.9,1,1,0,0,0,2.6,2.1);

	this.instance_4 = new lib.Grupodeclips0_4_1();
	this.instance_4.setTransform(46.9,-4.3,1,1,0,0,0,4.5,3.5);

	this.instance_5 = new lib.Grupodeclips0_5_1();
	this.instance_5.setTransform(50.2,-4.5,1,1,0,0,0,7,5.3);

	this.instance_6 = new lib.Grupodeclips0_6_1();
	this.instance_6.setTransform(52.4,-12.2,1,1,0,0,0,3.8,4.9);

	this.instance_7 = new lib.Grupodeclips0_7_1();
	this.instance_7.setTransform(49.3,-11.7,1,1,0,0,0,2,4.5);

	this.instance_8 = new lib.Grupodeclips0_8_1();
	this.instance_8.setTransform(54.9,-12.6,1,1,0,0,0,3.8,5.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EBEBEB").s().p("AgEAHIgBgCIgBgCIAJgNIAEAIIgJANg");
	this.shape_1.setTransform(39.9,-12.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CDCDCC").s().p("AAAAqQACgPABgPQADgOgBgQQAAgPgDgTIAEgKIADAiQAAARgCAOQgBARgEAMQgCARgEAIIgEAGQAFgJADgMg");
	this.shape_2.setTransform(48.6,3.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#9B9B9B").s().p("AAAADIgJgRIACAAIAKARIAHAMg");
	this.shape_3.setTransform(45.3,-13.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ak8AYQAJgCEzgWQE1gYAIACQgJABk0AWQklAXgVAAIgCAAg");
	this.shape_4.setTransform(44.2,-52);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#555454").s().p("AAAABQAAgHgCgLIgFgJIAIAAIADAIQADAKABAJQAAAQgIAJIgHABQAHgHAAgTg");
	this.shape_5.setTransform(46.5,35.4);

	this.instance_9 = new lib.Grupodeclips0_9_1();
	this.instance_9.setTransform(45.6,35.8,1,1,0,0,0,3.6,3.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#555454").s().p("AAAAAQAAgGgCgLIgFgJIAHAAIAEAIQADAKABAIQAAARgIAJIgHABQAHgIAAgTg");
	this.shape_6.setTransform(46.3,-38.2);

	this.instance_10 = new lib.Grupodeclips0_10_1();
	this.instance_10.setTransform(45.5,-37.8,1,1,0,0,0,3.7,3.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#222222").s().p("AgqiQIBVgLIgCEoIhTAPg");
	this.shape_7.setTransform(45.4,-0.2);

	this.instance_11 = new lib.Grupodeclips0_11_1();
	this.instance_11.setTransform(42.9,-17.2,1,1,0,0,0,31.8,37);

	this.instance_12 = new lib.Grupodeclips0_14_1();
	this.instance_12.setTransform(42.2,-52.4,1,1,0,0,0,33.6,3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAKHxQgDg+gImzQgLnyACgIQADAJAJHxQAKGzgBA+IAAAKIgBgKg");
	this.shape_8.setTransform(12.2,2.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#CDCDCC","#F3F2F3"],[0,1],-38.9,-38.9,37.5,37.5).s().p("AlZISIAAv+IKzg+IAAQMIp8BGIABgKQABg+gKm0QgLnwgDgJQgCAIALHyQAKGzADA+IAAAKIgeADg");
	this.shape_9.setTransform(42.5,-1.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.instance_12},{t:this.instance_11},{t:this.shape_7},{t:this.instance_10},{t:this.shape_6},{t:this.instance_9},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.shape},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.instance_12},{t:this.instance_11},{t:this.shape_7},{t:this.instance_10},{t:this.shape_6},{t:this.instance_9},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.shape},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(7.8,-57.3,69.3,111.1);


(lib.off = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAeBGQgBgOgDgNQgEgWgJgZQgKgagLgTIgPgWIgHgJIAIAIIAPAWQALATAKAbQAJAYAEAXQADANABAOIAAALg");
	this.shape.setTransform(45.9,-5.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAOAyQgDgdgHgVQgEgZgLgZIgDgHIADAHQALAWAGAcQAHAbABAXIABAIg");
	this.shape_1.setTransform(42.9,-1.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ak8AYQAJgDEzgVQE1gYAIABQgJADk0AVQkrAXgQAAIgBAAg");
	this.shape_2.setTransform(44.2,-52);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#555454").s().p("AAAAAQAAgGgCgLIgFgJIAIAAIADAIQADAKABAIQAAARgIAIIgHACQAHgIAAgTg");
	this.shape_3.setTransform(46.5,35.4);

	this.instance = new lib.Grupodeclips0_38();
	this.instance.setTransform(45.7,35.7,1,1,0,0,0,3.7,3.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#555454").s().p("AAAABQAAgIgCgKIgFgJIAHAAIAEAIQADAKABAJQAAAQgIAJIgHABQAHgJAAgRg");
	this.shape_4.setTransform(46.3,-38.3);

	this.instance_1 = new lib.Grupodeclips0_1_2();
	this.instance_1.setTransform(45.5,-37.8,1,1,0,0,0,3.7,3.9);

	this.instance_2 = new lib.Grupodeclips0_2_2();
	this.instance_2.setTransform(46.1,7.9,1,1,0,0,0,5,11.7);

	this.instance_3 = new lib.Grupodeclips0_3_2();
	this.instance_3.setTransform(42.8,-1.7,1,1,0,0,0,1.7,6.5);

	this.instance_4 = new lib.Grupodeclips0_4_2();
	this.instance_4.setTransform(42.1,14.4,1,1,0,0,0,1.7,1.7);

	this.instance_5 = new lib.Grupodeclips0_5_2();
	this.instance_5.setTransform(45,-5.3,1,1,0,0,0,7,10.7);

	this.instance_6 = new lib.Grupodeclips0_6_2();
	this.instance_6.setTransform(54.9,16.3,1,1,0,0,0,2.9,4.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F3F2F3").s().p("AhBgmIAvgIIBUBUIgvAJg");
	this.shape_5.setTransform(51.1,7.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E6E6E6").s().p("AgyglIARgIIBUBUIgTAHg");
	this.shape_6.setTransform(47.9,8.5);

	this.instance_7 = new lib.Grupodeclips0_7_2();
	this.instance_7.setTransform(51.7,16.7,1,1,0,0,0,1.3,4.2);

	this.instance_8 = new lib.Grupodeclips0_8_2();
	this.instance_8.setTransform(57.4,15.8,1,1,0,0,0,0.7,4.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#9B9B9B").s().p("AgkgXIgOgMIBVA6IAQAOg");
	this.shape_7.setTransform(46.8,17.2);

	this.instance_9 = new lib.Grupodeclips0_9_2();
	this.instance_9.setTransform(46,-5,1,1,0,0,0,3.6,8.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#555454").s().p("AgBAAIADAAIAAAAIgDABg");
	this.shape_8.setTransform(43.3,14.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#222222").s().p("AgqiQIBVgLIgCEoIhTAPg");
	this.shape_9.setTransform(45.4,-0.3);

	this.instance_10 = new lib.Grupodeclips0_10_2();
	this.instance_10.setTransform(42.9,-17.2,1,1,0,0,0,31.8,37.1);

	this.instance_11 = new lib.Grupodeclips0_11_2();
	this.instance_11.setTransform(9.9,-49.4,1,1,0,0,0,3.6,3.3);

	this.instance_12 = new lib.Grupodeclips0_13_1();
	this.instance_12.setTransform(42.2,-52.5,1,1,0,0,0,33.6,3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AALH4IgBgOIgEhmIAAgNIgCgzIAAggIAAgEIgBgYIgBg3IgBgjIAAgDIgBgSIAAhNIAAgkIgBgoIgJn2IAAgEIAAAEIAMH2QAKG0gBA9IAAAIIAAACIAAgDg");
	this.shape_10.setTransform(12.2,2.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#CDCDCC","#F3F2F3"],[0,1],-38.9,-38.9,37.5,37.5).s().p("AlZISIAAv+IKzg+IAAQMIqaBJgAk5nKIAKH3IABAoIAAAkIACBNIAAASIAAADIABAjIACA2IAAAYIAAAFIABAfIACA0IAAAMIADBnIABAHIAAAGIAAADIABgBIAAgIQABg+gKm0IgOn2IAAgDIgBADg");
	this.shape_11.setTransform(42.5,-1.7);

	this.addChild(this.shape_11,this.shape_10,this.instance_12,this.instance_11,this.instance_10,this.shape_9,this.shape_8,this.instance_9,this.shape_7,this.instance_8,this.instance_7,this.shape_6,this.shape_5,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.shape_4,this.instance,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(7.3,-57.3,69.9,111.1);


(lib.haloAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.instance = new lib.halo();
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0.75},39).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-116.4,-116.4,233,233);


(lib.bombilla = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#373535").ss(0.3,0,0,3.9).p("AEJpsIGNAAABpjlIItAAAAiDhIJ0AAACOJtIIIAAADhAOIG5AAAqZFKILuAAAqZEZIKVAAAqZksIItAA");
	this.shape.setTransform(47.4,3.4);

	this.instance = new lib.Grupodeclips0();
	this.instance.setTransform(66.5,22.4,1,1,0,0,0,3.1,11);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYgZQAGgoAPghIAfASQgSAggFAoQgGAwANAtIgXAOQgWg8AJhAg");
	this.shape_1.setTransform(23.7,-35.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FEFEFE").s().p("AgYgZQAFgmAQgkIAfASQgSAggGApQgEAxAMAtIgYAOQgWg7AKhCg");
	this.shape_2.setTransform(23.7,-35.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FDFEFE").s().p("AgZgaQAFgnARgkIAgATQgTAigFAoQgGAxAOAuIgYAPQgXg9AJhDg");
	this.shape_3.setTransform(23.7,-35.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FDFDFD").s().p("AgagbQAGgoAQgjIAhATQgTAhgGAqQgFAzAOAtIgZAPQgXg9AJhFg");
	this.shape_4.setTransform(23.8,-35.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FCFDFD").s().p("AgagaQAFgnARgmIAiATQgTAigGAqQgGAyAOAwIgZAOQgYg9AKhFg");
	this.shape_5.setTransform(23.8,-35.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FBFCFC").s().p("AgagbQAGgqAQgkIAjAUQgUAjgGAqQgFAzAOAwIgaAPQgZhAALhFg");
	this.shape_6.setTransform(23.8,-35.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FBFBFC").s().p("AgbgcQAGgoARgmIAjATQgUAmgGAoQgFA1APAwIgbAPQgZhAAKhHg");
	this.shape_7.setTransform(23.8,-35.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FAFBFB").s().p("AgcgcQAGgqASglIAkAUQgVAkgGArQgFA1APAwIgbAPQgahCAKhGg");
	this.shape_8.setTransform(23.8,-35.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FAFAFB").s().p("AgcgcQAGgsASglIAkAVQgUAlgGArQgGA0APAyIgbAQQgahBAKhJg");
	this.shape_9.setTransform(23.8,-35.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F9FAFA").s().p("AgdgcQAGgrASgnIAmAUQgVAlgHAsQgFA3APAyIgcAPQgahDAKhIg");
	this.shape_10.setTransform(23.9,-35.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F8F9FA").s().p("AgdgdQAGgsASgmIAmAUQgWAogFAqQgGA3AQAzIgcAPQgchCALhLg");
	this.shape_11.setTransform(23.9,-35.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F8F9F9").s().p("AgegdQAGgtATgnIAnAVQgWAngHAsQgFA4AQAzIgdAQQgchDALhMg");
	this.shape_12.setTransform(23.9,-35.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#F7F9F9").s().p("AgegeQAGgrATgpIAnAVQgWAmgGAuQgGA3ARA1IgeAQQgchFALhMg");
	this.shape_13.setTransform(23.9,-35.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F7F8F9").s().p("AgfgeQAHguATgnIAoAVQgXAogGAtQgGA6ARAzIgeAQQgdhFALhNg");
	this.shape_14.setTransform(23.9,-35.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F7F8F8").s().p("AgggeQAHguATgpIApAWQgXAogGAuQgGA5ARA1IgeARQgehHALhNg");
	this.shape_15.setTransform(24,-35.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F6F7F8").s().p("AgggfQAGguAUgpIAqAWQgXApgHAtQgGA6ASA3IgfAQQgehIALhOg");
	this.shape_16.setTransform(24,-35.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F6F7F7").s().p("AgggfQAGgvAUgpIArAWQgXAogIAwQgGA7ASA2IgfAQQgfhJAMhOg");
	this.shape_17.setTransform(24,-35.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F5F6F7").s().p("AghggQAGguAVgrIArAXQgYApgHAwQgGA7ASA3IggARQgehJALhRg");
	this.shape_18.setTransform(24,-35.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F5F6F7").s().p("AgiggQAHgwAVgqIAsAXQgZAqgGAwQgHA7ATA4IghARQgfhJALhSg");
	this.shape_19.setTransform(24,-35.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F4F6F6").s().p("AgiggQAHgxAVgqIAsAXQgYApgHAxQgHA9AUA4IghARQghhKAMhSg");
	this.shape_20.setTransform(24,-35.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F4F5F6").s().p("AgjghQAHgvAVgtIAuAYQgaArgGAwQgHA+AUA4IgiASQghhLAMhUg");
	this.shape_21.setTransform(24.1,-35.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#F3F5F6").s().p("AgjghQAHgzAVgqIAuAYQgZArgHAxQgHA+AUA6IgiARQghhNAMhTg");
	this.shape_22.setTransform(24.1,-35.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#F3F5F5").s().p("AgkghQAIgyAVgsIAvAYQgZArgIAyQgHA+AVA7IgjARQgihMAMhVg");
	this.shape_23.setTransform(24.1,-35.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#F3F4F5").s().p("AgkgiQAGgyAXgtIAvAZQgZAqgIA0QgHBAAVA6IgjASQgjhPANhVg");
	this.shape_24.setTransform(24.1,-35.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#F2F4F5").s().p("AglgiQAIgzAWgtIAwAZQgaArgIA0QgHBAAWA7IgkASQgjhPAMhWg");
	this.shape_25.setTransform(24.1,-35.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#F2F3F4").s().p("AglgjQAHgzAXgtIAxAYQgbAtgHA0QgIBAAWA8IgkASQgkhQANhXg");
	this.shape_26.setTransform(24.1,-35.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#F1F3F4").s().p("AgmgjQAHg0AXguIAyAZQgbAsgHA2QgIBBAWA8IglATQgkhSANhXg");
	this.shape_27.setTransform(24.2,-35.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#F1F3F4").s().p("AgmgjQAHg1AXguIAzAZQgbAtgIA1QgIBDAXA9IgmASQgkhQANhag");
	this.shape_28.setTransform(24.2,-35.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#F1F2F3").s().p("AgngkQAHg0AYgvIAzAZQgcAugHA1QgIBCAXA/IgmASQglhSANhag");
	this.shape_29.setTransform(24.2,-35.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#F0F2F3").s().p("AgogkQAJg3AXguIA0AaQgcAvgIA1QgIBDAXA/IgmATQglhTAMhbg");
	this.shape_30.setTransform(24.2,-35.2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#F0F2F3").s().p("AgoglQAHg0AZgxIA1AaQgdAtgIA4QgIBFAYA+IgnATQgmhUANhcg");
	this.shape_31.setTransform(24.2,-35.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#EFF1F3").s().p("AgpglQAIg3AYgvIA2AaQgdAvgIA3QgIBFAYA/IgnATQgnhVANhcg");
	this.shape_32.setTransform(24.3,-35.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#EFF1F2").s().p("AgpglQAIg4AYgwIA2AbQgdAwgIA3QgIBEAZBBIgoAUQgohVAOheg");
	this.shape_33.setTransform(24.3,-35.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#EEF1F2").s().p("AgpgmQAHg2AZgyIA3AbQgdAvgIA5QgJBHAZBAIgoATQgohXAOheg");
	this.shape_34.setTransform(24.3,-35.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#EEF0F2").s().p("AgqgmQAIg4AZgxIA4AbQgeAwgIA5QgJBGAaBCIgpAUQgphYAOhfg");
	this.shape_35.setTransform(24.3,-35.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#EEF0F1").s().p("AgrgmQAIg6AagxIA4AcQgeAwgIA6QgJBGAaBDIgqAUQgphZAOhfg");
	this.shape_36.setTransform(24.3,-35.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#EDF0F1").s().p("AgrgnQAIg4AagzIA5AcQgeAwgJA6QgJBIAbBEIgqATQgqhXAOhjg");
	this.shape_37.setTransform(24.3,-35.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#EDEFF1").s().p("AgsgnQAJg7AZgyIA6AdQgfAwgIA7QgJBJAbBDIgrAUQgqhZAOhig");
	this.shape_38.setTransform(24.4,-35.3);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#ECEFF1").s().p("AgsgoQAIg6AagzIA7AdQggAxgIA7QgJBJAbBEIgrAVQgqhbAOhjg");
	this.shape_39.setTransform(24.4,-35.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#ECEFF0").s().p("AgtgoQAIg5Abg1IA7AdQggAygIA7QgJBJAbBGIgrAUQgrhaAOhlg");
	this.shape_40.setTransform(24.4,-35.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#ECEEF0").s().p("AgugoQAJg8AbgzIA8AdQggAygJA8QgJBLAcBFIgsAVQgshdAOhkg");
	this.shape_41.setTransform(24.4,-35.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#EBEEF0").s().p("AgugpQAIg6Acg2IA9AdQggAzgJA9QgKBKAdBHIgtAVQgshdAOhmg");
	this.shape_42.setTransform(24.4,-35.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#EBEEEF").s().p("AgugpQAIg7Acg2IA9AeQghA0gIA8QgKBLAdBIIgtAUQgtheAPhmg");
	this.shape_43.setTransform(24.4,-35.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#EAEDEF").s().p("AgvgpQAJg+Abg1IA/AfQghAygJA/QgKBMAdBIIguAUQgtheAPhng");
	this.shape_44.setTransform(24.5,-35.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#EAEDEF").s().p("AgvgqQAIg8Acg3IA/AeQghA0gJA/QgKBMAeBJIgvAVQguhhAQhng");
	this.shape_45.setTransform(24.5,-35.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#EAEDEF").s().p("AgwgqQAJg/Acg1IBAAeQgiAzgJBAQgKBNAeBKIgvAVQguhgAPhpg");
	this.shape_46.setTransform(24.5,-35.3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#E9EDEE").s().p("AgxgqQAJg/Adg2IBAAeQgiA1gJA/QgKBOAeBKIgvAWQgvhhAPhqg");
	this.shape_47.setTransform(24.5,-35.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#E9ECEE").s().p("AgxgrQAIg9Aeg4IBBAeQgiA1gJBAQgLBPAfBKIgwAWQgvhiAPhrg");
	this.shape_48.setTransform(24.5,-35.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#E9ECEE").s().p("AgygrQAJhAAdg3IBCAfQgiA1gKBBQgKBQAfBKIgwAWQgwhiAPhsg");
	this.shape_49.setTransform(24.6,-35.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#E8ECEE").s().p("AgygrQAIg/Aeg6IBDAgQgjA2gJBBQgLBQAgBMIgxAVQgxhjAQhsg");
	this.shape_50.setTransform(24.6,-35.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#E8EBED").s().p("AgzgsQAJg/Aeg6IBEAgQgkA2gJBCQgLBRAgBMIgxAWQgxhkAPhug");
	this.shape_51.setTransform(24.6,-35.3);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#E7EBED").s().p("AgzgsQAJhBAeg5IBEAgQgjA3gKBCQgLBRAhBNIgyAWQgyhlAQhug");
	this.shape_52.setTransform(24.6,-35.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgFAHQgYgOgdgFIAKgiQAlAHAbAXQAdAVAOAgIgfAKQgMgYgVgQg");
	this.shape_53.setTransform(67.3,-55.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FEFEFE").s().p("AgGAIQgYgQgegFIAKgjQAmAIAdAYQAdAVAPAiIggAKQgNgZgWgQg");
	this.shape_54.setTransform(67.3,-55.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FDFEFE").s().p("AgGAIQgZgQgfgFIAKglQAoAIAdAZQAfAWAPAjIghALQgNgagXgRg");
	this.shape_55.setTransform(67.3,-55.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FDFDFD").s().p("AgGAIQgagQgggGIAKgmQApAJAfAZQAgAYAPAkIgiALQgOgbgXgSg");
	this.shape_56.setTransform(67.3,-55.6);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FCFDFD").s().p("AgGAIQgbgRghgGIAKgnQArAIAfAbQAhAZAQAlIgjAMQgOgcgYgTg");
	this.shape_57.setTransform(67.3,-55.6);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FBFCFC").s().p("AgHAJQgbgSgigGIALgpQArAJAhAbQAiAaAQAnIgkAMQgPgdgZgTg");
	this.shape_58.setTransform(67.3,-55.5);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FBFBFC").s().p("AgHAJQgcgSgjgGIALgrQAtAJAhAcQAjAbARApIglAMQgPgegagUg");
	this.shape_59.setTransform(67.3,-55.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FAFBFB").s().p("AgHAJQgdgTglgGIAMgsQAuAKAjAdQAkAbARAqIgmANQgPgfgbgVg");
	this.shape_60.setTransform(67.3,-55.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FAFAFB").s().p("AgIAJQgdgTglgHIALgtQAxAKAjAeQAlAcASArIgoAOQgQgggcgWg");
	this.shape_61.setTransform(67.3,-55.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#F9FAFA").s().p("AgIAKQgfgVglgGIAMguQAxAJAkAfQAmAdATAtIgpANQgQgggdgWg");
	this.shape_62.setTransform(67.3,-55.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#F8F9FA").s().p("AgIAKQgggWgngGIANgvQAzAJAlAhQAnAdASAuIgpAPQgRgigdgXg");
	this.shape_63.setTransform(67.3,-55.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#F8F9F9").s().p("AgIALQgggWgpgIIANgwQA0AKAmAhQApAfATAvIgrAOQgRgigegXg");
	this.shape_64.setTransform(67.3,-55.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#F7F9F9").s().p("AgJALQghgXgpgHIANgyQA1ALAoAiQApAgAUAwIgsAOQgSgjgfgYg");
	this.shape_65.setTransform(67.3,-55.3);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#F7F8F9").s().p("AgJALQgigXgqgIIAOgzQA2ALAoAjQAqAgAVAyIgtAPQgSgkgggZg");
	this.shape_66.setTransform(67.3,-55.3);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#F7F8F8").s().p("AgJALQgjgYgrgHIAOg1QA3ALAqAkQArAiAVAyIguAQQgTgmgggZg");
	this.shape_67.setTransform(67.3,-55.3);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#F6F7F8").s().p("AgJAMQgkgZgsgIIAOg2QA5ALAqAlQAtAjAVA0IguAQQgUgmghgag");
	this.shape_68.setTransform(67.3,-55.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#F6F7F7").s().p("AgKAMQgkgZgtgIIAOg4QA7AMAsAmQAtAjAVA2IgvAQQgVgogigag");
	this.shape_69.setTransform(67.3,-55.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#F5F6F7").s().p("AgKAMQglgagugIIAPg5QA7AMAtAnQAuAkAWA3IgwARQgVgpgjgbg");
	this.shape_70.setTransform(67.3,-55.2);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#F5F6F7").s().p("AgKAMQgmgagvgIIAPg7QA9ANAuAnQAuAlAXA4IgyASQgUgpgkgdg");
	this.shape_71.setTransform(67.3,-55.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#F4F6F6").s().p("AgKAMQgngbgwgIIAPg8QA/ANAuAoQAwAmAXA6IgzASQgVgrgkgdg");
	this.shape_72.setTransform(67.2,-55.1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#F4F5F6").s().p("AgKANQgogcgxgIIAPg+QBAANAvAqQAxAnAYA7Ig0ASQgVgsglgdg");
	this.shape_73.setTransform(67.2,-55.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#F3F5F6").s().p("AgLANQgogcgygJIAQg/QBAAOAxAqQAyAoAYA8Ig1ATQgWgtgmgeg");
	this.shape_74.setTransform(67.2,-55);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#F3F5F5").s().p("AgLAOQgpgegzgJIAQhAQBCAOAyArQAzApAYA9Ig2ATQgWgtgngeg");
	this.shape_75.setTransform(67.2,-55);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#F3F4F5").s().p("AgLAOQgrgeg0gJIARhBQBEAOAyAsQA0AqAZA+Ig2ATQgYgugngfg");
	this.shape_76.setTransform(67.2,-55);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#F2F4F5").s().p("AgLAOQgsgeg0gKIARhCQBEAOA0AtQA1AqAZBAIg3AUQgYgvgoggg");
	this.shape_77.setTransform(67.2,-54.9);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#F2F3F4").s().p("AgLAPQgtggg1gJIARhEQBFAOA2AuQA2AsAZBBIg5AUQgYgwgoggg");
	this.shape_78.setTransform(67.2,-54.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#F1F3F4").s().p("AgMAPQgsggg4gKIAShFQBIAPA1AvQA3AsAbBDIg6AUQgZgxgqghg");
	this.shape_79.setTransform(67.2,-54.9);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#F1F3F4").s().p("AgMAPQgughg4gJIAShHQBJAPA3AwQA4AtAbBEIg7AVQgZgygrgig");
	this.shape_80.setTransform(67.2,-54.9);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#F1F2F3").s().p("AgMAPQgvghg5gKIAShIQBKAPA4AxQA5AuAcBFIg9AWQgZgzgrgjg");
	this.shape_81.setTransform(67.2,-54.8);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#F0F2F3").s().p("AgNAPQgvghg6gLIAThJQBLAQA5AxQA6AwAcBHIg+AVQgZg0gtgkg");
	this.shape_82.setTransform(67.2,-54.8);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#F0F2F3").s().p("AgNAQQgwgig7gLIAThLQBMAQA6AzQA7AwAdBHIg/AXQgZg2gugjg");
	this.shape_83.setTransform(67.2,-54.8);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#EFF1F3").s().p("AgNAQQgxgjg8gLIAThMQBOAQA7A0QA8AxAdBJIhAAXQgag2guglg");
	this.shape_84.setTransform(67.2,-54.7);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#EFF1F2").s().p("AgOAQQgxgjg9gLIAThOQBPARA8A0QA9AyAeBLIhBAXQgbg3gvgmg");
	this.shape_85.setTransform(67.2,-54.7);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#EEF1F2").s().p("AgOARQgyglg+gLIAThOQBRAQA9A2QA+AyAeBMIhCAXQgbg3gwgmg");
	this.shape_86.setTransform(67.2,-54.7);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#EEF0F2").s().p("AgOARQgzglhAgLIAVhQQBSARA+A2QA/A0AeBNIhCAYQgdg6gwgmg");
	this.shape_87.setTransform(67.2,-54.7);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#EEF0F1").s().p("AgOASQg0gmhAgMIAUhRQBTARA/A3QBBA1AeBOIhDAYQgdg5gxgng");
	this.shape_88.setTransform(67.2,-54.6);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#EDF0F1").s().p("AgOASQg2gnhAgLIAUhTQBUARBBA5QBBA1AfBQIhEAYQgdg6gygog");
	this.shape_89.setTransform(67.2,-54.6);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#EDEFF1").s().p("AgOASQg3gnhCgMIAWhUQBVASBBA5QBCA2AhBRIhGAZQgeg8gygog");
	this.shape_90.setTransform(67.2,-54.5);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#ECEFF1").s().p("AgPATQg3gohDgMIAWhWQBXASBCA6QBDA4AhBSIhIAZQgdg8g0gpg");
	this.shape_91.setTransform(67.1,-54.5);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#ECEFF0").s().p("AgPASQg4gohEgMIAWhXQBYASBDA7QBFA5AhBTIhJAaQgeg+g0gqg");
	this.shape_92.setTransform(67.1,-54.5);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#ECEEF0").s().p("AgPATQg5gphFgNIAWhYQBaASBEA8QBFA6AiBVIhKAaQgeg/g1gqg");
	this.shape_93.setTransform(67.1,-54.5);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#EBEEF0").s().p("AgQATQg5gqhGgMIAWhaQBbATBFA9QBHA6AiBWIhLAbQgfhAg2grg");
	this.shape_94.setTransform(67.1,-54.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#EBEEEF").s().p("AgQATQg5gqhIgNIAXhbQBcATBHA+QBGA7AjBYIhLAbQgghBg3gsg");
	this.shape_95.setTransform(67.1,-54.4);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#EAEDEF").s().p("AgQAUQg7gshIgNIAXhcQBdAUBIA+QBIA8AjBaIhMAbQgghBg4gtg");
	this.shape_96.setTransform(67.1,-54.4);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#EAEDEF").s().p("AgQAUQg8gshJgNIAYheQBeAUBJBAQBJA9AjBaIhOAcQgghDg4gtg");
	this.shape_97.setTransform(67.1,-54.3);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#EAEDEF").s().p("AgRAUQg8gshKgNIAYhgQBgAVBJBAQBKA+AkBcIhOAcQghhEg6gug");
	this.shape_98.setTransform(67.1,-54.3);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#E9EDEE").s().p("AgRAVQg9guhLgNIAYhhQBhAVBKBBQBMBAAkBcIhPAdQgihFg6gug");
	this.shape_99.setTransform(67.1,-54.3);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#E9ECEE").s().p("AgRAVQg+gthMgPIAYhiQBjAWBLBCQBNBAAkBeIhQAdQgihGg7gvg");
	this.shape_100.setTransform(67.1,-54.3);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#E9ECEE").s().p("AgSAWQg+gvhNgOIAYhjQBkAVBMBDQBOBBAlBfIhSAeQgihHg8gvg");
	this.shape_101.setTransform(67.1,-54.2);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#E8ECEE").s().p("AgSAVQg/gvhOgOIAYhkQBmAVBNBEQBPBCAlBgIhTAeQgihHg9gxg");
	this.shape_102.setTransform(67.1,-54.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#E8EBED").s().p("AgSAWQhAgwhQgOIAahmQBmAVBPBFQBQBDAmBiIhVAeQgjhIg9gxg");
	this.shape_103.setTransform(67.1,-54.1);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#E7EBED").s().p("AgSAWQhBgxhRgOIAahnQBoAVBQBGQBQBEAnBjIhWAfQgjhKg+gxg");
	this.shape_104.setTransform(67.1,-54.1);

	this.instance_1 = new lib.Grupodeclips0_1();
	this.instance_1.setTransform(51.9,-11.8,1,1,0,0,0,5.1,1);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().s("#D47C3C").ss(1,0,1).p("AAYIXIgrAAQgKAAgIgIQgHgIAAgMIAArhIiKkZIAPgXIAPAXIAQgXIAPAXIAPgXIAQAXIAPgXIAPAXIAPgXIAQAXIAPgXIAOAXIAOgXIAQAXIAPgXIAPAXIAPgXIAPAXIAPgXIAQAXIAPgXIAQAXIAPgXIAQAYIiKEYIAAI1IBuAA");
	this.shape_105.setTransform(51.9,25.6);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#7B7C77").ss(0.6,0,0,3.9).p("AAaBFIBBiJAgZBFIhBiJ");
	this.shape_106.setTransform(51.9,-18.9);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("#5B6C6E").ss(0.2,0,0,3.9).p("AC4iuQACAAAAApQAAAHgQAFQgLADAAALQAAAKAJAEQASACAAAIQABAHgRAEQgLAEAAALQAAAKAJAEQASACAAAIQABAHgRAEQgLAEAAALQAAAHAJAEQASAEAAAGQAAAIgQAEQgLADAAAMQAAAJAJAEQASADAAAHQAAAEgGAEIADAAIg0BKIgDAAIghAuIitAAIgiguIgDAAIg3hKIAEgCQAKgEAAgKQAAgKgLgEQgPgDgBgHQAAgHARgFQAKgEAAgKQAAgIgLgEQgPgDgBgHQAAgHARgEQAKgEAAgKQAAgLgLgEQgPgDgBgGQAAgIARgEQAKgEAAgKQAAgLgLgEQgPgCgBgHIAAg4QAAgGgDgFQgEgHgGgBIGJgBQgFABgEAGQgDAFgBAFg");
	this.shape_107.setTransform(51.6,60.3);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#606963").s().p("AgEAkQgkg0gGgUIBdAAQgRAzgUAWg");
	this.shape_108.setTransform(47.9,71.3);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#656C67").s().p("AgMAkQglg2gGgSIBvAAQgQAvgWAag");
	this.shape_109.setTransform(48,71.3);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#6A706A").s().p("AgTAkIgZglQgPgXgFgMICBAAQgPAqgYAfg");
	this.shape_110.setTransform(48.2,71.3);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#70736E").s().p("AgbAkQgog4gFgQICRAAQgHAVgNAVQgLAVgJAKg");
	this.shape_111.setTransform(48.4,71.3);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#757772").s().p("AgjAkQgpg7gFgNICjAAQgHASgOAXQgNAWgHAKg");
	this.shape_112.setTransform(48.7,71.3);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#7A7B76").s().p("AgrAkIgagkQgSgbgDgJIC0AAQgFAQgQAZQgNAWgIAKg");
	this.shape_113.setTransform(48.9,71.3);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#7F7F7A").s().p("AgyAkQgthAgDgIIDFAAQgEAOgRAaIgWAhg");
	this.shape_114.setTransform(49,71.3);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#84837E").s().p("Ag5AkIgbgkQgVgegCgGIDXAAQgEAMgTAcQgQAagGAHg");
	this.shape_115.setTransform(49.2,71.3);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#898883").s().p("AhBAkQgvg/gDgJIDnAAQgDAKgUAdQgRAbgGAHg");
	this.shape_116.setTransform(49.4,71.3);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#8E8C88").s().p("AhJAkQgwhBgDgHID5AAQgDAIgVAeQgSAdgFAGg");
	this.shape_117.setTransform(49.7,71.3);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#94918D").s().p("AhRAkQgyhDgCgFIEKAAQgCAJguBAg");
	this.shape_118.setTransform(49.9,71.3);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#999692").s().p("AhYAkIg1hIIEbAAQgCAGgvBCg");
	this.shape_119.setTransform(50,71.3);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#9F9C97").s().p("AhgAkIg2hIIEtAAIgzBIg");
	this.shape_120.setTransform(50.2,71.3);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#A5A19D").s().p("AhnAkIg3hIIE9AAIgzBIg");
	this.shape_121.setTransform(50.4,71.3);

	this.instance_2 = new lib.Grupodeclips0_2();
	this.instance_2.setTransform(60.9,47.1,1,1,0,0,0,6.9,0.8);

	this.instance_3 = new lib.Grupodeclips0_3();
	this.instance_3.setTransform(51.7,45.5,1,1,0,0,0,19.9,4.4);

	this.instance_4 = new lib.Grupodeclips0_4();
	this.instance_4.setTransform(60.9,66.9,1,1,0,0,0,6.9,0.7);

	this.instance_5 = new lib.Grupodeclips0_5();
	this.instance_5.setTransform(52.4,66.7,1,1,0,0,0,18.2,1);

	this.instance_6 = new lib.Grupodeclips0_6();
	this.instance_6.setTransform(60.9,62,1,1,0,0,0,6.9,0.8);

	this.instance_7 = new lib.Grupodeclips0_7();
	this.instance_7.setTransform(51.8,64.9,1,1,0,0,0,17.2,2.6);

	this.instance_8 = new lib.Grupodeclips0_8();
	this.instance_8.setTransform(51.8,64.9,1,1,0,0,0,17.2,2.6);

	this.instance_9 = new lib.Grupodeclips0_9();
	this.instance_9.setTransform(51.8,64.9,1,1,0,0,0,17.2,2.6);

	this.instance_10 = new lib.Grupodeclips0_10();
	this.instance_10.setTransform(51.3,64.9,1,1,0,0,0,17.5,2.6);

	this.instance_11 = new lib.Grupodeclips0_11();
	this.instance_11.setTransform(51.7,65.2,1,1,0,0,0,17.4,2.3);

	this.instance_12 = new lib.Grupodeclips0_12();
	this.instance_12.setTransform(51.8,62.7,1,1,0,0,0,18.8,2);

	this.instance_13 = new lib.Grupodeclips0_13();
	this.instance_13.setTransform(60.9,57,1,1,0,0,0,6.9,0.7);

	this.instance_14 = new lib.Grupodeclips0_14();
	this.instance_14.setTransform(51.8,59.9,1,1,0,0,0,17.2,2.6);

	this.instance_15 = new lib.Grupodeclips0_15();
	this.instance_15.setTransform(51.8,59.9,1,1,0,0,0,17.2,2.6);

	this.instance_16 = new lib.Grupodeclips0_16();
	this.instance_16.setTransform(51.8,59.9,1,1,0,0,0,17.2,2.6);

	this.instance_17 = new lib.Grupodeclips0_17();
	this.instance_17.setTransform(51.3,59.9,1,1,0,0,0,17.5,2.6);

	this.instance_18 = new lib.Grupodeclips0_18();
	this.instance_18.setTransform(51.7,60.2,1,1,0,0,0,17.4,2.3);

	this.instance_19 = new lib.Grupodeclips0_19();
	this.instance_19.setTransform(51.8,57.8,1,1,0,0,0,18.8,2);

	this.instance_20 = new lib.Grupodeclips0_20();
	this.instance_20.setTransform(60.9,52.1,1,1,0,0,0,6.9,0.8);

	this.instance_21 = new lib.Grupodeclips0_21();
	this.instance_21.setTransform(51.8,54.9,1,1,0,0,0,17.2,2.6);

	this.instance_22 = new lib.Grupodeclips0_22();
	this.instance_22.setTransform(51.8,54.9,1,1,0,0,0,17.2,2.6);

	this.instance_23 = new lib.Grupodeclips0_23();
	this.instance_23.setTransform(51.8,54.9,1,1,0,0,0,17.2,2.6);

	this.instance_24 = new lib.Grupodeclips0_24();
	this.instance_24.setTransform(51.3,54.9,1,1,0,0,0,17.5,2.6);

	this.instance_25 = new lib.Grupodeclips0_25();
	this.instance_25.setTransform(51.7,55.2,1,1,0,0,0,17.4,2.3);

	this.instance_26 = new lib.Grupodeclips0_26();
	this.instance_26.setTransform(51.8,52.8,1,1,0,0,0,18.8,2);

	this.instance_27 = new lib.Grupodeclips0_27();
	this.instance_27.setTransform(51.8,49.9,1,1,0,0,0,17.2,2.6);

	this.instance_28 = new lib.Grupodeclips0_28();
	this.instance_28.setTransform(51.8,49.9,1,1,0,0,0,17.2,2.6);

	this.instance_29 = new lib.Grupodeclips0_29();
	this.instance_29.setTransform(51.8,49.9,1,1,0,0,0,17.2,2.6);

	this.instance_30 = new lib.Grupodeclips0_30();
	this.instance_30.setTransform(51.3,49.9,1,1,0,0,0,17.5,2.6);

	this.instance_31 = new lib.Grupodeclips0_31();
	this.instance_31.setTransform(51.7,50.3,1,1,0,0,0,17.4,2.3);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#606963").s().p("AgEAkQgkg0gGgUIBdAAQgRAzgUAWg");
	this.shape_122.setTransform(47.9,71.3);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#656C67").s().p("AgMAkQglg2gGgSIBvAAQgQAvgWAag");
	this.shape_123.setTransform(48,71.3);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#6A706A").s().p("AgTAkIgZglQgPgXgFgMICBAAQgPAqgYAfg");
	this.shape_124.setTransform(48.2,71.3);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#70736E").s().p("AgbAkQgog4gFgQICRAAQgHAVgNAVQgLAVgJAKg");
	this.shape_125.setTransform(48.4,71.3);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#757772").s().p("AgjAkQgpg7gFgNICjAAQgHASgOAXQgNAWgHAKg");
	this.shape_126.setTransform(48.7,71.3);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#7A7B76").s().p("AgrAkIgagkQgSgbgDgJIC0AAQgFAQgQAZQgNAWgIAKg");
	this.shape_127.setTransform(48.9,71.3);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#7F7F7A").s().p("AgyAkQgthAgDgIIDFAAQgEAOgRAaIgWAhg");
	this.shape_128.setTransform(49,71.3);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#84837E").s().p("Ag5AkIgbgkQgVgegCgGIDXAAQgEAMgTAcQgQAagGAHg");
	this.shape_129.setTransform(49.2,71.3);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#898883").s().p("AhBAkQgvg/gDgJIDnAAQgDAKgUAdQgRAbgGAHg");
	this.shape_130.setTransform(49.4,71.3);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#8E8C88").s().p("AhJAkQgwhBgDgHID5AAQgDAIgVAeQgSAdgFAGg");
	this.shape_131.setTransform(49.7,71.3);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#94918D").s().p("AhRAkQgyhDgCgFIEKAAQgCAJguBAg");
	this.shape_132.setTransform(49.9,71.3);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#999692").s().p("AhYAkIg1hIIEbAAQgCAGgvBCg");
	this.shape_133.setTransform(50,71.3);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#9F9C97").s().p("AhgAkIg2hIIEtAAIgzBIg");
	this.shape_134.setTransform(50.2,71.3);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#A5A19D").s().p("AhnAkIg3hIIE9AAIgzBIg");
	this.shape_135.setTransform(50.4,71.3);

	this.instance_32 = new lib.Grupodeclips0_32();
	this.instance_32.setTransform(51.4,68.7,1,1,0,0,0,18.8,17.9);

	this.instance_33 = new lib.Grupodeclips0_33();
	this.instance_33.setTransform(52.3,77.1,1,1,0,0,0,12.6,2.5);

	this.instance_34 = new lib.Grupodeclips0_34();
	this.instance_34.setTransform(51.9,15.1,1,1,0,0,0,6.5,27.4);

	this.instance_35 = new lib.Grupodeclips0_35();
	this.instance_35.setTransform(51.1,-34.5,1,1,0,0,0,46.4,46.4);

	this.instance_36 = new lib.Grupodeclips0_36();
	this.instance_36.setTransform(51.3,-20.8,1,1,0,0,0,46.8,62.6);

	this.addChild(this.instance_36,this.instance_35,this.instance_34,this.instance_33,this.instance_32,this.shape_135,this.shape_134,this.shape_133,this.shape_132,this.shape_131,this.shape_130,this.shape_129,this.shape_128,this.shape_127,this.shape_126,this.shape_125,this.shape_124,this.shape_123,this.shape_122,this.instance_31,this.instance_30,this.instance_29,this.instance_28,this.instance_27,this.instance_26,this.instance_25,this.instance_24,this.instance_23,this.instance_22,this.instance_21,this.instance_20,this.instance_19,this.instance_18,this.instance_17,this.instance_16,this.instance_15,this.instance_14,this.instance_13,this.instance_12,this.instance_11,this.instance_10,this.instance_9,this.instance_8,this.instance_7,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.shape_121,this.shape_120,this.shape_119,this.shape_118,this.shape_117,this.shape_116,this.shape_115,this.shape_114,this.shape_113,this.shape_112,this.shape_111,this.shape_110,this.shape_109,this.shape_108,this.shape_107,this.shape_106,this.shape_105,this.instance_1,this.shape_104,this.shape_103,this.shape_102,this.shape_101,this.shape_100,this.shape_99,this.shape_98,this.shape_97,this.shape_96,this.shape_95,this.shape_94,this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.instance,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-19.2,-83.3,133.4,163);


(lib.animacionLuz = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.instance = new lib.corriente();
	this.instance.setTransform(33.7,151.6);
	this.instance.shadow = new cjs.Shadow("#FF9900",0,0,6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({guide:{path:[33.7,151.5,23,151.5,12.3,151.5,12.3,96.5,12.3,41.4,25.7,14.2,39.1,-13,37.5,-15.3,36,-17.6,34.5,-15.3,33,-13.1,31.5,-15.3,30,-17.6,28.5,-15.3,27.1,-13.1,25.6,-15.3,24.1,-17.6,22.6,-15.3,21.2,-13.1,19.6,-15.3,18.1,-17.6,16.6,-15.3,15.2,-13.1,13.7,-15.3,12.2,-17.6,10.7,-15.3,9.3,-13.1,7.8,-15.3,6.3,-17.6,4.9,-15.3,3.5,-13.1,2,-15.3,0.5,-17.6,-0.9,-15.3,-2.3,-13.1,-3.8,-15.3,-5.3,-17.6,-6.8,-15.3,-8.2,-13.1,-9.7,-15.3,-11.2,-17.6,-12.7,-15.3,-14.1,-13.1,-15.6,-15.3,-17.1,-17.6,-18.6,-15.3,-20.1,-13.1,-21.6,-15.3,-23.1,-17.6,-24.6,-15.3,-26.1,-13.1,-27.6,-15.3,-29,-17.6,-30.5,-15.3,-31.9,-13.1,-18.6,14.1,-5.2,41.4,-5.2,113.2,-5.2,185,-5.2,187.2,-3.7,188.8,-2.3,190.4,-0.2,190.4,3.9,190.4,8.1,190.4]}},39).to({_off:true},1).wait(10));

	// Capa 1
	this.instance_1 = new lib.Grupodeclips0();
	this.instance_1.setTransform(31.9,80.2,1.945,1.945,0,0,0,3,11);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYgZQAGgoAPghIAfASQgSAggFAoQgGAwANAtIgXAOQgWg8AJhAg");
	this.shape.setTransform(-51.2,-31.9,1.945,1.945);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEFEFE").s().p("AgYgZQAFgmAQgkIAfASQgSAggGApQgEAxAMAtIgYAOQgWg7AKhCg");
	this.shape_1.setTransform(-51.1,-31.9,1.945,1.945);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDFEFE").s().p("AgZgaQAFgnARgkIAgATQgTAigFAoQgGAxAOAuIgYAPQgXg9AJhDg");
	this.shape_2.setTransform(-51.1,-31.9,1.945,1.945);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FDFDFD").s().p("AgagbQAGgoAQgjIAhATQgTAhgGAqQgFAzAOAtIgZAPQgXg9AJhFg");
	this.shape_3.setTransform(-51,-31.9,1.945,1.945);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FCFDFD").s().p("AgagaQAFgnARgmIAiATQgTAigGAqQgGAyAOAwIgZAOQgYg9AKhFg");
	this.shape_4.setTransform(-51,-31.9,1.945,1.945);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FBFCFC").s().p("AgagbQAGgqAQgkIAjAUQgUAjgGAqQgFAzAOAwIgaAPQgZhAALhFg");
	this.shape_5.setTransform(-51,-31.9,1.945,1.945);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FBFBFC").s().p("AgbgcQAGgoARgmIAjATQgUAmgGAoQgFA1APAwIgbAPQgZhAAKhHg");
	this.shape_6.setTransform(-51,-31.9,1.945,1.945);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FAFBFB").s().p("AgcgcQAGgqASglIAkAUQgVAkgGArQgFA1APAwIgbAPQgahCAKhGg");
	this.shape_7.setTransform(-50.9,-31.9,1.945,1.945);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FAFAFB").s().p("AgcgcQAGgsASglIAkAVQgUAlgGArQgGA0APAyIgbAQQgahBAKhJg");
	this.shape_8.setTransform(-50.9,-31.9,1.945,1.945);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F9FAFA").s().p("AgdgcQAGgrASgnIAmAUQgVAlgHAsQgFA3APAyIgcAPQgahDAKhIg");
	this.shape_9.setTransform(-50.8,-31.9,1.945,1.945);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F8F9FA").s().p("AgdgdQAGgsASgmIAmAUQgWAogFAqQgGA3AQAzIgcAPQgchCALhLg");
	this.shape_10.setTransform(-50.8,-31.9,1.945,1.945);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F8F9F9").s().p("AgegdQAGgtATgnIAnAVQgWAngHAsQgFA4AQAzIgdAQQgchDALhMg");
	this.shape_11.setTransform(-50.8,-31.9,1.945,1.945);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F7F9F9").s().p("AgegeQAGgrATgpIAnAVQgWAmgGAuQgGA3ARA1IgeAQQgchFALhMg");
	this.shape_12.setTransform(-50.7,-31.9,1.945,1.945);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#F7F8F9").s().p("AgfgeQAHguATgnIAoAVQgXAogGAtQgGA6ARAzIgeAQQgdhFALhNg");
	this.shape_13.setTransform(-50.7,-31.9,1.945,1.945);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F7F8F8").s().p("AgggeQAHguATgpIApAWQgXAogGAuQgGA5ARA1IgeARQgehHALhNg");
	this.shape_14.setTransform(-50.7,-31.9,1.945,1.945);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F6F7F8").s().p("AgggfQAGguAUgpIAqAWQgXApgHAtQgGA6ASA3IgfAQQgehIALhOg");
	this.shape_15.setTransform(-50.6,-31.9,1.945,1.945);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F6F7F7").s().p("AgggfQAGgvAUgpIArAWQgXAogIAwQgGA7ASA2IgfAQQgfhJAMhOg");
	this.shape_16.setTransform(-50.6,-31.9,1.945,1.945);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F5F6F7").s().p("AghggQAGguAVgrIArAXQgYApgHAwQgGA7ASA3IggARQgehJALhRg");
	this.shape_17.setTransform(-50.6,-31.9,1.945,1.945);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F5F6F7").s().p("AgiggQAHgwAVgqIAsAXQgZAqgGAwQgHA7ATA4IghARQgfhJALhSg");
	this.shape_18.setTransform(-50.5,-31.9,1.945,1.945);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F4F6F6").s().p("AgiggQAHgxAVgqIAsAXQgYApgHAxQgHA9AUA4IghARQghhKAMhSg");
	this.shape_19.setTransform(-50.5,-31.9,1.945,1.945);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F4F5F6").s().p("AgjghQAHgvAVgtIAuAYQgaArgGAwQgHA+AUA4IgiASQghhLAMhUg");
	this.shape_20.setTransform(-50.5,-31.9,1.945,1.945);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F3F5F6").s().p("AgjghQAHgzAVgqIAuAYQgZArgHAxQgHA+AUA6IgiARQghhNAMhTg");
	this.shape_21.setTransform(-50.4,-31.9,1.945,1.945);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#F3F5F5").s().p("AgkghQAIgyAVgsIAvAYQgZArgIAyQgHA+AVA7IgjARQgihMAMhVg");
	this.shape_22.setTransform(-50.4,-31.9,1.945,1.945);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#F3F4F5").s().p("AgkgiQAGgyAXgtIAvAZQgZAqgIA0QgHBAAVA6IgjASQgjhPANhVg");
	this.shape_23.setTransform(-50.4,-31.9,1.945,1.945);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#F2F4F5").s().p("AglgiQAIgzAWgtIAwAZQgaArgIA0QgHBAAWA7IgkASQgjhPAMhWg");
	this.shape_24.setTransform(-50.3,-32,1.945,1.945);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#F2F3F4").s().p("AglgjQAHgzAXgtIAxAYQgbAtgHA0QgIBAAWA8IgkASQgkhQANhXg");
	this.shape_25.setTransform(-50.3,-31.9,1.945,1.945);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#F1F3F4").s().p("AgmgjQAHg0AXguIAyAZQgbAsgHA2QgIBBAWA8IglATQgkhSANhXg");
	this.shape_26.setTransform(-50.2,-31.9,1.945,1.945);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#F1F3F4").s().p("AgmgjQAHg1AXguIAzAZQgbAtgIA1QgIBDAXA9IgmASQgkhQANhag");
	this.shape_27.setTransform(-50.2,-32,1.945,1.945);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#F1F2F3").s().p("AgngkQAHg0AYgvIAzAZQgcAugHA1QgIBCAXA/IgmASQglhSANhag");
	this.shape_28.setTransform(-50.2,-31.9,1.945,1.945);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#F0F2F3").s().p("AgogkQAJg3AXguIA0AaQgcAvgIA1QgIBDAXA/IgmATQglhTAMhbg");
	this.shape_29.setTransform(-50.2,-31.9,1.945,1.945);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#F0F2F3").s().p("AgoglQAHg0AZgxIA1AaQgdAtgIA4QgIBFAYA+IgnATQgmhUANhcg");
	this.shape_30.setTransform(-50.1,-32,1.945,1.945);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#EFF1F3").s().p("AgpglQAIg3AYgvIA2AaQgdAvgIA3QgIBFAYA/IgnATQgnhVANhcg");
	this.shape_31.setTransform(-50.1,-31.9,1.945,1.945);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#EFF1F2").s().p("AgpglQAIg4AYgwIA2AbQgdAwgIA3QgIBEAZBBIgoAUQgohVAOheg");
	this.shape_32.setTransform(-50.1,-31.9,1.945,1.945);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#EEF1F2").s().p("AgpgmQAHg2AZgyIA3AbQgdAvgIA5QgJBHAZBAIgoATQgohXAOheg");
	this.shape_33.setTransform(-50,-32,1.945,1.945);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#EEF0F2").s().p("AgqgmQAIg4AZgxIA4AbQgeAwgIA5QgJBGAaBCIgpAUQgphYAOhfg");
	this.shape_34.setTransform(-50,-32,1.945,1.945);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#EEF0F1").s().p("AgrgmQAIg6AagxIA4AcQgeAwgIA6QgJBGAaBDIgqAUQgphZAOhfg");
	this.shape_35.setTransform(-50,-31.9,1.945,1.945);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#EDF0F1").s().p("AgrgnQAIg4AagzIA5AcQgeAwgJA6QgJBIAbBEIgqATQgqhXAOhjg");
	this.shape_36.setTransform(-49.9,-32,1.945,1.945);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#EDEFF1").s().p("AgsgnQAJg7AZgyIA6AdQgfAwgIA7QgJBJAbBDIgrAUQgqhZAOhig");
	this.shape_37.setTransform(-49.8,-32,1.945,1.945);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#ECEFF1").s().p("AgsgoQAIg6AagzIA7AdQggAxgIA7QgJBJAbBEIgrAVQgqhbAOhjg");
	this.shape_38.setTransform(-49.8,-31.9,1.945,1.945);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#ECEFF0").s().p("AgtgoQAIg5Abg1IA7AdQggAygIA7QgJBJAbBGIgrAUQgrhaAOhlg");
	this.shape_39.setTransform(-49.8,-32,1.945,1.945);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#ECEEF0").s().p("AgugoQAJg8AbgzIA8AdQggAygJA8QgJBLAcBFIgsAVQgshdAOhkg");
	this.shape_40.setTransform(-49.8,-32,1.945,1.945);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#EBEEF0").s().p("AgugpQAIg6Acg2IA9AdQggAzgJA9QgKBKAdBHIgtAVQgshdAOhmg");
	this.shape_41.setTransform(-49.7,-31.9,1.945,1.945);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#EBEEEF").s().p("AgugpQAIg7Acg2IA9AeQghA0gIA8QgKBLAdBIIgtAUQgtheAPhmg");
	this.shape_42.setTransform(-49.7,-32,1.945,1.945);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#EAEDEF").s().p("AgvgpQAJg+Abg1IA/AfQghAygJA/QgKBMAdBIIguAUQgtheAPhng");
	this.shape_43.setTransform(-49.7,-32,1.945,1.945);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#EAEDEF").s().p("AgvgqQAIg8Acg3IA/AeQghA0gJA/QgKBMAeBJIgvAVQguhhAQhng");
	this.shape_44.setTransform(-49.6,-31.9,1.945,1.945);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#EAEDEF").s().p("AgwgqQAJg/Acg1IBAAeQgiAzgJBAQgKBNAeBKIgvAVQguhgAPhpg");
	this.shape_45.setTransform(-49.6,-32,1.945,1.945);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#E9EDEE").s().p("AgxgqQAJg/Adg2IBAAeQgiA1gJA/QgKBOAeBKIgvAWQgvhhAPhqg");
	this.shape_46.setTransform(-49.6,-32,1.945,1.945);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#E9ECEE").s().p("AgxgrQAIg9Aeg4IBBAeQgiA1gJBAQgLBPAfBKIgwAWQgvhiAPhrg");
	this.shape_47.setTransform(-49.6,-32,1.945,1.945);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#E9ECEE").s().p("AgygrQAJhAAdg3IBCAfQgiA1gKBBQgKBQAfBKIgwAWQgwhiAPhsg");
	this.shape_48.setTransform(-49.5,-32,1.945,1.945);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#E8ECEE").s().p("AgygrQAIg/Aeg6IBDAgQgjA2gJBBQgLBQAgBMIgxAVQgxhjAQhsg");
	this.shape_49.setTransform(-49.5,-32,1.945,1.945);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#E8EBED").s().p("AgzgsQAJg/Aeg6IBEAgQgkA2gJBCQgLBRAgBMIgxAWQgxhkAPhug");
	this.shape_50.setTransform(-49.4,-32,1.945,1.945);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#E7EBED").s().p("AgzgsQAJhBAeg5IBEAgQgjA3gKBCQgLBRAhBNIgyAWQgyhlAQhug");
	this.shape_51.setTransform(-49.4,-32,1.945,1.945);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgFAHQgYgOgdgFIAKgiQAlAHAbAXQAdAVAOAgIgfAKQgMgYgVgQg");
	this.shape_52.setTransform(33.6,-71.7,1.945,1.945);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FEFEFE").s().p("AgGAIQgYgQgegFIAKgjQAmAIAdAYQAdAVAPAiIggAKQgNgZgWgQg");
	this.shape_53.setTransform(33.6,-71.6,1.945,1.945);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FDFEFE").s().p("AgGAIQgZgQgfgFIAKglQAoAIAdAZQAfAWAPAjIghALQgNgagXgRg");
	this.shape_54.setTransform(33.6,-71.6,1.945,1.945);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FDFDFD").s().p("AgGAIQgagQgggGIAKgmQApAJAfAZQAgAYAPAkIgiALQgOgbgXgSg");
	this.shape_55.setTransform(33.6,-71.5,1.945,1.945);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FCFDFD").s().p("AgGAIQgbgRghgGIAKgnQArAIAfAbQAhAZAQAlIgjAMQgOgcgYgTg");
	this.shape_56.setTransform(33.6,-71.4,1.945,1.945);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FBFCFC").s().p("AgHAJQgbgSgigGIALgpQArAJAhAbQAiAaAQAnIgkAMQgPgdgZgTg");
	this.shape_57.setTransform(33.6,-71.4,1.945,1.945);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FBFBFC").s().p("AgHAJQgcgSgjgGIALgrQAtAJAhAcQAjAbARApIglAMQgPgegagUg");
	this.shape_58.setTransform(33.6,-71.3,1.945,1.945);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FAFBFB").s().p("AgHAJQgdgTglgGIAMgsQAuAKAjAdQAkAbARAqIgmANQgPgfgbgVg");
	this.shape_59.setTransform(33.5,-71.3,1.945,1.945);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FAFAFB").s().p("AgIAJQgdgTglgHIALgtQAxAKAjAeQAlAcASArIgoAOQgQgggcgWg");
	this.shape_60.setTransform(33.5,-71.2,1.945,1.945);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#F9FAFA").s().p("AgIAKQgfgVglgGIAMguQAxAJAkAfQAmAdATAtIgpANQgQgggdgWg");
	this.shape_61.setTransform(33.5,-71.2,1.945,1.945);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#F8F9FA").s().p("AgIAKQgggWgngGIANgvQAzAJAlAhQAnAdASAuIgpAPQgRgigdgXg");
	this.shape_62.setTransform(33.5,-71.1,1.945,1.945);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#F8F9F9").s().p("AgIALQgggWgpgIIANgwQA0AKAmAhQApAfATAvIgrAOQgRgigegXg");
	this.shape_63.setTransform(33.5,-71.1,1.945,1.945);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#F7F9F9").s().p("AgJALQghgXgpgHIANgyQA1ALAoAiQApAgAUAwIgsAOQgSgjgfgYg");
	this.shape_64.setTransform(33.5,-71,1.945,1.945);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#F7F8F9").s().p("AgJALQgigXgqgIIAOgzQA2ALAoAjQAqAgAVAyIgtAPQgSgkgggZg");
	this.shape_65.setTransform(33.5,-70.9,1.945,1.945);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#F7F8F8").s().p("AgJALQgjgYgrgHIAOg1QA3ALAqAkQArAiAVAyIguAQQgTgmgggZg");
	this.shape_66.setTransform(33.5,-70.9,1.945,1.945);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#F6F7F8").s().p("AgJAMQgkgZgsgIIAOg2QA5ALAqAlQAtAjAVA0IguAQQgUgmghgag");
	this.shape_67.setTransform(33.4,-70.8,1.945,1.945);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#F6F7F7").s().p("AgKAMQgkgZgtgIIAOg4QA7AMAsAmQAtAjAVA2IgvAQQgVgogigag");
	this.shape_68.setTransform(33.4,-70.8,1.945,1.945);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#F5F6F7").s().p("AgKAMQglgagugIIAPg5QA7AMAtAnQAuAkAWA3IgwARQgVgpgjgbg");
	this.shape_69.setTransform(33.4,-70.7,1.945,1.945);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#F5F6F7").s().p("AgKAMQgmgagvgIIAPg7QA9ANAuAnQAuAlAXA4IgyASQgUgpgkgdg");
	this.shape_70.setTransform(33.4,-70.6,1.945,1.945);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#F4F6F6").s().p("AgKAMQgngbgwgIIAPg8QA/ANAuAoQAwAmAXA6IgzASQgVgrgkgdg");
	this.shape_71.setTransform(33.4,-70.5,1.945,1.945);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#F4F5F6").s().p("AgKANQgogcgxgIIAPg+QBAANAvAqQAxAnAYA7Ig0ASQgVgsglgdg");
	this.shape_72.setTransform(33.4,-70.5,1.945,1.945);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#F3F5F6").s().p("AgLANQgogcgygJIAQg/QBAAOAxAqQAyAoAYA8Ig1ATQgWgtgmgeg");
	this.shape_73.setTransform(33.4,-70.4,1.945,1.945);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#F3F5F5").s().p("AgLAOQgpgegzgJIAQhAQBCAOAyArQAzApAYA9Ig2ATQgWgtgngeg");
	this.shape_74.setTransform(33.4,-70.4,1.945,1.945);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#F3F4F5").s().p("AgLAOQgrgeg0gJIARhBQBEAOAyAsQA0AqAZA+Ig2ATQgYgugngfg");
	this.shape_75.setTransform(33.3,-70.3,1.945,1.945);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#F2F4F5").s().p("AgLAOQgsgeg0gKIARhCQBEAOA0AtQA1AqAZBAIg3AUQgYgvgoggg");
	this.shape_76.setTransform(33.3,-70.2,1.945,1.945);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#F2F3F4").s().p("AgLAPQgtggg1gJIARhEQBFAOA2AuQA2AsAZBBIg5AUQgYgwgoggg");
	this.shape_77.setTransform(33.3,-70.2,1.945,1.945);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#F1F3F4").s().p("AgMAPQgsggg4gKIAShFQBIAPA1AvQA3AsAbBDIg6AUQgZgxgqghg");
	this.shape_78.setTransform(33.3,-70.1,1.945,1.945);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#F1F3F4").s().p("AgMAPQgughg4gJIAShHQBJAPA3AwQA4AtAbBEIg7AVQgZgygrgig");
	this.shape_79.setTransform(33.3,-70.1,1.945,1.945);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#F1F2F3").s().p("AgMAPQgvghg5gKIAShIQBKAPA4AxQA5AuAcBFIg9AWQgZgzgrgjg");
	this.shape_80.setTransform(33.3,-70,1.945,1.945);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#F0F2F3").s().p("AgNAPQgvghg6gLIAThJQBLAQA5AxQA6AwAcBHIg+AVQgZg0gtgkg");
	this.shape_81.setTransform(33.3,-70,1.945,1.945);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#F0F2F3").s().p("AgNAQQgwgig7gLIAThLQBMAQA6AzQA7AwAdBHIg/AXQgZg2gugjg");
	this.shape_82.setTransform(33.2,-69.9,1.945,1.945);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#EFF1F3").s().p("AgNAQQgxgjg8gLIAThMQBOAQA7A0QA8AxAdBJIhAAXQgag2guglg");
	this.shape_83.setTransform(33.3,-69.8,1.945,1.945);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#EFF1F2").s().p("AgOAQQgxgjg9gLIAThOQBPARA8A0QA9AyAeBLIhBAXQgbg3gvgmg");
	this.shape_84.setTransform(33.3,-69.7,1.945,1.945);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#EEF1F2").s().p("AgOARQgyglg+gLIAThOQBRAQA9A2QA+AyAeBMIhCAXQgbg3gwgmg");
	this.shape_85.setTransform(33.3,-69.7,1.945,1.945);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#EEF0F2").s().p("AgOARQgzglhAgLIAVhQQBSARA+A2QA/A0AeBNIhCAYQgdg6gwgmg");
	this.shape_86.setTransform(33.2,-69.7,1.945,1.945);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#EEF0F1").s().p("AgOASQg0gmhAgMIAUhRQBTARA/A3QBBA1AeBOIhDAYQgdg5gxgng");
	this.shape_87.setTransform(33.2,-69.6,1.945,1.945);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#EDF0F1").s().p("AgOASQg2gnhAgLIAUhTQBUARBBA5QBBA1AfBQIhEAYQgdg6gygog");
	this.shape_88.setTransform(33.2,-69.6,1.945,1.945);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#EDEFF1").s().p("AgOASQg3gnhCgMIAWhUQBVASBBA5QBCA2AhBRIhGAZQgeg8gygog");
	this.shape_89.setTransform(33.2,-69.5,1.945,1.945);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#ECEFF1").s().p("AgPATQg3gohDgMIAWhWQBXASBCA6QBDA4AhBSIhIAZQgdg8g0gpg");
	this.shape_90.setTransform(33.2,-69.5,1.945,1.945);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#ECEFF0").s().p("AgPASQg4gohEgMIAWhXQBYASBDA7QBFA5AhBTIhJAaQgeg+g0gqg");
	this.shape_91.setTransform(33.2,-69.4,1.945,1.945);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#ECEEF0").s().p("AgPATQg5gphFgNIAWhYQBaASBEA8QBFA6AiBVIhKAaQgeg/g1gqg");
	this.shape_92.setTransform(33.2,-69.3,1.945,1.945);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#EBEEF0").s().p("AgQATQg5gqhGgMIAWhaQBbATBFA9QBHA6AiBWIhLAbQgfhAg2grg");
	this.shape_93.setTransform(33.2,-69.2,1.945,1.945);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#EBEEEF").s().p("AgQATQg5gqhIgNIAXhbQBcATBHA+QBGA7AjBYIhLAbQgghBg3gsg");
	this.shape_94.setTransform(33.1,-69.2,1.945,1.945);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#EAEDEF").s().p("AgQAUQg7gshIgNIAXhcQBdAUBIA+QBIA8AjBaIhMAbQgghBg4gtg");
	this.shape_95.setTransform(33.1,-69.1,1.945,1.945);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#EAEDEF").s().p("AgQAUQg8gshJgNIAYheQBeAUBJBAQBJA9AjBaIhOAcQgghDg4gtg");
	this.shape_96.setTransform(33.1,-69.1,1.945,1.945);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#EAEDEF").s().p("AgRAUQg8gshKgNIAYhgQBgAVBJBAQBKA+AkBcIhOAcQghhEg6gug");
	this.shape_97.setTransform(33.1,-69,1.945,1.945);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#E9EDEE").s().p("AgRAVQg9guhLgNIAYhhQBhAVBKBBQBMBAAkBcIhPAdQgihFg6gug");
	this.shape_98.setTransform(33.1,-68.9,1.945,1.945);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#E9ECEE").s().p("AgRAVQg+gthMgPIAYhiQBjAWBLBCQBNBAAkBeIhQAdQgihGg7gvg");
	this.shape_99.setTransform(33.1,-68.9,1.945,1.945);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#E9ECEE").s().p("AgSAWQg+gvhNgOIAYhjQBkAVBMBDQBOBBAlBfIhSAeQgihHg8gvg");
	this.shape_100.setTransform(33.1,-68.8,1.945,1.945);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#E8ECEE").s().p("AgSAVQg/gvhOgOIAYhkQBmAVBNBEQBPBCAlBgIhTAeQgihHg9gxg");
	this.shape_101.setTransform(33,-68.8,1.945,1.945);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#E8EBED").s().p("AgSAWQhAgwhQgOIAahmQBmAVBPBFQBQBDAmBiIhVAeQgjhIg9gxg");
	this.shape_102.setTransform(33,-68.7,1.945,1.945);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#E7EBED").s().p("AgSAWQhBgxhRgOIAahnQBoAVBQBGQBQBEAnBjIhWAfQgjhKg+gxg");
	this.shape_103.setTransform(33,-68.6,1.945,1.945);

	this.instance_2 = new lib.Grupodeclips0_1();
	this.instance_2.setTransform(3.3,13.6,1.945,1.945,0,0,0,5,1);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#D47C3C").ss(1,0,1).p("AAuQRIhUAAQgVAAgOgQQgPgQAAgWIAA2cIkLoiIAdgtIAdAtIAegtIAeAtIAegtIAeAtIAdgtIAeAtIAdgtIAeAtIAdgtIAeAtIAcgtIAeAtIAdgtIAeAtIAdgtIAfAtIAdgtIAeAtIAdgtIAeAtIAegtIAfAuIkMIhIAARNIDWAA");
	this.shape_104.setTransform(3.5,86.4);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().s("#7B7C77").ss(0.6,0,0,3.9).p("AgZBFIhBiJAAaBFIBBiJ");
	this.shape_105.setTransform(3.5,-0.1,1.945,1.945);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#5B6C6E").ss(0.2,0,0,3.9).p("AC4iuQACAAAAApQAAAHgQAFQgLADAAALQAAAKAJAEQASACAAAIQABAHgRAEQgLAEAAALQAAAKAJAEQASACAAAIQABAHgRAEQgLAEAAALQAAAHAJAEQASAEAAAGQAAAIgQAEQgLADAAAMQAAAJAJAEQASADAAAHQAAAEgGAEIADAAIg0BKIgDAAIghAuIitAAIgiguIgDAAIg3hKIAEgCQAKgEAAgKQAAgKgLgEQgPgDgBgHQAAgHARgFQAKgEAAgKQAAgIgLgEQgPgDgBgHQAAgHARgEQAKgEAAgKQAAgLgLgEQgPgDgBgGQAAgIARgEQAKgEAAgKQAAgLgLgEQgPgCgBgHIAAg4QAAgGgDgFQgEgHgGgBIGJgBQgFABgEAGQgDAFgBAFg");
	this.shape_106.setTransform(3,154,1.945,1.945);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#606963").s().p("AgEAkQgkg0gGgUIBdAAQgRAzgUAWg");
	this.shape_107.setTransform(-4.2,175.4,1.945,1.945);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#656C67").s().p("AgMAkQglg2gGgSIBvAAQgQAvgWAag");
	this.shape_108.setTransform(-3.9,175.4,1.945,1.945);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#6A706A").s().p("AgTAkIgZglQgPgXgFgMICBAAQgPAqgYAfg");
	this.shape_109.setTransform(-3.5,175.4,1.945,1.945);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#70736E").s().p("AgbAkQgog4gFgQICRAAQgHAVgNAVQgLAVgJAKg");
	this.shape_110.setTransform(-3.1,175.3,1.945,1.945);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#757772").s().p("AgjAkQgpg7gFgNICjAAQgHASgOAXQgNAWgHAKg");
	this.shape_111.setTransform(-2.6,175.3,1.945,1.945);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#7A7B76").s().p("AgrAkIgagkQgSgbgDgJIC0AAQgFAQgQAZQgNAWgIAKg");
	this.shape_112.setTransform(-2.3,175.3,1.945,1.945);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#7F7F7A").s().p("AgyAkQgthAgDgIIDFAAQgEAOgRAaIgWAhg");
	this.shape_113.setTransform(-1.9,175.3,1.945,1.945);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#84837E").s().p("Ag5AkIgbgkQgVgegCgGIDXAAQgEAMgTAcQgQAagGAHg");
	this.shape_114.setTransform(-1.5,175.3,1.945,1.945);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#898883").s().p("AhBAkQgvg/gDgJIDnAAQgDAKgUAdQgRAbgGAHg");
	this.shape_115.setTransform(-1.1,175.3,1.945,1.945);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#8E8C88").s().p("AhJAkQgwhBgDgHID5AAQgDAIgVAeQgSAdgFAGg");
	this.shape_116.setTransform(-0.7,175.3,1.945,1.945);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#94918D").s().p("AhRAkQgyhDgCgFIEKAAQgCAJguBAg");
	this.shape_117.setTransform(-0.3,175.3,1.945,1.945);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#999692").s().p("AhYAkIg1hIIEbAAQgCAGgvBCg");
	this.shape_118.setTransform(0,175.2,1.945,1.945);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#9F9C97").s().p("AhgAkIg2hIIEtAAIgzBIg");
	this.shape_119.setTransform(0.3,175.2,1.945,1.945);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#A5A19D").s().p("AhnAkIg3hIIE9AAIgzBIg");
	this.shape_120.setTransform(0.7,175.2,1.945,1.945);

	this.instance_3 = new lib.Grupodeclips0_2();
	this.instance_3.setTransform(21,128.2,1.945,1.945,0,0,0,6.9,0.8);

	this.instance_4 = new lib.Grupodeclips0_3();
	this.instance_4.setTransform(3.1,125.1,1.945,1.945,0,0,0,19.9,4.4);

	this.instance_5 = new lib.Grupodeclips0_4();
	this.instance_5.setTransform(21,166.8,1.945,1.945,0,0,0,6.9,0.7);

	this.instance_6 = new lib.Grupodeclips0_5();
	this.instance_6.setTransform(4.5,166.3,1.945,1.945,0,0,0,18.1,1);

	this.instance_7 = new lib.Grupodeclips0_6();
	this.instance_7.setTransform(21,157.3,1.945,1.945,0,0,0,6.9,0.8);

	this.instance_8 = new lib.Grupodeclips0_7();
	this.instance_8.setTransform(3.3,162.8,1.945,1.945,0,0,0,17.2,2.6);

	this.instance_9 = new lib.Grupodeclips0_8();
	this.instance_9.setTransform(3.1,162.8,1.945,1.945,0,0,0,17.1,2.6);

	this.instance_10 = new lib.Grupodeclips0_9();
	this.instance_10.setTransform(3.1,162.8,1.945,1.945,0,0,0,17.1,2.6);

	this.instance_11 = new lib.Grupodeclips0_10();
	this.instance_11.setTransform(2.2,162.8,1.945,1.945,0,0,0,17.4,2.6);

	this.instance_12 = new lib.Grupodeclips0_11();
	this.instance_12.setTransform(3,163.4,1.945,1.945,0,0,0,17.3,2.3);

	this.instance_13 = new lib.Grupodeclips0_12();
	this.instance_13.setTransform(3.3,158.7,1.945,1.945,0,0,0,18.9,2);

	this.instance_14 = new lib.Grupodeclips0_13();
	this.instance_14.setTransform(21,147.5,1.945,1.945,0,0,0,6.9,0.7);

	this.instance_15 = new lib.Grupodeclips0_14();
	this.instance_15.setTransform(3.3,153.1,1.945,1.945,0,0,0,17.2,2.6);

	this.instance_16 = new lib.Grupodeclips0_15();
	this.instance_16.setTransform(3.1,153.1,1.945,1.945,0,0,0,17.1,2.6);

	this.instance_17 = new lib.Grupodeclips0_16();
	this.instance_17.setTransform(3.1,153.1,1.945,1.945,0,0,0,17.1,2.6);

	this.instance_18 = new lib.Grupodeclips0_17();
	this.instance_18.setTransform(2.2,153.1,1.945,1.945,0,0,0,17.4,2.6);

	this.instance_19 = new lib.Grupodeclips0_18();
	this.instance_19.setTransform(3,153.8,1.945,1.945,0,0,0,17.3,2.3);

	this.instance_20 = new lib.Grupodeclips0_19();
	this.instance_20.setTransform(3.3,149,1.945,1.945,0,0,0,18.9,2);

	this.instance_21 = new lib.Grupodeclips0_20();
	this.instance_21.setTransform(21,137.9,1.945,1.945,0,0,0,6.9,0.8);

	this.instance_22 = new lib.Grupodeclips0_21();
	this.instance_22.setTransform(3.3,143.4,1.945,1.945,0,0,0,17.2,2.6);

	this.instance_23 = new lib.Grupodeclips0_22();
	this.instance_23.setTransform(3.1,143.4,1.945,1.945,0,0,0,17.1,2.6);

	this.instance_24 = new lib.Grupodeclips0_23();
	this.instance_24.setTransform(3.1,143.4,1.945,1.945,0,0,0,17.1,2.6);

	this.instance_25 = new lib.Grupodeclips0_24();
	this.instance_25.setTransform(2.2,143.4,1.945,1.945,0,0,0,17.4,2.6);

	this.instance_26 = new lib.Grupodeclips0_25();
	this.instance_26.setTransform(3,144,1.945,1.945,0,0,0,17.3,2.3);

	this.instance_27 = new lib.Grupodeclips0_26();
	this.instance_27.setTransform(3.3,139.3,1.945,1.945,0,0,0,18.9,2);

	this.instance_28 = new lib.Grupodeclips0_27();
	this.instance_28.setTransform(3.3,133.8,1.945,1.945,0,0,0,17.2,2.6);

	this.instance_29 = new lib.Grupodeclips0_28();
	this.instance_29.setTransform(3.1,133.8,1.945,1.945,0,0,0,17.1,2.6);

	this.instance_30 = new lib.Grupodeclips0_29();
	this.instance_30.setTransform(3.1,133.8,1.945,1.945,0,0,0,17.1,2.6);

	this.instance_31 = new lib.Grupodeclips0_30();
	this.instance_31.setTransform(2.2,133.8,1.945,1.945,0,0,0,17.4,2.6);

	this.instance_32 = new lib.Grupodeclips0_31();
	this.instance_32.setTransform(3,134.4,1.945,1.945,0,0,0,17.3,2.3);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#606963").s().p("AgEAkQgkg0gGgUIBdAAQgRAzgUAWg");
	this.shape_121.setTransform(-4.2,175.4,1.945,1.945);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#656C67").s().p("AgMAkQglg2gGgSIBvAAQgQAvgWAag");
	this.shape_122.setTransform(-3.9,175.4,1.945,1.945);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#6A706A").s().p("AgTAkIgZglQgPgXgFgMICBAAQgPAqgYAfg");
	this.shape_123.setTransform(-3.5,175.4,1.945,1.945);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#70736E").s().p("AgbAkQgog4gFgQICRAAQgHAVgNAVQgLAVgJAKg");
	this.shape_124.setTransform(-3.1,175.3,1.945,1.945);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#757772").s().p("AgjAkQgpg7gFgNICjAAQgHASgOAXQgNAWgHAKg");
	this.shape_125.setTransform(-2.6,175.3,1.945,1.945);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#7A7B76").s().p("AgrAkIgagkQgSgbgDgJIC0AAQgFAQgQAZQgNAWgIAKg");
	this.shape_126.setTransform(-2.3,175.3,1.945,1.945);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#7F7F7A").s().p("AgyAkQgthAgDgIIDFAAQgEAOgRAaIgWAhg");
	this.shape_127.setTransform(-1.9,175.3,1.945,1.945);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#84837E").s().p("Ag5AkIgbgkQgVgegCgGIDXAAQgEAMgTAcQgQAagGAHg");
	this.shape_128.setTransform(-1.5,175.3,1.945,1.945);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#898883").s().p("AhBAkQgvg/gDgJIDnAAQgDAKgUAdQgRAbgGAHg");
	this.shape_129.setTransform(-1.1,175.3,1.945,1.945);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#8E8C88").s().p("AhJAkQgwhBgDgHID5AAQgDAIgVAeQgSAdgFAGg");
	this.shape_130.setTransform(-0.7,175.3,1.945,1.945);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#94918D").s().p("AhRAkQgyhDgCgFIEKAAQgCAJguBAg");
	this.shape_131.setTransform(-0.3,175.3,1.945,1.945);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#999692").s().p("AhYAkIg1hIIEbAAQgCAGgvBCg");
	this.shape_132.setTransform(0,175.2,1.945,1.945);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#9F9C97").s().p("AhgAkIg2hIIEtAAIgzBIg");
	this.shape_133.setTransform(0.3,175.2,1.945,1.945);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#A5A19D").s().p("AhnAkIg3hIIE9AAIgzBIg");
	this.shape_134.setTransform(0.7,175.2,1.945,1.945);

	this.instance_33 = new lib.Grupodeclips0_32();
	this.instance_33.setTransform(2.6,170.3,1.945,1.945,0,0,0,18.9,17.9);

	this.instance_34 = new lib.Grupodeclips0_33();
	this.instance_34.setTransform(4.5,186.6,1.945,1.945,0,0,0,12.6,2.5);

	this.instance_35 = new lib.Grupodeclips0_34();
	this.instance_35.setTransform(3.4,66.1,1.945,1.945,0,0,0,6.5,27.4);

	this.instance_36 = new lib.Grupodeclips0_35();
	this.instance_36.setTransform(2.1,-30.6,1.945,1.945,0,0,0,46.4,46.4);

	this.instance_37 = new lib.Grupodeclips0_36();
	this.instance_37.setTransform(2.2,-3.8,1.945,1.945,0,0,0,46.7,62.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.instance_2},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_1}]}).wait(50));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88.2,-125.4,181.4,317);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '400px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}