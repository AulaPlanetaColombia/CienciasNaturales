window.onresize = resize;
var scale 	= 1;
var iniciat;

var showingLines = false;
var inverted = false;
var spires = 1;
var activateLight = false;
var lightFactor = 1;

$(document).ready(function(){
	resize();
	initialize();
});

function resize(){
	var scaleh = $(window).height() / 608;
	var scalew = $(window).width() / 950;
	
	var margLeft = 0;
	var margTop = 0; 
	if(scaleh<scalew){
		scale = scaleh;
		margLeft = $(window).width()/2-(950/2)*scale;
		margTop = 0;
	}else{
		scale = scalew;
		margTop = $(window).height()/2-(608/2)*scale;
		margLeft = 0;
	}
	
	$('.plantilla').css('transform', 'scale(' + scale + ')');
	$('.plantilla').css('marginLeft', margLeft+'px');
	$('.plantilla').css('marginTop', margTop+'px');
}

function restart(){
	
}

var prevTime = 0;
var prevPos = 0;
var direction = "left";
function initialize(){
	iniciat = false;
	showingLines = false;
	inverted = false;
	spires = 1;

	$("#magnet").draggable({
		scroll: false,
		drag: function(evt,ui){
			// zoom fix
			ui.position.top = Math.round(ui.position.top / scale);
			ui.position.left = Math.round(ui.position.left / scale);

			if(ui.position.top < 0){
				ui.position.top = 0;
			}
			if(ui.position.top > 520){
				ui.position.top = 520;
			}
			if(ui.position.left < 0){
				ui.position.left = 0;
			}
			if(ui.position.left > 830){
				ui.position.left = 830;
			}

			var posL = ui.position.left;
			var posT = ui.position.top;
			$("#fieldLines").css("left",(posL-295)+"px");
			$("#fieldLines").css("top",(posT-223)+"px");

			fixMagnetPosition(ui,posL,posT);
			if(activateLight){
				showLight((evt.timeStamp - prevTime),(ui.position.left - prevPos));
			}else{
				showMinLight((evt.timeStamp - prevTime),(ui.position.left - prevPos));
			}
			prevTime = evt.timeStamp;

			if(ui.position.left < prevPos){
				direction = "left";
			}else{
				direction = "right";
			}

			prevPos = ui.position.left;

		}
	});
	$("#magnet").css('-ms-touch-action', 'none');
	
	$("#light").velocity({
		scale: 0
	},{
		duration: 0
	});
}

function showLight(time,posDif){
	if(time!=0){
		var speed = Math.abs(posDif)/time;
		var rotateSpeed = 200 - 200*speed;
		
		if(rotateSpeed < 0){
			rotateSpeed = 0;
		}
		var angleRotate = 0;
		var lightScale = 1*speed/lightFactor;
		$("#light").velocity("stop");
		$("#light").velocity({
			scale: lightScale
		},{
			duration: 50,
			complete: function(element){
				$("#light").velocity({
					scale: 0
				},{
					duration: 100
				});
			}
		});
		
		$("#needle").velocity("stop");
		if(direction == "left"){
			if(!inverted) {
				angleRotate = 90 * speed / lightFactor;
				if (angleRotate > 90) {
					angleRotate = 90;
				}
			}else{
				angleRotate = -90 * speed / lightFactor;
				if (angleRotate < -90) {
					angleRotate = -90;
				}
			}
			$("#needle").velocity({
				rotateZ: angleRotate+"deg"
			},{
				duration: 50,
				complete: function(element){
					$("#needle").velocity({
						rotateZ: "0deg"
					},{
						duration: 200
					});
				}
			});
		}else{
			if(!inverted) {
				angleRotate = -90 * speed / lightFactor;
				if (angleRotate < -90) {
					angleRotate = -90;
				}
			}else{
				angleRotate = 90 * speed / lightFactor;
				if (angleRotate > 90) {
					angleRotate = 90;
				}
			}
			$("#needle").velocity({
				rotateZ: angleRotate+"deg"
			},{
				duration: 50,
				complete: function(element){
					$("#needle").velocity({
						rotateZ: "0deg"
					},{
						duration: 200
					});
				}
			});
		}
	}
}

function showMinLight(time,posDif){
	if(time!=0){
		var speed = Math.abs(posDif)/time/25;
		var rotateSpeed = 200 - 200*speed;
		
		if(rotateSpeed < 0){
			rotateSpeed = 0;
		}
		var angleRotate = 0;
		var lightScale = 1*speed/lightFactor;
		$("#light").velocity("stop");
		$("#light").velocity({
			scale: lightScale
		},{
			duration: 50,
			complete: function(element){
				$("#light").velocity({
					scale: 0
				},{
					duration: 100
				});
			}
		});
		
		$("#needle").velocity("stop");
		if(direction == "left"){
			if(!inverted) {
				angleRotate = 90 * speed / lightFactor;
				if (angleRotate > 90) {
					angleRotate = 90;
				}
			}else{
				angleRotate = -90 * speed / lightFactor;
				if (angleRotate < -90) {
					angleRotate = -90;
				}
			}
			$("#needle").velocity({
				rotateZ: angleRotate+"deg"
			},{
				duration: 50,
				complete: function(element){
					$("#needle").velocity({
						rotateZ: "0deg"
					},{
						duration: 200
					});
				}
			});
		}else{
			if(!inverted) {
				angleRotate = -90 * speed / lightFactor;
				if (angleRotate < -90) {
					angleRotate = -90;
				}
			}else{
				angleRotate = 90 * speed / lightFactor;
				if (angleRotate > 90) {
					angleRotate = 90;
				}
			}
			$("#needle").velocity({
				rotateZ: angleRotate+"deg"
			},{
				duration: 50,
				complete: function(element){
					$("#needle").velocity({
						rotateZ: "0deg"
					},{
						duration: 200
					});
				}
			});
		}
	}
}

function fixMagnetPosition(ui,posL,posT) {
	var newPosL = posL;
	var newPosT = posT;
	if((posL+120)>280 && posL < 280) {
		if(posT>318 && posT<362){
			newPosL = 280-120;
		}
		if(posT>398 && posT<437){
			newPosL = 280-120;
		}
	}
	if((posL+120)>365 && posL < 365) {
		if(posT>315 && posT<362){
			newPosL = 365;
		}
		if(posT>398 && posT<437){
			newPosL = 365;
		}
	}
	if(spires == 2){
		if((posL+120)>284 && posL < 284) {
			if(posT>90 && posT<130){
				newPosL = 284-120;
			}
			if(posT>169 && posT<208){
				newPosL = 284-120;
			}
		}
		if((posL+120)>325 && posL < 325) {
			if(posT>90 && posT<130){
				newPosL = 325;
			}
			if(posT>169 && posT<208){
				newPosL = 325;
			}
		}
	}
	
	if((posL+120)>280 && posL <365){
		if(posT>362 && posT<398){
			activateLight = true;
			lightFactor = 1;
		}
		if((posL+120)>284 && posL <325){
			if(posT>130 && posT<169){
				if(spires==2){
					activateLight = true;
					lightFactor = 2;
				}
			}
		}
	}else{
		activateLight = false;
	}

	ui.position.left = newPosL;
	ui.position.top = newPosT;
	$("#fieldLines").css("left",(newPosL-295)+"px");
	$("#fieldLines").css("top",(newPosT-223)+"px");
}

function set1spire() {
	spires = 1;
	$("#x1").css("display","block");
	$("#x2").css("display","none");

	$("#lines2").css("display","none");
	$("#espira2back").css("display","none");
	$("#espira2front").css("display","none");
}
function set2spires() {
	spires = 2;
	$("#x2").css("display","block");
	$("#x1").css("display","none");

	$("#lines2").css("display","block");
	$("#espira2back").css("display","block");
	$("#espira2front").css("display","block");
}
function showLines() {
	if(showingLines) {
		$("#fieldLines").css("display","none");
		$("#x3").css("display","none");
		showingLines = false;
	}else{
		$("#fieldLines").css("display","block");
		$("#x3").css("display","block");
		showingLines = true;
	}
}
function invert(){
	if(inverted) {
		$("#x4").css("display","none");
		$("#magnet").attr("src","images/magnet.png");
		$("#fieldLines").attr("src","images/fieldLines.png");
		inverted = false;
	}else{
		$("#x4").css("display","block");
		$("#magnet").attr("src","images/magnetInvert.png");
		$("#fieldLines").attr("src","images/fieldLinesInvert.png");
		inverted = true;
	}
}
function iniciar(){
	if(!iniciat){	
			
	}
}

function reiniciar(){
	if(canChange){
		restart();
		initialize();
	}
}