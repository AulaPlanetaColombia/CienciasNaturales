(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0,0,1,0,0);
       
	this.text = new cjs.Text(txt['titulo'], "31px Georgia");
	this.text.textAlign = "center";
	this.text.lineHeight = 33;
	this.text.lineWidth = 783;
	this.text.setTransform(473.5,53.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA76gGjMh3zAAAQhkAAAABkIAAJ/QAABkBkAAMB3zAAAQBkAAAAhkIAAp/QAAhkhkAAg");
	this.shape.setTransform(475.5,70.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Eg75AGjQhkABAAhlIAAp+QAAhjBkAAMB3zAAAQBkAAAABjIAAJ+QAABlhkgBg");
	this.shape_1.setTransform(475.5,70.1);

	

	this.instance = new lib.intro();
        this.instance.setTransform(0,-100);
           this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.addChild(this.logo, this.titulo, this.instance,this.shape_2,this.shape_1,this.shape,this.text, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
       this.instance = new lib.mc_grafica1();
	this.instance.setTransform(476,385.5,1,1,0,0,0,250,191.5);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
       this.text = new cjs.Text(txt['patras'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 121;
	this.text.setTransform(697,165+incremento);

	this.text_1 = new cjs.Text(txt['palante'], "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 121;
	this.text_1.setTransform(473,165+incremento);

	this.text_2 = new cjs.Text(txt['quieto'], "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 121;
	this.text_2.setTransform(256.5,165+incremento);

	this.btn_next = new lib.btn1();
	this.btn_next.setTransform(411.8,104.4);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.btn1(), 3);

	this.btn_1 = new lib.btn2();
	this.btn_1.setTransform(259.2,129.7,1,1,0,0,0,62.5,34.6);
	new cjs.ButtonHelper(this.btn_1, 0, 1, 2, false, new lib.btn2(), 3);

	this.btn_3 = new lib.btn3();
	this.btn_3.setTransform(635.1,104.3);
	new cjs.ButtonHelper(this.btn_3, 0, 1, 2, false, new lib.btn3(), 3);

  this.btn_next.on("click", function (evt) {
            putStage(new lib.frame4());
        });
  this.btn_1.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
  this.btn_3.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        
	this.instance = new lib.mc_grafica2();
	this.instance.setTransform(476,385.5,1,1,0,0,0,250,191.5);

	this.text_3 = new cjs.Text(txt['elegir'], "25px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 27;
	this.text_3.lineWidth = 783;
	this.text_3.setTransform(473.5,15+incremento);

       
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text_3,this.instance,this.btn_3,this.btn_1,this.btn_next,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
       this.text = new cjs.Text(txt['patras'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 121;
	this.text.setTransform(697,165+incremento);

	this.text_1 = new cjs.Text(txt['palante'], "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 121;
	this.text_1.setTransform(473,165+incremento);

	this.text_2 = new cjs.Text(txt['quieto'], "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 121;
	this.text_2.setTransform(256.5,165+incremento);

	this.btn_next = new lib.btn1();
	this.btn_next.setTransform(411.8,104.4);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.btn1(), 3);

	this.btn_1 = new lib.btn2();
	this.btn_1.setTransform(259.2,129.7,1,1,0,0,0,62.5,34.6);
	new cjs.ButtonHelper(this.btn_1, 0, 1, 2, false, new lib.btn2(), 3);

	this.btn_3 = new lib.btn3();
	this.btn_3.setTransform(635.1,104.3);
	new cjs.ButtonHelper(this.btn_3, 0, 1, 2, false, new lib.btn3(), 3);


        
	this.instance = new lib.mc_fichaerror();
	this.instance.setTransform(657.8,362.1,1,1,0,0,0,492.4,107.1);

	this.btn_cerrar = new lib.btn_cerrar();
	this.btn_cerrar.setTransform(758.1,273.9,0.775,0.775);
	new cjs.ButtonHelper(this.btn_cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);

       
        this.btn_cerrar.on("click", function (evt) {
            putStage(new lib.frame3());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.btn_cerrar,this.text_3,this.instance,this.btn_3,this.btn_1,this.btn_next,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

     (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
       this.text = new cjs.Text(txt['patras'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 121;
	this.text.setTransform(697,165+incremento);

	this.text_1 = new cjs.Text(txt['palante'], "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 121;
	this.text_1.setTransform(473,165+incremento);

	this.text_2 = new cjs.Text(txt['quieto'], "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 121;
	this.text_2.setTransform(256.5,165+incremento);

	this.btn_next = new lib.btn1();
	this.btn_next.setTransform(411.8,104.4);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.btn1(), 3);

	this.btn_1 = new lib.btn2();
	this.btn_1.setTransform(259.2,129.7,1,1,0,0,0,62.5,34.6);
	new cjs.ButtonHelper(this.btn_1, 0, 1, 2, false, new lib.btn2(), 3);

	this.btn_3 = new lib.btn3();
	this.btn_3.setTransform(635.1,104.3);
	new cjs.ButtonHelper(this.btn_3, 0, 1, 2, false, new lib.btn3(), 3);

  this.btn_next.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
  this.btn_1.on("click", function (evt) {
            putStage(new lib.frame5());
        });
  this.btn_3.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        
	this.instance = new lib.mc_grafica3();
	this.instance.setTransform(476,385.5,1,1,0,0,0,250,191.5);

	this.text_3 = new cjs.Text(txt['elegir'], "25px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 27;
	this.text_3.lineWidth = 783;
	this.text_3.setTransform(473.5,15+incremento);

       
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text_3,this.instance,this.btn_3,this.btn_1,this.btn_next,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
       this.text = new cjs.Text(txt['patras'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 121;
	this.text.setTransform(697,165+incremento);

	this.text_1 = new cjs.Text(txt['palante'], "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 121;
	this.text_1.setTransform(473,165+incremento);

	this.text_2 = new cjs.Text(txt['quieto'], "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 121;
	this.text_2.setTransform(256.5,165+incremento);

	this.btn_next = new lib.btn1();
	this.btn_next.setTransform(411.8,104.4);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.btn1(), 3);

	this.btn_1 = new lib.btn2();
	this.btn_1.setTransform(259.2,129.7,1,1,0,0,0,62.5,34.6);
	new cjs.ButtonHelper(this.btn_1, 0, 1, 2, false, new lib.btn2(), 3);

	this.btn_3 = new lib.btn3();
	this.btn_3.setTransform(635.1,104.3);
	new cjs.ButtonHelper(this.btn_3, 0, 1, 2, false, new lib.btn3(), 3);


        
	this.instance = new lib.mc_fichaerror();
	this.instance.setTransform(657.8,362.1,1,1,0,0,0,492.4,107.1);

	this.btn_cerrar = new lib.btn_cerrar();
	this.btn_cerrar.setTransform(758.1,273.9,0.775,0.775);
	new cjs.ButtonHelper(this.btn_cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);

       
        this.btn_cerrar.on("click", function (evt) {
            putStage(new lib.frame4());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.btn_cerrar,this.text_3,this.instance,this.btn_3,this.btn_1,this.btn_next,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

     (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
       this.text = new cjs.Text(txt['patras'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 121;
	this.text.setTransform(697,165+incremento);

	this.text_1 = new cjs.Text(txt['palante'], "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 121;
	this.text_1.setTransform(473,165+incremento);

	this.text_2 = new cjs.Text(txt['quieto'], "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 121;
	this.text_2.setTransform(256.5,165+incremento);

	this.btn_next = new lib.btn1();
	this.btn_next.setTransform(411.8,104.4);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.btn1(), 3);

	this.btn_1 = new lib.btn2();
	this.btn_1.setTransform(259.2,129.7,1,1,0,0,0,62.5,34.6);
	new cjs.ButtonHelper(this.btn_1, 0, 1, 2, false, new lib.btn2(), 3);

	this.btn_3 = new lib.btn3();
	this.btn_3.setTransform(635.1,104.3);
	new cjs.ButtonHelper(this.btn_3, 0, 1, 2, false, new lib.btn3(), 3);

  this.btn_next.on("click", function (evt) {
            putStage(new lib.frame6());
        });
  this.btn_1.on("click", function (evt) {
            putStage(new lib.frame5_1());
        });
  this.btn_3.on("click", function (evt) {
            putStage(new lib.frame5_1());
        });
        
	this.instance = new lib.mc_grafica4();
	this.instance.setTransform(476,385.5,1,1,0,0,0,250,191.5);

	this.text_3 = new cjs.Text(txt['elegir'], "25px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 27;
	this.text_3.lineWidth = 783;
	this.text_3.setTransform(473.5,15+incremento);

       
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text_3,this.instance,this.btn_3,this.btn_1,this.btn_next,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame5_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
       this.text = new cjs.Text(txt['patras'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 121;
	this.text.setTransform(697,165+incremento);

	this.text_1 = new cjs.Text(txt['palante'], "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 121;
	this.text_1.setTransform(473,165+incremento);

	this.text_2 = new cjs.Text(txt['quieto'], "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 121;
	this.text_2.setTransform(256.5,165+incremento);

	this.btn_next = new lib.btn1();
	this.btn_next.setTransform(411.8,104.4);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.btn1(), 3);

	this.btn_1 = new lib.btn2();
	this.btn_1.setTransform(259.2,129.7,1,1,0,0,0,62.5,34.6);
	new cjs.ButtonHelper(this.btn_1, 0, 1, 2, false, new lib.btn2(), 3);

	this.btn_3 = new lib.btn3();
	this.btn_3.setTransform(635.1,104.3);
	new cjs.ButtonHelper(this.btn_3, 0, 1, 2, false, new lib.btn3(), 3);


        
	this.instance = new lib.mc_fichaerror();
	this.instance.setTransform(657.8,362.1,1,1,0,0,0,492.4,107.1);

	this.btn_cerrar = new lib.btn_cerrar();
	this.btn_cerrar.setTransform(758.1,273.9,0.775,0.775);
	new cjs.ButtonHelper(this.btn_cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);

       
        this.btn_cerrar.on("click", function (evt) {
            putStage(new lib.frame5());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.btn_cerrar,this.text_3,this.instance,this.btn_3,this.btn_1,this.btn_next,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
       this.text = new cjs.Text(txt['patras'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 121;
	this.text.setTransform(697,165+incremento);

	this.text_1 = new cjs.Text(txt['palante'], "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 121;
	this.text_1.setTransform(473,165+incremento);

	this.text_2 = new cjs.Text(txt['quieto'], "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 121;
	this.text_2.setTransform(256.5,165+incremento);

	this.btn_next = new lib.btn1();
	this.btn_next.setTransform(411.8,104.4);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.btn1(), 3);

	this.btn_1 = new lib.btn2();
	this.btn_1.setTransform(259.2,129.7,1,1,0,0,0,62.5,34.6);
	new cjs.ButtonHelper(this.btn_1, 0, 1, 2, false, new lib.btn2(), 3);

	this.btn_3 = new lib.btn3();
	this.btn_3.setTransform(635.1,104.3);
	new cjs.ButtonHelper(this.btn_3, 0, 1, 2, false, new lib.btn3(), 3);

  this.btn_next.on("click", function (evt) {
            putStage(new lib.frame6_1());
        });
  this.btn_1.on("click", function (evt) {
            putStage(new lib.frame6_1());
        });
  this.btn_3.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        
	this.instance = new lib.mc_grafica5();
	this.instance.setTransform(476,385.5,1,1,0,0,0,250,191.5);

	this.text_3 = new cjs.Text(txt['elegir'], "25px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 27;
	this.text_3.lineWidth = 783;
	this.text_3.setTransform(473.5,15+incremento);

       
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text_3,this.instance,this.btn_3,this.btn_1,this.btn_next,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame6_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
       this.text = new cjs.Text(txt['patras'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 121;
	this.text.setTransform(697,165+incremento);

	this.text_1 = new cjs.Text(txt['palante'], "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 121;
	this.text_1.setTransform(473,165+incremento);

	this.text_2 = new cjs.Text(txt['quieto'], "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 121;
	this.text_2.setTransform(256.5,165+incremento);

	this.btn_next = new lib.btn1();
	this.btn_next.setTransform(411.8,104.4);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.btn1(), 3);

	this.btn_1 = new lib.btn2();
	this.btn_1.setTransform(259.2,129.7,1,1,0,0,0,62.5,34.6);
	new cjs.ButtonHelper(this.btn_1, 0, 1, 2, false, new lib.btn2(), 3);

	this.btn_3 = new lib.btn3();
	this.btn_3.setTransform(635.1,104.3);
	new cjs.ButtonHelper(this.btn_3, 0, 1, 2, false, new lib.btn3(), 3);


        
	this.instance = new lib.mc_fichaerror();
	this.instance.setTransform(657.8,362.1,1,1,0,0,0,492.4,107.1);

	this.btn_cerrar = new lib.btn_cerrar();
	this.btn_cerrar.setTransform(758.1,273.9,0.775,0.775);
	new cjs.ButtonHelper(this.btn_cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);

       
        this.btn_cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.btn_cerrar,this.text_3,this.instance,this.btn_3,this.btn_1,this.btn_next,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
     this.instance = new lib.Path_1();
	this.instance.setTransform(364.3,82.9,0.839,0.839,0,0,0,98,103.7);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.706)",7,7,15);

	this.instance_1 = new lib.coche1siluetaPetit();
	this.instance_1.setTransform(716.3,332.8,1,1,0,45,-134.9);

	this.instance_2 = new lib.coche1siluetaPetit();
	this.instance_2.setTransform(482.1,319.1,1,1,-44.9);

	this.instance_3 = new lib.coche2siluetaPetit();
	this.instance_3.setTransform(388.8,306.4,1,1,3.2);

	this.instance_4 = new lib.coche1siluetaPetit();
	this.instance_4.setTransform(259.9,425.4,1,1,-44.9);

	this.instance_5 = new lib.mc_grafica5b();
	this.instance_5.setTransform(475.4,340.3,1,1,0,0,0,250,191.5);

	this.text = new cjs.Text(txt['correcto'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 772;
	this.text.setTransform(82.5,73+incremento);

       
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text_3,this.instance,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   
   
(lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,125,60);


(lib.Mapadebits2 = function() {
	this.initialize(img.Mapadebits2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,125,60);


(lib.Mapadebits3 = function() {
	this.initialize(img.Mapadebits3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,125,60);


(lib.Mapadebits4 = function() {
	this.initialize(img.Mapadebits4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,138,66);


(lib.Mapadebits5 = function() {
	this.initialize(img.Mapadebits5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,138,66);


(lib.Mapadebits6 = function() {
	this.initialize(img.Mapadebits6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,138,66);


   (lib.boton1 = function() {
	this.initialize(img.boton1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,125,60);


(lib.boton2 = function() {
	this.initialize(img.boton2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,125,60);


(lib.boton3 = function() {
	this.initialize(img.boton3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,125,85);


(lib.CN_08_10_06 = function() {
	this.initialize(img.CN_08_10_06);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,383);


(lib.CN_08_10_06bntif = function() {
	this.initialize(img.CN_08_10_06bntif);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1042,235);


(lib.CN_08_10_06Distancia = function() {
	this.initialize(img.CN_08_10_06Distancia);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,383);


(lib.CN_08_10_06Distancia_1 = function() {
	this.initialize(img.CN_08_10_06Distancia_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,126,363);


(lib.CN_08_10_06Tiempo = function() {
	this.initialize(img.CN_08_10_06Tiempo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,383);


(lib.coche1siluetaPetit = function() {
	this.initialize(img.coche1siluetaPetit);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,113,28);


(lib.coche2siluetaPetit = function() {
	this.initialize(img.coche2siluetaPetit);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,73,50);


(lib.intro = function() {
	this.initialize(img.intro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,702);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.mc_grafica5b = function() {
	this.initialize();

	// animacio3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0789B4").ss(2,1,1).p("AoroXIRXQv");
	this.shape.setTransform(422.4,158);

	// animacio
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#0789B4").ss(2,1,1).p("AorIZIRXwx");
	this.shape_1.setTransform(311.6,158.2,0.985,1,0,0,0,0.3,0);

	// animacio
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#0789B4").ss(2,1,1).p("AoxAAIRjAA");
	this.shape_2.setTransform(200.3,212);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#0789B4").ss(2,1,1).p("AoqIcIRVw3");
	this.shape_3.setTransform(88.6,266);

	// base
	this.text = new cjs.Text("0", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.setTransform(16.4,313.5);

	this.text_1 = new cjs.Text(txt['distancia'], "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.setTransform(61.4,19.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_4.setTransform(28.9,51.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_5.setTransform(28.9,104.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_6.setTransform(28.8,157.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_7.setTransform(28.5,211.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_8.setTransform(28.5,265.3);

	this.text_2 = new cjs.Text("25", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.setTransform(11.3,45.5);

	this.text_3 = new cjs.Text("20", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 19;
	this.text_3.setTransform(11.3,97.9);

	this.text_4 = new cjs.Text("15", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 19;
	this.text_4.setTransform(11.3,150.7);

	this.text_5 = new cjs.Text("10", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 19;
	this.text_5.setTransform(11.3,205.3);

	this.text_6 = new cjs.Text("5", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 19;
	this.text_6.setTransform(11.3,258.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAATeMAAAgm7");
	this.shape_9.setTransform(32.7,189.3,1,1.109);

	this.text_7 = new cjs.Text(txt['tiempo'], "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 19;
	this.text_7.setTransform(445,348.4);

	this.text_8 = new cjs.Text("40", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 19;
	this.text_8.setTransform(478.8,328.6);

	this.text_9 = new cjs.Text("35", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 19;
	this.text_9.setTransform(422.8,328.6);

	this.text_10 = new cjs.Text("30", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 19;
	this.text_10.setTransform(366.5,328.6);

	this.text_11 = new cjs.Text("25", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 19;
	this.text_11.setTransform(311.6,328.6);

	this.text_12 = new cjs.Text("20", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 19;
	this.text_12.setTransform(256.5,328.6);

	this.text_13 = new cjs.Text("15", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 19;
	this.text_13.setTransform(200.8,328.6);

	this.text_14 = new cjs.Text("10", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 19;
	this.text_14.setTransform(144.4,328.6);

	this.text_15 = new cjs.Text("5", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 19;
	this.text_15.setTransform(89.1,328.6);

	this.text_16 = new cjs.Text("0", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 19;
	this.text_16.setTransform(33.7,328.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_10.setTransform(479.8,322.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_11.setTransform(423.4,322.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_12.setTransform(367.2,322.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_13.setTransform(312.1,322.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_14.setTransform(256.9,322.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_15.setTransform(200.9,322.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_16.setTransform(144.5,322.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_17.setTransform(89.6,322.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("EgjIAAAMBGRAAA");
	this.shape_18.setTransform(255.4,319.5);

	this.addChild(this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.shape_9,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.text_1,this.text,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(1.3,19.9,487.5,344);


(lib.mc_grafica5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// animacio3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0789B4").ss(2,1,1).p("AgEgEIAJAJ");
	this.shape.setTransform(367.3,104.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#0789B4").ss(2,1,1).p("AgXgWIAvAt");
	this.shape_1.setTransform(369.2,106.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#0789B4").ss(2,1,1).p("AgqgpIBVBT");
	this.shape_2.setTransform(371.1,108.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#0789B4").ss(2,1,1).p("Ag9g7IB7B3");
	this.shape_3.setTransform(373,110.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#0789B4").ss(2,1,1).p("AhQhNIChCb");
	this.shape_4.setTransform(374.9,112.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#0789B4").ss(2,1,1).p("AhjhgIDHDB");
	this.shape_5.setTransform(376.8,114);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#0789B4").ss(2,1,1).p("Ah2hyIDtDl");
	this.shape_6.setTransform(378.7,115.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#0789B4").ss(2,1,1).p("AiJiEIETEJ");
	this.shape_7.setTransform(380.6,117.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#0789B4").ss(2,1,1).p("AiciWIE5Et");
	this.shape_8.setTransform(382.5,119.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#0789B4").ss(2,1,1).p("AivipIFfFT");
	this.shape_9.setTransform(384.4,121.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#0789B4").ss(2,1,1).p("AjCi7IGFF3");
	this.shape_10.setTransform(386.3,123.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#0789B4").ss(2,1,1).p("AjVjNIGrGb");
	this.shape_11.setTransform(388.2,125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#0789B4").ss(2,1,1).p("AjojgIHRHB");
	this.shape_12.setTransform(390.1,126.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#0789B4").ss(2,1,1).p("Aj7jyIH3Hl");
	this.shape_13.setTransform(392,128.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#0789B4").ss(2,1,1).p("AkOkEIIdIJ");
	this.shape_14.setTransform(393.9,130.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#0789B4").ss(2,1,1).p("AkhkXIJDIv");
	this.shape_15.setTransform(395.8,132.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#0789B4").ss(2,1,1).p("Ak0kpIJpJT");
	this.shape_16.setTransform(397.7,134.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#0789B4").ss(2,1,1).p("AlHk7IKPJ3");
	this.shape_17.setTransform(399.6,136);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#0789B4").ss(2,1,1).p("AlalOIK1Kd");
	this.shape_18.setTransform(401.5,137.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#0789B4").ss(2,1,1).p("AltlgILbLB");
	this.shape_19.setTransform(403.4,139.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#0789B4").ss(2,1,1).p("AmAlyIMBLl");
	this.shape_20.setTransform(405.3,141.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#0789B4").ss(2,1,1).p("AmTmFIMnML");
	this.shape_21.setTransform(407.2,143.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#0789B4").ss(2,1,1).p("AmmmXINNMv");
	this.shape_22.setTransform(409.1,145.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#0789B4").ss(2,1,1).p("Am5mpINzNT");
	this.shape_23.setTransform(411,147);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#0789B4").ss(2,1,1).p("AnMm7IOZN3");
	this.shape_24.setTransform(412.9,148.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#0789B4").ss(2,1,1).p("AnfnOIO/Od");
	this.shape_25.setTransform(414.8,150.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#0789B4").ss(2,1,1).p("AnyngIPlPB");
	this.shape_26.setTransform(416.7,152.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#0789B4").ss(2,1,1).p("AoFnyIQLPl");
	this.shape_27.setTransform(418.6,154.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#0789B4").ss(2,1,1).p("AoYoFIQxQL");
	this.shape_28.setTransform(420.5,156.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#0789B4").ss(2,1,1).p("AoroXIRXQv");
	this.shape_29.setTransform(422.4,158);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).wait(1));

	// animacio
	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#0789B4").ss(2,1,1).p("AorIZIRXwx");
	this.shape_30.setTransform(311.6,158.2,0.985,1,0,0,0,0.3,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30}]}).wait(30));

	// animacio
	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#0789B4").ss(2,1,1).p("AoxAAIRjAA");
	this.shape_31.setTransform(200.3,212);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#0789B4").ss(2,1,1).p("AoqIcIRVw3");
	this.shape_32.setTransform(88.6,266);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32},{t:this.shape_31}]}).wait(30));

	// base
	this.text = new cjs.Text("0", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.setTransform(16.4,313.5);

	this.text_1 = new cjs.Text(txt['distancia'], "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.setTransform(61.4,19.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_33.setTransform(28.9,51.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_34.setTransform(28.9,104.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_35.setTransform(28.8,157.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_36.setTransform(28.5,211.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_37.setTransform(28.5,265.3);

	this.text_2 = new cjs.Text("25", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.setTransform(11.3,45.5);

	this.text_3 = new cjs.Text("20", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 19;
	this.text_3.setTransform(11.3,97.9);

	this.text_4 = new cjs.Text("15", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 19;
	this.text_4.setTransform(11.3,150.7);

	this.text_5 = new cjs.Text("10", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 19;
	this.text_5.setTransform(11.3,205.3);

	this.text_6 = new cjs.Text("5", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 19;
	this.text_6.setTransform(11.3,258.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAATeMAAAgm7");
	this.shape_38.setTransform(32.7,189.3,1,1.109);

	this.text_7 = new cjs.Text(txt['tiempo'], "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 19;
	this.text_7.setTransform(446.5,348.4);

	this.text_8 = new cjs.Text("40", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 19;
	this.text_8.setTransform(478.8,328.6);

	this.text_9 = new cjs.Text("35", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 19;
	this.text_9.setTransform(422.8,328.6);

	this.text_10 = new cjs.Text("30", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 19;
	this.text_10.setTransform(366.5,328.6);

	this.text_11 = new cjs.Text("25", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 19;
	this.text_11.setTransform(311.6,328.6);

	this.text_12 = new cjs.Text("20", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 19;
	this.text_12.setTransform(256.5,328.6);

	this.text_13 = new cjs.Text("15", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 19;
	this.text_13.setTransform(200.8,328.6);

	this.text_14 = new cjs.Text("10", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 19;
	this.text_14.setTransform(144.4,328.6);

	this.text_15 = new cjs.Text("5", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 19;
	this.text_15.setTransform(89.1,328.6);

	this.text_16 = new cjs.Text("0", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 19;
	this.text_16.setTransform(33.7,328.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_39.setTransform(479.8,322.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_40.setTransform(423.4,322.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_41.setTransform(367.2,322.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_42.setTransform(312.1,322.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_43.setTransform(256.9,322.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_44.setTransform(200.9,322.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_45.setTransform(144.5,322.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_46.setTransform(89.6,322.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("EgjIAAAMBGRAAA");
	this.shape_47.setTransform(255.4,319.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.shape_38},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.text_1},{t:this.text}]}).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.3,19.9,487.5,344);


(lib.mc_grafica4b = function() {
	this.initialize();

	// animacio
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0789B4").ss(2,1,1).p("AorIZIRXwx");
	this.shape.setTransform(311.6,158.2,0.985,1,0,0,0,0.3,0);

	// animacio
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#0789B4").ss(2,1,1).p("AoxAAIRjAA");
	this.shape_1.setTransform(200.3,212);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#0789B4").ss(2,1,1).p("AoqIcIRVw3");
	this.shape_2.setTransform(88.6,266);

	// base
	this.text = new cjs.Text("0", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.setTransform(16.4,313.5);

	this.text_1 = new cjs.Text(txt['distancia'], "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.setTransform(61.4,19.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_3.setTransform(28.9,51.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_4.setTransform(28.9,104.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_5.setTransform(28.8,157.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_6.setTransform(28.5,211.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_7.setTransform(28.5,265.3);

	this.text_2 = new cjs.Text("25", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.setTransform(11.3,45.5);

	this.text_3 = new cjs.Text("20", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 19;
	this.text_3.setTransform(11.3,97.9);

	this.text_4 = new cjs.Text("15", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 19;
	this.text_4.setTransform(11.3,150.7);

	this.text_5 = new cjs.Text("10", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 19;
	this.text_5.setTransform(11.3,205.3);

	this.text_6 = new cjs.Text("5", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 19;
	this.text_6.setTransform(11.3,258.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAATeMAAAgm7");
	this.shape_8.setTransform(32.7,189.3,1,1.109);

	this.text_7 = new cjs.Text(txt['tiempo'], "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 19;
	this.text_7.setTransform(449.5,348.4);

	this.text_8 = new cjs.Text("40", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 19;
	this.text_8.setTransform(478.8,328.6);

	this.text_9 = new cjs.Text("35", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 19;
	this.text_9.setTransform(422.8,328.6);

	this.text_10 = new cjs.Text("30", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 19;
	this.text_10.setTransform(366.5,328.6);

	this.text_11 = new cjs.Text("25", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 19;
	this.text_11.setTransform(311.6,328.6);

	this.text_12 = new cjs.Text("20", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 19;
	this.text_12.setTransform(256.5,328.6);

	this.text_13 = new cjs.Text("15", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 19;
	this.text_13.setTransform(200.8,328.6);

	this.text_14 = new cjs.Text("10", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 19;
	this.text_14.setTransform(144.4,328.6);

	this.text_15 = new cjs.Text("5", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 19;
	this.text_15.setTransform(89.1,328.6);

	this.text_16 = new cjs.Text("0", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 19;
	this.text_16.setTransform(33.7,328.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_9.setTransform(479.8,322.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_10.setTransform(423.4,322.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_11.setTransform(367.2,322.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_12.setTransform(312.1,322.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_13.setTransform(256.9,322.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_14.setTransform(200.9,322.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_15.setTransform(144.5,322.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_16.setTransform(89.6,322.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("EgjIAAAMBGRAAA");
	this.shape_17.setTransform(255.4,319.5);

	this.addChild(this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.shape_8,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.text_1,this.text,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(1.3,19.9,487.5,344);


(lib.mc_grafica4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// animacio
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0789B4").ss(2,1,1).p("AgFAGIALgL");
	this.shape.setTransform(311.4,158.3,1,1,0,0,0,54.2,-53);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#0789B4").ss(2,1,1).p("AgYAYIAxgv");
	this.shape_1.setTransform(259,209.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#0789B4").ss(2,1,1).p("AgrArIBXhV");
	this.shape_2.setTransform(260.9,207.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#0789B4").ss(2,1,1).p("Ag9A9IB7h5");
	this.shape_3.setTransform(262.8,205.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#0789B4").ss(2,1,1).p("AhQBPIChid");
	this.shape_4.setTransform(264.6,204);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#0789B4").ss(2,1,1).p("AhjBiIDHjD");
	this.shape_5.setTransform(266.5,202.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#0789B4").ss(2,1,1).p("Ah1B0IDrjn");
	this.shape_6.setTransform(268.4,200.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#0789B4").ss(2,1,1).p("AiICGIERkL");
	this.shape_7.setTransform(270.3,198.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#0789B4").ss(2,1,1).p("AibCZIE3kx");
	this.shape_8.setTransform(272.1,196.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#0789B4").ss(2,1,1).p("AitCrIFblV");
	this.shape_9.setTransform(274,194.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#0789B4").ss(2,1,1).p("AjAC9IGBl5");
	this.shape_10.setTransform(275.9,193);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#0789B4").ss(2,1,1).p("AjTDQIGnmf");
	this.shape_11.setTransform(277.7,191.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#0789B4").ss(2,1,1).p("AjlDiIHLnD");
	this.shape_12.setTransform(279.6,189.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#0789B4").ss(2,1,1).p("Aj4D0IHxnn");
	this.shape_13.setTransform(281.5,187.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#0789B4").ss(2,1,1).p("AkLEGIIXoL");
	this.shape_14.setTransform(283.3,185.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#0789B4").ss(2,1,1).p("AkdEZII7ox");
	this.shape_15.setTransform(285.2,183.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#0789B4").ss(2,1,1).p("AkwErIJhpV");
	this.shape_16.setTransform(287.1,182);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#0789B4").ss(2,1,1).p("AlDE9IKHp5");
	this.shape_17.setTransform(288.9,180.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#0789B4").ss(2,1,1).p("AlWFQIKtqf");
	this.shape_18.setTransform(290.8,178.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#0789B4").ss(2,1,1).p("AloFiILRrD");
	this.shape_19.setTransform(292.7,176.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#0789B4").ss(2,1,1).p("Al7F0IL3rn");
	this.shape_20.setTransform(294.5,174.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#0789B4").ss(2,1,1).p("AmOGHIMdsN");
	this.shape_21.setTransform(296.4,172.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#0789B4").ss(2,1,1).p("AmgGZINBsx");
	this.shape_22.setTransform(298.3,171);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#0789B4").ss(2,1,1).p("AmzGrINntV");
	this.shape_23.setTransform(300.1,169.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#0789B4").ss(2,1,1).p("AnGG+IONt7");
	this.shape_24.setTransform(302,167.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#0789B4").ss(2,1,1).p("AnYHQIOxuf");
	this.shape_25.setTransform(303.9,165.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#0789B4").ss(2,1,1).p("AnrHiIPXvD");
	this.shape_26.setTransform(305.7,163.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#0789B4").ss(2,1,1).p("An+H1IP9vp");
	this.shape_27.setTransform(307.6,161.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#0789B4").ss(2,1,1).p("AoQIHIQhwN");
	this.shape_28.setTransform(309.5,160.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#0789B4").ss(2,1,1).p("AorIZIRXwx");
	this.shape_29.setTransform(311.5,158.2,0.985,1,0,0,0,0.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).wait(1));

	// animacio
	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#0789B4").ss(2,1,1).p("AoxAAIRjAA");
	this.shape_30.setTransform(200.3,212);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#0789B4").ss(2,1,1).p("AoqIcIRVw3");
	this.shape_31.setTransform(88.6,266);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30}]}).wait(30));

	// Capa 2
	this.text = new cjs.Text("0", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.setTransform(16.4,313.5);

	this.text_1 = new cjs.Text(txt['distancia'], "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.setTransform(61.4,19.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_32.setTransform(28.9,51.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_33.setTransform(28.9,104.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_34.setTransform(28.8,157.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_35.setTransform(28.5,211.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_36.setTransform(28.5,265.3);

	this.text_2 = new cjs.Text("25", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.setTransform(11.3,45.5);

	this.text_3 = new cjs.Text("20", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 19;
	this.text_3.setTransform(11.3,97.9);

	this.text_4 = new cjs.Text("15", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 19;
	this.text_4.setTransform(11.3,150.7);

	this.text_5 = new cjs.Text("10", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 19;
	this.text_5.setTransform(11.3,205.3);

	this.text_6 = new cjs.Text("5", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 19;
	this.text_6.setTransform(11.3,258.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAATeMAAAgm7");
	this.shape_37.setTransform(32.7,189.3,1,1.109);

	this.text_7 = new cjs.Text(txt['tiempo'], "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 19;
	this.text_7.setTransform(448,348.4);

	this.text_8 = new cjs.Text("40", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 19;
	this.text_8.setTransform(478.8,328.6);

	this.text_9 = new cjs.Text("35", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 19;
	this.text_9.setTransform(422.8,328.6);

	this.text_10 = new cjs.Text("30", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 19;
	this.text_10.setTransform(366.5,328.6);

	this.text_11 = new cjs.Text("25", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 19;
	this.text_11.setTransform(311.6,328.6);

	this.text_12 = new cjs.Text("20", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 19;
	this.text_12.setTransform(256.5,328.6);

	this.text_13 = new cjs.Text("15", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 19;
	this.text_13.setTransform(200.8,328.6);

	this.text_14 = new cjs.Text("10", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 19;
	this.text_14.setTransform(144.4,328.6);

	this.text_15 = new cjs.Text("5", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 19;
	this.text_15.setTransform(89.1,328.6);

	this.text_16 = new cjs.Text("0", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 19;
	this.text_16.setTransform(33.7,328.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_38.setTransform(479.8,322.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_39.setTransform(423.4,322.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_40.setTransform(367.2,322.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_41.setTransform(312.1,322.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_42.setTransform(256.9,322.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_43.setTransform(200.9,322.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_44.setTransform(144.5,322.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_45.setTransform(89.6,322.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("EgjIAAAMBGRAAA");
	this.shape_46.setTransform(255.4,319.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.shape_37},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.text_1},{t:this.text}]}).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.3,19.9,487.5,344);


(lib.mc_grafica2b = function() {
	this.initialize();

	// animacio
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0789B4").ss(2,1,1).p("AoqIcIRVw3");
	this.shape.setTransform(88.6,266);

	// Capa 2
	this.text = new cjs.Text("0", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.setTransform(16.4,313.5);

	this.text_1 = new cjs.Text(txt['distancia'], "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.setTransform(63.4,19.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_1.setTransform(28.9,51.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_2.setTransform(28.9,104.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_3.setTransform(28.8,157.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_4.setTransform(28.5,211.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_5.setTransform(28.5,265.3);

	this.text_2 = new cjs.Text("25", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.setTransform(11.3,45.5);

	this.text_3 = new cjs.Text("20", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 19;
	this.text_3.setTransform(11.3,97.9);

	this.text_4 = new cjs.Text("15", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 19;
	this.text_4.setTransform(11.3,150.7);

	this.text_5 = new cjs.Text("10", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 19;
	this.text_5.setTransform(11.3,205.3);

	this.text_6 = new cjs.Text("5", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 19;
	this.text_6.setTransform(11.3,258.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAATeMAAAgm7");
	this.shape_6.setTransform(32.7,189.3,1,1.109);

	this.text_7 = new cjs.Text(txt['tiempo'], "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 19;
	this.text_7.setTransform(450,348.4);

	this.text_8 = new cjs.Text("40", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 19;
	this.text_8.setTransform(478.8,328.6);

	this.text_9 = new cjs.Text("35", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 19;
	this.text_9.setTransform(422.8,328.6);

	this.text_10 = new cjs.Text("30", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 19;
	this.text_10.setTransform(366.5,328.6);

	this.text_11 = new cjs.Text("25", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 19;
	this.text_11.setTransform(311.6,328.6);

	this.text_12 = new cjs.Text("20", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 19;
	this.text_12.setTransform(256.5,328.6);

	this.text_13 = new cjs.Text("15", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 19;
	this.text_13.setTransform(200.8,328.6);

	this.text_14 = new cjs.Text("10", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 19;
	this.text_14.setTransform(144.4,328.6);

	this.text_15 = new cjs.Text("5", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 19;
	this.text_15.setTransform(89.1,328.6);

	this.text_16 = new cjs.Text("0", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 19;
	this.text_16.setTransform(33.7,328.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_7.setTransform(479.8,322.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_8.setTransform(423.4,322.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_9.setTransform(367.2,322.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_10.setTransform(312.1,322.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_11.setTransform(256.9,322.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_12.setTransform(200.9,322.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_13.setTransform(144.5,322.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_14.setTransform(89.6,322.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("EgjIAAAMBGRAAA");
	this.shape_15.setTransform(255.4,319.5);

	this.addChild(this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.shape_6,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.text_1,this.text,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(1.3,19.9,487.5,344);


(lib.mc_grafica2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// animacio
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0789B4").ss(2,1,1).p("AgYAZIAxgx");
	this.shape.setTransform(35.6,317.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#0789B4").ss(2,1,1).p("AgqAqIBVhT");
	this.shape_1.setTransform(37.4,315.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#0789B4").ss(2,1,1).p("Ag8A7IB5h1");
	this.shape_2.setTransform(39.2,314.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#0789B4").ss(2,1,1).p("AhNBMICbiX");
	this.shape_3.setTransform(40.9,312.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#0789B4").ss(2,1,1).p("AhfBdIC/i5");
	this.shape_4.setTransform(42.7,310.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#0789B4").ss(2,1,1).p("AhwBuIDhjb");
	this.shape_5.setTransform(44.4,308.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#0789B4").ss(2,1,1).p("AiCCAIEFj/");
	this.shape_6.setTransform(46.2,307.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#0789B4").ss(2,1,1).p("AiUCRIEpkh");
	this.shape_7.setTransform(48,305.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#0789B4").ss(2,1,1).p("AilCiIFLlD");
	this.shape_8.setTransform(49.7,303.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#0789B4").ss(2,1,1).p("Ai3CzIFvll");
	this.shape_9.setTransform(51.5,302.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#0789B4").ss(2,1,1).p("AjJDEIGTmH");
	this.shape_10.setTransform(53.3,300.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#0789B4").ss(2,1,1).p("AjaDVIG1mp");
	this.shape_11.setTransform(55,298.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#0789B4").ss(2,1,1).p("AjsDnIHZnM");
	this.shape_12.setTransform(56.8,296.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#0789B4").ss(2,1,1).p("Aj+D4IH9nv");
	this.shape_13.setTransform(58.6,295.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#0789B4").ss(2,1,1).p("AkPEJIIfoR");
	this.shape_14.setTransform(60.3,293.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#0789B4").ss(2,1,1).p("AkhEaIJDoz");
	this.shape_15.setTransform(62.1,291.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#0789B4").ss(2,1,1).p("AkzErIJnpV");
	this.shape_16.setTransform(63.9,290);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#0789B4").ss(2,1,1).p("AlEE8IKJp3");
	this.shape_17.setTransform(65.6,288.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#0789B4").ss(2,1,1).p("AlWFNIKtqa");
	this.shape_18.setTransform(67.4,286.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#0789B4").ss(2,1,1).p("AlnFfILPq9");
	this.shape_19.setTransform(69.1,284.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#0789B4").ss(2,1,1).p("Al5FwILzrf");
	this.shape_20.setTransform(70.9,283.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#0789B4").ss(2,1,1).p("AmLGBIMXsB");
	this.shape_21.setTransform(72.7,281.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#0789B4").ss(2,1,1).p("AmcGSIM5sj");
	this.shape_22.setTransform(74.4,279.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#0789B4").ss(2,1,1).p("AmuGjINdtF");
	this.shape_23.setTransform(76.2,278);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#0789B4").ss(2,1,1).p("AnAG0IOBtn");
	this.shape_24.setTransform(78,276.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#0789B4").ss(2,1,1).p("AnRHGIOjuL");
	this.shape_25.setTransform(79.7,274.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#0789B4").ss(2,1,1).p("AnjHXIPHut");
	this.shape_26.setTransform(81.5,272.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#0789B4").ss(2,1,1).p("An1HoIPrvP");
	this.shape_27.setTransform(83.3,271.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#0789B4").ss(2,1,1).p("AoGH5IQNvx");
	this.shape_28.setTransform(85,269.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#0789B4").ss(2,1,1).p("AoYIKIQxwT");
	this.shape_29.setTransform(86.8,267.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#0789B4").ss(2,1,1).p("AoqIcIRVw3");
	this.shape_30.setTransform(88.6,266);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).wait(1));

	// Capa 2
	this.text = new cjs.Text("0", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.setTransform(16.4,313.5);

	this.text_1 = new cjs.Text(txt['distancia'], "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.setTransform(63.4,19.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_31.setTransform(28.9,51.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_32.setTransform(28.9,104.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_33.setTransform(28.8,157.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_34.setTransform(28.5,211.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_35.setTransform(28.5,265.3);

	this.text_2 = new cjs.Text("25", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.setTransform(11.3,45.5);

	this.text_3 = new cjs.Text("20", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 19;
	this.text_3.setTransform(11.3,97.9);

	this.text_4 = new cjs.Text("15", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 19;
	this.text_4.setTransform(11.3,150.7);

	this.text_5 = new cjs.Text("10", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 19;
	this.text_5.setTransform(11.3,205.3);

	this.text_6 = new cjs.Text("5", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 19;
	this.text_6.setTransform(11.3,258.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAATeMAAAgm7");
	this.shape_36.setTransform(32.7,189.3,1,1.109);

	this.text_7 = new cjs.Text(txt['tiempo'], "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 19;
	this.text_7.setTransform(450,348.4);

	this.text_8 = new cjs.Text("40", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 19;
	this.text_8.setTransform(478.8,328.6);

	this.text_9 = new cjs.Text("35", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 19;
	this.text_9.setTransform(422.8,328.6);

	this.text_10 = new cjs.Text("30", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 19;
	this.text_10.setTransform(366.5,328.6);

	this.text_11 = new cjs.Text("25", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 19;
	this.text_11.setTransform(311.6,328.6);

	this.text_12 = new cjs.Text("20", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 19;
	this.text_12.setTransform(256.5,328.6);

	this.text_13 = new cjs.Text("15", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 19;
	this.text_13.setTransform(200.8,328.6);

	this.text_14 = new cjs.Text("10", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 19;
	this.text_14.setTransform(144.4,328.6);

	this.text_15 = new cjs.Text("5", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 19;
	this.text_15.setTransform(89.1,328.6);

	this.text_16 = new cjs.Text("0", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 19;
	this.text_16.setTransform(33.7,328.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_37.setTransform(479.8,322.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_38.setTransform(423.4,322.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_39.setTransform(367.2,322.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_40.setTransform(312.1,322.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_41.setTransform(256.9,322.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_42.setTransform(200.9,322.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_43.setTransform(144.5,322.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_44.setTransform(89.6,322.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("EgjIAAAMBGRAAA");
	this.shape_45.setTransform(255.4,319.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.shape_36},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.text_1},{t:this.text}]}).wait(31));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.3,19.9,487.5,344);


(lib.mc_grafica1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// maskara4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_161 = new cjs.Graphics().p("Apga1IAAk1ITBAAIAAE1g");
	var mask_graphics_162 = new cjs.Graphics().p("ApgC+IAAl7ITBAAIAAF7g");
	var mask_graphics_163 = new cjs.Graphics().p("ApgDiIAAnDITBAAIAAHDg");
	var mask_graphics_164 = new cjs.Graphics().p("ApgEGIAAoLITBAAIAAILg");
	var mask_graphics_165 = new cjs.Graphics().p("ApgEqIAApTITBAAIAAJTg");
	var mask_graphics_166 = new cjs.Graphics().p("ApgFOIAAqbITBAAIAAKbg");
	var mask_graphics_167 = new cjs.Graphics().p("ApgFyIAArjITBAAIAALjg");
	var mask_graphics_168 = new cjs.Graphics().p("ApgGWIAAsrITBAAIAAMrg");
	var mask_graphics_169 = new cjs.Graphics().p("ApgG7IAAt1ITBAAIAAN1g");
	var mask_graphics_170 = new cjs.Graphics().p("ApgHfIAAu9ITBAAIAAO9g");
	var mask_graphics_171 = new cjs.Graphics().p("ApgIDIAAwFITBAAIAAQFg");
	var mask_graphics_172 = new cjs.Graphics().p("ApgInIAAxNITBAAIAARNg");
	var mask_graphics_173 = new cjs.Graphics().p("ApgJLIAAyVITBAAIAASVg");
	var mask_graphics_174 = new cjs.Graphics().p("ApgJvIAAzdITBAAIAATdg");
	var mask_graphics_175 = new cjs.Graphics().p("ApgKTIAA0lITBAAIAAUlg");
	var mask_graphics_176 = new cjs.Graphics().p("ApgK3IAA1tITBAAIAAVtg");
	var mask_graphics_177 = new cjs.Graphics().p("ApgLbIAA21ITBAAIAAW1g");
	var mask_graphics_178 = new cjs.Graphics().p("ApgL/IAA39ITBAAIAAX9g");
	var mask_graphics_179 = new cjs.Graphics().p("ApgMkIAA5HITBAAIAAZHg");
	var mask_graphics_180 = new cjs.Graphics().p("ApgNIIAA6PITBAAIAAaPg");
	var mask_graphics_181 = new cjs.Graphics().p("ApgNsIAA7XITBAAIAAbXg");
	var mask_graphics_182 = new cjs.Graphics().p("ApgOQIAA8fITBAAIAAcfg");
	var mask_graphics_183 = new cjs.Graphics().p("ApgO0IAA9nITBAAIAAdng");
	var mask_graphics_184 = new cjs.Graphics().p("ApgPYIAA+vITBAAIAAevg");
	var mask_graphics_185 = new cjs.Graphics().p("ApgP8IAA/3ITBAAIAAf3g");
	var mask_graphics_186 = new cjs.Graphics().p("ApgQgMAAAgg/ITBAAMAAAAg/g");
	var mask_graphics_187 = new cjs.Graphics().p("ApgREMAAAgiHITBAAMAAAAiHg");
	var mask_graphics_188 = new cjs.Graphics().p("ApgRoMAAAgjPITBAAMAAAAjPg");
	var mask_graphics_189 = new cjs.Graphics().p("ApgSNMAAAgkZITBAAMAAAAkZg");
	var mask_graphics_190 = new cjs.Graphics().p("ApgSxMAAAglhITBAAMAAAAlhg");
	var mask_graphics_191 = new cjs.Graphics().p("ApgTVMAAAgmpITBAAMAAAAmpg");
	var mask_graphics_192 = new cjs.Graphics().p("ApgT5MAAAgnxITBAAMAAAAnxg");
	var mask_graphics_193 = new cjs.Graphics().p("ApgUdMAAAgo5ITBAAMAAAAo5g");
	var mask_graphics_194 = new cjs.Graphics().p("ApgVBMAAAgqBITBAAMAAAAqBg");
	var mask_graphics_195 = new cjs.Graphics().p("ApgVlMAAAgrJITBAAMAAAArJg");
	var mask_graphics_196 = new cjs.Graphics().p("ApgWJMAAAgsRITBAAMAAAAsRg");
	var mask_graphics_197 = new cjs.Graphics().p("ApgWtMAAAgtZITBAAMAAAAtZg");
	var mask_graphics_198 = new cjs.Graphics().p("ApgXRMAAAguhITBAAMAAAAuhg");
	var mask_graphics_199 = new cjs.Graphics().p("ApgX2MAAAgvrITBAAMAAAAvrg");
	var mask_graphics_200 = new cjs.Graphics().p("ApgYaMAAAgwzITBAAMAAAAwzg");
	var mask_graphics_201 = new cjs.Graphics().p("ApgaGMAAAgx7ITBAAMAAAAx7g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(161).to({graphics:mask_graphics_161,x:57.5,y:171.7}).wait(1).to({graphics:mask_graphics_162,x:57.5,y:324.1}).wait(1).to({graphics:mask_graphics_163,x:57.5,y:320.3}).wait(1).to({graphics:mask_graphics_164,x:57.5,y:316.4}).wait(1).to({graphics:mask_graphics_165,x:57.5,y:312.6}).wait(1).to({graphics:mask_graphics_166,x:57.5,y:308.7}).wait(1).to({graphics:mask_graphics_167,x:57.5,y:304.9}).wait(1).to({graphics:mask_graphics_168,x:57.5,y:301.1}).wait(1).to({graphics:mask_graphics_169,x:57.5,y:297.2}).wait(1).to({graphics:mask_graphics_170,x:57.5,y:293.4}).wait(1).to({graphics:mask_graphics_171,x:57.5,y:289.5}).wait(1).to({graphics:mask_graphics_172,x:57.5,y:285.7}).wait(1).to({graphics:mask_graphics_173,x:57.5,y:281.8}).wait(1).to({graphics:mask_graphics_174,x:57.5,y:278}).wait(1).to({graphics:mask_graphics_175,x:57.5,y:274.1}).wait(1).to({graphics:mask_graphics_176,x:57.5,y:270.3}).wait(1).to({graphics:mask_graphics_177,x:57.5,y:266.5}).wait(1).to({graphics:mask_graphics_178,x:57.5,y:262.6}).wait(1).to({graphics:mask_graphics_179,x:57.5,y:258.8}).wait(1).to({graphics:mask_graphics_180,x:57.5,y:254.9}).wait(1).to({graphics:mask_graphics_181,x:57.5,y:251.1}).wait(1).to({graphics:mask_graphics_182,x:57.5,y:247.2}).wait(1).to({graphics:mask_graphics_183,x:57.5,y:243.4}).wait(1).to({graphics:mask_graphics_184,x:57.5,y:239.5}).wait(1).to({graphics:mask_graphics_185,x:57.5,y:235.7}).wait(1).to({graphics:mask_graphics_186,x:57.5,y:231.8}).wait(1).to({graphics:mask_graphics_187,x:57.5,y:228}).wait(1).to({graphics:mask_graphics_188,x:57.5,y:224.2}).wait(1).to({graphics:mask_graphics_189,x:57.5,y:220.3}).wait(1).to({graphics:mask_graphics_190,x:57.5,y:216.5}).wait(1).to({graphics:mask_graphics_191,x:57.5,y:212.6}).wait(1).to({graphics:mask_graphics_192,x:57.5,y:208.8}).wait(1).to({graphics:mask_graphics_193,x:57.5,y:204.9}).wait(1).to({graphics:mask_graphics_194,x:57.5,y:201.1}).wait(1).to({graphics:mask_graphics_195,x:57.5,y:197.2}).wait(1).to({graphics:mask_graphics_196,x:57.5,y:193.4}).wait(1).to({graphics:mask_graphics_197,x:57.5,y:189.6}).wait(1).to({graphics:mask_graphics_198,x:57.5,y:185.7}).wait(1).to({graphics:mask_graphics_199,x:57.5,y:181.9}).wait(1).to({graphics:mask_graphics_200,x:57.5,y:178}).wait(1).to({graphics:mask_graphics_201,x:57.5,y:167}).wait(1));

	// base distancia
	this.text = new cjs.Text("0", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.setTransform(16.4,313.5);

	this.text_1 = new cjs.Text(txt['distancia'], "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.setTransform(63.4,19.9);

	this.text_2 = new cjs.Text("25", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.setTransform(11.3,45.5);

	this.text_3 = new cjs.Text("20", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 19;
	this.text_3.setTransform(11.3,97.9);

	this.text_4 = new cjs.Text("15", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 19;
	this.text_4.setTransform(11.3,150.7);

	this.text_5 = new cjs.Text("10", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 19;
	this.text_5.setTransform(11.3,205.3);

	this.text_6 = new cjs.Text("5", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 19;
	this.text_6.setTransform(11.3,258.9);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},101).to({state:[{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]},60).wait(41));

	// maskara3 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_101 = new cjs.Graphics().p("AiqdDIAAq5IFVAAIAAK5g");
	var mask_1_graphics_102 = new cjs.Graphics().p("AjTFcIAAq3IGnAAIAAK3g");
	var mask_1_graphics_103 = new cjs.Graphics().p("Aj8FcIAAq3IH5AAIAAK3g");
	var mask_1_graphics_104 = new cjs.Graphics().p("AklFcIAAq3IJLAAIAAK3g");
	var mask_1_graphics_105 = new cjs.Graphics().p("AlOFcIAAq3IKdAAIAAK3g");
	var mask_1_graphics_106 = new cjs.Graphics().p("Al3FcIAAq3ILvAAIAAK3g");
	var mask_1_graphics_107 = new cjs.Graphics().p("AmgFcIAAq3INBAAIAAK3g");
	var mask_1_graphics_108 = new cjs.Graphics().p("AnJFcIAAq3IOTAAIAAK3g");
	var mask_1_graphics_109 = new cjs.Graphics().p("AnyFcIAAq3IPlAAIAAK3g");
	var mask_1_graphics_110 = new cjs.Graphics().p("AobFcIAAq3IQ3AAIAAK3g");
	var mask_1_graphics_111 = new cjs.Graphics().p("ApEFcIAAq3ISJAAIAAK3g");
	var mask_1_graphics_112 = new cjs.Graphics().p("AptFcIAAq3ITbAAIAAK3g");
	var mask_1_graphics_113 = new cjs.Graphics().p("AqWFcIAAq3IUtAAIAAK3g");
	var mask_1_graphics_114 = new cjs.Graphics().p("Aq/FcIAAq3IV/AAIAAK3g");
	var mask_1_graphics_115 = new cjs.Graphics().p("AroFcIAAq3IXRAAIAAK3g");
	var mask_1_graphics_116 = new cjs.Graphics().p("AsRFcIAAq3IYjAAIAAK3g");
	var mask_1_graphics_117 = new cjs.Graphics().p("As6FcIAAq3IZ1AAIAAK3g");
	var mask_1_graphics_118 = new cjs.Graphics().p("AtjFcIAAq3IbHAAIAAK3g");
	var mask_1_graphics_119 = new cjs.Graphics().p("AuMFcIAAq3IcZAAIAAK3g");
	var mask_1_graphics_120 = new cjs.Graphics().p("Au1FcIAAq3IdrAAIAAK3g");
	var mask_1_graphics_121 = new cjs.Graphics().p("AveFcIAAq3Ie9AAIAAK3g");
	var mask_1_graphics_122 = new cjs.Graphics().p("AwHFcIAAq3MAgPAAAIAAK3g");
	var mask_1_graphics_123 = new cjs.Graphics().p("AwwFcIAAq3MAhhAAAIAAK3g");
	var mask_1_graphics_124 = new cjs.Graphics().p("AxYFcIAAq3MAixAAAIAAK3g");
	var mask_1_graphics_125 = new cjs.Graphics().p("AyBFcIAAq3MAkDAAAIAAK3g");
	var mask_1_graphics_126 = new cjs.Graphics().p("AyqFcIAAq3MAlVAAAIAAK3g");
	var mask_1_graphics_127 = new cjs.Graphics().p("AzTFcIAAq3MAmnAAAIAAK3g");
	var mask_1_graphics_128 = new cjs.Graphics().p("Az8FcIAAq3MAn5AAAIAAK3g");
	var mask_1_graphics_129 = new cjs.Graphics().p("A0lFcIAAq3MApLAAAIAAK3g");
	var mask_1_graphics_130 = new cjs.Graphics().p("A1OFcIAAq3MAqdAAAIAAK3g");
	var mask_1_graphics_131 = new cjs.Graphics().p("A13FcIAAq3MArvAAAIAAK3g");
	var mask_1_graphics_132 = new cjs.Graphics().p("A2gFcIAAq3MAtBAAAIAAK3g");
	var mask_1_graphics_133 = new cjs.Graphics().p("A3JFcIAAq3MAuTAAAIAAK3g");
	var mask_1_graphics_134 = new cjs.Graphics().p("A3yFcIAAq3MAvlAAAIAAK3g");
	var mask_1_graphics_135 = new cjs.Graphics().p("A4bFcIAAq3MAw3AAAIAAK3g");
	var mask_1_graphics_136 = new cjs.Graphics().p("A5EFcIAAq3MAyJAAAIAAK3g");
	var mask_1_graphics_137 = new cjs.Graphics().p("A5tFcIAAq3MAzbAAAIAAK3g");
	var mask_1_graphics_138 = new cjs.Graphics().p("A6WFcIAAq3MA0tAAAIAAK3g");
	var mask_1_graphics_139 = new cjs.Graphics().p("A6/FcIAAq3MA1/AAAIAAK3g");
	var mask_1_graphics_140 = new cjs.Graphics().p("A7oFcIAAq3MA3RAAAIAAK3g");
	var mask_1_graphics_141 = new cjs.Graphics().p("A8RFcIAAq3MA4jAAAIAAK3g");
	var mask_1_graphics_142 = new cjs.Graphics().p("A86FcIAAq3MA51AAAIAAK3g");
	var mask_1_graphics_143 = new cjs.Graphics().p("A9jFcIAAq3MA7HAAAIAAK3g");
	var mask_1_graphics_144 = new cjs.Graphics().p("A+MFcIAAq3MA8ZAAAIAAK3g");
	var mask_1_graphics_145 = new cjs.Graphics().p("A+1FcIAAq3MA9rAAAIAAK3g");
	var mask_1_graphics_146 = new cjs.Graphics().p("A/eFcIAAq3MA+9AAAIAAK3g");
	var mask_1_graphics_147 = new cjs.Graphics().p("EggHAFcIAAq3MBAPAAAIAAK3g");
	var mask_1_graphics_148 = new cjs.Graphics().p("EggwAFcIAAq3MBBhAAAIAAK3g");
	var mask_1_graphics_149 = new cjs.Graphics().p("EghZAFcIAAq3MBCzAAAIAAK3g");
	var mask_1_graphics_150 = new cjs.Graphics().p("EgiCAFcIAAq3MBEFAAAIAAK3g");
	var mask_1_graphics_151 = new cjs.Graphics().p("EgirAFcIAAq3MBFXAAAIAAK3g");
	var mask_1_graphics_152 = new cjs.Graphics().p("EgjUAFcIAAq3MBGpAAAIAAK3g");
	var mask_1_graphics_153 = new cjs.Graphics().p("Egj8AFcIAAq3MBH5AAAIAAK3g");
	var mask_1_graphics_154 = new cjs.Graphics().p("EgklAFcIAAq3MBJLAAAIAAK3g");
	var mask_1_graphics_155 = new cjs.Graphics().p("EglOAFcIAAq3MBKdAAAIAAK3g");
	var mask_1_graphics_156 = new cjs.Graphics().p("Egl3AFcIAAq3MBLvAAAIAAK3g");
	var mask_1_graphics_157 = new cjs.Graphics().p("EgmgAFcIAAq3MBNBAAAIAAK3g");
	var mask_1_graphics_158 = new cjs.Graphics().p("EgnJAFcIAAq3MBOTAAAIAAK3g");
	var mask_1_graphics_159 = new cjs.Graphics().p("EgnyAFcIAAq3MBPlAAAIAAK3g");
	var mask_1_graphics_160 = new cjs.Graphics().p("EgobAdDIAAq5MBQ3AAAIAAK5g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(101).to({graphics:mask_1_graphics_101,x:-12.6,y:186}).wait(1).to({graphics:mask_1_graphics_102,x:-8.2,y:337}).wait(1).to({graphics:mask_1_graphics_103,x:-3.9,y:337}).wait(1).to({graphics:mask_1_graphics_104,x:0.3,y:337}).wait(1).to({graphics:mask_1_graphics_105,x:4.7,y:337}).wait(1).to({graphics:mask_1_graphics_106,x:9,y:337}).wait(1).to({graphics:mask_1_graphics_107,x:13.3,y:337}).wait(1).to({graphics:mask_1_graphics_108,x:17.7,y:337}).wait(1).to({graphics:mask_1_graphics_109,x:22,y:337}).wait(1).to({graphics:mask_1_graphics_110,x:26.3,y:337}).wait(1).to({graphics:mask_1_graphics_111,x:30.7,y:337}).wait(1).to({graphics:mask_1_graphics_112,x:35,y:337}).wait(1).to({graphics:mask_1_graphics_113,x:39.3,y:337}).wait(1).to({graphics:mask_1_graphics_114,x:43.7,y:337}).wait(1).to({graphics:mask_1_graphics_115,x:48,y:337}).wait(1).to({graphics:mask_1_graphics_116,x:52.3,y:337}).wait(1).to({graphics:mask_1_graphics_117,x:56.7,y:337}).wait(1).to({graphics:mask_1_graphics_118,x:61,y:337}).wait(1).to({graphics:mask_1_graphics_119,x:65.4,y:337}).wait(1).to({graphics:mask_1_graphics_120,x:69.7,y:337}).wait(1).to({graphics:mask_1_graphics_121,x:74,y:337}).wait(1).to({graphics:mask_1_graphics_122,x:78.4,y:337}).wait(1).to({graphics:mask_1_graphics_123,x:82.7,y:337}).wait(1).to({graphics:mask_1_graphics_124,x:87,y:337}).wait(1).to({graphics:mask_1_graphics_125,x:91.4,y:337}).wait(1).to({graphics:mask_1_graphics_126,x:95.7,y:337}).wait(1).to({graphics:mask_1_graphics_127,x:100,y:337}).wait(1).to({graphics:mask_1_graphics_128,x:104.4,y:337}).wait(1).to({graphics:mask_1_graphics_129,x:108.7,y:337}).wait(1).to({graphics:mask_1_graphics_130,x:113,y:337}).wait(1).to({graphics:mask_1_graphics_131,x:117.4,y:337}).wait(1).to({graphics:mask_1_graphics_132,x:121.7,y:337}).wait(1).to({graphics:mask_1_graphics_133,x:126,y:337}).wait(1).to({graphics:mask_1_graphics_134,x:130.4,y:337}).wait(1).to({graphics:mask_1_graphics_135,x:134.7,y:337}).wait(1).to({graphics:mask_1_graphics_136,x:139,y:337}).wait(1).to({graphics:mask_1_graphics_137,x:143.4,y:337}).wait(1).to({graphics:mask_1_graphics_138,x:147.7,y:337}).wait(1).to({graphics:mask_1_graphics_139,x:152,y:337}).wait(1).to({graphics:mask_1_graphics_140,x:156.4,y:337}).wait(1).to({graphics:mask_1_graphics_141,x:160.7,y:337}).wait(1).to({graphics:mask_1_graphics_142,x:165,y:337}).wait(1).to({graphics:mask_1_graphics_143,x:169.4,y:337}).wait(1).to({graphics:mask_1_graphics_144,x:173.7,y:337}).wait(1).to({graphics:mask_1_graphics_145,x:178.1,y:337}).wait(1).to({graphics:mask_1_graphics_146,x:182.4,y:337}).wait(1).to({graphics:mask_1_graphics_147,x:186.7,y:337}).wait(1).to({graphics:mask_1_graphics_148,x:191.1,y:337}).wait(1).to({graphics:mask_1_graphics_149,x:195.4,y:337}).wait(1).to({graphics:mask_1_graphics_150,x:199.7,y:337}).wait(1).to({graphics:mask_1_graphics_151,x:204.1,y:337}).wait(1).to({graphics:mask_1_graphics_152,x:208.4,y:337}).wait(1).to({graphics:mask_1_graphics_153,x:212.7,y:337}).wait(1).to({graphics:mask_1_graphics_154,x:217.1,y:337}).wait(1).to({graphics:mask_1_graphics_155,x:221.4,y:337}).wait(1).to({graphics:mask_1_graphics_156,x:225.7,y:337}).wait(1).to({graphics:mask_1_graphics_157,x:230.1,y:337}).wait(1).to({graphics:mask_1_graphics_158,x:234.4,y:337}).wait(1).to({graphics:mask_1_graphics_159,x:238.7,y:337}).wait(1).to({graphics:mask_1_graphics_160,x:243.1,y:186}).wait(42));

	// base tiempo
	this.text_7 = new cjs.Text(txt['tiempo'], "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 19;
	this.text_7.setTransform(448.2,348.4);

	this.text_8 = new cjs.Text("40", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 19;
	this.text_8.setTransform(478.8,328.6);

	this.text_9 = new cjs.Text("35", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 19;
	this.text_9.setTransform(422.8,328.6);

	this.text_10 = new cjs.Text("30", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 19;
	this.text_10.setTransform(366.5,328.6);

	this.text_11 = new cjs.Text("25", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 19;
	this.text_11.setTransform(311.6,328.6);

	this.text_12 = new cjs.Text("20", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 19;
	this.text_12.setTransform(256.5,328.6);

	this.text_13 = new cjs.Text("15", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 19;
	this.text_13.setTransform(200.8,328.6);

	this.text_14 = new cjs.Text("10", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 19;
	this.text_14.setTransform(144.4,328.6);

	this.text_15 = new cjs.Text("5", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 19;
	this.text_15.setTransform(89.1,328.6);

	this.text_16 = new cjs.Text("0", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 19;
	this.text_16.setTransform(33.7,328.6);

	this.text_7.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = this.text_11.mask = this.text_12.mask = this.text_13.mask = this.text_14.mask = this.text_15.mask = this.text_16.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7}]},101).wait(101));

	// maskara2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_60 = new cjs.Graphics().p("Apga1IAAk1ITBAAIAAE1g");
	var mask_2_graphics_61 = new cjs.Graphics().p("ApgC+IAAl7ITBAAIAAF7g");
	var mask_2_graphics_62 = new cjs.Graphics().p("ApgDiIAAnDITBAAIAAHDg");
	var mask_2_graphics_63 = new cjs.Graphics().p("ApgEGIAAoLITBAAIAAILg");
	var mask_2_graphics_64 = new cjs.Graphics().p("ApgEqIAApTITBAAIAAJTg");
	var mask_2_graphics_65 = new cjs.Graphics().p("ApgFOIAAqbITBAAIAAKbg");
	var mask_2_graphics_66 = new cjs.Graphics().p("ApgFyIAArjITBAAIAALjg");
	var mask_2_graphics_67 = new cjs.Graphics().p("ApgGWIAAsrITBAAIAAMrg");
	var mask_2_graphics_68 = new cjs.Graphics().p("ApgG7IAAt1ITBAAIAAN1g");
	var mask_2_graphics_69 = new cjs.Graphics().p("ApgHfIAAu9ITBAAIAAO9g");
	var mask_2_graphics_70 = new cjs.Graphics().p("ApgIDIAAwFITBAAIAAQFg");
	var mask_2_graphics_71 = new cjs.Graphics().p("ApgInIAAxNITBAAIAARNg");
	var mask_2_graphics_72 = new cjs.Graphics().p("ApgJLIAAyVITBAAIAASVg");
	var mask_2_graphics_73 = new cjs.Graphics().p("ApgJvIAAzdITBAAIAATdg");
	var mask_2_graphics_74 = new cjs.Graphics().p("ApgKTIAA0lITBAAIAAUlg");
	var mask_2_graphics_75 = new cjs.Graphics().p("ApgK3IAA1tITBAAIAAVtg");
	var mask_2_graphics_76 = new cjs.Graphics().p("ApgLbIAA21ITBAAIAAW1g");
	var mask_2_graphics_77 = new cjs.Graphics().p("ApgL/IAA39ITBAAIAAX9g");
	var mask_2_graphics_78 = new cjs.Graphics().p("ApgMkIAA5HITBAAIAAZHg");
	var mask_2_graphics_79 = new cjs.Graphics().p("ApgNIIAA6PITBAAIAAaPg");
	var mask_2_graphics_80 = new cjs.Graphics().p("ApgNsIAA7XITBAAIAAbXg");
	var mask_2_graphics_81 = new cjs.Graphics().p("ApgOQIAA8fITBAAIAAcfg");
	var mask_2_graphics_82 = new cjs.Graphics().p("ApgO0IAA9nITBAAIAAdng");
	var mask_2_graphics_83 = new cjs.Graphics().p("ApgPYIAA+vITBAAIAAevg");
	var mask_2_graphics_84 = new cjs.Graphics().p("ApgP8IAA/3ITBAAIAAf3g");
	var mask_2_graphics_85 = new cjs.Graphics().p("ApgQgMAAAgg/ITBAAMAAAAg/g");
	var mask_2_graphics_86 = new cjs.Graphics().p("ApgREMAAAgiHITBAAMAAAAiHg");
	var mask_2_graphics_87 = new cjs.Graphics().p("ApgRoMAAAgjPITBAAMAAAAjPg");
	var mask_2_graphics_88 = new cjs.Graphics().p("ApgSNMAAAgkZITBAAMAAAAkZg");
	var mask_2_graphics_89 = new cjs.Graphics().p("ApgSxMAAAglhITBAAMAAAAlhg");
	var mask_2_graphics_90 = new cjs.Graphics().p("ApgTVMAAAgmpITBAAMAAAAmpg");
	var mask_2_graphics_91 = new cjs.Graphics().p("ApgT5MAAAgnxITBAAMAAAAnxg");
	var mask_2_graphics_92 = new cjs.Graphics().p("ApgUdMAAAgo5ITBAAMAAAAo5g");
	var mask_2_graphics_93 = new cjs.Graphics().p("ApgVBMAAAgqBITBAAMAAAAqBg");
	var mask_2_graphics_94 = new cjs.Graphics().p("ApgVlMAAAgrJITBAAMAAAArJg");
	var mask_2_graphics_95 = new cjs.Graphics().p("ApgWJMAAAgsRITBAAMAAAAsRg");
	var mask_2_graphics_96 = new cjs.Graphics().p("ApgWtMAAAgtZITBAAMAAAAtZg");
	var mask_2_graphics_97 = new cjs.Graphics().p("ApgXRMAAAguhITBAAMAAAAuhg");
	var mask_2_graphics_98 = new cjs.Graphics().p("ApgX2MAAAgvrITBAAMAAAAvrg");
	var mask_2_graphics_99 = new cjs.Graphics().p("ApgYaMAAAgwzITBAAMAAAAwzg");
	var mask_2_graphics_100 = new cjs.Graphics().p("ApgaGMAAAgx7ITBAAMAAAAx7g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(60).to({graphics:mask_2_graphics_60,x:57.5,y:171.7}).wait(1).to({graphics:mask_2_graphics_61,x:57.5,y:324.1}).wait(1).to({graphics:mask_2_graphics_62,x:57.5,y:320.3}).wait(1).to({graphics:mask_2_graphics_63,x:57.5,y:316.4}).wait(1).to({graphics:mask_2_graphics_64,x:57.5,y:312.6}).wait(1).to({graphics:mask_2_graphics_65,x:57.5,y:308.7}).wait(1).to({graphics:mask_2_graphics_66,x:57.5,y:304.9}).wait(1).to({graphics:mask_2_graphics_67,x:57.5,y:301.1}).wait(1).to({graphics:mask_2_graphics_68,x:57.5,y:297.2}).wait(1).to({graphics:mask_2_graphics_69,x:57.5,y:293.4}).wait(1).to({graphics:mask_2_graphics_70,x:57.5,y:289.5}).wait(1).to({graphics:mask_2_graphics_71,x:57.5,y:285.7}).wait(1).to({graphics:mask_2_graphics_72,x:57.5,y:281.8}).wait(1).to({graphics:mask_2_graphics_73,x:57.5,y:278}).wait(1).to({graphics:mask_2_graphics_74,x:57.5,y:274.1}).wait(1).to({graphics:mask_2_graphics_75,x:57.5,y:270.3}).wait(1).to({graphics:mask_2_graphics_76,x:57.5,y:266.5}).wait(1).to({graphics:mask_2_graphics_77,x:57.5,y:262.6}).wait(1).to({graphics:mask_2_graphics_78,x:57.5,y:258.8}).wait(1).to({graphics:mask_2_graphics_79,x:57.5,y:254.9}).wait(1).to({graphics:mask_2_graphics_80,x:57.5,y:251.1}).wait(1).to({graphics:mask_2_graphics_81,x:57.5,y:247.2}).wait(1).to({graphics:mask_2_graphics_82,x:57.5,y:243.4}).wait(1).to({graphics:mask_2_graphics_83,x:57.5,y:239.5}).wait(1).to({graphics:mask_2_graphics_84,x:57.5,y:235.7}).wait(1).to({graphics:mask_2_graphics_85,x:57.5,y:231.8}).wait(1).to({graphics:mask_2_graphics_86,x:57.5,y:228}).wait(1).to({graphics:mask_2_graphics_87,x:57.5,y:224.2}).wait(1).to({graphics:mask_2_graphics_88,x:57.5,y:220.3}).wait(1).to({graphics:mask_2_graphics_89,x:57.5,y:216.5}).wait(1).to({graphics:mask_2_graphics_90,x:57.5,y:212.6}).wait(1).to({graphics:mask_2_graphics_91,x:57.5,y:208.8}).wait(1).to({graphics:mask_2_graphics_92,x:57.5,y:204.9}).wait(1).to({graphics:mask_2_graphics_93,x:57.5,y:201.1}).wait(1).to({graphics:mask_2_graphics_94,x:57.5,y:197.2}).wait(1).to({graphics:mask_2_graphics_95,x:57.5,y:193.4}).wait(1).to({graphics:mask_2_graphics_96,x:57.5,y:189.6}).wait(1).to({graphics:mask_2_graphics_97,x:57.5,y:185.7}).wait(1).to({graphics:mask_2_graphics_98,x:57.5,y:181.9}).wait(1).to({graphics:mask_2_graphics_99,x:57.5,y:178}).wait(1).to({graphics:mask_2_graphics_100,x:57.5,y:167}).wait(102));

	// base distancia
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape.setTransform(28.9,51.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_1.setTransform(28.9,104.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_2.setTransform(28.8,157.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_3.setTransform(28.5,211.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_4.setTransform(28.5,265.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAATeMAAAgm7");
	this.shape_5.setTransform(32.7,189.3,1,1.109);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},60).wait(142));

	// maskara (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("AiqdDIAAq5IFVAAIAAK5g");
	var mask_3_graphics_1 = new cjs.Graphics().p("AjTFcIAAq3IGnAAIAAK3g");
	var mask_3_graphics_2 = new cjs.Graphics().p("Aj8FcIAAq3IH5AAIAAK3g");
	var mask_3_graphics_3 = new cjs.Graphics().p("AklFcIAAq3IJLAAIAAK3g");
	var mask_3_graphics_4 = new cjs.Graphics().p("AlOFcIAAq3IKdAAIAAK3g");
	var mask_3_graphics_5 = new cjs.Graphics().p("Al3FcIAAq3ILvAAIAAK3g");
	var mask_3_graphics_6 = new cjs.Graphics().p("AmgFcIAAq3INBAAIAAK3g");
	var mask_3_graphics_7 = new cjs.Graphics().p("AnJFcIAAq3IOTAAIAAK3g");
	var mask_3_graphics_8 = new cjs.Graphics().p("AnyFcIAAq3IPlAAIAAK3g");
	var mask_3_graphics_9 = new cjs.Graphics().p("AobFcIAAq3IQ3AAIAAK3g");
	var mask_3_graphics_10 = new cjs.Graphics().p("ApEFcIAAq3ISJAAIAAK3g");
	var mask_3_graphics_11 = new cjs.Graphics().p("AptFcIAAq3ITbAAIAAK3g");
	var mask_3_graphics_12 = new cjs.Graphics().p("AqWFcIAAq3IUtAAIAAK3g");
	var mask_3_graphics_13 = new cjs.Graphics().p("Aq/FcIAAq3IV/AAIAAK3g");
	var mask_3_graphics_14 = new cjs.Graphics().p("AroFcIAAq3IXRAAIAAK3g");
	var mask_3_graphics_15 = new cjs.Graphics().p("AsRFcIAAq3IYjAAIAAK3g");
	var mask_3_graphics_16 = new cjs.Graphics().p("As6FcIAAq3IZ1AAIAAK3g");
	var mask_3_graphics_17 = new cjs.Graphics().p("AtjFcIAAq3IbHAAIAAK3g");
	var mask_3_graphics_18 = new cjs.Graphics().p("AuMFcIAAq3IcZAAIAAK3g");
	var mask_3_graphics_19 = new cjs.Graphics().p("Au1FcIAAq3IdrAAIAAK3g");
	var mask_3_graphics_20 = new cjs.Graphics().p("AveFcIAAq3Ie9AAIAAK3g");
	var mask_3_graphics_21 = new cjs.Graphics().p("AwHFcIAAq3MAgPAAAIAAK3g");
	var mask_3_graphics_22 = new cjs.Graphics().p("AwwFcIAAq3MAhhAAAIAAK3g");
	var mask_3_graphics_23 = new cjs.Graphics().p("AxYFcIAAq3MAixAAAIAAK3g");
	var mask_3_graphics_24 = new cjs.Graphics().p("AyBFcIAAq3MAkDAAAIAAK3g");
	var mask_3_graphics_25 = new cjs.Graphics().p("AyqFcIAAq3MAlVAAAIAAK3g");
	var mask_3_graphics_26 = new cjs.Graphics().p("AzTFcIAAq3MAmnAAAIAAK3g");
	var mask_3_graphics_27 = new cjs.Graphics().p("Az8FcIAAq3MAn5AAAIAAK3g");
	var mask_3_graphics_28 = new cjs.Graphics().p("A0lFcIAAq3MApLAAAIAAK3g");
	var mask_3_graphics_29 = new cjs.Graphics().p("A1OFcIAAq3MAqdAAAIAAK3g");
	var mask_3_graphics_30 = new cjs.Graphics().p("A13FcIAAq3MArvAAAIAAK3g");
	var mask_3_graphics_31 = new cjs.Graphics().p("A2gFcIAAq3MAtBAAAIAAK3g");
	var mask_3_graphics_32 = new cjs.Graphics().p("A3JFcIAAq3MAuTAAAIAAK3g");
	var mask_3_graphics_33 = new cjs.Graphics().p("A3yFcIAAq3MAvlAAAIAAK3g");
	var mask_3_graphics_34 = new cjs.Graphics().p("A4bFcIAAq3MAw3AAAIAAK3g");
	var mask_3_graphics_35 = new cjs.Graphics().p("A5EFcIAAq3MAyJAAAIAAK3g");
	var mask_3_graphics_36 = new cjs.Graphics().p("A5tFcIAAq3MAzbAAAIAAK3g");
	var mask_3_graphics_37 = new cjs.Graphics().p("A6WFcIAAq3MA0tAAAIAAK3g");
	var mask_3_graphics_38 = new cjs.Graphics().p("A6/FcIAAq3MA1/AAAIAAK3g");
	var mask_3_graphics_39 = new cjs.Graphics().p("A7oFcIAAq3MA3RAAAIAAK3g");
	var mask_3_graphics_40 = new cjs.Graphics().p("A8RFcIAAq3MA4jAAAIAAK3g");
	var mask_3_graphics_41 = new cjs.Graphics().p("A86FcIAAq3MA51AAAIAAK3g");
	var mask_3_graphics_42 = new cjs.Graphics().p("A9jFcIAAq3MA7HAAAIAAK3g");
	var mask_3_graphics_43 = new cjs.Graphics().p("A+MFcIAAq3MA8ZAAAIAAK3g");
	var mask_3_graphics_44 = new cjs.Graphics().p("A+1FcIAAq3MA9rAAAIAAK3g");
	var mask_3_graphics_45 = new cjs.Graphics().p("A/eFcIAAq3MA+9AAAIAAK3g");
	var mask_3_graphics_46 = new cjs.Graphics().p("EggHAFcIAAq3MBAPAAAIAAK3g");
	var mask_3_graphics_47 = new cjs.Graphics().p("EggwAFcIAAq3MBBhAAAIAAK3g");
	var mask_3_graphics_48 = new cjs.Graphics().p("EghZAFcIAAq3MBCzAAAIAAK3g");
	var mask_3_graphics_49 = new cjs.Graphics().p("EgiCAFcIAAq3MBEFAAAIAAK3g");
	var mask_3_graphics_50 = new cjs.Graphics().p("EgirAFcIAAq3MBFXAAAIAAK3g");
	var mask_3_graphics_51 = new cjs.Graphics().p("EgjUAFcIAAq3MBGpAAAIAAK3g");
	var mask_3_graphics_52 = new cjs.Graphics().p("Egj8AFcIAAq3MBH5AAAIAAK3g");
	var mask_3_graphics_53 = new cjs.Graphics().p("EgklAFcIAAq3MBJLAAAIAAK3g");
	var mask_3_graphics_54 = new cjs.Graphics().p("EglOAFcIAAq3MBKdAAAIAAK3g");
	var mask_3_graphics_55 = new cjs.Graphics().p("Egl3AFcIAAq3MBLvAAAIAAK3g");
	var mask_3_graphics_56 = new cjs.Graphics().p("EgmgAFcIAAq3MBNBAAAIAAK3g");
	var mask_3_graphics_57 = new cjs.Graphics().p("EgnJAFcIAAq3MBOTAAAIAAK3g");
	var mask_3_graphics_58 = new cjs.Graphics().p("EgnyAFcIAAq3MBPlAAAIAAK3g");
	var mask_3_graphics_59 = new cjs.Graphics().p("EgobAdDIAAq5MBQ3AAAIAAK5g");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:-12.6,y:186}).wait(1).to({graphics:mask_3_graphics_1,x:-8.2,y:337}).wait(1).to({graphics:mask_3_graphics_2,x:-3.9,y:337}).wait(1).to({graphics:mask_3_graphics_3,x:0.3,y:337}).wait(1).to({graphics:mask_3_graphics_4,x:4.7,y:337}).wait(1).to({graphics:mask_3_graphics_5,x:9,y:337}).wait(1).to({graphics:mask_3_graphics_6,x:13.3,y:337}).wait(1).to({graphics:mask_3_graphics_7,x:17.7,y:337}).wait(1).to({graphics:mask_3_graphics_8,x:22,y:337}).wait(1).to({graphics:mask_3_graphics_9,x:26.3,y:337}).wait(1).to({graphics:mask_3_graphics_10,x:30.7,y:337}).wait(1).to({graphics:mask_3_graphics_11,x:35,y:337}).wait(1).to({graphics:mask_3_graphics_12,x:39.3,y:337}).wait(1).to({graphics:mask_3_graphics_13,x:43.7,y:337}).wait(1).to({graphics:mask_3_graphics_14,x:48,y:337}).wait(1).to({graphics:mask_3_graphics_15,x:52.3,y:337}).wait(1).to({graphics:mask_3_graphics_16,x:56.7,y:337}).wait(1).to({graphics:mask_3_graphics_17,x:61,y:337}).wait(1).to({graphics:mask_3_graphics_18,x:65.4,y:337}).wait(1).to({graphics:mask_3_graphics_19,x:69.7,y:337}).wait(1).to({graphics:mask_3_graphics_20,x:74,y:337}).wait(1).to({graphics:mask_3_graphics_21,x:78.4,y:337}).wait(1).to({graphics:mask_3_graphics_22,x:82.7,y:337}).wait(1).to({graphics:mask_3_graphics_23,x:87,y:337}).wait(1).to({graphics:mask_3_graphics_24,x:91.4,y:337}).wait(1).to({graphics:mask_3_graphics_25,x:95.7,y:337}).wait(1).to({graphics:mask_3_graphics_26,x:100,y:337}).wait(1).to({graphics:mask_3_graphics_27,x:104.4,y:337}).wait(1).to({graphics:mask_3_graphics_28,x:108.7,y:337}).wait(1).to({graphics:mask_3_graphics_29,x:113,y:337}).wait(1).to({graphics:mask_3_graphics_30,x:117.4,y:337}).wait(1).to({graphics:mask_3_graphics_31,x:121.7,y:337}).wait(1).to({graphics:mask_3_graphics_32,x:126,y:337}).wait(1).to({graphics:mask_3_graphics_33,x:130.4,y:337}).wait(1).to({graphics:mask_3_graphics_34,x:134.7,y:337}).wait(1).to({graphics:mask_3_graphics_35,x:139,y:337}).wait(1).to({graphics:mask_3_graphics_36,x:143.4,y:337}).wait(1).to({graphics:mask_3_graphics_37,x:147.7,y:337}).wait(1).to({graphics:mask_3_graphics_38,x:152,y:337}).wait(1).to({graphics:mask_3_graphics_39,x:156.4,y:337}).wait(1).to({graphics:mask_3_graphics_40,x:160.7,y:337}).wait(1).to({graphics:mask_3_graphics_41,x:165,y:337}).wait(1).to({graphics:mask_3_graphics_42,x:169.4,y:337}).wait(1).to({graphics:mask_3_graphics_43,x:173.7,y:337}).wait(1).to({graphics:mask_3_graphics_44,x:178.1,y:337}).wait(1).to({graphics:mask_3_graphics_45,x:182.4,y:337}).wait(1).to({graphics:mask_3_graphics_46,x:186.7,y:337}).wait(1).to({graphics:mask_3_graphics_47,x:191.1,y:337}).wait(1).to({graphics:mask_3_graphics_48,x:195.4,y:337}).wait(1).to({graphics:mask_3_graphics_49,x:199.7,y:337}).wait(1).to({graphics:mask_3_graphics_50,x:204.1,y:337}).wait(1).to({graphics:mask_3_graphics_51,x:208.4,y:337}).wait(1).to({graphics:mask_3_graphics_52,x:212.7,y:337}).wait(1).to({graphics:mask_3_graphics_53,x:217.1,y:337}).wait(1).to({graphics:mask_3_graphics_54,x:221.4,y:337}).wait(1).to({graphics:mask_3_graphics_55,x:225.7,y:337}).wait(1).to({graphics:mask_3_graphics_56,x:230.1,y:337}).wait(1).to({graphics:mask_3_graphics_57,x:234.4,y:337}).wait(1).to({graphics:mask_3_graphics_58,x:238.7,y:337}).wait(1).to({graphics:mask_3_graphics_59,x:243.1,y:186}).wait(143));

	// base tiempo
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_6.setTransform(479.8,322.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_7.setTransform(423.4,322.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_8.setTransform(367.2,322.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_9.setTransform(312.1,322.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_10.setTransform(256.9,322.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_11.setTransform(200.9,322.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_12.setTransform(144.5,322.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_13.setTransform(89.6,322.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("EgjIAAAMBGRAAA");
	this.shape_14.setTransform(255.4,319.5);

	this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(202));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(30.5,319.5,450,6.3);


(lib.Path = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#F09122","#DF081F"],[0,1],22.6,52.5,-22,-52.8).s().p("AEVG3IlKlxIjbFxQg1gdgvglQhehKAhglIECkIIjbjkQARhAAZg6QAzh1AmAdIDYFRIEWkqIBGAlQBBArgbAfIkXEXIF/EWQgbA4gjAxQg0BLghAAQgKAAgJgIg");
	this.shape.setTransform(102.6,102.6,1,1,0,0,0,0.8,-0.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(57.5,58.2,88.7,89.5);


(lib.Path_1 = function() {
	this.initialize();

	// Capa 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#0B6635","#95C030"],[0,1],34.5,77.7,-16.7,-68.8).s().p("ApNImQhWg8hWgzIhFgnIg/kOIAKAAQCVAUD6CeQB9BPBfBLQAhogGXnoQCAiZCWiAQBLhBAyghIE7E3QpsF1kSKEQhVDKgpDNQgVBmgDA+QiljQkSjAg");
	this.shape_1.setTransform(97.9,103.7,0.5,0.5);

	this.addChild(this.shape_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(53.3,56.2,89.4,95.1);

(lib.btn3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,1).p("AoNknQhkAAAABgIAAGOQAABhBkAAIQbAAQBkAAAAhhIAAmOQAAhghkAAg");
	this.shape.setTransform(63,29.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:29.4}}]}).to({state:[{t:this.shape,p:{scaleX:1.1,scaleY:1.1,y:29.3}}]},1).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:29.4}}]},1).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:29.4}}]},1).wait(1));

	// Capa 1
	this.instance = new lib.Mapadebits3();

	this.instance_1 = new lib.Mapadebits6();
	this.instance_1.setTransform(-6.2,-2.9);

	this.shape_1 = new lib.Mapadebits3();
	

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.2,125.7,60.3);


(lib.btn2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,1).p("AoNknQhkAAAABgIAAGOQAABhBkAAIQbAAQBkAAAAhhIAAmOQAAhghkAAg");
	this.shape.setTransform(61,39);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:39}}]}).to({state:[{t:this.shape,p:{scaleX:1.1,scaleY:1.1,y:38.9}}]},1).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:39}}]},1).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:39}}]},1).wait(1));

	// Capa 1
	this.instance = new lib.Mapadebits1();
	this.instance.setTransform(-1.5,9.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img.boton3).s().p("AAAAAIAAAAIAAAAg");
	this.shape_1.setTransform(123.4,69.4);

	this.instance_1 = new lib.Mapadebits4();
	this.instance_1.setTransform(-7.7,6.5);

	this.shape_2 =  new lib.Mapadebits1();
	this.shape_2.setTransform(-1.5,9.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{x:123.4,y:69.4}},{t:this.instance}]}).to({state:[{t:this.shape_1,p:{x:129.6,y:72.4}},{t:this.instance_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.6,9.4,125.4,60.2);


(lib.btn1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,1).p("AoNknQhkAAAABgIAAGOQAABhBkAAIQbAAQBkAAAAhhIAAmOQAAhghkAAg");
	this.shape.setTransform(63,29.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:29.4}}]}).to({state:[{t:this.shape,p:{scaleX:1.1,scaleY:1.1,y:29.3}}]},1).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:29.4}}]},1).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:29.4}}]},1).wait(1));

	// Capa 1
	this.instance = new lib.Mapadebits2();

	this.instance_1 = new lib.Mapadebits5();
	this.instance_1.setTransform(-6.2,-2.9);

	this.shape_1 = new lib.Mapadebits2();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.2,125.7,60.3);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-6,-16.6,1.247,1.197);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0,5.2,1.247,1.197);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_1.setTransform(0,5.2,1.247,1.197);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.shape,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.text,p:{scaleX:1.412,scaleY:1.356,x:-8.5,y:-19.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.5,-16.7,38.7,40.9);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.mc_grafica3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// boton
	
	// animacio
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0789B4").ss(2,1,1).p("AAAAAIACAA");
	this.shape.setTransform(144.2,212);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#0789B4").ss(2,1,1).p("AoqIcIRVw3");
	this.shape_1.setTransform(88.6,266);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#0789B4").ss(2,1,1).p("Ao/IcIRUw3IArAA");
	this.shape_2.setTransform(90.7,266);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#0789B4").ss(2,1,1).p("ApSIcIRUw3IBRAA");
	this.shape_3.setTransform(92.6,266);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#0789B4").ss(2,1,1).p("AplIcIRUw3IB3AA");
	this.shape_4.setTransform(94.5,266);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#0789B4").ss(2,1,1).p("Ap5IcIRUw3ICfAA");
	this.shape_5.setTransform(96.5,266);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#0789B4").ss(2,1,1).p("AqMIcIRUw3IDFAA");
	this.shape_6.setTransform(98.4,266);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#0789B4").ss(2,1,1).p("AqfIcIRUw3IDrAA");
	this.shape_7.setTransform(100.3,266);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#0789B4").ss(2,1,1).p("AqzIcIRUw3IETAA");
	this.shape_8.setTransform(102.3,266);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#0789B4").ss(2,1,1).p("ArGIcIRUw3IE5AA");
	this.shape_9.setTransform(104.2,266);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#0789B4").ss(2,1,1).p("ArZIcIRUw3IFfAA");
	this.shape_10.setTransform(106.1,266);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#0789B4").ss(2,1,1).p("ArtIcIRUw3IGHAA");
	this.shape_11.setTransform(108.1,266);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#0789B4").ss(2,1,1).p("AsAIcIRUw3IGtAA");
	this.shape_12.setTransform(110,266);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#0789B4").ss(2,1,1).p("AsTIcIRUw3IHTAA");
	this.shape_13.setTransform(111.9,266);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#0789B4").ss(2,1,1).p("AsnIcIRUw3IH7AA");
	this.shape_14.setTransform(113.9,266);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#0789B4").ss(2,1,1).p("As6IcIRUw3IIhAA");
	this.shape_15.setTransform(115.8,266);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#0789B4").ss(2,1,1).p("AtNIcIRUw3IJHAA");
	this.shape_16.setTransform(117.7,266);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#0789B4").ss(2,1,1).p("AtgIcIRUw3IJtAA");
	this.shape_17.setTransform(119.6,266);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#0789B4").ss(2,1,1).p("At0IcIRUw3IKVAA");
	this.shape_18.setTransform(121.6,266);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#0789B4").ss(2,1,1).p("AuHIcIRUw3IK7AA");
	this.shape_19.setTransform(123.5,266);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#0789B4").ss(2,1,1).p("AuaIcIRUw3ILhAA");
	this.shape_20.setTransform(125.4,266);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#0789B4").ss(2,1,1).p("AuuIcIRUw3IMJAA");
	this.shape_21.setTransform(127.4,266);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#0789B4").ss(2,1,1).p("AvBIcIRUw3IMvAA");
	this.shape_22.setTransform(129.3,266);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#0789B4").ss(2,1,1).p("AvUIcIRUw3INVAA");
	this.shape_23.setTransform(131.2,266);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#0789B4").ss(2,1,1).p("AvoIcIRUw3IN9AA");
	this.shape_24.setTransform(133.2,266);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#0789B4").ss(2,1,1).p("Av7IcIRUw3IOjAA");
	this.shape_25.setTransform(135.1,266);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#0789B4").ss(2,1,1).p("AwOIcIRUw3IPJAA");
	this.shape_26.setTransform(137,266);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#0789B4").ss(2,1,1).p("AwiIcIRUw3IPxAA");
	this.shape_27.setTransform(139,266);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#0789B4").ss(2,1,1).p("Aw1IcIRUw3IQXAA");
	this.shape_28.setTransform(140.9,266);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#0789B4").ss(2,1,1).p("AxIIcIRUw3IQ9AA");
	this.shape_29.setTransform(142.8,266);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#0789B4").ss(2,1,1).p("AoxAAIRjAA");
	this.shape_30.setTransform(200.3,212);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_1},{t:this.shape_30}]},1).wait(1));

	// Capa 2
	this.text = new cjs.Text("0", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.setTransform(16.4,313.5);

	this.text_1 = new cjs.Text(txt['distancia'], "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.setTransform(63.4,19.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_31.setTransform(28.9,51.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_32.setTransform(28.9,104.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_33.setTransform(28.8,157.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_34.setTransform(28.5,211.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AApAAIhRAA");
	this.shape_35.setTransform(28.5,265.3);

	this.text_2 = new cjs.Text("25", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.setTransform(11.3,45.5);

	this.text_3 = new cjs.Text("20", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 19;
	this.text_3.setTransform(11.3,97.9);

	this.text_4 = new cjs.Text("15", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 19;
	this.text_4.setTransform(11.3,150.7);

	this.text_5 = new cjs.Text("10", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 19;
	this.text_5.setTransform(11.3,205.3);

	this.text_6 = new cjs.Text("5", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 19;
	this.text_6.setTransform(11.3,258.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAATeMAAAgm7");
	this.shape_36.setTransform(32.7,189.3,1,1.109);

	this.text_7 = new cjs.Text(txt['tiempo'], "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 19;
	this.text_7.setTransform(441,348.4);

	this.text_8 = new cjs.Text("40", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 19;
	this.text_8.setTransform(478.8,328.6);

	this.text_9 = new cjs.Text("35", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 19;
	this.text_9.setTransform(422.8,328.6);

	this.text_10 = new cjs.Text("30", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 19;
	this.text_10.setTransform(366.5,328.6);

	this.text_11 = new cjs.Text("25", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 19;
	this.text_11.setTransform(311.6,328.6);

	this.text_12 = new cjs.Text("20", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 19;
	this.text_12.setTransform(256.5,328.6);

	this.text_13 = new cjs.Text("15", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 19;
	this.text_13.setTransform(200.8,328.6);

	this.text_14 = new cjs.Text("10", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 19;
	this.text_14.setTransform(144.4,328.6);

	this.text_15 = new cjs.Text("5", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 19;
	this.text_15.setTransform(89.1,328.6);

	this.text_16 = new cjs.Text("0", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 19;
	this.text_16.setTransform(33.7,328.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_37.setTransform(479.8,322.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_38.setTransform(423.4,322.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_39.setTransform(367.2,322.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_40.setTransform(312.1,322.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgdIAAA7");
	this.shape_41.setTransform(256.9,322.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_42.setTransform(200.9,322.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_43.setTransform(144.5,322.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("AAAgcIAAA5");
	this.shape_44.setTransform(89.6,322.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#1D1D1B").ss(1,0,0,4).p("EgjIAAAMBGRAAA");
	this.shape_45.setTransform(255.4,319.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.shape_36},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.text_1},{t:this.text}]}).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.3,19.9,487.5,344);


(lib.mc_fichaerror = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Path();
	this.instance.setTransform(985.8,195.1,0.741,0.741,0,0,0,873.6,284.6);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.706)",7,7,15);

	this.text = new cjs.Text("", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 528;
	this.text.setTransform(44.8,58.6);
  var html = createDiv(txt['incorrecto'], "Verdana", "20px", '530px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(44, 58-608);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("EAuagQtMhczAAAQhkAAAABkIAAeUQAABkBkAAMBczAAAQBkAAAAhkIAA+UQAAhkhkAAg");
	this.shape.setTransform(307.1,107.1);

	this.addChild(this.shape,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,614.2,214.2);


      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}